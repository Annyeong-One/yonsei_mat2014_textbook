# Python Variables - Complete Tutorial

## What are Variables?

Variables are containers for storing data values. Think of them as labeled boxes where you can store information and retrieve it later.

## Creating Variables

In Python, you don't need to declare variable types explicitly. Python figures it out automatically!

```python
# Creating variables
name = "Alice"
age = 25
height = 5.6
is_student = True
```

## Variable Naming Rules

### Must Follow:
1. Must start with a letter or underscore (_)
2. Cannot start with a number
3. Can only contain alphanumeric characters and underscores (A-z, 0-9, and _)
4. Case-sensitive (age, Age, and AGE are different variables)
5. Cannot be a Python keyword

### Valid Names:
```python
my_variable = 10
_private_var = 20
myVar = 30
MY_CONSTANT = 40
variable2 = 50
```

### Invalid Names:
```python
# 2variable = 10  # Cannot start with number
# my-variable = 20  # Hyphens not allowed
# my variable = 30  # Spaces not allowed
# for = 40  # 'for' is a Python keyword
```

## Naming Conventions (Best Practices)

### 1. Snake Case (Recommended for Python)
```python
first_name = "John"
user_age = 30
total_price = 99.99
```

### 2. Camel Case
```python
firstName = "John"
userAge = 30
totalPrice = 99.99
```

### 3. Constants (All Uppercase)
```python
PI = 3.14159
MAX_SIZE = 100
DATABASE_URL = "localhost"
```

## Assigning Values

### Simple Assignment
```python
x = 5
y = "Hello"
```

### Multiple Assignment
```python
# Assign same value to multiple variables
a = b = c = 100

# Assign different values to multiple variables
x, y, z = 1, 2, 3
```

### Swapping Variables
```python
a = 10
b = 20

# Traditional way (other languages)
temp = a
a = b
b = temp

# Pythonic way
a, b = b, a
```

## Reassigning Variables

Variables can be reassigned with different values:

```python
x = 10
print(x)  # Output: 10

x = 20
print(x)  # Output: 20

x = "Now I'm a string!"
print(x)  # Output: Now I'm a string!
```

## Variable Scope (Introduction)

```python
# Global variable
global_var = "I'm accessible everywhere"

def my_function():
    # Local variable
    local_var = "I only exist inside this function"
    print(global_var)  # Can access global variable
    print(local_var)

my_function()
# print(local_var)  # This would cause an error!
```

## Deleting Variables

```python
x = 10
print(x)  # Output: 10

del x
# print(x)  # This would cause an error - x no longer exists
```

## Type Checking

```python
x = 5
print(type(x))  # Output: <class 'int'>

name = "Alice"
print(type(name))  # Output: <class 'str'>
```

## Best Practices

1. **Use descriptive names**: `user_age` is better than `ua` or `x`
2. **Be consistent**: Choose one naming convention and stick with it
3. **Avoid single-letter names**: Except for loops (i, j, k) or mathematical formulas
4. **Don't use built-in names**: Avoid names like `list`, `str`, `int`
5. **Use meaningful names**: `student_count` is better than `number` or `count`

## Common Mistakes

```python
# ❌ Using reserved keywords
# class = "Math"  # 'class' is a keyword

# ❌ Starting with numbers
# 1st_place = "Gold"

# ❌ Using special characters
# user@name = "John"

# ✅ Correct alternatives
student_class = "Math"
first_place = "Gold"
user_name = "John"
```

## Practice Tips

1. Start with simple, descriptive names
2. Practice the snake_case convention
3. Read your code aloud - if the variable name makes sense, it's good!
4. Remember: code is read more often than it's written

## Next Steps

Now that you understand variables, you're ready to learn about different data types that variables can hold!
