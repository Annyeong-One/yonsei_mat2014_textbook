"""
Python Variables - Practice Exercises
Try to solve these without looking at the solutions first!
"""

print("Exercise 1: Create Variables")
print("-" * 40)
print("Task: Create variables for your personal information")
print("- your_name (string)")
print("- your_age (integer)")
print("- your_height (float, in meters)")
print("- is_learning_python (boolean)")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 2: Multiple Assignment")
print("-" * 40)
print("Task: Assign the value 0 to three variables: x, y, and z in one line")
print()
# Write your code below:




print("\n" + "=" * 50 + "\n")

print("Exercise 3: Variable Swap")
print("-" * 40)
print("Task: Given two variables, swap their values")
print("Start with: a = 'cat', b = 'dog'")
print("End with: a = 'dog', b = 'cat'")
print()
# Write your code below:
a = "cat"
b = "dog"





print("\n" + "=" * 50 + "\n")

print("Exercise 4: Calculate Total")
print("-" * 40)
print("Task: Calculate total price")
print("- Create a variable 'price' with value 29.99")
print("- Create a variable 'quantity' with value 5")
print("- Calculate and store the total in a variable 'total'")
print("- Print the result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 5: String Concatenation")
print("-" * 40)
print("Task: Create a full name from parts")
print("- first_name = 'John'")
print("- middle_name = 'Michael'")
print("- last_name = 'Smith'")
print("- Create full_name by combining all three with spaces")
print("- Print the full name")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 6: Temperature Converter Variables")
print("-" * 40)
print("Task: Set up variables for temperature conversion")
print("- Create celsius = 25")
print("- Convert to Fahrenheit: fahrenheit = (celsius * 9/5) + 32")
print("- Print both temperatures with labels")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 7: Age Calculator")
print("-" * 40)
print("Task: Calculate age in days")
print("- Create a variable 'age_in_years' with your age")
print("- Calculate 'age_in_days' (assume 365 days per year)")
print("- Print a message: 'You are approximately X days old'")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 8: Shopping Cart")
print("-" * 40)
print("Task: Create variables for a shopping cart")
print("- item1_name = 'Apple', item1_price = 1.50, item1_quantity = 4")
print("- item2_name = 'Bread', item2_price = 2.99, item2_quantity = 2")
print("- Calculate item1_total and item2_total")
print("- Calculate cart_total")
print("- Print a summary")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 9: Variable Type Checking")
print("-" * 40)
print("Task: Create variables of different types and print their types")
print("- Create an integer variable")
print("- Create a float variable")
print("- Create a string variable")
print("- Create a boolean variable")
print("- Print each with its type")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 10: Rectangle Area Calculator")
print("-" * 40)
print("Task: Calculate the area and perimeter of a rectangle")
print("- length = 10")
print("- width = 5")
print("- Calculate area (length * width)")
print("- Calculate perimeter (2 * (length + width))")
print("- Print both results with labels")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")
print("Exercises completed! Check solutions.py for answers.")
