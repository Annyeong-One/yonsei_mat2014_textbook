"""
Python Variables - Exercise Solutions
Compare your solutions with these!
"""

print("=" * 50)
print("Exercise 1 Solution: Create Variables")
print("=" * 50)

your_name = "Alice"
your_age = 25
your_height = 1.65
is_learning_python = True

print(f"Name: {your_name}")
print(f"Age: {your_age}")
print(f"Height: {your_height}m")
print(f"Learning Python: {is_learning_python}")
print()

print("=" * 50)
print("Exercise 2 Solution: Multiple Assignment")
print("=" * 50)

x = y = z = 0
print(f"x = {x}, y = {y}, z = {z}")
print()

print("=" * 50)
print("Exercise 3 Solution: Variable Swap")
print("=" * 50)

a = "cat"
b = "dog"
print(f"Before swap: a = '{a}', b = '{b}'")

# Solution - Pythonic way
a, b = b, a
print(f"After swap: a = '{a}', b = '{b}'")
print()

print("=" * 50)
print("Exercise 4 Solution: Calculate Total")
print("=" * 50)

price = 29.99
quantity = 5
total = price * quantity

print(f"Price: ${price}")
print(f"Quantity: {quantity}")
print(f"Total: ${total:.2f}")
print()

print("=" * 50)
print("Exercise 5 Solution: String Concatenation")
print("=" * 50)

first_name = "John"
middle_name = "Michael"
last_name = "Smith"

# Method 1: Using + operator
full_name = first_name + " " + middle_name + " " + last_name
print(f"Method 1: {full_name}")

# Method 2: Using f-string (preferred)
full_name = f"{first_name} {middle_name} {last_name}"
print(f"Method 2: {full_name}")
print()

print("=" * 50)
print("Exercise 6 Solution: Temperature Converter")
print("=" * 50)

celsius = 25
fahrenheit = (celsius * 9/5) + 32

print(f"Temperature in Celsius: {celsius}°C")
print(f"Temperature in Fahrenheit: {fahrenheit}°F")
print()

print("=" * 50)
print("Exercise 7 Solution: Age Calculator")
print("=" * 50)

age_in_years = 25
age_in_days = age_in_years * 365

print(f"You are approximately {age_in_days} days old")
print(f"(Based on {age_in_years} years)")
print()

print("=" * 50)
print("Exercise 8 Solution: Shopping Cart")
print("=" * 50)

item1_name = "Apple"
item1_price = 1.50
item1_quantity = 4

item2_name = "Bread"
item2_price = 2.99
item2_quantity = 2

item1_total = item1_price * item1_quantity
item2_total = item2_price * item2_quantity
cart_total = item1_total + item2_total

print("Shopping Cart Summary:")
print(f"{item1_name}: ${item1_price} x {item1_quantity} = ${item1_total:.2f}")
print(f"{item2_name}: ${item2_price} x {item2_quantity} = ${item2_total:.2f}")
print(f"Total: ${cart_total:.2f}")
print()

print("=" * 50)
print("Exercise 9 Solution: Variable Type Checking")
print("=" * 50)

my_integer = 42
my_float = 3.14
my_string = "Hello, Python!"
my_boolean = True

print(f"{my_integer} is type: {type(my_integer)}")
print(f"{my_float} is type: {type(my_float)}")
print(f"{my_string} is type: {type(my_string)}")
print(f"{my_boolean} is type: {type(my_boolean)}")
print()

print("=" * 50)
print("Exercise 10 Solution: Rectangle Calculator")
print("=" * 50)

length = 10
width = 5

area = length * width
perimeter = 2 * (length + width)

print(f"Rectangle dimensions: {length} x {width}")
print(f"Area: {area} square units")
print(f"Perimeter: {perimeter} units")
print()

print("=" * 50)
print("All solutions completed!")
print("=" * 50)
print()
print("Key Takeaways:")
print("- Variables store data and can be reassigned")
print("- Use descriptive names with snake_case")
print("- Python is dynamically typed")
print("- Multiple assignment and swapping are Pythonic")
print("- Use f-strings for modern string formatting")
