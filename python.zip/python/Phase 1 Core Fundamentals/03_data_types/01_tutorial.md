# Python Data Types - Complete Tutorial

## What are Data Types?

Data types define the kind of data a variable can hold and what operations can be performed on it. Python has several built-in data types that are essential for programming.

## Built-in Data Types

Python has the following standard data types:

### 1. Numeric Types
- `int` - Integer numbers
- `float` - Decimal numbers
- `complex` - Complex numbers

### 2. Text Type
- `str` - Strings (text)

### 3. Boolean Type
- `bool` - True or False

### 4. Sequence Types
- `list` - Ordered, mutable collection
- `tuple` - Ordered, immutable collection
- `range` - Sequence of numbers

### 5. Mapping Type
- `dict` - Key-value pairs (dictionary)

### 6. Set Types
- `set` - Unordered collection of unique items
- `frozenset` - Immutable set

### 7. None Type
- `NoneType` - Represents absence of value

---

## 1. Integer (int)

Whole numbers without decimal points.

```python
age = 25
year = 2024
temperature = -15
big_number = 1_000_000  # Underscores for readability

print(type(age))  # <class 'int'>
```

### Integer Operations
```python
a = 10
b = 3

print(a + b)   # Addition: 13
print(a - b)   # Subtraction: 7
print(a * b)   # Multiplication: 30
print(a / b)   # Division (float): 3.333...
print(a // b)  # Floor division: 3
print(a % b)   # Modulus (remainder): 1
print(a ** b)  # Exponentiation: 1000
```

---

## 2. Float (float)

Numbers with decimal points.

```python
price = 19.99
pi = 3.14159
scientific = 1.5e3  # Scientific notation (1500.0)
small = 1.5e-3  # 0.0015

print(type(price))  # <class 'float'>
```

### Float Operations
```python
x = 10.5
y = 2.5

print(x + y)   # 13.0
print(x - y)   # 8.0
print(x * y)   # 26.25
print(x / y)   # 4.2
```

### Float Precision
```python
# Be careful with float precision!
result = 0.1 + 0.2
print(result)  # 0.30000000000000004

# Use round() for precision
print(round(result, 2))  # 0.3
```

---

## 3. String (str)

Text data enclosed in quotes.

```python
name = "Alice"
message = 'Hello World'
multiline = """This is a
multiline string"""
multiline2 = '''Also works
with single quotes'''

print(type(name))  # <class 'str'>
```

### String Operations

#### Concatenation
```python
first = "Hello"
last = "World"
full = first + " " + last  # "Hello World"
```

#### Repetition
```python
laugh = "Ha" * 3  # "HaHaHa"
```

#### Indexing
```python
text = "Python"
print(text[0])   # 'P' (first character)
print(text[-1])  # 'n' (last character)
```

#### Slicing
```python
text = "Python"
print(text[0:3])   # 'Pyt'
print(text[:3])    # 'Pyt'
print(text[3:])    # 'hon'
print(text[-3:])   # 'hon'
```

#### String Methods
```python
text = "hello world"
print(text.upper())       # 'HELLO WORLD'
print(text.capitalize())  # 'Hello world'
print(text.title())       # 'Hello World'
print(text.replace("world", "Python"))  # 'hello Python'
print(text.split())       # ['hello', 'world']
print(len(text))          # 11
```

### String Formatting

#### Method 1: f-strings (Recommended, Python 3.6+)
```python
name = "Alice"
age = 30
print(f"My name is {name} and I'm {age} years old")
```

#### Method 2: format() method
```python
print("My name is {} and I'm {} years old".format(name, age))
```

#### Method 3: % operator (Old style)
```python
print("My name is %s and I'm %d years old" % (name, age))
```

---

## 4. Boolean (bool)

Represents truth values: `True` or `False`.

```python
is_active = True
is_deleted = False

print(type(is_active))  # <class 'bool'>
```

### Boolean Operations
```python
a = True
b = False

print(a and b)   # False (logical AND)
print(a or b)    # True (logical OR)
print(not a)     # False (logical NOT)
```

### Comparison Returns Booleans
```python
x = 10
y = 20

print(x > y)    # False
print(x < y)    # True
print(x == y)   # False
print(x != y)   # True
```

### Truthy and Falsy Values
```python
# Falsy values (evaluate to False)
bool(0)          # False
bool(0.0)        # False
bool("")         # False (empty string)
bool([])         # False (empty list)
bool(None)       # False

# Truthy values (evaluate to True)
bool(1)          # True
bool(-1)         # True
bool("text")     # True
bool([1, 2])     # True
```

---

## 5. List (list)

Ordered, mutable collection of items.

```python
numbers = [1, 2, 3, 4, 5]
fruits = ["apple", "banana", "orange"]
mixed = [1, "hello", 3.14, True]
nested = [[1, 2], [3, 4]]

print(type(numbers))  # <class 'list'>
```

### List Operations
```python
fruits = ["apple", "banana", "orange"]

# Accessing elements
print(fruits[0])      # 'apple'
print(fruits[-1])     # 'orange'

# Modifying elements
fruits[1] = "grape"
print(fruits)         # ['apple', 'grape', 'orange']

# Adding elements
fruits.append("mango")
print(fruits)         # ['apple', 'grape', 'orange', 'mango']

# Removing elements
fruits.remove("grape")
print(fruits)         # ['apple', 'orange', 'mango']

# Length
print(len(fruits))    # 3

# Slicing
print(fruits[1:])     # ['orange', 'mango']
```

---

## 6. Tuple (tuple)

Ordered, immutable collection of items.

```python
coordinates = (10, 20)
colors = ("red", "green", "blue")
single_item = (42,)  # Note the comma!

print(type(coordinates))  # <class 'tuple'>
```

### Tuple Operations
```python
point = (10, 20, 30)

# Accessing elements
print(point[0])       # 10

# Cannot modify tuples!
# point[0] = 15       # This would cause an error!

# Unpacking
x, y, z = point
print(f"x={x}, y={y}, z={z}")
```

---

## 7. Dictionary (dict)

Unordered collection of key-value pairs.

```python
person = {
    "name": "Alice",
    "age": 30,
    "city": "New York"
}

print(type(person))  # <class 'dict'>
```

### Dictionary Operations
```python
person = {"name": "Alice", "age": 30}

# Accessing values
print(person["name"])        # 'Alice'
print(person.get("age"))     # 30

# Adding/Modifying
person["email"] = "alice@email.com"
person["age"] = 31

# Removing
del person["email"]

# Keys and values
print(person.keys())         # dict_keys(['name', 'age'])
print(person.values())       # dict_values(['Alice', 31])
```

---

## 8. Set (set)

Unordered collection of unique items.

```python
numbers = {1, 2, 3, 4, 5}
unique_letters = {"a", "b", "c"}

print(type(numbers))  # <class 'set'>
```

### Set Operations
```python
set1 = {1, 2, 3}
set2 = {3, 4, 5}

print(set1 | set2)   # Union: {1, 2, 3, 4, 5}
print(set1 & set2)   # Intersection: {3}
print(set1 - set2)   # Difference: {1, 2}
```

---

## 9. None Type

Represents the absence of a value.

```python
result = None
print(type(result))  # <class 'NoneType'>

# Commonly used as default value
def greet(name=None):
    if name is None:
        print("Hello, Guest!")
    else:
        print(f"Hello, {name}!")
```

---

## Type Conversion (Casting)

Convert between different data types:

```python
# To integer
x = int("10")        # String to int: 10
y = int(3.7)         # Float to int: 3

# To float
a = float("3.14")    # String to float: 3.14
b = float(5)         # Int to float: 5.0

# To string
c = str(100)         # Int to string: "100"
d = str(3.14)        # Float to string: "3.14"

# To list
e = list("hello")    # String to list: ['h', 'e', 'l', 'l', 'o']
f = list((1, 2, 3))  # Tuple to list: [1, 2, 3]

# To boolean
g = bool(1)          # True
h = bool(0)          # False
```

---

## Checking Data Types

```python
x = 42
y = "hello"

# Using type()
print(type(x))           # <class 'int'>
print(type(y))           # <class 'str'>

# Using isinstance()
print(isinstance(x, int))      # True
print(isinstance(y, str))      # True
print(isinstance(x, (int, float)))  # True (checks multiple types)
```

---

## Best Practices

1. **Choose the right data type**: Use the most appropriate type for your data
2. **Immutable for constants**: Use tuples for data that shouldn't change
3. **Lists for collections**: Use lists when you need to modify collections
4. **Dictionaries for mappings**: Use dicts for key-value relationships
5. **Type hints (Python 3.5+)**:
```python
def greet(name: str) -> str:
    return f"Hello, {name}"
```

---

## Common Mistakes

```python
# ❌ Confusing division operators
print(7 / 2)   # 3.5 (always returns float)
print(7 // 2)  # 3 (floor division)

# ❌ Modifying tuples
# my_tuple = (1, 2, 3)
# my_tuple[0] = 10  # Error!

# ❌ Using mutable default arguments
# def add_item(item, my_list=[]):  # Don't do this!
#     my_list.append(item)

# ✅ Correct way
def add_item(item, my_list=None):
    if my_list is None:
        my_list = []
    my_list.append(item)
```

---

## Summary

| Data Type | Mutable? | Ordered? | Example |
|-----------|----------|----------|---------|
| int | No | - | `42` |
| float | No | - | `3.14` |
| str | No | Yes | `"hello"` |
| bool | No | - | `True` |
| list | Yes | Yes | `[1, 2, 3]` |
| tuple | No | Yes | `(1, 2, 3)` |
| dict | Yes | No* | `{"key": "value"}` |
| set | Yes | No | `{1, 2, 3}` |

*Python 3.7+ maintains insertion order for dictionaries

---

## Next Steps

Now that you understand data types, you're ready to learn about operators to manipulate this data!
