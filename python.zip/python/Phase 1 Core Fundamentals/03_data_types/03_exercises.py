"""
Python Data Types - Practice Exercises
Try to solve these without looking at the solutions first!
"""

print("Exercise 1: Working with Integers")
print("-" * 40)
print("Task:")
print("- Create a variable 'birth_year' with your birth year")
print("- Create a variable 'current_year' with 2024")
print("- Calculate your age and store it in 'age'")
print("- Print: 'I am approximately X years old'")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 2: Float Calculations")
print("-" * 40)
print("Task:")
print("- Create 'radius' = 5.0")
print("- Calculate circle area: area = 3.14159 * radius ** 2")
print("- Calculate circumference: circumference = 2 * 3.14159 * radius")
print("- Print both with 2 decimal places")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 3: String Manipulation")
print("-" * 40)
print("Task:")
print("- Create a variable 'sentence' = 'python programming is fun'")
print("- Convert it to title case")
print("- Replace 'fun' with 'awesome'")
print("- Split it into a list of words")
print("- Print each result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 4: String Slicing")
print("-" * 40)
print("Task:")
print("- Create 'text' = 'Hello, World!'")
print("- Extract 'Hello' (first 5 characters)")
print("- Extract 'World' (characters from index 7 to 12)")
print("- Extract every second character")
print("- Print each result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 5: Boolean Logic")
print("-" * 40)
print("Task:")
print("- Create variables: age = 18, has_license = True, has_car = False")
print("- Check if person can drive: age >= 18 AND has_license")
print("- Check if person can drive independently: can_drive AND has_car")
print("- Print both results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 6: Working with Lists")
print("-" * 40)
print("Task:")
print("- Create a list of your 5 favorite foods")
print("- Add one more food to the end")
print("- Remove the second food")
print("- Print the first and last food")
print("- Print the length of the list")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 7: List Operations")
print("-" * 40)
print("Task:")
print("- Create 'numbers' = [10, 20, 30, 40, 50]")
print("- Calculate and print the sum of all numbers")
print("- Calculate and print the average")
print("- Find and print the maximum and minimum values")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 8: Tuples and Unpacking")
print("-" * 40)
print("Task:")
print("- Create a tuple with your (name, age, city)")
print("- Unpack the tuple into three separate variables")
print("- Print: 'My name is X, I am Y years old, and I live in Z'")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 9: Dictionary Operations")
print("-" * 40)
print("Task:")
print("- Create a dictionary 'student' with keys: name, age, grade, subjects")
print("- subjects should be a list of 3 subjects")
print("- Add a new key 'gpa' with value 3.8")
print("- Update the grade")
print("- Print all keys and values")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 10: Sets and Uniqueness")
print("-" * 40)
print("Task:")
print("- Create a list with duplicate numbers: [1, 2, 2, 3, 3, 3, 4, 4, 4, 4]")
print("- Convert it to a set to remove duplicates")
print("- Convert back to a sorted list")
print("- Print the result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 11: Type Conversion")
print("-" * 40)
print("Task:")
print("- Create 'num_str' = '100'")
print("- Convert it to int and add 50")
print("- Convert the result to float")
print("- Convert the float to string and concatenate with ' dollars'")
print("- Print the final string")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 12: Mixed Data Types")
print("-" * 40)
print("Task:")
print("- Create a dictionary representing a book:")
print("  - title (string)")
print("  - author (string)")
print("  - year (int)")
print("  - price (float)")
print("  - in_stock (boolean)")
print("  - genres (list of strings)")
print("- Print each field with its type")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 13: None and Default Values")
print("-" * 40)
print("Task:")
print("- Create a variable 'result' = None")
print("- Check if result is None using 'is'")
print("- If None, set result to 'No data available'")
print("- Print the result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 14: Nested Data Structures")
print("-" * 40)
print("Task:")
print("- Create a list of 3 dictionaries, each representing a person")
print("- Each person should have: name, age, and hobbies (list)")
print("- Print the name of the second person")
print("- Print all hobbies of the third person")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 15: Practical Application")
print("-" * 40)
print("Task: Create a simple inventory system")
print("- Create a dictionary with 3 products")
print("- Each product: name, price (float), quantity (int), available (bool)")
print("- Calculate total inventory value (sum of price * quantity for all products)")
print("- Print inventory and total value")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")
print("Exercises completed! Check solutions.py for answers.")
