"""
Python Data Types - Exercise Solutions
Compare your solutions with these!
"""

print("=" * 50)
print("Exercise 1 Solution: Working with Integers")
print("=" * 50)

birth_year = 1995
current_year = 2024
age = current_year - birth_year

print(f"I am approximately {age} years old")
print()

print("=" * 50)
print("Exercise 2 Solution: Float Calculations")
print("=" * 50)

radius = 5.0
area = 3.14159 * radius ** 2
circumference = 2 * 3.14159 * radius

print(f"Circle with radius {radius}")
print(f"Area: {area:.2f}")
print(f"Circumference: {circumference:.2f}")
print()

print("=" * 50)
print("Exercise 3 Solution: String Manipulation")
print("=" * 50)

sentence = 'python programming is fun'
print(f"Original: {sentence}")

title_case = sentence.title()
print(f"Title case: {title_case}")

replaced = sentence.replace('fun', 'awesome')
print(f"Replaced: {replaced}")

words = sentence.split()
print(f"Words list: {words}")
print()

print("=" * 50)
print("Exercise 4 Solution: String Slicing")
print("=" * 50)

text = 'Hello, World!'
print(f"Original: {text}")

hello = text[:5]
print(f"First 5 chars: {hello}")

world = text[7:12]
print(f"Characters 7-12: {world}")

every_second = text[::2]
print(f"Every second char: {every_second}")
print()

print("=" * 50)
print("Exercise 5 Solution: Boolean Logic")
print("=" * 50)

age = 18
has_license = True
has_car = False

can_drive = age >= 18 and has_license
print(f"Can drive: {can_drive}")

can_drive_independently = can_drive and has_car
print(f"Can drive independently: {can_drive_independently}")
print()

print("=" * 50)
print("Exercise 6 Solution: Working with Lists")
print("=" * 50)

favorite_foods = ["Pizza", "Sushi", "Tacos", "Pasta", "Ice Cream"]
print(f"Original list: {favorite_foods}")

favorite_foods.append("Burger")
print(f"After adding: {favorite_foods}")

favorite_foods.remove(favorite_foods[1])
print(f"After removing 2nd item: {favorite_foods}")

print(f"First food: {favorite_foods[0]}")
print(f"Last food: {favorite_foods[-1]}")
print(f"Length: {len(favorite_foods)}")
print()

print("=" * 50)
print("Exercise 7 Solution: List Operations")
print("=" * 50)

numbers = [10, 20, 30, 40, 50]
print(f"Numbers: {numbers}")

total = sum(numbers)
print(f"Sum: {total}")

average = total / len(numbers)
print(f"Average: {average}")

print(f"Maximum: {max(numbers)}")
print(f"Minimum: {min(numbers)}")
print()

print("=" * 50)
print("Exercise 8 Solution: Tuples and Unpacking")
print("=" * 50)

person_info = ("Alice", 30, "New York")
print(f"Tuple: {person_info}")

name, age, city = person_info
print(f"My name is {name}, I am {age} years old, and I live in {city}")
print()

print("=" * 50)
print("Exercise 9 Solution: Dictionary Operations")
print("=" * 50)

student = {
    "name": "John Doe",
    "age": 20,
    "grade": "A",
    "subjects": ["Math", "Physics", "Computer Science"]
}
print(f"Original student: {student}")

student["gpa"] = 3.8
print(f"After adding GPA: {student}")

student["grade"] = "A+"
print(f"After updating grade: {student}")

print(f"\nKeys: {list(student.keys())}")
print(f"Values: {list(student.values())}")
print()

print("=" * 50)
print("Exercise 10 Solution: Sets and Uniqueness")
print("=" * 50)

numbers_with_duplicates = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4]
print(f"Original list: {numbers_with_duplicates}")

unique_numbers = set(numbers_with_duplicates)
print(f"As set (unique): {unique_numbers}")

sorted_unique = sorted(list(unique_numbers))
print(f"Sorted list: {sorted_unique}")
print()

print("=" * 50)
print("Exercise 11 Solution: Type Conversion")
print("=" * 50)

num_str = '100'
print(f"Original string: '{num_str}'")

num_int = int(num_str) + 50
print(f"After converting to int and adding 50: {num_int}")

num_float = float(num_int)
print(f"As float: {num_float}")

final_string = str(num_float) + ' dollars'
print(f"Final string: '{final_string}'")
print()

print("=" * 50)
print("Exercise 12 Solution: Mixed Data Types")
print("=" * 50)

book = {
    "title": "Python Programming",
    "author": "John Smith",
    "year": 2024,
    "price": 29.99,
    "in_stock": True,
    "genres": ["Technology", "Education", "Programming"]
}

print("Book information:")
for key, value in book.items():
    print(f"  {key}: {value} (Type: {type(value).__name__})")
print()

print("=" * 50)
print("Exercise 13 Solution: None and Default Values")
print("=" * 50)

result = None
print(f"Initial result: {result}")

if result is None:
    result = "No data available"
    print("Result was None, setting default value")

print(f"Final result: {result}")
print()

print("=" * 50)
print("Exercise 14 Solution: Nested Data Structures")
print("=" * 50)

people = [
    {
        "name": "Alice",
        "age": 30,
        "hobbies": ["Reading", "Hiking", "Photography"]
    },
    {
        "name": "Bob",
        "age": 25,
        "hobbies": ["Gaming", "Cooking", "Music"]
    },
    {
        "name": "Charlie",
        "age": 35,
        "hobbies": ["Swimming", "Painting", "Travel"]
    }
]

print(f"Second person's name: {people[1]['name']}")
print(f"Third person's hobbies: {people[2]['hobbies']}")
print()

print("=" * 50)
print("Exercise 15 Solution: Practical Application")
print("=" * 50)

inventory = {
    "Laptop": {
        "name": "Laptop",
        "price": 999.99,
        "quantity": 5,
        "available": True
    },
    "Mouse": {
        "name": "Mouse",
        "price": 25.50,
        "quantity": 20,
        "available": True
    },
    "Keyboard": {
        "name": "Keyboard",
        "price": 75.00,
        "quantity": 0,
        "available": False
    }
}

print("Inventory:")
total_value = 0.0

for product_id, product in inventory.items():
    item_value = product["price"] * product["quantity"]
    total_value += item_value
    
    print(f"\n{product['name']}:")
    print(f"  Price: ${product['price']:.2f}")
    print(f"  Quantity: {product['quantity']}")
    print(f"  Available: {product['available']}")
    print(f"  Item Value: ${item_value:.2f}")

print(f"\nTotal Inventory Value: ${total_value:.2f}")
print()

print("=" * 50)
print("All solutions completed!")
print("=" * 50)
print()
print("Key Takeaways:")
print("- Python has multiple built-in data types")
print("- int and float for numbers")
print("- str for text")
print("- bool for True/False values")
print("- list, tuple, dict, and set for collections")
print("- Choose the right data type for your needs")
print("- Use type conversion when needed")
print("- Nested structures allow complex data representation")
