# Python Data Types - Learning Module

## 📚 Contents

This module contains everything you need to learn about Python data types:

1. **01_tutorial.md** - Comprehensive guide to all Python data types
2. **02_examples.py** - 12 practical examples demonstrating each type
3. **03_exercises.py** - 15 hands-on exercises
4. **04_solutions.py** - Solutions to all exercises

## 🎯 Learning Objectives

After completing this module, you will be able to:

- ✅ Understand all Python built-in data types
- ✅ Work with numeric types (int, float, complex)
- ✅ Manipulate strings effectively
- ✅ Use boolean logic
- ✅ Work with collections (list, tuple, dict, set)
- ✅ Convert between different data types
- ✅ Choose the appropriate data type for your needs

## 🚀 How to Use This Module

### Step 1: Read the Tutorial
Start with `01_tutorial.md` for a complete overview of all data types.

### Step 2: Run the Examples
Execute `02_examples.py` to see data types in action:
```bash
python 02_examples.py
```

### Step 3: Practice with Exercises
Open `03_exercises.py` and solve all 15 exercises.

### Step 4: Check Your Solutions
Compare your answers with `04_solutions.py`.

## 💡 Key Data Types Covered

### Basic Types
- **int** - Whole numbers
- **float** - Decimal numbers
- **str** - Text/strings
- **bool** - True/False values

### Collections
- **list** - Ordered, mutable collections
- **tuple** - Ordered, immutable collections
- **dict** - Key-value pairs
- **set** - Unordered unique items

### Special
- **None** - Absence of value

## ⏱️ Estimated Time

- Tutorial reading: 30-40 minutes
- Examples: 15 minutes
- Exercises: 60-90 minutes
- **Total: ~2-2.5 hours**

## 📝 Tips for Success

1. Don't rush through the tutorial - data types are fundamental
2. Run and modify the example code
3. Try exercises without looking at solutions first
4. Experiment with type conversions
5. Use the Python `type()` function to check types
6. Practice with `isinstance()` for type checking

## 🎓 Quick Reference

| Type | Example | Mutable? |
|------|---------|----------|
| int | `42` | No |
| float | `3.14` | No |
| str | `"hello"` | No |
| bool | `True` | No |
| list | `[1, 2, 3]` | Yes |
| tuple | `(1, 2, 3)` | No |
| dict | `{"key": "value"}` | Yes |
| set | `{1, 2, 3}` | Yes |

## 🔗 What's Next?

After mastering data types, move on to **Operators** to learn how to manipulate and compare these different types of data!

---
Happy Coding! 🐍
