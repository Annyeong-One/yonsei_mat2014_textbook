# Python Operators - Complete Tutorial

## What are Operators?

Operators are special symbols that perform operations on variables and values. They allow you to manipulate data, perform calculations, make comparisons, and create logical expressions.

## Types of Operators in Python

1. Arithmetic Operators
2. Assignment Operators
3. Comparison (Relational) Operators
4. Logical Operators
5. Bitwise Operators
6. Membership Operators
7. Identity Operators

---

## 1. Arithmetic Operators

Perform mathematical operations.

| Operator | Name | Example | Result |
|----------|------|---------|--------|
| `+` | Addition | `5 + 3` | `8` |
| `-` | Subtraction | `5 - 3` | `2` |
| `*` | Multiplication | `5 * 3` | `15` |
| `/` | Division | `7 / 2` | `3.5` |
| `//` | Floor Division | `7 // 2` | `3` |
| `%` | Modulus | `7 % 2` | `1` |
| `**` | Exponentiation | `5 ** 2` | `25` |

### Examples

```python
# Basic arithmetic
x = 10
y = 3

print(x + y)   # 13 (Addition)
print(x - y)   # 7 (Subtraction)
print(x * y)   # 30 (Multiplication)
print(x / y)   # 3.333... (Division - always returns float)
print(x // y)  # 3 (Floor division - rounds down)
print(x % y)   # 1 (Remainder)
print(x ** y)  # 1000 (10 to the power of 3)
```

### Important Notes

```python
# Division always returns float
print(10 / 2)    # 5.0 (not 5)

# Floor division rounds down to nearest integer
print(7 // 2)    # 3
print(-7 // 2)   # -4 (rounds toward negative infinity)

# Modulus gives remainder
print(10 % 3)    # 1
print(17 % 5)    # 2

# Exponentiation for powers and roots
print(2 ** 3)    # 8 (2 cubed)
print(9 ** 0.5)  # 3.0 (square root)
```

---

## 2. Assignment Operators

Assign values to variables.

| Operator | Example | Equivalent To |
|----------|---------|---------------|
| `=` | `x = 5` | `x = 5` |
| `+=` | `x += 3` | `x = x + 3` |
| `-=` | `x -= 3` | `x = x - 3` |
| `*=` | `x *= 3` | `x = x * 3` |
| `/=` | `x /= 3` | `x = x / 3` |
| `//=` | `x //= 3` | `x = x // 3` |
| `%=` | `x %= 3` | `x = x % 3` |
| `**=` | `x **= 3` | `x = x ** 3` |

### Examples

```python
# Simple assignment
x = 10

# Compound assignment operators
x += 5    # x = x + 5 → x = 15
x -= 3    # x = x - 3 → x = 12
x *= 2    # x = x * 2 → x = 24
x /= 4    # x = x / 4 → x = 6.0
x //= 2   # x = x // 2 → x = 3.0
x %= 2    # x = x % 2 → x = 1.0
x **= 3   # x = x ** 3 → x = 1.0

# Multiple assignment
a = b = c = 10

# Multiple values
x, y, z = 1, 2, 3
```

---

## 3. Comparison (Relational) Operators

Compare two values and return a boolean (`True` or `False`).

| Operator | Name | Example | Result |
|----------|------|---------|--------|
| `==` | Equal to | `5 == 5` | `True` |
| `!=` | Not equal to | `5 != 3` | `True` |
| `>` | Greater than | `5 > 3` | `True` |
| `<` | Less than | `5 < 3` | `False` |
| `>=` | Greater than or equal | `5 >= 5` | `True` |
| `<=` | Less than or equal | `5 <= 3` | `False` |

### Examples

```python
x = 10
y = 20

print(x == y)   # False
print(x != y)   # True
print(x > y)    # False
print(x < y)    # True
print(x >= 10)  # True
print(y <= 20)  # True
```

### Important Notes

```python
# == vs = (common mistake!)
x = 5      # Assignment
x == 5     # Comparison

# Comparing different types
print(5 == 5.0)      # True (values are equal)
print(5 == "5")      # False (different types)

# Chaining comparisons
x = 15
print(10 < x < 20)   # True (x is between 10 and 20)
print(10 < x < 15)   # False
```

---

## 4. Logical Operators

Combine conditional statements.

| Operator | Description | Example |
|----------|-------------|---------|
| `and` | Returns True if both are true | `x > 5 and x < 10` |
| `or` | Returns True if at least one is true | `x > 5 or x < 3` |
| `not` | Reverses the boolean value | `not(x > 5)` |

### Truth Tables

#### AND Operator
| A | B | A and B |
|---|---|---------|
| True | True | True |
| True | False | False |
| False | True | False |
| False | False | False |

#### OR Operator
| A | B | A or B |
|---|---|--------|
| True | True | True |
| True | False | True |
| False | True | True |
| False | False | False |

#### NOT Operator
| A | not A |
|---|-------|
| True | False |
| False | True |

### Examples

```python
x = 15

# AND - both conditions must be True
print(x > 10 and x < 20)    # True
print(x > 10 and x > 20)    # False

# OR - at least one condition must be True
print(x > 10 or x > 20)     # True
print(x < 10 or x > 20)     # False

# NOT - reverses the boolean
print(not(x > 10))          # False
print(not(x < 10))          # True

# Combining multiple conditions
age = 25
has_license = True
has_car = True

can_drive = age >= 18 and has_license
can_drive_independently = can_drive and has_car

print(can_drive)            # True
print(can_drive_independently)  # True
```

### Short-Circuit Evaluation

```python
# AND stops at first False
print(False and print("This won't execute"))  # False

# OR stops at first True
print(True or print("This won't execute"))    # True
```

---

## 5. Bitwise Operators

Perform operations on binary representations of integers.

| Operator | Name | Description |
|----------|------|-------------|
| `&` | AND | Sets each bit to 1 if both bits are 1 |
| `|` | OR | Sets each bit to 1 if one of the bits is 1 |
| `^` | XOR | Sets each bit to 1 if only one bit is 1 |
| `~` | NOT | Inverts all bits |
| `<<` | Left shift | Shifts left by pushing zeros in from right |
| `>>` | Right shift | Shifts right by pushing copies of leftmost bit |

### Examples

```python
a = 5   # Binary: 0101
b = 3   # Binary: 0011

print(a & b)   # 1 (Binary: 0001)
print(a | b)   # 7 (Binary: 0111)
print(a ^ b)   # 6 (Binary: 0110)
print(~a)      # -6 (Inverts bits)
print(a << 1)  # 10 (Binary: 1010)
print(a >> 1)  # 2 (Binary: 0010)
```

---

## 6. Membership Operators

Test if a value is present in a sequence (string, list, tuple, set, dict).

| Operator | Description | Example |
|----------|-------------|---------|
| `in` | Returns True if value exists in sequence | `'a' in 'apple'` |
| `not in` | Returns True if value doesn't exist | `'b' not in 'apple'` |

### Examples

```python
# String membership
text = "Hello World"
print('H' in text)         # True
print('h' in text)         # False (case-sensitive)
print('World' in text)     # True
print('Python' not in text)  # True

# List membership
fruits = ['apple', 'banana', 'orange']
print('apple' in fruits)      # True
print('grape' not in fruits)  # True

# Dictionary membership (checks keys)
person = {'name': 'Alice', 'age': 30}
print('name' in person)       # True
print('Alice' in person)      # False (checks keys, not values)
print('Alice' in person.values())  # True

# Set membership
numbers = {1, 2, 3, 4, 5}
print(3 in numbers)           # True
print(10 not in numbers)      # True
```

---

## 7. Identity Operators

Compare the memory locations of two objects.

| Operator | Description | Example |
|----------|-------------|---------|
| `is` | Returns True if both variables are the same object | `x is y` |
| `is not` | Returns True if both variables are not the same object | `x is not y` |

### Examples

```python
# Identity vs Equality
x = [1, 2, 3]
y = [1, 2, 3]
z = x

print(x == y)      # True (same values)
print(x is y)      # False (different objects in memory)
print(x is z)      # True (same object)
print(x is not y)  # True

# None comparison (always use 'is')
value = None
print(value is None)      # True (correct way)
print(value == None)      # True (but 'is' is preferred)

# Small integer caching
a = 10
b = 10
print(a is b)      # True (Python caches small integers)

# Larger numbers
a = 1000
b = 1000
print(a == b)      # True
print(a is b)      # May be False (depends on implementation)
```

---

## Operator Precedence

Order in which operators are evaluated (highest to lowest):

1. `()` - Parentheses
2. `**` - Exponentiation
3. `+x`, `-x`, `~x` - Unary plus, minus, bitwise NOT
4. `*`, `/`, `//`, `%` - Multiplication, division, floor division, modulus
5. `+`, `-` - Addition, subtraction
6. `<<`, `>>` - Bitwise shifts
7. `&` - Bitwise AND
8. `^` - Bitwise XOR
9. `|` - Bitwise OR
10. `==`, `!=`, `>`, `>=`, `<`, `<=`, `is`, `is not`, `in`, `not in` - Comparisons
11. `not` - Logical NOT
12. `and` - Logical AND
13. `or` - Logical OR

### Examples

```python
# Without parentheses
result = 2 + 3 * 4
print(result)      # 14 (not 20, because * has higher precedence)

# With parentheses
result = (2 + 3) * 4
print(result)      # 20

# Complex expression
result = 10 + 5 * 2 ** 3
print(result)      # 50 (2**3=8, then 5*8=40, then 10+40=50)

# With parentheses for clarity
result = 10 + (5 * (2 ** 3))
print(result)      # 50 (same result, but clearer)
```

---

## Best Practices

1. **Use parentheses for clarity**: Even if not required, they make code more readable
```python
# Less clear
if x > 5 and y < 10 or z == 0:
    pass

# More clear
if (x > 5 and y < 10) or (z == 0):
    pass
```

2. **Use compound operators**: They're more concise and slightly faster
```python
# Instead of
x = x + 5

# Use
x += 5
```

3. **Use `is` for None**: Not `==`
```python
# Correct
if value is None:
    pass

# Not recommended
if value == None:
    pass
```

4. **Avoid complex expressions**: Break them down for readability
```python
# Hard to read
if not (x > 10 and y < 20) or z == 0 and w != 5:
    pass

# Better
is_outside_range = not (x > 10 and y < 20)
is_special_case = z == 0 and w != 5

if is_outside_range or is_special_case:
    pass
```

---

## Common Mistakes

```python
# ❌ Using = instead of ==
if x = 5:  # SyntaxError!
    pass

# ✅ Correct
if x == 5:
    pass

# ❌ Confusing / and //
print(7 / 2)   # 3.5
print(7 // 2)  # 3

# ❌ Using == with None
if x == None:  # Works but not Pythonic
    pass

# ✅ Correct
if x is None:
    pass

# ❌ Forgetting operator precedence
result = 2 + 3 * 4  # 14, not 20

# ✅ Use parentheses
result = (2 + 3) * 4  # 20
```

---

## Practical Examples

### Example 1: Calculate discount
```python
price = 100
discount_percent = 20

discount_amount = price * (discount_percent / 100)
final_price = price - discount_amount

print(f"Original: ${price}")
print(f"Discount: {discount_percent}%")
print(f"You save: ${discount_amount}")
print(f"Final price: ${final_price}")
```

### Example 2: Check eligibility
```python
age = 25
income = 50000
has_debt = False

is_eligible = age >= 18 and income >= 30000 and not has_debt

print(f"Eligible for loan: {is_eligible}")
```

### Example 3: Swap without temp variable
```python
a = 10
b = 20

# Using arithmetic operators
a = a + b  # a = 30
b = a - b  # b = 10
a = a - b  # a = 20

# Pythonic way (uses tuple packing/unpacking)
a, b = b, a
```

---

## Summary Table

| Category | Operators | Purpose |
|----------|-----------|---------|
| Arithmetic | `+`, `-`, `*`, `/`, `//`, `%`, `**` | Math operations |
| Assignment | `=`, `+=`, `-=`, `*=`, etc. | Assign values |
| Comparison | `==`, `!=`, `>`, `<`, `>=`, `<=` | Compare values |
| Logical | `and`, `or`, `not` | Boolean logic |
| Bitwise | `&`, `|`, `^`, `~`, `<<`, `>>` | Binary operations |
| Membership | `in`, `not in` | Check membership |
| Identity | `is`, `is not` | Check identity |

---

## Next Steps

Now that you understand operators, you can combine them with variables and data types to write more complex and powerful programs!
