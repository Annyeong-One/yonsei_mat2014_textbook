"""
Python Operators - Practice Exercises
Try to solve these without looking at the solutions first!
"""

print("Exercise 1: Basic Arithmetic")
print("-" * 40)
print("Task:")
print("- Calculate the area of a rectangle: length = 12, width = 8")
print("- Calculate the perimeter")
print("- Print both results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 2: Division and Modulus")
print("-" * 40)
print("Task:")
print("- You have 17 cookies and 5 friends")
print("- Calculate how many cookies each friend gets (use //)")
print("- Calculate how many cookies are left over (use %)")
print("- Print both results with descriptive messages")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 3: Compound Assignment")
print("-" * 40)
print("Task:")
print("- Start with balance = 1000")
print("- Add 500 using +=")
print("- Subtract 200 using -=")
print("- Multiply by 1.05 (5% interest) using *=")
print("- Print the final balance")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 4: Comparison Operators")
print("-" * 40)
print("Task:")
print("- Create two variables: score1 = 85, score2 = 92")
print("- Check if score1 is greater than score2")
print("- Check if score1 is less than or equal to 85")
print("- Check if score2 is not equal to 100")
print("- Print all results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 5: Chained Comparisons")
print("-" * 40)
print("Task:")
print("- Create variable: age = 25")
print("- Check if age is between 18 and 30 (inclusive)")
print("- Check if age is between 30 and 40")
print("- Print both results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 6: Logical AND")
print("-" * 40)
print("Task:")
print("- temperature = 75, is_sunny = True, is_weekend = True")
print("- Check if it's a good day for picnic:")
print("  (temperature between 70-80 AND is_sunny AND is_weekend)")
print("- Print the result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 7: Logical OR")
print("-" * 40)
print("Task:")
print("- is_raining = False, is_snowing = False, is_stormy = True")
print("- Check if you should stay inside:")
print("  (is_raining OR is_snowing OR is_stormy)")
print("- Print the result")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 8: NOT Operator")
print("-" * 40)
print("Task:")
print("- is_logged_in = False")
print("- Create a variable 'needs_to_login' that is True if NOT logged in")
print("- Print the result with a message")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 9: Membership in String")
print("-" * 40)
print("Task:")
print("- email = 'user@example.com'")
print("- Check if '@' is in the email")
print("- Check if '.com' is in the email")
print("- Check if 'gmail' is NOT in the email")
print("- Print all results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 10: Membership in List")
print("-" * 40)
print("Task:")
print("- shopping_cart = ['apple', 'banana', 'milk', 'bread']")
print("- Check if 'milk' is in the cart")
print("- Check if 'eggs' is NOT in the cart")
print("- Print appropriate messages")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 11: Identity Operators")
print("-" * 40)
print("Task:")
print("- Create list1 = [1, 2, 3]")
print("- Create list2 = [1, 2, 3]")
print("- Create list3 = list1")
print("- Check if list1 == list2 (values equal)")
print("- Check if list1 is list2 (same object)")
print("- Check if list1 is list3 (same object)")
print("- Print all results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 12: Calculate BMI")
print("-" * 40)
print("Task:")
print("- weight_kg = 70, height_m = 1.75")
print("- Calculate BMI = weight / (height ** 2)")
print("- Check if BMI is between 18.5 and 24.9 (healthy range)")
print("- Print BMI and whether it's in healthy range")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 13: Discount Calculator")
print("-" * 40)
print("Task:")
print("- price = 150, is_member = True, quantity = 3")
print("- If member, apply 10% discount")
print("- If quantity >= 3, apply additional 5% discount")
print("- Calculate final price")
print("- Print original price, discounts applied, and final price")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 14: Voting Eligibility")
print("-" * 40)
print("Task:")
print("- age = 17, is_citizen = True, is_registered = False")
print("- Can vote if: age >= 18 AND is_citizen AND is_registered")
print("- Print each condition separately")
print("- Print final eligibility")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")

print("Exercise 15: Password Validator")
print("-" * 40)
print("Task:")
print("- password = 'Secure123'")
print("- Check if password length >= 8")
print("- Check if it contains a number (hint: any(c.isdigit() for c in password))")
print("- Check if it contains uppercase (hint: any(c.isupper() for c in password))")
print("- Password is valid if ALL conditions are True")
print("- Print validation results")
print()
# Write your code below:





print("\n" + "=" * 50 + "\n")
print("Exercises completed! Check solutions.py for answers.")
