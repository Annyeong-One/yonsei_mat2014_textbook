"""
Python Operators - Exercise Solutions
Compare your solutions with these!
"""

print("=" * 50)
print("Exercise 1 Solution: Basic Arithmetic")
print("=" * 50)

length = 12
width = 8

area = length * width
perimeter = 2 * (length + width)

print(f"Rectangle: {length} x {width}")
print(f"Area: {area} square units")
print(f"Perimeter: {perimeter} units")
print()

print("=" * 50)
print("Exercise 2 Solution: Division and Modulus")
print("=" * 50)

cookies = 17
friends = 5

cookies_per_friend = cookies // friends
leftover_cookies = cookies % friends

print(f"Total cookies: {cookies}")
print(f"Number of friends: {friends}")
print(f"Each friend gets: {cookies_per_friend} cookies")
print(f"Leftover cookies: {leftover_cookies}")
print()

print("=" * 50)
print("Exercise 3 Solution: Compound Assignment")
print("=" * 50)

balance = 1000
print(f"Starting balance: ${balance}")

balance += 500
print(f"After deposit: ${balance}")

balance -= 200
print(f"After withdrawal: ${balance}")

balance *= 1.05
print(f"After 5% interest: ${balance:.2f}")
print()

print("=" * 50)
print("Exercise 4 Solution: Comparison Operators")
print("=" * 50)

score1 = 85
score2 = 92

print(f"Score 1: {score1}")
print(f"Score 2: {score2}")
print()

print(f"score1 > score2: {score1 > score2}")
print(f"score1 <= 85: {score1 <= 85}")
print(f"score2 != 100: {score2 != 100}")
print()

print("=" * 50)
print("Exercise 5 Solution: Chained Comparisons")
print("=" * 50)

age = 25
print(f"Age: {age}")
print()

is_young_adult = 18 <= age <= 30
print(f"Is between 18 and 30: {is_young_adult}")

is_middle_aged = 30 < age < 40
print(f"Is between 30 and 40: {is_middle_aged}")
print()

print("=" * 50)
print("Exercise 6 Solution: Logical AND")
print("=" * 50)

temperature = 75
is_sunny = True
is_weekend = True

good_for_picnic = (70 <= temperature <= 80) and is_sunny and is_weekend

print(f"Temperature: {temperature}°F")
print(f"Is sunny: {is_sunny}")
print(f"Is weekend: {is_weekend}")
print(f"Good day for picnic: {good_for_picnic}")
print()

print("=" * 50)
print("Exercise 7 Solution: Logical OR")
print("=" * 50)

is_raining = False
is_snowing = False
is_stormy = True

should_stay_inside = is_raining or is_snowing or is_stormy

print(f"Is raining: {is_raining}")
print(f"Is snowing: {is_snowing}")
print(f"Is stormy: {is_stormy}")
print(f"Should stay inside: {should_stay_inside}")
print()

print("=" * 50)
print("Exercise 8 Solution: NOT Operator")
print("=" * 50)

is_logged_in = False
needs_to_login = not is_logged_in

print(f"Is logged in: {is_logged_in}")
print(f"Needs to login: {needs_to_login}")

if needs_to_login:
    print("Please log in to continue")
print()

print("=" * 50)
print("Exercise 9 Solution: Membership in String")
print("=" * 50)

email = 'user@example.com'
print(f"Email: {email}")
print()

has_at = '@' in email
has_dotcom = '.com' in email
not_gmail = 'gmail' not in email

print(f"Contains '@': {has_at}")
print(f"Contains '.com': {has_dotcom}")
print(f"Is NOT Gmail: {not_gmail}")
print()

print("=" * 50)
print("Exercise 10 Solution: Membership in List")
print("=" * 50)

shopping_cart = ['apple', 'banana', 'milk', 'bread']
print(f"Shopping cart: {shopping_cart}")
print()

has_milk = 'milk' in shopping_cart
needs_eggs = 'eggs' not in shopping_cart

print(f"Has milk: {has_milk}")
if has_milk:
    print("✓ Milk is in the cart")

print(f"Needs eggs: {needs_eggs}")
if needs_eggs:
    print("✗ Don't forget to add eggs!")
print()

print("=" * 50)
print("Exercise 11 Solution: Identity Operators")
print("=" * 50)

list1 = [1, 2, 3]
list2 = [1, 2, 3]
list3 = list1

print(f"list1: {list1}")
print(f"list2: {list2}")
print(f"list3: {list3} (reference to list1)")
print()

print(f"list1 == list2: {list1 == list2} (same values)")
print(f"list1 is list2: {list1 is list2} (different objects)")
print(f"list1 is list3: {list1 is list3} (same object)")
print()

print("=" * 50)
print("Exercise 12 Solution: Calculate BMI")
print("=" * 50)

weight_kg = 70
height_m = 1.75

bmi = weight_kg / (height_m ** 2)
is_healthy = 18.5 <= bmi <= 24.9

print(f"Weight: {weight_kg} kg")
print(f"Height: {height_m} m")
print(f"BMI: {bmi:.2f}")
print(f"Is in healthy range (18.5-24.9): {is_healthy}")

if is_healthy:
    print("✓ BMI is in the healthy range")
else:
    print("⚠ BMI is outside the healthy range")
print()

print("=" * 50)
print("Exercise 13 Solution: Discount Calculator")
print("=" * 50)

price = 150
is_member = True
quantity = 3

print(f"Original price: ${price}")
print(f"Is member: {is_member}")
print(f"Quantity: {quantity}")
print()

# Calculate discounts
final_price = price

if is_member:
    discount_percent = 10
    final_price *= (1 - discount_percent / 100)
    print(f"Member discount (10%): -${price * 0.10:.2f}")

if quantity >= 3:
    # Apply additional discount to already discounted price
    additional_discount = 5
    discount_amount = final_price * (additional_discount / 100)
    final_price *= (1 - additional_discount / 100)
    print(f"Bulk discount (5%): -${discount_amount:.2f}")

print(f"Final price: ${final_price:.2f}")
print()

print("=" * 50)
print("Exercise 14 Solution: Voting Eligibility")
print("=" * 50)

age = 17
is_citizen = True
is_registered = False

print(f"Age: {age}")
print(f"Is citizen: {is_citizen}")
print(f"Is registered: {is_registered}")
print()

age_eligible = age >= 18
print(f"Age requirement (>= 18): {age_eligible}")
print(f"Citizenship requirement: {is_citizen}")
print(f"Registration requirement: {is_registered}")
print()

can_vote = age_eligible and is_citizen and is_registered
print(f"Can vote: {can_vote}")

if not can_vote:
    print("\nReasons cannot vote:")
    if not age_eligible:
        print("  - Must be at least 18 years old")
    if not is_citizen:
        print("  - Must be a citizen")
    if not is_registered:
        print("  - Must be registered to vote")
print()

print("=" * 50)
print("Exercise 15 Solution: Password Validator")
print("=" * 50)

password = 'Secure123'
print(f"Password: {password}")
print()

# Check conditions
has_min_length = len(password) >= 8
has_number = any(c.isdigit() for c in password)
has_uppercase = any(c.isupper() for c in password)

print("Password requirements:")
print(f"  Length >= 8: {has_min_length} (Current: {len(password)})")
print(f"  Contains number: {has_number}")
print(f"  Contains uppercase: {has_uppercase}")
print()

is_valid = has_min_length and has_number and has_uppercase
print(f"Password is valid: {is_valid}")

if is_valid:
    print("✓ Password meets all requirements")
else:
    print("✗ Password does not meet all requirements")
print()

print("=" * 50)
print("All solutions completed!")
print("=" * 50)
print()
print("Key Takeaways:")
print("- Arithmetic operators: +, -, *, /, //, %, **")
print("- Assignment operators: =, +=, -=, *=, etc.")
print("- Comparison operators: ==, !=, >, <, >=, <=")
print("- Logical operators: and, or, not")
print("- Membership operators: in, not in")
print("- Identity operators: is, is not")
print("- Use parentheses for clarity")
print("- Understand operator precedence")
