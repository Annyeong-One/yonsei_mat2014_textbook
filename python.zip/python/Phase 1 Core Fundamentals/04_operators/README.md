# Python Operators - Learning Module

## 📚 Contents

This module contains everything you need to learn about Python operators:

1. **01_tutorial.md** - Comprehensive guide to all Python operators
2. **02_examples.py** - 15 practical examples
3. **03_exercises.py** - 15 hands-on exercises
4. **04_solutions.py** - Solutions to all exercises

## 🎯 Learning Objectives

After completing this module, you will be able to:

- ✅ Use arithmetic operators for calculations
- ✅ Apply assignment operators efficiently
- ✅ Make comparisons with relational operators
- ✅ Combine conditions with logical operators
- ✅ Test membership with in/not in
- ✅ Check object identity with is/is not
- ✅ Understand and apply operator precedence
- ✅ Write complex conditional expressions

## 🚀 How to Use This Module

### Step 1: Read the Tutorial
Start with `01_tutorial.md` for a complete overview of all operators.

### Step 2: Run the Examples
Execute `02_examples.py` to see operators in action:
```bash
python 02_examples.py
```

### Step 3: Practice with Exercises
Open `03_exercises.py` and solve all 15 exercises.

### Step 4: Check Your Solutions
Compare your answers with `04_solutions.py`.

## 💡 Operator Categories Covered

### 1. Arithmetic Operators
- Addition, subtraction, multiplication
- Division (regular and floor)
- Modulus, exponentiation

### 2. Assignment Operators
- Simple assignment (=)
- Compound assignment (+=, -=, *=, etc.)

### 3. Comparison Operators
- Equal to, not equal to
- Greater than, less than
- Greater/less than or equal to

### 4. Logical Operators
- AND, OR, NOT
- Truth tables and short-circuit evaluation

### 5. Membership Operators
- in, not in
- Testing membership in sequences

### 6. Identity Operators
- is, is not
- Comparing object identity

### 7. Bitwise Operators
- AND, OR, XOR, NOT
- Bit shifts

## ⏱️ Estimated Time

- Tutorial reading: 40-50 minutes
- Examples: 20 minutes
- Exercises: 60-90 minutes
- **Total: ~2-2.5 hours**

## 📝 Tips for Success

1. Master operator precedence - use parentheses when in doubt
2. Remember: `=` is assignment, `==` is comparison
3. Use `is` for None comparisons, not `==`
4. Practice with truth tables for logical operators
5. Understand the difference between `/` and `//`
6. Use compound operators for cleaner code
7. Test your understanding with various data types

## 🎓 Quick Reference

### Arithmetic
```python
+  -  *  /  //  %  **
```

### Comparison
```python
==  !=  >  <  >=  <=
```

### Logical
```python
and  or  not
```

### Membership
```python
in  not in
```

### Identity
```python
is  is not
```

## ⚠️ Common Pitfalls

- Confusing `=` with `==`
- Forgetting operator precedence
- Using `==` instead of `is` for None
- Mixing up `/` (float division) and `//` (floor division)
- Not understanding short-circuit evaluation

## 🔗 What's Next?

You've now mastered the fundamentals! Next topics could include:
- Control Flow (if/else, loops)
- Functions
- Data Structures
- Exception Handling

---
Happy Coding! 🐍
