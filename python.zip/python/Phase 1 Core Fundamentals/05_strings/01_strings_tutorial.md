# Python Strings - Complete Tutorial

## Table of Contents
1. [Introduction to Strings](#introduction-to-strings)
2. [Creating Strings](#creating-strings)
3. [String Indexing](#string-indexing)
4. [String Slicing](#string-slicing)
5. [String Operations](#string-operations)
6. [String Methods](#string-methods)
7. [String Formatting](#string-formatting)
8. [Escape Sequences](#escape-sequences)
9. [String Immutability](#string-immutability)
10. [Best Practices](#best-practices)

---

## Introduction to Strings

**What is a String?**

A string is a sequence of characters enclosed in quotes. Strings are one of the most fundamental data types in Python.

```python
name = "Alice"
message = 'Hello, World!'
```

**Key Characteristics:**
- Strings are **immutable** (cannot be changed after creation)
- Strings are **sequences** (ordered collection of characters)
- Strings are **iterable** (can loop through characters)

---

## Creating Strings

### Method 1: Single Quotes

```python
text = 'Hello'
message = 'Python is awesome'
```

**Best for:** Short strings, strings containing double quotes

```python
quote = 'She said "Hello"'
```

### Method 2: Double Quotes

```python
text = "Hello"
message = "Python is awesome"
```

**Best for:** Sentences, strings containing single quotes (contractions)

```python
sentence = "It's a beautiful day"
```

### Method 3: Triple Quotes (Multiline)

```python
# Triple single quotes
text = '''This is
a multiline
string'''

# Triple double quotes
text = """This is also
a multiline
string"""
```

**Best for:** 
- Docstrings
- Multiline text
- Text with both single and double quotes

```python
paragraph = """
She said, "It's a wonderful day!"
The sun is shining.
"""
```

### Empty String

```python
empty = ""
also_empty = ''
```

### String Constructor

```python
# Convert other types to strings
num_str = str(42)        # "42"
float_str = str(3.14)    # "3.14"
bool_str = str(True)     # "True"
list_str = str([1,2,3])  # "[1, 2, 3]"
```

---

## String Indexing

Strings are **indexed** - each character has a position.

### Positive Indexing (from left)

```python
text = "Python"
#       012345  (indices)

text[0]  # 'P' - first character
text[1]  # 'y'
text[5]  # 'n' - last character
```

### Negative Indexing (from right)

```python
text = "Python"
#       -6-5-4-3-2-1  (negative indices)

text[-1]  # 'n' - last character
text[-2]  # 'o'
text[-6]  # 'P' - first character
```

### Visual Representation

```
String: "Python"

Positive:  0   1   2   3   4   5
         ┌───┬───┬───┬───┬───┬───┐
         │ P │ y │ t │ h │ o │ n │
         └───┴───┴───┴───┴───┴───┘
Negative: -6  -5  -4  -3  -2  -1
```

### Index Rules

- First character: index `0` or `-len(string)`
- Last character: index `len(string)-1` or `-1`
- Index out of range → `IndexError`

```python
text = "Hi"
text[0]   # 'H' ✓
text[5]   # IndexError ✗
```

---

## String Slicing

Slicing extracts a **substring** from a string.

### Basic Syntax

```python
string[start:stop:step]
```

- **start**: Starting index (inclusive)
- **stop**: Ending index (exclusive)
- **step**: Step size (default: 1)

### Examples

```python
text = "Python Programming"
#       0123456789...

# Basic slicing
text[0:6]    # "Python" (indices 0-5)
text[7:18]   # "Programming"

# Omitting start (defaults to 0)
text[:6]     # "Python"

# Omitting stop (goes to end)
text[7:]     # "Programming"

# Omitting both (copies entire string)
text[:]      # "Python Programming"

# Negative indices
text[-11:]   # "Programming" (last 11 characters)
text[:-12]   # "Python" (all except last 12)

# With step
text[::2]    # "Pto rgamn" (every 2nd character)
text[::3]    # "Ph ormn" (every 3rd character)

# Reverse string
text[::-1]   # "gnimmargorP nohtyP"
```

### Visual Guide

```
text = "Hello"
        01234

text[1:4]    → "ell"
       ↑ ↑
       │ └─ stop (not included)
       └─── start (included)

text[:3]     → "Hel" (start defaults to 0)
text[2:]     → "llo" (stop defaults to end)
text[:]      → "Hello" (full copy)
```

### Common Patterns

```python
text = "Hello, World!"

# First 5 characters
text[:5]          # "Hello"

# Last 6 characters
text[-6:]         # "World!"

# Remove first and last
text[1:-1]        # "ello, World"

# Every other character
text[::2]         # "Hlo ol!"

# Reverse
text[::-1]        # "!dlroW ,olleH"

# Middle section
text[7:12]        # "World"
```

---

## String Operations

### Concatenation (+)

Joining strings together:

```python
first = "Hello"
last = "World"
full = first + " " + last  # "Hello World"

# Multiple concatenations
greeting = "Hi" + " " + "there" + "!"  # "Hi there!"
```

### Repetition (*)

Repeating strings:

```python
laugh = "Ha" * 3      # "HaHaHa"
line = "-" * 40       # "----------------------------------------"
spaces = " " * 10     # "          " (10 spaces)
```

### Membership (in / not in)

Check if substring exists:

```python
text = "Python Programming"

"Python" in text      # True
"Java" in text        # False
"prog" in text        # False (case-sensitive)
"Programming" in text # True

"Java" not in text    # True
```

### Length (len)

Get string length:

```python
text = "Hello"
len(text)        # 5

empty = ""
len(empty)       # 0

multiline = """Line 1
Line 2"""
len(multiline)   # 13 (includes newline)
```

### Comparison

Strings compare **lexicographically** (alphabetically):

```python
"apple" < "banana"    # True
"apple" == "apple"    # True
"Apple" == "apple"    # False (case-sensitive)

"10" < "2"            # True (string comparison, not numeric!)
"abc" < "abd"         # True ('c' < 'd')
```

### Iteration

Loop through characters:

```python
for char in "Hello":
    print(char)
# Output:
# H
# e
# l
# l
# o
```

---

## String Methods

Python strings have 40+ built-in methods. Here are the essential ones:

### Case Conversion

```python
text = "hello world"

text.upper()        # "HELLO WORLD"
text.lower()        # "hello world"
text.capitalize()   # "Hello world" (first letter only)
text.title()        # "Hello World" (each word)
text.swapcase()     # "HELLO WORLD" → "hello world"
```

### Trimming Whitespace

```python
text = "  Hello  "

text.strip()        # "Hello" (both ends)
text.lstrip()       # "Hello  " (left side)
text.rstrip()       # "  Hello" (right side)

# Strip specific characters
"###Hello###".strip('#')   # "Hello"
```

### Splitting and Joining

```python
# Split string into list
text = "apple,banana,cherry"
text.split(',')     # ['apple', 'banana', 'cherry']

sentence = "Hello World"
sentence.split()    # ['Hello', 'World'] (splits on whitespace)

# Split with limit
"a-b-c-d".split('-', 2)  # ['a', 'b', 'c-d']

# Join list into string
words = ['Hello', 'World']
' '.join(words)     # "Hello World"
'-'.join(words)     # "Hello-World"
''.join(words)      # "HelloWorld"
```

### Searching

```python
text = "Python Programming"

# Find position
text.find('P')          # 0 (first occurrence)
text.find('o')          # 4
text.find('xyz')        # -1 (not found)

# Index (like find, but raises error if not found)
text.index('P')         # 0
text.index('xyz')       # ValueError

# Count occurrences
text.count('o')         # 1
text.count('P')         # 2
text.count('xyz')       # 0

# Check start/end
text.startswith('Py')   # True
text.startswith('Java') # False
text.endswith('ming')   # True
text.endswith('Python') # False
```

### Replacing

```python
text = "Hello World"

text.replace('World', 'Python')      # "Hello Python"
text.replace('l', 'L')                # "HeLLo WorLd"
text.replace('l', 'L', 1)             # "HeLlo World" (replace first)

# Replace multiple
text.replace('o', '0').replace('l', '1')  # "He110 W0r1d"
```

### Validation Methods

```python
# Alphabetic
"Hello".isalpha()       # True
"Hello123".isalpha()    # False

# Numeric
"12345".isdigit()       # True
"123.45".isdigit()      # False

# Alphanumeric
"Hello123".isalnum()    # True
"Hello 123".isalnum()   # False (space)

# Lowercase/Uppercase
"hello".islower()       # True
"HELLO".isupper()       # True
"Hello".islower()       # False

# Whitespace
"   ".isspace()         # True
"  a  ".isspace()       # False

# Decimal
"123".isdecimal()       # True
"12.3".isdecimal()      # False
```

### Alignment and Padding

```python
text = "Hi"

text.center(10)         # "    Hi    " (centered)
text.center(10, '*')    # "****Hi****"

text.ljust(10)          # "Hi        " (left-aligned)
text.ljust(10, '-')     # "Hi--------"

text.rjust(10)          # "        Hi" (right-aligned)
text.rjust(10, '0')     # "00000000Hi"

text.zfill(5)           # "000Hi" (zero-padding)
```

---

## String Formatting

### Method 1: f-strings (Recommended - Python 3.6+)

Most readable and efficient:

```python
name = "Alice"
age = 30

# Basic
f"My name is {name}"                    # "My name is Alice"
f"I am {age} years old"                 # "I am 30 years old"

# Expressions
f"Next year I'll be {age + 1}"          # "Next year I'll be 31"
f"Uppercase: {name.upper()}"            # "Uppercase: ALICE"

# Multiple variables
f"{name} is {age} years old"            # "Alice is 30 years old"

# Formatting numbers
price = 19.99
f"Price: ${price:.2f}"                  # "Price: $19.99"
f"Price: ${price:>10.2f}"               # "Price: $     19.99" (right-aligned)

# Thousands separator
big_num = 1000000
f"{big_num:,}"                          # "1,000,000"

# Percentage
ratio = 0.857
f"{ratio:.1%}"                          # "85.7%"

# Padding and alignment
f"{name:<10}"                           # "Alice     " (left)
f"{name:>10}"                           # "     Alice" (right)
f"{name:^10}"                           # "  Alice   " (center)
```

### Method 2: .format() Method

Flexible and powerful:

```python
name = "Bob"
age = 25

# Positional
"My name is {} and I'm {}".format(name, age)
# "My name is Bob and I'm 25"

# Indexed
"{0} is {1} years old. {0} likes Python".format(name, age)
# "Bob is 25 years old. Bob likes Python"

# Named
"{n} is {a} years old".format(n=name, a=age)
# "Bob is 25 years old"

# Formatting
"{:.2f}".format(3.14159)                # "3.14"
"{:>10}".format("Hi")                   # "        Hi"
"{:0>5}".format("42")                   # "00042"
```

### Method 3: % Operator (Legacy)

Old-style formatting (still used):

```python
name = "Charlie"
age = 35

# Basic
"My name is %s" % name                  # "My name is Charlie"
"I am %d years old" % age               # "I am 35 years old"

# Multiple values (use tuple)
"Name: %s, Age: %d" % (name, age)       # "Name: Charlie, Age: 35"

# Formatting
"Pi: %.2f" % 3.14159                    # "Pi: 3.14"
"Number: %05d" % 42                     # "Number: 00042"
```

**Format Specifiers:**
- `%s` - String
- `%d` - Integer
- `%f` - Float
- `%x` - Hexadecimal
- `%o` - Octal

### Comparison Table

| Feature | f-string | .format() | % operator |
|---------|----------|-----------|------------|
| Readability | ★★★★★ | ★★★★☆ | ★★★☆☆ |
| Performance | ★★★★★ | ★★★★☆ | ★★★☆☆ |
| Python Version | 3.6+ | 2.7+ | All |
| Expressions | Yes | Limited | No |
| **Recommended** | **Yes** | Sometimes | Legacy only |

---

## Escape Sequences

Special characters that start with backslash `\`:

```python
# Newline
print("Line 1\nLine 2")
# Output:
# Line 1
# Line 2

# Tab
print("Name:\tAlice")
# Output: Name:    Alice

# Backslash
print("C:\\Users\\Alice")
# Output: C:\Users\Alice

# Quotes
print("She said \"Hello\"")
# Output: She said "Hello"

print('It\'s sunny')
# Output: It's sunny

# Carriage return
print("Hello\rWorld")  # Overwrites

# Backspace
print("Hello\b!")      # "Hell!"
```

### Common Escape Sequences

| Sequence | Meaning |
|----------|---------|
| `\n` | Newline |
| `\t` | Tab |
| `\\` | Backslash |
| `\'` | Single quote |
| `\"` | Double quote |
| `\r` | Carriage return |
| `\b` | Backspace |
| `\f` | Form feed |
| `\v` | Vertical tab |

### Raw Strings

Use `r` prefix to treat backslashes literally:

```python
# Regular string
path = "C:\new\test"    # \n and \t are escape sequences!

# Raw string
path = r"C:\new\test"   # Backslashes are literal
print(path)             # C:\new\test

# Useful for regex
pattern = r"\d+\.\d+"   # Matches numbers like 3.14
```

**When to use raw strings:**
- File paths (Windows)
- Regular expressions
- LaTeX strings
- Any string with many backslashes

---

## String Immutability

Strings are **immutable** - cannot be changed after creation.

```python
text = "Hello"

# This does NOT modify the string
text[0] = 'h'  # TypeError: 'str' object does not support item assignment

# Instead, create a new string
text = 'h' + text[1:]  # "hello"

# Methods return NEW strings
original = "hello"
uppercase = original.upper()  # Creates new string

print(original)    # "hello" (unchanged)
print(uppercase)   # "HELLO" (new string)
```

### Why Immutability Matters

```python
# Same string in memory
a = "Python"
b = "Python"
a is b  # True (Python optimizes by reusing)

# Efficient memory usage
text = "Python"
text = text.upper()  # Creates new string, old one is garbage collected
```

### Building Strings Efficiently

```python
# ❌ Bad: Slow for large strings
result = ""
for i in range(1000):
    result += str(i)  # Creates new string each time!

# ✅ Good: Fast
parts = []
for i in range(1000):
    parts.append(str(i))
result = ''.join(parts)

# ✅ Even better: List comprehension
result = ''.join(str(i) for i in range(1000))
```

---

## Best Practices

### 1. Use f-strings for Formatting

```python
# ✅ Good
name = "Alice"
age = 30
message = f"{name} is {age} years old"

# ❌ Avoid
message = name + " is " + str(age) + " years old"
```

### 2. Choose Appropriate Quotes

```python
# ✅ Good
sentence = "It's a beautiful day"
quote = 'She said "Hello"'

# ❌ Avoid
sentence = 'It\'s a beautiful day'  # Unnecessary escaping
```

### 3. Use .join() for Multiple Strings

```python
words = ['Hello', 'World', 'Python']

# ✅ Good
result = ' '.join(words)

# ❌ Avoid (slow for many strings)
result = ''
for word in words:
    result += word + ' '
```

### 4. Strip User Input

```python
# ✅ Good
user_input = input("Enter name: ").strip()

# ❌ Bad
user_input = input("Enter name: ")  # May have leading/trailing spaces
```

### 5. Use in for Substring Checks

```python
text = "Python Programming"

# ✅ Good
if "Python" in text:
    print("Found")

# ❌ Avoid
if text.find("Python") != -1:
    print("Found")
```

### 6. Use Raw Strings for Paths

```python
# ✅ Good
path = r"C:\Users\Alice\Documents"

# ❌ Avoid
path = "C:\\Users\\Alice\\Documents"
```

### 7. Validate Before Processing

```python
# ✅ Good
user_input = input("Enter age: ")
if user_input.isdigit():
    age = int(user_input)
else:
    print("Invalid input")

# ❌ Bad (may crash)
age = int(input("Enter age: "))
```

---

## Summary

### Key Takeaways

1. **Strings are immutable** - Methods return new strings
2. **Multiple ways to create** - Single, double, triple quotes
3. **Indexing** - Access individual characters (positive/negative)
4. **Slicing** - Extract substrings [start:stop:step]
5. **Rich methods** - 40+ built-in methods for manipulation
6. **f-strings are best** - Modern, readable, efficient
7. **Escape sequences** - Special characters with backslash
8. **Raw strings** - Literal backslashes with r prefix

### Quick Reference

```python
# Creation
s = "Hello"

# Indexing
s[0]        # First
s[-1]       # Last

# Slicing
s[1:4]      # Substring
s[::-1]     # Reverse

# Methods
s.upper()         # HELLO
s.lower()         # hello
s.strip()         # Remove whitespace
s.split()         # Split into list
s.replace(old, new)  # Replace text
s.startswith(x)   # Check start
s.find(x)         # Find position

# Formatting
f"{var}"          # f-string
"{0}".format(var) # .format()
"%s" % var        # % operator

# Operations
s1 + s2           # Concatenate
s * 3             # Repeat
'x' in s          # Membership
len(s)            # Length
```

---

## Next Steps

1. Run the examples in `02_strings_examples.py`
2. Practice with `03_strings_exercises.py`
3. Check solutions in `04_strings_solutions.py`
4. Start using strings in your projects!

**Master strings and you've mastered a huge part of Python! 🎉**
