#!/usr/bin/env python3
"""
Python Strings - Practice Exercises
====================================

Complete these 20 exercises to test your understanding of Python strings.

Instructions:
1. Read each exercise carefully
2. Write your solution
3. Test your code
4. Check 04_strings_solutions.py for answers

Difficulty levels:
★☆☆ - Basic
★★☆ - Intermediate  
★★★ - Advanced
"""

print("=" * 70)
print("PYTHON STRINGS - PRACTICE EXERCISES")
print("=" * 70)
print()

# ============================================================================
# EXERCISE 1: Basic String Creation ★☆☆
# ============================================================================

print("Exercise 1: Basic String Creation ★☆☆")
print("-" * 70)
print("""
Create three strings:
1. A string with your name
2. A string with your favorite color  
3. A multiline string with your address

Print all three.
""")

# Write your solution here:

print()

# ============================================================================
# EXERCISE 2: String Indexing ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 2: String Indexing ★☆☆")
print("-" * 70)
print("""
Given: text = "Programming"

Print:
1. The first character
2. The last character using negative index
3. The 5th character
""")

# Write your solution here:
# text = "Programming"

print()

# ============================================================================
# EXERCISE 3: String Slicing ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 3: String Slicing ★☆☆")
print("-" * 70)
print("""
Given: text = "Python Programming"

Extract and print:
1. The first word (Python)
2. The second word (Programming)
3. Every 2nd character
4. The string reversed
""")

# Write your solution here:
# text = "Python Programming"

print()

# ============================================================================
# EXERCISE 4: String Concatenation ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 4: String Concatenation ★☆☆")
print("-" * 70)
print("""
Create variables:
- first_name = "John"
- last_name = "Doe"

Create and print a full_name string with a space between them.
Then create an email by combining first and last name with "@example.com"
""")

# Write your solution here:

print()

# ============================================================================
# EXERCISE 5: Case Conversion ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 5: Case Conversion ★☆☆")
print("-" * 70)
print("""
Given: text = "python programming"

Print the text in:
1. All uppercase
2. Title case
3. Capitalized (first letter only)
""")

# Write your solution here:
# text = "python programming"

print()

# ============================================================================
# EXERCISE 6: Strip Whitespace ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 6: Strip Whitespace ★☆☆")
print("-" * 70)
print("""
Given: user_input = "   alice@example.com   "

Clean the input by removing leading and trailing whitespace.
Convert to lowercase.
Print the cleaned email.
""")

# Write your solution here:
# user_input = "   alice@example.com   "

print()

# ============================================================================
# EXERCISE 7: Split and Join ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 7: Split and Join ★★☆")
print("-" * 70)
print("""
Given: csv_data = "apple,banana,cherry,date"

1. Split the string into a list of fruits
2. Print the list
3. Join the list back into a string with " | " as separator
4. Print the result
""")

# Write your solution here:
# csv_data = "apple,banana,cherry,date"

print()

# ============================================================================
# EXERCISE 8: String Search ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 8: String Search ★★☆")
print("-" * 70)
print("""
Given: text = "Python is awesome. Python is powerful."

Find and print:
1. The position of the first "Python"
2. The total count of "Python" in the text
3. Whether the text starts with "Python"
4. Whether the text ends with "powerful."
""")

# Write your solution here:
# text = "Python is awesome. Python is powerful."

print()

# ============================================================================
# EXERCISE 9: Replace Text ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 9: Replace Text ★★☆")
print("-" * 70)
print("""
Given: text = "I love Java. Java is great!"

Replace all occurrences of "Java" with "Python"
Print the result.
""")

# Write your solution here:
# text = "I love Java. Java is great!"

print()

# ============================================================================
# EXERCISE 10: f-string Formatting ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 10: f-string Formatting ★★☆")
print("-" * 70)
print("""
Create variables:
- product = "Laptop"
- price = 999.99
- quantity = 3

Use an f-string to print:
"Product: Laptop, Price: $999.99, Quantity: 3, Total: $2999.97"
""")

# Write your solution here:

print()

# ============================================================================
# EXERCISE 11: String Validation ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 11: String Validation ★★☆")
print("-" * 70)
print("""
Write a function that checks if a string is a valid password:
- At least 8 characters
- Contains at least one digit
- Contains at least one letter

Test with: "pass", "password", "pass123", "12345678"
""")

# Write your solution here:
def is_valid_password(password):
    pass  # Replace with your code

# Test cases:
# test_passwords = ["pass", "password", "pass123", "12345678"]

print()

# ============================================================================
# EXERCISE 12: Count Vowels ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 12: Count Vowels ★★☆")
print("-" * 70)
print("""
Write a function that counts the number of vowels (a, e, i, o, u) in a string.
Ignore case.

Test with: "Hello World", "Python Programming"
""")

# Write your solution here:
def count_vowels(text):
    pass  # Replace with your code

# Test cases:
# print(count_vowels("Hello World"))
# print(count_vowels("Python Programming"))

print()

# ============================================================================
# EXERCISE 13: Palindrome Check ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 13: Palindrome Check ★★☆")
print("-" * 70)
print("""
Write a function that checks if a string is a palindrome (reads the same 
forwards and backwards). Ignore case and spaces.

Test with: "racecar", "A man a plan a canal Panama", "hello"
""")

# Write your solution here:
def is_palindrome(text):
    pass  # Replace with your code

# Test cases:
# print(is_palindrome("racecar"))
# print(is_palindrome("A man a plan a canal Panama"))
# print(is_palindrome("hello"))

print()

# ============================================================================
# EXERCISE 14: Extract Initials ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 14: Extract Initials ★★☆")
print("-" * 70)
print("""
Write a function that extracts initials from a full name.

Example: "John Doe" → "J.D."
         "Alice Bob Charlie" → "A.B.C."

Test with: "John Doe", "Alice Bob Charlie"
""")

# Write your solution here:
def get_initials(name):
    pass  # Replace with your code

# Test cases:
# print(get_initials("John Doe"))
# print(get_initials("Alice Bob Charlie"))

print()

# ============================================================================
# EXERCISE 15: Title Case Converter ★★★
# ============================================================================

print("=" * 70)
print("Exercise 15: Title Case Converter ★★★")
print("-" * 70)
print("""
Write a function that converts text to title case, but keeps certain 
words lowercase: "a", "an", "the", "and", "or", "but", "for"

Example: "the lord of the rings" → "The Lord of the Rings"

Test with: "the quick brown fox and the lazy dog"
""")

# Write your solution here:
def smart_title(text):
    pass  # Replace with your code

# Test case:
# print(smart_title("the quick brown fox and the lazy dog"))

print()

# ============================================================================
# EXERCISE 16: Word Frequency ★★★
# ============================================================================

print("=" * 70)
print("Exercise 16: Word Frequency ★★★")
print("-" * 70)
print("""
Write a function that counts the frequency of each word in a text.
Return a dictionary.

Example: "hello world hello" → {"hello": 2, "world": 1}

Test with: "Python is great and Python is fun"
""")

# Write your solution here:
def word_frequency(text):
    pass  # Replace with your code

# Test case:
# print(word_frequency("Python is great and Python is fun"))

print()

# ============================================================================
# EXERCISE 17: Acronym Generator ★★★
# ============================================================================

print("=" * 70)
print("Exercise 17: Acronym Generator ★★★")
print("-" * 70)
print("""
Write a function that generates an acronym from a phrase.

Example: "Portable Network Graphics" → "PNG"
         "Hypertext Markup Language" → "HTML"

Test with: "Portable Network Graphics", "Hypertext Markup Language"
""")

# Write your solution here:
def make_acronym(phrase):
    pass  # Replace with your code

# Test cases:
# print(make_acronym("Portable Network Graphics"))
# print(make_acronym("Hypertext Markup Language"))

print()

# ============================================================================
# EXERCISE 18: Sentence Reverser ★★★
# ============================================================================

print("=" * 70)
print("Exercise 18: Sentence Reverser ★★★")
print("-" * 70)
print("""
Write a function that reverses the order of words in a sentence, 
but keeps the words themselves intact.

Example: "Hello World" → "World Hello"
         "Python is awesome" → "awesome is Python"

Test with: "Hello World", "Python is awesome"
""")

# Write your solution here:
def reverse_sentence(sentence):
    pass  # Replace with your code

# Test cases:
# print(reverse_sentence("Hello World"))
# print(reverse_sentence("Python is awesome"))

print()

# ============================================================================
# EXERCISE 19: Caesar Cipher ★★★
# ============================================================================

print("=" * 70)
print("Exercise 19: Caesar Cipher ★★★")
print("-" * 70)
print("""
Write a function that encrypts a message using Caesar cipher 
(shift each letter by n positions).

Example: "abc" with shift 1 → "bcd"
         "Hello" with shift 3 → "Khoor"

Only shift letters, keep other characters unchanged.
Handle both upper and lowercase.

Test with: "Hello World", shift 3
""")

# Write your solution here:
def caesar_cipher(text, shift):
    pass  # Replace with your code

# Test case:
# print(caesar_cipher("Hello World", 3))

print()

# ============================================================================
# EXERCISE 20: String Compression ★★★
# ============================================================================

print("=" * 70)
print("Exercise 20: String Compression ★★★")
print("-" * 70)
print("""
Write a function that compresses a string using run-length encoding.

Example: "aaabbbcc" → "a3b3c2"
         "abcd" → "abcd" (no compression if not shorter)

Test with: "aaabbbcc", "aabbcc", "abcd"
""")

# Write your solution here:
def compress_string(text):
    pass  # Replace with your code

# Test cases:
# print(compress_string("aaabbbcc"))
# print(compress_string("aabbcc"))
# print(compress_string("abcd"))

print()

# ============================================================================
# CONGRATULATIONS!
# ============================================================================

print("=" * 70)
print("CONGRATULATIONS!")
print("=" * 70)
print("""
You've completed all 20 string exercises!

Next steps:
1. Check your solutions in 04_strings_solutions.py
2. Compare your approach with the provided solutions
3. Learn from the explanations
4. Keep practicing with your own string problems!

String mastery unlocked! 🎉
""")
