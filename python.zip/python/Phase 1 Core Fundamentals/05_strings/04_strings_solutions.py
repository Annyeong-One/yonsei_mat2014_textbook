#!/usr/bin/env python3
"""
Python Strings - Exercise Solutions
====================================

Detailed solutions and explanations for all 20 exercises.

Each solution includes:
1. The complete code
2. Expected output
3. Step-by-step explanation
4. Key concepts demonstrated
"""

print("=" * 70)
print("PYTHON STRINGS - EXERCISE SOLUTIONS")
print("=" * 70)
print()

# ============================================================================
# SOLUTION 1: Basic String Creation
# ============================================================================

print("Solution 1: Basic String Creation ★☆☆")
print("-" * 70)

name = "Alice Johnson"
favorite_color = "Blue"
address = """123 Main Street
Springfield, IL 62701
USA"""

print(f"Name: {name}")
print(f"Favorite Color: {favorite_color}")
print(f"Address:\n{address}")

print("\nExplanation:")
print("• Use single or double quotes for regular strings")
print("• Use triple quotes (''' or \"\"\") for multiline strings")
print("• Triple quotes preserve all newlines and formatting")
print()

# ============================================================================
# SOLUTION 2: String Indexing
# ============================================================================

print("=" * 70)
print("Solution 2: String Indexing ★☆☆")
print("-" * 70)

text = "Programming"

print(f"String: '{text}'")
print(f"First character: '{text[0]}'")
print(f"Last character: '{text[-1]}'")
print(f"5th character: '{text[4]}'")

print("\nExplanation:")
print("• text[0]: first character (index 0)")
print("• text[-1]: last character (negative indexing)")
print("• text[4]: 5th character (0-indexed, so 4)")
print("• Negative indices count from the end")
print()

# ============================================================================
# SOLUTION 3: String Slicing
# ============================================================================

print("=" * 70)
print("Solution 3: String Slicing ★☆☆")
print("-" * 70)

text = "Python Programming"

first_word = text[:6]
second_word = text[7:]
every_second = text[::2]
reversed_text = text[::-1]

print(f"Original: '{text}'")
print(f"First word: '{first_word}'")
print(f"Second word: '{second_word}'")
print(f"Every 2nd character: '{every_second}'")
print(f"Reversed: '{reversed_text}'")

print("\nExplanation:")
print("• [:6]: from start to index 6 (exclusive)")
print("• [7:]: from index 7 to end")
print("• [::2]: every 2nd character (step=2)")
print("• [::-1]: reverse (negative step)")
print()

# ============================================================================
# SOLUTION 4: String Concatenation
# ============================================================================

print("=" * 70)
print("Solution 4: String Concatenation ★☆☆")
print("-" * 70)

first_name = "John"
last_name = "Doe"

full_name = first_name + " " + last_name
email = first_name.lower() + "." + last_name.lower() + "@example.com"

print(f"Full name: {full_name}")
print(f"Email: {email}")

print("\nExplanation:")
print("• Use + to concatenate strings")
print("• Add spaces manually when needed")
print("• Use .lower() to convert to lowercase")
print("• Can chain multiple + operations")
print()

# ============================================================================
# SOLUTION 5: Case Conversion
# ============================================================================

print("=" * 70)
print("Solution 5: Case Conversion ★☆☆")
print("-" * 70)

text = "python programming"

print(f"Original: '{text}'")
print(f"Uppercase: '{text.upper()}'")
print(f"Title case: '{text.title()}'")
print(f"Capitalized: '{text.capitalize()}'")

print("\nExplanation:")
print("• .upper(): converts all characters to uppercase")
print("• .title(): capitalizes first letter of each word")
print("• .capitalize(): capitalizes only the first letter")
print()

# ============================================================================
# SOLUTION 6: Strip Whitespace
# ============================================================================

print("=" * 70)
print("Solution 6: Strip Whitespace ★☆☆")
print("-" * 70)

user_input = "   alice@example.com   "

cleaned_email = user_input.strip().lower()

print(f"Original: '{user_input}'")
print(f"Cleaned: '{cleaned_email}'")

print("\nExplanation:")
print("• .strip() removes leading and trailing whitespace")
print("• .lower() converts to lowercase")
print("• Can chain methods together")
print("• Always clean user input!")
print()

# ============================================================================
# SOLUTION 7: Split and Join
# ============================================================================

print("=" * 70)
print("Solution 7: Split and Join ★★☆")
print("-" * 70)

csv_data = "apple,banana,cherry,date"

fruits = csv_data.split(',')
print(f"Original: '{csv_data}'")
print(f"Split list: {fruits}")

joined = " | ".join(fruits)
print(f"Joined: '{joined}'")

print("\nExplanation:")
print("• .split(','): splits string on comma delimiter")
print("• Returns a list of strings")
print("• .join(): joins list into string")
print("• Join is called on the delimiter string")
print()

# ============================================================================
# SOLUTION 8: String Search
# ============================================================================

print("=" * 70)
print("Solution 8: String Search ★★☆")
print("-" * 70)

text = "Python is awesome. Python is powerful."

position = text.find("Python")
count = text.count("Python")
starts = text.startswith("Python")
ends = text.endswith("powerful.")

print(f"Text: '{text}'")
print(f"Position of first 'Python': {position}")
print(f"Count of 'Python': {count}")
print(f"Starts with 'Python': {starts}")
print(f"Ends with 'powerful.': {ends}")

print("\nExplanation:")
print("• .find(): returns index of first occurrence")
print("• .count(): counts total occurrences")
print("• .startswith(): checks beginning")
print("• .endswith(): checks end")
print()

# ============================================================================
# SOLUTION 9: Replace Text
# ============================================================================

print("=" * 70)
print("Solution 9: Replace Text ★★☆")
print("-" * 70)

text = "I love Java. Java is great!"

replaced = text.replace("Java", "Python")

print(f"Original: '{text}'")
print(f"Replaced: '{replaced}'")

print("\nExplanation:")
print("• .replace(old, new): replaces all occurrences")
print("• Returns new string (original unchanged)")
print("• Case-sensitive replacement")
print()

# ============================================================================
# SOLUTION 10: f-string Formatting
# ============================================================================

print("=" * 70)
print("Solution 10: f-string Formatting ★★☆")
print("-" * 70)

product = "Laptop"
price = 999.99
quantity = 3
total = price * quantity

result = f"Product: {product}, Price: ${price:.2f}, Quantity: {quantity}, Total: ${total:.2f}"
print(result)

print("\nExplanation:")
print("• f-strings: prefix with f and use {variables}")
print("• {price:.2f}: formats float to 2 decimal places")
print("• Can include expressions like {price * quantity}")
print("• Most readable formatting method")
print()

# ============================================================================
# SOLUTION 11: String Validation
# ============================================================================

print("=" * 70)
print("Solution 11: String Validation ★★☆")
print("-" * 70)

def is_valid_password(password):
    """Check if password is valid (8+ chars, has digit and letter)"""
    if len(password) < 8:
        return False
    
    has_digit = any(char.isdigit() for char in password)
    has_letter = any(char.isalpha() for char in password)
    
    return has_digit and has_letter

# Test cases
test_passwords = ["pass", "password", "pass123", "12345678"]

for pwd in test_passwords:
    valid = is_valid_password(pwd)
    print(f"'{pwd}' → {valid}")

print("\nExplanation:")
print("• len(password): checks length")
print("• any(): checks if any element is True")
print("• char.isdigit(): checks if character is a digit")
print("• char.isalpha(): checks if character is a letter")
print("• Combines multiple validation rules")
print()

# ============================================================================
# SOLUTION 12: Count Vowels
# ============================================================================

print("=" * 70)
print("Solution 12: Count Vowels ★★☆")
print("-" * 70)

def count_vowels(text):
    """Count vowels in a string (case-insensitive)"""
    vowels = "aeiouAEIOU"
    count = 0
    for char in text:
        if char in vowels:
            count += 1
    return count

# Alternative solution using sum
def count_vowels_v2(text):
    """Count vowels using sum and generator"""
    return sum(1 for char in text if char.lower() in "aeiou")

test_strings = ["Hello World", "Python Programming"]

for string in test_strings:
    count = count_vowels(string)
    print(f"'{string}' → {count} vowels")

print("\nExplanation:")
print("• Iterate through each character")
print("• Check if character is in vowels string")
print("• Increment counter if vowel found")
print("• Alternative: use sum with generator expression")
print()

# ============================================================================
# SOLUTION 13: Palindrome Check
# ============================================================================

print("=" * 70)
print("Solution 13: Palindrome Check ★★☆")
print("-" * 70)

def is_palindrome(text):
    """Check if string is a palindrome (ignore case and spaces)"""
    # Remove spaces and convert to lowercase
    cleaned = text.replace(" ", "").lower()
    # Check if equals its reverse
    return cleaned == cleaned[::-1]

test_cases = [
    "racecar",
    "A man a plan a canal Panama",
    "hello"
]

for test in test_cases:
    result = is_palindrome(test)
    print(f"'{test}' → {result}")

print("\nExplanation:")
print("• .replace(' ', ''): removes all spaces")
print("• .lower(): converts to lowercase")
print("• [::-1]: reverses the string")
print("• Compare cleaned string with its reverse")
print()

# ============================================================================
# SOLUTION 14: Extract Initials
# ============================================================================

print("=" * 70)
print("Solution 14: Extract Initials ★★☆")
print("-" * 70)

def get_initials(name):
    """Extract initials from a full name"""
    words = name.split()
    initials = []
    for word in words:
        initials.append(word[0].upper())
    return ".".join(initials) + "."

# Alternative: more concise
def get_initials_v2(name):
    """Extract initials using list comprehension"""
    return ".".join(word[0].upper() for word in name.split()) + "."

test_names = ["John Doe", "Alice Bob Charlie"]

for name in test_names:
    initials = get_initials(name)
    print(f"'{name}' → '{initials}'")

print("\nExplanation:")
print("• .split(): splits name into words")
print("• word[0]: gets first character of each word")
print("• .upper(): converts to uppercase")
print("• '.'.join(): joins with periods")
print("• Add final period at the end")
print()

# ============================================================================
# SOLUTION 15: Title Case Converter
# ============================================================================

print("=" * 70)
print("Solution 15: Title Case Converter ★★★")
print("-" * 70)

def smart_title(text):
    """Convert to title case, keeping certain words lowercase"""
    lowercase_words = {"a", "an", "the", "and", "or", "but", "for"}
    
    words = text.split()
    result = []
    
    for i, word in enumerate(words):
        # Capitalize first word and words not in lowercase set
        if i == 0 or word.lower() not in lowercase_words:
            result.append(word.capitalize())
        else:
            result.append(word.lower())
    
    return " ".join(result)

test_text = "the quick brown fox and the lazy dog"
result = smart_title(test_text)

print(f"Original: '{test_text}'")
print(f"Smart title: '{result}'")

print("\nExplanation:")
print("• Define set of words to keep lowercase")
print("• Always capitalize first word (i == 0)")
print("• Capitalize words not in lowercase set")
print("• Keep others lowercase")
print("• Join words back together")
print()

# ============================================================================
# SOLUTION 16: Word Frequency
# ============================================================================

print("=" * 70)
print("Solution 16: Word Frequency ★★★")
print("-" * 70)

def word_frequency(text):
    """Count frequency of each word"""
    words = text.lower().split()
    frequency = {}
    
    for word in words:
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1
    
    return frequency

# Alternative using .get()
def word_frequency_v2(text):
    """Count frequency using .get()"""
    words = text.lower().split()
    frequency = {}
    
    for word in words:
        frequency[word] = frequency.get(word, 0) + 1
    
    return frequency

test_text = "Python is great and Python is fun"
result = word_frequency(test_text)

print(f"Text: '{test_text}'")
print(f"Frequency: {result}")

print("\nExplanation:")
print("• .lower().split(): normalize and split")
print("• Use dictionary to store counts")
print("• Check if word exists, increment or initialize")
print("• Alternative: use .get(word, 0) for default value")
print()

# ============================================================================
# SOLUTION 17: Acronym Generator
# ============================================================================

print("=" * 70)
print("Solution 17: Acronym Generator ★★★")
print("-" * 70)

def make_acronym(phrase):
    """Generate acronym from phrase"""
    words = phrase.split()
    acronym = ""
    for word in words:
        acronym += word[0].upper()
    return acronym

# Alternative: more concise
def make_acronym_v2(phrase):
    """Generate acronym using join"""
    return "".join(word[0].upper() for word in phrase.split())

test_phrases = [
    "Portable Network Graphics",
    "Hypertext Markup Language"
]

for phrase in test_phrases:
    acronym = make_acronym(phrase)
    print(f"'{phrase}' → '{acronym}'")

print("\nExplanation:")
print("• .split(): splits phrase into words")
print("• word[0]: first character of each word")
print("• .upper(): convert to uppercase")
print("• Join all first characters together")
print()

# ============================================================================
# SOLUTION 18: Sentence Reverser
# ============================================================================

print("=" * 70)
print("Solution 18: Sentence Reverser ★★★")
print("-" * 70)

def reverse_sentence(sentence):
    """Reverse word order but keep words intact"""
    words = sentence.split()
    reversed_words = words[::-1]
    return " ".join(reversed_words)

# One-liner version
def reverse_sentence_v2(sentence):
    """Reverse sentence in one line"""
    return " ".join(sentence.split()[::-1])

test_sentences = ["Hello World", "Python is awesome"]

for sentence in test_sentences:
    reversed_s = reverse_sentence(sentence)
    print(f"'{sentence}' → '{reversed_s}'")

print("\nExplanation:")
print("• .split(): splits into words")
print("• [::-1]: reverses the list of words")
print("• .join(): joins words back with spaces")
print("• Words themselves remain unchanged")
print()

# ============================================================================
# SOLUTION 19: Caesar Cipher
# ============================================================================

print("=" * 70)
print("Solution 19: Caesar Cipher ★★★")
print("-" * 70)

def caesar_cipher(text, shift):
    """Encrypt text using Caesar cipher"""
    result = ""
    
    for char in text:
        if char.isalpha():
            # Get ASCII value
            ascii_offset = ord('A') if char.isupper() else ord('a')
            
            # Shift character
            shifted = (ord(char) - ascii_offset + shift) % 26
            
            # Convert back to character
            result += chr(shifted + ascii_offset)
        else:
            # Keep non-alphabetic characters unchanged
            result += char
    
    return result

test_text = "Hello World"
shift_amount = 3
encrypted = caesar_cipher(test_text, shift_amount)

print(f"Original: '{test_text}'")
print(f"Shift: {shift_amount}")
print(f"Encrypted: '{encrypted}'")

# Decrypt by shifting back
decrypted = caesar_cipher(encrypted, -shift_amount)
print(f"Decrypted: '{decrypted}'")

print("\nExplanation:")
print("• ord(char): gets ASCII value of character")
print("• Determine offset based on case (A or a)")
print("• Shift within alphabet using modulo 26")
print("• chr(): converts ASCII back to character")
print("• Keep non-alphabetic characters unchanged")
print("• To decrypt: shift in opposite direction")
print()

# ============================================================================
# SOLUTION 20: String Compression
# ============================================================================

print("=" * 70)
print("Solution 20: String Compression ★★★")
print("-" * 70)

def compress_string(text):
    """Compress string using run-length encoding"""
    if not text:
        return text
    
    compressed = []
    count = 1
    current_char = text[0]
    
    for i in range(1, len(text)):
        if text[i] == current_char:
            count += 1
        else:
            # Add character and count to result
            compressed.append(current_char + str(count))
            current_char = text[i]
            count = 1
    
    # Add the last group
    compressed.append(current_char + str(count))
    
    # Join and return only if shorter than original
    result = "".join(compressed)
    return result if len(result) < len(text) else text

test_strings = ["aaabbbcc", "aabbcc", "abcd"]

for string in test_strings:
    compressed = compress_string(string)
    print(f"'{string}' → '{compressed}'")

print("\nExplanation:")
print("• Track current character and count")
print("• When character changes, add 'char' + 'count'")
print("• Don't forget the last group")
print("• Only return compressed if shorter")
print("• Example: 'aaa' → 'a3' (2 chars shorter)")
print()

# ============================================================================
# FINAL SUMMARY
# ============================================================================

print("=" * 70)
print("CONGRATULATIONS! 🎉")
print("=" * 70)
print("""
You've reviewed all 20 string exercise solutions!

Key Skills Mastered:

1. String Creation & Manipulation
   • Single, double, triple quotes
   • Concatenation and repetition

2. Indexing & Slicing
   • Positive and negative indices
   • Extracting substrings

3. String Methods
   • Case conversion (.upper, .lower, .title)
   • Trimming (.strip, .lstrip, .rstrip)
   • Splitting and joining
   • Searching and replacing

4. String Formatting
   • f-strings (modern and best)
   • .format() method
   • Alignment and padding

5. Validation & Analysis
   • Character type checking
   • Pattern matching
   • Frequency counting

6. Advanced Techniques
   • Palindrome checking
   • Cipher encryption
   • String compression
   • Text transformations

Best Practices Learned:
✓ Always strip user input
✓ Use f-strings for formatting
✓ Validate before processing
✓ Use appropriate string methods
✓ Consider edge cases
✓ Write clean, readable code

Next Steps:
• Apply these skills in your projects
• Practice with real-world text data
• Explore regular expressions (regex)
• Build text processing applications

Keep practicing and happy coding! 🐍
""")
