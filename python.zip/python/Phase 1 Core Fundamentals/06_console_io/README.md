# Module 13: Console Input/Output 💬

Learn how to interact with users through the console using Python's input and output functions.

## 📚 What You'll Learn

- **Console Output**
  - Using the `print()` function
  - Formatting output with f-strings
  - Number formatting and alignment
  - Creating formatted tables

- **Console Input**
  - Getting user input with `input()`
  - Type conversion (int, float, etc.)
  - Handling multiple inputs
  - Input validation techniques

- **String Formatting**
  - F-strings (modern approach)
  - format() method
  - Alignment and padding
  - Special format specifications

- **Input Validation**
  - Using try-except blocks
  - Range validation
  - Choice validation
  - Error handling

- **Interactive Programs**
  - Menu systems
  - Simple games
  - Calculators
  - User registration forms

## 📋 Prerequisites

Before starting this module, you should be familiar with:
- **Module 01-05**: Python basics, variables, data types
- **Module 06-07**: Control flow and loops
- **Module 08-11**: Data structures (lists, dictionaries, etc.)
- **Module 12**: Functions

## 📁 Module Structure

```
13_console_io/
├── README.md              # This file
├── tutorial.md            # Complete tutorial with examples
├── examples/              # Code examples
│   ├── basic_io.py       # Basic input/output
│   ├── formatting.py     # String formatting examples
│   ├── validation.py     # Input validation patterns
│   └── interactive.py    # Interactive program examples
├── exercises/             # Practice exercises
│   └── exercises.md      # Exercise descriptions
└── solutions/             # Exercise solutions
    ├── exercise_01.py
    ├── exercise_02.py
    └── ...
```

## 🚀 Getting Started

### 1. Read the Tutorial
Start with `tutorial.md` for a comprehensive introduction to console I/O.

### 2. Study the Examples
Check out the `examples/` directory for practical code examples:
```bash
cd examples
python basic_io.py
python formatting.py
python validation.py
python interactive.py
```

### 3. Complete the Exercises
Practice what you've learned with exercises in `exercises/exercises.md`.

### 4. Check Solutions
Compare your solutions with the provided ones in the `solutions/` directory.

## 💡 Quick Start Example

```python
# Simple interactive program
name = input("What's your name? ")
age = int(input("How old are you? "))

print(f"Hello, {name}!")
print(f"Next year you'll be {age + 1} years old.")
```

## 🎯 Key Concepts

### Output
```python
# Basic output
print("Hello, World!")

# Formatted output
name = "Alice"
age = 25
print(f"Name: {name}, Age: {age}")

# Number formatting
pi = 3.14159
print(f"Pi: {pi:.2f}")  # Output: Pi: 3.14
```

### Input
```python
# Getting input
name = input("Enter your name: ")

# Converting input
age = int(input("Enter your age: "))
height = float(input("Enter your height: "))

# Validating input
while True:
    try:
        age = int(input("Enter age: "))
        if age > 0:
            break
        print("Age must be positive!")
    except ValueError:
        print("Please enter a valid number!")
```

## ⚠️ Common Mistakes to Avoid

1. **Forgetting that input() returns a string**
   ```python
   # Wrong
   age = input("Age: ")
   next_year = age + 1  # Error! Can't add int to string
   
   # Correct
   age = int(input("Age: "))
   next_year = age + 1
   ```

2. **Not validating input**
   ```python
   # Wrong
   age = int(input("Age: "))  # Crashes if user enters text
   
   # Correct
   while True:
       try:
           age = int(input("Age: "))
           break
       except ValueError:
           print("Please enter a number!")
   ```

3. **Using + for formatting instead of f-strings**
   ```python
   # Not recommended
   print("Hello " + name + ", you are " + str(age))
   
   # Better
   print(f"Hello {name}, you are {age}")
   ```

## 🔗 What's Next?

After completing this module, you'll be ready for:

- **Module 14: File Operations** - Learn to read and write files, work with CSV/JSON
- **Module 15: LEGB Rule** - Understand scope and namespaces
- **Module 16: Recursion** - Master recursive functions

## 📚 Additional Resources

- [Python Official Documentation - Input/Output](https://docs.python.org/3/tutorial/inputoutput.html)
- [PEP 498 - Literal String Interpolation (f-strings)](https://www.python.org/dev/peps/pep-0498/)
- [Python String Formatting](https://docs.python.org/3/library/string.html#formatstrings)

## 🤝 Need Help?

- Review the tutorial and examples
- Check the solutions for guidance
- Try breaking down complex problems into smaller steps
- Practice with different types of input and output

## ⭐ Tips for Success

1. **Practice regularly** - Try creating small interactive programs
2. **Validate all input** - Always handle potential errors
3. **Use f-strings** - They're more readable and efficient
4. **Provide clear prompts** - Users should know what to enter
5. **Give feedback** - Let users know what's happening

---

**Ready to start?** Open `tutorial.md` and begin your journey into console I/O! 🚀

**Note:** This module focuses exclusively on console (terminal) input and output. File operations (reading/writing files) are covered in Module 14.
