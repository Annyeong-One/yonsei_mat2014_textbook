# Python Console Input/Output Tutorial

## Table of Contents
1. [Introduction](#introduction)
2. [Console Output](#console-output)
3. [Console Input](#console-input)
4. [String Formatting](#string-formatting)
5. [Input Validation](#input-validation)
6. [Interactive Programs](#interactive-programs)
7. [Best Practices](#best-practices)

---

## Introduction

Console Input/Output (I/O) operations allow programs to interact with users through the terminal or command line. They are fundamental for:
- **Output**: Displaying information, results, and messages to users
- **Input**: Receiving data and commands from users
- **Interaction**: Creating interactive command-line programs

Python provides simple, intuitive functions for console I/O operations.

---

## Console Output

### The print() Function

The `print()` function displays output to the console.

**Basic Syntax:**
```python
print(value1, value2, ..., sep=' ', end='\n')
```

**Parameters:**
- `sep` - Separator between values (default: space)
- `end` - Character at the end (default: newline)

**Examples:**

```python
# Simple output
print("Hello, World!")

# Multiple values
print("Python", "is", "awesome")  
# Output: Python is awesome

# Custom separator
print("Python", "is", "awesome", sep="-")  
# Output: Python-is-awesome

# Custom ending (no newline)
print("Hello", end=" ")
print("World")  
# Output: Hello World (on same line)

# Empty line
print()

# Multiple items
name = "Alice"
age = 25
print("Name:", name, "Age:", age)
# Output: Name: Alice Age: 25
```

### Formatting Output

**1. f-strings (Recommended - Python 3.6+):**
```python
name = "Alice"
age = 25
city = "New York"

print(f"My name is {name} and I am {age} years old")
print(f"I live in {city}")
print(f"{name} will be {age + 1} next year")

# Expressions inside f-strings
x = 10
y = 20
print(f"The sum of {x} and {y} is {x + y}")
```

**2. format() method:**
```python
print("My name is {} and I am {} years old".format(name, age))
print("My name is {0} and I am {1} years old".format(name, age))
print("My name is {n} and I am {a} years old".format(n=name, a=age))
```

**3. Old-style formatting (legacy):**
```python
print("My name is %s and I am %d years old" % (name, age))
```

### Number Formatting

```python
pi = 3.14159265359

# Decimal places
print(f"Pi: {pi:.2f}")  # Output: Pi: 3.14
print(f"Pi: {pi:.4f}")  # Output: Pi: 3.1416

# Width and alignment
print(f"Pi: {pi:10.2f}")   # Right-aligned in 10 spaces: "      3.14"
print(f"Pi: {pi:<10.2f}")  # Left-aligned: "3.14      "
print(f"Pi: {pi:^10.2f}")  # Center-aligned: "   3.14   "

# Padding with zeros
print(f"Number: {42:05d}")  # Output: Number: 00042

# Thousands separator
big_number = 1000000
print(f"Number: {big_number:,}")  # Output: Number: 1,000,000
print(f"Number: {big_number:_}")  # Output: Number: 1_000_000

# Percentage
ratio = 0.875
print(f"Success rate: {ratio:.1%}")  # Output: Success rate: 87.5%

# Scientific notation
large = 1234567890
print(f"Scientific: {large:.2e}")  # Output: Scientific: 1.23e+09
```

### Advanced Formatting

```python
# Table formatting
print(f"{'Name':<10} {'Age':>5} {'City':<15}")
print("-" * 30)
print(f"{'Alice':<10} {25:>5} {'New York':<15}")
print(f"{'Bob':<10} {30:>5} {'Los Angeles':<15}")

# Multiple lines
message = f"""
Name: {name}
Age: {age}
City: {city}
"""
print(message)

# Dictionary formatting
person = {"name": "Alice", "age": 25, "city": "New York"}
print(f"Person: {person['name']}, {person['age']}, {person['city']}")
```

---

## Console Input

### The input() Function

The `input()` function reads a line from the user as a **string**.

**Basic Syntax:**
```python
variable = input(prompt)
```

**Examples:**

```python
# Get user's name
name = input("Enter your name: ")
print(f"Hello, {name}!")

# Get age (returns string!)
age = input("Enter your age: ")
print(f"Type of age: {type(age)}")  # Output: <class 'str'>

# Without prompt
response = input()
print(f"You entered: {response}")
```

**Important:** `input()` always returns a string, even if the user types a number!

### Type Conversion

Convert input to other data types:

```python
# Integer input
age = int(input("Enter your age: "))
print(f"Next year you'll be {age + 1}")

# Float input
height = float(input("Enter your height in meters: "))
print(f"Your height is {height} meters")

# Boolean conversion
answer = input("Are you ready? (yes/no): ")
is_ready = answer.lower() == "yes"
print(f"Ready status: {is_ready}")

# Multiple inputs on one line
numbers = input("Enter two numbers separated by space: ")
x, y = numbers.split()
x, y = int(x), int(y)
print(f"Sum: {x + y}")

# Alternative for multiple inputs
x, y = map(int, input("Enter two numbers: ").split())
print(f"Product: {x * y}")
```

### Handling Different Input Types

```python
# List of numbers
numbers = input("Enter numbers separated by spaces: ")
num_list = [int(n) for n in numbers.split()]
print(f"Numbers: {num_list}")
print(f"Sum: {sum(num_list)}")

# Yes/No questions
answer = input("Continue? (y/n): ").lower()
if answer in ['y', 'yes']:
    print("Continuing...")
else:
    print("Stopping...")

# Multiple choice
print("Choose an option:")
print("1. Option A")
print("2. Option B")
print("3. Option C")
choice = input("Enter choice (1-3): ")
```

---

## String Formatting

### Format Specifications

```python
# Alignment
text = "Python"
print(f"|{text:<10}|")  # Left: |Python    |
print(f"|{text:>10}|")  # Right: |    Python|
print(f"|{text:^10}|")  # Center: |  Python  |

# Fill character
print(f"|{text:*<10}|")  # |Python****|
print(f"|{text:->10}|")  # |----Python|

# Numbers with signs
num = 42
print(f"{num:+d}")   # +42 (show sign)
print(f"{num: d}")   # " 42" (space for positive)
print(f"{-num:+d}")  # -42

# Binary, octal, hex
number = 42
print(f"Decimal: {number}")      # 42
print(f"Binary: {number:b}")     # 101010
print(f"Octal: {number:o}")      # 52
print(f"Hex: {number:x}")        # 2a
print(f"Hex (upper): {number:X}") # 2A
```

### String Operations in Output

```python
name = "alice"

# Case conversion
print(f"Name: {name.upper()}")      # ALICE
print(f"Name: {name.capitalize()}")  # Alice
print(f"Name: {name.title()}")      # Alice

# String methods
text = "  hello world  "
print(f"Stripped: '{text.strip()}'")
print(f"Length: {len(text)}")

# Joining
words = ["Python", "is", "awesome"]
print(f"Joined: {' '.join(words)}")
```

---

## Input Validation

### Basic Validation

Always validate user input to prevent errors:

```python
# Method 1: Loop until valid
while True:
    age = input("Enter your age: ")
    if age.isdigit():
        age = int(age)
        if age > 0:
            break
        else:
            print("Age must be positive!")
    else:
        print("Please enter a valid number!")

print(f"Your age is {age}")
```

### Using Try-Except

```python
# Integer validation
while True:
    try:
        age = int(input("Enter your age: "))
        if age < 0:
            print("Age cannot be negative!")
            continue
        if age > 150:
            print("Please enter a realistic age!")
            continue
        break
    except ValueError:
        print("Please enter a valid number!")

print(f"Your age is {age}")

# Float validation
while True:
    try:
        price = float(input("Enter price: $"))
        if price < 0:
            print("Price cannot be negative!")
            continue
        break
    except ValueError:
        print("Please enter a valid number!")

print(f"Price: ${price:.2f}")
```

### Range Validation

```python
def get_number_in_range(prompt, min_val, max_val):
    """Get a number within a specific range."""
    while True:
        try:
            num = int(input(prompt))
            if min_val <= num <= max_val:
                return num
            else:
                print(f"Please enter a number between {min_val} and {max_val}")
        except ValueError:
            print("Please enter a valid number!")

# Usage
score = get_number_in_range("Enter score (0-100): ", 0, 100)
print(f"Score: {score}")
```

### Choice Validation

```python
def get_choice(prompt, valid_choices):
    """Get input that matches one of the valid choices."""
    while True:
        choice = input(prompt).lower().strip()
        if choice in valid_choices:
            return choice
        else:
            print(f"Please enter one of: {', '.join(valid_choices)}")

# Usage
answer = get_choice("Continue? (yes/no): ", ['yes', 'no', 'y', 'n'])
print(f"You chose: {answer}")
```

---

## Interactive Programs

### Simple Menu System

```python
def display_menu():
    print("\n" + "="*40)
    print("MAIN MENU")
    print("="*40)
    print("1. Option A")
    print("2. Option B")
    print("3. Option C")
    print("4. Exit")
    print("="*40)

def main():
    while True:
        display_menu()
        choice = input("Enter your choice (1-4): ")
        
        if choice == '1':
            print("You selected Option A")
        elif choice == '2':
            print("You selected Option B")
        elif choice == '3':
            print("You selected Option C")
        elif choice == '4':
            print("Goodbye!")
            break
        else:
            print("Invalid choice! Please try again.")

# main()  # Uncomment to run
```

### Calculator Example

```python
def calculator():
    print("Simple Calculator")
    print("-" * 30)
    
    while True:
        try:
            num1 = float(input("Enter first number: "))
            operator = input("Enter operator (+, -, *, /): ")
            num2 = float(input("Enter second number: "))
            
            if operator == '+':
                result = num1 + num2
            elif operator == '-':
                result = num1 - num2
            elif operator == '*':
                result = num1 * num2
            elif operator == '/':
                if num2 == 0:
                    print("Error: Cannot divide by zero!")
                    continue
                result = num1 / num2
            else:
                print("Invalid operator!")
                continue
            
            print(f"\nResult: {num1} {operator} {num2} = {result}")
            
            again = input("\nCalculate again? (y/n): ")
            if again.lower() != 'y':
                break
                
        except ValueError:
            print("Error: Please enter valid numbers!")

# calculator()  # Uncomment to run
```

### Quiz Program

```python
def quiz():
    score = 0
    questions = [
        {
            "question": "What is the capital of France?",
            "options": ["1. London", "2. Paris", "3. Berlin", "4. Madrid"],
            "answer": "2"
        },
        {
            "question": "What is 2 + 2?",
            "options": ["1. 3", "2. 4", "3. 5", "4. 6"],
            "answer": "2"
        }
    ]
    
    print("QUIZ TIME!")
    print("="*40)
    
    for i, q in enumerate(questions, 1):
        print(f"\nQuestion {i}: {q['question']}")
        for option in q['options']:
            print(f"  {option}")
        
        answer = input("Your answer: ")
        if answer == q['answer']:
            print("✓ Correct!")
            score += 1
        else:
            print("✗ Wrong!")
    
    print(f"\n{'='*40}")
    print(f"Your score: {score}/{len(questions)}")
    print(f"Percentage: {score/len(questions)*100:.1f}%")

# quiz()  # Uncomment to run
```

### User Registration

```python
def register_user():
    print("USER REGISTRATION")
    print("="*40)
    
    # Get username
    while True:
        username = input("Username (3-20 characters): ").strip()
        if 3 <= len(username) <= 20:
            break
        print("Username must be 3-20 characters!")
    
    # Get age
    while True:
        try:
            age = int(input("Age (13+): "))
            if age >= 13:
                break
            print("You must be at least 13 years old!")
        except ValueError:
            print("Please enter a valid number!")
    
    # Get email
    while True:
        email = input("Email: ").strip()
        if '@' in email and '.' in email:
            break
        print("Please enter a valid email!")
    
    # Confirm
    print("\n" + "="*40)
    print("REGISTRATION SUMMARY")
    print("="*40)
    print(f"Username: {username}")
    print(f"Age: {age}")
    print(f"Email: {email}")
    print("="*40)
    
    confirm = input("\nConfirm registration? (yes/no): ")
    if confirm.lower() == 'yes':
        print("✓ Registration successful!")
        return {"username": username, "age": age, "email": email}
    else:
        print("Registration cancelled.")
        return None

# user = register_user()  # Uncomment to run
```

---

## Best Practices

### 1. Always Validate Input
Never trust user input - always validate and handle errors.

```python
# BAD
age = int(input("Enter age: "))  # Can crash!

# GOOD
while True:
    try:
        age = int(input("Enter age: "))
        if age > 0:
            break
        print("Age must be positive!")
    except ValueError:
        print("Please enter a valid number!")
```

### 2. Use Clear Prompts
Make it obvious what input is expected.

```python
# BAD
x = input("Enter: ")

# GOOD
age = input("Enter your age (years): ")
name = input("Enter your full name: ")
```

### 3. Use f-strings for Formatting
Modern, readable, and efficient.

```python
# BAD
print("Hello " + name + ", you are " + str(age) + " years old")

# GOOD
print(f"Hello {name}, you are {age} years old")
```

### 4. Strip Whitespace
Remove leading/trailing spaces from input.

```python
name = input("Enter your name: ").strip()
```

### 5. Provide Feedback
Let users know what's happening.

```python
print("Processing...")
# Do something
print("✓ Done!")

print("Loading data...")
# Load data
print("✓ Data loaded successfully!")
```

### 6. Use Meaningful Variable Names

```python
# BAD
x = input("Enter name: ")
y = int(input("Enter age: "))

# GOOD
name = input("Enter name: ")
age = int(input("Enter age: "))
```

### 7. Handle Edge Cases

```python
# Check for empty input
name = input("Enter name: ").strip()
if not name:
    print("Name cannot be empty!")

# Check for division by zero
if divisor == 0:
    print("Cannot divide by zero!")
```

---

## Common Patterns

### Getting Confirmed Input

```python
def get_confirmed_input(prompt):
    while True:
        value = input(prompt)
        confirm = input(f"You entered '{value}'. Is this correct? (y/n): ")
        if confirm.lower() == 'y':
            return value
        print("Let's try again.")

email = get_confirmed_input("Enter your email: ")
```

### Creating Progress Indicators

```python
import time

# Simple progress
for i in range(1, 11):
    print(f"Progress: {i*10}%")
    time.sleep(0.1)

# Progress bar
def show_progress(current, total, bar_length=40):
    percent = current / total
    filled = int(bar_length * percent)
    bar = '█' * filled + '░' * (bar_length - filled)
    print(f"\rProgress: [{bar}] {percent*100:.1f}%", end='')

for i in range(101):
    show_progress(i, 100)
    time.sleep(0.02)
print()  # New line after completion
```

### Pretty Tables

```python
def print_table(data, headers):
    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in data:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(str(cell)))
    
    # Print header
    header_row = " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers))
    print(header_row)
    print("-" * len(header_row))
    
    # Print data
    for row in data:
        data_row = " | ".join(str(cell).ljust(widths[i]) for i, cell in enumerate(row))
        print(data_row)

# Usage
headers = ["Name", "Age", "City"]
data = [
    ["Alice", 25, "New York"],
    ["Bob", 30, "Los Angeles"],
    ["Charlie", 35, "Chicago"]
]
print_table(data, headers)
```

---

## Summary

**Key Takeaways:**
- `print()` for output with flexible formatting options
- `input()` always returns a string - convert to needed type
- f-strings are the modern way to format output
- Always validate user input with try-except
- Provide clear prompts and feedback to users
- Strip whitespace from input
- Handle edge cases and errors gracefully

**Best Practices:**
1. Use f-strings for formatting
2. Validate all user input
3. Provide clear prompts
4. Give feedback to users
5. Handle errors gracefully
6. Use meaningful variable names
7. Test edge cases

**Next Steps:**
1. Practice with the example programs
2. Complete the exercises
3. Build small interactive console applications
4. Move on to Module 14 to learn file operations

Happy Coding! 🚀
