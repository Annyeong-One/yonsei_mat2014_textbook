# Python Control Flow: if/else Statements

## Table of Contents
1. [Introduction](#introduction)
2. [The if Statement](#the-if-statement)
3. [The if-else Statement](#the-if-else-statement)
4. [The if-elif-else Statement](#the-if-elif-else-statement)
5. [Nested Conditionals](#nested-conditionals)
6. [Ternary Operator](#ternary-operator)
7. [Truthy and Falsy Values](#truthy-and-falsy-values)
8. [Common Patterns](#common-patterns)
9. [Best Practices](#best-practices)

---

## Introduction

**Control flow** determines the order in which code executes. The most fundamental control flow structure is the **conditional statement**, which allows your program to make decisions based on conditions.

### Why Control Flow Matters

Without control flow, programs would execute every line in order, making them inflexible. Control flow lets you:
- Make decisions based on user input
- Handle different scenarios
- Validate data
- Create interactive programs

---

## The if Statement

The `if` statement executes code only when a condition is `True`.

### Syntax

```python
if condition:
    # code to execute if condition is True
    # must be indented
```

### Key Points

- **Condition**: Must evaluate to `True` or `False`
- **Colon (`:`)**: Required after the condition
- **Indentation**: Code block must be indented (usually 4 spaces)

### Examples

```python
# Simple if statement
age = 18
if age >= 18:
    print("You are an adult")

# Multiple statements in if block
temperature = 35
if temperature > 30:
    print("It's hot outside!")
    print("Remember to stay hydrated")
    print("Wear sunscreen")

# Using comparison operators
score = 85
if score >= 60:
    print("You passed!")

# Using logical operators
is_weekend = True
is_sunny = True
if is_weekend and is_sunny:
    print("Perfect day for a picnic!")
```

### Common Mistake

```python
# ❌ WRONG - Missing colon
if age >= 18
    print("Adult")

# ❌ WRONG - No indentation
if age >= 18:
print("Adult")

# ✅ CORRECT
if age >= 18:
    print("Adult")
```

---

## The if-else Statement

The `if-else` statement provides an alternative path when the condition is `False`.

### Syntax

```python
if condition:
    # code if condition is True
else:
    # code if condition is False
```

### Examples

```python
# Basic if-else
age = 15
if age >= 18:
    print("You can vote")
else:
    print("You cannot vote yet")

# With calculations
number = 7
if number % 2 == 0:
    print("Even number")
else:
    print("Odd number")

# With user input
password = "secret123"
if password == "correct_password":
    print("Access granted")
else:
    print("Access denied")

# Temperature converter
celsius = 25
if celsius < 0:
    print("It's freezing!")
else:
    print("Temperature is above freezing")
```

---

## The if-elif-else Statement

Use `elif` (else if) to check multiple conditions sequentially.

### Syntax

```python
if condition1:
    # code if condition1 is True
elif condition2:
    # code if condition2 is True
elif condition3:
    # code if condition3 is True
else:
    # code if all conditions are False
```

### Key Points

- Can have **multiple elif** statements
- **Only ONE block executes** (the first true condition)
- **else is optional** but recommended for completeness
- Conditions are checked **in order** (top to bottom)

### Examples

```python
# Grade calculator
score = 85

if score >= 90:
    print("Grade: A")
elif score >= 80:
    print("Grade: B")
elif score >= 70:
    print("Grade: C")
elif score >= 60:
    print("Grade: D")
else:
    print("Grade: F")

# Time of day greeting
hour = 14

if hour < 12:
    print("Good morning!")
elif hour < 18:
    print("Good afternoon!")
else:
    print("Good evening!")

# BMI calculator
bmi = 22.5

if bmi < 18.5:
    print("Underweight")
elif bmi < 25:
    print("Normal weight")
elif bmi < 30:
    print("Overweight")
else:
    print("Obese")

# Traffic light
light = "yellow"

if light == "red":
    print("Stop")
elif light == "yellow":
    print("Caution")
elif light == "green":
    print("Go")
else:
    print("Light malfunction")
```

### Order Matters!

```python
# This works correctly
score = 85
if score >= 90:
    print("A")
elif score >= 80:
    print("B")  # This executes
elif score >= 70:
    print("C")

# This is WRONG (order matters!)
score = 85
if score >= 60:
    print("D")  # This executes first!
elif score >= 70:
    print("C")
elif score >= 80:
    print("B")  # Never reached!
```

---

## Nested Conditionals

You can place if statements inside other if statements.

### Syntax

```python
if condition1:
    if condition2:
        # code if both conditions are True
    else:
        # code if condition1 is True but condition2 is False
else:
    # code if condition1 is False
```

### Examples

```python
# Age and license check
age = 20
has_license = True

if age >= 18:
    if has_license:
        print("You can drive")
    else:
        print("You need to get a license")
else:
    print("You are too young to drive")

# Student discount system
is_student = True
age = 15

if is_student:
    if age < 18:
        print("50% student discount")
    else:
        print("20% student discount")
else:
    print("No discount")

# Login system
username = "admin"
password = "password123"

if username == "admin":
    if password == "password123":
        print("Login successful")
    else:
        print("Wrong password")
else:
    print("User not found")
```

### Best Practice: Avoid Deep Nesting

```python
# ❌ TOO NESTED (hard to read)
if condition1:
    if condition2:
        if condition3:
            if condition4:
                print("Too deep!")

# ✅ BETTER - Use 'and'
if condition1 and condition2 and condition3 and condition4:
    print("Much clearer!")

# ✅ BETTER - Early return (in functions)
def process_data(data):
    if not data:
        return "No data"
    if not data.is_valid():
        return "Invalid data"
    # Process data here
    return "Success"
```

---

## Ternary Operator

A compact way to write simple if-else statements in one line.

### Syntax

```python
value_if_true if condition else value_if_false
```

### Examples

```python
# Basic ternary
age = 20
status = "adult" if age >= 18 else "minor"
print(status)  # adult

# With calculation
number = 7
parity = "even" if number % 2 == 0 else "odd"

# Max of two numbers
a = 10
b = 20
max_value = a if a > b else b

# Absolute value
x = -5
absolute = x if x >= 0 else -x

# Temperature message
temp = 25
message = "Hot" if temp > 30 else "Cold" if temp < 10 else "Moderate"
```

### When to Use

✅ **Good for:**
- Simple assignments
- Return statements
- Short, readable conditions

❌ **Avoid for:**
- Complex logic
- Multiple statements
- Nested ternaries (hard to read)

---

## Truthy and Falsy Values

In Python, values can be evaluated as `True` or `False` in boolean contexts.

### Falsy Values (evaluate to False)

```python
False          # Boolean False
None           # None type
0              # Zero integer
0.0            # Zero float
0j             # Zero complex
''             # Empty string
""             # Empty string
[]             # Empty list
()             # Empty tuple
{}             # Empty dict
set()          # Empty set
```

### Truthy Values (evaluate to True)

```python
True           # Boolean True
Any non-zero number (1, -1, 3.14, etc.)
Any non-empty string ("hello", "0", " ")
Any non-empty container ([1], (1,), {1}, {"a": 1})
Any object (unless __bool__ is defined to return False)
```

### Examples

```python
# Empty string is falsy
name = ""
if name:
    print(f"Hello, {name}")
else:
    print("Please enter your name")  # This executes

# Empty list is falsy
items = []
if items:
    print(f"You have {len(items)} items")
else:
    print("Your cart is empty")  # This executes

# Zero is falsy
count = 0
if count:
    print(f"Count: {count}")
else:
    print("Count is zero")  # This executes

# None is falsy
result = None
if result:
    print(f"Result: {result}")
else:
    print("No result")  # This executes

# Non-empty values are truthy
message = "Hello"
if message:
    print(message)  # This executes

numbers = [1, 2, 3]
if numbers:
    print("List has items")  # This executes
```

### Be Specific When Needed

```python
# ❌ AMBIGUOUS
def get_user_age():
    return 0  # Could mean "not found" or actually zero

age = get_user_age()
if age:  # False for 0, but 0 is a valid age!
    print(f"Age: {age}")

# ✅ BETTER
def get_user_age():
    return None  # Explicitly means "not found"

age = get_user_age()
if age is not None:
    print(f"Age: {age}")
```

---

## Common Patterns

### Pattern 1: Membership Testing

```python
# Check if value is in a list
fruits = ["apple", "banana", "orange"]
fruit = "apple"

if fruit in fruits:
    print(f"{fruit} is available")

# Check if key exists in dictionary
person = {"name": "Alice", "age": 30}

if "email" in person:
    print(person["email"])
else:
    print("Email not provided")
```

### Pattern 2: Range Checking

```python
# Check if number is in range
age = 25

if 18 <= age <= 65:
    print("Working age")

# Temperature ranges
temp = 22

if 20 <= temp <= 25:
    print("Comfortable temperature")
```

### Pattern 3: Multiple Conditions

```python
# Check multiple values
status = "active"

if status in ["active", "pending", "processing"]:
    print("Order is being processed")

# Any condition true
has_permission = False
is_admin = True
is_owner = False

if has_permission or is_admin or is_owner:
    print("Access granted")
```

### Pattern 4: Guard Clauses

```python
# Early exit pattern
def process_order(order):
    # Guard clauses
    if not order:
        return "No order"
    
    if order.total < 0:
        return "Invalid amount"
    
    if not order.items:
        return "Empty order"
    
    # Main logic here (not nested!)
    return "Order processed"
```

### Pattern 5: Default Values

```python
# Provide default if value is None
username = None
display_name = username if username else "Guest"

# Or using 'or' operator
display_name = username or "Guest"

# For dictionaries
config = {"host": "localhost"}
port = config.get("port") or 8080
```

---

## Best Practices

### 1. Use Meaningful Conditions

```python
# ❌ BAD
if x:
    do_something()

# ✅ GOOD
if is_valid_user(x):
    do_something()

if user_has_permission:
    do_something()
```

### 2. Keep Conditions Simple

```python
# ❌ COMPLEX
if (age >= 18 and age <= 65) and (income > 30000) and (credit_score >= 650) and not has_bankruptcy:
    approve_loan()

# ✅ CLEARER
is_eligible_age = 18 <= age <= 65
has_sufficient_income = income > 30000
has_good_credit = credit_score >= 650
has_clean_record = not has_bankruptcy

if is_eligible_age and has_sufficient_income and has_good_credit and has_clean_record:
    approve_loan()
```

### 3. Avoid Unnecessary else

```python
# ❌ UNNECESSARY
def is_adult(age):
    if age >= 18:
        return True
    else:
        return False

# ✅ BETTER
def is_adult(age):
    return age >= 18
```

### 4. Use elif for Mutually Exclusive Conditions

```python
# ❌ INEFFICIENT
if score >= 90:
    grade = "A"
if score >= 80 and score < 90:
    grade = "B"
if score >= 70 and score < 80:
    grade = "C"

# ✅ BETTER
if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
```

### 5. Consider Using Dictionaries for Multiple Conditions

```python
# ❌ LONG IF-ELIF CHAIN
if day == "Monday":
    message = "Start of work week"
elif day == "Tuesday":
    message = "Second day"
elif day == "Wednesday":
    message = "Midweek"
# ... etc

# ✅ BETTER
messages = {
    "Monday": "Start of work week",
    "Tuesday": "Second day",
    "Wednesday": "Midweek",
    "Thursday": "Almost Friday",
    "Friday": "TGIF!",
    "Saturday": "Weekend!",
    "Sunday": "Relax"
}
message = messages.get(day, "Invalid day")
```

### 6. Be Careful with Floating Point Comparisons

```python
# ❌ RISKY
if 0.1 + 0.2 == 0.3:  # Might be False!
    print("Equal")

# ✅ BETTER
import math
if math.isclose(0.1 + 0.2, 0.3):
    print("Equal")

# Or with tolerance
if abs((0.1 + 0.2) - 0.3) < 0.0001:
    print("Equal")
```

---

## Common Mistakes

### Mistake 1: Using = Instead of ==

```python
# ❌ WRONG (assignment, not comparison)
if x = 10:  # SyntaxError
    print("Ten")

# ✅ CORRECT
if x == 10:
    print("Ten")
```

### Mistake 2: Forgetting Colon

```python
# ❌ WRONG
if age >= 18
    print("Adult")

# ✅ CORRECT
if age >= 18:
    print("Adult")
```

### Mistake 3: Missing Indentation

```python
# ❌ WRONG
if age >= 18:
print("Adult")  # IndentationError

# ✅ CORRECT
if age >= 18:
    print("Adult")
```

### Mistake 4: Comparing with None Using ==

```python
# ❌ NOT RECOMMENDED
if value == None:
    do_something()

# ✅ CORRECT
if value is None:
    do_something()
```

---

## Summary

### Key Takeaways

1. **if** - Execute code when condition is True
2. **if-else** - Choose between two paths
3. **if-elif-else** - Choose from multiple paths
4. **Indentation matters** - Defines code blocks
5. **Conditions must be boolean** - Or evaluate to True/False
6. **Order matters** - First true condition executes
7. **Ternary operator** - One-line if-else for simple cases
8. **Truthy/Falsy** - Many values can be used as conditions

### Control Flow Decision Tree

```
Start
  ↓
Do I need to make a decision?
  ├─ No → No if statement needed
  └─ Yes → Do I have 2 options?
      ├─ Yes → Use if-else
      └─ No → Do I have 3+ options?
          ├─ Yes → Use if-elif-else
          └─ No → Do I need to check multiple independent conditions?
              ├─ Yes → Use multiple if statements
              └─ No → Do I need to check conditions within conditions?
                  └─ Yes → Use nested if or combine with 'and'/'or'
```

---

## Next Steps

Now that you understand conditional statements, you're ready to learn about:
- **Loops** - Repeat code multiple times
- **Functions** - Organize code into reusable blocks
- **Exception handling** - Handle errors gracefully

Practice makes perfect! Work through the exercises to solidify your understanding.
