"""
Python Control Flow - Practice Exercises
Test your understanding of if/else statements!
"""

print("Exercise 1: Simple if Statement")
print("-" * 60)
print("Task:")
print("- Create a variable: age = 20")
print("- If age is greater than or equal to 18, print 'You are an adult'")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 2: if-else Statement")
print("-" * 60)
print("Task:")
print("- Create a variable: number = 15")
print("- If number is even, print 'Even'")
print("- Otherwise, print 'Odd'")
print("- Hint: Use % (modulus) operator")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 3: Grade Calculator")
print("-" * 60)
print("Task:")
print("- Create a variable: score = 75")
print("- Assign grade based on score:")
print("  90-100: A")
print("  80-89: B")
print("  70-79: C")
print("  60-69: D")
print("  Below 60: F")
print("- Print the grade")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 4: Positive, Negative, or Zero")
print("-" * 60)
print("Task:")
print("- Create a variable: num = -5")
print("- Check if it's positive, negative, or zero")
print("- Print appropriate message")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 5: Leap Year Checker")
print("-" * 60)
print("Task:")
print("- Create a variable: year = 2024")
print("- A leap year is:")
print("  - Divisible by 4 AND")
print("  - Not divisible by 100 OR divisible by 400")
print("- Print 'Leap year' or 'Not a leap year'")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 6: Nested Conditions - Login System")
print("-" * 60)
print("Task:")
print("- username = 'admin', password = 'pass123'")
print("- Check if username is 'admin'")
print("  - If yes, check if password is 'pass123'")
print("    - If yes, print 'Login successful'")
print("    - If no, print 'Wrong password'")
print("  - If username wrong, print 'User not found'")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 7: Multiple Conditions with 'and'")
print("-" * 60)
print("Task:")
print("- age = 25, has_license = True, has_insurance = True")
print("- Can drive if all three conditions are met:")
print("  - age >= 18")
print("  - has_license is True")
print("  - has_insurance is True")
print("- Print 'Can drive' or 'Cannot drive'")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 8: Membership Testing")
print("-" * 60)
print("Task:")
print("- fruits = ['apple', 'banana', 'orange']")
print("- fruit = 'banana'")
print("- Check if fruit is in the list")
print("- Print appropriate message")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 9: Ternary Operator")
print("-" * 60)
print("Task:")
print("- age = 16")
print("- Use ternary operator to assign:")
print("  - 'adult' if age >= 18")
print("  - 'minor' otherwise")
print("- Print the result")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 10: Temperature Converter Decision")
print("-" * 60)
print("Task:")
print("- celsius = 100")
print("- If celsius >= 100, print 'Water boils'")
print("- If celsius <= 0, print 'Water freezes'")
print("- Otherwise, print 'Water is liquid'")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 11: Range Checking")
print("-" * 60)
print("Task:")
print("- score = 88")
print("- Check if score is between 80 and 90 (inclusive)")
print("- Print 'In range' or 'Out of range'")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 12: Triangle Type Classifier")
print("-" * 60)
print("Task:")
print("- side1 = 5, side2 = 5, side3 = 8")
print("- Classify triangle:")
print("  - All sides equal: Equilateral")
print("  - Two sides equal: Isosceles")
print("  - No sides equal: Scalene")
print("- Print the triangle type")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 13: Discount Calculator")
print("-" * 60)
print("Task:")
print("- price = 100, is_member = True")
print("- If member: 20% discount")
print("- If not member: No discount")
print("- Calculate and print final price")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 14: Largest of Three Numbers")
print("-" * 60)
print("Task:")
print("- a = 15, b = 22, c = 18")
print("- Find and print the largest number")
print("- Use if-elif-else statements")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 15: Voting Eligibility")
print("-" * 60)
print("Task:")
print("- age = 17, is_citizen = True")
print("- Can vote if:")
print("  - age >= 18 AND is_citizen is True")
print("- Print eligibility status with reason")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 16: Season Detector")
print("-" * 60)
print("Task:")
print("- month = 7 (1-12)")
print("- Determine season:")
print("  - 12, 1, 2: Winter")
print("  - 3, 4, 5: Spring")
print("  - 6, 7, 8: Summer")
print("  - 9, 10, 11: Fall")
print("- Print the season")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 17: Shipping Cost")
print("-" * 60)
print("Task:")
print("- weight = 3.5 (kg)")
print("- Calculate shipping cost:")
print("  - 0-1 kg: $5")
print("  - 1-5 kg: $10")
print("  - 5-10 kg: $15")
print("  - Over 10 kg: $20")
print("- Print the cost")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 18: Password Validator")
print("-" * 60)
print("Task:")
print("- password = 'Test123'")
print("- Valid if:")
print("  - Length >= 8")
print("  - Contains at least one uppercase letter")
print("  - Contains at least one digit")
print("- Print 'Valid' or 'Invalid' with reasons")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 19: BMI Calculator with Categories")
print("-" * 60)
print("Task:")
print("- weight = 70 (kg), height = 1.75 (m)")
print("- Calculate BMI = weight / (height ** 2)")
print("- Categorize:")
print("  - < 18.5: Underweight")
print("  - 18.5-24.9: Normal")
print("  - 25-29.9: Overweight")
print("  - >= 30: Obese")
print("- Print BMI and category")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")

print("Exercise 20: Comprehensive Loan Approval")
print("-" * 60)
print("Task:")
print("- age = 30, income = 50000, credit_score = 720, has_debt = False")
print("- Approve loan if ALL conditions are met:")
print("  - age between 21 and 65 (inclusive)")
print("  - income >= 40000")
print("  - credit_score >= 650")
print("  - has_debt is False")
print("- Print approval status with detailed feedback")
print()
# Write your code below:




print("\n" + "=" * 60 + "\n")
print("Exercises completed! Check solutions.py for answers.")
