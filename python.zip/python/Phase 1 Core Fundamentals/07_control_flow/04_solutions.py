"""
Python Control Flow - Exercise Solutions
Compare your solutions and learn from explanations!
"""

print("=" * 60)
print("Exercise 1 Solution: Simple if Statement")
print("=" * 60)

age = 20
if age >= 18:
    print("You are an adult")

print("\nExplanation:")
print("• Simple if statement checks one condition")
print("• Code block executes only if condition is True")
print()

print("=" * 60)
print("Exercise 2 Solution: if-else Statement")
print("=" * 60)

number = 15
if number % 2 == 0:
    print("Even")
else:
    print("Odd")

print("\nExplanation:")
print("• % (modulus) returns remainder of division")
print("• Even numbers have remainder 0 when divided by 2")
print("• Odd numbers have remainder 1")
print()

print("=" * 60)
print("Exercise 3 Solution: Grade Calculator")
print("=" * 60)

score = 75

if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
elif score >= 60:
    grade = "D"
else:
    grade = "F"

print(f"Score: {score}")
print(f"Grade: {grade}")

print("\nExplanation:")
print("• Use elif for multiple mutually exclusive conditions")
print("• Order matters - check from highest to lowest")
print("• First true condition executes, rest are skipped")
print()

print("=" * 60)
print("Exercise 4 Solution: Positive, Negative, or Zero")
print("=" * 60)

num = -5

if num > 0:
    print(f"{num} is positive")
elif num < 0:
    print(f"{num} is negative")
else:
    print(f"{num} is zero")

print("\nExplanation:")
print("• Three mutually exclusive conditions")
print("• If not positive and not negative, must be zero")
print()

print("=" * 60)
print("Exercise 5 Solution: Leap Year Checker")
print("=" * 60)

year = 2024

# Method 1: Step by step
if year % 4 == 0:
    if year % 100 == 0:
        if year % 400 == 0:
            print(f"{year} is a leap year")
        else:
            print(f"{year} is not a leap year")
    else:
        print(f"{year} is a leap year")
else:
    print(f"{year} is not a leap year")

# Method 2: Combined conditions (cleaner)
if (year % 4 == 0 and year % 100 != 0) or (year % 400 == 0):
    print(f"{year} is a leap year (Method 2)")
else:
    print(f"{year} is not a leap year (Method 2)")

print("\nExplanation:")
print("• Leap year rules:")
print("  1. Divisible by 4")
print("  2. If divisible by 100, must also be divisible by 400")
print("• Can use nested ifs or combine with logical operators")
print()

print("=" * 60)
print("Exercise 6 Solution: Nested Conditions - Login System")
print("=" * 60)

username = "admin"
password = "pass123"

if username == "admin":
    if password == "pass123":
        print("Login successful")
    else:
        print("Wrong password")
else:
    print("User not found")

print("\nExplanation:")
print("• Nested if checks second condition only if first is True")
print("• This creates a two-level decision tree")
print()

print("=" * 60)
print("Exercise 7 Solution: Multiple Conditions with 'and'")
print("=" * 60)

age = 25
has_license = True
has_insurance = True

if age >= 18 and has_license and has_insurance:
    print("Can drive")
else:
    print("Cannot drive")

print("\nExplanation:")
print("• 'and' requires ALL conditions to be True")
print("• If any condition is False, entire expression is False")
print()

print("=" * 60)
print("Exercise 8 Solution: Membership Testing")
print("=" * 60)

fruits = ['apple', 'banana', 'orange']
fruit = 'banana'

if fruit in fruits:
    print(f"{fruit} is in the list")
else:
    print(f"{fruit} is not in the list")

print("\nExplanation:")
print("• 'in' operator checks if item exists in collection")
print("• Works with lists, tuples, strings, sets, dicts")
print()

print("=" * 60)
print("Exercise 9 Solution: Ternary Operator")
print("=" * 60)

age = 16
status = "adult" if age >= 18 else "minor"
print(f"Status: {status}")

print("\nExplanation:")
print("• Ternary syntax: value_if_true if condition else value_if_false")
print("• Compact one-line alternative to if-else")
print("• Best for simple assignments")
print()

print("=" * 60)
print("Exercise 10 Solution: Temperature Converter Decision")
print("=" * 60)

celsius = 100

if celsius >= 100:
    print("Water boils")
elif celsius <= 0:
    print("Water freezes")
else:
    print("Water is liquid")

print("\nExplanation:")
print("• Multiple independent conditions")
print("• First match wins (order matters)")
print()

print("=" * 60)
print("Exercise 11 Solution: Range Checking")
print("=" * 60)

score = 88

if 80 <= score <= 90:
    print("In range")
else:
    print("Out of range")

print("\nExplanation:")
print("• Python allows chained comparisons: 80 <= score <= 90")
print("• Equivalent to: score >= 80 and score <= 90")
print("• More readable and Pythonic")
print()

print("=" * 60)
print("Exercise 12 Solution: Triangle Type Classifier")
print("=" * 60)

side1 = 5
side2 = 5
side3 = 8

if side1 == side2 == side3:
    triangle_type = "Equilateral"
elif side1 == side2 or side2 == side3 or side1 == side3:
    triangle_type = "Isosceles"
else:
    triangle_type = "Scalene"

print(f"Triangle type: {triangle_type}")

print("\nExplanation:")
print("• Check most specific condition first (all equal)")
print("• Then check if any two are equal")
print("• Default to scalene if no sides match")
print()

print("=" * 60)
print("Exercise 13 Solution: Discount Calculator")
print("=" * 60)

price = 100
is_member = True

if is_member:
    discount = 0.20  # 20%
    final_price = price * (1 - discount)
    print(f"Member discount: {discount * 100}%")
else:
    final_price = price
    print("No discount")

print(f"Original price: ${price}")
print(f"Final price: ${final_price}")

print("\nExplanation:")
print("• Calculate discount percentage based on membership")
print("• Apply discount to original price")
print("• Can use multiplication for percentage discount")
print()

print("=" * 60)
print("Exercise 14 Solution: Largest of Three Numbers")
print("=" * 60)

a = 15
b = 22
c = 18

if a >= b and a >= c:
    largest = a
elif b >= a and b >= c:
    largest = b
else:
    largest = c

print(f"Numbers: {a}, {b}, {c}")
print(f"Largest: {largest}")

# Alternative using max() function
largest_alt = max(a, b, c)
print(f"Largest (using max): {largest_alt}")

print("\nExplanation:")
print("• Compare each number with the other two")
print("• Or use Python's built-in max() function")
print()

print("=" * 60)
print("Exercise 15 Solution: Voting Eligibility")
print("=" * 60)

age = 17
is_citizen = True

can_vote = age >= 18 and is_citizen

if can_vote:
    print("✓ You are eligible to vote")
else:
    print("✗ You are not eligible to vote")
    if age < 18:
        print("  Reason: Must be at least 18 years old")
    if not is_citizen:
        print("  Reason: Must be a citizen")

print("\nExplanation:")
print("• Check multiple requirements with 'and'")
print("• Provide specific feedback for failed conditions")
print()

print("=" * 60)
print("Exercise 16 Solution: Season Detector")
print("=" * 60)

month = 7

if month in [12, 1, 2]:
    season = "Winter"
elif month in [3, 4, 5]:
    season = "Spring"
elif month in [6, 7, 8]:
    season = "Summer"
elif month in [9, 10, 11]:
    season = "Fall"
else:
    season = "Invalid month"

print(f"Month {month}: {season}")

print("\nExplanation:")
print("• Use 'in' with list to check multiple values")
print("• Cleaner than multiple 'or' conditions")
print()

print("=" * 60)
print("Exercise 17 Solution: Shipping Cost")
print("=" * 60)

weight = 3.5

if weight <= 1:
    cost = 5
elif weight <= 5:
    cost = 10
elif weight <= 10:
    cost = 15
else:
    cost = 20

print(f"Weight: {weight} kg")
print(f"Shipping cost: ${cost}")

print("\nExplanation:")
print("• Use elif for range-based pricing")
print("• Order from smallest to largest range")
print("• First matching condition determines the price")
print()

print("=" * 60)
print("Exercise 18 Solution: Password Validator")
print("=" * 60)

password = "Test123"

has_length = len(password) >= 8
has_upper = any(c.isupper() for c in password)
has_digit = any(c.isdigit() for c in password)

is_valid = has_length and has_upper and has_digit

print(f"Password: {'*' * len(password)}")
print(f"Length >= 8: {has_length}")
print(f"Has uppercase: {has_upper}")
print(f"Has digit: {has_digit}")

if is_valid:
    print("✓ Password is valid")
else:
    print("✗ Password is invalid")
    if not has_length:
        print("  - Must be at least 8 characters")
    if not has_upper:
        print("  - Must contain uppercase letter")
    if not has_digit:
        print("  - Must contain digit")

print("\nExplanation:")
print("• Break down complex validation into simple checks")
print("• Combine checks with 'and'")
print("• Provide specific feedback for each failed requirement")
print()

print("=" * 60)
print("Exercise 19 Solution: BMI Calculator with Categories")
print("=" * 60)

weight = 70
height = 1.75

bmi = weight / (height ** 2)

print(f"Weight: {weight} kg")
print(f"Height: {height} m")
print(f"BMI: {bmi:.2f}")

if bmi < 18.5:
    category = "Underweight"
elif bmi < 25:
    category = "Normal"
elif bmi < 30:
    category = "Overweight"
else:
    category = "Obese"

print(f"Category: {category}")

print("\nExplanation:")
print("• Calculate BMI first")
print("• Use elif chain for range-based categorization")
print("• Format BMI to 2 decimal places for display")
print()

print("=" * 60)
print("Exercise 20 Solution: Comprehensive Loan Approval")
print("=" * 60)

age = 30
income = 50000
credit_score = 720
has_debt = False

print("Loan Application:")
print(f"  Age: {age}")
print(f"  Income: ${income}")
print(f"  Credit Score: {credit_score}")
print(f"  Has Debt: {has_debt}")
print()

# Check each condition
age_ok = 21 <= age <= 65
income_ok = income >= 40000
credit_ok = credit_score >= 650
debt_ok = not has_debt

print("Requirement Checks:")
print(f"  Age (21-65): {'✓' if age_ok else '✗'}")
print(f"  Income (>= $40,000): {'✓' if income_ok else '✗'}")
print(f"  Credit Score (>= 650): {'✓' if credit_ok else '✗'}")
print(f"  No Debt: {'✓' if debt_ok else '✗'}")
print()

# Overall approval
approved = age_ok and income_ok and credit_ok and debt_ok

if approved:
    print("🎉 LOAN APPROVED")
else:
    print("❌ LOAN DENIED")
    print("\nReasons:")
    if not age_ok:
        print("  - Age must be between 21 and 65")
    if not income_ok:
        print("  - Income must be at least $40,000")
    if not credit_ok:
        print("  - Credit score must be at least 650")
    if not debt_ok:
        print("  - Must not have existing debt")

print("\nExplanation:")
print("• Break complex decision into individual checks")
print("• Store each condition in a descriptive variable")
print("• Combine all conditions for final decision")
print("• Provide detailed feedback for each requirement")
print("• Makes code readable and maintainable")
print()

print("=" * 60)
print("All solutions completed!")
print("=" * 60)
print()
print("Key Takeaways:")
print("✓ if: Execute code when condition is True")
print("✓ if-else: Choose between two paths")
print("✓ if-elif-else: Choose from multiple paths")
print("✓ and: All conditions must be True")
print("✓ or: At least one condition must be True")
print("✓ not: Reverses boolean value")
print("✓ in: Check membership in collections")
print("✓ Indentation defines code blocks")
print("✓ Order matters in elif chains")
print("✓ Break complex conditions into simple variables")
