# Python Control Flow: if/else Statements

## 📚 Contents

This module teaches you how to make decisions in Python code:

1. **01_tutorial.md** - Complete guide to conditional statements
2. **02_examples.py** - 20 practical demonstrations
3. **03_exercises.py** - 20 hands-on exercises
4. **04_solutions.py** - Detailed solutions with explanations

## 🎯 Learning Objectives

After completing this module, you will be able to:

- ✅ Use `if` statements to execute code conditionally
- ✅ Implement `if-else` for binary decisions
- ✅ Write `if-elif-else` chains for multiple conditions
- ✅ Create nested conditionals
- ✅ Apply logical operators (`and`, `or`, `not`)
- ✅ Use the ternary operator for one-liners
- ✅ Understand truthy and falsy values
- ✅ Write clean, readable conditional code

## 🚀 How to Use This Module

### Step 1: Read the Tutorial
Start with `01_tutorial.md` covering:
- Basic if statement syntax
- if-else and if-elif-else
- Nested conditionals
- Logical operators
- Ternary operator
- Best practices

### Step 2: Run the Examples
Execute `02_examples.py`:
```bash
python 02_examples.py
```

### Step 3: Practice
Solve all exercises in `03_exercises.py`

### Step 4: Review
Check your solutions against `04_solutions.py`

## 💡 Key Concepts

### Basic Syntax

```python
# if statement
if condition:
    # code to execute

# if-else
if condition:
    # code if True
else:
    # code if False

# if-elif-else
if condition1:
    # code for condition1
elif condition2:
    # code for condition2
else:
    # code if all False
```

### Logical Operators

```python
and  # All conditions must be True
or   # At least one must be True
not  # Reverses boolean value
```

### Comparison Operators

```python
==   # Equal to
!=   # Not equal to
>    # Greater than
<    # Less than
>=   # Greater than or equal to
<=   # Less than or equal to
```

## ⏱️ Estimated Time

- Tutorial reading: 30-40 minutes
- Examples: 15 minutes
- Exercises: 60-90 minutes
- **Total: ~2-2.5 hours**

## 📝 Prerequisites

- Understanding of variables
- Basic data types (int, float, str, bool)
- Comparison and logical operators

## 🎓 Real-World Applications

Control flow is everywhere:
- **Login systems**: Check username and password
- **E-commerce**: Calculate discounts based on membership
- **Games**: Different outcomes based on player choices
- **Validation**: Check if user input is valid
- **Grading**: Assign grades based on scores

## 💡 Quick Examples

### Example 1: Age Check
```python
age = 20
if age >= 18:
    print("Adult")
else:
    print("Minor")
```

### Example 2: Grade Calculator
```python
score = 85
if score >= 90:
    grade = "A"
elif score >= 80:
    grade = "B"
elif score >= 70:
    grade = "C"
else:
    grade = "F"
```

### Example 3: Multiple Conditions
```python
age = 25
has_license = True

if age >= 18 and has_license:
    print("Can drive")
else:
    print("Cannot drive")
```

## 📊 Topics Covered

### Fundamentals
- if statement basics
- Indentation rules
- Colon syntax
- Code blocks

### Decision Making
- if-else statements
- if-elif-else chains
- Nested conditionals
- Order of evaluation

### Advanced Concepts
- Ternary operator
- Truthy and falsy values
- Short-circuit evaluation
- Guard clauses pattern

### Best Practices
- Avoiding deep nesting
- Using meaningful conditions
- Breaking complex logic into variables
- Early returns

## ⚠️ Common Mistakes to Avoid

1. **Using `=` instead of `==`**
   ```python
   # ❌ Wrong
   if x = 10:
   
   # ✅ Correct
   if x == 10:
   ```

2. **Forgetting the colon**
   ```python
   # ❌ Wrong
   if age >= 18
   
   # ✅ Correct
   if age >= 18:
   ```

3. **Incorrect indentation**
   ```python
   # ❌ Wrong
   if age >= 18:
   print("Adult")
   
   # ✅ Correct
   if age >= 18:
       print("Adult")
   ```

4. **Wrong order in elif chains**
   ```python
   # ❌ Wrong (will never reach 80+)
   if score >= 60:
       grade = "D"
   elif score >= 80:
       grade = "B"
   
   # ✅ Correct (highest first)
   if score >= 80:
       grade = "B"
   elif score >= 60:
       grade = "D"
   ```

## 🎯 Practice Tips

1. **Start simple**: Master basic if-else before complex chains
2. **Draw flowcharts**: Visualize decision logic
3. **Test edge cases**: Check boundary conditions
4. **Use descriptive names**: Make conditions readable
5. **Avoid deep nesting**: Keep conditionals flat when possible

## 🔗 What's Next?

After mastering control flow:
- **Loops** - Repeat code multiple times
- **Functions** - Organize code into reusable blocks
- **Data structures** - Work with complex data

## 📈 Progressive Learning Path

```
Variables → Data Types → Operators → Control Flow → Loops → Functions
                                         ↑ YOU ARE HERE
```

## 🎁 Bonus Tips

### Pythonic Patterns

```python
# Check for None
if value is None:  # ✅
if value == None:  # ❌

# Range checking
if 10 <= x <= 20:  # ✅ Pythonic
if x >= 10 and x <= 20:  # ✅ Works but verbose

# Membership testing
if color in ['red', 'green', 'blue']:  # ✅
if color == 'red' or color == 'green' or color == 'blue':  # ❌

# Ternary operator
result = "yes" if condition else "no"  # ✅
```

## 💬 Did You Know?

- Python uses indentation (not braces) for code blocks
- You can chain comparisons: `10 < x < 20`
- Empty collections evaluate to `False`
- `elif` is short for "else if"
- The ternary operator can be nested (but avoid it!)

## 🏆 Challenge Yourself

After completing exercises, try:
1. Build a simple calculator with menu options
2. Create a grade calculator that handles extra credit
3. Make a password strength checker
4. Design a simple game with branching storylines
5. Build a tax calculator with different brackets

---

**Ready to make your programs think?**

Start with the tutorial and work through the examples. Control flow is fundamental to every program you'll ever write!

Happy Coding! 🐍
