# Python Loops: for and while

## Table of Contents
1. [Introduction](#introduction)
2. [The for Loop](#the-for-loop)
3. [The while Loop](#the-while-loop)
4. [Loop Control: break and continue](#loop-control-break-and-continue)
5. [The range() Function](#the-range-function)
6. [Iterating Over Collections](#iterating-over-collections)
7. [Nested Loops](#nested-loops)
8. [Loop with else Clause](#loop-with-else-clause)
9. [Common Loop Patterns](#common-loop-patterns)
10. [Best Practices](#best-practices)

---

## Introduction

**Loops** allow you to execute code repeatedly. Instead of writing the same code multiple times, you use a loop to repeat actions automatically.

### Why Loops Matter

Loops are essential for:
- Processing collections of data
- Repeating tasks a specific number of times
- Continuing until a condition is met
- Reducing code duplication
- Automating repetitive tasks

### Two Types of Loops in Python

1. **for loop** - Iterate over a sequence (definite iteration)
2. **while loop** - Repeat while a condition is True (indefinite iteration)

---

## The for Loop

The `for` loop iterates over a sequence of elements.

### Syntax

```python
for variable in sequence:
    # code to execute for each element
    # variable holds current element
```

### Basic Examples

```python
# Loop through a list
fruits = ["apple", "banana", "orange"]
for fruit in fruits:
    print(fruit)

# Loop through a string
for letter in "Python":
    print(letter)

# Loop through a range of numbers
for i in range(5):
    print(i)  # 0, 1, 2, 3, 4
```

### Key Concepts

- **Iteration variable**: Temporary variable holding current element
- **Sequence**: List, tuple, string, range, etc.
- **Indentation**: Loop body must be indented
- **Automatic progression**: Moves to next element automatically

### More Examples

```python
# Print numbers 1 to 5
for num in range(1, 6):
    print(num)

# Sum of numbers
total = 0
for num in [1, 2, 3, 4, 5]:
    total += num
print(f"Total: {total}")

# Process each character
word = "hello"
for char in word:
    print(f"Letter: {char}")

# Enumerate for index and value
fruits = ["apple", "banana", "orange"]
for index, fruit in enumerate(fruits):
    print(f"{index}: {fruit}")
```

---

## The while Loop

The `while` loop repeats as long as a condition is `True`.

### Syntax

```python
while condition:
    # code to execute while condition is True
    # must eventually make condition False!
```

### Basic Examples

```python
# Count from 1 to 5
count = 1
while count <= 5:
    print(count)
    count += 1  # CRITICAL: Update the variable!

# Keep asking until valid input
password = ""
while password != "secret":
    password = input("Enter password: ")
print("Access granted")

# Sum until target reached
total = 0
num = 1
while total < 20:
    total += num
    num += 1
print(f"Total: {total}")
```

### ⚠️ Infinite Loops Warning

```python
# ❌ INFINITE LOOP - Never do this!
while True:
    print("This will run forever!")

# ❌ INFINITE LOOP - Forgot to update
count = 1
while count <= 5:
    print(count)
    # Missing: count += 1

# ✅ CORRECT - Condition eventually becomes False
count = 1
while count <= 5:
    print(count)
    count += 1
```

### When to Use while vs for

**Use `for` when:**
- You know how many iterations you need
- You're iterating over a collection
- You have a definite sequence

**Use `while` when:**
- You don't know how many iterations needed
- You're waiting for a condition to change
- You need indefinite iteration

---

## Loop Control: break and continue

### The break Statement

Exits the loop immediately, regardless of the loop condition.

```python
# Break syntax
for item in sequence:
    if condition:
        break  # Exit loop immediately
    # This code is skipped after break

# Find first even number
numbers = [1, 3, 5, 6, 7, 8]
for num in numbers:
    if num % 2 == 0:
        print(f"First even number: {num}")
        break  # Stop searching

# Search with while
count = 1
while True:
    if count == 5:
        break
    print(count)
    count += 1
```

### The continue Statement

Skips rest of current iteration and moves to next one.

```python
# Continue syntax
for item in sequence:
    if condition:
        continue  # Skip to next iteration
    # This code is skipped if continue executed

# Skip odd numbers
for num in range(10):
    if num % 2 != 0:
        continue  # Skip odd numbers
    print(num)  # Only prints even numbers

# Process only positive numbers
numbers = [5, -2, 8, -7, 3, -1, 9]
for num in numbers:
    if num < 0:
        continue  # Skip negative numbers
    print(f"Processing: {num}")
```

### break vs continue

```python
# Comparing break and continue
print("With break:")
for i in range(5):
    if i == 3:
        break  # Stops loop at 3
    print(i)  # Prints: 0, 1, 2

print("\nWith continue:")
for i in range(5):
    if i == 3:
        continue  # Skips 3, continues with 4
    print(i)  # Prints: 0, 1, 2, 4
```

---

## The range() Function

`range()` generates a sequence of numbers, commonly used with `for` loops.

### Syntax

```python
range(stop)              # 0 to stop-1
range(start, stop)       # start to stop-1
range(start, stop, step) # start to stop-1, increment by step
```

### Examples

```python
# range(stop) - starts at 0
for i in range(5):
    print(i)  # 0, 1, 2, 3, 4

# range(start, stop)
for i in range(2, 7):
    print(i)  # 2, 3, 4, 5, 6

# range(start, stop, step)
for i in range(0, 10, 2):
    print(i)  # 0, 2, 4, 6, 8

# Negative step (counting down)
for i in range(10, 0, -1):
    print(i)  # 10, 9, 8, ..., 1

# Even numbers from 0 to 10
for i in range(0, 11, 2):
    print(i)  # 0, 2, 4, 6, 8, 10
```

### range() Returns a Range Object

```python
# range() is memory efficient
numbers = range(1000000)  # Doesn't create list!
print(type(numbers))  # <class 'range'>

# Convert to list if needed
numbers_list = list(range(10))
print(numbers_list)  # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
```

---

## Iterating Over Collections

### Lists

```python
fruits = ["apple", "banana", "orange"]

# Method 1: Direct iteration
for fruit in fruits:
    print(fruit)

# Method 2: Index-based
for i in range(len(fruits)):
    print(f"{i}: {fruits[i]}")

# Method 3: enumerate() - RECOMMENDED
for index, fruit in enumerate(fruits):
    print(f"{index}: {fruit}")

# Method 4: Start enumerate at 1
for index, fruit in enumerate(fruits, start=1):
    print(f"{index}: {fruit}")
```

### Dictionaries

```python
person = {"name": "Alice", "age": 30, "city": "NYC"}

# Iterate over keys (default)
for key in person:
    print(key)

# Iterate over values
for value in person.values():
    print(value)

# Iterate over key-value pairs
for key, value in person.items():
    print(f"{key}: {value}")
```

### Strings

```python
word = "Python"

# Each character
for char in word:
    print(char)

# With index
for index, char in enumerate(word):
    print(f"{index}: {char}")
```

### Tuples and Sets

```python
# Tuple
coordinates = (10, 20, 30)
for coord in coordinates:
    print(coord)

# Set
unique_numbers = {1, 2, 3, 4, 5}
for num in unique_numbers:
    print(num)
```

---

## Nested Loops

Loops inside other loops - useful for multi-dimensional data.

### Syntax

```python
for outer in outer_sequence:
    for inner in inner_sequence:
        # code using both outer and inner
```

### Examples

```python
# Multiplication table
for i in range(1, 4):
    for j in range(1, 4):
        print(f"{i} × {j} = {i * j}")
    print()  # Blank line after each row

# Matrix (2D list)
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

for row in matrix:
    for element in row:
        print(element, end=" ")
    print()  # New line after each row

# All combinations
colors = ["red", "blue"]
sizes = ["S", "M", "L"]

for color in colors:
    for size in sizes:
        print(f"{color}-{size}")
```

### Nested Loop Performance

```python
# ⚠️ Be careful - nested loops can be slow!
# O(n²) complexity
for i in range(1000):
    for j in range(1000):
        pass  # This runs 1,000,000 times!
```

---

## Loop with else Clause

Python's unique feature: `else` clause after loops.

### How it Works

- **`else` executes** when loop completes normally
- **`else` doesn't execute** if loop exits via `break`

### Examples

```python
# Search with for-else
numbers = [1, 3, 5, 7, 9]
search = 4

for num in numbers:
    if num == search:
        print(f"Found {search}")
        break
else:
    print(f"{search} not found")  # This executes

# Search with while-else
count = 0
while count < 5:
    if count == 10:
        print("Found 10")
        break
    count += 1
else:
    print("10 not found")  # This executes
```

### Practical Use: Prime Number Check

```python
def is_prime(n):
    if n < 2:
        return False
    
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False  # Found divisor, not prime
    else:
        return True  # No divisor found, is prime

print(is_prime(17))  # True
print(is_prime(15))  # False
```

---

## Common Loop Patterns

### Pattern 1: Accumulator

```python
# Sum of numbers
total = 0
for num in [1, 2, 3, 4, 5]:
    total += num
print(total)  # 15

# Product of numbers
product = 1
for num in [2, 3, 4]:
    product *= num
print(product)  # 24
```

### Pattern 2: Counter

```python
# Count even numbers
count = 0
for num in range(20):
    if num % 2 == 0:
        count += 1
print(f"Even numbers: {count}")
```

### Pattern 3: Finding Maximum/Minimum

```python
numbers = [3, 7, 2, 9, 1, 5]

# Find maximum
max_num = numbers[0]
for num in numbers:
    if num > max_num:
        max_num = num
print(f"Max: {max_num}")

# Or use built-in
print(f"Max: {max(numbers)}")
```

### Pattern 4: Filtering

```python
# Filter even numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
evens = []

for num in numbers:
    if num % 2 == 0:
        evens.append(num)
print(evens)

# Or use list comprehension (more Pythonic)
evens = [num for num in numbers if num % 2 == 0]
```

### Pattern 5: Searching

```python
# Linear search
items = ["apple", "banana", "orange"]
target = "banana"
found = False

for item in items:
    if item == target:
        found = True
        break

if found:
    print(f"Found {target}")

# Or use 'in' operator
if target in items:
    print(f"Found {target}")
```

### Pattern 6: Processing Pairs

```python
# Process adjacent elements
numbers = [1, 2, 3, 4, 5]

for i in range(len(numbers) - 1):
    current = numbers[i]
    next_num = numbers[i + 1]
    print(f"{current} + {next_num} = {current + next_num}")
```

---

## Best Practices

### 1. Choose the Right Loop

```python
# ✅ GOOD - for loop for known iterations
for i in range(10):
    print(i)

# ❌ BAD - while loop for known iterations
i = 0
while i < 10:
    print(i)
    i += 1
```

### 2. Use Meaningful Variable Names

```python
# ❌ BAD
for x in [1, 2, 3]:
    print(x)

# ✅ GOOD
for score in [85, 92, 78]:
    print(score)

# ✅ GOOD (single letter OK for simple counters)
for i in range(10):
    print(i)
```

### 3. Avoid Modifying List While Iterating

```python
# ❌ WRONG - Modifying while iterating
numbers = [1, 2, 3, 4, 5]
for num in numbers:
    if num % 2 == 0:
        numbers.remove(num)  # Don't do this!

# ✅ CORRECT - Create new list
numbers = [1, 2, 3, 4, 5]
odd_numbers = [num for num in numbers if num % 2 != 0]

# ✅ CORRECT - Iterate over copy
numbers = [1, 2, 3, 4, 5]
for num in numbers.copy():
    if num % 2 == 0:
        numbers.remove(num)
```

### 4. Use enumerate() Instead of range(len())

```python
# ❌ NOT PYTHONIC
fruits = ["apple", "banana", "orange"]
for i in range(len(fruits)):
    print(f"{i}: {fruits[i]}")

# ✅ PYTHONIC
for i, fruit in enumerate(fruits):
    print(f"{i}: {fruit}")
```

### 5. Use zip() for Parallel Iteration

```python
names = ["Alice", "Bob", "Charlie"]
ages = [25, 30, 35]

# ❌ NOT PYTHONIC
for i in range(len(names)):
    print(f"{names[i]} is {ages[i]} years old")

# ✅ PYTHONIC
for name, age in zip(names, ages):
    print(f"{name} is {age} years old")
```

### 6. Break Long Loops Into Functions

```python
# ❌ HARD TO READ
for user in users:
    if user.is_active:
        if user.has_subscription:
            if user.payment_valid:
                # 20 more lines...

# ✅ BETTER
def should_process_user(user):
    return (user.is_active and 
            user.has_subscription and 
            user.payment_valid)

for user in users:
    if should_process_user(user):
        process_user(user)
```

---

## Common Mistakes

### Mistake 1: Infinite Loops

```python
# ❌ WRONG - Never ends
while True:
    print("Forever")

# ✅ CORRECT - Has exit condition
count = 0
while count < 5:
    print(count)
    count += 1
```

### Mistake 2: Off-by-One Errors

```python
# ❌ WRONG - Misses last element
for i in range(len(items) - 1):
    print(items[i])

# ✅ CORRECT
for i in range(len(items)):
    print(items[i])

# ✅ BETTER - Direct iteration
for item in items:
    print(item)
```

### Mistake 3: Using Wrong Range

```python
# Want numbers 1 to 10 inclusive
# ❌ WRONG - Stops at 9
for i in range(1, 10):
    print(i)

# ✅ CORRECT
for i in range(1, 11):
    print(i)
```

### Mistake 4: Forgetting to Update in while Loop

```python
# ❌ WRONG - Infinite loop
count = 0
while count < 5:
    print(count)
    # Missing: count += 1

# ✅ CORRECT
count = 0
while count < 5:
    print(count)
    count += 1
```

---

## Summary

### Key Takeaways

1. **for loops** iterate over sequences (definite)
2. **while loops** continue while condition is True (indefinite)
3. **break** exits loop immediately
4. **continue** skips to next iteration
5. **range()** generates number sequences
6. **enumerate()** provides index and value
7. **zip()** pairs elements from multiple sequences
8. **else clause** runs when loop completes normally

### Loop Comparison

| Feature | for Loop | while Loop |
|---------|----------|------------|
| Use when | Known iterations | Unknown iterations |
| Syntax | `for x in seq:` | `while condition:` |
| Common use | Iterate collections | Wait for condition |
| Risk | Less prone to infinite loops | Can infinite loop |
| Pythonic | More common | Use when necessary |

### Quick Reference

```python
# for loop
for item in collection:
    print(item)

# while loop
while condition:
    # code
    # update condition

# range
range(start, stop, step)

# enumerate
for i, item in enumerate(collection):
    print(i, item)

# zip
for x, y in zip(list1, list2):
    print(x, y)

# break and continue
for item in items:
    if condition:
        break  # Exit loop
    if other_condition:
        continue  # Skip iteration
```

---

## Next Steps

Now that you understand loops, you're ready to learn about:
- **Functions** - Organize code into reusable blocks
- **List comprehensions** - Elegant way to create lists
- **Generators** - Memory-efficient iterations

Practice makes perfect! Work through the exercises to master loops.
