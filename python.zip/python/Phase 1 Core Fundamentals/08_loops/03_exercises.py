"""
Python Loops - Practice Exercises
Test your understanding of for and while loops!
"""

print("Exercise 1: Print Numbers 1 to 10")
print("-"*60)
print("Task: Use a for loop to print numbers from 1 to 10")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 2: Sum of First N Numbers")
print("-"*60)
print("Task: Calculate sum of numbers from 1 to 100")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 3: Print Even Numbers")
print("-"*60)
print("Task: Print all even numbers from 1 to 20")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 4: Multiplication Table")
print("-"*60)
print("Task: Print multiplication table for 7 (7x1 through 7x10)")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 5: Countdown")
print("-"*60)
print("Task: Use while loop to countdown from 10 to 1")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 6: Find First Multiple")
print("-"*60)
print("Task: Find first number divisible by 7 in range(1, 100)")
print("Use break statement")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 7: Skip Multiples of 3")
print("-"*60)
print("Task: Print 1-20, but skip multiples of 3 using continue")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 8: Factorial Calculator")
print("-"*60)
print("Task: Calculate factorial of 6 (6! = 6×5×4×3×2×1)")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 9: List Sum")
print("-"*60)
print("Task: Sum all numbers in [5, 12, 8, 19, 3, 15]")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 10: Count Vowels")
print("-"*60)
print("Task: Count vowels (a,e,i,o,u) in 'Hello World'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 11: Find Maximum")
print("-"*60)
print("Task: Find maximum number in [45, 23, 78, 12, 89, 34]")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 12: Nested Loop Pattern")
print("-"*60)
print("Task: Print triangle pattern:")
print("*")
print("**")
print("***")
print("****")
print("*****")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 13: FizzBuzz")
print("-"*60)
print("Task: Print 1-30, but:")
print("- Multiples of 3: print 'Fizz'")
print("- Multiples of 5: print 'Buzz'")
print("- Multiples of both: print 'FizzBuzz'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 14: Reverse a String")
print("-"*60)
print("Task: Reverse 'Python' using a loop")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 15: Prime Number Check")
print("-"*60)
print("Task: Check if 29 is prime using a for loop")
print()
# Write your code below:


print("\n"+"="*60+"\n")
print("Exercises completed! Check solutions.py")
