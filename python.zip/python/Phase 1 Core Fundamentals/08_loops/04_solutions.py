"""
Python Loops - Exercise Solutions
"""

print("="*60)
print("Exercise 1 Solution: Print Numbers 1 to 10")
print("="*60)
for i in range(1, 11):
    print(i)
print()

print("="*60)
print("Exercise 2 Solution: Sum of First N Numbers")
print("="*60)
total = 0
for i in range(1, 101):
    total += i
print(f"Sum: {total}")
# Or using formula: n*(n+1)/2 = 100*101/2 = 5050
print()

print("="*60)
print("Exercise 3 Solution: Print Even Numbers")
print("="*60)
for i in range(2, 21, 2):
    print(i, end=" ")
print("\n")

print("="*60)
print("Exercise 4 Solution: Multiplication Table")
print("="*60)
for i in range(1, 11):
    print(f"7 × {i} = {7*i}")
print()

print("="*60)
print("Exercise 5 Solution: Countdown")
print("="*60)
count = 10
while count >= 1:
    print(count)
    count -= 1
print()

print("="*60)
print("Exercise 6 Solution: Find First Multiple")
print("="*60)
for num in range(1, 100):
    if num % 7 == 0:
        print(f"First multiple of 7: {num}")
        break
print()

print("="*60)
print("Exercise 7 Solution: Skip Multiples of 3")
print("="*60)
for i in range(1, 21):
    if i % 3 == 0:
        continue
    print(i, end=" ")
print("\n")

print("="*60)
print("Exercise 8 Solution: Factorial Calculator")
print("="*60)
n = 6
factorial = 1
for i in range(1, n+1):
    factorial *= i
print(f"{n}! = {factorial}")
print()

print("="*60)
print("Exercise 9 Solution: List Sum")
print("="*60)
numbers = [5, 12, 8, 19, 3, 15]
total = 0
for num in numbers:
    total += num
print(f"Sum: {total}")
# Or: print(f"Sum: {sum(numbers)}")
print()

print("="*60)
print("Exercise 10 Solution: Count Vowels")
print("="*60)
text = "Hello World"
vowels = "aeiouAEIOU"
count = 0
for char in text:
    if char in vowels:
        count += 1
print(f"Vowels in '{text}': {count}")
print()

print("="*60)
print("Exercise 11 Solution: Find Maximum")
print("="*60)
numbers = [45, 23, 78, 12, 89, 34]
max_num = numbers[0]
for num in numbers:
    if num > max_num:
        max_num = num
print(f"Maximum: {max_num}")
# Or: print(f"Maximum: {max(numbers)}")
print()

print("="*60)
print("Exercise 12 Solution: Nested Loop Pattern")
print("="*60)
for i in range(1, 6):
    for j in range(i):
        print("*", end="")
    print()
# Or simpler: for i in range(1, 6): print("*" * i)
print()

print("="*60)
print("Exercise 13 Solution: FizzBuzz")
print("="*60)
for i in range(1, 31):
    if i % 15 == 0:
        print("FizzBuzz")
    elif i % 3 == 0:
        print("Fizz")
    elif i % 5 == 0:
        print("Buzz")
    else:
        print(i)
print()

print("="*60)
print("Exercise 14 Solution: Reverse a String")
print("="*60)
text = "Python"
reversed_text = ""
for char in text:
    reversed_text = char + reversed_text
print(f"Original: {text}")
print(f"Reversed: {reversed_text}")
# Or: print(text[::-1])
print()

print("="*60)
print("Exercise 15 Solution: Prime Number Check")
print("="*60)
num = 29
is_prime = True
if num < 2:
    is_prime = False
else:
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            is_prime = False
            break
print(f"{num} is {'prime' if is_prime else 'not prime'}")
print()

print("="*60)
print("All solutions completed!")
print("="*60)
print("\nKey Takeaways:")
print("• for loops iterate over sequences")
print("• while loops continue while condition is True")
print("• break exits loop immediately")
print("• continue skips to next iteration")
print("• range() generates number sequences")
print("• Nested loops for multi-dimensional tasks")
