# Python Loops: for and while

## 📚 Contents

1. **01_tutorial.md** - Complete guide to loops
2. **02_examples.py** - 15 practical demonstrations
3. **03_exercises.py** - 15 practice exercises
4. **04_solutions.py** - Detailed solutions

## 🎯 Learning Objectives

- ✅ Master `for` loops for iteration
- ✅ Use `while` loops for conditional repetition
- ✅ Apply `break` and `continue` statements
- ✅ Work with `range()`, `enumerate()`, and `zip()`
- ✅ Create nested loops
- ✅ Understand loop-else construct
- ✅ Implement common loop patterns

## 🚀 Quick Start

```bash
# Read tutorial first
# Then run examples
python 02_examples.py

# Practice exercises
python 03_exercises.py

# Check solutions
python 04_solutions.py
```

## 💡 Key Concepts

### for Loop
```python
for item in sequence:
    # code
```

### while Loop
```python
while condition:
    # code
```

### Loop Control
```python
break     # Exit loop
continue  # Skip to next iteration
```

### Useful Functions
```python
range(start, stop, step)
enumerate(sequence)
zip(seq1, seq2)
```

## ⏱️ Time: ~2-2.5 hours

## 🔗 Next: Functions Module

Happy Coding! 🐍
