"""
05_type_inspection_functions.py - Type Inspection Functions
type(), isinstance(), id(), dir(), help(), callable()
"""

print("=" * 70)
print("TYPE INSPECTION BUILT-IN FUNCTIONS")
print("=" * 70)

# type() - Get type of object
print("\n1. type() - Object Type")
print(f"type(42) = {type(42)}")
print(f"type(3.14) = {type(3.14)}")
print(f"type('hello') = {type('hello')}")
print(f"type([1, 2, 3]) = {type([1, 2, 3])}")
print(f"type({{'a': 1}}) = {type({'a': 1})}")

# isinstance() - Check if object is instance of type
print("\n2. isinstance() - Type Checking")
x = 42
print(f"isinstance(42, int) = {isinstance(x, int)}")
print(f"isinstance(42, str) = {isinstance(x, str)}")
print(f"isinstance(42, (int, float)) = {isinstance(x, (int, float))}")

y = [1, 2, 3]
print(f"isinstance([1,2,3], list) = {isinstance(y, list)}")

# id() - Memory address of object
print("\n3. id() - Object Identity")
a = [1, 2, 3]
b = a
c = [1, 2, 3]
print(f"a = {a}, id = {id(a)}")
print(f"b = {b}, id = {id(b)}")
print(f"c = {c}, id = {id(c)}")
print(f"a is b: {a is b} (same id)")
print(f"a is c: {a is c} (different id)")

# dir() - List attributes and methods
print("\n4. dir() - Object Attributes")
x = "hello"
methods = dir(x)
print(f"dir('hello') shows {len(methods)} attributes/methods")
print(f"Some string methods: {[m for m in methods if not m.startswith('_')][:10]}")

# help() - Get documentation
print("\n5. help() - Documentation")
print("help(len) would display:")
print("  Help on built-in function len:")
print("  len(obj, /)")
print("    Return the number of items in a container.")
print("\nTry: help(print), help(len), help(str.upper)")

# callable() - Check if object can be called
print("\n6. callable() - Is it a function?")
def my_function():
    pass

print(f"callable(print) = {callable(print)}")
print(f"callable(my_function) = {callable(my_function)}")
print(f"callable(42) = {callable(42)}")
print(f"callable('hello') = {callable('hello')}")

print("\n" + "=" * 70)
print("PRACTICAL EXAMPLES")
print("=" * 70)

# Dynamic type checking
print("\nExample: Safe division")
def safe_divide(a, b):
    if not isinstance(a, (int, float)) or not isinstance(b, (int, float)):
        return "Error: Both arguments must be numbers"
    if b == 0:
        return "Error: Cannot divide by zero"
    return a / b

print(f"safe_divide(10, 2) = {safe_divide(10, 2)}")
print(f"safe_divide(10, 0) = {safe_divide(10, 0)}")
print(f"safe_divide('10', 2) = {safe_divide('10', 2)}")

# Inspect object capabilities
print("\nExample: Discover object methods")
my_list = [1, 2, 3]
list_methods = [m for m in dir(my_list) if not m.startswith('_') and callable(getattr(my_list, m))]
print(f"List methods: {list_methods[:8]}...")

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)
print("""
1. type(obj) - returns the type of object
2. isinstance(obj, type) - check if object is of type (preferred)
3. id(obj) - returns unique identifier (memory address)
4. dir(obj) - lists all attributes and methods
5. help(obj) - shows documentation
6. callable(obj) - checks if object can be called like a function

BEST PRACTICES:
- Use isinstance() instead of type() == for type checking
- Use id() and 'is' to check object identity
- Use dir() and help() to explore unfamiliar objects
- callable() is useful before trying to call something
""")

print("\nSee exercises.py for practice!")
