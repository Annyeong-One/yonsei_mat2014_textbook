# Python Built-in Functions (Basic)

## Overview
This package covers essential Python built-in functions that students need from day one. These functions are used throughout Python programming and should be mastered early in the learning journey.

## Prerequisites
- Basic Python syntax (variables, data types)
- Understanding of control flow (if/else)
- Loops (for, while)
- Basic data structures (lists, strings)

## Course Structure

### Tutorial Files
1. **01_input_output_functions.py** - print(), input(), format()
2. **02_type_conversion_functions.py** - int(), float(), str(), bool(), list(), dict(), tuple(), set()
3. **03_numeric_functions.py** - abs(), round(), pow(), min(), max(), sum()
4. **04_sequence_functions.py** - len(), range(), sorted(), reversed()
5. **05_type_inspection_functions.py** - type(), isinstance(), id(), dir(), help()

### Exercise and Solution Files
- **exercises.py** - Practice problems for all basic built-ins
- **solutions.py** - Complete solutions with explanations

## Key Concepts Covered

### Input/Output
- Reading user input
- Printing output with formatting
- String formatting methods

### Type Conversion
- Converting between data types
- Type safety and validation
- Common conversion patterns

### Numeric Operations
- Mathematical operations
- Rounding and precision
- Finding extremes in sequences

### Sequence Operations
- Measuring length
- Generating number sequences
- Basic sorting and reversing

### Type Inspection
- Checking object types
- Exploring object attributes
- Getting help on functions

## Learning Objectives
By completing this module, students will:
1. Use built-in functions for I/O operations
2. Convert between different data types safely
3. Perform common numeric operations
4. Work with sequences efficiently
5. Inspect and explore Python objects

## Teaching Notes
- These functions are essential building blocks
- Students will use these throughout the course
- Emphasize practical usage over theory
- Encourage experimentation with help() and dir()
- Show common mistakes and how to avoid them

## Estimated Time
- Tutorial files: 3-4 hours total
- Exercises: 1-2 hours
- Total: 4-6 hours

## Next Steps
After mastering these basic built-ins, students will learn:
- How to define their own functions
- Advanced built-in functions (map, filter, zip)
- Lambda functions and functional programming
