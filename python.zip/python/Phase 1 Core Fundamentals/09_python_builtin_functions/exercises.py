"""
exercises.py - Practice Problems for Basic Built-in Functions
Complete these exercises to master the basic built-in functions
"""

print("=" * 70)
print("BASIC BUILT-IN FUNCTIONS - EXERCISES")
print("=" * 70)

# SECTION 1: Input/Output (10 exercises)
print("\nSECTION 1: Input/Output Functions")
print("-" * 70)
print("""
1. Ask user for their name and age, print: "Hello [name], you are [age] years old"
2. Print numbers 1-10 on the same line, separated by spaces
3. Create a formatted receipt with item names and prices aligned
4. Ask for temperature in Celsius, convert and display in Fahrenheit
5. Print a countdown from 10 to 1, updating the same line

6. Ask for 3 numbers, calculate and print their sum
7. Create a mad libs game (ask for nouns, verbs, adjectives)
8. Print a pattern: ***** (use print(end=''))
9. Display progress: [####------] 40%
10. Format prices with $ sign and 2 decimal places
""")

# SECTION 2: Type Conversion (10 exercises)
print("\nSECTION 2: Type Conversion Functions")
print("-" * 70)
print("""
1. Convert string "123" to integer and add 10
2. Convert "3.14" to float and multiply by 2
3. Convert boolean True to integer and string
4. Check which of these are truthy: 0, "", [], None, "0", [0]
5. Convert list [1,2,3] to tuple, then to set

6. Split "10 20 30" and convert each to integer
7. Convert binary string "1010" to decimal integer
8. Convert decimal 255 to hexadecimal string
9. Get ASCII value of 'A' and convert back to character
10. Safely convert user input to integer with error handling
""")

# SECTION 3: Numeric Functions (10 exercises)
print("\nSECTION 3: Numeric Functions")
print("-" * 70)
print("""
1. Calculate absolute difference between two numbers
2. Round 3.14159 to 2 decimal places
3. Calculate 2 to the power of 10
4. Find minimum of [15, 23, 7, 42, 8]
5. Find maximum of three user-provided numbers

6. Calculate sum of numbers 1 to 100
7. Find average of [85, 92, 78, 88, 95]
8. Use divmod to convert minutes to hours and minutes
9. Calculate distance between points (x1,y1) and (x2,y2)
10. Round prices: [12.678, 5.234, 8.999] to 2 decimals
""")

# SECTION 4: Sequence Functions (10 exercises)
print("\nSECTION 4: Sequence Functions")
print("-" * 70)
print("""
1. Get length of string "Python Programming"
2. Generate list of even numbers 0-20 using range
3. Sort list [5, 2, 8, 1, 9] without modifying original
4. Reverse string "hello" 
5. Check if all elements in [2, 4, 6, 8] are even

6. Check if any element in [1, 3, 5, 6, 7] is even
7. Create list of first 10 square numbers
8. Sort words ['banana', 'apple', 'cherry'] alphabetically
9. Check if all characters in password are alphanumeric
10. Find positions of all 'a' in "banana"
""")

# SECTION 5: Type Inspection (10 exercises)
print("\nSECTION 5: Type Inspection Functions")
print("-" * 70)
print("""
1. Check type of 42, 3.14, "hello", [1,2,3]
2. Use isinstance to check if "hello" is a string
3. Check if two lists have the same id
4. List all methods of a list object using dir()
5. Check if len is callable

6. Compare id of x=5 and y=5 (small integers)
7. Compare id of a=[1,2,3] and b=[1,2,3]
8. Find all methods of string that start with 'is'
9. Check if object is number (int or float)
10. Get help documentation for range function
""")

print("\n" + "=" * 70)
print("See solutions.py for complete answers!")
print("=" * 70)
