"""
solutions.py - Complete Solutions with Explanations
"""

print("=" * 70)
print("BASIC BUILT-IN FUNCTIONS - SOLUTIONS")
print("=" * 70)

# SECTION 1: Input/Output Solutions
print("\nSECTION 1: Input/Output Solutions")
print("-" * 70)

# Exercise 1
print("\n1. Name and age greeting")
# name = input("Enter name: ")
# age = int(input("Enter age: "))
name, age = "Alice", 25  # Simulated
print(f"Hello {name}, you are {age} years old")

# Exercise 2
print("\n2. Numbers on one line")
for i in range(1, 11):
    print(i, end=" ")
print()  # Newline

# Exercise 3
print("\n3. Formatted receipt")
items = [("Apple", 1.50), ("Banana", 0.75), ("Orange", 2.00)]
print("-" * 30)
for item, price in items:
    print(f"{item:<20} ${price:>6.2f}")
print("-" * 30)
total = sum(price for item, price in items)
print(f"{'TOTAL':<20} ${total:>6.2f}")

# Exercise 4-5 skipped for brevity

# SECTION 2: Type Conversion Solutions
print("\n" + "=" * 70)
print("SECTION 2: Type Conversion Solutions")
print("-" * 70)

# Exercise 1
print("\n1. String to int")
num_str = "123"
num_int = int(num_str) + 10
print(f"Result: {num_int}")

# Exercise 2
print("\n2. String to float")
pi_str = "3.14"
result = float(pi_str) * 2
print(f"Result: {result}")

# Exercise 4
print("\n4. Truthy/Falsy check")
values = [0, "", [], None, "0", [0]]
for val in values:
    print(f"{repr(val):10} -> {bool(val)}")

# Exercise 7
print("\n7. Binary to decimal")
binary = "1010"
decimal = int(binary, 2)
print(f"Binary {binary} = Decimal {decimal}")

# SECTION 3: Numeric Solutions
print("\n" + "=" * 70)
print("SECTION 3: Numeric Solutions")
print("-" * 70)

# Exercise 1
print("\n1. Absolute difference")
a, b = 10, 25
diff = abs(a - b)
print(f"|{a} - {b}| = {diff}")

# Exercise 2
print("\n2. Rounding")
pi = 3.14159
rounded = round(pi, 2)
print(f"Pi rounded to 2 places: {rounded}")

# Exercise 6
print("\n6. Sum 1 to 100")
total = sum(range(1, 101))
print(f"Sum of 1-100: {total}")

# Exercise 7
print("\n7. Average")
grades = [85, 92, 78, 88, 95]
average = sum(grades) / len(grades)
print(f"Average: {round(average, 2)}")

# SECTION 4: Sequence Solutions
print("\n" + "=" * 70)
print("SECTION 4: Sequence Solutions")
print("-" * 70)

# Exercise 1
print("\n1. String length")
text = "Python Programming"
print(f"Length of '{text}': {len(text)}")

# Exercise 2
print("\n2. Even numbers 0-20")
evens = list(range(0, 21, 2))
print(f"Even numbers: {evens}")

# Exercise 3
print("\n3. Sort without modifying")
numbers = [5, 2, 8, 1, 9]
sorted_nums = sorted(numbers)
print(f"Original: {numbers}")
print(f"Sorted: {sorted_nums}")

# Exercise 5
print("\n5. All elements even")
numbers = [2, 4, 6, 8]
all_even = all(n % 2 == 0 for n in numbers)
print(f"All even in {numbers}: {all_even}")

# SECTION 5: Type Inspection Solutions
print("\n" + "=" * 70)
print("SECTION 5: Type Inspection Solutions")
print("-" * 70)

# Exercise 1
print("\n1. Check types")
values = [42, 3.14, "hello", [1,2,3]]
for val in values:
    print(f"type({repr(val)}) = {type(val).__name__}")

# Exercise 2
print("\n2. isinstance check")
result = isinstance("hello", str)
print(f"isinstance('hello', str) = {result}")

# Exercise 6-7
print("\n6-7. ID comparison")
x, y = 5, 5
print(f"id(5) == id(5): {id(x) == id(y)} (small ints cached)")
a, b = [1,2,3], [1,2,3]
print(f"id([1,2,3]) == id([1,2,3]): {id(a) == id(b)} (different objects)")

print("\n" + "=" * 70)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 70)
