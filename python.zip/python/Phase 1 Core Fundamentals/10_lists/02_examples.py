"""
PRACTICAL EXAMPLES - Lists
===========================

Real-world examples demonstrating when and how to use lists.
"""

# =============================================================================
# EXAMPLE 1: To-Do List Application
# =============================================================================

print("=" * 60)
print("EXAMPLE 1: To-Do List Application")
print("=" * 60)

class TodoList:
    def __init__(self):
        self.tasks = []
    
    def add_task(self, task, priority="normal"):
        """Add a task with priority"""
        self.tasks.append({"task": task, "priority": priority, "done": False})
        print(f"✓ Added: {task} [{priority}]")
    
    def complete_task(self, index):
        """Mark task as complete"""
        if 0 <= index < len(self.tasks):
            self.tasks[index]["done"] = True
            print(f"✓ Completed: {self.tasks[index]['task']}")
        else:
            print("Invalid task number")
    
    def remove_task(self, index):
        """Remove a task"""
        if 0 <= index < len(self.tasks):
            removed = self.tasks.pop(index)
            print(f"✗ Removed: {removed['task']}")
        else:
            print("Invalid task number")
    
    def show_tasks(self):
        """Display all tasks"""
        if not self.tasks:
            print("No tasks! 🎉")
            return
        
        print("\nCurrent tasks:")
        for i, task in enumerate(self.tasks):
            status = "✓" if task["done"] else "○"
            print(f"  {i+1}. {status} {task['task']} [{task['priority']}]")
    
    def get_pending(self):
        """Get list of pending tasks"""
        return [task for task in self.tasks if not task["done"]]
    
    def sort_by_priority(self):
        """Sort tasks by priority"""
        priority_order = {"high": 0, "normal": 1, "low": 2}
        self.tasks.sort(key=lambda x: priority_order.get(x["priority"], 1))
        print("✓ Sorted by priority")

# Usage
todo = TodoList()
todo.add_task("Buy groceries", "high")
todo.add_task("Finish Python tutorial", "high")
todo.add_task("Call dentist", "normal")
todo.add_task("Watch movie", "low")
todo.show_tasks()

todo.complete_task(0)
todo.sort_by_priority()
todo.show_tasks()
print()

# =============================================================================
# EXAMPLE 2: Student Grade Management
# =============================================================================

print("=" * 60)
print("EXAMPLE 2: Student Grade Management")
print("=" * 60)

class GradeBook:
    def __init__(self):
        self.students = []
    
    def add_student(self, name):
        """Add a student"""
        self.students.append({"name": name, "grades": []})
        print(f"✓ Added student: {name}")
    
    def add_grade(self, student_name, subject, grade):
        """Add a grade for a student"""
        for student in self.students:
            if student["name"] == student_name:
                student["grades"].append({"subject": subject, "grade": grade})
                print(f"✓ Added {subject}: {grade} for {student_name}")
                return
        print(f"Student {student_name} not found")
    
    def get_average(self, student_name):
        """Calculate student's average"""
        for student in self.students:
            if student["name"] == student_name:
                grades = [g["grade"] for g in student["grades"]]
                return sum(grades) / len(grades) if grades else 0
        return None
    
    def get_top_students(self, n=3):
        """Get top n students by average"""
        averages = [(s["name"], self.get_average(s["name"])) for s in self.students]
        averages.sort(key=lambda x: x[1], reverse=True)
        return averages[:n]
    
    def get_subject_average(self, subject):
        """Get class average for a subject"""
        grades = []
        for student in self.students:
            for grade in student["grades"]:
                if grade["subject"] == subject:
                    grades.append(grade["grade"])
        return sum(grades) / len(grades) if grades else 0

# Usage
gradebook = GradeBook()
gradebook.add_student("Alice")
gradebook.add_student("Bob")
gradebook.add_student("Charlie")

gradebook.add_grade("Alice", "Math", 95)
gradebook.add_grade("Alice", "English", 88)
gradebook.add_grade("Bob", "Math", 87)
gradebook.add_grade("Bob", "English", 92)
gradebook.add_grade("Charlie", "Math", 90)
gradebook.add_grade("Charlie", "English", 85)

print(f"\nAlice's average: {gradebook.get_average('Alice'):.2f}")
print(f"Math class average: {gradebook.get_subject_average('Math'):.2f}")
print(f"Top 2 students: {gradebook.get_top_students(2)}")
print()

# =============================================================================
# EXAMPLE 3: Shopping Cart
# =============================================================================

print("=" * 60)
print("EXAMPLE 3: Shopping Cart")
print("=" * 60)

class ShoppingCart:
    def __init__(self):
        self.items = []
    
    def add_item(self, name, price, quantity=1):
        """Add item to cart"""
        # Check if item already exists
        for item in self.items:
            if item["name"] == name:
                item["quantity"] += quantity
                print(f"✓ Updated {name} quantity to {item['quantity']}")
                return
        
        # Add new item
        self.items.append({"name": name, "price": price, "quantity": quantity})
        print(f"✓ Added {name} x{quantity} @ ${price}")
    
    def remove_item(self, name):
        """Remove item from cart"""
        for i, item in enumerate(self.items):
            if item["name"] == name:
                removed = self.items.pop(i)
                print(f"✗ Removed {name}")
                return
        print(f"{name} not in cart")
    
    def update_quantity(self, name, quantity):
        """Update item quantity"""
        for item in self.items:
            if item["name"] == name:
                item["quantity"] = quantity
                print(f"✓ Updated {name} quantity to {quantity}")
                return
        print(f"{name} not in cart")
    
    def get_total(self):
        """Calculate total price"""
        return sum(item["price"] * item["quantity"] for item in self.items)
    
    def apply_discount(self, percent):
        """Apply discount to all items"""
        for item in self.items:
            item["price"] *= (1 - percent / 100)
        print(f"✓ Applied {percent}% discount")
    
    def show_cart(self):
        """Display cart contents"""
        if not self.items:
            print("Cart is empty")
            return
        
        print("\n=== Shopping Cart ===")
        for item in self.items:
            total = item["price"] * item["quantity"]
            print(f"  {item['name']}: ${item['price']:.2f} x {item['quantity']} = ${total:.2f}")
        print(f"\nTotal: ${self.get_total():.2f}")

# Usage
cart = ShoppingCart()
cart.add_item("Apple", 1.50, 5)
cart.add_item("Bread", 2.99, 2)
cart.add_item("Milk", 3.49, 1)
cart.add_item("Apple", 1.50, 3)  # Will update quantity
cart.show_cart()

cart.apply_discount(10)
cart.show_cart()
print()

# =============================================================================
# EXAMPLE 4: Playlist Manager
# =============================================================================

print("=" * 60)
print("EXAMPLE 4: Music Playlist Manager")
print("=" * 60)

class Playlist:
    def __init__(self, name):
        self.name = name
        self.songs = []
    
    def add_song(self, title, artist, duration):
        """Add song to playlist"""
        self.songs.append({"title": title, "artist": artist, "duration": duration})
        print(f"♪ Added: {title} by {artist}")
    
    def remove_song(self, title):
        """Remove song by title"""
        for i, song in enumerate(self.songs):
            if song["title"] == title:
                self.songs.pop(i)
                print(f"✗ Removed: {title}")
                return
        print(f"Song not found: {title}")
    
    def shuffle(self):
        """Shuffle playlist"""
        import random
        random.shuffle(self.songs)
        print("♪ Playlist shuffled")
    
    def total_duration(self):
        """Get total playlist duration"""
        total_seconds = sum(song["duration"] for song in self.songs)
        minutes = total_seconds // 60
        seconds = total_seconds % 60
        return f"{minutes}:{seconds:02d}"
    
    def find_by_artist(self, artist):
        """Find all songs by an artist"""
        return [song for song in self.songs if song["artist"].lower() == artist.lower()]
    
    def sort_by_title(self):
        """Sort songs alphabetically by title"""
        self.songs.sort(key=lambda x: x["title"])
        print("✓ Sorted by title")
    
    def sort_by_duration(self):
        """Sort songs by duration"""
        self.songs.sort(key=lambda x: x["duration"])
        print("✓ Sorted by duration")
    
    def show_playlist(self):
        """Display playlist"""
        print(f"\n=== {self.name} ===")
        for i, song in enumerate(self.songs, 1):
            mins = song["duration"] // 60
            secs = song["duration"] % 60
            print(f"  {i}. {song['title']} - {song['artist']} ({mins}:{secs:02d})")
        print(f"Total Duration: {self.total_duration()}")

# Usage
playlist = Playlist("My Favorites")
playlist.add_song("Bohemian Rhapsody", "Queen", 354)
playlist.add_song("Stairway to Heaven", "Led Zeppelin", 482)
playlist.add_song("Hotel California", "Eagles", 391)
playlist.add_song("Imagine", "John Lennon", 183)

playlist.show_playlist()
playlist.sort_by_title()
playlist.show_playlist()
print()

# =============================================================================
# EXAMPLE 5: Inventory Management
# =============================================================================

print("=" * 60)
print("EXAMPLE 5: Inventory Management System")
print("=" * 60)

class Inventory:
    def __init__(self):
        self.products = []
        self.next_id = 1
    
    def add_product(self, name, quantity, price):
        """Add a product"""
        product = {
            "id": self.next_id,
            "name": name,
            "quantity": quantity,
            "price": price
        }
        self.products.append(product)
        print(f"✓ Added: {name} (ID: {self.next_id})")
        self.next_id += 1
    
    def update_stock(self, product_id, change):
        """Update stock (positive or negative)"""
        for product in self.products:
            if product["id"] == product_id:
                product["quantity"] += change
                if product["quantity"] < 0:
                    product["quantity"] = 0
                print(f"✓ Updated {product['name']} stock to {product['quantity']}")
                return
        print(f"Product ID {product_id} not found")
    
    def get_total_value(self):
        """Calculate total inventory value"""
        return sum(p["quantity"] * p["price"] for p in self.products)
    
    def low_stock_alert(self, threshold=10):
        """Get products with low stock"""
        return [p for p in self.products if p["quantity"] < threshold]
    
    def most_valuable(self, n=5):
        """Get n most valuable products"""
        valued = [(p, p["quantity"] * p["price"]) for p in self.products]
        valued.sort(key=lambda x: x[1], reverse=True)
        return valued[:n]
    
    def find_product(self, name):
        """Find product by name"""
        for product in self.products:
            if name.lower() in product["name"].lower():
                return product
        return None
    
    def show_inventory(self):
        """Display all products"""
        print("\n=== INVENTORY ===")
        print(f"{'ID':<5} {'Name':<20} {'Qty':<8} {'Price':<10} {'Value':<10}")
        print("-" * 60)
        for p in self.products:
            value = p["quantity"] * p["price"]
            print(f"{p['id']:<5} {p['name']:<20} {p['quantity']:<8} ${p['price']:<9.2f} ${value:<9.2f}")
        print(f"\nTotal Value: ${self.get_total_value():.2f}")

# Usage
inventory = Inventory()
inventory.add_product("Laptop", 50, 999.99)
inventory.add_product("Mouse", 5, 19.99)
inventory.add_product("Keyboard", 30, 79.99)
inventory.add_product("Monitor", 20, 299.99)

inventory.show_inventory()

inventory.update_stock(2, -3)  # Sell 3 mice
print(f"\nLow stock items: {[p['name'] for p in inventory.low_stock_alert()]}")
print()

# =============================================================================
# EXAMPLE 6: Data Analysis with Lists
# =============================================================================

print("=" * 60)
print("EXAMPLE 6: Sales Data Analysis")
print("=" * 60)

# Monthly sales data
monthly_sales = [15000, 18000, 22000, 17000, 25000, 30000,
                 28000, 32000, 29000, 35000, 40000, 38000]

months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
          "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

# Basic statistics
average_sales = sum(monthly_sales) / len(monthly_sales)
max_sales = max(monthly_sales)
min_sales = min(monthly_sales)
best_month = months[monthly_sales.index(max_sales)]
worst_month = months[monthly_sales.index(min_sales)]

print(f"Average monthly sales: ${average_sales:,.2f}")
print(f"Best month: {best_month} (${max_sales:,})")
print(f"Worst month: {worst_month} (${min_sales:,})")

# Find months above average
above_average = [(months[i], sales) for i, sales in enumerate(monthly_sales) 
                 if sales > average_sales]
print(f"\nMonths above average: {len(above_average)}")

# Calculate month-over-month growth
growth_rates = [(monthly_sales[i] - monthly_sales[i-1]) / monthly_sales[i-1] * 100
                for i in range(1, len(monthly_sales))]
avg_growth = sum(growth_rates) / len(growth_rates)
print(f"Average growth rate: {avg_growth:.2f}%")

# Find quarters
q1 = sum(monthly_sales[0:3])
q2 = sum(monthly_sales[3:6])
q3 = sum(monthly_sales[6:9])
q4 = sum(monthly_sales[9:12])

quarters = [q1, q2, q3, q4]
print(f"\nQuarterly sales: Q1=${q1:,}, Q2=${q2:,}, Q3=${q3:,}, Q4=${q4:,}")
print(f"Best quarter: Q{quarters.index(max(quarters)) + 1}")
print()

print("=" * 60)
print("EXAMPLES COMPLETE!")
print("=" * 60)
