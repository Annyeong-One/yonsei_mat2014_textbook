"""
EXERCISES - Lists
=================

Practice problems to master Python lists. Solutions are in 04_solutions.py
Try to solve these on your own first!

Difficulty levels: ⭐ Easy | ⭐⭐ Medium | ⭐⭐⭐ Hard
"""

# =============================================================================
# SECTION 1: LIST BASICS
# =============================================================================

print("=" * 60)
print("SECTION 1: LIST BASICS")
print("=" * 60)

# Exercise 1.1 ⭐
# Create a list of your 5 favorite movies
def exercise_1_1():
    # Your code here
    pass

# Exercise 1.2 ⭐
# Access the first, last, and middle element from a list
def exercise_1_2():
    numbers = [10, 20, 30, 40, 50]
    # Your code here
    pass

# Exercise 1.3 ⭐
# Add "grape" to the end, insert "blueberry" at position 2, remove "banana"
def exercise_1_3():
    fruits = ["apple", "banana", "cherry", "date"]
    # Your code here
    pass

# Exercise 1.4 ⭐⭐
# Reverse a list without using reverse() or [::-1]
def exercise_1_4():
    numbers = [1, 2, 3, 4, 5]
    # Your code here using a loop
    pass

# Exercise 1.5 ⭐⭐
# Find sum, average, max, and min
def exercise_1_5():
    numbers = [23, 45, 67, 12, 89, 34, 56, 78, 90, 11]
    # Your code here
    pass

# =============================================================================
# SECTION 2: LIST SLICING
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 2: LIST SLICING")
print("=" * 60)

# Exercise 2.1 ⭐
# Get first 3 elements, last 3 elements, and every 2nd element
def exercise_2_1():
    numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    # Your code here
    pass

# Exercise 2.2 ⭐
# Reverse a list using slicing
def exercise_2_2():
    letters = ['a', 'b', 'c', 'd', 'e']
    # Your code here
    pass

# Exercise 2.3 ⭐⭐
# Split list into two halves
def exercise_2_3():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # Your code here
    pass

# Exercise 2.4 ⭐⭐
# Get every 3rd element starting from index 1
def exercise_2_4():
    numbers = list(range(20))
    # Your code here
    pass

# =============================================================================
# SECTION 3: LIST METHODS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 3: LIST METHODS")
print("=" * 60)

# Exercise 3.1 ⭐
# Sort list ascending and descending
def exercise_3_1():
    numbers = [64, 34, 25, 12, 22, 11, 90]
    # Your code here
    pass

# Exercise 3.2 ⭐⭐
# Remove duplicates while preserving order
def exercise_3_2():
    numbers = [1, 2, 3, 2, 4, 3, 5, 1, 6]
    # Your code here
    pass

# Exercise 3.3 ⭐⭐
# Count occurrences of each element
def exercise_3_3():
    items = ["apple", "banana", "apple", "cherry", "banana", "apple"]
    # Your code here - create a dictionary
    pass

# Exercise 3.4 ⭐⭐⭐
# Rotate list to the right by n positions
def exercise_3_4(lst, n):
    """[1,2,3,4,5] rotated by 2 becomes [4,5,1,2,3]"""
    # Your code here
    pass

# =============================================================================
# SECTION 4: LIST COMPREHENSIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 4: LIST COMPREHENSIONS")
print("=" * 60)

# Exercise 4.1 ⭐
# Create list of squares from 1 to 10
def exercise_4_1():
    # Your code here
    pass

# Exercise 4.2 ⭐
# Create list of even numbers from 1 to 20
def exercise_4_2():
    # Your code here
    pass

# Exercise 4.3 ⭐⭐
# Convert all strings to uppercase
def exercise_4_3():
    words = ["hello", "world", "python", "programming"]
    # Your code here
    pass

# Exercise 4.4 ⭐⭐
# Extract numbers greater than 50
def exercise_4_4():
    numbers = [23, 67, 45, 89, 12, 56, 78, 34, 90, 11]
    # Your code here
    pass

# Exercise 4.5 ⭐⭐⭐
# Create list of (number, square, cube) for numbers 1-5
def exercise_4_5():
    # Your code here
    pass

# Exercise 4.6 ⭐⭐⭐
# Flatten nested list
def exercise_4_6():
    nested = [[1, 2, 3], [4, 5], [6, 7, 8, 9]]
    # Your code here
    pass

# =============================================================================
# SECTION 5: NESTED LISTS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 5: NESTED LISTS")
print("=" * 60)

# Exercise 5.1 ⭐⭐
# Create a 3x3 matrix of zeros
def exercise_5_1():
    # Your code here
    pass

# Exercise 5.2 ⭐⭐
# Sum all elements in a 2D list
def exercise_5_2():
    matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    # Your code here
    pass

# Exercise 5.3 ⭐⭐⭐
# Transpose a matrix
def exercise_5_3():
    matrix = [[1, 2, 3], [4, 5, 6]]
    # Result should be [[1, 4], [2, 5], [3, 6]]
    # Your code here
    pass

# Exercise 5.4 ⭐⭐⭐
# Find maximum element in 2D list
def exercise_5_4():
    matrix = [[1, 5, 3], [9, 2, 8], [4, 7, 6]]
    # Your code here
    pass

# =============================================================================
# SECTION 6: SEARCHING AND FILTERING
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 6: SEARCHING AND FILTERING")
print("=" * 60)

# Exercise 6.1 ⭐
# Find index of first occurrence of element
def exercise_6_1():
    numbers = [10, 20, 30, 20, 40, 20]
    # Find index of first 20
    # Your code here
    pass

# Exercise 6.2 ⭐⭐
# Find all indices of an element
def exercise_6_2(lst, target):
    """Return list of all indices where target appears"""
    # Your code here
    pass

# Exercise 6.3 ⭐⭐
# Find common elements in two lists
def exercise_6_3(list1, list2):
    # Your code here
    pass

# Exercise 6.4 ⭐⭐⭐
# Find second largest element
def exercise_6_4(numbers):
    # Your code here
    pass

# =============================================================================
# SECTION 7: REAL-WORLD APPLICATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 7: REAL-WORLD APPLICATIONS")
print("=" * 60)

# Exercise 7.1 ⭐⭐⭐
# Shopping cart - add, remove, calculate total
def exercise_7_1():
    """
    Create shopping cart that can:
    - Add items with price and quantity
    - Remove items
    - Update quantity
    - Calculate total
    """
    # Your code here
    pass

# Exercise 7.2 ⭐⭐⭐
# Grade calculator
def exercise_7_2():
    """
    Store test scores and:
    - Calculate average
    - Assign letter grade
    - Find highest/lowest
    - Drop lowest score and recalculate
    """
    # Your code here
    pass

# Exercise 7.3 ⭐⭐⭐
# Contact list manager
def exercise_7_3():
    """
    Manage contacts:
    - Add contact (name, phone, email)
    - Search by name
    - List all
    - Sort alphabetically
    """
    # Your code here
    pass

# Exercise 7.4 ⭐⭐⭐
# Task scheduler
def exercise_7_4():
    """
    Schedule tasks with priority:
    - Add task with priority (high/medium/low)
    - Sort by priority
    - Mark complete
    - Show pending tasks
    """
    # Your code here
    pass

# =============================================================================
# BONUS CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("BONUS CHALLENGES")
print("=" * 60)

# Bonus 1 ⭐⭐⭐
# Merge two sorted lists into one sorted list
def merge_sorted_lists(list1, list2):
    # Your code here
    pass

# Bonus 2 ⭐⭐⭐
# Find longest increasing subsequence length
def longest_increasing_subsequence(numbers):
    """[1,3,2,4,5] -> 4 (subsequence: 1,2,4,5)"""
    # Your code here
    pass

# Bonus 3 ⭐⭐⭐
# Move all zeros to end while maintaining order
def move_zeros(numbers):
    """[1,0,2,0,3] -> [1,2,3,0,0]"""
    # Your code here
    pass

# Bonus 4 ⭐⭐⭐
# Find pairs that sum to target
def find_pairs_sum(numbers, target):
    """Find all pairs that sum to target"""
    # Your code here
    pass

# Bonus 5 ⭐⭐⭐
# Sliding window maximum
def sliding_window_max(numbers, k):
    """Find max in each window of size k"""
    # Your code here
    pass

print("\n" + "=" * 60)
print("EXERCISES COMPLETE!")
print("Check 04_solutions.py for answers")
print("=" * 60)
