"""
SOLUTIONS - Lists
=================

Solutions to all exercises in 03_exercises.py
"""

# =============================================================================
# SECTION 1: LIST BASICS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 1: LIST BASICS - SOLUTIONS")
print("=" * 60)

# Exercise 1.1 Solution
def exercise_1_1():
    movies = ["The Matrix", "Inception", "Interstellar", "The Shawshank Redemption", "Pulp Fiction"]
    print(f"Favorite movies: {movies}")

exercise_1_1()

# Exercise 1.2 Solution
def exercise_1_2():
    numbers = [10, 20, 30, 40, 50]
    print(f"First: {numbers[0]}")
    print(f"Last: {numbers[-1]}")
    print(f"Middle: {numbers[len(numbers)//2]}")

exercise_1_2()

# Exercise 1.3 Solution
def exercise_1_3():
    fruits = ["apple", "banana", "cherry", "date"]
    fruits.append("grape")
    fruits.insert(2, "blueberry")
    fruits.remove("banana")
    print(f"Result: {fruits}")

exercise_1_3()

# Exercise 1.4 Solution
def exercise_1_4():
    numbers = [1, 2, 3, 4, 5]
    reversed_list = []
    for i in range(len(numbers) - 1, -1, -1):
        reversed_list.append(numbers[i])
    print(f"Reversed: {reversed_list}")

exercise_1_4()

# Exercise 1.5 Solution
def exercise_1_5():
    numbers = [23, 45, 67, 12, 89, 34, 56, 78, 90, 11]
    print(f"Sum: {sum(numbers)}")
    print(f"Average: {sum(numbers) / len(numbers)}")
    print(f"Max: {max(numbers)}")
    print(f"Min: {min(numbers)}")

exercise_1_5()
print()

# =============================================================================
# SECTION 2: LIST SLICING - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 2: LIST SLICING - SOLUTIONS")
print("=" * 60)

# Exercise 2.1 Solution
def exercise_2_1():
    numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    print(f"First 3: {numbers[:3]}")
    print(f"Last 3: {numbers[-3:]}")
    print(f"Every 2nd: {numbers[::2]}")

exercise_2_1()

# Exercise 2.2 Solution
def exercise_2_2():
    letters = ['a', 'b', 'c', 'd', 'e']
    reversed_letters = letters[::-1]
    print(f"Reversed: {reversed_letters}")

exercise_2_2()

# Exercise 2.3 Solution
def exercise_2_3():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    mid = len(numbers) // 2
    first_half = numbers[:mid]
    second_half = numbers[mid:]
    print(f"First half: {first_half}")
    print(f"Second half: {second_half}")

exercise_2_3()

# Exercise 2.4 Solution
def exercise_2_4():
    numbers = list(range(20))
    result = numbers[1::3]
    print(f"Every 3rd from index 1: {result}")

exercise_2_4()
print()

# =============================================================================
# SECTION 3: LIST METHODS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 3: LIST METHODS - SOLUTIONS")
print("=" * 60)

# Exercise 3.1 Solution
def exercise_3_1():
    numbers = [64, 34, 25, 12, 22, 11, 90]
    numbers.sort()
    print(f"Ascending: {numbers}")
    numbers.sort(reverse=True)
    print(f"Descending: {numbers}")

exercise_3_1()

# Exercise 3.2 Solution
def exercise_3_2():
    numbers = [1, 2, 3, 2, 4, 3, 5, 1, 6]
    unique = list(dict.fromkeys(numbers))
    print(f"No duplicates: {unique}")

exercise_3_2()

# Exercise 3.3 Solution
def exercise_3_3():
    items = ["apple", "banana", "apple", "cherry", "banana", "apple"]
    counts = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    print(f"Counts: {counts}")

exercise_3_3()

# Exercise 3.4 Solution
def exercise_3_4(lst, n):
    n = n % len(lst) if lst else 0
    return lst[-n:] + lst[:-n] if n else lst

print(f"Rotated: {exercise_3_4([1, 2, 3, 4, 5], 2)}")
print()

# =============================================================================
# SECTION 4: LIST COMPREHENSIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 4: LIST COMPREHENSIONS - SOLUTIONS")
print("=" * 60)

# Exercise 4.1 Solution
def exercise_4_1():
    squares = [x**2 for x in range(1, 11)]
    print(f"Squares: {squares}")

exercise_4_1()

# Exercise 4.2 Solution
def exercise_4_2():
    evens = [x for x in range(1, 21) if x % 2 == 0]
    print(f"Evens: {evens}")

exercise_4_2()

# Exercise 4.3 Solution
def exercise_4_3():
    words = ["hello", "world", "python", "programming"]
    uppercase = [word.upper() for word in words]
    print(f"Uppercase: {uppercase}")

exercise_4_3()

# Exercise 4.4 Solution
def exercise_4_4():
    numbers = [23, 67, 45, 89, 12, 56, 78, 34, 90, 11]
    greater_50 = [n for n in numbers if n > 50]
    print(f"Greater than 50: {greater_50}")

exercise_4_4()

# Exercise 4.5 Solution
def exercise_4_5():
    result = [(x, x**2, x**3) for x in range(1, 6)]
    print(f"(n, n², n³): {result}")

exercise_4_5()

# Exercise 4.6 Solution
def exercise_4_6():
    nested = [[1, 2, 3], [4, 5], [6, 7, 8, 9]]
    flattened = [item for sublist in nested for item in sublist]
    print(f"Flattened: {flattened}")

exercise_4_6()
print()

# =============================================================================
# SECTION 5: NESTED LISTS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 5: NESTED LISTS - SOLUTIONS")
print("=" * 60)

# Exercise 5.1 Solution
def exercise_5_1():
    matrix = [[0] * 3 for _ in range(3)]
    print(f"3x3 zeros: {matrix}")

exercise_5_1()

# Exercise 5.2 Solution
def exercise_5_2():
    matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    total = sum(sum(row) for row in matrix)
    print(f"Sum: {total}")

exercise_5_2()

# Exercise 5.3 Solution
def exercise_5_3():
    matrix = [[1, 2, 3], [4, 5, 6]]
    transposed = [[row[i] for row in matrix] for i in range(len(matrix[0]))]
    print(f"Transposed: {transposed}")

exercise_5_3()

# Exercise 5.4 Solution
def exercise_5_4():
    matrix = [[1, 5, 3], [9, 2, 8], [4, 7, 6]]
    maximum = max(max(row) for row in matrix)
    print(f"Maximum: {maximum}")

exercise_5_4()
print()

# =============================================================================
# SECTION 6: SEARCHING AND FILTERING - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 6: SEARCHING AND FILTERING - SOLUTIONS")
print("=" * 60)

# Exercise 6.1 Solution
def exercise_6_1():
    numbers = [10, 20, 30, 20, 40, 20]
    index = numbers.index(20)
    print(f"First index of 20: {index}")

exercise_6_1()

# Exercise 6.2 Solution
def exercise_6_2(lst, target):
    return [i for i, x in enumerate(lst) if x == target]

print(f"All indices: {exercise_6_2([10, 20, 30, 20, 40, 20], 20)}")

# Exercise 6.3 Solution
def exercise_6_3(list1, list2):
    return [x for x in list1 if x in list2]

print(f"Common: {exercise_6_3([1, 2, 3, 4], [3, 4, 5, 6])}")

# Exercise 6.4 Solution
def exercise_6_4(numbers):
    sorted_nums = sorted(set(numbers), reverse=True)
    return sorted_nums[1] if len(sorted_nums) > 1 else None

print(f"Second largest: {exercise_6_4([1, 5, 3, 9, 2, 9, 8])}")
print()

# =============================================================================
# SECTION 7: REAL-WORLD APPLICATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 7: REAL-WORLD APPLICATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 7.1 Solution
def exercise_7_1():
    cart = []
    
    def add_item(name, price, quantity):
        cart.append({"name": name, "price": price, "quantity": quantity})
    
    def calculate_total():
        return sum(item["price"] * item["quantity"] for item in cart)
    
    add_item("Apple", 1.50, 5)
    add_item("Bread", 2.99, 2)
    print(f"Cart: {cart}")
    print(f"Total: ${calculate_total():.2f}")

exercise_7_1()

# Exercise 7.2 Solution
def exercise_7_2():
    scores = [85, 92, 78, 90, 88]
    
    average = sum(scores) / len(scores)
    highest = max(scores)
    lowest = min(scores)
    
    def letter_grade(avg):
        if avg >= 90: return 'A'
        elif avg >= 80: return 'B'
        elif avg >= 70: return 'C'
        elif avg >= 60: return 'D'
        else: return 'F'
    
    print(f"Average: {average:.1f} ({letter_grade(average)})")
    print(f"Highest: {highest}, Lowest: {lowest}")
    
    # Drop lowest
    scores_copy = scores.copy()
    scores_copy.remove(lowest)
    new_avg = sum(scores_copy) / len(scores_copy)
    print(f"Without lowest: {new_avg:.1f}")

exercise_7_2()

# Exercise 7.3 Solution
def exercise_7_3():
    contacts = []
    
    def add_contact(name, phone, email):
        contacts.append({"name": name, "phone": phone, "email": email})
    
    def search(name):
        return [c for c in contacts if name.lower() in c["name"].lower()]
    
    add_contact("Alice", "555-1234", "alice@email.com")
    add_contact("Bob", "555-5678", "bob@email.com")
    
    print(f"Found: {search('alice')}")

exercise_7_3()

# Exercise 7.4 Solution
def exercise_7_4():
    tasks = []
    
    def add_task(name, priority):
        tasks.append({"name": name, "priority": priority, "done": False})
    
    def sort_by_priority():
        priority_map = {"high": 0, "medium": 1, "low": 2}
        tasks.sort(key=lambda x: priority_map[x["priority"]])
    
    add_task("Task 1", "high")
    add_task("Task 2", "low")
    add_task("Task 3", "medium")
    
    sort_by_priority()
    print(f"Sorted tasks: {[t['name'] for t in tasks]}")

exercise_7_4()
print()

# =============================================================================
# BONUS CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("BONUS CHALLENGES - SOLUTIONS")
print("=" * 60)

# Bonus 1 Solution
def merge_sorted_lists(list1, list2):
    result = []
    i = j = 0
    while i < len(list1) and j < len(list2):
        if list1[i] <= list2[j]:
            result.append(list1[i])
            i += 1
        else:
            result.append(list2[j])
            j += 1
    result.extend(list1[i:])
    result.extend(list2[j:])
    return result

print(f"Merged: {merge_sorted_lists([1, 3, 5], [2, 4, 6])}")

# Bonus 2 Solution
def longest_increasing_subsequence(numbers):
    if not numbers:
        return 0
    dp = [1] * len(numbers)
    for i in range(1, len(numbers)):
        for j in range(i):
            if numbers[i] > numbers[j]:
                dp[i] = max(dp[i], dp[j] + 1)
    return max(dp)

print(f"LIS length: {longest_increasing_subsequence([1, 3, 2, 4, 5])}")

# Bonus 3 Solution
def move_zeros(numbers):
    non_zero = [x for x in numbers if x != 0]
    zeros = [0] * (len(numbers) - len(non_zero))
    return non_zero + zeros

print(f"Zeros moved: {move_zeros([1, 0, 2, 0, 3])}")

# Bonus 4 Solution
def find_pairs_sum(numbers, target):
    pairs = []
    seen = set()
    for num in numbers:
        complement = target - num
        if complement in seen:
            pairs.append((complement, num))
        seen.add(num)
    return pairs

print(f"Pairs that sum to 10: {find_pairs_sum([1, 2, 3, 4, 5, 6, 7, 8, 9], 10)}")

# Bonus 5 Solution
def sliding_window_max(numbers, k):
    if not numbers or k <= 0:
        return []
    result = []
    for i in range(len(numbers) - k + 1):
        window = numbers[i:i+k]
        result.append(max(window))
    return result

print(f"Sliding max: {sliding_window_max([1, 3, 2, 5, 8, 1], 3)}")

print("\n" + "=" * 60)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 60)
