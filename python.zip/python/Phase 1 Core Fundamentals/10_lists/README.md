# Lists - Python Data Structure

## Overview
This module covers Python lists - one of the most versatile and commonly used data structures in Python.

## Contents
- **01_lists_tutorial.py** - Complete guide to Python lists
- **02_examples.py** - Practical examples using lists
- **03_exercises.py** - Practice problems (try these first!)
- **04_solutions.py** - Solutions to the exercises

## Learning Objectives
By the end of this module, you should be able to:
- Create and manipulate lists
- Use list methods effectively (append, insert, remove, sort, etc.)
- Apply slicing and indexing techniques
- Master list comprehensions
- Iterate through lists efficiently
- Work with nested lists
- Understand when to use lists vs other data structures

## Recommended Learning Path
1. Read through `01_lists_tutorial.py`
2. Study the examples in `02_examples.py`
3. Attempt the exercises in `03_exercises.py`
4. Check your solutions against `04_solutions.py`

## Quick Reference

### Creating Lists
```python
empty_list = []
numbers = [1, 2, 3, 4, 5]
mixed = [1, "hello", 3.14, True]
```

### Common Operations
```python
# Access
first = my_list[0]
last = my_list[-1]

# Slice
first_three = my_list[:3]

# Modify
my_list[0] = 10
my_list.append(6)

# Methods
my_list.sort()
my_list.reverse()
my_list.remove(value)
```

### List Comprehension
```python
squares = [x**2 for x in range(10)]
evens = [x for x in range(20) if x % 2 == 0]
```

## Key Features
- **Ordered** - maintains insertion order
- **Mutable** - can be modified after creation
- **Indexable** - access by position
- **Allows duplicates** - same value can appear multiple times
- **Dynamic size** - grows/shrinks as needed

Happy learning!
