"""
PRACTICAL EXAMPLES - Tuples
============================

Real-world examples demonstrating when and how to use tuples.
"""

# =============================================================================
# EXAMPLE 1: Geographical Coordinates
# =============================================================================

print("=" * 60)
print("EXAMPLE 1: Geographical Coordinates")
print("=" * 60)

# Tuples are perfect for coordinates - they shouldn't change
cities = {
    "New York": (40.7128, -74.0060),
    "London": (51.5074, -0.1278),
    "Tokyo": (35.6762, 139.6503),
    "Sydney": (-33.8688, 151.2093),
    "Paris": (48.8566, 2.3522)
}

def calculate_distance(coord1, coord2):
    """Simplified distance calculation"""
    import math
    lat1, lon1 = coord1
    lat2, lon2 = coord2
    return math.sqrt((lat2 - lat1)**2 + (lon2 - lon1)**2)

# Find distances from New York
ny_coords = cities["New York"]
print(f"Distances from New York:")
for city, coords in cities.items():
    if city != "New York":
        distance = calculate_distance(ny_coords, coords)
        print(f"  {city}: {distance:.2f} degrees")
print()

# =============================================================================
# EXAMPLE 2: RGB Color Library
# =============================================================================

print("=" * 60)
print("EXAMPLE 2: RGB Color Library")
print("=" * 60)

# Tuples for immutable RGB values
COLORS = {
    "RED": (255, 0, 0),
    "GREEN": (0, 255, 0),
    "BLUE": (0, 0, 255),
    "YELLOW": (255, 255, 0),
    "PURPLE": (128, 0, 128),
    "ORANGE": (255, 165, 0),
    "BLACK": (0, 0, 0),
    "WHITE": (255, 255, 255)
}

def mix_colors(color1, color2):
    """Mix two RGB colors by averaging"""
    r1, g1, b1 = color1
    r2, g2, b2 = color2
    return ((r1 + r2) // 2, (g1 + g2) // 2, (b1 + b2) // 2)

def color_to_hex(rgb):
    """Convert RGB tuple to hex string"""
    r, g, b = rgb
    return f"#{r:02x}{g:02x}{b:02x}"

def is_dark(rgb):
    """Check if color is dark (brightness < 128)"""
    r, g, b = rgb
    brightness = (r + g + b) / 3
    return brightness < 128

# Mix colors
red = COLORS["RED"]
blue = COLORS["BLUE"]
purple = mix_colors(red, blue)

print(f"Red: {red} -> {color_to_hex(red)}")
print(f"Blue: {blue} -> {color_to_hex(blue)}")
print(f"Mixed (Purple): {purple} -> {color_to_hex(purple)}")
print(f"Is purple dark? {is_dark(purple)}")
print()

# =============================================================================
# EXAMPLE 3: Database Records
# =============================================================================

print("=" * 60)
print("EXAMPLE 3: Database Records")
print("=" * 60)

from collections import namedtuple

# Define record structure using named tuple
Employee = namedtuple('Employee', ['id', 'name', 'department', 'salary'])
Product = namedtuple('Product', ['sku', 'name', 'price', 'stock'])

# Create employee records
employees = [
    Employee(1, "Alice Johnson", "Engineering", 85000),
    Employee(2, "Bob Smith", "Marketing", 65000),
    Employee(3, "Charlie Brown", "Engineering", 90000),
    Employee(4, "Diana Prince", "HR", 70000),
    Employee(5, "Eve Wilson", "Engineering", 95000)
]

# Query functions
def get_by_department(employees, dept):
    return [emp for emp in employees if emp.department == dept]

def get_average_salary(employees):
    return sum(emp.salary for emp in employees) / len(employees)

def get_highest_paid(employees):
    return max(employees, key=lambda emp: emp.salary)

def get_salary_range(employees):
    salaries = [emp.salary for emp in employees]
    return (min(salaries), max(salaries))

# Run queries
engineering = get_by_department(employees, "Engineering")
print(f"Engineering employees:")
for emp in engineering:
    print(f"  {emp.name}: ${emp.salary:,}")

print(f"\nAverage salary: ${get_average_salary(employees):,.2f}")

top_earner = get_highest_paid(employees)
print(f"Highest paid: {top_earner.name} (${top_earner.salary:,})")

min_sal, max_sal = get_salary_range(employees)
print(f"Salary range: ${min_sal:,} - ${max_sal:,}")
print()

# =============================================================================
# EXAMPLE 4: Function Return Values
# =============================================================================

print("=" * 60)
print("EXAMPLE 4: Multiple Return Values")
print("=" * 60)

def analyze_text(text):
    """Analyze text and return multiple values as tuple"""
    words = text.split()
    chars = len(text)
    word_count = len(words)
    avg_word_length = sum(len(word) for word in words) / word_count if word_count > 0 else 0
    unique_words = len(set(words))
    
    # Return multiple values as tuple
    return word_count, chars, avg_word_length, unique_words

# Unpack the return tuple
text = "Python is an amazing programming language for beginners and experts"
words, chars, avg_length, unique = analyze_text(text)

print(f"Text: '{text}'")
print(f"Words: {words}")
print(f"Characters: {chars}")
print(f"Average word length: {avg_length:.2f}")
print(f"Unique words: {unique}")

# Can also use named tuple for clarity
from collections import namedtuple
TextStats = namedtuple('TextStats', ['words', 'chars', 'avg_length', 'unique'])

def analyze_text_named(text):
    words = text.split()
    chars = len(text)
    word_count = len(words)
    avg_word_length = sum(len(word) for word in words) / word_count if word_count > 0 else 0
    unique_words = len(set(words))
    return TextStats(word_count, chars, avg_word_length, unique_words)

stats = analyze_text_named(text)
print(f"\nUsing named tuple: {stats.words} words, {stats.chars} chars")
print()

# =============================================================================
# EXAMPLE 5: Configuration Settings
# =============================================================================

print("=" * 60)
print("EXAMPLE 5: Configuration Settings")
print("=" * 60)

# Using tuples for immutable configuration
ServerConfig = namedtuple('ServerConfig', ['host', 'port', 'ssl', 'timeout'])
DatabaseConfig = namedtuple('DatabaseConfig', ['host', 'port', 'name', 'pool_size'])

# Create configurations
server = ServerConfig(
    host='localhost',
    port=8080,
    ssl=True,
    timeout=30
)

database = DatabaseConfig(
    host='db.example.com',
    port=5432,
    name='myapp',
    pool_size=10
)

def print_config(config):
    """Print configuration settings"""
    print(f"{type(config).__name__}:")
    for field, value in config._asdict().items():
        print(f"  {field}: {value}")

print_config(server)
print()
print_config(database)
print()

# =============================================================================
# EXAMPLE 6: Date and Time Representation
# =============================================================================

print("=" * 60)
print("EXAMPLE 6: Date and Time Representation")
print("=" * 60)

Date = namedtuple('Date', ['year', 'month', 'day'])
Time = namedtuple('Time', ['hour', 'minute', 'second'])
DateTime = namedtuple('DateTime', ['date', 'time'])

def format_date(date):
    """Format date as YYYY-MM-DD"""
    return f"{date.year:04d}-{date.month:02d}-{date.day:02d}"

def format_time(time):
    """Format time as HH:MM:SS"""
    return f"{time.hour:02d}:{time.minute:02d}:{time.second:02d}"

def is_leap_year(year):
    """Check if year is a leap year"""
    return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

# Create dates
birthday = Date(1990, 5, 15)
meeting_time = Time(14, 30, 0)
meeting = DateTime(Date(2024, 11, 4), Time(14, 30, 0))

print(f"Birthday: {format_date(birthday)}")
print(f"Meeting time: {format_time(meeting_time)}")
print(f"Full meeting: {format_date(meeting.date)} {format_time(meeting.time)}")
print(f"Is 2024 a leap year? {is_leap_year(2024)}")
print()

# =============================================================================
# EXAMPLE 7: Graph/Network Edges
# =============================================================================

print("=" * 60)
print("EXAMPLE 7: Graph Edges (Network)")
print("=" * 60)

# Edges as tuples (immutable connections)
edges = [
    ('A', 'B'),
    ('A', 'C'),
    ('B', 'D'),
    ('C', 'D'),
    ('C', 'E'),
    ('D', 'E')
]

def build_graph(edges):
    """Build adjacency list from edges"""
    graph = {}
    for source, target in edges:
        if source not in graph:
            graph[source] = []
        if target not in graph:
            graph[target] = []
        graph[source].append(target)
        graph[target].append(source)  # Undirected graph
    return graph

def get_neighbors(graph, node):
    """Get all neighbors of a node"""
    return graph.get(node, [])

def count_edges(edges):
    """Count total edges"""
    return len(edges)

graph = build_graph(edges)
print("Graph structure:")
for node, neighbors in sorted(graph.items()):
    print(f"  {node} -> {neighbors}")

print(f"\nNeighbors of C: {get_neighbors(graph, 'C')}")
print(f"Total edges: {count_edges(edges)}")
print()

# =============================================================================
# EXAMPLE 8: Mathematical Points and Vectors
# =============================================================================

print("=" * 60)
print("EXAMPLE 8: Points and Vectors")
print("=" * 60)

Point2D = namedtuple('Point2D', ['x', 'y'])
Point3D = namedtuple('Point3D', ['x', 'y', 'z'])

def distance_2d(p1, p2):
    """Calculate distance between two 2D points"""
    import math
    dx = p2.x - p1.x
    dy = p2.y - p1.y
    return math.sqrt(dx**2 + dy**2)

def midpoint_2d(p1, p2):
    """Find midpoint between two 2D points"""
    return Point2D((p1.x + p2.x) / 2, (p1.y + p2.y) / 2)

def translate(point, dx, dy):
    """Translate point by dx, dy"""
    return Point2D(point.x + dx, point.y + dy)

# Create points
p1 = Point2D(0, 0)
p2 = Point2D(3, 4)

print(f"Point 1: {p1}")
print(f"Point 2: {p2}")
print(f"Distance: {distance_2d(p1, p2):.2f}")
print(f"Midpoint: {midpoint_2d(p1, p2)}")
print(f"P1 translated by (5, 5): {translate(p1, 5, 5)}")
print()

# =============================================================================
# EXAMPLE 9: Game Development - Tile Positions
# =============================================================================

print("=" * 60)
print("EXAMPLE 9: Game Tile Map")
print("=" * 60)

# Tile map using tuples for positions (immutable coordinates)
tile_map = {
    (0, 0): "grass",
    (0, 1): "grass",
    (0, 2): "water",
    (1, 0): "grass",
    (1, 1): "tree",
    (1, 2): "water",
    (2, 0): "mountain",
    (2, 1): "grass",
    (2, 2): "grass"
}

def get_tile(position):
    """Get tile type at position"""
    return tile_map.get(position, "unknown")

def get_neighbors(position):
    """Get neighboring positions"""
    x, y = position
    neighbors = [
        (x-1, y), (x+1, y),  # left, right
        (x, y-1), (x, y+1)   # up, down
    ]
    return [(pos, get_tile(pos)) for pos in neighbors if pos in tile_map]

def display_map():
    """Display the tile map"""
    for y in range(3):
        for x in range(3):
            tile = get_tile((x, y))
            print(f"{tile:10}", end="")
        print()

print("Tile Map:")
display_map()
print(f"\nTile at (1, 1): {get_tile((1, 1))}")
print(f"Neighbors of (1, 1): {get_neighbors((1, 1))}")
print()

print("=" * 60)
print("EXAMPLES COMPLETE!")
print("=" * 60)
