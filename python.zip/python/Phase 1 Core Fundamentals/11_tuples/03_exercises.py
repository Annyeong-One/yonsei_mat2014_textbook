"""
EXERCISES - Tuples
==================

Practice problems to master Python tuples. Solutions are in 04_solutions.py
Try to solve these on your own first!

Difficulty levels: ⭐ Easy | ⭐⭐ Medium | ⭐⭐⭐ Hard
"""

# =============================================================================
# SECTION 1: TUPLE BASICS
# =============================================================================

print("=" * 60)
print("SECTION 1: TUPLE BASICS")
print("=" * 60)

# Exercise 1.1 ⭐
# Create a tuple with 5 different data types
def exercise_1_1():
    # Your code here
    pass

# Exercise 1.2 ⭐
# Create a single-element tuple (don't forget the comma!)
def exercise_1_2():
    # Your code here
    pass

# Exercise 1.3 ⭐
# Access first, last, and middle element from a tuple
def exercise_1_3():
    numbers = (10, 20, 30, 40, 50)
    # Your code here
    pass

# Exercise 1.4 ⭐
# Try to modify a tuple element and handle the error
def exercise_1_4():
    numbers = (1, 2, 3, 4, 5)
    # Your code here - try to change numbers[0] and catch the error
    pass

# Exercise 1.5 ⭐
# Count occurrences and find index
def exercise_1_5():
    numbers = (1, 2, 3, 2, 4, 2, 5)
    # Count how many 2s and find first index of 2
    # Your code here
    pass

# =============================================================================
# SECTION 2: TUPLE UNPACKING
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 2: TUPLE UNPACKING")
print("=" * 60)

# Exercise 2.1 ⭐
# Unpack a tuple into separate variables
def exercise_2_1():
    person = ("Alice", 25, "Engineer", "New York")
    # Unpack into name, age, job, city
    # Your code here
    pass

# Exercise 2.2 ⭐
# Swap two variables using tuple unpacking
def exercise_2_2():
    a = 10
    b = 20
    # Swap them
    # Your code here
    pass

# Exercise 2.3 ⭐⭐
# Use extended unpacking with *
def exercise_2_3():
    numbers = (1, 2, 3, 4, 5, 6, 7)
    # Get first, last, and everything in between
    # Your code here
    pass

# Exercise 2.4 ⭐⭐
# Unpack nested tuples
def exercise_2_4():
    data = ((1, 2), (3, 4), (5, 6))
    # Unpack to get all individual numbers
    # Your code here
    pass

# =============================================================================
# SECTION 3: TUPLE OPERATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 3: TUPLE OPERATIONS")
print("=" * 60)

# Exercise 3.1 ⭐
# Concatenate two tuples
def exercise_3_1():
    tuple1 = (1, 2, 3)
    tuple2 = (4, 5, 6)
    # Your code here
    pass

# Exercise 3.2 ⭐
# Repeat a tuple 3 times
def exercise_3_2():
    numbers = (1, 2, 3)
    # Your code here
    pass

# Exercise 3.3 ⭐
# Check if element exists in tuple
def exercise_3_3():
    fruits = ("apple", "banana", "cherry")
    # Check if "banana" is in the tuple
    # Your code here
    pass

# Exercise 3.4 ⭐⭐
# Find min, max, and sum of numeric tuple
def exercise_3_4():
    numbers = (45, 23, 67, 12, 89, 34)
    # Your code here
    pass

# Exercise 3.5 ⭐⭐
# Compare two tuples
def exercise_3_5():
    tuple1 = (1, 2, 3)
    tuple2 = (1, 2, 4)
    # Which is greater? (lexicographic comparison)
    # Your code here
    pass

# =============================================================================
# SECTION 4: CONVERTING BETWEEN LISTS AND TUPLES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 4: CONVERTING BETWEEN LISTS AND TUPLES")
print("=" * 60)

# Exercise 4.1 ⭐
# Convert tuple to list, modify it, convert back
def exercise_4_1():
    numbers = (1, 2, 3, 4, 5)
    # Add 6, 7, 8 to the tuple
    # Your code here
    pass

# Exercise 4.2 ⭐⭐
# Create a tuple from a string
def exercise_4_2():
    text = "hello"
    # Convert to tuple of characters
    # Your code here
    pass

# Exercise 4.3 ⭐⭐
# Remove duplicates from a tuple
def exercise_4_3():
    numbers = (1, 2, 2, 3, 3, 3, 4, 5, 5)
    # Remove duplicates (hint: use set, then back to tuple)
    # Your code here
    pass

# =============================================================================
# SECTION 5: NAMED TUPLES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 5: NAMED TUPLES")
print("=" * 60)

# Exercise 5.1 ⭐⭐
# Create a Point named tuple and use it
def exercise_5_1():
    from collections import namedtuple
    # Create Point with x and y
    # Create a point (10, 20)
    # Access both by index and by name
    # Your code here
    pass

# Exercise 5.2 ⭐⭐
# Create a Book named tuple
def exercise_5_2():
    from collections import namedtuple
    # Create Book with title, author, year, pages
    # Create 3 book instances
    # Your code here
    pass

# Exercise 5.3 ⭐⭐⭐
# Use named tuple _replace method
def exercise_5_3():
    from collections import namedtuple
    Person = namedtuple('Person', ['name', 'age', 'city'])
    person = Person('Alice', 30, 'NYC')
    # Create a new person with age = 31 using _replace
    # Your code here
    pass

# =============================================================================
# SECTION 6: TUPLES AS DICTIONARY KEYS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 6: TUPLES AS DICTIONARY KEYS")
print("=" * 60)

# Exercise 6.1 ⭐⭐
# Create a dictionary with coordinate tuples as keys
def exercise_6_1():
    # Create a grid where keys are (x, y) coordinates
    # and values are terrain types ("Land", "Water", "Mountain")
    # Your code here
    pass

# Exercise 6.2 ⭐⭐⭐
# Store and lookup data using tuple keys
def exercise_6_2():
    # Create a grade book where keys are (student, subject) tuples
    # Store at least 4 grades
    # Look up specific grades
    # Your code here
    pass

# =============================================================================
# SECTION 7: FUNCTIONS RETURNING TUPLES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 7: FUNCTIONS RETURNING TUPLES")
print("=" * 60)

# Exercise 7.1 ⭐⭐
# Create a function that returns min, max, and average
def exercise_7_1(numbers):
    # Return (min, max, average) as tuple
    # Your code here
    pass

# Exercise 7.2 ⭐⭐
# Create a function that returns (quotient, remainder)
def exercise_7_2(a, b):
    # Return division result as tuple
    # Your code here
    pass

# Exercise 7.3 ⭐⭐⭐
# Create a function that analyzes a string
def exercise_7_3(text):
    """
    Return (word_count, char_count, unique_words, avg_word_length)
    """
    # Your code here
    pass

# =============================================================================
# SECTION 8: REAL-WORLD APPLICATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 8: REAL-WORLD APPLICATIONS")
print("=" * 60)

# Exercise 8.1 ⭐⭐⭐
# RGB Color Mixer
def exercise_8_1():
    """
    Create functions to:
    - Mix two RGB tuples (average each component)
    - Convert RGB tuple to hex string
    - Check if color is light or dark
    """
    # Your code here
    pass

# Exercise 8.2 ⭐⭐⭐
# Coordinate System
def exercise_8_2():
    """
    Create functions for 2D points (as tuples):
    - Calculate distance between two points
    - Find midpoint
    - Check if point is in a rectangle (given by two corner points)
    """
    # Your code here
    pass

# Exercise 8.3 ⭐⭐⭐
# Database-style records
def exercise_8_3():
    """
    Create employee records using named tuples:
    - Store list of employees
    - Find employees by department
    - Calculate average salary
    - Find highest paid employee
    """
    # Your code here
    pass

# Exercise 8.4 ⭐⭐⭐
# Date operations
def exercise_8_4():
    """
    Create a Date named tuple (year, month, day):
    - Check if date is valid
    - Compare two dates
    - Check if year is leap year
    - Format date as string
    """
    # Your code here
    pass

# =============================================================================
# BONUS CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("BONUS CHALLENGES")
print("=" * 60)

# Bonus 1 ⭐⭐⭐
# Flatten nested tuples
def flatten_tuple(nested):
    """
    Flatten a nested tuple structure
    ((1, 2), (3, 4), (5, 6)) -> (1, 2, 3, 4, 5, 6)
    """
    # Your code here
    pass

# Bonus 2 ⭐⭐⭐
# Rotate tuple elements
def rotate_tuple(t, n):
    """
    Rotate tuple by n positions
    (1, 2, 3, 4, 5) rotated by 2 -> (4, 5, 1, 2, 3)
    """
    # Your code here
    pass

# Bonus 3 ⭐⭐⭐
# Tuple-based immutable configuration
class Config:
    """
    Create an immutable configuration class using tuples
    Should raise error if you try to modify settings
    """
    # Your code here
    pass

# Bonus 4 ⭐⭐⭐
# Matrix operations with nested tuples
def transpose_matrix(matrix):
    """
    Transpose a matrix represented as nested tuples
    ((1, 2, 3), (4, 5, 6)) -> ((1, 4), (2, 5), (3, 6))
    """
    # Your code here
    pass

# Bonus 5 ⭐⭐⭐
# Create a immutable Point class
class Point:
    """
    Create a Point class using __slots__ and making it immutable
    Should behave like a tuple but with x, y attributes
    """
    # Your code here
    pass

print("\n" + "=" * 60)
print("EXERCISES COMPLETE!")
print("Check 04_solutions.py for answers")
print("=" * 60)
