"""
SOLUTIONS - Tuples
==================

Solutions to all exercises in 03_exercises.py
"""

from collections import namedtuple

# =============================================================================
# SECTION 1: TUPLE BASICS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 1: TUPLE BASICS - SOLUTIONS")
print("=" * 60)

# Exercise 1.1 Solution
def exercise_1_1():
    mixed = (42, "hello", 3.14, True, [1, 2, 3])
    print(f"Mixed tuple: {mixed}")
    for i, element in enumerate(mixed):
        print(f"  Element {i}: {element} (type: {type(element).__name__})")

exercise_1_1()

# Exercise 1.2 Solution
def exercise_1_2():
    single = (5,)  # Note the comma!
    not_tuple = (5)
    print(f"Single tuple: {single}, type: {type(single)}")
    print(f"Not tuple: {not_tuple}, type: {type(not_tuple)}")

exercise_1_2()

# Exercise 1.3 Solution
def exercise_1_3():
    numbers = (10, 20, 30, 40, 50)
    print(f"First: {numbers[0]}")
    print(f"Last: {numbers[-1]}")
    print(f"Middle: {numbers[len(numbers)//2]}")

exercise_1_3()

# Exercise 1.4 Solution
def exercise_1_4():
    numbers = (1, 2, 3, 4, 5)
    try:
        numbers[0] = 10
    except TypeError as e:
        print(f"Cannot modify tuple: {e}")

exercise_1_4()

# Exercise 1.5 Solution
def exercise_1_5():
    numbers = (1, 2, 3, 2, 4, 2, 5)
    count = numbers.count(2)
    index = numbers.index(2)
    print(f"Count of 2: {count}")
    print(f"First index of 2: {index}")

exercise_1_5()
print()

# =============================================================================
# SECTION 2: TUPLE UNPACKING - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 2: TUPLE UNPACKING - SOLUTIONS")
print("=" * 60)

# Exercise 2.1 Solution
def exercise_2_1():
    person = ("Alice", 25, "Engineer", "New York")
    name, age, job, city = person
    print(f"Name: {name}, Age: {age}, Job: {job}, City: {city}")

exercise_2_1()

# Exercise 2.2 Solution
def exercise_2_2():
    a, b = 10, 20
    print(f"Before: a={a}, b={b}")
    a, b = b, a
    print(f"After swap: a={a}, b={b}")

exercise_2_2()

# Exercise 2.3 Solution
def exercise_2_3():
    numbers = (1, 2, 3, 4, 5, 6, 7)
    first, *middle, last = numbers
    print(f"First: {first}, Middle: {middle}, Last: {last}")

exercise_2_3()

# Exercise 2.4 Solution
def exercise_2_4():
    data = ((1, 2), (3, 4), (5, 6))
    for a, b in data:
        print(f"  Unpacked: {a}, {b}")

exercise_2_4()
print()

# =============================================================================
# SECTION 3: TUPLE OPERATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 3: TUPLE OPERATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 3.1 Solution
def exercise_3_1():
    tuple1 = (1, 2, 3)
    tuple2 = (4, 5, 6)
    combined = tuple1 + tuple2
    print(f"Concatenated: {combined}")

exercise_3_1()

# Exercise 3.2 Solution
def exercise_3_2():
    numbers = (1, 2, 3)
    repeated = numbers * 3
    print(f"Repeated: {repeated}")

exercise_3_2()

# Exercise 3.3 Solution
def exercise_3_3():
    fruits = ("apple", "banana", "cherry")
    print(f"'banana' in fruits: {'banana' in fruits}")

exercise_3_3()

# Exercise 3.4 Solution
def exercise_3_4():
    numbers = (45, 23, 67, 12, 89, 34)
    print(f"Min: {min(numbers)}, Max: {max(numbers)}, Sum: {sum(numbers)}")

exercise_3_4()

# Exercise 3.5 Solution
def exercise_3_5():
    tuple1 = (1, 2, 3)
    tuple2 = (1, 2, 4)
    print(f"{tuple1} < {tuple2}: {tuple1 < tuple2}")

exercise_3_5()
print()

# =============================================================================
# SECTION 4: CONVERTING - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 4: CONVERTING - SOLUTIONS")
print("=" * 60)

# Exercise 4.1 Solution
def exercise_4_1():
    numbers = (1, 2, 3, 4, 5)
    temp = list(numbers)
    temp.extend([6, 7, 8])
    numbers = tuple(temp)
    print(f"Result: {numbers}")

exercise_4_1()

# Exercise 4.2 Solution
def exercise_4_2():
    text = "hello"
    char_tuple = tuple(text)
    print(f"Tuple: {char_tuple}")

exercise_4_2()

# Exercise 4.3 Solution
def exercise_4_3():
    numbers = (1, 2, 2, 3, 3, 3, 4, 5, 5)
    unique = tuple(set(numbers))
    print(f"Unique: {unique}")

exercise_4_3()
print()

# =============================================================================
# SECTION 5: NAMED TUPLES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 5: NAMED TUPLES - SOLUTIONS")
print("=" * 60)

# Exercise 5.1 Solution
def exercise_5_1():
    Point = namedtuple('Point', ['x', 'y'])
    p = Point(10, 20)
    print(f"By index: x={p[0]}, y={p[1]}")
    print(f"By name: x={p.x}, y={p.y}")

exercise_5_1()

# Exercise 5.2 Solution
def exercise_5_2():
    Book = namedtuple('Book', ['title', 'author', 'year', 'pages'])
    books = [
        Book("1984", "George Orwell", 1949, 328),
        Book("To Kill a Mockingbird", "Harper Lee", 1960, 324),
        Book("The Great Gatsby", "F. Scott Fitzgerald", 1925, 180)
    ]
    for book in books:
        print(f"  {book.title} by {book.author}")

exercise_5_2()

# Exercise 5.3 Solution
def exercise_5_3():
    Person = namedtuple('Person', ['name', 'age', 'city'])
    person = Person('Alice', 30, 'NYC')
    new_person = person._replace(age=31)
    print(f"Original: {person}")
    print(f"Updated: {new_person}")

exercise_5_3()
print()

# =============================================================================
# SECTION 6: TUPLES AS DICTIONARY KEYS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 6: TUPLES AS DICT KEYS - SOLUTIONS")
print("=" * 60)

# Exercise 6.1 Solution
def exercise_6_1():
    grid = {
        (0, 0): "Land",
        (0, 1): "Water",
        (1, 0): "Mountain",
        (1, 1): "Land"
    }
    print("Grid:")
    for coord, terrain in grid.items():
        print(f"  {coord}: {terrain}")

exercise_6_1()

# Exercise 6.2 Solution
def exercise_6_2():
    grades = {
        ("Alice", "Math"): 95,
        ("Alice", "English"): 88,
        ("Bob", "Math"): 87,
        ("Bob", "English"): 92
    }
    print(f"Alice's Math grade: {grades[('Alice', 'Math')]}")

exercise_6_2()
print()

# =============================================================================
# SECTION 7: FUNCTIONS RETURNING TUPLES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 7: FUNCTIONS RETURNING TUPLES - SOLUTIONS")
print("=" * 60)

# Exercise 7.1 Solution
def exercise_7_1(numbers):
    return (min(numbers), max(numbers), sum(numbers) / len(numbers))

result = exercise_7_1([1, 2, 3, 4, 5])
print(f"Stats: {result}")

# Exercise 7.2 Solution
def exercise_7_2(a, b):
    return (a // b, a % b)

q, r = exercise_7_2(17, 5)
print(f"17 ÷ 5 = {q} remainder {r}")

# Exercise 7.3 Solution
def exercise_7_3(text):
    words = text.split()
    word_count = len(words)
    char_count = len(text)
    unique_words = len(set(words))
    avg_word_length = sum(len(w) for w in words) / word_count if word_count else 0
    return (word_count, char_count, unique_words, avg_word_length)

stats = exercise_7_3("hello world hello")
print(f"Text stats: {stats}")
print()

# =============================================================================
# SECTION 8: REAL-WORLD APPLICATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 8: REAL-WORLD APPLICATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 8.1 Solution
def exercise_8_1():
    def mix_colors(c1, c2):
        r1, g1, b1 = c1
        r2, g2, b2 = c2
        return ((r1+r2)//2, (g1+g2)//2, (b1+b2)//2)
    
    def to_hex(rgb):
        r, g, b = rgb
        return f"#{r:02x}{g:02x}{b:02x}"
    
    def is_dark(rgb):
        r, g, b = rgb
        return (r + g + b) / 3 < 128
    
    red = (255, 0, 0)
    blue = (0, 0, 255)
    purple = mix_colors(red, blue)
    print(f"Purple: {purple} -> {to_hex(purple)}")
    print(f"Is dark? {is_dark(purple)}")

exercise_8_1()

# Exercise 8.2 Solution
def exercise_8_2():
    import math
    
    def distance(p1, p2):
        x1, y1 = p1
        x2, y2 = p2
        return math.sqrt((x2-x1)**2 + (y2-y1)**2)
    
    def midpoint(p1, p2):
        x1, y1 = p1
        x2, y2 = p2
        return ((x1+x2)/2, (y1+y2)/2)
    
    p1 = (0, 0)
    p2 = (3, 4)
    print(f"Distance: {distance(p1, p2):.2f}")
    print(f"Midpoint: {midpoint(p1, p2)}")

exercise_8_2()

# Exercise 8.3 Solution
def exercise_8_3():
    Employee = namedtuple('Employee', ['name', 'dept', 'salary'])
    employees = [
        Employee("Alice", "IT", 85000),
        Employee("Bob", "HR", 65000),
        Employee("Charlie", "IT", 90000)
    ]
    
    it_employees = [e for e in employees if e.dept == "IT"]
    avg_salary = sum(e.salary for e in employees) / len(employees)
    highest_paid = max(employees, key=lambda e: e.salary)
    
    print(f"IT employees: {[e.name for e in it_employees]}")
    print(f"Average salary: ${avg_salary:,.2f}")
    print(f"Highest paid: {highest_paid.name}")

exercise_8_3()

# Exercise 8.4 Solution
def exercise_8_4():
    Date = namedtuple('Date', ['year', 'month', 'day'])
    
    def is_valid_date(date):
        if date.month < 1 or date.month > 12:
            return False
        days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if is_leap_year(date.year):
            days_in_month[1] = 29
        return 1 <= date.day <= days_in_month[date.month - 1]
    
    def is_leap_year(year):
        return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)
    
    date = Date(2024, 2, 29)
    print(f"Is {date} valid? {is_valid_date(date)}")
    print(f"Is 2024 leap year? {is_leap_year(2024)}")

exercise_8_4()
print()

# =============================================================================
# BONUS CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("BONUS CHALLENGES - SOLUTIONS")
print("=" * 60)

# Bonus 1 Solution
def flatten_tuple(nested):
    result = []
    for item in nested:
        if isinstance(item, tuple):
            result.extend(flatten_tuple(item))
        else:
            result.append(item)
    return tuple(result)

print(f"Flattened: {flatten_tuple(((1, 2), (3, 4), (5, 6)))}")

# Bonus 2 Solution
def rotate_tuple(t, n):
    if not t:
        return t
    n = n % len(t)
    return t[-n:] + t[:-n] if n else t

print(f"Rotated: {rotate_tuple((1, 2, 3, 4, 5), 2)}")

# Bonus 3 Solution
class Config:
    def __init__(self, **kwargs):
        self._config = tuple(sorted(kwargs.items()))
    
    def __getattr__(self, name):
        for key, value in self._config:
            if key == name:
                return value
        raise AttributeError(f"No such config: {name}")
    
    def __setattr__(self, name, value):
        if name.startswith('_'):
            super().__setattr__(name, value)
        else:
            raise AttributeError("Config is immutable")

config = Config(debug=True, port=8080)
print(f"Config debug: {config.debug}")

# Bonus 4 Solution
def transpose_matrix(matrix):
    return tuple(zip(*matrix))

matrix = ((1, 2, 3), (4, 5, 6))
print(f"Transposed: {transpose_matrix(matrix)}")

# Bonus 5 Solution
class Point:
    __slots__ = ('_x', '_y')
    
    def __init__(self, x, y):
        object.__setattr__(self, '_x', x)
        object.__setattr__(self, '_y', y)
    
    @property
    def x(self):
        return self._x
    
    @property
    def y(self):
        return self._y
    
    def __setattr__(self, name, value):
        raise AttributeError("Point is immutable")
    
    def __repr__(self):
        return f"Point({self._x}, {self._y})"

p = Point(10, 20)
print(f"Point: {p}, x={p.x}, y={p.y}")

print("\n" + "=" * 60)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 60)
