# Tuples - Python Data Structure

## Overview
This module covers Python tuples - immutable, ordered sequences that are perfect for representing fixed collections of items.

## Contents
- **01_tuples_tutorial.py** - Complete guide to Python tuples
- **02_examples.py** - Practical examples using tuples
- **03_exercises.py** - Practice problems (try these first!)
- **04_solutions.py** - Solutions to the exercises

## Learning Objectives
By the end of this module, you should be able to:
- Create and use tuples effectively
- Understand the difference between tuples and lists
- Use tuple unpacking and packing
- Work with named tuples
- Understand when to use tuples vs lists
- Use tuples as dictionary keys
- Apply tuples in real-world scenarios

## Recommended Learning Path
1. Read through `01_tuples_tutorial.py`
2. Study the examples in `02_examples.py`
3. Attempt the exercises in `03_exercises.py`
4. Check your solutions against `04_solutions.py`

## Quick Reference

### Creating Tuples
```python
empty_tuple = ()
single = (5,)  # Note the comma!
numbers = (1, 2, 3, 4, 5)
coords = 10, 20  # Parentheses optional
```

### Common Operations
```python
# Access (like lists)
first = my_tuple[0]
last = my_tuple[-1]

# Slice
first_three = my_tuple[:3]

# Cannot modify!
# my_tuple[0] = 10  # ERROR!

# Tuple methods
count = my_tuple.count(5)
index = my_tuple.index(3)

# Unpacking
x, y, z = (1, 2, 3)
```

### Named Tuples
```python
from collections import namedtuple
Point = namedtuple('Point', ['x', 'y'])
p = Point(10, 20)
print(p.x, p.y)
```

## Key Features
- **Immutable** - cannot be modified after creation
- **Ordered** - maintains insertion order
- **Faster than lists** - slightly better performance
- **Hashable** - can be used as dictionary keys
- **Less memory** - smaller footprint than lists

## Tuples vs Lists

Use **TUPLES** when:
- Data should not change (coordinates, RGB colors, dates)
- You need a hashable collection (dict keys)
- Returning multiple values from functions
- Performance matters slightly

Use **LISTS** when:
- Data needs to be modified
- You need list methods (append, remove, sort)
- Order changes frequently

Happy learning!
