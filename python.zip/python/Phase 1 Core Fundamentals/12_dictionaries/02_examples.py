"""
PRACTICAL EXAMPLES - Dictionaries
==================================

Real-world examples demonstrating when and how to use dictionaries.
"""

# =============================================================================
# EXAMPLE 1: Contact Management System
# =============================================================================

print("=" * 60)
print("EXAMPLE 1: Contact Management System")
print("=" * 60)

class ContactBook:
    def __init__(self):
        self.contacts = {}
    
    def add_contact(self, name, phone, email, address=""):
        self.contacts[name] = {
            "phone": phone,
            "email": email,
            "address": address
        }
        print(f"✓ Added {name}")
    
    def get_contact(self, name):
        return self.contacts.get(name, None)
    
    def update_contact(self, name, **kwargs):
        if name in self.contacts:
            self.contacts[name].update(kwargs)
            print(f"✓ Updated {name}")
        else:
            print(f"✗ {name} not found")
    
    def delete_contact(self, name):
        if name in self.contacts:
            del self.contacts[name]
            print(f"✓ Deleted {name}")
        else:
            print(f"✗ {name} not found")
    
    def search_by_phone(self, phone):
        for name, info in self.contacts.items():
            if info["phone"] == phone:
                return name, info
        return None
    
    def list_all(self):
        print("\nAll Contacts:")
        for name, info in sorted(self.contacts.items()):
            print(f"  {name}: {info['phone']} | {info['email']}")

# Usage
contacts = ContactBook()
contacts.add_contact("Alice", "555-1234", "alice@email.com")
contacts.add_contact("Bob", "555-5678", "bob@email.com", "123 Main St")
contacts.update_contact("Alice", address="456 Oak Ave")
contacts.list_all()
print()

# =============================================================================
# EXAMPLE 2: Word Frequency Counter
# =============================================================================

print("=" * 60)
print("EXAMPLE 2: Word Frequency Counter")
print("=" * 60)

def analyze_text(text):
    """Count word frequencies in text"""
    # Clean and split text
    words = text.lower().replace(",", "").replace(".", "").split()
    
    # Count frequencies
    word_counts = {}
    for word in words:
        word_counts[word] = word_counts.get(word, 0) + 1
    
    # Sort by frequency
    sorted_words = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
    
    return dict(sorted_words)

text = """
Python is an amazing programming language. Python is easy to learn,
and Python is powerful. Many developers love Python because Python
makes coding fun.
"""

word_freq = analyze_text(text)
print("Word Frequencies:")
for word, count in list(word_freq.items())[:10]:  # Top 10
    print(f"  {word}: {count}")
print()

# =============================================================================
# EXAMPLE 3: Student Grade Management
# =============================================================================

print("=" * 60)
print("EXAMPLE 3: Student Grade Management")
print("=" * 60)

class GradeBook:
    def __init__(self):
        self.students = {}
    
    def add_student(self, student_id, name):
        self.students[student_id] = {
            "name": name,
            "grades": {}
        }
    
    def add_grade(self, student_id, subject, grade):
        if student_id in self.students:
            self.students[student_id]["grades"][subject] = grade
        else:
            print(f"Student {student_id} not found")
    
    def get_average(self, student_id):
        if student_id not in self.students:
            return None
        grades = self.students[student_id]["grades"].values()
        return sum(grades) / len(grades) if grades else 0
    
    def get_class_average(self, subject):
        grades = []
        for student in self.students.values():
            if subject in student["grades"]:
                grades.append(student["grades"][subject])
        return sum(grades) / len(grades) if grades else 0
    
    def get_top_students(self, n=3):
        averages = []
        for student_id, data in self.students.items():
            avg = self.get_average(student_id)
            averages.append((data["name"], avg))
        averages.sort(key=lambda x: x[1], reverse=True)
        return averages[:n]

# Usage
gradebook = GradeBook()
gradebook.add_student("S001", "Alice")
gradebook.add_student("S002", "Bob")
gradebook.add_student("S003", "Charlie")

gradebook.add_grade("S001", "Math", 95)
gradebook.add_grade("S001", "English", 88)
gradebook.add_grade("S002", "Math", 87)
gradebook.add_grade("S002", "English", 92)
gradebook.add_grade("S003", "Math", 90)
gradebook.add_grade("S003", "English", 85)

print(f"Alice's average: {gradebook.get_average('S001'):.2f}")
print(f"Math class average: {gradebook.get_class_average('Math'):.2f}")
print(f"\nTop students: {gradebook.get_top_students()}")
print()

# =============================================================================
# EXAMPLE 4: Configuration Manager
# =============================================================================

print("=" * 60)
print("EXAMPLE 4: Configuration Manager")
print("=" * 60)

class Config:
    def __init__(self):
        self.settings = {
            "database": {
                "host": "localhost",
                "port": 5432,
                "name": "mydb"
            },
            "app": {
                "debug": True,
                "max_connections": 100,
                "timeout": 30
            },
            "logging": {
                "level": "INFO",
                "file": "app.log"
            }
        }
    
    def get(self, path, default=None):
        """Get config value using dot notation: 'database.host'"""
        keys = path.split(".")
        value = self.settings
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        return value
    
    def set(self, path, value):
        """Set config value using dot notation"""
        keys = path.split(".")
        config = self.settings
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        config[keys[-1]] = value
    
    def print_config(self):
        """Pretty print configuration"""
        import json
        print(json.dumps(self.settings, indent=2))

# Usage
config = Config()
print(f"Database host: {config.get('database.host')}")
print(f"Max connections: {config.get('app.max_connections')}")

config.set("app.debug", False)
config.set("app.version", "1.0.0")
print("\nUpdated configuration:")
config.print_config()
print()

# =============================================================================
# EXAMPLE 5: Inventory Management
# =============================================================================

print("=" * 60)
print("EXAMPLE 5: Inventory Management")
print("=" * 60)

class Inventory:
    def __init__(self):
        self.items = {}
    
    def add_item(self, item_id, name, quantity, price):
        self.items[item_id] = {
            "name": name,
            "quantity": quantity,
            "price": price
        }
        print(f"✓ Added {name} (ID: {item_id})")
    
    def update_quantity(self, item_id, change):
        if item_id in self.items:
            self.items[item_id]["quantity"] += change
            if self.items[item_id]["quantity"] < 0:
                self.items[item_id]["quantity"] = 0
        else:
            print(f"Item {item_id} not found")
    
    def get_total_value(self):
        total = 0
        for item in self.items.values():
            total += item["quantity"] * item["price"]
        return total
    
    def low_stock_alert(self, threshold=10):
        low_stock = {
            item_id: item 
            for item_id, item in self.items.items() 
            if item["quantity"] < threshold
        }
        return low_stock
    
    def most_valuable_items(self, n=5):
        items_with_value = [
            (item_id, data["name"], data["quantity"] * data["price"])
            for item_id, data in self.items.items()
        ]
        items_with_value.sort(key=lambda x: x[2], reverse=True)
        return items_with_value[:n]

# Usage
inventory = Inventory()
inventory.add_item("A001", "Laptop", 50, 899.99)
inventory.add_item("A002", "Mouse", 5, 19.99)
inventory.add_item("A003", "Keyboard", 30, 49.99)
inventory.add_item("A004", "Monitor", 20, 299.99)

inventory.update_quantity("A002", -2)  # Sell 2 mice

print(f"\nTotal inventory value: ${inventory.get_total_value():,.2f}")
print("\nLow stock items:")
for item_id, item in inventory.low_stock_alert().items():
    print(f"  {item['name']}: {item['quantity']} units")
print()

# =============================================================================
# EXAMPLE 6: Cache Implementation
# =============================================================================

print("=" * 60)
print("EXAMPLE 6: LRU Cache Implementation")
print("=" * 60)

from collections import OrderedDict

class LRUCache:
    def __init__(self, capacity):
        self.cache = OrderedDict()
        self.capacity = capacity
    
    def get(self, key):
        if key not in self.cache:
            return None
        # Move to end (most recently used)
        self.cache.move_to_end(key)
        return self.cache[key]
    
    def put(self, key, value):
        if key in self.cache:
            # Update and move to end
            self.cache.move_to_end(key)
        self.cache[key] = value
        
        # Remove least recently used if over capacity
        if len(self.cache) > self.capacity:
            oldest = next(iter(self.cache))
            del self.cache[oldest]
            print(f"Evicted: {oldest}")
    
    def display(self):
        print("Cache contents (oldest to newest):")
        for key, value in self.cache.items():
            print(f"  {key}: {value}")

# Usage
cache = LRUCache(capacity=3)
cache.put("a", 1)
cache.put("b", 2)
cache.put("c", 3)
cache.display()

print("\nAccessing 'a'...")
cache.get("a")

print("\nAdding 'd' (should evict 'b')...")
cache.put("d", 4)
cache.display()
print()

# =============================================================================
# EXAMPLE 7: Graph Representation
# =============================================================================

print("=" * 60)
print("EXAMPLE 7: Graph (Social Network)")
print("=" * 60)

class SocialNetwork:
    def __init__(self):
        self.graph = {}
    
    def add_user(self, user):
        if user not in self.graph:
            self.graph[user] = set()
    
    def add_friendship(self, user1, user2):
        self.add_user(user1)
        self.add_user(user2)
        self.graph[user1].add(user2)
        self.graph[user2].add(user1)
    
    def get_friends(self, user):
        return self.graph.get(user, set())
    
    def mutual_friends(self, user1, user2):
        friends1 = self.graph.get(user1, set())
        friends2 = self.graph.get(user2, set())
        return friends1 & friends2
    
    def suggest_friends(self, user):
        """Suggest friends based on mutual connections"""
        friends = self.graph.get(user, set())
        suggestions = {}
        
        for friend in friends:
            for friend_of_friend in self.graph[friend]:
                if friend_of_friend != user and friend_of_friend not in friends:
                    suggestions[friend_of_friend] = suggestions.get(friend_of_friend, 0) + 1
        
        # Sort by number of mutual connections
        return sorted(suggestions.items(), key=lambda x: x[1], reverse=True)

# Usage
network = SocialNetwork()
network.add_friendship("Alice", "Bob")
network.add_friendship("Alice", "Charlie")
network.add_friendship("Bob", "Charlie")
network.add_friendship("Bob", "Diana")
network.add_friendship("Charlie", "Eve")

print(f"Alice's friends: {network.get_friends('Alice')}")
print(f"Mutual friends (Alice, Bob): {network.mutual_friends('Alice', 'Bob')}")
print(f"Friend suggestions for Alice: {network.suggest_friends('Alice')}")
print()

# =============================================================================
# EXAMPLE 8: JSON-like Data Processing
# =============================================================================

print("=" * 60)
print("EXAMPLE 8: Processing API Response")
print("=" * 60)

# Simulated API response
api_response = {
    "status": "success",
    "data": {
        "users": [
            {"id": 1, "name": "Alice", "email": "alice@example.com", "active": True},
            {"id": 2, "name": "Bob", "email": "bob@example.com", "active": False},
            {"id": 3, "name": "Charlie", "email": "charlie@example.com", "active": True}
        ],
        "total": 3,
        "page": 1
    }
}

def process_users(response):
    """Extract and process user data"""
    if response["status"] != "success":
        return None
    
    users = response["data"]["users"]
    
    # Filter active users
    active_users = [u for u in users if u["active"]]
    
    # Create email lookup
    email_lookup = {u["email"]: u["name"] for u in users}
    
    # Create id to user mapping
    user_map = {u["id"]: u for u in users}
    
    return {
        "active_count": len(active_users),
        "active_users": [u["name"] for u in active_users],
        "email_lookup": email_lookup,
        "user_map": user_map
    }

result = process_users(api_response)
print(f"Active users: {result['active_count']}")
print(f"Names: {result['active_users']}")
print(f"Email lookup: {result['email_lookup']}")
print()

# =============================================================================
# EXAMPLE 9: Menu-Driven Application
# =============================================================================

print("=" * 60)
print("EXAMPLE 9: Restaurant Menu System")
print("=" * 60)

class Restaurant:
    def __init__(self):
        self.menu = {
            "appetizers": {
                "Spring Rolls": {"price": 6.99, "calories": 150},
                "Soup": {"price": 4.99, "calories": 120}
            },
            "entrees": {
                "Burger": {"price": 12.99, "calories": 650},
                "Pasta": {"price": 14.99, "calories": 550},
                "Salad": {"price": 10.99, "calories": 300}
            },
            "desserts": {
                "Ice Cream": {"price": 5.99, "calories": 250},
                "Cake": {"price": 6.99, "calories": 400}
            }
        }
        self.orders = []
    
    def display_menu(self):
        print("\n=== MENU ===")
        for category, items in self.menu.items():
            print(f"\n{category.upper()}:")
            for item, details in items.items():
                print(f"  {item}: ${details['price']} ({details['calories']} cal)")
    
    def add_to_order(self, item_name):
        for category, items in self.menu.items():
            if item_name in items:
                self.orders.append({
                    "item": item_name,
                    "price": items[item_name]["price"],
                    "calories": items[item_name]["calories"]
                })
                print(f"✓ Added {item_name}")
                return
        print(f"✗ {item_name} not found")
    
    def calculate_total(self):
        total_price = sum(order["price"] for order in self.orders)
        total_calories = sum(order["calories"] for order in self.orders)
        return {"price": total_price, "calories": total_calories}
    
    def show_order(self):
        print("\n=== YOUR ORDER ===")
        for order in self.orders:
            print(f"  {order['item']}: ${order['price']}")
        totals = self.calculate_total()
        print(f"\nTotal: ${totals['price']:.2f}")
        print(f"Total Calories: {totals['calories']}")

# Usage
restaurant = Restaurant()
restaurant.add_to_order("Burger")
restaurant.add_to_order("Ice Cream")
restaurant.show_order()
print()

# =============================================================================
# EXAMPLE 10: Data Transformation Pipeline
# =============================================================================

print("=" * 60)
print("EXAMPLE 10: Data Transformation")
print("=" * 60)

# Raw data from different sources
users_list = [
    {"user_id": "U001", "name": "Alice", "age": 30},
    {"user_id": "U002", "name": "Bob", "age": 25},
    {"user_id": "U003", "name": "Charlie", "age": 35}
]

purchases = [
    {"user_id": "U001", "item": "Book", "amount": 15.99},
    {"user_id": "U001", "item": "Pen", "amount": 2.99},
    {"user_id": "U002", "item": "Notebook", "amount": 5.99},
    {"user_id": "U003", "item": "Book", "amount": 15.99}
]

# Transform and combine data
def create_user_profiles(users, purchases):
    # Create user lookup
    user_profiles = {u["user_id"]: {**u, "purchases": [], "total_spent": 0} 
                     for u in users}
    
    # Add purchase data
    for purchase in purchases:
        user_id = purchase["user_id"]
        if user_id in user_profiles:
            user_profiles[user_id]["purchases"].append(purchase)
            user_profiles[user_id]["total_spent"] += purchase["amount"]
    
    return user_profiles

profiles = create_user_profiles(users_list, purchases)

print("User Profiles:")
for user_id, profile in profiles.items():
    print(f"\n{profile['name']} ({user_id}):")
    print(f"  Age: {profile['age']}")
    print(f"  Purchases: {len(profile['purchases'])}")
    print(f"  Total Spent: ${profile['total_spent']:.2f}")

print("\n" + "=" * 60)
print("EXAMPLES COMPLETE!")
print("=" * 60)
