"""
EXERCISES - Dictionaries
=========================

Practice problems to master Python dictionaries. Solutions are in 04_solutions.py
Try to solve these on your own first!

Difficulty levels: ⭐ Easy | ⭐⭐ Medium | ⭐⭐⭐ Hard
"""

# =============================================================================
# SECTION 1: DICTIONARY BASICS
# =============================================================================

print("=" * 60)
print("SECTION 1: DICTIONARY BASICS")
print("=" * 60)

# Exercise 1.1 ⭐
# Create a dictionary representing a person with name, age, city, and occupation
def exercise_1_1():
    # Your code here
    pass

# Exercise 1.2 ⭐
# Access and print specific values from the dictionary
def exercise_1_2():
    book = {
        "title": "1984",
        "author": "George Orwell",
        "year": 1949,
        "pages": 328
    }
    # Print the title and author
    # Your code here
    pass

# Exercise 1.3 ⭐
# Add new key-value pairs to a dictionary
def exercise_1_3():
    student = {"name": "Alice", "age": 20}
    # Add "major": "Computer Science" and "gpa": 3.8
    # Your code here
    pass

# Exercise 1.4 ⭐
# Modify existing values in a dictionary
def exercise_1_4():
    product = {"name": "Laptop", "price": 999, "quantity": 5}
    # Update price to 899 and quantity to 3
    # Your code here
    pass

# Exercise 1.5 ⭐
# Remove items from a dictionary
def exercise_1_5():
    data = {"a": 1, "b": 2, "c": 3, "d": 4}
    # Remove "b" using del
    # Remove and print "c" using pop()
    # Your code here
    pass

# =============================================================================
# SECTION 2: DICTIONARY METHODS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 2: DICTIONARY METHODS")
print("=" * 60)

# Exercise 2.1 ⭐
# Use get() method with default values
def exercise_2_1():
    person = {"name": "Bob", "age": 25}
    # Get "city" with default "Unknown"
    # Get "age" with default 0
    # Your code here
    pass

# Exercise 2.2 ⭐
# Get all keys, values, and items from a dictionary
def exercise_2_2():
    scores = {"Alice": 85, "Bob": 92, "Charlie": 78}
    # Print all keys
    # Print all values
    # Print all items
    # Your code here
    pass

# Exercise 2.3 ⭐⭐
# Use update() to merge dictionaries
def exercise_2_3():
    dict1 = {"a": 1, "b": 2}
    dict2 = {"c": 3, "d": 4}
    dict3 = {"b": 20, "e": 5}
    # Merge all three dictionaries
    # Your code here
    pass

# Exercise 2.4 ⭐⭐
# Use setdefault() to initialize values
def exercise_2_4():
    word_count = {}
    words = ["apple", "banana", "apple", "cherry", "banana", "apple"]
    # Count words using setdefault()
    # Your code here
    pass

# Exercise 2.5 ⭐⭐
# Create a dictionary using fromkeys()
def exercise_2_5():
    keys = ["red", "green", "blue"]
    # Create dict with all values as 0
    # Your code here
    pass

# =============================================================================
# SECTION 3: ITERATING THROUGH DICTIONARIES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 3: ITERATING THROUGH DICTIONARIES")
print("=" * 60)

# Exercise 3.1 ⭐
# Iterate and print all key-value pairs
def exercise_3_1():
    fruits = {"apple": 5, "banana": 3, "cherry": 8}
    # Print each fruit and its quantity
    # Your code here
    pass

# Exercise 3.2 ⭐⭐
# Find the key with maximum value
def exercise_3_2():
    scores = {"Alice": 85, "Bob": 92, "Charlie": 78, "Diana": 95}
    # Find and print the name with highest score
    # Your code here
    pass

# Exercise 3.3 ⭐⭐
# Calculate sum of all values
def exercise_3_3():
    prices = {"apple": 1.50, "banana": 0.75, "cherry": 2.00, "date": 3.50}
    # Calculate and print total of all prices
    # Your code here
    pass

# Exercise 3.4 ⭐⭐
# Count items that meet a condition
def exercise_3_4():
    ages = {"Alice": 25, "Bob": 17, "Charlie": 30, "Diana": 16, "Eve": 22}
    # Count how many people are 18 or older
    # Your code here
    pass

# =============================================================================
# SECTION 4: DICTIONARY COMPREHENSIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 4: DICTIONARY COMPREHENSIONS")
print("=" * 60)

# Exercise 4.1 ⭐
# Create a dictionary of squares using comprehension
def exercise_4_1():
    # Create {1: 1, 2: 4, 3: 9, 4: 16, 5: 25}
    # Your code here
    pass

# Exercise 4.2 ⭐⭐
# Filter dictionary based on values
def exercise_4_2():
    scores = {"Alice": 85, "Bob": 92, "Charlie": 78, "Diana": 95, "Eve": 88}
    # Create new dict with only scores >= 90
    # Your code here
    pass

# Exercise 4.3 ⭐⭐
# Transform dictionary values
def exercise_4_3():
    celsius = {"morning": 20, "afternoon": 25, "evening": 18}
    # Convert to Fahrenheit: F = C * 9/5 + 32
    # Your code here
    pass

# Exercise 4.4 ⭐⭐
# Invert a dictionary (swap keys and values)
def exercise_4_4():
    original = {"a": 1, "b": 2, "c": 3}
    # Create {1: "a", 2: "b", 3: "c"}
    # Your code here
    pass

# Exercise 4.5 ⭐⭐⭐
# Create dictionary from two lists
def exercise_4_5():
    keys = ["name", "age", "city", "job"]
    values = ["Alice", 30, "NYC", "Engineer"]
    # Create dictionary combining both lists
    # Your code here
    pass

# =============================================================================
# SECTION 5: NESTED DICTIONARIES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 5: NESTED DICTIONARIES")
print("=" * 60)

# Exercise 5.1 ⭐⭐
# Access nested dictionary values
def exercise_5_1():
    company = {
        "employees": {
            "E001": {"name": "Alice", "dept": "IT"},
            "E002": {"name": "Bob", "dept": "HR"}
        }
    }
    # Print Alice's department
    # Your code here
    pass

# Exercise 5.2 ⭐⭐
# Create a nested dictionary structure
def exercise_5_2():
    # Create a dictionary of students where each student has:
    # - name
    # - grades (dict of subject: grade)
    # Create for at least 2 students
    # Your code here
    pass

# Exercise 5.3 ⭐⭐⭐
# Iterate through nested dictionary
def exercise_5_3():
    store = {
        "electronics": {
            "laptop": 999,
            "mouse": 29,
            "keyboard": 79
        },
        "clothing": {
            "shirt": 25,
            "pants": 40
        }
    }
    # Print all items with their category and price
    # Your code here
    pass

# =============================================================================
# SECTION 6: PRACTICAL APPLICATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 6: PRACTICAL APPLICATIONS")
print("=" * 60)

# Exercise 6.1 ⭐⭐
# Count character frequency in a string
def exercise_6_1(text):
    """
    Count how many times each character appears
    Example: "hello" -> {"h": 1, "e": 1, "l": 2, "o": 1}
    """
    # Your code here
    pass

# Exercise 6.2 ⭐⭐
# Group items by property
def exercise_6_2():
    """
    Group students by grade
    students = [
        ("Alice", "A"),
        ("Bob", "B"),
        ("Charlie", "A"),
        ("Diana", "C")
    ]
    Result: {"A": ["Alice", "Charlie"], "B": ["Bob"], "C": ["Diana"]}
    """
    # Your code here
    pass

# Exercise 6.3 ⭐⭐⭐
# Merge dictionaries with sum of values
def exercise_6_3(dict1, dict2):
    """
    Merge two dictionaries, summing values for common keys
    Example: {"a": 1, "b": 2} + {"b": 3, "c": 4} = {"a": 1, "b": 5, "c": 4}
    """
    # Your code here
    pass

# Exercise 6.4 ⭐⭐⭐
# Find common keys between dictionaries
def exercise_6_4(dict1, dict2):
    """Find keys that exist in both dictionaries"""
    # Your code here
    pass

# Exercise 6.5 ⭐⭐⭐
# Deep copy nested dictionary
def exercise_6_5():
    """
    Create a deep copy of a nested dictionary
    (modifying the copy shouldn't affect the original)
    """
    original = {
        "user": {"name": "Alice", "settings": {"theme": "dark"}}
    }
    # Your code here
    pass

# =============================================================================
# SECTION 7: REAL-WORLD CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 7: REAL-WORLD CHALLENGES")
print("=" * 60)

# Exercise 7.1 ⭐⭐⭐
# Shopping cart system
def exercise_7_1():
    """
    Create a shopping cart system with:
    - Add item (name, price, quantity)
    - Update quantity
    - Remove item
    - Calculate total
    - Apply discount
    """
    # Your code here
    pass

# Exercise 7.2 ⭐⭐⭐
# Grade calculator
def exercise_7_2():
    """
    Calculate grades for students:
    - Store multiple test scores per student
    - Calculate average for each student
    - Assign letter grade (A: 90+, B: 80-89, C: 70-79, D: 60-69, F: <60)
    - Find class average
    """
    # Your code here
    pass

# Exercise 7.3 ⭐⭐⭐
# Word index (like a book index)
def exercise_7_3(text):
    """
    Create an index showing which line each word appears on
    Example:
    Line 1: "hello world"
    Line 2: "hello python"
    Result: {"hello": [1, 2], "world": [1], "python": [2]}
    """
    # Your code here
    pass

# Exercise 7.4 ⭐⭐⭐
# Phone book with search
def exercise_7_4():
    """
    Create a phone book that can:
    - Add contact (name, phone, email)
    - Search by name (partial match)
    - Search by phone
    - List all contacts
    - Delete contact
    """
    # Your code here
    pass

# Exercise 7.5 ⭐⭐⭐
# Inventory tracker
def exercise_7_5():
    """
    Track product inventory:
    - Add product (id, name, quantity, price)
    - Update stock (add or remove quantity)
    - Calculate total inventory value
    - Find low stock items (quantity < threshold)
    - Most expensive items
    """
    # Your code here
    pass

# =============================================================================
# SECTION 8: ADVANCED CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 8: ADVANCED CHALLENGES")
print("=" * 60)

# Exercise 8.1 ⭐⭐⭐
# Flatten nested dictionary
def exercise_8_1(nested_dict):
    """
    Flatten nested dictionary with dot notation
    Example: {"a": {"b": 1, "c": 2}} -> {"a.b": 1, "a.c": 2}
    """
    # Your code here
    pass

# Exercise 8.2 ⭐⭐⭐
# Dictionary difference
def exercise_8_2(dict1, dict2):
    """
    Find differences between two dictionaries
    Return: (keys only in dict1, keys only in dict2, keys with different values)
    """
    # Your code here
    pass

# Exercise 8.3 ⭐⭐⭐
# Frequency analysis
def exercise_8_3(text):
    """
    Analyze text and return:
    - Most common words (top 10)
    - Average word length
    - Words that appear only once
    """
    # Your code here
    pass

# Exercise 8.4 ⭐⭐⭐
# Dictionary path access
def exercise_8_4():
    """
    Create get_nested() function that accesses nested dict using path
    Example: get_nested(data, "user.address.city")
    """
    # Your code here
    pass

# Exercise 8.5 ⭐⭐⭐
# JSON-like data transformation
def exercise_8_5():
    """
    Transform data from one format to another
    Input: List of dicts with user data
    Output: Dict indexed by user_id with computed fields
    """
    # Your code here
    pass

# =============================================================================
# BONUS CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("BONUS CHALLENGES")
print("=" * 60)

# Bonus 1 ⭐⭐⭐
# Memoization decorator
def memoize(func):
    """
    Create a decorator that caches function results in a dictionary
    """
    # Your code here
    pass

# Bonus 2 ⭐⭐⭐
# Two-way dictionary (BiDict)
class BiDict:
    """
    Create a bidirectional dictionary where you can look up by key or value
    """
    def __init__(self):
        # Your code here
        pass

# Bonus 3 ⭐⭐⭐
# Spell checker
def spell_checker(dictionary, text):
    """
    Build a simple spell checker:
    - Load dictionary of valid words
    - Find misspelled words in text
    - Suggest corrections (words with 1-2 character difference)
    """
    # Your code here
    pass

# Bonus 4 ⭐⭐⭐
# Graph shortest path
def shortest_path(graph, start, end):
    """
    Find shortest path in a graph represented as dict
    graph = {"A": ["B", "C"], "B": ["D"], "C": ["D"], "D": []}
    """
    # Your code here
    pass

# Bonus 5 ⭐⭐⭐
# Configuration merger
def merge_configs(default, user, system):
    """
    Merge three config dictionaries with priority:
    system > user > default
    Handle nested dictionaries
    """
    # Your code here
    pass

print("\n" + "=" * 60)
print("EXERCISES COMPLETE!")
print("Check 04_solutions.py for answers")
print("=" * 60)
