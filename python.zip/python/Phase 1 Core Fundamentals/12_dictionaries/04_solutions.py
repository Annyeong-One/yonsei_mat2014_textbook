"""
SOLUTIONS - Dictionaries
=========================

Solutions to all exercises in 03_exercises.py
Study these after attempting the problems yourself!
"""

# =============================================================================
# SECTION 1: DICTIONARY BASICS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 1: DICTIONARY BASICS - SOLUTIONS")
print("=" * 60)

# Exercise 1.1 Solution
def exercise_1_1():
    person = {
        "name": "Alice",
        "age": 30,
        "city": "New York",
        "occupation": "Engineer"
    }
    print(f"Person: {person}")

exercise_1_1()

# Exercise 1.2 Solution
def exercise_1_2():
    book = {
        "title": "1984",
        "author": "George Orwell",
        "year": 1949,
        "pages": 328
    }
    print(f"Title: {book['title']}")
    print(f"Author: {book['author']}")

exercise_1_2()

# Exercise 1.3 Solution
def exercise_1_3():
    student = {"name": "Alice", "age": 20}
    student["major"] = "Computer Science"
    student["gpa"] = 3.8
    print(f"Student: {student}")

exercise_1_3()

# Exercise 1.4 Solution
def exercise_1_4():
    product = {"name": "Laptop", "price": 999, "quantity": 5}
    product["price"] = 899
    product["quantity"] = 3
    print(f"Updated product: {product}")

exercise_1_4()

# Exercise 1.5 Solution
def exercise_1_5():
    data = {"a": 1, "b": 2, "c": 3, "d": 4}
    del data["b"]
    c_value = data.pop("c")
    print(f"Removed c: {c_value}")
    print(f"Remaining: {data}")

exercise_1_5()
print()

# =============================================================================
# SECTION 2: DICTIONARY METHODS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 2: DICTIONARY METHODS - SOLUTIONS")
print("=" * 60)

# Exercise 2.1 Solution
def exercise_2_1():
    person = {"name": "Bob", "age": 25}
    city = person.get("city", "Unknown")
    age = person.get("age", 0)
    print(f"City: {city}")
    print(f"Age: {age}")

exercise_2_1()

# Exercise 2.2 Solution
def exercise_2_2():
    scores = {"Alice": 85, "Bob": 92, "Charlie": 78}
    print(f"Keys: {list(scores.keys())}")
    print(f"Values: {list(scores.values())}")
    print(f"Items: {list(scores.items())}")

exercise_2_2()

# Exercise 2.3 Solution
def exercise_2_3():
    dict1 = {"a": 1, "b": 2}
    dict2 = {"c": 3, "d": 4}
    dict3 = {"b": 20, "e": 5}
    
    result = {**dict1, **dict2, **dict3}
    print(f"Merged: {result}")
    
    # Alternative using update
    alt_result = {}
    alt_result.update(dict1)
    alt_result.update(dict2)
    alt_result.update(dict3)
    print(f"Alternative: {alt_result}")

exercise_2_3()

# Exercise 2.4 Solution
def exercise_2_4():
    word_count = {}
    words = ["apple", "banana", "apple", "cherry", "banana", "apple"]
    
    for word in words:
        word_count.setdefault(word, 0)
        word_count[word] += 1
    
    print(f"Word count: {word_count}")

exercise_2_4()

# Exercise 2.5 Solution
def exercise_2_5():
    keys = ["red", "green", "blue"]
    colors = dict.fromkeys(keys, 0)
    print(f"Colors: {colors}")

exercise_2_5()
print()

# =============================================================================
# SECTION 3: ITERATING THROUGH DICTIONARIES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 3: ITERATING THROUGH DICTIONARIES - SOLUTIONS")
print("=" * 60)

# Exercise 3.1 Solution
def exercise_3_1():
    fruits = {"apple": 5, "banana": 3, "cherry": 8}
    for fruit, quantity in fruits.items():
        print(f"  {fruit}: {quantity}")

exercise_3_1()

# Exercise 3.2 Solution
def exercise_3_2():
    scores = {"Alice": 85, "Bob": 92, "Charlie": 78, "Diana": 95}
    max_name = max(scores, key=scores.get)
    print(f"Highest score: {max_name} with {scores[max_name]}")

exercise_3_2()

# Exercise 3.3 Solution
def exercise_3_3():
    prices = {"apple": 1.50, "banana": 0.75, "cherry": 2.00, "date": 3.50}
    total = sum(prices.values())
    print(f"Total: ${total:.2f}")

exercise_3_3()

# Exercise 3.4 Solution
def exercise_3_4():
    ages = {"Alice": 25, "Bob": 17, "Charlie": 30, "Diana": 16, "Eve": 22}
    adults = sum(1 for age in ages.values() if age >= 18)
    print(f"Adults (18+): {adults}")

exercise_3_4()
print()

# =============================================================================
# SECTION 4: DICTIONARY COMPREHENSIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 4: DICTIONARY COMPREHENSIONS - SOLUTIONS")
print("=" * 60)

# Exercise 4.1 Solution
def exercise_4_1():
    squares = {x: x**2 for x in range(1, 6)}
    print(f"Squares: {squares}")

exercise_4_1()

# Exercise 4.2 Solution
def exercise_4_2():
    scores = {"Alice": 85, "Bob": 92, "Charlie": 78, "Diana": 95, "Eve": 88}
    high_scores = {name: score for name, score in scores.items() if score >= 90}
    print(f"High scores: {high_scores}")

exercise_4_2()

# Exercise 4.3 Solution
def exercise_4_3():
    celsius = {"morning": 20, "afternoon": 25, "evening": 18}
    fahrenheit = {time: temp * 9/5 + 32 for time, temp in celsius.items()}
    print(f"Fahrenheit: {fahrenheit}")

exercise_4_3()

# Exercise 4.4 Solution
def exercise_4_4():
    original = {"a": 1, "b": 2, "c": 3}
    inverted = {v: k for k, v in original.items()}
    print(f"Inverted: {inverted}")

exercise_4_4()

# Exercise 4.5 Solution
def exercise_4_5():
    keys = ["name", "age", "city", "job"]
    values = ["Alice", 30, "NYC", "Engineer"]
    person = {k: v for k, v in zip(keys, values)}
    print(f"Person: {person}")

exercise_4_5()
print()

# =============================================================================
# SECTION 5: NESTED DICTIONARIES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 5: NESTED DICTIONARIES - SOLUTIONS")
print("=" * 60)

# Exercise 5.1 Solution
def exercise_5_1():
    company = {
        "employees": {
            "E001": {"name": "Alice", "dept": "IT"},
            "E002": {"name": "Bob", "dept": "HR"}
        }
    }
    dept = company["employees"]["E001"]["dept"]
    print(f"Alice's department: {dept}")

exercise_5_1()

# Exercise 5.2 Solution
def exercise_5_2():
    students = {
        "S001": {
            "name": "Alice",
            "grades": {"Math": 95, "English": 88, "Science": 92}
        },
        "S002": {
            "name": "Bob",
            "grades": {"Math": 87, "English": 90, "Science": 85}
        }
    }
    print(f"Students: {students}")

exercise_5_2()

# Exercise 5.3 Solution
def exercise_5_3():
    store = {
        "electronics": {
            "laptop": 999,
            "mouse": 29,
            "keyboard": 79
        },
        "clothing": {
            "shirt": 25,
            "pants": 40
        }
    }
    
    print("Store inventory:")
    for category, items in store.items():
        for item, price in items.items():
            print(f"  {category} - {item}: ${price}")

exercise_5_3()
print()

# =============================================================================
# SECTION 6: PRACTICAL APPLICATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 6: PRACTICAL APPLICATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 6.1 Solution
def exercise_6_1(text):
    char_count = {}
    for char in text:
        char_count[char] = char_count.get(char, 0) + 1
    return char_count

print(f"Character count: {exercise_6_1('hello')}")

# Exercise 6.2 Solution
def exercise_6_2():
    students = [
        ("Alice", "A"),
        ("Bob", "B"),
        ("Charlie", "A"),
        ("Diana", "C")
    ]
    
    by_grade = {}
    for name, grade in students:
        if grade not in by_grade:
            by_grade[grade] = []
        by_grade[grade].append(name)
    
    print(f"By grade: {by_grade}")

exercise_6_2()

# Exercise 6.3 Solution
def exercise_6_3(dict1, dict2):
    result = dict1.copy()
    for key, value in dict2.items():
        result[key] = result.get(key, 0) + value
    return result

print(f"Merged sum: {exercise_6_3({'a': 1, 'b': 2}, {'b': 3, 'c': 4})}")

# Exercise 6.4 Solution
def exercise_6_4(dict1, dict2):
    return set(dict1.keys()) & set(dict2.keys())

print(f"Common keys: {exercise_6_4({'a': 1, 'b': 2}, {'b': 3, 'c': 4})}")

# Exercise 6.5 Solution
def exercise_6_5():
    import copy
    original = {
        "user": {"name": "Alice", "settings": {"theme": "dark"}}
    }
    deep_copied = copy.deepcopy(original)
    
    # Modify copy
    deep_copied["user"]["name"] = "Bob"
    
    print(f"Original: {original['user']['name']}")
    print(f"Copy: {deep_copied['user']['name']}")

exercise_6_5()
print()

# =============================================================================
# SECTION 7: REAL-WORLD CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 7: REAL-WORLD CHALLENGES - SOLUTIONS")
print("=" * 60)

# Exercise 7.1 Solution
def exercise_7_1():
    class ShoppingCart:
        def __init__(self):
            self.items = {}
        
        def add_item(self, name, price, quantity):
            self.items[name] = {"price": price, "quantity": quantity}
        
        def update_quantity(self, name, quantity):
            if name in self.items:
                self.items[name]["quantity"] = quantity
        
        def remove_item(self, name):
            if name in self.items:
                del self.items[name]
        
        def calculate_total(self):
            return sum(item["price"] * item["quantity"] 
                      for item in self.items.values())
        
        def apply_discount(self, percent):
            for item in self.items.values():
                item["price"] *= (1 - percent / 100)
    
    cart = ShoppingCart()
    cart.add_item("Apple", 1.50, 5)
    cart.add_item("Banana", 0.75, 3)
    print(f"Total: ${cart.calculate_total():.2f}")
    cart.apply_discount(10)
    print(f"After 10% discount: ${cart.calculate_total():.2f}")

exercise_7_1()

# Exercise 7.2 Solution
def exercise_7_2():
    students = {
        "Alice": [85, 90, 88],
        "Bob": [78, 82, 80],
        "Charlie": [95, 92, 94]
    }
    
    def letter_grade(avg):
        if avg >= 90: return 'A'
        elif avg >= 80: return 'B'
        elif avg >= 70: return 'C'
        elif avg >= 60: return 'D'
        else: return 'F'
    
    print("Student grades:")
    all_averages = []
    for name, scores in students.items():
        avg = sum(scores) / len(scores)
        all_averages.append(avg)
        grade = letter_grade(avg)
        print(f"  {name}: {avg:.1f} ({grade})")
    
    class_avg = sum(all_averages) / len(all_averages)
    print(f"Class average: {class_avg:.1f}")

exercise_7_2()

# Exercise 7.3 Solution
def exercise_7_3(text):
    lines = text.strip().split('\n')
    word_index = {}
    
    for line_num, line in enumerate(lines, 1):
        words = line.lower().split()
        for word in words:
            if word not in word_index:
                word_index[word] = []
            if line_num not in word_index[word]:
                word_index[word].append(line_num)
    
    return word_index

sample_text = """hello world
hello python
world of programming"""
print(f"Word index: {exercise_7_3(sample_text)}")

# Exercise 7.4 Solution
def exercise_7_4():
    class PhoneBook:
        def __init__(self):
            self.contacts = {}
        
        def add_contact(self, name, phone, email):
            self.contacts[name.lower()] = {"phone": phone, "email": email}
        
        def search_by_name(self, query):
            query = query.lower()
            return {name: info for name, info in self.contacts.items() 
                   if query in name}
        
        def search_by_phone(self, phone):
            for name, info in self.contacts.items():
                if info["phone"] == phone:
                    return {name: info}
            return {}
        
        def list_all(self):
            for name, info in sorted(self.contacts.items()):
                print(f"  {name.title()}: {info['phone']} | {info['email']}")
        
        def delete_contact(self, name):
            name = name.lower()
            if name in self.contacts:
                del self.contacts[name]
    
    phonebook = PhoneBook()
    phonebook.add_contact("Alice Johnson", "555-1234", "alice@email.com")
    phonebook.add_contact("Bob Smith", "555-5678", "bob@email.com")
    print("Search 'alice':", phonebook.search_by_name("alice"))

exercise_7_4()

# Exercise 7.5 Solution
def exercise_7_5():
    class Inventory:
        def __init__(self):
            self.products = {}
        
        def add_product(self, prod_id, name, quantity, price):
            self.products[prod_id] = {
                "name": name,
                "quantity": quantity,
                "price": price
            }
        
        def update_stock(self, prod_id, change):
            if prod_id in self.products:
                self.products[prod_id]["quantity"] += change
        
        def total_value(self):
            return sum(p["quantity"] * p["price"] 
                      for p in self.products.values())
        
        def low_stock(self, threshold=10):
            return {pid: p for pid, p in self.products.items() 
                   if p["quantity"] < threshold}
        
        def most_expensive(self, n=3):
            sorted_products = sorted(
                self.products.items(),
                key=lambda x: x[1]["price"],
                reverse=True
            )
            return sorted_products[:n]
    
    inv = Inventory()
    inv.add_product("P001", "Laptop", 50, 999.99)
    inv.add_product("P002", "Mouse", 5, 29.99)
    inv.add_product("P003", "Keyboard", 30, 79.99)
    
    print(f"Total value: ${inv.total_value():,.2f}")
    print(f"Low stock: {inv.low_stock()}")
    print(f"Most expensive: {inv.most_expensive(2)}")

exercise_7_5()
print()

# =============================================================================
# SECTION 8: ADVANCED CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 8: ADVANCED CHALLENGES - SOLUTIONS")
print("=" * 60)

# Exercise 8.1 Solution
def exercise_8_1(nested_dict, parent_key=''):
    items = []
    for key, value in nested_dict.items():
        new_key = f"{parent_key}.{key}" if parent_key else key
        if isinstance(value, dict):
            items.extend(exercise_8_1(value, new_key).items())
        else:
            items.append((new_key, value))
    return dict(items)

print(f"Flattened: {exercise_8_1({'a': {'b': 1, 'c': 2}})}")

# Exercise 8.2 Solution
def exercise_8_2(dict1, dict2):
    only_in_1 = set(dict1.keys()) - set(dict2.keys())
    only_in_2 = set(dict2.keys()) - set(dict1.keys())
    common = set(dict1.keys()) & set(dict2.keys())
    different_values = {k for k in common if dict1[k] != dict2[k]}
    
    return (only_in_1, only_in_2, different_values)

d1 = {"a": 1, "b": 2, "c": 3}
d2 = {"b": 20, "c": 3, "d": 4}
print(f"Differences: {exercise_8_2(d1, d2)}")

# Exercise 8.3 Solution
def exercise_8_3(text):
    from collections import Counter
    words = text.lower().replace(",", "").replace(".", "").split()
    
    word_count = Counter(words)
    most_common = word_count.most_common(10)
    avg_length = sum(len(w) for w in words) / len(words)
    unique_words = [w for w, count in word_count.items() if count == 1]
    
    return {
        "most_common": most_common,
        "avg_length": avg_length,
        "unique_words": unique_words
    }

sample = "the quick brown fox jumps over the lazy dog"
print(f"Analysis: {exercise_8_3(sample)}")

# Exercise 8.4 Solution
def exercise_8_4():
    def get_nested(data, path, default=None):
        keys = path.split(".")
        for key in keys:
            if isinstance(data, dict) and key in data:
                data = data[key]
            else:
                return default
        return data
    
    data = {"user": {"address": {"city": "NYC"}}}
    print(f"Nested access: {get_nested(data, 'user.address.city')}")

exercise_8_4()

# Exercise 8.5 Solution
def exercise_8_5():
    users = [
        {"user_id": "U001", "name": "Alice", "age": 30},
        {"user_id": "U002", "name": "Bob", "age": 25}
    ]
    
    transformed = {}
    for user in users:
        user_id = user["user_id"]
        transformed[user_id] = {
            **user,
            "age_group": "adult" if user["age"] >= 18 else "minor",
            "name_length": len(user["name"])
        }
    
    print(f"Transformed: {transformed}")

exercise_8_5()
print()

# =============================================================================
# BONUS CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("BONUS CHALLENGES - SOLUTIONS")
print("=" * 60)

# Bonus 1 Solution
def memoize(func):
    cache = {}
    def wrapper(*args):
        if args not in cache:
            cache[args] = func(*args)
        return cache[args]
    return wrapper

@memoize
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(f"Fibonacci(10): {fibonacci(10)}")

# Bonus 2 Solution
class BiDict:
    def __init__(self):
        self.key_to_value = {}
        self.value_to_key = {}
    
    def set(self, key, value):
        self.key_to_value[key] = value
        self.value_to_key[value] = key
    
    def get_by_key(self, key):
        return self.key_to_value.get(key)
    
    def get_by_value(self, value):
        return self.value_to_key.get(value)

bidict = BiDict()
bidict.set("a", 1)
bidict.set("b", 2)
print(f"By key 'a': {bidict.get_by_key('a')}")
print(f"By value 1: {bidict.get_by_value(1)}")

# Bonus 3 Solution
def spell_checker(dictionary, text):
    words = text.lower().split()
    valid_words = set(w.lower() for w in dictionary)
    misspelled = [w for w in words if w not in valid_words]
    return misspelled

dictionary = ["hello", "world", "python", "programming"]
text = "hello wrld python programing"
print(f"Misspelled: {spell_checker(dictionary, text)}")

# Bonus 4 Solution
def shortest_path(graph, start, end):
    from collections import deque
    
    queue = deque([(start, [start])])
    visited = set()
    
    while queue:
        node, path = queue.popleft()
        if node == end:
            return path
        
        if node in visited:
            continue
        visited.add(node)
        
        for neighbor in graph.get(node, []):
            queue.append((neighbor, path + [neighbor]))
    
    return None

graph = {"A": ["B", "C"], "B": ["D"], "C": ["D"], "D": []}
print(f"Shortest path A->D: {shortest_path(graph, 'A', 'D')}")

# Bonus 5 Solution
def merge_configs(default, user, system):
    def deep_merge(dict1, dict2):
        result = dict1.copy()
        for key, value in dict2.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = deep_merge(result[key], value)
            else:
                result[key] = value
        return result
    
    result = deep_merge(default, user)
    result = deep_merge(result, system)
    return result

default = {"theme": "light", "lang": "en", "options": {"debug": False}}
user = {"theme": "dark", "options": {"debug": True, "verbose": True}}
system = {"lang": "es"}
print(f"Merged config: {merge_configs(default, user, system)}")

print("\n" + "=" * 60)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 60)
