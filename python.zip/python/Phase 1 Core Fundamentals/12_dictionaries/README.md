# Dictionaries - Python Data Structures

## Overview
This module covers Python dictionaries - one of the most powerful and versatile data structures for storing key-value pairs.

## Contents
- **01_dictionaries_tutorial.py** - Complete guide to Python dictionaries
- **02_examples.py** - Practical real-world examples
- **03_exercises.py** - Practice problems (try these first!)
- **04_solutions.py** - Solutions to the exercises

## Learning Objectives
By the end of this module, you should be able to:
- Create and manipulate dictionaries
- Access, add, modify, and remove key-value pairs
- Use dictionary methods effectively
- Iterate through dictionaries in various ways
- Work with nested dictionaries
- Apply dictionary comprehensions
- Choose when dictionaries are the best data structure

## Recommended Learning Path
1. Read through `01_dictionaries_tutorial.py`
2. Study the examples in `02_examples.py`
3. Attempt the exercises in `03_exercises.py`
4. Check your solutions against `04_solutions.py`

## Quick Reference

### Creating Dictionaries
```python
# Empty dictionary
my_dict = {}
my_dict = dict()

# With initial values
person = {"name": "Alice", "age": 30, "city": "NYC"}
```

### Common Operations
```python
# Access
value = my_dict["key"]
value = my_dict.get("key", default)

# Add/Modify
my_dict["new_key"] = "value"

# Remove
del my_dict["key"]
value = my_dict.pop("key")

# Check existence
if "key" in my_dict:
    print("Key exists!")
```

### Key Features
- **Unordered** (Python 3.7+ maintains insertion order)
- **Mutable** - can be modified after creation
- **Keys must be immutable** - strings, numbers, tuples (not lists)
- **Values can be any type** - including other dictionaries
- **Fast lookup** - O(1) average time complexity

Happy learning!
