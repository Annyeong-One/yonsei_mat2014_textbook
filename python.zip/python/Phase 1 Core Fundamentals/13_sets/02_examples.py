"""
PRACTICAL EXAMPLES - Sets
==========================

Real-world examples demonstrating when and how to use sets.
"""

# =============================================================================
# EXAMPLE 1: Email List Deduplication
# =============================================================================

print("=" * 60)
print("EXAMPLE 1: Email List Deduplication")
print("=" * 60)

class EmailList:
    def __init__(self):
        self.emails = set()
    
    def add_email(self, email):
        """Add email to list (automatically prevents duplicates)"""
        email = email.lower().strip()
        if email in self.emails:
            print(f"  {email} already exists")
            return False
        self.emails.add(email)
        print(f"  ✓ Added {email}")
        return True
    
    def add_bulk(self, email_list):
        """Add multiple emails at once"""
        added = 0
        for email in email_list:
            if self.add_email(email):
                added += 1
        print(f"\nAdded {added} new emails, {len(email_list) - added} duplicates skipped")
    
    def remove_email(self, email):
        """Remove email from list"""
        email = email.lower().strip()
        self.emails.discard(email)
    
    def count(self):
        return len(self.emails)

# Usage
email_list = EmailList()
emails = [
    "alice@email.com",
    "bob@email.com",
    "alice@email.com",  # Duplicate
    "Charlie@email.com",
    "ALICE@EMAIL.COM"   # Duplicate (case insensitive)
]
email_list.add_bulk(emails)
print(f"Total unique emails: {email_list.count()}")
print()

# =============================================================================
# EXAMPLE 2: Tag Management System
# =============================================================================

print("=" * 60)
print("EXAMPLE 2: Tag Management System")
print("=" * 60)

class Article:
    def __init__(self, title):
        self.title = title
        self.tags = set()
    
    def add_tags(self, *tags):
        """Add one or more tags"""
        self.tags.update(tag.lower() for tag in tags)
    
    def remove_tag(self, tag):
        """Remove a tag"""
        self.tags.discard(tag.lower())
    
    def has_tag(self, tag):
        """Check if article has a tag"""
        return tag.lower() in self.tags
    
    def __repr__(self):
        return f"Article('{self.title}', tags={self.tags})"

# Create articles
article1 = Article("Python Basics")
article1.add_tags("python", "programming", "beginner")

article2 = Article("Advanced Python")
article2.add_tags("python", "programming", "advanced", "oop")

article3 = Article("Web Development")
article3.add_tags("web", "javascript", "html", "css")

# Find articles with common tags
def find_common_tags(*articles):
    """Find tags common to all articles"""
    if not articles:
        return set()
    common = articles[0].tags
    for article in articles[1:]:
        common &= article.tags
    return common

# Find all unique tags
def all_tags(*articles):
    """Get all unique tags from all articles"""
    all_tags = set()
    for article in articles:
        all_tags |= article.tags
    return all_tags

print(f"Article 1: {article1}")
print(f"Article 2: {article2}")
print(f"\nCommon tags (1 & 2): {find_common_tags(article1, article2)}")
print(f"All unique tags: {all_tags(article1, article2, article3)}")
print()

# =============================================================================
# EXAMPLE 3: Access Control System
# =============================================================================

print("=" * 60)
print("EXAMPLE 3: Access Control System")
print("=" * 60)

class AccessControl:
    def __init__(self):
        self.permissions = {}
    
    def grant_permission(self, user, permission):
        """Grant a permission to a user"""
        if user not in self.permissions:
            self.permissions[user] = set()
        self.permissions[user].add(permission)
        print(f"✓ Granted '{permission}' to {user}")
    
    def revoke_permission(self, user, permission):
        """Revoke a permission from a user"""
        if user in self.permissions:
            self.permissions[user].discard(permission)
            print(f"✗ Revoked '{permission}' from {user}")
    
    def has_permission(self, user, permission):
        """Check if user has a specific permission"""
        return user in self.permissions and permission in self.permissions[user]
    
    def has_all_permissions(self, user, required_permissions):
        """Check if user has all required permissions"""
        if user not in self.permissions:
            return False
        return required_permissions.issubset(self.permissions[user])
    
    def has_any_permission(self, user, permissions):
        """Check if user has any of the given permissions"""
        if user not in self.permissions:
            return False
        return not self.permissions[user].isdisjoint(permissions)
    
    def get_users_with_permission(self, permission):
        """Find all users with a specific permission"""
        return {user for user, perms in self.permissions.items() 
                if permission in perms}

# Usage
ac = AccessControl()
ac.grant_permission("alice", "read")
ac.grant_permission("alice", "write")
ac.grant_permission("alice", "delete")
ac.grant_permission("bob", "read")
ac.grant_permission("bob", "write")

print(f"\nAlice has delete permission: {ac.has_permission('alice', 'delete')}")
print(f"Bob has delete permission: {ac.has_permission('bob', 'delete')}")

required = {"read", "write", "delete"}
print(f"\nAlice has all required permissions: {ac.has_all_permissions('alice', required)}")
print(f"Bob has all required permissions: {ac.has_all_permissions('bob', required)}")

print(f"\nUsers with write permission: {ac.get_users_with_permission('write')}")
print()

# =============================================================================
# EXAMPLE 4: Social Network Friends
# =============================================================================

print("=" * 60)
print("EXAMPLE 4: Social Network Friends")
print("=" * 60)

class SocialNetwork:
    def __init__(self):
        self.friendships = {}
    
    def add_user(self, user):
        """Add a user to the network"""
        if user not in self.friendships:
            self.friendships[user] = set()
    
    def add_friendship(self, user1, user2):
        """Create bidirectional friendship"""
        self.add_user(user1)
        self.add_user(user2)
        self.friendships[user1].add(user2)
        self.friendships[user2].add(user1)
        print(f"✓ {user1} and {user2} are now friends")
    
    def remove_friendship(self, user1, user2):
        """Remove friendship"""
        if user1 in self.friendships:
            self.friendships[user1].discard(user2)
        if user2 in self.friendships:
            self.friendships[user2].discard(user1)
    
    def get_friends(self, user):
        """Get user's friends"""
        return self.friendships.get(user, set())
    
    def mutual_friends(self, user1, user2):
        """Find mutual friends between two users"""
        friends1 = self.friendships.get(user1, set())
        friends2 = self.friendships.get(user2, set())
        return friends1 & friends2
    
    def suggest_friends(self, user):
        """Suggest friends based on mutual connections"""
        friends = self.friendships.get(user, set())
        suggestions = set()
        
        for friend in friends:
            # Friends of friends
            suggestions |= self.friendships.get(friend, set())
        
        # Remove user and existing friends
        suggestions.discard(user)
        suggestions -= friends
        
        return suggestions
    
    def degrees_of_separation(self, user1, user2):
        """Find if users are connected and how many degrees apart"""
        if user1 == user2:
            return 0
        
        visited = {user1}
        queue = [(user1, 0)]
        
        while queue:
            current, degree = queue.pop(0)
            
            for friend in self.friendships.get(current, set()):
                if friend == user2:
                    return degree + 1
                
                if friend not in visited:
                    visited.add(friend)
                    queue.append((friend, degree + 1))
        
        return None  # Not connected

# Usage
network = SocialNetwork()
network.add_friendship("Alice", "Bob")
network.add_friendship("Alice", "Charlie")
network.add_friendship("Bob", "Diana")
network.add_friendship("Charlie", "Diana")
network.add_friendship("Diana", "Eve")

print(f"\nAlice's friends: {network.get_friends('Alice')}")
print(f"Mutual friends (Alice, Diana): {network.mutual_friends('Alice', 'Diana')}")
print(f"Friend suggestions for Alice: {network.suggest_friends('Alice')}")
print(f"Degrees of separation (Alice, Eve): {network.degrees_of_separation('Alice', 'Eve')}")
print()

# =============================================================================
# EXAMPLE 5: Inventory Stock Checker
# =============================================================================

print("=" * 60)
print("EXAMPLE 5: Inventory Stock Checker")
print("=" * 60)

class Store:
    def __init__(self, name):
        self.name = name
        self.inventory = set()
    
    def add_product(self, product):
        self.inventory.add(product)
    
    def remove_product(self, product):
        self.inventory.discard(product)
    
    def has_product(self, product):
        return product in self.inventory

# Multiple stores
store1 = Store("Downtown")
store1.inventory = {"laptop", "mouse", "keyboard", "monitor", "webcam"}

store2 = Store("Uptown")
store2.inventory = {"laptop", "tablet", "phone", "monitor", "headphones"}

store3 = Store("Mall")
store3.inventory = {"mouse", "keyboard", "tablet", "headphones", "speaker"}

def products_in_all_stores(*stores):
    """Find products available in all stores"""
    if not stores:
        return set()
    common = stores[0].inventory.copy()
    for store in stores[1:]:
        common &= store.inventory
    return common

def products_in_any_store(*stores):
    """Find all unique products across all stores"""
    all_products = set()
    for store in stores:
        all_products |= store.inventory
    return all_products

def find_product_locations(product, *stores):
    """Find which stores have a product"""
    locations = []
    for store in stores:
        if product in store.inventory:
            locations.append(store.name)
    return locations

def exclusive_products(store, *other_stores):
    """Find products only in this store"""
    exclusive = store.inventory.copy()
    for other in other_stores:
        exclusive -= other.inventory
    return exclusive

print("Store Inventories:")
print(f"  {store1.name}: {store1.inventory}")
print(f"  {store2.name}: {store2.inventory}")
print(f"  {store3.name}: {store3.inventory}")

print(f"\nProducts in all stores: {products_in_all_stores(store1, store2, store3)}")
print(f"Products in any store: {products_in_any_store(store1, store2, store3)}")
print(f"Locations with 'laptop': {find_product_locations('laptop', store1, store2, store3)}")
print(f"Exclusive to {store1.name}: {exclusive_products(store1, store2, store3)}")
print()

# =============================================================================
# EXAMPLE 6: Spell Checker with Word Set
# =============================================================================

print("=" * 60)
print("EXAMPLE 6: Simple Spell Checker")
print("=" * 60)

class SpellChecker:
    def __init__(self):
        # In real app, load from file
        self.dictionary = {
            "hello", "world", "python", "programming", "computer",
            "science", "data", "algorithm", "function", "variable"
        }
    
    def add_word(self, word):
        """Add word to dictionary"""
        self.dictionary.add(word.lower())
    
    def is_valid(self, word):
        """Check if word is in dictionary"""
        return word.lower() in self.dictionary
    
    def check_text(self, text):
        """Find misspelled words in text"""
        words = text.lower().replace(".", "").replace(",", "").split()
        misspelled = set()
        
        for word in words:
            if not self.is_valid(word):
                misspelled.add(word)
        
        return misspelled
    
    def get_stats(self, text):
        """Get spelling statistics"""
        words = text.lower().replace(".", "").replace(",", "").split()
        word_set = set(words)
        
        valid = {w for w in word_set if self.is_valid(w)}
        invalid = word_set - valid
        
        return {
            "total_words": len(words),
            "unique_words": len(word_set),
            "valid_unique": len(valid),
            "invalid_unique": len(invalid),
            "accuracy": len(valid) / len(word_set) * 100 if word_set else 0
        }

# Usage
checker = SpellChecker()
text = "hello world this is a python programming test with som mispeled words"

misspelled = checker.check_text(text)
print(f"Text: {text}")
print(f"Misspelled words: {misspelled}")

stats = checker.get_stats(text)
print(f"\nStatistics:")
for key, value in stats.items():
    if isinstance(value, float):
        print(f"  {key}: {value:.1f}%")
    else:
        print(f"  {key}: {value}")
print()

# =============================================================================
# EXAMPLE 7: Course Prerequisites Checker
# =============================================================================

print("=" * 60)
print("EXAMPLE 7: Course Prerequisites")
print("=" * 60)

class CourseSystem:
    def __init__(self):
        self.courses = {}
        self.completed = {}
    
    def add_course(self, course_id, prerequisites=None):
        """Add a course with its prerequisites"""
        self.courses[course_id] = set(prerequisites) if prerequisites else set()
    
    def complete_course(self, student, course_id):
        """Mark course as completed for student"""
        if student not in self.completed:
            self.completed[student] = set()
        self.completed[student].add(course_id)
    
    def can_enroll(self, student, course_id):
        """Check if student can enroll in course"""
        if course_id not in self.courses:
            return False
        
        prerequisites = self.courses[course_id]
        completed = self.completed.get(student, set())
        
        return prerequisites.issubset(completed)
    
    def missing_prerequisites(self, student, course_id):
        """Find missing prerequisites for a course"""
        if course_id not in self.courses:
            return None
        
        prerequisites = self.courses[course_id]
        completed = self.completed.get(student, set())
        
        return prerequisites - completed
    
    def available_courses(self, student):
        """Find all courses student can enroll in"""
        available = set()
        completed = self.completed.get(student, set())
        
        for course_id, prereqs in self.courses.items():
            if course_id not in completed and prereqs.issubset(completed):
                available.add(course_id)
        
        return available

# Usage
system = CourseSystem()
system.add_course("CS101")  # No prerequisites
system.add_course("CS102", ["CS101"])
system.add_course("CS201", ["CS101", "CS102"])
system.add_course("CS202", ["CS201"])

# Student completes some courses
system.complete_course("Alice", "CS101")
system.complete_course("Alice", "CS102")

print("Alice's completed courses: CS101, CS102")
print(f"Can enroll in CS201: {system.can_enroll('Alice', 'CS201')}")
print(f"Can enroll in CS202: {system.can_enroll('Alice', 'CS202')}")
print(f"Missing for CS202: {system.missing_prerequisites('Alice', 'CS202')}")
print(f"Available courses: {system.available_courses('Alice')}")
print()

# =============================================================================
# EXAMPLE 8: Website Visitor Tracking
# =============================================================================

print("=" * 60)
print("EXAMPLE 8: Website Visitor Tracking")
print("=" * 60)

class WebsiteAnalytics:
    def __init__(self):
        self.daily_visitors = {}
    
    def log_visit(self, day, visitor_id):
        """Log a visitor for a specific day"""
        if day not in self.daily_visitors:
            self.daily_visitors[day] = set()
        self.daily_visitors[day].add(visitor_id)
    
    def unique_visitors(self, day):
        """Get unique visitors for a day"""
        return len(self.daily_visitors.get(day, set()))
    
    def returning_visitors(self, day1, day2):
        """Find visitors who came back on day2 after visiting day1"""
        visitors_day1 = self.daily_visitors.get(day1, set())
        visitors_day2 = self.daily_visitors.get(day2, set())
        return visitors_day1 & visitors_day2
    
    def new_visitors(self, day, previous_days):
        """Find visitors who are new on this day"""
        current = self.daily_visitors.get(day, set())
        previous = set()
        for prev_day in previous_days:
            previous |= self.daily_visitors.get(prev_day, set())
        return current - previous
    
    def total_unique_visitors(self, days):
        """Get total unique visitors across multiple days"""
        all_visitors = set()
        for day in days:
            all_visitors |= self.daily_visitors.get(day, set())
        return len(all_visitors)

# Usage
analytics = WebsiteAnalytics()

# Log some visits
for visitor in ["user1", "user2", "user3", "user4"]:
    analytics.log_visit("Monday", visitor)

for visitor in ["user2", "user3", "user5", "user6"]:
    analytics.log_visit("Tuesday", visitor)

for visitor in ["user1", "user3", "user5", "user7"]:
    analytics.log_visit("Wednesday", visitor)

print("Analytics Report:")
print(f"Monday unique visitors: {analytics.unique_visitors('Monday')}")
print(f"Tuesday unique visitors: {analytics.unique_visitors('Tuesday')}")
print(f"Returning (Mon->Tue): {analytics.returning_visitors('Monday', 'Tuesday')}")
print(f"New on Tuesday: {analytics.new_visitors('Tuesday', ['Monday'])}")
print(f"Total unique (Mon-Wed): {analytics.total_unique_visitors(['Monday', 'Tuesday', 'Wednesday'])}")
print()

print("=" * 60)
print("EXAMPLES COMPLETE!")
print("=" * 60)
