"""
EXERCISES - Sets
================

Practice problems to master Python sets. Solutions are in 04_solutions.py
Try to solve these on your own first!

Difficulty levels: ⭐ Easy | ⭐⭐ Medium | ⭐⭐⭐ Hard
"""

# =============================================================================
# SECTION 1: SET BASICS
# =============================================================================

print("=" * 60)
print("SECTION 1: SET BASICS")
print("=" * 60)

# Exercise 1.1 ⭐
# Create a set with 5 unique numbers
def exercise_1_1():
    # Your code here
    pass

# Exercise 1.2 ⭐
# Add elements to a set
def exercise_1_2():
    fruits = {"apple", "banana"}
    # Add "cherry" and "date"
    # Your code here
    pass

# Exercise 1.3 ⭐
# Remove elements from a set
def exercise_1_3():
    numbers = {1, 2, 3, 4, 5}
    # Remove 3 using remove()
    # Remove 6 using discard() (it doesn't exist, should not error)
    # Your code here
    pass

# Exercise 1.4 ⭐
# Check membership in a set
def exercise_1_4():
    colors = {"red", "green", "blue"}
    # Check if "red" is in the set
    # Check if "yellow" is NOT in the set
    # Your code here
    pass

# Exercise 1.5 ⭐
# Get the length of a set
def exercise_1_5():
    letters = {"a", "b", "c", "d", "e"}
    # Print the number of elements
    # Your code here
    pass

# =============================================================================
# SECTION 2: SET OPERATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 2: SET OPERATIONS")
print("=" * 60)

# Exercise 2.1 ⭐
# Find the union of two sets
def exercise_2_1():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    # Find union using | operator
    # Find union using .union() method
    # Your code here
    pass

# Exercise 2.2 ⭐
# Find the intersection of two sets
def exercise_2_2():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    # Find intersection (common elements)
    # Your code here
    pass

# Exercise 2.3 ⭐
# Find the difference between two sets
def exercise_2_3():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    # Find elements in a but not in b
    # Find elements in b but not in a
    # Your code here
    pass

# Exercise 2.4 ⭐⭐
# Find symmetric difference
def exercise_2_4():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    # Find elements in a or b, but not both
    # Your code here
    pass

# Exercise 2.5 ⭐⭐
# Check if one set is a subset of another
def exercise_2_5():
    a = {1, 2}
    b = {1, 2, 3, 4, 5}
    # Check if a is a subset of b
    # Check if b is a superset of a
    # Your code here
    pass

# =============================================================================
# SECTION 3: REMOVING DUPLICATES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 3: REMOVING DUPLICATES")
print("=" * 60)

# Exercise 3.1 ⭐
# Remove duplicates from a list
def exercise_3_1():
    numbers = [1, 2, 2, 3, 3, 3, 4, 5, 5]
    # Convert to set and back to list to remove duplicates
    # Your code here
    pass

# Exercise 3.2 ⭐⭐
# Remove duplicates while preserving order
def exercise_3_2():
    items = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]
    # Remove duplicates but keep first occurrence order
    # Your code here
    # Hint: Use a set to track seen items
    pass

# Exercise 3.3 ⭐⭐
# Check if a list has duplicates
def exercise_3_3(items):
    """Return True if list has duplicates, False otherwise"""
    # Your code here
    pass

# Exercise 3.4 ⭐⭐
# Find duplicate elements
def exercise_3_4(items):
    """Return a set of elements that appear more than once"""
    # Your code here
    pass

# =============================================================================
# SECTION 4: SET COMPREHENSIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 4: SET COMPREHENSIONS")
print("=" * 60)

# Exercise 4.1 ⭐
# Create a set of squares using comprehension
def exercise_4_1():
    # Create set of squares from 1 to 10
    # Your code here
    pass

# Exercise 4.2 ⭐
# Create a set with condition
def exercise_4_2():
    # Create set of even numbers from 1 to 20
    # Your code here
    pass

# Exercise 4.3 ⭐⭐
# Extract unique characters
def exercise_4_3(text):
    """Extract unique lowercase letters from text"""
    # Your code here
    pass

# Exercise 4.4 ⭐⭐
# Set from two lists
def exercise_4_4():
    list1 = [1, 2, 3, 4, 5]
    list2 = [4, 5, 6, 7, 8]
    # Create set of numbers that appear in either list
    # Your code here
    pass

# =============================================================================
# SECTION 5: PRACTICAL APPLICATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 5: PRACTICAL APPLICATIONS")
print("=" * 60)

# Exercise 5.1 ⭐⭐
# Find common elements in multiple lists
def exercise_5_1():
    list1 = [1, 2, 3, 4, 5]
    list2 = [2, 3, 4, 5, 6]
    list3 = [3, 4, 5, 6, 7]
    # Find elements common to all three lists
    # Your code here
    pass

# Exercise 5.2 ⭐⭐
# Find unique elements across lists
def exercise_5_2():
    list1 = [1, 2, 3]
    list2 = [3, 4, 5]
    list3 = [5, 6, 7]
    # Find all unique elements across all lists
    # Your code here
    pass

# Exercise 5.3 ⭐⭐
# Count unique words in text
def exercise_5_3(text):
    """Count number of unique words in text (case insensitive)"""
    # Your code here
    pass

# Exercise 5.4 ⭐⭐⭐
# Find words that appear in one text but not another
def exercise_5_4(text1, text2):
    """Find words in text1 that don't appear in text2"""
    # Your code here
    pass

# Exercise 5.5 ⭐⭐⭐
# Validate email list
def exercise_5_5(emails):
    """
    Return set of valid unique emails
    Valid: contains @ and .
    Convert to lowercase
    Remove duplicates
    """
    # Your code here
    pass

# =============================================================================
# SECTION 6: FROZENSETS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 6: FROZENSETS")
print("=" * 60)

# Exercise 6.1 ⭐
# Create a frozenset
def exercise_6_1():
    # Create a frozenset from [1, 2, 3, 4, 5]
    # Your code here
    pass

# Exercise 6.2 ⭐⭐
# Use frozenset as dictionary key
def exercise_6_2():
    # Create a dictionary with frozensets as keys
    # Map frozenset([1, 2]) to "group1"
    # Map frozenset([3, 4]) to "group2"
    # Your code here
    pass

# Exercise 6.3 ⭐⭐
# Set of sets using frozensets
def exercise_6_3():
    # Create a set containing multiple frozensets
    # Your code here
    pass

# =============================================================================
# SECTION 7: REAL-WORLD CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 7: REAL-WORLD CHALLENGES")
print("=" * 60)

# Exercise 7.1 ⭐⭐⭐
# Student enrollment system
def exercise_7_1():
    """
    Create a system to track student course enrollments:
    - Add student to course
    - Remove student from course
    - Find students enrolled in multiple courses
    - Find courses a student is enrolled in
    """
    # Your code here
    pass

# Exercise 7.2 ⭐⭐⭐
# Friend recommendation system
def exercise_7_2():
    """
    Given friendships as dict of sets:
    - Find mutual friends between two people
    - Suggest friends (friends of friends, excluding existing friends)
    """
    friendships = {
        "Alice": {"Bob", "Charlie"},
        "Bob": {"Alice", "Diana"},
        "Charlie": {"Alice", "Diana"},
        "Diana": {"Bob", "Charlie", "Eve"}
    }
    # Your code here
    pass

# Exercise 7.3 ⭐⭐⭐
# Product category manager
def exercise_7_3():
    """
    Track products and their categories:
    - Add product to categories
    - Find products in multiple categories
    - Find products exclusive to one category
    """
    # Your code here
    pass

# Exercise 7.4 ⭐⭐⭐
# Permission system
def exercise_7_4():
    """
    Create a role-based permission system:
    - Assign permissions to roles
    - Assign roles to users
    - Check if user has permission
    - Find all users with a specific permission
    """
    # Your code here
    pass

# Exercise 7.5 ⭐⭐⭐
# Tag-based search system
def exercise_7_5():
    """
    Create a tag-based search for articles:
    - Add tags to articles
    - Search articles by tags (must have all tags)
    - Search articles by tags (must have any tag)
    - Find most common tags
    """
    # Your code here
    pass

# =============================================================================
# SECTION 8: ADVANCED CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 8: ADVANCED CHALLENGES")
print("=" * 60)

# Exercise 8.1 ⭐⭐⭐
# Jaccard similarity
def jaccard_similarity(set1, set2):
    """
    Calculate Jaccard similarity: |A ∩ B| / |A ∪ B|
    Returns value between 0 and 1
    """
    # Your code here
    pass

# Exercise 8.2 ⭐⭐⭐
# Power set
def power_set(s):
    """
    Generate all subsets of a set
    Example: {1, 2} -> {}, {1}, {2}, {1, 2}
    """
    # Your code here
    pass

# Exercise 8.3 ⭐⭐⭐
# Disjoint set groups
def find_disjoint_groups(sets):
    """
    Group sets that share common elements
    Example: [{1,2}, {2,3}, {4,5}] -> [{1,2,3}, {4,5}]
    """
    # Your code here
    pass

# Exercise 8.4 ⭐⭐⭐
# Connected components
def find_connected_components(edges):
    """
    Find connected components in a graph
    edges = [(1,2), (2,3), (4,5)] -> [{1,2,3}, {4,5}]
    """
    # Your code here
    pass

# Exercise 8.5 ⭐⭐⭐
# Set cover problem (greedy approach)
def set_cover(universe, subsets):
    """
    Find minimum number of subsets that cover all elements
    universe = {1,2,3,4,5}
    subsets = [{1,2}, {2,3,4}, {4,5}]
    """
    # Your code here
    pass

# =============================================================================
# BONUS CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("BONUS CHALLENGES")
print("=" * 60)

# Bonus 1 ⭐⭐⭐
# Anagram groups
def group_anagrams(words):
    """
    Group words that are anagrams of each other
    ["eat", "tea", "tan", "ate", "nat", "bat"]
    -> [{"eat", "tea", "ate"}, {"tan", "nat"}, {"bat"}]
    """
    # Your code here
    pass

# Bonus 2 ⭐⭐⭐
# Bloom filter (simple version)
class SimpleBloomFilter:
    """
    Implement a simple bloom filter using sets
    - May have false positives
    - Never has false negatives
    """
    def __init__(self, size):
        # Your code here
        pass
    
    def add(self, item):
        # Your code here
        pass
    
    def might_contain(self, item):
        # Your code here
        pass

# Bonus 3 ⭐⭐⭐
# Sudoku validator
def is_valid_sudoku(board):
    """
    Check if a 9x9 Sudoku board is valid
    Use sets to check for duplicates in rows, columns, and boxes
    """
    # Your code here
    pass

# Bonus 4 ⭐⭐⭐
# Collaborative filtering
def recommend_items(user_items, all_user_items):
    """
    Recommend items based on what similar users liked
    user_items: set of items current user likes
    all_user_items: dict mapping users to their item sets
    Returns: recommended items
    """
    # Your code here
    pass

# Bonus 5 ⭐⭐⭐
# Version control merge
def find_merge_conflicts(branch1_files, branch2_files, base_files):
    """
    Find files that were modified in both branches
    Returns: (clean_merges, conflicts)
    """
    # Your code here
    pass

print("\n" + "=" * 60)
print("EXERCISES COMPLETE!")
print("Check 04_solutions.py for answers")
print("=" * 60)
