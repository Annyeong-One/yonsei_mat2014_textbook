"""
SOLUTIONS - Sets
================

Solutions to all exercises in 03_exercises.py
Study these after attempting the problems yourself!
"""

# =============================================================================
# SECTION 1: SET BASICS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 1: SET BASICS - SOLUTIONS")
print("=" * 60)

# Exercise 1.1 Solution
def exercise_1_1():
    numbers = {1, 2, 3, 4, 5}
    print(f"Set: {numbers}")

exercise_1_1()

# Exercise 1.2 Solution
def exercise_1_2():
    fruits = {"apple", "banana"}
    fruits.add("cherry")
    fruits.add("date")
    print(f"After adding: {fruits}")

exercise_1_2()

# Exercise 1.3 Solution
def exercise_1_3():
    numbers = {1, 2, 3, 4, 5}
    numbers.remove(3)
    print(f"After remove(3): {numbers}")
    
    numbers.discard(6)  # No error even though 6 doesn't exist
    print(f"After discard(6): {numbers}")

exercise_1_3()

# Exercise 1.4 Solution
def exercise_1_4():
    colors = {"red", "green", "blue"}
    print(f"'red' in colors: {'red' in colors}")
    print(f"'yellow' not in colors: {'yellow' not in colors}")

exercise_1_4()

# Exercise 1.5 Solution
def exercise_1_5():
    letters = {"a", "b", "c", "d", "e"}
    print(f"Number of elements: {len(letters)}")

exercise_1_5()
print()

# =============================================================================
# SECTION 2: SET OPERATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 2: SET OPERATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 2.1 Solution
def exercise_2_1():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    print(f"Union (|): {a | b}")
    print(f"Union (.union()): {a.union(b)}")

exercise_2_1()

# Exercise 2.2 Solution
def exercise_2_2():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    print(f"Intersection: {a & b}")
    print(f"Intersection (.intersection()): {a.intersection(b)}")

exercise_2_2()

# Exercise 2.3 Solution
def exercise_2_3():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    print(f"In a but not b: {a - b}")
    print(f"In b but not a: {b - a}")

exercise_2_3()

# Exercise 2.4 Solution
def exercise_2_4():
    a = {1, 2, 3, 4}
    b = {3, 4, 5, 6}
    print(f"Symmetric difference: {a ^ b}")
    print(f"Symmetric difference (.symmetric_difference()): {a.symmetric_difference(b)}")

exercise_2_4()

# Exercise 2.5 Solution
def exercise_2_5():
    a = {1, 2}
    b = {1, 2, 3, 4, 5}
    print(f"a is subset of b: {a <= b}")
    print(f"a.issubset(b): {a.issubset(b)}")
    print(f"b is superset of a: {b >= a}")
    print(f"b.issuperset(a): {b.issuperset(a)}")

exercise_2_5()
print()

# =============================================================================
# SECTION 3: REMOVING DUPLICATES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 3: REMOVING DUPLICATES - SOLUTIONS")
print("=" * 60)

# Exercise 3.1 Solution
def exercise_3_1():
    numbers = [1, 2, 2, 3, 3, 3, 4, 5, 5]
    unique = list(set(numbers))
    print(f"Without duplicates: {unique}")

exercise_3_1()

# Exercise 3.2 Solution
def exercise_3_2():
    items = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]
    seen = set()
    result = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    print(f"Preserving order: {result}")

exercise_3_2()

# Exercise 3.3 Solution
def exercise_3_3(items):
    return len(items) != len(set(items))

print(f"Has duplicates [1,2,2,3]: {exercise_3_3([1, 2, 2, 3])}")
print(f"Has duplicates [1,2,3,4]: {exercise_3_3([1, 2, 3, 4])}")

# Exercise 3.4 Solution
def exercise_3_4(items):
    seen = set()
    duplicates = set()
    for item in items:
        if item in seen:
            duplicates.add(item)
        seen.add(item)
    return duplicates

print(f"Duplicate elements: {exercise_3_4([1, 2, 2, 3, 3, 3, 4])}")
print()

# =============================================================================
# SECTION 4: SET COMPREHENSIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 4: SET COMPREHENSIONS - SOLUTIONS")
print("=" * 60)

# Exercise 4.1 Solution
def exercise_4_1():
    squares = {x**2 for x in range(1, 11)}
    print(f"Squares: {squares}")

exercise_4_1()

# Exercise 4.2 Solution
def exercise_4_2():
    evens = {x for x in range(1, 21) if x % 2 == 0}
    print(f"Evens: {evens}")

exercise_4_2()

# Exercise 4.3 Solution
def exercise_4_3(text):
    return {char.lower() for char in text if char.isalpha()}

print(f"Unique letters: {exercise_4_3('Hello World!')}")

# Exercise 4.4 Solution
def exercise_4_4():
    list1 = [1, 2, 3, 4, 5]
    list2 = [4, 5, 6, 7, 8]
    combined = set(list1) | set(list2)
    print(f"Combined: {combined}")

exercise_4_4()
print()

# =============================================================================
# SECTION 5: PRACTICAL APPLICATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 5: PRACTICAL APPLICATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 5.1 Solution
def exercise_5_1():
    list1 = [1, 2, 3, 4, 5]
    list2 = [2, 3, 4, 5, 6]
    list3 = [3, 4, 5, 6, 7]
    common = set(list1) & set(list2) & set(list3)
    print(f"Common to all: {common}")

exercise_5_1()

# Exercise 5.2 Solution
def exercise_5_2():
    list1 = [1, 2, 3]
    list2 = [3, 4, 5]
    list3 = [5, 6, 7]
    all_unique = set(list1) | set(list2) | set(list3)
    print(f"All unique: {all_unique}")

exercise_5_2()

# Exercise 5.3 Solution
def exercise_5_3(text):
    words = text.lower().split()
    return len(set(words))

print(f"Unique word count: {exercise_5_3('hello world hello python world')}")

# Exercise 5.4 Solution
def exercise_5_4(text1, text2):
    words1 = set(text1.lower().split())
    words2 = set(text2.lower().split())
    return words1 - words2

print(f"Words only in text1: {exercise_5_4('hello world python', 'hello java')}")

# Exercise 5.5 Solution
def exercise_5_5(emails):
    valid = set()
    for email in emails:
        email = email.lower().strip()
        if '@' in email and '.' in email:
            valid.add(email)
    return valid

emails = ["alice@email.com", "BOB@EMAIL.COM", "invalid", "charlie@test.com"]
print(f"Valid emails: {exercise_5_5(emails)}")
print()

# =============================================================================
# SECTION 6: FROZENSETS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 6: FROZENSETS - SOLUTIONS")
print("=" * 60)

# Exercise 6.1 Solution
def exercise_6_1():
    frozen = frozenset([1, 2, 3, 4, 5])
    print(f"Frozenset: {frozen}")

exercise_6_1()

# Exercise 6.2 Solution
def exercise_6_2():
    groups = {
        frozenset([1, 2]): "group1",
        frozenset([3, 4]): "group2"
    }
    print(f"Dict with frozenset keys: {groups}")

exercise_6_2()

# Exercise 6.3 Solution
def exercise_6_3():
    set_of_sets = {frozenset([1, 2]), frozenset([3, 4]), frozenset([5, 6])}
    print(f"Set of frozensets: {set_of_sets}")

exercise_6_3()
print()

# =============================================================================
# SECTION 7: REAL-WORLD CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 7: REAL-WORLD CHALLENGES - SOLUTIONS")
print("=" * 60)

# Exercise 7.1 Solution
def exercise_7_1():
    class EnrollmentSystem:
        def __init__(self):
            self.enrollments = {}  # course -> set of students
            self.student_courses = {}  # student -> set of courses
        
        def enroll(self, student, course):
            if course not in self.enrollments:
                self.enrollments[course] = set()
            self.enrollments[course].add(student)
            
            if student not in self.student_courses:
                self.student_courses[student] = set()
            self.student_courses[student].add(course)
        
        def drop(self, student, course):
            if course in self.enrollments:
                self.enrollments[course].discard(student)
            if student in self.student_courses:
                self.student_courses[student].discard(course)
        
        def students_in_multiple(self, *courses):
            if not courses:
                return set()
            students = self.enrollments.get(courses[0], set()).copy()
            for course in courses[1:]:
                students &= self.enrollments.get(course, set())
            return students
        
        def get_courses(self, student):
            return self.student_courses.get(student, set())
    
    system = EnrollmentSystem()
    system.enroll("Alice", "Math")
    system.enroll("Alice", "CS")
    system.enroll("Bob", "Math")
    system.enroll("Bob", "CS")
    
    print(f"Students in both Math and CS: {system.students_in_multiple('Math', 'CS')}")
    print(f"Alice's courses: {system.get_courses('Alice')}")

exercise_7_1()

# Exercise 7.2 Solution
def exercise_7_2():
    friendships = {
        "Alice": {"Bob", "Charlie"},
        "Bob": {"Alice", "Diana"},
        "Charlie": {"Alice", "Diana"},
        "Diana": {"Bob", "Charlie", "Eve"}
    }
    
    def mutual_friends(person1, person2):
        return friendships.get(person1, set()) & friendships.get(person2, set())
    
    def suggest_friends(person):
        friends = friendships.get(person, set())
        suggestions = set()
        for friend in friends:
            suggestions |= friendships.get(friend, set())
        suggestions.discard(person)
        suggestions -= friends
        return suggestions
    
    print(f"Mutual friends (Alice, Diana): {mutual_friends('Alice', 'Diana')}")
    print(f"Friend suggestions for Alice: {suggest_friends('Alice')}")

exercise_7_2()

# Exercise 7.3 Solution
def exercise_7_3():
    class CategoryManager:
        def __init__(self):
            self.products = {}  # product -> set of categories
        
        def add_to_category(self, product, category):
            if product not in self.products:
                self.products[product] = set()
            self.products[product].add(category)
        
        def in_multiple_categories(self, *categories):
            result = set()
            for product, cats in self.products.items():
                if set(categories).issubset(cats):
                    result.add(product)
            return result
        
        def exclusive_to(self, category):
            result = set()
            for product, cats in self.products.items():
                if cats == {category}:
                    result.add(product)
            return result
    
    manager = CategoryManager()
    manager.add_to_category("Laptop", "Electronics")
    manager.add_to_category("Laptop", "Computers")
    manager.add_to_category("Phone", "Electronics")
    
    print(f"In multiple categories: {manager.in_multiple_categories('Electronics', 'Computers')}")
    print(f"Exclusive to Electronics: {manager.exclusive_to('Electronics')}")

exercise_7_3()

# Exercise 7.4 Solution
def exercise_7_4():
    class PermissionSystem:
        def __init__(self):
            self.role_permissions = {}  # role -> set of permissions
            self.user_roles = {}  # user -> set of roles
        
        def assign_permission(self, role, permission):
            if role not in self.role_permissions:
                self.role_permissions[role] = set()
            self.role_permissions[role].add(permission)
        
        def assign_role(self, user, role):
            if user not in self.user_roles:
                self.user_roles[user] = set()
            self.user_roles[user].add(role)
        
        def has_permission(self, user, permission):
            roles = self.user_roles.get(user, set())
            for role in roles:
                if permission in self.role_permissions.get(role, set()):
                    return True
            return False
        
        def users_with_permission(self, permission):
            result = set()
            for user, roles in self.user_roles.items():
                for role in roles:
                    if permission in self.role_permissions.get(role, set()):
                        result.add(user)
                        break
            return result
    
    system = PermissionSystem()
    system.assign_permission("admin", "read")
    system.assign_permission("admin", "write")
    system.assign_permission("user", "read")
    system.assign_role("Alice", "admin")
    system.assign_role("Bob", "user")
    
    print(f"Alice has write: {system.has_permission('Alice', 'write')}")
    print(f"Bob has write: {system.has_permission('Bob', 'write')}")
    print(f"Users with read: {system.users_with_permission('read')}")

exercise_7_4()

# Exercise 7.5 Solution
def exercise_7_5():
    class TagSearchSystem:
        def __init__(self):
            self.articles = {}  # article -> set of tags
        
        def add_tags(self, article, *tags):
            if article not in self.articles:
                self.articles[article] = set()
            self.articles[article].update(tags)
        
        def search_all(self, *tags):
            """Articles that have ALL specified tags"""
            required = set(tags)
            return {article for article, article_tags in self.articles.items()
                   if required.issubset(article_tags)}
        
        def search_any(self, *tags):
            """Articles that have ANY of the specified tags"""
            search_tags = set(tags)
            return {article for article, article_tags in self.articles.items()
                   if not search_tags.isdisjoint(article_tags)}
        
        def most_common_tags(self, n=5):
            from collections import Counter
            all_tags = []
            for tags in self.articles.values():
                all_tags.extend(tags)
            return Counter(all_tags).most_common(n)
    
    system = TagSearchSystem()
    system.add_tags("Article1", "python", "programming", "beginner")
    system.add_tags("Article2", "python", "web", "django")
    system.add_tags("Article3", "javascript", "web", "frontend")
    
    print(f"With python AND web: {system.search_all('python', 'web')}")
    print(f"With python OR web: {system.search_any('python', 'web')}")
    print(f"Most common tags: {system.most_common_tags(3)}")

exercise_7_5()
print()

# =============================================================================
# SECTION 8: ADVANCED CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 8: ADVANCED CHALLENGES - SOLUTIONS")
print("=" * 60)

# Exercise 8.1 Solution
def jaccard_similarity(set1, set2):
    intersection = len(set1 & set2)
    union = len(set1 | set2)
    return intersection / union if union > 0 else 0

print(f"Jaccard similarity: {jaccard_similarity({1, 2, 3}, {2, 3, 4}):.2f}")

# Exercise 8.2 Solution
def power_set(s):
    s = list(s)
    result = []
    for i in range(2 ** len(s)):
        subset = {s[j] for j in range(len(s)) if (i & (1 << j))}
        result.append(subset)
    return result

print(f"Power set of {{1,2}}: {power_set({1, 2})}")

# Exercise 8.3 Solution
def find_disjoint_groups(sets):
    if not sets:
        return []
    
    sets = [set(s) for s in sets]
    groups = []
    
    for s in sets:
        merged = False
        for group in groups:
            if not group.isdisjoint(s):
                group |= s
                merged = True
                break
        if not merged:
            groups.append(s.copy())
    
    # Merge groups that became connected
    changed = True
    while changed:
        changed = False
        new_groups = []
        while groups:
            current = groups.pop(0)
            merged = False
            for i, group in enumerate(new_groups):
                if not group.isdisjoint(current):
                    new_groups[i] |= current
                    merged = True
                    changed = True
                    break
            if not merged:
                new_groups.append(current)
        groups = new_groups
    
    return groups

print(f"Disjoint groups: {find_disjoint_groups([{1,2}, {2,3}, {4,5}])}")

# Exercise 8.4 Solution
def find_connected_components(edges):
    graph = {}
    for a, b in edges:
        if a not in graph:
            graph[a] = set()
        if b not in graph:
            graph[b] = set()
        graph[a].add(b)
        graph[b].add(a)
    
    components = []
    visited = set()
    
    for node in graph:
        if node not in visited:
            component = set()
            stack = [node]
            while stack:
                current = stack.pop()
                if current not in visited:
                    visited.add(current)
                    component.add(current)
                    stack.extend(graph[current] - visited)
            components.append(component)
    
    return components

print(f"Connected components: {find_connected_components([(1,2), (2,3), (4,5)])}")

# Exercise 8.5 Solution
def set_cover(universe, subsets):
    universe = set(universe)
    subsets = [set(s) for s in subsets]
    covered = set()
    selected = []
    
    while covered != universe:
        best = max(subsets, key=lambda s: len(s - covered))
        selected.append(best)
        covered |= best
    
    return selected

universe = {1, 2, 3, 4, 5}
subsets = [{1, 2}, {2, 3, 4}, {4, 5}]
print(f"Set cover: {set_cover(universe, subsets)}")
print()

# =============================================================================
# BONUS CHALLENGES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("BONUS CHALLENGES - SOLUTIONS")
print("=" * 60)

# Bonus 1 Solution
def group_anagrams(words):
    groups = {}
    for word in words:
        key = frozenset(word)
        if key not in groups:
            groups[key] = set()
        groups[key].add(word)
    return list(groups.values())

print(f"Anagram groups: {group_anagrams(['eat', 'tea', 'tan', 'ate', 'nat', 'bat'])}")

# Bonus 2 Solution
class SimpleBloomFilter:
    def __init__(self, size):
        self.size = size
        self.bits = set()
    
    def _hash(self, item):
        return hash(item) % self.size
    
    def add(self, item):
        self.bits.add(self._hash(item))
    
    def might_contain(self, item):
        return self._hash(item) in self.bits

bloom = SimpleBloomFilter(100)
bloom.add("apple")
print(f"Might contain 'apple': {bloom.might_contain('apple')}")
print(f"Might contain 'banana': {bloom.might_contain('banana')}")

# Bonus 3 Solution
def is_valid_sudoku(board):
    # Check rows
    for row in board:
        nums = {n for n in row if n != 0}
        if len(nums) != len([n for n in row if n != 0]):
            return False
    
    # Check columns
    for col in range(9):
        nums = {board[row][col] for row in range(9) if board[row][col] != 0}
        if len(nums) != len([board[row][col] for row in range(9) if board[row][col] != 0]):
            return False
    
    # Check 3x3 boxes
    for box_row in range(3):
        for box_col in range(3):
            nums = set()
            count = 0
            for i in range(3):
                for j in range(3):
                    val = board[box_row*3+i][box_col*3+j]
                    if val != 0:
                        nums.add(val)
                        count += 1
            if len(nums) != count:
                return False
    
    return True

# Bonus 4 Solution
def recommend_items(user_items, all_user_items):
    similar_users = {}
    for user, items in all_user_items.items():
        similarity = len(user_items & items)
        if similarity > 0:
            similar_users[user] = similarity
    
    recommendations = set()
    for user in sorted(similar_users, key=similar_users.get, reverse=True)[:5]:
        recommendations |= all_user_items[user]
    
    recommendations -= user_items
    return recommendations

user = {"item1", "item2"}
all_users = {
    "user1": {"item1", "item2", "item3"},
    "user2": {"item2", "item4"},
    "user3": {"item1", "item5"}
}
print(f"Recommendations: {recommend_items(user, all_users)}")

# Bonus 5 Solution
def find_merge_conflicts(branch1_files, branch2_files, base_files):
    modified_in_1 = branch1_files - base_files
    modified_in_2 = branch2_files - base_files
    
    conflicts = modified_in_1 & modified_in_2
    clean_merges = (modified_in_1 | modified_in_2) - conflicts
    
    return (clean_merges, conflicts)

branch1 = {"file1.py", "file2.py", "file3.py"}
branch2 = {"file1.py", "file4.py"}
base = {"file1.py"}
print(f"Merge analysis: {find_merge_conflicts(branch1, branch2, base)}")

print("\n" + "=" * 60)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 60)
