# Sets - Python Data Structures

## Overview
This module covers Python sets - unordered collections of unique elements that are perfect for membership testing, removing duplicates, and mathematical set operations.

## Contents
- **01_sets_tutorial.py** - Complete guide to Python sets
- **02_examples.py** - Practical real-world examples
- **03_exercises.py** - Practice problems (try these first!)
- **04_solutions.py** - Solutions to the exercises

## Learning Objectives
By the end of this module, you should be able to:
- Create and manipulate sets and frozensets
- Use set operations (union, intersection, difference, etc.)
- Apply set methods effectively
- Understand when to use sets vs other data structures
- Use sets for duplicate removal and membership testing
- Work with set comprehensions

## Recommended Learning Path
1. Read through `01_sets_tutorial.py`
2. Study the examples in `02_examples.py`
3. Attempt the exercises in `03_exercises.py`
4. Check your solutions against `04_solutions.py`

## Quick Reference

### Creating Sets
```python
# Empty set (note: {} creates a dict, not a set!)
my_set = set()

# With initial values
my_set = {1, 2, 3, 4, 5}
my_set = set([1, 2, 3])
```

### Set Operations
```python
# Union (all elements)
a | b  or  a.union(b)

# Intersection (common elements)
a & b  or  a.intersection(b)

# Difference (in a but not in b)
a - b  or  a.difference(b)

# Symmetric difference (in a or b, but not both)
a ^ b  or  a.symmetric_difference(b)

# Subset
a <= b  or  a.issubset(b)

# Superset
a >= b  or  a.issuperset(b)
```

### Key Features
- **Unordered** - no indexing or slicing
- **Unique elements** - duplicates automatically removed
- **Mutable** - can add/remove elements (use frozenset for immutable)
- **Fast membership testing** - O(1) average time
- **Elements must be hashable** - can't contain lists or other sets

Happy learning!
