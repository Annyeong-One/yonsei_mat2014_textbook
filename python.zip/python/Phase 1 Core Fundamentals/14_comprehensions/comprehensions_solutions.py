# Python Comprehensions - Solutions

## Part 1: List Comprehensions

### Exercise 1: Basic Transformation
```python
cubes = [x**3 for x in range(1, 11)]
print(cubes)
# [1, 8, 27, 64, 125, 216, 343, 512, 729, 1000]
```

### Exercise 2: String Manipulation
```python
names = ['ALICE', 'Bob', 'CHARLIE', 'diana', 'EVE']
lowercase_names = [name.lower() for name in names]
print(lowercase_names)
# ['alice', 'bob', 'charlie', 'diana', 'eve']
```

### Exercise 3: Filtering
```python
numbers = list(range(1, 11))

# Odd numbers
odds = [x for x in numbers if x % 2 != 0]
print(odds)  # [1, 3, 5, 7, 9]

# Divisible by 3
div_by_3 = [x for x in numbers if x % 3 == 0]
print(div_by_3)  # [3, 6, 9]

# Greater than 5
greater_5 = [x for x in numbers if x > 5]
print(greater_5)  # [6, 7, 8, 9, 10]
```

### Exercise 4: Conditional Transformation
```python
celsius = [25, -5, 15, -10, 30, 0]
fahrenheit = [c * 9/5 + 32 if c >= 0 else 'Freezing' for c in celsius]
print(fahrenheit)
# [77.0, 'Freezing', 59.0, 'Freezing', 86.0, 32.0]
```

### Exercise 5: Working with Strings
```python
sentence = "Python Programming is Fun"
vowels = [char for char in sentence if char.lower() in 'aeiou']
print(vowels)
# ['o', 'o', 'a', 'i', 'i', 'u']
```

### Exercise 6: List of Tuples
```python
subjects = ['Math', 'Science', 'English']
scores = [85, 92, 88]
combined = [(subject, score) for subject, score in zip(subjects, scores)]
print(combined)
# [('Math', 85), ('Science', 92), ('English', 88)]

# Alternative using list()
combined = list(zip(subjects, scores))
```

### Exercise 7: Nested List Comprehension
```python
matrix = [[i + j for j in range(5)] for i in range(5)]
for row in matrix:
    print(row)
# [[0, 1, 2, 3, 4],
#  [1, 2, 3, 4, 5],
#  [2, 3, 4, 5, 6],
#  [3, 4, 5, 6, 7],
#  [4, 5, 6, 7, 8]]
```

### Exercise 8: Flattening
```python
nested = [[1, 2, 3], [4, 5], [6, 7, 8, 9]]
flat = [num for sublist in nested for num in sublist]
print(flat)
# [1, 2, 3, 4, 5, 6, 7, 8, 9]
```

### Exercise 9: Multiple Conditions
```python
# Divisible by 3 OR 5, but NOT both
numbers = [x for x in range(1, 51) if (x % 3 == 0 or x % 5 == 0) and not (x % 3 == 0 and x % 5 == 0)]
print(numbers)
# [3, 5, 6, 9, 10, 12, 18, 20, 21, 24, 25, 27, 33, 35, 36, 39, 40, 42, 48, 50]

# Alternative using XOR
numbers = [x for x in range(1, 51) if (x % 3 == 0) != (x % 5 == 0)]
```

### Exercise 10: String Processing
```python
words = ['apple', 'cat', 'elephant', 'dog', 'orange', 'ant', 'umbrella']
result = [word.upper() for word in words if word[0] in 'aeiou' and len(word) > 3]
print(result)
# ['APPLE', 'ELEPHANT', 'ORANGE', 'UMBRELLA']
```

## Part 2: Dictionary Comprehensions

### Exercise 11: Create Character Count
```python
text = "hello world"
char_count = {char: text.count(char) for char in text if char != ' '}
print(char_count)
# {'h': 1, 'e': 1, 'l': 3, 'o': 2, 'w': 1, 'r': 1, 'd': 1}

# More efficient version (counts once)
char_count = {}
for char in text:
    if char != ' ':
        char_count[char] = char_count.get(char, 0) + 1
```

### Exercise 12: Square Dictionary
```python
squares = {x: x**2 for x in range(1, 11)}
print(squares)
# {1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81, 10: 100}
```

### Exercise 13: Filter Dictionary
```python
products = {'laptop': 1200, 'mouse': 25, 'keyboard': 75, 'monitor': 300, 'cable': 15}
affordable = {k: v for k, v in products.items() if v < 50}
print(affordable)
# {'mouse': 25, 'cable': 15}
```

### Exercise 14: Transform Values
```python
ages = {'Alice': 25, 'Bob': 30, 'Charlie': 35}
next_year = {name: age + 1 for name, age in ages.items()}
print(next_year)
# {'Alice': 26, 'Bob': 31, 'Charlie': 36}
```

### Exercise 15: Swap Keys and Values
```python
grade_letters = {'A': 90, 'B': 80, 'C': 70, 'D': 60}
swapped = {v: k for k, v in grade_letters.items()}
print(swapped)
# {90: 'A', 80: 'B', 70: 'C', 60: 'D'}
```

### Exercise 16: Combine Lists into Dictionary
```python
fruits = ['apple', 'banana', 'cherry', 'date']
colors = ['red', 'yellow', 'red', 'brown']
fruit_colors = {fruit: color for fruit, color in zip(fruits, colors)}
print(fruit_colors)
# {'apple': 'red', 'banana': 'yellow', 'cherry': 'red', 'date': 'brown'}
```

### Exercise 17: Conditional Dictionary
```python
words = ['cat', 'elephant', 'dog', 'butterfly', 'ant']
word_lengths = {word: 'short' if len(word) <= 5 else 'long' for word in words}
print(word_lengths)
# {'cat': 'short', 'elephant': 'long', 'dog': 'short', 'butterfly': 'long', 'ant': 'short'}
```

### Exercise 18: Nested Dictionary
```python
students = ['Alice', 'Bob', 'Charlie']
subjects = ['Math', 'Science', 'English']
gradebook = {student: {subject: 0 for subject in subjects} for student in students}
print(gradebook)
# {'Alice': {'Math': 0, 'Science': 0, 'English': 0},
#  'Bob': {'Math': 0, 'Science': 0, 'English': 0},
#  'Charlie': {'Math': 0, 'Science': 0, 'English': 0}}
```

## Part 3: Set Comprehensions

### Exercise 19: Unique Squares
```python
numbers = [1, 2, 3, 4, 5, 2, 3, 4, 5, 6]
unique_squares = {x**2 for x in numbers}
print(unique_squares)
# {1, 4, 9, 16, 25, 36}
```

### Exercise 20: First Letters
```python
sentence = "the quick brown fox jumps over the lazy dog"
first_letters = {word[0] for word in sentence.split()}
print(first_letters)
# {'t', 'q', 'b', 'f', 'j', 'o', 'l', 'd'}
```

### Exercise 21: Unique Lengths
```python
words = ['cat', 'elephant', 'dog', 'bird', 'butterfly', 'ant']
lengths = {len(word) for word in words}
print(lengths)
# {3, 4, 8, 9}
```

### Exercise 22: Even Numbers Set
```python
evens = {x for x in range(1, 21) if x % 2 == 0}
print(evens)
# {2, 4, 6, 8, 10, 12, 14, 16, 18, 20}

# Alternative
evens = {x for x in range(2, 21, 2)}
```

### Exercise 23: Common Factors
```python
factors_24 = {x for x in range(1, 25) if 24 % x == 0}
factors_36 = {x for x in range(1, 37) if 36 % x == 0}
common = factors_24 & factors_36  # Set intersection
print(common)
# {1, 2, 3, 4, 6, 12}

# Using comprehension
common = {x for x in range(1, 25) if 24 % x == 0 and 36 % x == 0}
print(common)
```

## Part 4: Generator Expressions

### Exercise 24: Sum of Squares
```python
total = sum(x**2 for x in range(1, 1001))
print(total)
# 333833500
```

### Exercise 25: Memory Efficiency
```python
evens_gen = (x for x in range(2, 2000001, 2))
total = sum(evens_gen)
print(total)
# 1000001000000
```

### Exercise 26: File Processing Simulation
```python
words = ['python', 'is', 'awesome', 'and', 'powerful']
lengths_gen = (len(word) for word in words)
max_length = max(lengths_gen)
print(max_length)
# 8
```

### Exercise 27: Filtering with Generator
```python
has_both = any(x % 7 == 0 and x % 11 == 0 for x in range(1, 101))
print(has_both)
# True (77 is divisible by both)

# Find the actual number
number = next((x for x in range(1, 101) if x % 7 == 0 and x % 11 == 0), None)
print(number)  # 77
```

### Exercise 28: Large Dataset
```python
total = sum(x for x in range(10000) if x % 17 == 0)
print(total)
# 2909706
```

## Part 5: Mixed Comprehensions

### Exercise 29: Grade Analysis
```python
students = ['Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank']
scores = [92, 85, 67, 78, 95, 71]

# 1. Students who passed
passed = [student for student, score in zip(students, scores) if score >= 70]
print("Passed:", passed)
# ['Alice', 'Bob', 'Diana', 'Eve', 'Frank']

# 2. Letter grades
def get_grade(score):
    if score >= 90: return 'A'
    elif score >= 80: return 'B'
    elif score >= 70: return 'C'
    else: return 'F'

grades = {student: get_grade(score) for student, score in zip(students, scores)}
print("Grades:", grades)
# {'Alice': 'A', 'Bob': 'B', 'Charlie': 'F', 'Diana': 'C', 'Eve': 'A', 'Frank': 'C'}

# 3. Unique grades
unique_grades = {get_grade(score) for score in scores}
print("Unique grades:", unique_grades)
# {'A', 'B', 'C', 'F'}
```

### Exercise 30: Data Transformation
```python
employees = ['Alice', 'Bob', 'Charlie', 'Diana']
salaries = [45000, 52000, 38000, 61000]

# 1. After raise (10%)
after_raise = [(name, salary * 1.1) for name, salary in zip(employees, salaries)]
print("After raise:", after_raise)
# [('Alice', 49500.0), ('Bob', 57200.0), ('Charlie', 41800.0), ('Diana', 67100.0)]

# 2. High earners
high_earners = {name: salary * 1.1 for name, salary in zip(employees, salaries) if salary * 1.1 > 50000}
print("High earners:", high_earners)
# {'Bob': 57200.0, 'Diana': 67100.0}

# 3. Salary brackets
def get_bracket(salary):
    bracket = (salary // 10000) * 10
    return f"{bracket}k-{bracket+10}k"

brackets = {get_bracket(salary * 1.1) for salary in salaries}
print("Brackets:", brackets)
# {'40k-50k', '50k-60k', '60k-70k'}
```

### Exercise 31: Text Analysis
```python
text = "The quick brown fox jumps over the lazy dog in the garden"

# 1. Words longer than 4 letters
long_words = [word.lower() for word in text.split() if len(word) > 4]
print("Long words:", long_words)
# ['quick', 'brown', 'jumps', 'garden']

# 2. Dictionary for 't' words
t_words = {word.lower(): len(word) for word in text.split() if word.lower().startswith('t')}
print("T-words:", t_words)
# {'the': 3}

# 3. Unique lengths
unique_lengths = {len(word) for word in text.split()}
print("Unique lengths:", unique_lengths)
# {2, 3, 4, 5, 6}

# 4. Generator for 'e' words
e_words_gen = (word for word in text.split() if 'e' in word.lower())
print("E-words:", list(e_words_gen))
# ['The', 'over', 'the', 'garden']
```

### Exercise 32: Number Analysis
```python
# 1. Perfect squares
squares = [x for x in range(1, 101) if int(x**0.5)**2 == x]
print("Perfect squares:", squares)
# [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]

# 2. Numbers divisible by 6 with divisors
def get_divisors(n):
    return [x for x in range(1, n+1) if n % x == 0]

div_by_6 = {x: get_divisors(x) for x in range(1, 101) if x % 6 == 0}
print("Divisible by 6:", div_by_6)

# 3. Prime numbers
primes = {x for x in range(2, 101) if len([d for d in range(1, x+1) if x % d == 0]) == 2}
print("Primes:", primes)

# 4. Sum of primes
sum_primes = sum(x for x in range(2, 101) if len([d for d in range(1, x+1) if x % d == 0]) == 2)
print("Sum of primes:", sum_primes)
# 1060
```

## Challenge Exercises

### Challenge 33: Cartesian Product
```python
coordinates = [(x, y) for x in range(3) for y in range(3) if (x, y) != (1, 1)]
print(coordinates)
# [(0, 0), (0, 1), (0, 2), (1, 0), (1, 2), (2, 0), (2, 1), (2, 2)]
```

### Challenge 34: Matrix Transpose
```python
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
transposed = [[row[i] for row in matrix] for i in range(len(matrix[0]))]
print(transposed)
# [[1, 4, 7], [2, 5, 8], [3, 6, 9]]

# Using zip
transposed = [list(row) for row in zip(*matrix)]
print(transposed)
```

### Challenge 35: Fibonacci Generator
```python
def fibonacci_gen(n):
    a, b = 0, 1
    count = 0
    while count < n:
        yield a
        a, b = b, a + b
        count += 1

print(list(fibonacci_gen(10)))
# [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
```

### Challenge 36: Dictionary Merge
```python
dict1 = {'a': 1, 'b': 2, 'c': 3}
dict2 = {'b': 3, 'c': 4, 'd': 5}

# Get all keys
all_keys = set(dict1.keys()) | set(dict2.keys())
merged = {k: dict1.get(k, 0) + dict2.get(k, 0) for k in all_keys}
print(merged)
# {'a': 1, 'b': 5, 'c': 7, 'd': 5}
```

### Challenge 37: Nested Filter
```python
nested = [[1, 2, 3], [4, 5, 6], [7, 8, 9], [10]]
evens = [num for sublist in nested for num in sublist if num % 2 == 0]
print(evens)
# [2, 4, 6, 8, 10]
```

### Challenge 38: Word Frequency (Top 5)
```python
sentence = "the quick brown fox jumps over the lazy dog the fox was quick"
words = sentence.lower().split()

# Count frequencies
freq = {word: words.count(word) for word in set(words)}

# Get top 5
top_5 = dict(sorted(freq.items(), key=lambda x: x[1], reverse=True)[:5])
print(top_5)
# {'the': 3, 'fox': 2, 'quick': 2, 'brown': 1, 'jumps': 1}
```

### Challenge 39: Spiral Matrix
```python
# This is complex for comprehensions - better with regular code
# But here's a creative approach using a predefined order
order = [0, 1, 2, 5, 8, 7, 6, 3, 4]
matrix = [[order.index(i*3+j)+1 for j in range(3)] for i in range(3)]
print(matrix)
# [[1, 2, 3], [8, 9, 4], [7, 6, 5]]
```

### Challenge 40: Complex Filter
```python
people = [
    {'name': 'Alice', 'age': 28, 'city': 'NYC'},
    {'name': 'Bob', 'age': 32, 'city': 'LA'},
    {'name': 'Charlie', 'age': 25, 'city': 'Chicago'},
    {'name': 'Amanda', 'age': 30, 'city': 'Boston'},
    {'name': 'David', 'age': 28, 'city': 'Seattle'}
]

# 1. Names over 25
over_25 = [p['name'] for p in people if p['age'] > 25]
print("Over 25:", over_25)
# ['Alice', 'Bob', 'Amanda', 'David']

# 2. A-names with ages
a_names = {p['name']: p['age'] for p in people if p['name'].startswith('A')}
print("A-names:", a_names)
# {'Alice': 28, 'Amanda': 30}

# 3. Unique ages
unique_ages = {p['age'] for p in people}
print("Unique ages:", unique_ages)
# {25, 28, 30, 32}

# 4. Average age
avg_age = sum(p['age'] for p in people) / len(people)
print("Average age:", avg_age)
# 28.6
```

## Bonus: Performance Challenge

### Challenge 41: Benchmark
```python
import timeit

# Regular loop
def with_loop():
    result = []
    for x in range(10000):
        result.append(x**2)
    return sum(result)

# List comprehension
def with_list_comp():
    return sum([x**2 for x in range(10000)])

# Generator expression
def with_generator():
    return sum(x**2 for x in range(10000))

loop_time = timeit.timeit(with_loop, number=1000)
list_time = timeit.timeit(with_list_comp, number=1000)
gen_time = timeit.timeit(with_generator, number=1000)

print(f"Loop: {loop_time:.4f}s")
print(f"List comprehension: {list_time:.4f}s")
print(f"Generator: {gen_time:.4f}s")
```

### Challenge 42: Memory Challenge
```python
import sys

def list_version():
    return [x**2 for x in range(1000000)]

def generator_version():
    return (x**2 for x in range(1000000))

list_result = list_version()
gen_result = generator_version()

print(f"List size: {sys.getsizeof(list_result):,} bytes")
print(f"Generator size: {sys.getsizeof(gen_result):,} bytes")

# List: ~8,000,000+ bytes
# Generator: ~200 bytes

# Use list when: need multiple iterations, indexing, or small dataset
# Use generator when: single iteration, large dataset, or memory constrained
```
