# Python Comprehensions Tutorial

## Introduction
Comprehensions are a concise and elegant way to create collections in Python. They provide a more readable alternative to traditional loops for creating lists, dictionaries, sets, and generators.

## Why Use Comprehensions?

### Traditional Loop:
```python
squares = []
for x in range(10):
    squares.append(x**2)
```

### With Comprehension:
```python
squares = [x**2 for x in range(10)]
```

**Benefits:**
- More concise and readable
- Often faster than loops
- More Pythonic (idiomatic)
- Single expression = clearer intent

## 1. List Comprehensions

### Basic Syntax
```python
[expression for item in iterable]
```

### Examples

#### Simple Transformation
```python
# Square each number
numbers = [1, 2, 3, 4, 5]
squares = [x**2 for x in numbers]
print(squares)  # [1, 4, 9, 16, 25]

# Convert to uppercase
words = ['hello', 'world', 'python']
upper_words = [word.upper() for word in words]
print(upper_words)  # ['HELLO', 'WORLD', 'PYTHON']
```

#### With Conditional (Filtering)
```python
# Filter even numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
evens = [x for x in numbers if x % 2 == 0]
print(evens)  # [2, 4, 6, 8, 10]

# Filter strings by length
words = ['cat', 'elephant', 'dog', 'butterfly']
long_words = [word for word in words if len(word) > 5]
print(long_words)  # ['elephant', 'butterfly']
```

#### With If-Else (Transformation)
```python
# Replace negative numbers with 0
numbers = [-2, 3, -5, 8, -1, 6]
positive = [x if x > 0 else 0 for x in numbers]
print(positive)  # [0, 3, 0, 8, 0, 6]

# Categorize numbers
numbers = [1, 2, 3, 4, 5, 6]
categories = ['even' if x % 2 == 0 else 'odd' for x in numbers]
print(categories)  # ['odd', 'even', 'odd', 'even', 'odd', 'even']
```

#### Nested List Comprehensions
```python
# Flatten a 2D list
matrix = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
flat = [num for row in matrix for num in row]
print(flat)  # [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Create multiplication table
table = [[i * j for j in range(1, 6)] for i in range(1, 6)]
for row in table:
    print(row)
```

#### Multiple Iterables
```python
# Cartesian product
colors = ['red', 'blue']
sizes = ['S', 'M', 'L']
combinations = [(color, size) for color in colors for size in sizes]
print(combinations)
# [('red', 'S'), ('red', 'M'), ('red', 'L'), ('blue', 'S'), ('blue', 'M'), ('blue', 'L')]

# Combine lists element-wise
list1 = [1, 2, 3]
list2 = [10, 20, 30]
sums = [a + b for a, b in zip(list1, list2)]
print(sums)  # [11, 22, 33]
```

## 2. Dictionary Comprehensions

### Basic Syntax
```python
{key_expression: value_expression for item in iterable}
```

### Examples

#### Create Dictionary from Lists
```python
# From two lists
keys = ['name', 'age', 'city']
values = ['Alice', 25, 'NYC']
person = {k: v for k, v in zip(keys, values)}
print(person)  # {'name': 'Alice', 'age': 25, 'city': 'NYC'}
```

#### Transform Values
```python
# Square values
numbers = {'a': 1, 'b': 2, 'c': 3}
squared = {k: v**2 for k, v in numbers.items()}
print(squared)  # {'a': 1, 'b': 4, 'c': 9}

# Calculate word lengths
words = ['cat', 'dog', 'elephant']
lengths = {word: len(word) for word in words}
print(lengths)  # {'cat': 3, 'dog': 3, 'elephant': 8}
```

#### With Conditional (Filtering)
```python
# Filter by value
scores = {'Alice': 85, 'Bob': 92, 'Charlie': 78, 'Diana': 95}
high_scores = {k: v for k, v in scores.items() if v >= 90}
print(high_scores)  # {'Bob': 92, 'Diana': 95}

# Filter by key
data = {'name': 'Alice', 'age': 25, 'temp': 98.6, 'score': 85}
numeric = {k: v for k, v in data.items() if isinstance(v, (int, float))}
print(numeric)  # {'age': 25, 'temp': 98.6, 'score': 85}
```

#### Swap Keys and Values
```python
original = {'a': 1, 'b': 2, 'c': 3}
swapped = {v: k for k, v in original.items()}
print(swapped)  # {1: 'a', 2: 'b', 3: 'c'}
```

#### Nested Dictionary Comprehension
```python
# Create nested dictionary
students = ['Alice', 'Bob', 'Charlie']
subjects = ['Math', 'Science']
grades = {student: {subject: 0 for subject in subjects} for student in students}
print(grades)
# {'Alice': {'Math': 0, 'Science': 0}, 'Bob': {'Math': 0, 'Science': 0}, ...}
```

## 3. Set Comprehensions

### Basic Syntax
```python
{expression for item in iterable}
```

### Examples

#### Remove Duplicates with Transformation
```python
# Unique squares
numbers = [1, 2, 2, 3, 3, 4, 5]
unique_squares = {x**2 for x in numbers}
print(unique_squares)  # {1, 4, 9, 16, 25}

# Unique lengths
words = ['cat', 'dog', 'bird', 'elephant', 'cat']
lengths = {len(word) for word in words}
print(lengths)  # {3, 4, 8}
```

#### With Conditional
```python
# Unique even numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 2, 4, 6]
unique_evens = {x for x in numbers if x % 2 == 0}
print(unique_evens)  # {2, 4, 6, 8}
```

#### From String
```python
# Unique vowels in text
text = "hello world"
vowels = {char for char in text if char in 'aeiou'}
print(vowels)  # {'e', 'o'}
```

## 4. Generator Expressions

### Basic Syntax
```python
(expression for item in iterable)
```

### Key Differences from List Comprehensions
- Uses parentheses `()` instead of brackets `[]`
- Returns a generator object (iterator)
- **Lazy evaluation** - computes values on demand
- **Memory efficient** - doesn't store all values

### Examples

#### Basic Generator
```python
# Generator expression
gen = (x**2 for x in range(10))
print(gen)  # <generator object>
print(type(gen))  # <class 'generator'>

# Iterate through generator
for value in gen:
    print(value)  # Prints 0, 1, 4, 9, 16, 25, 36, 49, 64, 81

# Convert to list if needed
squares = list((x**2 for x in range(10)))
```

#### Memory Efficiency Comparison
```python
import sys

# List comprehension - stores all values
list_comp = [x**2 for x in range(1000000)]
print(f"List size: {sys.getsizeof(list_comp)} bytes")

# Generator expression - stores formula only
gen_exp = (x**2 for x in range(1000000))
print(f"Generator size: {sys.getsizeof(gen_exp)} bytes")
# Generator is much smaller!
```

#### Using with Functions
```python
# sum() accepts iterables
total = sum(x**2 for x in range(100))
print(total)

# max/min
largest = max(x for x in range(100) if x % 7 == 0)
print(largest)

# any/all
has_negative = any(x < 0 for x in [1, 2, -3, 4])
print(has_negative)  # True
```

#### When to Use Generators
```python
# ✅ Good - only need to iterate once
total = sum(x**2 for x in range(1000000))

# ❌ Not ideal - need to iterate multiple times
gen = (x**2 for x in range(10))
first_pass = list(gen)
second_pass = list(gen)  # Empty! Generator is exhausted
print(second_pass)  # []

# ✓ Better - use list comprehension if iterating multiple times
squares = [x**2 for x in range(10)]
first_pass = squares
second_pass = squares  # Still has values
```

## Performance Comparison

```python
import timeit

# Using loop
def with_loop():
    result = []
    for x in range(1000):
        result.append(x**2)
    return result

# Using list comprehension
def with_comprehension():
    return [x**2 for x in range(1000)]

# Compare timing
loop_time = timeit.timeit(with_loop, number=10000)
comp_time = timeit.timeit(with_comprehension, number=10000)

print(f"Loop: {loop_time:.4f} seconds")
print(f"Comprehension: {comp_time:.4f} seconds")
# Comprehension is typically 20-30% faster!
```

## When to Use Each Type

### List Comprehensions
- Need a list of transformed/filtered values
- Will access elements multiple times
- Need indexing or slicing

### Dictionary Comprehensions
- Creating key-value mappings
- Transforming existing dictionaries
- Grouping data

### Set Comprehensions
- Need unique values
- Testing membership efficiently
- Mathematical set operations

### Generator Expressions
- Processing large datasets
- Only need to iterate once
- Want to save memory
- Using with sum(), max(), min(), any(), all()

## Best Practices

### ✅ DO:
```python
# Keep it simple and readable
squares = [x**2 for x in range(10)]

# Use meaningful variable names
upper_names = [name.upper() for name in names]

# Use for simple transformations
prices_with_tax = [price * 1.08 for price in prices]
```

### ❌ DON'T:
```python
# Don't make it too complex
# Bad - hard to read
result = [x**2 if x % 2 == 0 else x**3 if x % 3 == 0 else x for x in range(20) if x > 5]

# Better - use regular loop
result = []
for x in range(20):
    if x > 5:
        if x % 2 == 0:
            result.append(x**2)
        elif x % 3 == 0:
            result.append(x**3)
        else:
            result.append(x)

# Don't use for side effects
# Bad - comprehension should create values, not perform actions
[print(x) for x in range(10)]  # Use regular loop instead!

# Don't nest too deeply
# Bad - more than 2 levels gets hard to read
result = [[[z for z in range(y)] for y in range(x)] for x in range(5)]
```

## Common Patterns

### Filter and Transform
```python
# Get lengths of long words
words = ['cat', 'elephant', 'dog', 'butterfly', 'bird']
long_lengths = [len(word) for word in words if len(word) > 5]
```

### Flatten Nested Structure
```python
# Flatten list of lists
nested = [[1, 2], [3, 4], [5, 6]]
flat = [item for sublist in nested for item in sublist]
```

### Create Lookup Dictionary
```python
# Create index: value mapping
items = ['apple', 'banana', 'cherry']
lookup = {i: item for i, item in enumerate(items)}
```

### Combine Multiple Conditions
```python
# Filter with multiple criteria
numbers = range(100)
result = [x for x in numbers if x % 2 == 0 if x % 3 == 0]
# Same as: if x % 2 == 0 and x % 3 == 0
```

## Practice Tips

1. Start simple - master basic syntax first
2. Compare with equivalent loop code
3. Read comprehensions aloud to understand flow
4. Use them when they make code clearer
5. Fall back to loops when comprehensions get complex
6. Remember: readable code > clever code

## Summary

| Type | Syntax | Creates | Use When |
|------|--------|---------|----------|
| List | `[expr for x in iter]` | List | Need mutable sequence |
| Dict | `{k: v for x in iter}` | Dictionary | Need key-value pairs |
| Set | `{expr for x in iter}` | Set | Need unique values |
| Generator | `(expr for x in iter)` | Generator | Large data, iterate once |

Comprehensions are powerful tools that make Python code more elegant and efficient. Master them, but remember: clarity always beats cleverness!
