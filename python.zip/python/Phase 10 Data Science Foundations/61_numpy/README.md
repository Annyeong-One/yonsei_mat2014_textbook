# NumPy Tutorial Package - Enhanced Edition
## Topic #37: NumPy Arrays and Numerical Computing

---

## 🔗 CRITICAL CONNECTIONS TO PREVIOUS TOPICS

This module **builds directly** on concepts from earlier in the course:

### **FROM TOPIC #24: Memory Deep Dive** 🧠
- **Contiguous memory allocation** - Arrays store data in a single block
- **Memory efficiency** - No per-element overhead like Python lists
- **Views vs copies** - Understanding shallow vs deep copying
- **Direct memory access** - Cache-friendly data access patterns

### **FROM TOPIC #25: List Internals** 📊
- **Over-allocation problem** - Lists pre-allocate extra space (wasted memory!)
- **Pointer arrays** - Lists store pointers to PyObjects (expensive!)
- **Dynamic resizing** - Lists grow/shrink dynamically (NumPy arrays are fixed size)
- **Homogeneous vs heterogeneous** - Arrays require same type (lists allow mixed types)

### **PREPARES FOR TOPICS #26-36: Object-Oriented Programming** 🎯
- **ndarray is a CLASS** - Arrays are objects with methods and attributes
- **Method chaining** - `arr.reshape().T.mean()` works because of OOP
- **Operator overloading** - Why `arr1 + arr2` works element-wise
- **Encapsulation** - Internal memory layout is hidden from users

---

## 📚 Why NumPy? The Performance Revolution

### **The Problem with Python Lists** (Review Topic #25!)

```python
# Python list internals (from Topic #25):
# 1. List is an array of POINTERS to PyObjects
# 2. Each element has overhead: type info, reference count, value
# 3. Elements can be scattered across memory
# 4. Over-allocation: List with 10 elements might allocate space for 20!

# Example: Memory for a list of 3 integers
my_list = [1, 2, 3]
# Memory layout (simplified):
# [ptr1] -> PyObject(type=int, refcount=1, value=1)  # 28+ bytes
# [ptr2] -> PyObject(type=int, refcount=1, value=2)  # 28+ bytes  
# [ptr3] -> PyObject(type=int, refcount=1, value=3)  # 28+ bytes
# Total: ~100+ bytes for just 3 integers!
```

### **The NumPy Solution** (Topic #24 Memory Efficiency!)

```python
# NumPy array memory layout:
# Contiguous block of raw data (no Python overhead!)
import numpy as np
arr = np.array([1, 2, 3], dtype=np.int32)
# Memory layout:
# [00000001][00000002][00000003]  # Just 12 bytes!
# That's 8x more efficient than Python lists!
```

### **Performance Comparison**

| Operation | Python List | NumPy Array | Speedup |
|-----------|-------------|-------------|---------|
| Memory per int | ~28 bytes | 4-8 bytes | 3-7x |
| Addition (1M elements) | ~100ms | ~1ms | 100x |
| Multiplication | ~150ms | ~1ms | 150x |
| Mathematical ops | Must loop | Vectorized | 50-200x |

---

## 📂 Package Structure

```
37_numpy_enhanced/
├── 01_beginner/                    # Beginner Level (4-5 hours)
│   ├── 01_arrays_vs_lists.py      # 🔗 Connects to Topic #24, #25
│   ├── 02_array_creation.py        # Creating arrays various ways
│   ├── 03_array_indexing.py        # Accessing array elements
│   └── 04_basic_operations.py      # Arithmetic, vectorization
│
├── 02_intermediate/                # Intermediate Level (4-5 hours)
│   ├── 01_broadcasting.py          # 🔥 Broadcasting rules
│   ├── 02_shape_manipulation.py    # Reshape, transpose, stack
│   ├── 03_mathematical_ops.py      # Linear algebra, statistics
│   └── 04_memory_views.py          # 🔗 Topic #24: Views vs copies
│
├── 03_advanced/                    # Advanced Level (3-4 hours)
│   ├── 01_advanced_indexing.py     # Boolean, fancy indexing
│   ├── 02_performance.py           # Vectorization techniques
│   └── 03_dtype_memory.py          # 🔗 Topic #24: Memory optimization
│
├── exercises/                      # Practice Problems
│   ├── exercises_beginner.py       # 15 problems
│   ├── exercises_intermediate.py   # 15 problems
│   ├── exercises_advanced.py       # 15 problems
│   ├── solutions_beginner.py       # Full solutions
│   ├── solutions_intermediate.py   # Full solutions
│   └── solutions_advanced.py       # Full solutions
│
└── README.md                       # This file
```

---

## 🎯 Learning Objectives

By completing this module, students will:

### **Memory & Performance Understanding** (Connects to #24, #25)
✅ Explain why NumPy arrays are more memory-efficient than Python lists
✅ Calculate memory usage for arrays vs lists
✅ Understand contiguous memory allocation and cache efficiency
✅ Recognize when to use views vs copies

### **Array Fundamentals**
✅ Create NumPy arrays using various methods
✅ Understand array properties: shape, dtype, ndim, size
✅ Access and modify array elements efficiently
✅ Perform vectorized operations without loops

### **Broadcasting & Vectorization** 
✅ Master NumPy's broadcasting rules
✅ Write efficient array operations (no loops!)
✅ Understand implicit array expansion
✅ Apply broadcasting to solve real problems

### **OOP Connections** (Prepares for #26-36)
✅ Recognize that ndarray is a class with methods
✅ Use array methods like `.reshape()`, `.mean()`, `.sum()`
✅ Understand operator overloading (`+`, `*`, etc.)
✅ Work with array attributes (`.shape`, `.dtype`, `.T`)

---

## 📖 Detailed Course Outline

### **Beginner Level** (4-5 hours total)

#### **01_arrays_vs_lists.py** ⭐ CRITICAL FOUNDATION
**Duration**: 60-75 minutes
**Prerequisites**: Topic #24 (Memory), Topic #25 (Lists)

**Topics Covered:**
- Why Python lists are slow (review #25 internals)
- Memory overhead comparison (connects to #24)
- Speed benchmarks: lists vs arrays
- When to use lists vs arrays
- Homogeneous vs heterogeneous data

**Code Demonstrations:**
```python
# Memory comparison (actual measurements!)
import sys
python_list = list(range(10000))
numpy_array = np.arange(10000)
print(f"List size: {sys.getsizeof(python_list):,} bytes")
print(f"Array size: {numpy_array.nbytes:,} bytes")
# Array is ~50x smaller!

# Speed comparison (timed benchmarks!)
%timeit [x * 2 for x in python_list]  # ~1ms
%timeit numpy_array * 2                 # ~0.01ms (100x faster!)
```

**Learning Outcomes:**
- Understand the fundamental trade-off: flexibility vs performance
- Connect abstract memory concepts (#24, #25) to concrete examples
- Make informed decisions about data structure choice

---

#### **02_array_creation.py**
**Duration**: 60 minutes
**Prerequisites**: Topic #10 (Lists), Topic #24 (Memory)

**Topics Covered:**
- Creating arrays from lists, tuples, ranges
- Array creation functions: `np.zeros()`, `np.ones()`, `np.arange()`, `np.linspace()`
- Random array generation
- Array from existing data
- The `dtype` parameter (memory control!)

**Code Demonstrations:**
```python
# Different dtypes = different memory usage!
arr_int8 = np.array([1,2,3], dtype=np.int8)    # 3 bytes
arr_int32 = np.array([1,2,3], dtype=np.int32)  # 12 bytes  
arr_float64 = np.array([1,2,3], dtype=np.float64)  # 24 bytes
# Choose dtype based on your data range and precision needs!
```

**Learning Outcomes:**
- Create arrays efficiently for various use cases
- Control memory usage through dtype selection
- Understand when to use which creation method

---

#### **03_array_indexing.py**
**Duration**: 60 minutes  
**Prerequisites**: Topic #10 (Lists - indexing basics)

**Topics Covered:**
- 1D indexing (like lists)
- Multi-dimensional indexing
- Slicing returns VIEWS not copies! (Topic #24!)
- Negative indices
- Stride patterns

**Code Demonstrations:**
```python
# CRITICAL INSIGHT: Slices are VIEWS (Topic #24)
arr = np.array([1, 2, 3, 4, 5])
view = arr[1:4]  # This is a VIEW, not a copy!
view[0] = 999    # Changes BOTH arr and view!
print(arr)       # [1, 999, 3, 4, 5] - Original changed!

# Want a copy? Use .copy()
copy = arr[1:4].copy()  # Now independent
copy[0] = 888
print(arr)  # Unchanged!
```

**Learning Outcomes:**
- Master NumPy's indexing syntax
- Understand views vs copies (crucial for Topic #24!)
- Avoid common "unexpected behavior" bugs

---

#### **04_basic_operations.py**
**Duration**: 60-75 minutes
**Prerequisites**: Basic Python math

**Topics Covered:**
- Element-wise arithmetic (vectorization!)
- No loops needed - "vectorized" operations
- Universal functions (ufuncs)
- Comparison operations
- Broadcasting basics (preview)

**Code Demonstrations:**
```python
# Vectorization = Hidden C-speed loops
# Python list way (SLOW):
result = [x * 2 for x in my_list]  # Python loop

# NumPy way (FAST):
result = arr * 2  # Single C-level operation!

# Works with arrays of same shape:
arr1 = np.array([1, 2, 3])
arr2 = np.array([10, 20, 30])
result = arr1 + arr2  # [11, 22, 33] - Element-wise!
```

**Learning Outcomes:**
- Write "vectorized" code (eliminate Python loops)
- Understand performance benefits
- Use ufuncs for mathematical operations

---

### **Intermediate Level** (4-5 hours total)

#### **01_broadcasting.py** 🔥 MOST POWERFUL FEATURE
**Duration**: 90 minutes
**Prerequisites**: Beginner tutorials

**Topics Covered:**
- What is broadcasting?
- Broadcasting rules (step-by-step)
- Common broadcasting patterns
- Practical examples
- Avoiding broadcasting errors

**The Three Broadcasting Rules:**
```python
# Rule 1: If arrays differ in ndim, pad smaller shape with 1s on left
arr1.shape = (3, 4, 5)
arr2.shape = (5,)      # Becomes (1, 1, 5)

# Rule 2: If shapes disagree, array with shape 1 is stretched
arr1.shape = (3, 1, 5)
arr2.shape = (1, 4, 5)  # Both become (3, 4, 5)

# Rule 3: If dimensions are not equal and neither is 1, ERROR!
arr1.shape = (3, 4)
arr2.shape = (3, 5)  # ❌ Can't broadcast!
```

**Practical Examples:**
```python
# Normalize each column independently
matrix = np.random.rand(100, 10)  # (100, 10)
means = matrix.mean(axis=0)        # (10,)
normalized = matrix - means         # Broadcasting! (100,10) - (10,)

# Create multiplication table
x = np.arange(1, 11).reshape(10, 1)  # (10, 1)
y = np.arange(1, 11).reshape(1, 10)  # (1, 10)
table = x * y  # (10, 10) - Full multiplication table!
```

**Learning Outcomes:**
- Master NumPy's most powerful feature
- Write elegant code without explicit loops
- Debug broadcasting errors

---

#### **02_shape_manipulation.py**
**Duration**: 75 minutes
**Prerequisites**: Understanding array shapes

**Topics Covered:**
- Reshaping arrays
- Transpose operations
- Stacking arrays (vertical, horizontal)
- Splitting arrays
- Flattening arrays
- Shape compatibility

**Code Demonstrations:**
```python
# Reshape doesn't copy data! (Topic #24)
arr = np.arange(12)          # Shape: (12,)
matrix = arr.reshape(3, 4)   # Shape: (3, 4) - SAME data!
matrix[0, 0] = 999
print(arr[0])  # 999 - They share memory!

# Transpose creates a VIEW too!
transposed = matrix.T  # Shape: (4, 3)
# Still pointing to same data, just different interpretation
```

**Learning Outcomes:**
- Manipulate array shapes efficiently
- Understand memory implications
- Combine arrays effectively

---

#### **03_mathematical_ops.py**
**Duration**: 75 minutes
**Prerequisites**: Basic linear algebra (matrices)

**Topics Covered:**
- Statistical operations (mean, std, var)
- Linear algebra (dot product, matrix multiplication)
- Aggregations along axes
- Mathematical functions (sin, cos, exp, log)

**Code Demonstrations:**
```python
# Axis parameter is crucial!
matrix = np.random.rand(5, 3)
row_means = matrix.mean(axis=1)     # Mean of each row: shape (5,)
col_means = matrix.mean(axis=0)     # Mean of each col: shape (3,)
total_mean = matrix.mean()          # Overall mean: scalar

# Matrix multiplication (dot product)
A = np.random.rand(3, 4)
B = np.random.rand(4, 5)
C = A @ B  # Modern syntax, equivalent to np.dot(A, B)
# Result shape: (3, 5)
```

**Learning Outcomes:**
- Perform mathematical operations efficiently
- Understand axis parameter
- Work with linear algebra operations

---

#### **04_memory_views.py** 🔗 DEEP DIVE INTO TOPIC #24
**Duration**: 60 minutes
**Prerequisites**: Topic #24 (CRITICAL!)

**Topics Covered:**
- Understanding memory layout
- Views vs copies (comprehensive)
- When NumPy makes copies
- Memory-efficient operations
- The `.base` attribute
- Forcing copies with `.copy()`

**Code Demonstrations:**
```python
# Check if it's a view or copy
arr = np.array([1, 2, 3, 4, 5])
view = arr[::2]  # Every 2nd element
print(view.base is arr)  # True - It's a view!

# Operations that return VIEWS:
arr[1:4]       # Slicing
arr.reshape()  # Reshaping
arr.T          # Transpose
arr.ravel()    # Flatten (usually)

# Operations that return COPIES:
arr[[1,2,4]]   # Fancy indexing
arr[arr > 2]   # Boolean indexing
arr.flatten()  # Flatten (always)

# Memory implications:
original = np.arange(1000000)  # 8 MB
view = original[::2]           # 0 bytes extra!
copy = original[::2].copy()    # Another 4 MB!
```

**Learning Outcomes:**
- Master views vs copies (crucial for performance!)
- Write memory-efficient code
- Avoid unexpected bugs from shared memory
- Connect to Topic #24 memory concepts

---

### **Advanced Level** (3-4 hours total)

#### **01_advanced_indexing.py**
**Duration**: 75 minutes
**Prerequisites**: Intermediate tutorials

**Topics Covered:**
- Boolean indexing (fancy filtering)
- Fancy indexing with arrays
- Combining indexing methods
- Index arrays
- Performance considerations

**Code Demonstrations:**
```python
# Boolean indexing (creates COPY!)
arr = np.array([1, 2, 3, 4, 5])
mask = arr > 2              # Boolean array
result = arr[mask]          # [3, 4, 5] - This is a COPY!

# Fancy indexing (also COPY!)
indices = np.array([0, 2, 4])
result = arr[indices]       # [1, 3, 5] - COPY!

# Why copies? Can't guarantee contiguous memory!
arr = np.arange(10)
arr[[1, 3, 7]] = 999  # Works! Sets multiple elements
```

**Learning Outcomes:**
- Use advanced indexing for complex selections
- Understand when copies are made
- Write efficient filtering operations

---

#### **02_performance.py** ⚡ SPEED OPTIMIZATION
**Duration**: 75 minutes
**Prerequisites**: All previous tutorials

**Topics Covered:**
- Vectorization techniques
- Eliminating Python loops
- Broadcasting for performance
- Memory layout and cache efficiency
- Profiling NumPy code

**Code Demonstrations:**
```python
# SLOW: Python loop
def slow_sum(arr):
    total = 0
    for i in range(len(arr)):
        total += arr[i]
    return total

# FAST: Vectorized
def fast_sum(arr):
    return np.sum(arr)

# Speed difference:
arr = np.random.rand(1000000)
%timeit slow_sum(arr)   # ~150ms
%timeit fast_sum(arr)   # ~0.5ms (300x faster!)

# Why? Vectorization uses:
# - Contiguous memory (Topic #24!)
# - Cache-friendly access
# - CPU vector instructions (SIMD)
# - No Python interpreter overhead
```

**Learning Outcomes:**
- Write high-performance NumPy code
- Understand vectorization deeply
- Profile and optimize bottlenecks

---

#### **03_dtype_memory.py** 🔗 ADVANCED TOPIC #24
**Duration**: 60 minutes
**Prerequisites**: Topic #24, Basic tutorials

**Topics Covered:**
- Data types and memory usage
- Choosing appropriate dtypes
- Structured arrays
- Memory layout (C vs Fortran order)
- Memory profiling

**Code Demonstrations:**
```python
# dtype affects memory dramatically!
# Example: 1 million integers

# Option 1: Default int64
arr_int64 = np.arange(1000000)
print(f"int64: {arr_int64.nbytes:,} bytes")  # 8,000,000 bytes (8 MB)

# Option 2: Smaller int32 (if values fit)
arr_int32 = np.arange(1000000, dtype=np.int32)
print(f"int32: {arr_int32.nbytes:,} bytes")  # 4,000,000 bytes (4 MB)

# Option 3: Even smaller int16 (if values < 32767)
arr_int16 = np.arange(1000, dtype=np.int16)
print(f"int16: {arr_int16.nbytes:,} bytes")  # 2,000 bytes (2 KB)

# Memory savings: 75% reduction from int64 to int16!

# Array order matters for cache!
C_order = np.array([[1,2,3], [4,5,6]], order='C')  # Row-major (default)
F_order = np.array([[1,2,3], [4,5,6]], order='F')  # Column-major

# Accessing rows is faster in C-order
# Accessing columns is faster in F-order
```

**Learning Outcomes:**
- Optimize memory usage through dtype selection
- Understand memory layout implications
- Write memory-efficient numerical code

---

## 🔧 Installation

```bash
# Install NumPy
pip install numpy

# Verify installation
python -c "import numpy as np; print(np.__version__)"

# Optional: Install for performance profiling
pip install memory_profiler line_profiler
```

---

## 🚀 Getting Started

### **Recommended Learning Path**

**Week 1-2: Foundation** (Connect to Topics #24, #25)
1. Read about list internals (review Topic #25)
2. Review memory concepts (Topic #24)
3. Complete `01_arrays_vs_lists.py` - Understand WHY NumPy
4. Complete `02_array_creation.py`
5. Complete beginner exercises 1-5

**Week 3: Core Operations**
1. Complete `03_array_indexing.py`
2. Complete `04_basic_operations.py`
3. Complete beginner exercises 6-15

**Week 4-5: Intermediate Mastery**
1. Complete `01_broadcasting.py` (CRITICAL!)
2. Complete `02_shape_manipulation.py`
3. Complete intermediate exercises 1-10

**Week 6: Mathematical Operations**
1. Complete `03_mathematical_ops.py`
2. Complete `04_memory_views.py` (connect to Topic #24!)
3. Complete intermediate exercises 11-15

**Week 7-8: Advanced Topics**
1. Complete `01_advanced_indexing.py`
2. Complete `02_performance.py`
3. Complete `03_dtype_memory.py`
4. Complete all advanced exercises

---

## 📊 Key Concepts Summary

### **Memory Efficiency** (Topic #24, #25)
```python
# Python list: Inefficient
# [ptr] -> PyObject -> value  (28+ bytes per element)

# NumPy array: Efficient  
# [value][value][value]  (4-8 bytes per element)
```

### **Vectorization** (Core Concept)
```python
# Slow: Python loop
for i in range(len(arr)):
    result[i] = arr[i] * 2

# Fast: Vectorized
result = arr * 2  # 50-200x faster!
```

### **Broadcasting** (Most Powerful Feature)
```python
# Add a row vector to every row of a matrix
matrix = np.random.rand(100, 10)  # (100, 10)
row_vec = np.random.rand(10)      # (10,)
result = matrix + row_vec          # Broadcasting! (100, 10)
```

### **Views vs Copies** (Topic #24)
```python
# View: Shares memory (fast, careful with modifications!)
view = arr[1:5]  # 0 bytes extra

# Copy: Independent (safe, uses more memory)
copy = arr[1:5].copy()  # New memory allocated
```

---

## 🎓 Teaching Notes (For Instructors)

### **Critical Connections to Emphasize**

1. **Topic #24 Connection (Memory)**
   - Show actual memory measurements
   - Compare list vs array memory usage
   - Demonstrate views vs copies practically
   - Discuss cache efficiency

2. **Topic #25 Connection (Lists)**
   - Review list over-allocation
   - Show pointer overhead visually
   - Contrast with contiguous array memory
   - Discuss when to use each

3. **Topics #26-36 Connection (OOP - Preview)**
   - Point out that ndarray is a class
   - Show method calls (`.reshape()`, `.mean()`)
   - Demonstrate operator overloading
   - Preview attributes (`.shape`, `.dtype`)

### **Common Student Misconceptions**

1. **"NumPy is always faster"**
   - False! For small data (<1000 elements), Python lists are fine
   - Overhead of array creation can dominate for small operations
   - Best use: Large numerical datasets

2. **"Slicing creates a copy"**
   - False! Slicing creates a VIEW (unlike Python lists)
   - This is both powerful and dangerous
   - Always check with `.base` attribute

3. **"Broadcasting is automatic"**
   - True, but understanding the rules is crucial
   - Silent errors can occur
   - Learn to predict shapes

---

## 📈 Assessment Ideas

### **Quizzes**
1. Calculate memory usage for arrays vs lists
2. Predict broadcasting results
3. Identify view vs copy operations
4. Debug common NumPy errors

### **Coding Challenges**
1. Convert list-based code to NumPy (measure speedup)
2. Implement image processing without loops
3. Optimize given slow NumPy code
4. Debug memory-related bugs

### **Projects**
1. Image filter implementation (convolution)
2. Financial simulation (Monte Carlo)
3. Game of Life (cellular automaton)
4. Signal processing (FFT analysis)

---

## 📚 Additional Resources

### **Official Documentation**
- [NumPy Documentation](https://numpy.org/doc/)
- [NumPy for Beginners](https://numpy.org/doc/stable/user/absolute_beginners.html)
- [Broadcasting Tutorial](https://numpy.org/doc/stable/user/basics.broadcasting.html)

### **Performance Resources**
- [Guide to NumPy Performance](https://numpy.org/doc/stable/user/c-info.how-to-extend.html)
- [Memory Layout](https://numpy.org/doc/stable/reference/internals.html)

---

## ⚡ Performance Tips

1. **Use vectorization** - Eliminate Python loops
2. **Choose appropriate dtype** - Don't waste memory
3. **Reuse arrays** - Avoid unnecessary allocations
4. **Understand views** - Leverage shared memory
5. **Profile your code** - Measure before optimizing

---

## 🎯 By the End of This Module

Students will be able to:
- ✅ Explain why NumPy is faster than Python lists (connecting to #24, #25)
- ✅ Write efficient numerical code without loops
- ✅ Master broadcasting for elegant operations
- ✅ Optimize memory usage through dtype selection
- ✅ Debug common NumPy issues
- ✅ Prepare for Pandas (Topic #40) which builds on NumPy
- ✅ Recognize OOP patterns (preview of #26-36)

---

## 🔜 Next Steps

After mastering NumPy, you'll be ready for:

- **Topic #38**: Matplotlib (visualizing NumPy arrays)
- **Topic #39**: SciPy Stats (statistical analysis with arrays)
- **Topic #40**: Pandas (DataFrames built on NumPy!)

---

**Total Time Estimate**: 12-15 hours (tutorials + exercises)
**Difficulty Progression**: Beginner → Intermediate → Advanced
**Focus**: Memory efficiency, performance, practical applications

---

**Happy array computing! 🚀📊**
