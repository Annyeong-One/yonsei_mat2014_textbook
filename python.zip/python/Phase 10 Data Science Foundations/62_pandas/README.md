# Comprehensive Pandas Tutorial Package - ENHANCED
### Python Data Analysis and Manipulation

---

## 🔗 CRITICAL CONNECTIONS TO PREVIOUS TOPICS

This module **builds directly** on concepts from earlier in the course:

### **FROM TOPIC #24: Memory Deep Dive** 🧠
- **Memory efficiency** - Understanding DataFrame memory usage
- **dtype optimization** - Choosing appropriate data types
- **Memory profiling** - Using `.memory_usage()` and `.info()`
- **Categorical data** - Reducing memory for repeated values

### **FROM TOPICS #26-36: Object-Oriented Programming** 🎯
- **DataFrames are OBJECTS** - Instances of the DataFrame class
- **Methods and attributes** - `.head()`, `.shape`, `.columns`
- **Method chaining** - `df.sort_values().groupby().mean()`
- **Inheritance** - Series inherits from ndarray
- **Encapsulation** - Internal optimizations hidden from users

### **FROM TOPIC #27: Attributes and Methods** 📚
- **Method chaining** - Elegant, readable data transformations
- **Fluent interfaces** - Methods return DataFrames for chaining
- **Immutable operations** - Most methods return NEW DataFrames

### **FROM TOPIC #37: NumPy Arrays** 🔢
- **Built on NumPy** - DataFrames use NumPy arrays internally
- **Vectorized operations** - No loops needed
- **Broadcasting** - Operations across DataFrames
- **Performance** - Leverages NumPy's speed

---

## 📚 Course Overview

This comprehensive pandas tutorial package is designed for undergraduate computer science students learning Python data analysis over one academic year. The course progresses from fundamental concepts to advanced techniques, with heavily commented code and practical exercises.

**Total Duration**: One year (three semesters)
**Prerequisites**: 
- Basic Python programming knowledge
- Topic #24 (Memory Deep Dive) - CRITICAL
- Topics #26-36 (Object-Oriented Programming) - CRITICAL  
- Topic #37 (NumPy) - CRITICAL
**Format**: Self-paced with exercises

---

## 📂 Package Structure

```
pandas_course/
├── 01_beginner/              # Beginner Level (Semester 1)
│   ├── 01_intro_and_series.py
│   ├── 02_intro_dataframes.py
│   ├── 03_reading_writing_data.py
│   └── 04_data_cleaning.py
│
├── 02_intermediate/          # Intermediate Level (Semester 2)
│   ├── 01_groupby_aggregation.py
│   ├── 02_merge_join_concat.py
│   └── 03_pivot_reshape.py
│
├── 03_advanced/              # Advanced Level (Semester 3)
│   ├── 01_time_series.py
│   ├── 02_multiindex.py
│   └── 03_performance.py
│
├── exercises/                # Practice Exercises
│   ├── 01_series_exercises.py
│   ├── 02_dataframe_exercises.py
│   ├── 03_groupby_merge_exercises.py
│   └── 04_time_series_exercises.py
│
└── README.md                 # This file
```

---

## 🎯 Learning Path

### **Semester 1: Beginner Level** (Fundamentals)

#### Tutorial 01: Introduction to Pandas and Series
**Topics Covered:**
- What is pandas and why use it
- Creating Series from various data sources
- Series attributes (values, index, dtype)
- Indexing and selection (.loc, .iloc)
- Basic operations and arithmetic
- Common Series methods (mean, median, sum, etc.)
- Handling missing data (dropna, fillna)
- Applying functions

**Key Learning Outcomes:**
- Understand 1D labeled arrays
- Master Series creation and manipulation
- Handle missing data effectively
- Apply transformations to Series

**Estimated Time**: 3-4 hours

---

#### Tutorial 02: Introduction to DataFrames
**Topics Covered:**
- Understanding 2D data structures
- Creating DataFrames from dictionaries, lists, arrays
- DataFrame attributes (shape, columns, index, dtypes)
- Viewing data (head, tail, sample)
- Selecting columns and rows
- Boolean indexing and filtering
- Adding and removing columns/rows
- Sorting DataFrames
- Basic statistics (describe, mean, count)
- Handling missing data in DataFrames

**Key Learning Outcomes:**
- Master 2D data manipulation
- Perform complex selections and filtering
- Add/remove data dynamically
- Generate statistical summaries

**Estimated Time**: 4-5 hours

---

#### Tutorial 03: Reading and Writing Data
**Topics Covered:**
- Reading CSV files (various parameters)
- Writing CSV files
- Reading Excel files (single/multiple sheets)
- Writing Excel files (with formatting)
- JSON file operations
- HTML tables
- SQL database operations
- Pickle and Parquet formats
- Best practices for I/O operations

**Key Learning Outcomes:**
- Import data from multiple formats
- Export data efficiently
- Handle large files with chunking
- Work with databases

**Estimated Time**: 3-4 hours

---

#### Tutorial 04: Data Cleaning and Preprocessing
**Topics Covered:**
- Comprehensive missing data handling
- Removing and identifying duplicates
- Data validation techniques
- Outlier detection (IQR, Z-score)
- String cleaning and standardization
- Data type conversions
- Normalization and standardization
- Building cleaning pipelines

**Key Learning Outcomes:**
- Clean real-world messy data
- Validate data integrity
- Handle outliers appropriately
- Standardize data formats
- Create reproducible cleaning workflows

**Estimated Time**: 4-5 hours

---

### **Semester 2: Intermediate Level** (Data Manipulation)

#### Tutorial 05: GroupBy and Aggregation
**Topics Covered:**
- Split-apply-combine methodology
- Grouping by single and multiple columns
- Aggregation functions (sum, mean, count, etc.)
- Multiple aggregations with agg()
- Filtering groups
- Transform operations
- Apply custom functions to groups

**Key Learning Outcomes:**
- Perform group-wise calculations
- Apply multiple aggregation functions
- Filter and transform grouped data
- Write custom aggregation functions

**Estimated Time**: 4-5 hours

---

#### Tutorial 06: Merging, Joining, and Concatenating
**Topics Covered:**
- SQL-style joins (inner, left, right, outer)
- Merging on different column names
- Concatenating DataFrames (vertical/horizontal)
- Joining on indices
- Handling overlapping columns
- Merging strategies for real-world data

**Key Learning Outcomes:**
- Combine multiple DataFrames
- Understand join types
- Handle complex merge scenarios
- Choose appropriate merge strategies

**Estimated Time**: 3-4 hours

---

#### Tutorial 07: Pivot Tables and Reshaping
**Topics Covered:**
- Pivot and pivot_table operations
- Multiple aggregation in pivot tables
- Melting (wide to long format)
- Stacking and unstacking
- Cross-tabulation
- Reshaping strategies

**Key Learning Outcomes:**
- Reshape data between wide and long formats
- Create pivot tables for analysis
- Perform cross-tabulations
- Transform data structures

**Estimated Time**: 3-4 hours

---

### **Semester 3: Advanced Level** (Specialized Topics)

#### Tutorial 08: Time Series Analysis
**Topics Covered:**
- Datetime parsing and formatting
- Creating date ranges
- Time-based indexing and slicing
- Resampling (changing frequency)
- Rolling and expanding windows
- Shift and lag operations
- Percentage changes
- Time zone handling

**Key Learning Outcomes:**
- Work with time-indexed data
- Perform time-based operations
- Calculate moving averages
- Handle time zones
- Resample to different frequencies

**Estimated Time**: 4-5 hours

---

#### Tutorial 09: Multi-Index (Hierarchical Indexing)
**Topics Covered:**
- Creating multi-level indices
- Selecting with multi-index
- Stacking and unstacking
- Swapping index levels
- Sorting multi-index DataFrames
- Aggregating by specific levels
- Converting between flat and hierarchical

**Key Learning Outcomes:**
- Work with hierarchical data
- Perform multi-level selections
- Transform index structures
- Aggregate at different levels

**Estimated Time**: 3-4 hours

---

#### Tutorial 10: Performance Optimization
**Topics Covered:**
- Vectorized operations vs loops
- Memory optimization techniques
- Categorical data for memory savings
- Query method for fast filtering
- Data type optimization
- Avoiding chained indexing
- Profiling and benchmarking
- Best practices for large datasets

**Key Learning Outcomes:**
- Write efficient pandas code
- Optimize memory usage
- Improve computation speed
- Profile and benchmark code

**Estimated Time**: 3-4 hours

---

## 💡 Exercise Files

Each exercise file contains 10 practical problems with solutions:

### Exercise 01: Series Fundamentals
- Creating and manipulating Series
- Statistical calculations
- Filtering and transformation
- Handling missing data

### Exercise 02: DataFrame Operations
- Creating DataFrames
- Selecting and filtering
- Adding/removing columns
- Sorting and grouping

### Exercise 03: GroupBy and Merging
- Group-wise operations
- Multiple aggregations
- Merging DataFrames
- Pivot tables

### Exercise 04: Time Series
- Date range creation
- Time-based indexing
- Resampling
- Rolling calculations

---

## 🚀 Getting Started

### Installation

```bash
# Install pandas and required dependencies
pip install pandas numpy openpyxl

# Optional: For Excel support
pip install openpyxl xlsxwriter

# Optional: For advanced features
pip install sqlalchemy pyarrow
```

### Running the Tutorials

1. **Start with beginner tutorials:**
   ```bash
   cd 01_beginner
   python 01_intro_and_series.py
   ```

2. **Each file is self-contained** - you can run them independently

3. **Follow the order** for progressive learning

4. **Complete exercises** after each tutorial section

### Running Exercises

```bash
cd exercises
python 01_series_exercises.py
```

---

## 📖 Study Guide

### Week-by-Week Plan (30 weeks)

**Weeks 1-4**: Beginner Tutorial 01-02 (Series and DataFrames)
**Weeks 5-8**: Beginner Tutorial 03-04 (I/O and Cleaning)
**Weeks 9-12**: Exercises 01-02, Review and Practice

**Weeks 13-16**: Intermediate Tutorial 05-06 (GroupBy and Merging)
**Weeks 17-20**: Intermediate Tutorial 07, Exercise 03
**Weeks 21-22**: Midterm Review and Project

**Weeks 23-26**: Advanced Tutorial 08-09 (Time Series and Multi-Index)
**Weeks 27-29**: Advanced Tutorial 10, Exercise 04
**Week 30**: Final Review and Comprehensive Project

---

## 🔑 Key Concepts Summary

### **DataFrames as Objects** (Topics #26-36: OOP)
```python
# DataFrame is a CLASS (Topic #26)
df = pd.DataFrame({'A': [1, 2, 3]})  # Creating an object
print(type(df))  # <class 'pandas.core.frame.DataFrame'>

# Has METHODS (Topic #27)
df.head()      # Method call
df.describe()  # Method call
df.mean()      # Method call

# Has ATTRIBUTES (Topic #27)
df.shape       # Attribute access (not a method!)
df.columns     # Attribute access
df.dtypes      # Attribute access
```

### **Method Chaining** (Topic #27: Fluent Interfaces)
```python
# Chain operations for readable data transformations
result = (df
    .query('age > 25')           # Filter
    .sort_values('salary')        # Sort
    .groupby('department')        # Group
    .agg({'salary': 'mean'})     # Aggregate
    .round(2))                    # Format

# This works because most methods return DataFrames!
# This is OBJECT-ORIENTED design (Topics #26-36)
```

### **Memory Optimization** (Topic #24)
```python
# Check memory usage
df.info(memory_usage='deep')
df.memory_usage(deep=True)

# Optimize dtypes (Topic #24 + #37)
df['age'] = df['age'].astype('int8')      # Save memory!
df['category'] = df['category'].astype('category')  # For repeated values

# Before optimization
print(df.memory_usage(deep=True).sum())  # e.g., 800 KB

# After optimization
print(df.memory_usage(deep=True).sum())  # e.g., 200 KB (75% savings!)
```

### **Essential Pandas Operations**

```python
# Reading data
df = pd.read_csv('file.csv')
df = pd.read_excel('file.xlsx')

# Basic selection
df['column']                    # Select column
df[['col1', 'col2']]           # Select multiple columns
df.loc[row_label, col_label]   # Label-based selection
df.iloc[row_pos, col_pos]      # Position-based selection

# Filtering
df[df['column'] > 5]           # Boolean indexing
df.query('column > 5')         # Query method

# Grouping and aggregation
df.groupby('column').mean()    # Group and aggregate
df.groupby(['col1', 'col2']).agg({'col3': ['sum', 'mean']})

# Merging
pd.merge(df1, df2, on='key')   # SQL-style merge
pd.concat([df1, df2])          # Stack DataFrames

# Reshaping
df.pivot_table(values='val', index='idx', columns='col')
df.melt(id_vars=['id'], value_vars=['col1', 'col2'])

# Time series
df['date'] = pd.to_datetime(df['date'])
df.set_index('date').resample('M').mean()
```

---

## 🎓 Best Practices

1. **Always use descriptive variable names**
   ```python
   # Good
   sales_data = pd.read_csv('sales.csv')
   
   # Bad
   df = pd.read_csv('sales.csv')
   ```

2. **Check data before operations**
   ```python
   df.info()
   df.describe()
   df.head()
   ```

3. **Handle missing data explicitly**
   ```python
   # Check for missing values
   df.isnull().sum()
   
   # Handle appropriately
   df.fillna(df.mean())  # or
   df.dropna()
   ```

4. **Use vectorized operations**
   ```python
   # Good (vectorized)
   df['new_col'] = df['col1'] * df['col2']
   
   # Bad (loop)
   for i in range(len(df)):
       df.loc[i, 'new_col'] = df.loc[i, 'col1'] * df.loc[i, 'col2']
   ```

5. **Comment your code**
   - All tutorial files are heavily commented
   - Follow the same practice in your own code

---

## 📊 Common Use Cases

### Data Analysis Workflow

```python
# 1. Import data
df = pd.read_csv('data.csv')

# 2. Explore data
print(df.head())
print(df.info())
print(df.describe())

# 3. Clean data
df = df.dropna()
df = df.drop_duplicates()

# 4. Transform data
df['new_column'] = df['column1'] * df['column2']

# 5. Analyze data
summary = df.groupby('category').agg({
    'sales': ['sum', 'mean'],
    'quantity': 'sum'
})

# 6. Export results
summary.to_csv('results.csv')
```

---

## 🔧 Troubleshooting

### Common Issues

**Issue**: ImportError: No module named 'pandas'
**Solution**: `pip install pandas`

**Issue**: Cannot read Excel files
**Solution**: `pip install openpyxl`

**Issue**: Memory error with large files
**Solution**: Use `chunksize` parameter or read specific columns only

**Issue**: SettingWithCopyWarning
**Solution**: Use `.loc[]` or `.copy()` explicitly

---

## 📚 Additional Resources

### Official Documentation
- [Pandas Documentation](https://pandas.pydata.org/docs/)
- [10 Minutes to Pandas](https://pandas.pydata.org/docs/user_guide/10min.html)

### Practice Datasets
- Kaggle Datasets
- UCI Machine Learning Repository
- Data.gov

### Further Learning
- NumPy for numerical computing
- Matplotlib/Seaborn for visualization
- Scikit-learn for machine learning

---

## 🎯 Learning Objectives

By completing this course, students will be able to:

✅ Import and export data in multiple formats
✅ Clean and preprocess real-world messy data
✅ Perform exploratory data analysis
✅ Manipulate and transform DataFrames
✅ Aggregate data using groupby operations
✅ Merge and join multiple datasets
✅ Work with time series data
✅ Optimize code for performance
✅ Handle multi-dimensional data
✅ Apply pandas to solve real-world problems

---

## 📝 Assessment Suggestions

### For Instructors

**Quizzes** (After each major section)
- Multiple choice on pandas concepts
- Code output prediction
- Syntax correction

**Assignments** (Biweekly)
- Data cleaning projects
- Analysis reports
- Visualization tasks

**Midterm Project**
- Comprehensive data analysis
- Real-world dataset
- Written report

**Final Project**
- Complete analysis pipeline
- Multiple data sources
- Advanced techniques
- Presentation

---

## 🤝 Contributing

This is an educational resource. Suggestions for improvement:
- Additional exercises
- More real-world examples
- Updated best practices
- Bug fixes

---

## 📜 License

This educational material is provided for learning purposes.

---

## 👨‍🏫 Course Philosophy

This course emphasizes:

1. **Learning by Doing**: Every concept has executable code
2. **Progressive Complexity**: Start simple, build gradually
3. **Real-World Application**: Use practical examples
4. **Best Practices**: Follow pandas conventions
5. **Comprehensive Comments**: Understand the "why" not just "how"

---

## ⏱️ Time Commitment

**Per Week**: 3-4 hours
- 1-2 hours: Tutorial study and execution
- 1-2 hours: Exercise practice
- 0.5-1 hour: Review and experimentation

**Total Course**: 100-120 hours over one year

---

## 🎓 Certification

Upon completion, students should be proficient in:
- Data manipulation with pandas
- Data cleaning and preprocessing
- Exploratory data analysis
- Statistical analysis
- Data visualization preparation
- Performance optimization

---

## 📞 Support

For questions or issues:
1. Review the tutorial comments
2. Check pandas documentation
3. Consult Stack Overflow
4. Review exercise solutions

---

## 🔄 Updates

This course package includes:
- **Version**: 1.0
- **Last Updated**: November 2024
- **Pandas Version**: 2.0+
- **Python Version**: 3.8+

---

## ✨ Acknowledgments

This comprehensive tutorial package was designed for undergraduate education, with a focus on:
- Clear, heavily commented code
- Progressive difficulty
- Practical applications
- Real-world data scenarios

---

**Happy Learning! 🐼📊**

---

*For best results, work through tutorials in order, complete all exercises, and experiment with your own datasets. Practice is key to mastering pandas!*
