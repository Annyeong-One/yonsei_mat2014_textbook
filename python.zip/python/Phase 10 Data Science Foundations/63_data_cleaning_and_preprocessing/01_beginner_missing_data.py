"""
Data Cleaning & Preprocessing - Tutorial 01
============================================
Topic: Handling Missing Data (Beginner Level)

Learning Objectives:
1. Understand types of missing data (MCAR, MAR, MNAR)
2. Detect missing values in datasets
3. Apply various imputation strategies
4. Make informed decisions about missing data handling

Author: Educational Package for Undergraduate CS
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 01: HANDLING MISSING DATA")
print("="*80)

# ============================================================================
# PART 1: UNDERSTANDING MISSING DATA
# ============================================================================

print("\n" + "="*80)
print("PART 1: Understanding Missing Data")
print("="*80)

# Creating sample dataset with missing values
data = {
    'student_id': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    'age': [20, 21, np.nan, 22, 20, np.nan, 21, 23, 20, 22],
    'gpa': [3.5, np.nan, 3.8, 3.2, np.nan, 3.9, 3.6, np.nan, 3.7, 3.4],
    'study_hours': [15, 20, 18, np.nan, 25, 22, np.nan, 19, 21, np.nan],
    'attendance': [95, 88, np.nan, 75, 92, 85, 90, np.nan, 87, 82]
}

df = pd.DataFrame(data)
print("\nSample Dataset:")
print(df)

#  Detect missing values
print("\n\nDetecting Missing Values:")
print("-" * 40)
print("Missing count per column:")
print(df.isnull().sum())
print("\nMissing percentage per column:")
print((df.isnull().sum() / len(df) * 100).round(2))

# ============================================================================
# PART 2: DELETION METHODS
# ============================================================================

print("\n" + "="*80)
print("PART 2: Deletion Methods")
print("="*80)

# Method 1: Listwise deletion (drop rows with any missing value)
df_listwise = df.dropna()
print(f"\nListwise deletion: {len(df)} rows → {len(df_listwise)} rows")
print("⚠️  Lost:", len(df) - len(df_listwise), "rows")

# Method 2: Column deletion (drop columns with too many missing)
threshold = 0.5  # 50% threshold
cols_to_drop = [col for col in df.columns if (df[col].isnull().sum() / len(df)) > threshold]
print(f"\nColumns with >{threshold*100}% missing: {cols_to_drop}")

# ============================================================================
# PART 3: IMPUTATION METHODS
# ============================================================================

print("\n" + "="*80)
print("PART 3: Imputation Methods")
print("="*80)

# Method 1: Mean imputation
df_mean = df.copy()
for col in ['age', 'gpa', 'study_hours', 'attendance']:
    df_mean[col] = df_mean[col].fillna(df_mean[col].mean())
print("\nAfter mean imputation:")
print("Missing values:", df_mean.isnull().sum().sum())

# Method 2: Median imputation (robust to outliers)
df_median = df.copy()
for col in ['age', 'gpa', 'study_hours', 'attendance']:
    df_median[col] = df_median[col].fillna(df_median[col].median())
print("\nAfter median imputation:")
print("Missing values:", df_median.isnull().sum().sum())

# Method 3: Forward fill (for time series)
df_ffill = df.copy()
df_ffill = df_ffill.fillna(method='ffill')
print("\nAfter forward fill:")
print("Missing values:", df_ffill.isnull().sum().sum())

# Method 4: Interpolation
df_interp = df.copy()
df_interp[['attendance']] = df_interp[['attendance']].interpolate(method='linear')
print("\nAfter interpolation on 'attendance':")
print("Missing in attendance:", df_interp['attendance'].isnull().sum())

# ============================================================================
# PART 4: ADVANCED STRATEGIES
# ============================================================================

print("\n" + "="*80)
print("PART 4: Advanced Strategies")
print("="*80)

# Strategy 1: Group-based imputation
df_grouped = df.copy()
df_grouped['year'] = [1, 1, 2, 2, 1, 2, 1, 2, 1, 2]  # Add grouping variable
df_grouped['gpa'] = df_grouped.groupby('year')['gpa'].transform(lambda x: x.fillna(x.mean()))
print("\nGroup-based imputation (GPA by year):")
print(df_grouped[['student_id', 'year', 'gpa']])

# Strategy 2: Missing value indicators
df_indicator = df.copy()
df_indicator['age_was_missing'] = df_indicator['age'].isnull().astype(int)
df_indicator['age'] = df_indicator['age'].fillna(df_indicator['age'].mean())
print("\nMissing value indicators added")
print(df_indicator[['student_id', 'age', 'age_was_missing']].head())

# ============================================================================
# PART 5: COMPLETE WORKFLOW EXAMPLE
# ============================================================================

print("\n" + "="*80)
print("PART 5: Complete Workflow")
print("="*80)

df_final = df.copy()

# Step 1: Analyze missingness pattern
print("\nStep 1: Analyze missingness")
print("Missing percentages:")
print((df_final.isnull().sum() / len(df_final) * 100).round(2))

# Step 2: Choose appropriate strategy for each column
print("\nStep 2: Apply tailored strategies")

# Age: Use median (robust)
if df_final['age'].isnull().any():
    median_age = df_final['age'].median()
    df_final['age'] = df_final['age'].fillna(median_age)
    print(f"✓ Age: filled with median ({median_age})")

# GPA: Use mean (normally distributed)
if df_final['gpa'].isnull().any():
    mean_gpa = df_final['gpa'].mean()
    df_final['gpa'] = df_final['gpa'].fillna(mean_gpa)
    print(f"✓ GPA: filled with mean ({mean_gpa:.2f})")

# Study hours: Use median
if df_final['study_hours'].isnull().any():
    median_hours = df_final['study_hours'].median()
    df_final['study_hours'] = df_final['study_hours'].fillna(median_hours)
    print(f"✓ Study hours: filled with median ({median_hours})")

# Attendance: Use interpolation
if df_final['attendance'].isnull().any():
    df_final['attendance'] = df_final['attendance'].interpolate(method='linear')
    print("✓ Attendance: filled with interpolation")

# Step 3: Verify
print("\nStep 3: Verification")
print("Remaining missing values:", df_final.isnull().sum().sum())
print("\nCleaned dataset:")
print(df_final)

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("\n" + "="*80)
print("KEY TAKEAWAYS")
print("="*80)

print("""
1. Always investigate WHY data is missing before deciding on strategy
2. Mean/median imputation is simple but reduces variance
3. Deletion is easy but can introduce bias
4. Forward fill works well for time series
5. Group-based imputation preserves subgroup characteristics
6. Document all imputation decisions for reproducibility
7. Consider multiple strategies and compare results
8. Missing indicators preserve information about missingness

DECISION GUIDE:
- <5% missing + MCAR → Deletion is acceptable
- Normally distributed → Mean imputation
- Skewed or outliers → Median imputation
- Time series → Forward fill or interpolation
- Clear subgroups → Group-based imputation
- Important pattern → Keep missing indicators

NEXT STEPS:
→ Practice with exercise_01_missing_data.py
→ Continue to 02_beginner_data_types.py
""")

print("="*80)
print("END OF TUTORIAL 01")
print("="*80)
