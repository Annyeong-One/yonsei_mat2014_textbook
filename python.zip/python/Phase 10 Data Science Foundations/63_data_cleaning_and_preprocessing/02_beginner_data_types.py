"""
Data Cleaning & Preprocessing - Tutorial 02
============================================
Topic: Data Types and Validation (Beginner Level)

Learning Objectives:
1. Understand pandas data types (dtypes)
2. Convert between data types safely
3. Validate data constraints
4. Handle type conversion errors
5. Optimize memory usage with appropriate types

Author: Educational Package for Undergraduate CS
"""

import pandas as pd
import numpy as np
from datetime import datetime
import re
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 02: DATA TYPES AND VALIDATION")
print("="*80)

# ============================================================================
# PART 1: UNDERSTANDING PANDAS DATA TYPES
# ============================================================================

print("\n" + "="*80)
print("PART 1: Understanding Pandas Data Types")
print("="*80)

# Sample dataset with mixed/incorrect types
data = {
    'student_id': ['001', '002', '003', '004', '005'],
    'age': ['20', '21', '22', 'twenty-three', '24'],  # Mixed types!
    'gpa': [3.5, 3.8, '3.2', 3.9, 3.6],  # Mixed numeric and string
    'enrollment_date': ['2023-09-01', '2023-09-01', '2023-09-02', '2023/09/01', '01-Sep-2023'],
    'is_active': ['True', 1, 'False', 0, 'Yes'],
    'credits': ['15', '18', '12', '21', '16']
}

df = pd.DataFrame(data)
print("\nDataset with type issues:")
print(df)
print("\nCurrent data types:")
print(df.dtypes)
print("\n⚠️  Many columns are 'object' instead of proper numeric/date types!")

# ============================================================================
# PART 2: TYPE CONVERSION STRATEGIES
# ============================================================================

print("\n" + "="*80)
print("PART 2: Type Conversion Strategies")
print("="*80)

df_clean = df.copy()

# Strategy 1: Safe numeric conversion with pd.to_numeric
print("\n--- Converting to Numeric Types ---")
# errors='coerce' converts invalid values to NaN
df_clean['age'] = pd.to_numeric(df_clean['age'], errors='coerce')
df_clean['gpa'] = pd.to_numeric(df_clean['gpa'], errors='coerce')
df_clean['credits'] = pd.to_numeric(df_clean['credits'], errors='coerce').astype('Int64')

print("After numeric conversion:")
print(df_clean[['age', 'gpa', 'credits']])
print("\nTypes:")
print(df_clean[['age', 'gpa', 'credits']].dtypes)
print("\n✓ Invalid 'twenty-three' became NaN (can be handled with missing data strategies)")

# Strategy 2: Boolean conversion with custom function
print("\n--- Converting to Boolean ---")

def flexible_bool(value):
    """Convert various representations to boolean"""
    if pd.isna(value):
        return np.nan
    str_val = str(value).lower().strip()
    if str_val in ['true', '1', 'yes', 'y', 't']:
        return True
    elif str_val in ['false', '0', 'no', 'n', 'f']:
        return False
    else:
        return np.nan

df_clean['is_active'] = df_clean['is_active'].apply(flexible_bool)
print("After boolean conversion:")
print(df_clean[['student_id', 'is_active']])

# Strategy 3: Datetime conversion
print("\n--- Converting to Datetime ---")
df_clean['enrollment_date'] = pd.to_datetime(df_clean['enrollment_date'], errors='coerce')
print("After datetime conversion:")
print(df_clean['enrollment_date'])
print(f"Type: {df_clean['enrollment_date'].dtype}")

# Strategy 4: Category type for efficiency
print("\n--- Converting to Category (Memory Optimization) ---")
df_clean['grade'] = ['A', 'B', 'A', 'B', 'A']
mem_before = df_clean['grade'].memory_usage(deep=True)
df_clean['grade'] = df_clean['grade'].astype('category')
mem_after = df_clean['grade'].memory_usage(deep=True)
print(f"Memory usage: {mem_before} bytes → {mem_after} bytes")
print(f"Savings: {(1 - mem_after/mem_before)*100:.1f}%")

# ============================================================================
# PART 3: DATA VALIDATION
# ============================================================================

print("\n" + "="*80)
print("PART 3: Data Validation")
print("="*80)

# Create validation dataset
val_data = {
    'student_id': [1, 2, 3, 4, 5],
    'age': [20, 21, -5, 22, 150],  # Invalid: -5 and 150
    'gpa': [3.5, 3.8, 5.2, 3.2, -1.0],  # Invalid: 5.2 and -1.0
    'email': ['john@edu.com', 'jane@edu', 'bob@edu.com', 'alice@', 'charlie@edu.com'],
    'phone': ['1234567890', '555-1234', '123', '9876543210', 'abc-defg']
}

df_val = pd.DataFrame(val_data)
print("\nDataset for validation:")
print(df_val)

# Validation 1: Range validation
print("\n--- Range Validation ---")
age_min, age_max = 18, 100
invalid_ages = df_val[(df_val['age'] < age_min) | (df_val['age'] > age_max)]
print(f"Invalid ages (not in range {age_min}-{age_max}):")
print(invalid_ages[['student_id', 'age']])

gpa_min, gpa_max = 0.0, 4.0
invalid_gpa = df_val[(df_val['gpa'] < gpa_min) | (df_val['gpa'] > gpa_max)]
print(f"\nInvalid GPAs (not in range {gpa_min}-{gpa_max}):")
print(invalid_gpa[['student_id', 'gpa']])

# Validation 2: Format validation (regex patterns)
print("\n--- Format Validation ---")

# Email validation
email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
df_val['email_valid'] = df_val['email'].str.match(email_pattern, na=False)
print("Email validation:")
print(df_val[['student_id', 'email', 'email_valid']])

# Phone validation (should have exactly 10 digits)
df_val['phone_digits'] = df_val['phone'].str.replace(r'\D', '', regex=True)
df_val['phone_valid'] = df_val['phone_digits'].str.len() == 10
print("\nPhone validation (10 digits required):")
print(df_val[['student_id', 'phone', 'phone_valid']])

# ============================================================================
# PART 4: HANDLING VALIDATION ERRORS
# ============================================================================

print("\n" + "="*80)
print("PART 4: Handling Validation Errors")
print("="*80)

df_fix = df_val.copy()

# Strategy 1: Set invalid values to NaN
print("\n--- Strategy 1: Set to NaN ---")
df_fix.loc[(df_fix['age'] < 18) | (df_fix['age'] > 100), 'age'] = np.nan
df_fix.loc[(df_fix['gpa'] < 0.0) | (df_fix['gpa'] > 4.0), 'gpa'] = np.nan
print("After setting invalid values to NaN:")
print(df_fix[['student_id', 'age', 'gpa']])

# Strategy 2: Clip to valid range
print("\n--- Strategy 2: Clip to Range ---")
df_clip = df_val.copy()
df_clip['age'] = df_clip['age'].clip(lower=18, upper=100)
df_clip['gpa'] = df_clip['gpa'].clip(lower=0.0, upper=4.0)
print("After clipping:")
print(df_clip[['student_id', 'age', 'gpa']])
print("⚠️  Clipping changes data - use carefully!")

# Strategy 3: Flag for manual review
print("\n--- Strategy 3: Flag for Review ---")
df_flag = df_val.copy()
df_flag['needs_review'] = ((df_flag['age'] < 18) | (df_flag['age'] > 100) |
                            (df_flag['gpa'] < 0.0) | (df_flag['gpa'] > 4.0))
flagged = df_flag[df_flag['needs_review']]
print(f"Flagged {len(flagged)} records for manual review:")
print(flagged[['student_id', 'age', 'gpa', 'needs_review']])

# ============================================================================
# PART 5: COMPLETE TYPE VALIDATION WORKFLOW
# ============================================================================

print("\n" + "="*80)
print("PART 5: Complete Type Validation Workflow")
print("="*80)

# Messy dataset
messy_data = {
    'id': ['1', '2', '3', '4', '5'],
    'age': ['25', '30', 'unknown', '35', '28'],
    'salary': ['50000', '60000', '55k', '70000', '48000'],
    'hire_date': ['2020-01-15', '2019/06/20', '15-Mar-2021', '2022-11-01', 'Invalid'],
    'is_manager': ['yes', 'no', '1', 'FALSE', 'True']
}

df_messy = pd.DataFrame(messy_data)
print("Original messy dataset:")
print(df_messy)
print("\nTypes:", df_messy.dtypes.values)

# Step-by-step cleaning
print("\n\nCleaning workflow:")
print("-" * 40)

df_processed = df_messy.copy()

# Convert ID to integer
df_processed['id'] = pd.to_numeric(df_processed['id'], errors='coerce').astype('Int64')
print("✓ Converted 'id' to integer")

# Convert age to integer
df_processed['age'] = pd.to_numeric(df_processed['age'], errors='coerce').astype('Int64')
print("✓ Converted 'age' to integer (invalid → NaN)")

# Convert salary (handle 'k' suffix)
df_processed['salary'] = df_processed['salary'].str.replace('k', '000', regex=False)
df_processed['salary'] = pd.to_numeric(df_processed['salary'], errors='coerce')
print("✓ Converted 'salary' (handled 'k' suffix)")

# Convert hire_date to datetime
df_processed['hire_date'] = pd.to_datetime(df_processed['hire_date'], errors='coerce')
print("✓ Converted 'hire_date' to datetime")

# Convert is_manager to boolean
df_processed['is_manager'] = df_processed['is_manager'].apply(flexible_bool)
print("✓ Converted 'is_manager' to boolean")

print("\nFinal processed dataset:")
print(df_processed)
print("\nFinal types:")
print(df_processed.dtypes)
print("\nMissing values after processing:")
print(df_processed.isnull().sum())

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("\n" + "="*80)
print("KEY TAKEAWAYS")
print("="*80)

print("""
1. ALWAYS check data types after loading - don't assume correctness
2. Use pd.to_numeric() and pd.to_datetime() with errors='coerce' for safety
3. Object dtype usually indicates type issues needing conversion
4. Category dtype saves memory for columns with limited unique values
5. Validate ranges AFTER type conversion
6. Document validation rules and conversion logic
7. Use appropriate types: Int64 for integers, float64 for decimals
8. Format validation with regex is powerful for structured data

TYPE CONVERSION CHECKLIST:
☐ Check current dtypes with df.dtypes
☐ Convert numeric strings to int/float
☐ Convert date strings to datetime
☐ Convert categorical strings to category
☐ Validate ranges after conversion
☐ Handle conversion errors appropriately
☐ Document all transformations
☐ Verify final types match expectations

NEXT STEPS:
→ Practice with exercise_02_data_types.py
→ Continue to 03_beginner_duplicates.py
""")

print("="*80)
print("END OF TUTORIAL 02")
print("="*80)
