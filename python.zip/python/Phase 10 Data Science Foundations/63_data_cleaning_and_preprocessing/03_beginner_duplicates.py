"""
Data Cleaning & Preprocessing - Tutorial 03
============================================
Topic: Detecting and Removing Duplicates (Beginner Level)

Learning Objectives:
1. Understand types of duplicates (exact, partial, semantic)
2. Detect duplicates using various methods
3. Apply appropriate duplicate removal strategies
4. Handle edge cases in duplicate detection

Author: Educational Package for Undergraduate CS
"""

import pandas as pd
import numpy as np
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 03: HANDLING DUPLICATES")
print("="*80)

# ============================================================================
# PART 1: UNDERSTANDING DUPLICATES
# ============================================================================

print("\n" + "="*80)
print("PART 1: Understanding Duplicates")
print("="*80)

# Sample data with duplicates
data = {
    'student_id': [1001, 1002, 1001, 1003, 1002, 1004, 1005, 1003],
    'name': ['Alice', 'Bob', 'Alice', 'Charlie', 'Bob', 'Diana', 'Eve', 'Charlie'],
    'age': [20, 21, 20, 22, 21, 20, 23, 22],
    'major': ['CS', 'Math', 'CS', 'Physics', 'Math', 'CS', 'Biology', 'Physics'],
    'gpa': [3.8, 3.5, 3.8, 3.9, 3.5, 3.7, 3.6, 3.9]
}

df = pd.DataFrame(data)
print("\nDataset with duplicates:")
print(df)
print(f"Shape: {df.shape}")

# ============================================================================
# PART 2: DETECTING DUPLICATES
# ============================================================================

print("\n" + "="*80)
print("PART 2: Detecting Duplicates")
print("="*80)

# Method 1: Check if any duplicates exist
has_dups = df.duplicated().any()
print(f"\nHas duplicates: {has_dups}")
print(f"Number of duplicate rows: {df.duplicated().sum()}")

# Method 2: Show duplicate rows (excluding first occurrence)
print("\nDuplicate rows (excluding first):")
print(df[df.duplicated()])

# Method 3: Show all occurrences (including first)
print("\nAll duplicate rows (including first occurrence):")
print(df[df.duplicated(keep=False)])

# Method 4: Duplicates in specific columns
print("\nRows with duplicate student_id:")
print(df[df.duplicated(subset=['student_id'], keep=False)].sort_values('student_id'))

# Method 5: Count duplicates per group
print("\nCount of each duplicate student_id:")
dup_counts = df['student_id'].value_counts()
print(dup_counts[dup_counts > 1])

# ============================================================================
# PART 3: REMOVING DUPLICATES
# ============================================================================

print("\n" + "="*80)
print("PART 3: Removing Duplicates")
print("="*80)

# Strategy 1: Keep first occurrence
df_first = df.drop_duplicates()
print(f"\nKeep first: {len(df)} rows → {len(df_first)} rows")
print(df_first)

# Strategy 2: Keep last occurrence
df_last = df.drop_duplicates(keep='last')
print(f"\nKeep last: {len(df)} rows → {len(df_last)} rows")
print(df_last)

# Strategy 3: Remove all duplicates
df_none = df.drop_duplicates(keep=False)
print(f"\nRemove all: {len(df)} rows → {len(df_none)} rows")
print(df_none)

# Strategy 4: Remove based on specific columns
df_by_id = df.drop_duplicates(subset=['student_id'])
print(f"\nBy student_id: {len(df)} rows → {len(df_by_id)} rows")
print(df_by_id)

# Strategy 5: Multiple column criteria
df_multi = df.drop_duplicates(subset=['student_id', 'major'])
print(f"\nBy student_id + major: {len(df)} rows → {len(df_multi)} rows")
print(df_multi)

# ============================================================================
# PART 4: HANDLING PARTIAL DUPLICATES
# ============================================================================

print("\n" + "="*80)
print("PART 4: Handling Partial Duplicates")
print("="*80)

# Transaction data example
trans_data = {
    'order_id': [1, 2, 3, 4, 5, 6],
    'customer_id': [101, 101, 102, 103, 101, 102],
    'product': ['Laptop', 'Mouse', 'Keyboard', 'Monitor', 'Laptop', 'Mouse'],
    'quantity': [1, 2, 1, 1, 1, 3],
    'price': [1000, 25, 75, 300, 1000, 20],
    'date': pd.to_datetime(['2023-01-01', '2023-01-02', '2023-01-01',
                            '2023-01-03', '2023-01-05', '2023-01-06'])
}

df_trans = pd.DataFrame(trans_data)
print("\nTransaction data:")
print(df_trans)

# Check: Same customer + product + price (potential duplicate)
potential_dups = df_trans.duplicated(subset=['customer_id', 'product', 'price'], keep=False)
print("\nPotential duplicates (same customer, product, price):")
print(df_trans[potential_dups].sort_values(['customer_id', 'product']))

# Different dates = different orders (NOT duplicates)
same_cust_prod = df_trans.duplicated(subset=['customer_id', 'product'], keep=False)
print("\nSame customer + product (likely VALID, different dates):")
print(df_trans[same_cust_prod].sort_values(['customer_id', 'product', 'date']))
print("⚠️  Don't remove these - different dates mean different orders!")

# ============================================================================
# PART 5: ADVANCED DUPLICATE HANDLING
# ============================================================================

print("\n" + "="*80)
print("PART 5: Advanced Duplicate Handling")
print("="*80)

# Strategy: Aggregate instead of remove
print("\n--- Aggregating Duplicates ---")
df_agg = df_trans.groupby('customer_id').agg({
    'price': ['sum', 'mean', 'count'],
    'date': ['min', 'max']
}).reset_index()
df_agg.columns = ['customer_id', 'total_amount', 'avg_amount', 
                  'num_purchases', 'first_purchase', 'last_purchase']
print("Aggregated by customer:")
print(df_agg)

# Strategy: Keep best duplicate based on completeness
print("\n--- Keep Best Duplicate ---")
quality_data = {
    'customer_id': [101, 101, 102, 102, 103],
    'email': ['alice@email.com', np.nan, 'bob@email.com', 'bob@mail.com', 'charlie@email.com'],
    'phone': [np.nan, '555-0101', '555-0102', np.nan, '555-0103']
}
df_quality = pd.DataFrame(quality_data)
df_quality['completeness'] = df_quality[['email', 'phone']].notna().sum(axis=1) / 2
df_best = df_quality.sort_values('completeness', ascending=False).drop_duplicates(
    subset=['customer_id'], keep='first')
print("Kept best record per customer:")
print(df_best)

# Strategy: Merge information from duplicates
print("\n--- Merge Duplicates ---")
def merge_duplicates(group):
    """Combine non-null values from duplicates"""
    return pd.Series({
        'customer_id': group['customer_id'].iloc[0],
        'email': group['email'].dropna().iloc[0] if group['email'].notna().any() else np.nan,
        'phone': group['phone'].dropna().iloc[0] if group['phone'].notna().any() else np.nan
    })
df_merged = df_quality.groupby('customer_id').apply(merge_duplicates).reset_index(drop=True)
print("Merged duplicates (combined info):")
print(df_merged)

# ============================================================================
# PART 6: SEMANTIC DUPLICATES
# ============================================================================

print("\n" + "="*80)
print("PART 6: Semantic Duplicates")
print("="*80)

# Different representations of same entity
semantic_data = {
    'name': ['John Doe', 'john doe', 'JOHN DOE', 'Bob Smith', 'Robert Smith'],
    'country': ['USA', 'United States', 'US', 'UK', 'United Kingdom']
}
df_semantic = pd.DataFrame(semantic_data)
print("\nDataset with semantic duplicates:")
print(df_semantic)

# Standardize for detection
df_semantic['name_lower'] = df_semantic['name'].str.lower()
print("\nCase-insensitive name duplicates:")
print(df_semantic[df_semantic.duplicated(subset=['name_lower'], keep=False)])

# Standardize countries
country_map = {
    'USA': 'United States', 'US': 'United States',
    'UK': 'United Kingdom'
}
df_semantic['country_std'] = df_semantic['country'].map(country_map).fillna(df_semantic['country'])
print("\nStandardized countries:")
print(df_semantic[['country', 'country_std']])

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("\n" + "="*80)
print("KEY TAKEAWAYS")
print("="*80)

print("""
1. Investigate WHY duplicates exist before removing
2. Exact duplicates usually safe to remove
3. Partial duplicates require domain knowledge
4. Semantic duplicates need standardization first
5. Consider aggregating instead of deleting
6. Keep best record or merge information when possible
7. Use subset parameter for targeted duplicate detection
8. Document duplicate handling strategy

DECISION TREE:
- Exact duplicates → Likely errors, remove
- Partial duplicates with different timestamps → Likely valid, keep
- Semantic duplicates → Standardize first

BEST PRACTICES:
☑ Standardize before detecting (lowercase, trim)
☑ Check multiple column combinations
☑ Sort by quality/date before keeping first/last
☑ Consider aggregating vs deleting
☑ Document removal criteria
☑ Verify business rules

NEXT STEPS:
→ Practice with exercise_03_duplicates.py
→ Continue to 04_intermediate_outliers.py
""")

print("="*80)
print("END OF TUTORIAL 03")
print("="*80)
