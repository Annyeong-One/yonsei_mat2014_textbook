"""
Data Cleaning & Preprocessing - Tutorial 05
Topic: Categorical Encoding (Intermediate)
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 05: CATEGORICAL ENCODING")
print("="*80)

# Sample data
data = {
    'color': ['red', 'blue', 'green', 'red', 'green', 'blue'],
    'size': ['S', 'M', 'L', 'M', 'S', 'L'],
    'grade': ['A', 'B', 'C', 'A', 'B', 'C'],
    'price': [10, 15, 20, 12, 11, 19]
}
df = pd.DataFrame(data)

print("\nOriginal data:")
print(df)

# Method 1: Label Encoding
print("\n--- Label Encoding ---")
le = LabelEncoder()
df['color_label'] = le.fit_transform(df['color'])
print("Color mapping:", dict(zip(le.classes_, le.transform(le.classes_))))
print(df[['color', 'color_label']])
print("⚠️  Implies ordering: use for ordinal data only!")

# Method 2: One-Hot Encoding
print("\n--- One-Hot Encoding ---")
df_onehot = pd.get_dummies(df, columns=['color'], prefix='color')
print(df_onehot.head())
print("✓ Creates binary columns, no implied ordering")

# Method 3: Ordinal Encoding
print("\n--- Ordinal Encoding ---")
size_order = {'S': 0, 'M': 1, 'L': 2}
df['size_ordinal'] = df['size'].map(size_order)
print(df[['size', 'size_ordinal']])
print("✓ Preserves natural ordering")

# Method 4: Frequency Encoding
print("\n--- Frequency Encoding ---")
color_freq = df['color'].value_counts() / len(df)
df['color_freq'] = df['color'].map(color_freq)
print(df[['color', 'color_freq']])
print("✓ Captures importance by frequency")

# Method 5: Target Encoding
print("\n--- Target Encoding ---")
color_price_mean = df.groupby('color')['price'].mean()
df['color_target'] = df['color'].map(color_price_mean)
print(df[['color', 'price', 'color_target']])
print("⚠️  Risk of overfitting, use with cross-validation!")

print("\nKEY TAKEAWAYS:")
print("- Label encoding: ordinal categories only")
print("- One-hot: nominal categories, increases dimensions")
print("- Ordinal: natural ordering preserved")
print("- Frequency: captures distribution information")
print("- Target: powerful but risk of leakage")
print("\nNEXT: 06_intermediate_transformation.py")
print("="*80)
