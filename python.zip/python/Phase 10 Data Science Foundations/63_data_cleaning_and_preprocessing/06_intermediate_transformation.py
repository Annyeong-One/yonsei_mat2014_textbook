"""
Data Cleaning & Preprocessing - Tutorial 06
Topic: Data Transformation (Intermediate)
"""
import pandas as pd
import numpy as np
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 06: DATA TRANSFORMATION")
print("="*80)

# Generate skewed data
np.random.seed(42)
skewed_data = np.random.exponential(scale=2.0, size=100)
df = pd.DataFrame({'value': skewed_data})

print("Original data stats:")
print(f"Mean: {df['value'].mean():.2f}")
print(f"Median: {df['value'].median():.2f}")
print(f"Skewness: {df['value'].skew():.2f}")

# Transformation 1: Log
print("\n--- Log Transformation ---")
df['log_value'] = np.log1p(df['value'])  # log1p handles zeros
print(f"Skewness after log: {df['log_value'].skew():.2f}")
print("✓ Reduces right skew, handles multiplicative relationships")

# Transformation 2: Square root
print("\n--- Square Root Transformation ---")
df['sqrt_value'] = np.sqrt(df['value'])
print(f"Skewness after sqrt: {df['sqrt_value'].skew():.2f}")
print("✓ Milder than log, preserves zeros")

# Transformation 3: Box-Cox
print("\n--- Box-Cox Transformation ---")
df_positive = df[df['value'] > 0].copy()
df_positive['boxcox_value'], lambda_param = stats.boxcox(df_positive['value'])
print(f"Optimal lambda: {lambda_param:.2f}")
print(f"Skewness after Box-Cox: {df_positive['boxcox_value'].skew():.2f}")
print("✓ Automatically finds best power transformation")

# Transformation 4: Yeo-Johnson (handles negatives)
print("\n--- Yeo-Johnson Transformation ---")
df['yeojohnson_value'], lambda_yj = stats.yeojohnson(df['value'])
print(f"Optimal lambda: {lambda_yj:.2f}")
print(f"Skewness after Yeo-Johnson: {df['yeojohnson_value'].skew():.2f}")
print("✓ Like Box-Cox but handles zero/negative values")

# Transformation 5: Quantile (Rank)
print("\n--- Quantile Transformation ---")
df['rank_value'] = df['value'].rank(pct=True)
print(f"Range: [{df['rank_value'].min():.2f}, {df['rank_value'].max():.2f}]")
print("✓ Makes distribution uniform")

print("\nWHEN TO USE:")
print("- Log: Right-skewed data, multiplicative relationships")
print("- Sqrt: Count data, Poisson-distributed")
print("- Box-Cox: Unknown best transformation (positive only)")
print("- Yeo-Johnson: Unknown transformation (any values)")
print("- Quantile: Need uniform distribution")
print("\nNEXT: 07_advanced_feature_scaling.py")
print("="*80)
