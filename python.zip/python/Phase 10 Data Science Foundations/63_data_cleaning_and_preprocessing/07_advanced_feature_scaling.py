"""
Data Cleaning & Preprocessing - Tutorial 07
Topic: Feature Scaling (Advanced)
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 07: FEATURE SCALING")
print("="*80)

# Sample data with different scales
data = {
    'age': [25, 30, 35, 40, 45],
    'salary': [50000, 60000, 75000, 90000, 100000],
    'years_exp': [2, 5, 8, 12, 15]
}
df = pd.DataFrame(data)

print("Original data:")
print(df)
print("\nRanges:")
for col in df.columns:
    print(f"  {col}: [{df[col].min()}, {df[col].max()}]")

# Method 1: Standardization (Z-score)
print("\n--- Standardization (mean=0, std=1) ---")
scaler = StandardScaler()
df_standard = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
print(df_standard)
print("Mean:", df_standard.mean().values.round(10))
print("Std:", df_standard.std().values.round(2))
print("✓ Use for: Algorithms assuming normal distribution (SVM, neural networks)")

# Method 2: Min-Max Scaling
print("\n--- Min-Max Scaling [0, 1] ---")
scaler = MinMaxScaler()
df_minmax = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
print(df_minmax)
print("✓ Use for: Neural networks, algorithms needing bounded inputs")

# Method 3: Robust Scaling (uses median and IQR)
print("\n--- Robust Scaling ---")
scaler = RobustScaler()
df_robust = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
print(df_robust)
print("✓ Use for: Data with outliers (less sensitive)")

# Method 4: Max Abs Scaling ([-1, 1])
from sklearn.preprocessing import MaxAbsScaler
print("\n--- MaxAbs Scaling [-1, 1] ---")
scaler = MaxAbsScaler()
df_maxabs = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
print(df_maxabs)
print("✓ Use for: Sparse data, preserves sparsity")

# Method 5: Unit Vector (L2 normalization)
from sklearn.preprocessing import Normalizer
print("\n--- L2 Normalization ---")
scaler = Normalizer()
df_l2 = pd.DataFrame(scaler.fit_transform(df), columns=df.columns)
print(df_l2)
print("✓ Use for: Text processing, when direction matters more than magnitude")

print("\nCHOOSING SCALER:")
print("StandardScaler → Normal distribution assumption, no outliers")
print("MinMaxScaler → Need [0,1] range, no outliers")
print("RobustScaler → Have outliers")
print("MaxAbsScaler → Sparse data")
print("Normalizer → Row-wise scaling (vectors)")
print("\nNEXT: 08_advanced_feature_engineering.py")
print("="*80)
