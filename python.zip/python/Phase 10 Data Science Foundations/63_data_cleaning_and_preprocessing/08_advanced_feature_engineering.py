"""
Data Cleaning & Preprocessing - Tutorial 08
Topic: Feature Engineering (Advanced)
"""
import pandas as pd
import numpy as np
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 08: FEATURE ENGINEERING")
print("="*80)

# Sample data
data = {
    'date': pd.date_range('2023-01-01', periods=10, freq='D'),
    'temperature': [20, 22, 19, 23, 25, 24, 26, 28, 27, 29],
    'humidity': [65, 70, 68, 72, 75, 73, 78, 80, 76, 82],
    'price': [100, 105, 98, 110, 115, 112, 118, 125, 120, 130]
}
df = pd.DataFrame(data)

print("Original data:")
print(df.head())

# Feature 1: Datetime features
print("\n--- Datetime Features ---")
df['day_of_week'] = df['date'].dt.dayofweek
df['month'] = df['date'].dt.month
df['is_weekend'] = (df['day_of_week'] >= 5).astype(int)
print(df[['date', 'day_of_week', 'month', 'is_weekend']].head())

# Feature 2: Lag features
print("\n--- Lag Features ---")
df['price_lag1'] = df['price'].shift(1)
df['price_lag2'] = df['price'].shift(2)
print(df[['date', 'price', 'price_lag1', 'price_lag2']].head(5))

# Feature 3: Rolling statistics
print("\n--- Rolling Statistics ---")
df['temp_rolling_mean_3'] = df['temperature'].rolling(window=3).mean()
df['temp_rolling_std_3'] = df['temperature'].rolling(window=3).std()
print(df[['date', 'temperature', 'temp_rolling_mean_3', 'temp_rolling_std_3']].head(5))

# Feature 4: Interaction features
print("\n--- Interaction Features ---")
df['temp_humidity_interaction'] = df['temperature'] * df['humidity']
df['temp_to_humidity_ratio'] = df['temperature'] / df['humidity']
print(df[['temperature', 'humidity', 'temp_humidity_interaction', 'temp_to_humidity_ratio']].head())

# Feature 5: Polynomial features
print("\n--- Polynomial Features ---")
df['temperature_squared'] = df['temperature'] ** 2
df['temperature_cubed'] = df['temperature'] ** 3
print(df[['temperature', 'temperature_squared', 'temperature_cubed']].head())

# Feature 6: Binning
print("\n--- Binning ---")
df['temp_category'] = pd.cut(df['temperature'], bins=3, labels=['Low', 'Medium', 'High'])
print(df[['temperature', 'temp_category']].head())

# Feature 7: Target encoding
print("\n--- Target Statistics ---")
df['price_diff'] = df['price'].diff()
df['price_pct_change'] = df['price'].pct_change()
print(df[['price', 'price_diff', 'price_pct_change']].head(5))

print("\nFEATURE ENGINEERING TYPES:")
print("1. Datetime: Extract components (day, month, season)")
print("2. Lag: Previous values for time series")
print("3. Rolling: Moving averages and statistics")
print("4. Interaction: Combine features (*, /, +, -)")
print("5. Polynomial: Non-linear relationships")
print("6. Binning: Discretize continuous variables")
print("7. Aggregation: Group statistics")
print("\nNEXT: 09_advanced_pipelines.py")
print("="*80)
