"""
Data Cleaning & Preprocessing - Tutorial 09
Topic: Preprocessing Pipelines (Advanced)
"""
import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 09: PREPROCESSING PIPELINES")
print("="*80)

# Sample data with mixed types and missing values
data = {
    'age': [25, np.nan, 35, 40, 45],
    'salary': [50000, 60000, np.nan, 90000, 100000],
    'department': ['IT', 'HR', 'IT', 'Finance', 'HR'],
    'experience': [2, 5, 8, np.nan, 15]
}
df = pd.DataFrame(data)

print("Original data:")
print(df)

# Define preprocessing for numerical columns
numeric_features = ['age', 'salary', 'experience']
numeric_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='median')),
    ('scaler', StandardScaler())
])

# Define preprocessing for categorical columns
categorical_features = ['department']
categorical_transformer = Pipeline(steps=[
    ('imputer', SimpleImputer(strategy='constant', fill_value='missing')),
    ('onehot', OneHotEncoder(drop='first', sparse_output=False))
])

# Combine preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)
    ])

# Fit and transform
df_processed = preprocessor.fit_transform(df)
print("\nProcessed data shape:", df_processed.shape)
print("\nProcessed data (first 3 rows):")
print(df_processed[:3])

# Get feature names
num_names = numeric_features
cat_names = preprocessor.named_transformers_['cat']['onehot'].get_feature_names_out(categorical_features)
all_names = list(num_names) + list(cat_names)
print("\nFeature names:")
print(all_names)

# Create DataFrame with feature names
df_result = pd.DataFrame(df_processed, columns=all_names)
print("\nFinal processed DataFrame:")
print(df_result)

print("\nPIPELINE BENEFITS:")
print("✓ Consistent preprocessing across train/test")
print("✓ Prevents data leakage")
print("✓ Reusable and reproducible")
print("✓ Easy to save and load")
print("✓ Integrates with scikit-learn models")
print("\nNEXT: 10_advanced_real_world.py")
print("="*80)
