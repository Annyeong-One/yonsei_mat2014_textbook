"""
Data Cleaning & Preprocessing - Tutorial 10
Topic: Real-World Complete Workflow (Advanced)
"""
import pandas as pd
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("TUTORIAL 10: COMPLETE REAL-WORLD WORKFLOW")
print("="*80)

# Simulate messy real-world data
np.random.seed(42)
data = {
    'id': ['001', '002', '003', '002', '004', '005', '006'],  # Has duplicate
    'age': [25, '30', 35, 30, np.nan, 45, '22'],  # Mixed types
    'salary': ['50k', '60000', '75000', '60000', '90k', np.nan, '48000'],  # Inconsistent format
    'department': ['IT', 'hr', 'IT', 'HR', 'Finance', 'IT', 'finance'],  # Case issues
    'join_date': ['2020-01-15', '2019/06/20', '2021-03-10', '2019/06/20', 
                  '2022-11-01', 'Invalid', '2023-05-15'],
    'performance': [85, 90, -5, 90, 95, 150, 88]  # Has outliers
}
df = pd.DataFrame(data)

print("Original messy data:")
print(df)
print("\nIssues detected:")
print("- Duplicate rows")
print("- Mixed data types")
print("- Inconsistent formats (salary)")
print("- Case inconsistencies")
print("- Invalid dates")
print("- Missing values")
print("- Outliers in performance")

# STEP 1: Handle duplicates
print("\n" + "="*80)
print("STEP 1: Handle Duplicates")
print("="*80)
print(f"Rows before: {len(df)}")
df = df.drop_duplicates(subset=['id', 'age', 'department'], keep='first')
print(f"Rows after: {len(df)}")

# STEP 2: Fix data types
print("\n" + "="*80)
print("STEP 2: Fix Data Types")
print("="*80)

# Clean salary (remove 'k', convert to numeric)
df['salary'] = df['salary'].str.replace('k', '000', regex=False)
df['salary'] = pd.to_numeric(df['salary'], errors='coerce')
print("✓ Salary converted to numeric")

# Convert age to numeric
df['age'] = pd.to_numeric(df['age'], errors='coerce')
print("✓ Age converted to numeric")

# Fix date
df['join_date'] = pd.to_datetime(df['join_date'], errors='coerce')
print("✓ Join date converted to datetime")

# STEP 3: Standardize categorical values
print("\n" + "="*80)
print("STEP 3: Standardize Categorical")
print("="*80)
df['department'] = df['department'].str.title()
print("✓ Department standardized to Title Case")
print(df['department'].unique())

# STEP 4: Handle outliers
print("\n" + "="*80)
print("STEP 4: Handle Outliers")
print("="*80)

# Performance should be 0-100
df.loc[(df['performance'] < 0) | (df['performance'] > 100), 'performance'] = np.nan
print("✓ Invalid performance scores set to NaN")

# STEP 5: Handle missing values
print("\n" + "="*80)
print("STEP 5: Handle Missing Values")
print("="*80)
print("Missing values before:")
print(df.isnull().sum())

# Impute numerical columns
df['age'] = df['age'].fillna(df['age'].median())
df['salary'] = df['salary'].fillna(df['salary'].median())
df['performance'] = df['performance'].fillna(df['performance'].mean())
print("\n✓ Numerical columns imputed")

# Handle missing dates
df['join_date'] = df['join_date'].fillna(pd.Timestamp('2020-01-01'))
print("✓ Missing dates filled with default")

print("\nMissing values after:")
print(df.isnull().sum())

# STEP 6: Feature engineering
print("\n" + "="*80)
print("STEP 6: Feature Engineering")
print("="*80)
df['tenure_days'] = (pd.Timestamp('2024-01-01') - df['join_date']).dt.days
df['tenure_years'] = df['tenure_days'] / 365.25
print("✓ Created tenure features")

# STEP 7: Scaling
print("\n" + "="*80)
print("STEP 7: Feature Scaling")
print("="*80)
scaler = StandardScaler()
numerical_cols = ['age', 'salary', 'performance', 'tenure_years']
df[numerical_cols] = scaler.fit_transform(df[numerical_cols])
print("✓ Numerical features scaled")

# Final result
print("\n" + "="*80)
print("FINAL CLEANED DATASET")
print("="*80)
print(df)
print("\nData quality summary:")
print(f"- Rows: {len(df)}")
print(f"- Columns: {len(df.columns)}")
print(f"- Missing values: {df.isnull().sum().sum()}")
print(f"- Duplicates: {df.duplicated().sum()}")
print(f"- Memory usage: {df.memory_usage(deep=True).sum() / 1024:.2f} KB")

print("\nCOMPLETE WORKFLOW STEPS:")
print("1. Remove duplicates")
print("2. Fix data types")
print("3. Standardize categories")
print("4. Handle outliers")
print("5. Impute missing values")
print("6. Engineer features")
print("7. Scale features")
print("\n✓ Data is now clean and ready for modeling!")
print("="*80)
