# Data Cleaning & Preprocessing - Python Educational Package

## Course Overview
This comprehensive package covers data cleaning and preprocessing techniques essential for data science and machine learning workflows. The materials progress from fundamental concepts to advanced preprocessing pipelines.

## Package Structure

### Tutorial Files (Lectures)
1. **01_beginner_missing_data.py** - Handling missing values, basic strategies
2. **02_beginner_data_types.py** - Data type conversions and validation
3. **03_beginner_duplicates.py** - Detecting and removing duplicate data
4. **04_intermediate_outliers.py** - Outlier detection and treatment methods
5. **05_intermediate_encoding.py** - Categorical variable encoding techniques
6. **06_intermediate_transformation.py** - Data transformation and normalization
7. **07_advanced_feature_scaling.py** - Advanced scaling techniques
8. **08_advanced_feature_engineering.py** - Creating new features
9. **09_advanced_pipelines.py** - Building preprocessing pipelines
10. **10_advanced_real_world.py** - Complete real-world workflow

### Exercise Files (Practice)
- **exercise_01_missing_data.py** - Practice handling missing values
- **exercise_02_data_types.py** - Practice data type operations
- **exercise_03_duplicates.py** - Practice duplicate handling
- **exercise_04_outliers.py** - Practice outlier detection
- **exercise_05_encoding.py** - Practice categorical encoding
- **exercise_06_complete_preprocessing.py** - Comprehensive challenge

### Solution Files
- **solution_01_missing_data.py** through **solution_06_complete_preprocessing.py**

## Prerequisites
- Basic Python programming
- NumPy and Pandas fundamentals
- Basic statistics knowledge

## Required Libraries
```bash
pip install numpy pandas scikit-learn scipy matplotlib seaborn
```

## How to Use This Package
1. Work through tutorial files 01-10 in order
2. Complete exercises after each 2-3 tutorial files
3. Compare your solutions with provided solution files
4. Apply concepts to your own datasets

---
*Designed for Undergraduate Computer Science Education*
