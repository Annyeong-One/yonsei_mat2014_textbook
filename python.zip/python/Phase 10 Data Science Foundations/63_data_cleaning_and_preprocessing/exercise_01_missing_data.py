"""
EXERCISE 01: Missing Data Practice
===================================
Complete the TODOs to practice handling missing data.
"""

import pandas as pd
import numpy as np

# Dataset with missing values
data = {
    'product_id': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    'price': [19.99, np.nan, 29.99, 24.99, np.nan, 34.99, np.nan, 39.99, 44.99, np.nan],
    'rating': [4.5, 4.2, np.nan, 4.8, 4.1, np.nan, 4.6, np.nan, 4.9, 4.3],
    'stock': [100, 50, np.nan, 75, 120, np.nan, 90, 110, np.nan, 85],
    'category': ['Electronics', 'Books', 'Electronics', 'Books', 'Electronics',
                'Toys', 'Books', 'Electronics', 'Toys', 'Books']
}

df = pd.DataFrame(data)

print("Dataset with missing values:")
print(df)

# TODO 1: Calculate the percentage of missing values for each column
print("\n--- TODO 1: Missing Value Percentages ---")
# YOUR CODE HERE
missing_pct = None  # Replace with your calculation
print(missing_pct)

# TODO 2: Fill missing prices with the median price
print("\n--- TODO 2: Fill Price with Median ---")
# YOUR CODE HERE
df_price_filled = df.copy()
# Fill missing prices here

# TODO 3: Fill missing ratings with the mean rating for each category
print("\n--- TODO 3: Fill Rating by Category Mean ---")
# YOUR CODE HERE
df_rating_filled = df.copy()
# Use group-based imputation

# TODO 4: Use forward fill for missing stock values
print("\n--- TODO 4: Forward Fill Stock ---")
# YOUR CODE HERE
df_stock_filled = df.copy()
# Apply forward fill

# TODO 5: Create a complete cleaning pipeline
print("\n--- TODO 5: Complete Pipeline ---")
# YOUR CODE HERE
df_clean = df.copy()
# Apply all cleaning steps
# 1. Price: median
# 2. Rating: category mean
# 3. Stock: forward fill then median for remaining

print("\nFinal cleaned dataset:")
print(df_clean)
print("\nMissing values remaining:", df_clean.isnull().sum().sum())
