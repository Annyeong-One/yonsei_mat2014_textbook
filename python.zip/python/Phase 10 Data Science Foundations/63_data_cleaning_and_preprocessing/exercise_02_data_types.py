"""
EXERCISE 02: Data Types Practice
=================================
"""

import pandas as pd
import numpy as np

data = {
    'emp_id': ['E001', 'E002', 'E003', 'E004', 'E005'],
    'age': ['28', '35', 'forty-two', '29', '38'],
    'salary': ['55000', '65k', '72000', '48000', '82k'],
    'start_date': ['2020-01-15', '2019/06/20', '15-Mar-2021', '2022-11-01', 'Invalid'],
    'is_manager': ['Yes', '0', 'TRUE', 'No', '1']
}

df = pd.DataFrame(data)
print("Original data:")
print(df)
print("\nCurrent types:")
print(df.dtypes)

# TODO 1: Convert age to numeric (handle errors)
print("\n--- TODO 1: Convert Age ---")
# YOUR CODE HERE

# TODO 2: Convert salary (handle 'k' suffix)
print("\n--- TODO 2: Convert Salary ---")
# YOUR CODE HERE

# TODO 3: Convert start_date to datetime
print("\n--- TODO 3: Convert Date ---")
# YOUR CODE HERE

# TODO 4: Convert is_manager to boolean
print("\n--- TODO 4: Convert Boolean ---")
# YOUR CODE HERE

# TODO 5: Validate age range (18-100)
print("\n--- TODO 5: Validate Age ---")
# YOUR CODE HERE
