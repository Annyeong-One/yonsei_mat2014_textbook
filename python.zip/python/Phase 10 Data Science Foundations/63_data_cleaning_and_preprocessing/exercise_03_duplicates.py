"""
EXERCISE 03: Duplicates Practice
=================================
"""

import pandas as pd

data = {
    'order_id': [1, 2, 2, 3, 4, 5, 5, 6],
    'customer': ['Alice', 'Bob', 'Bob', 'Charlie', 'Alice', 'Diana', 'Diana', 'Eve'],
    'product': ['Laptop', 'Mouse', 'Mouse', 'Keyboard', 'Monitor', 'Headset', 'Headset', 'Webcam'],
    'quantity': [1, 2, 2, 1, 1, 3, 3, 1],
    'price': [1000, 25, 25, 75, 300, 50, 50, 80]
}

df = pd.DataFrame(data)
print("Dataset:")
print(df)

# TODO 1: Find exact duplicate rows
print("\n--- TODO 1: Find Exact Duplicates ---")
# YOUR CODE HERE

# TODO 2: Find duplicates by order_id
print("\n--- TODO 2: Duplicates by Order ID ---")
# YOUR CODE HERE

# TODO 3: Remove exact duplicates (keep first)
print("\n--- TODO 3: Remove Exact Duplicates ---")
# YOUR CODE HERE

# TODO 4: Check if customer has multiple different products
print("\n--- TODO 4: Customer Product Variety ---")
# YOUR CODE HERE
