"""
EXERCISE 04: Outliers Practice
===============================
"""

import pandas as pd
import numpy as np

np.random.seed(42)
data = np.concatenate([np.random.normal(100, 15, 45), [200, 210, -50, -40, 205]])
df = pd.DataFrame({'score': data})

print("Dataset statistics:")
print(df.describe())

# TODO 1: Detect outliers using Z-score (threshold=3)
print("\n--- TODO 1: Z-Score Outliers ---")
# YOUR CODE HERE

# TODO 2: Detect outliers using IQR method
print("\n--- TODO 2: IQR Outliers ---")
# YOUR CODE HERE

# TODO 3: Remove outliers using IQR method
print("\n--- TODO 3: Remove Outliers ---")
# YOUR CODE HERE

# TODO 4: Cap outliers to IQR bounds
print("\n--- TODO 4: Cap Outliers ---")
# YOUR CODE HERE
