"""
EXERCISE 05: Encoding Practice
===============================
"""

import pandas as pd

data = {
    'size': ['Small', 'Medium', 'Large', 'Small', 'Large'],
    'color': ['Red', 'Blue', 'Green', 'Red', 'Blue'],
    'grade': ['A', 'B', 'C', 'A', 'B'],
    'price': [10, 15, 20, 12, 18]
}

df = pd.DataFrame(data)
print("Original data:")
print(df)

# TODO 1: Create ordinal encoding for size (S=0, M=1, L=2)
print("\n--- TODO 1: Ordinal Encoding ---")
# YOUR CODE HERE

# TODO 2: Create one-hot encoding for color
print("\n--- TODO 2: One-Hot Encoding ---")
# YOUR CODE HERE

# TODO 3: Create target encoding for color (mean price)
print("\n--- TODO 3: Target Encoding ---")
# YOUR CODE HERE

# TODO 4: Create frequency encoding for grade
print("\n--- TODO 4: Frequency Encoding ---")
# YOUR CODE HERE
