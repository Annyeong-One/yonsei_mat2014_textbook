"""
EXERCISE 06: Complete Preprocessing Challenge
==============================================
Apply all learned techniques to clean this messy dataset!
"""

import pandas as pd
import numpy as np

np.random.seed(42)

# Messy real-world dataset
data = {
    'id': ['001', '002', '003', '002', '004', '005'],  # Has duplicate
    'age': ['25', 'thirty', '35', '30', np.nan, '45'],  # Mixed types + missing
    'salary': ['50k', '60000', '75k', '60000', '90000', np.nan],  # Format issues + missing
    'department': ['IT', 'hr', 'IT', 'HR', 'finance', 'it'],  # Case issues
    'rating': [4.5, 4.2, 8.5, 4.2, 4.8, 3.9],  # Has outlier (8.5)
    'experience': ['2', '5', '8', '5', '12', '15']
}

df = pd.DataFrame(data)
print("Original messy dataset:")
print(df)

# CHALLENGE: Complete ALL preprocessing steps
print("\n" + "="*80)
print("CHALLENGE: Clean This Dataset!")
print("="*80)

# Step 1: Remove duplicates
# YOUR CODE HERE

# Step 2: Fix data types
# YOUR CODE HERE

# Step 3: Standardize categories (department)
# YOUR CODE HERE

# Step 4: Handle outliers (rating should be 0-5)
# YOUR CODE HERE

# Step 5: Handle missing values
# YOUR CODE HERE

# Step 6: Create a categorical encoding for department
# YOUR CODE HERE

# Print final cleaned dataset
print("\nFinal cleaned dataset:")
# print(df_final)
print("\nValidation:")
# print("- Duplicates:", df_final.duplicated().sum())
# print("- Missing:", df_final.isnull().sum().sum())
# print("- Data types valid:", "Check manually")
