"""
SOLUTION 01: Missing Data Practice
===================================
"""

import pandas as pd
import numpy as np

data = {
    'product_id': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    'price': [19.99, np.nan, 29.99, 24.99, np.nan, 34.99, np.nan, 39.99, 44.99, np.nan],
    'rating': [4.5, 4.2, np.nan, 4.8, 4.1, np.nan, 4.6, np.nan, 4.9, 4.3],
    'stock': [100, 50, np.nan, 75, 120, np.nan, 90, 110, np.nan, 85],
    'category': ['Electronics', 'Books', 'Electronics', 'Books', 'Electronics',
                'Toys', 'Books', 'Electronics', 'Toys', 'Books']
}
df = pd.DataFrame(data)

print("="*80)
print("SOLUTION 01: Missing Data")
print("="*80)

# SOLUTION 1: Missing percentages
print("\n--- Solution 1: Missing Value Percentages ---")
missing_pct = (df.isnull().sum() / len(df) * 100).round(2)
print(missing_pct)

# SOLUTION 2: Median imputation for price
print("\n--- Solution 2: Fill Price with Median ---")
df_price_filled = df.copy()
median_price = df_price_filled['price'].median()
df_price_filled['price'] = df_price_filled['price'].fillna(median_price)
print(f"Filled {(df['price'].isnull().sum())} missing prices with median: {median_price}")
print(df_price_filled['price'])

# SOLUTION 3: Group-based imputation for rating
print("\n--- Solution 3: Fill Rating by Category Mean ---")
df_rating_filled = df.copy()
df_rating_filled['rating'] = df_rating_filled.groupby('category')['rating'].transform(
    lambda x: x.fillna(x.mean())
)
print("Filled ratings with category means:")
print(df_rating_filled[['category', 'rating']])

# SOLUTION 4: Forward fill for stock
print("\n--- Solution 4: Forward Fill Stock ---")
df_stock_filled = df.copy()
df_stock_filled['stock'] = df_stock_filled['stock'].fillna(method='ffill')
print("Stock after forward fill:")
print(df_stock_filled['stock'])

# SOLUTION 5: Complete pipeline
print("\n--- Solution 5: Complete Pipeline ---")
df_clean = df.copy()

# Price: median
df_clean['price'] = df_clean['price'].fillna(df_clean['price'].median())

# Rating: category mean
df_clean['rating'] = df_clean.groupby('category')['rating'].transform(
    lambda x: x.fillna(x.mean())
)

# Stock: forward fill then median for any remaining
df_clean['stock'] = df_clean['stock'].fillna(method='ffill')
df_clean['stock'] = df_clean['stock'].fillna(df_clean['stock'].median())

print("Final cleaned dataset:")
print(df_clean)
print("\nMissing values remaining:", df_clean.isnull().sum().sum())
print("\n✓ All missing values handled!")
print("="*80)
