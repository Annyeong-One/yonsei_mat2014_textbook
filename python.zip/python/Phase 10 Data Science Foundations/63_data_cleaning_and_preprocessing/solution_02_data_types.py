"""
SOLUTION 02: Data Types Practice
=================================
"""

import pandas as pd
import numpy as np

data = {
    'emp_id': ['E001', 'E002', 'E003', 'E004', 'E005'],
    'age': ['28', '35', 'forty-two', '29', '38'],
    'salary': ['55000', '65k', '72000', '48000', '82k'],
    'start_date': ['2020-01-15', '2019/06/20', '15-Mar-2021', '2022-11-01', 'Invalid'],
    'is_manager': ['Yes', '0', 'TRUE', 'No', '1']
}
df = pd.DataFrame(data)

print("="*80)
print("SOLUTION 02: Data Types")
print("="*80)

# SOLUTION 1: Convert age
print("\n--- Solution 1: Convert Age ---")
df['age'] = pd.to_numeric(df['age'], errors='coerce')
print(f"Age type: {df['age'].dtype}")
print(df['age'])

# SOLUTION 2: Convert salary
print("\n--- Solution 2: Convert Salary ---")
df['salary'] = df['salary'].str.replace('k', '000', regex=False)
df['salary'] = pd.to_numeric(df['salary'], errors='coerce')
print(f"Salary type: {df['salary'].dtype}")
print(df['salary'])

# SOLUTION 3: Convert date
print("\n--- Solution 3: Convert Date ---")
df['start_date'] = pd.to_datetime(df['start_date'], errors='coerce')
print(f"Date type: {df['start_date'].dtype}")
print(df['start_date'])

# SOLUTION 4: Convert boolean
print("\n--- Solution 4: Convert Boolean ---")
def to_bool(val):
    if pd.isna(val): return np.nan
    str_val = str(val).lower().strip()
    return str_val in ['yes', '1', 'true', 't', 'y']

df['is_manager'] = df['is_manager'].apply(to_bool)
print(f"Boolean type: {df['is_manager'].dtype}")
print(df['is_manager'])

# SOLUTION 5: Validate age
print("\n--- Solution 5: Validate Age ---")
invalid_ages = df[(df['age'] < 18) | (df['age'] > 100)]
print(f"Invalid ages found: {len(invalid_ages)}")
if len(invalid_ages) > 0:
    print(invalid_ages[['emp_id', 'age']])
    df.loc[(df['age'] < 18) | (df['age'] > 100), 'age'] = np.nan
    print("✓ Invalid ages set to NaN")

print("\nFinal cleaned data:")
print(df)
print("="*80)
