"""
SOLUTION 03: Duplicates Practice
=================================
"""

import pandas as pd

data = {
    'order_id': [1, 2, 2, 3, 4, 5, 5, 6],
    'customer': ['Alice', 'Bob', 'Bob', 'Charlie', 'Alice', 'Diana', 'Diana', 'Eve'],
    'product': ['Laptop', 'Mouse', 'Mouse', 'Keyboard', 'Monitor', 'Headset', 'Headset', 'Webcam'],
    'quantity': [1, 2, 2, 1, 1, 3, 3, 1],
    'price': [1000, 25, 25, 75, 300, 50, 50, 80]
}
df = pd.DataFrame(data)

print("="*80)
print("SOLUTION 03: Duplicates")
print("="*80)

# SOLUTION 1: Exact duplicates
print("\n--- Solution 1: Find Exact Duplicates ---")
exact_dups = df[df.duplicated(keep=False)]
print(f"Found {len(exact_dups)} exact duplicate rows:")
print(exact_dups)

# SOLUTION 2: Duplicates by order_id
print("\n--- Solution 2: Duplicates by Order ID ---")
order_dups = df[df.duplicated(subset=['order_id'], keep=False)]
print(f"Found {len(order_dups)} rows with duplicate order_id:")
print(order_dups.sort_values('order_id'))

# SOLUTION 3: Remove exact duplicates
print("\n--- Solution 3: Remove Exact Duplicates ---")
df_clean = df.drop_duplicates()
print(f"Removed: {len(df)} → {len(df_clean)} rows")
print(df_clean)

# SOLUTION 4: Customer product variety
print("\n--- Solution 4: Customer Product Variety ---")
customer_products = df_clean.groupby('customer')['product'].nunique()
print("Products per customer:")
print(customer_products)

print("\n✓ Duplicate handling complete!")
print("="*80)
