"""
SOLUTION 04: Outliers Practice
===============================
"""

import pandas as pd
import numpy as np

np.random.seed(42)
data = np.concatenate([np.random.normal(100, 15, 45), [200, 210, -50, -40, 205]])
df = pd.DataFrame({'score': data})

print("="*80)
print("SOLUTION 04: Outliers")
print("="*80)

print("\nDataset statistics:")
print(df.describe())

# SOLUTION 1: Z-score outliers
print("\n--- Solution 1: Z-Score Outliers ---")
z_scores = np.abs((df['score'] - df['score'].mean()) / df['score'].std())
outliers_z = df[z_scores > 3]
print(f"Outliers (|z| > 3): {len(outliers_z)} found")
print(outliers_z)

# SOLUTION 2: IQR outliers
print("\n--- Solution 2: IQR Outliers ---")
Q1 = df['score'].quantile(0.25)
Q3 = df['score'].quantile(0.75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
outliers_iqr = df[(df['score'] < lower_bound) | (df['score'] > upper_bound)]
print(f"IQR bounds: [{lower_bound:.2f}, {upper_bound:.2f}]")
print(f"Outliers: {len(outliers_iqr)} found")
print(outliers_iqr)

# SOLUTION 3: Remove outliers
print("\n--- Solution 3: Remove Outliers ---")
df_removed = df[(df['score'] >= lower_bound) & (df['score'] <= upper_bound)]
print(f"Removed: {len(df)} → {len(df_removed)} rows")
print(f"New mean: {df_removed['score'].mean():.2f}")

# SOLUTION 4: Cap outliers
print("\n--- Solution 4: Cap Outliers ---")
df_capped = df.copy()
df_capped['score'] = df_capped['score'].clip(lower=lower_bound, upper=upper_bound)
print(f"Capped to [{lower_bound:.2f}, {upper_bound:.2f}]")
print(f"New mean: {df_capped['score'].mean():.2f}")
print("\n✓ Outlier handling complete!")
print("="*80)
