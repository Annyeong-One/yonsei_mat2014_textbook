"""
SOLUTION 05: Encoding Practice
===============================
"""

import pandas as pd

data = {
    'size': ['Small', 'Medium', 'Large', 'Small', 'Large'],
    'color': ['Red', 'Blue', 'Green', 'Red', 'Blue'],
    'grade': ['A', 'B', 'C', 'A', 'B'],
    'price': [10, 15, 20, 12, 18]
}
df = pd.DataFrame(data)

print("="*80)
print("SOLUTION 05: Encoding")
print("="*80)

print("\nOriginal data:")
print(df)

# SOLUTION 1: Ordinal encoding
print("\n--- Solution 1: Ordinal Encoding ---")
size_order = {'Small': 0, 'Medium': 1, 'Large': 2}
df['size_ordinal'] = df['size'].map(size_order)
print(df[['size', 'size_ordinal']])

# SOLUTION 2: One-hot encoding
print("\n--- Solution 2: One-Hot Encoding ---")
df_onehot = pd.get_dummies(df, columns=['color'], prefix='color')
print(df_onehot)

# SOLUTION 3: Target encoding
print("\n--- Solution 3: Target Encoding ---")
color_price_mean = df.groupby('color')['price'].mean()
df['color_target'] = df['color'].map(color_price_mean)
print(df[['color', 'price', 'color_target']])

# SOLUTION 4: Frequency encoding
print("\n--- Solution 4: Frequency Encoding ---")
grade_freq = df['grade'].value_counts() / len(df)
df['grade_freq'] = df['grade'].map(grade_freq)
print(df[['grade', 'grade_freq']])

print("\n✓ Encoding complete!")
print("="*80)
