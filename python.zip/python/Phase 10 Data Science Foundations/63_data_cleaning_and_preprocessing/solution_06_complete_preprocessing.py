"""
SOLUTION 06: Complete Preprocessing Challenge
==============================================
"""

import pandas as pd
import numpy as np

np.random.seed(42)

data = {
    'id': ['001', '002', '003', '002', '004', '005'],
    'age': ['25', 'thirty', '35', '30', np.nan, '45'],
    'salary': ['50k', '60000', '75k', '60000', '90000', np.nan],
    'department': ['IT', 'hr', 'IT', 'HR', 'finance', 'it'],
    'rating': [4.5, 4.2, 8.5, 4.2, 4.8, 3.9],
    'experience': ['2', '5', '8', '5', '12', '15']
}
df = pd.DataFrame(data)

print("="*80)
print("SOLUTION 06: Complete Preprocessing")
print("="*80)

print("\nOriginal messy dataset:")
print(df)

# Step 1: Remove duplicates
print("\n--- Step 1: Remove Duplicates ---")
print(f"Before: {len(df)} rows")
df = df.drop_duplicates()
print(f"After: {len(df)} rows")

# Step 2: Fix data types
print("\n--- Step 2: Fix Data Types ---")
df['age'] = pd.to_numeric(df['age'], errors='coerce')
df['salary'] = df['salary'].str.replace('k', '000', regex=False)
df['salary'] = pd.to_numeric(df['salary'], errors='coerce')
df['experience'] = pd.to_numeric(df['experience'])
print("✓ Converted to appropriate types")

# Step 3: Standardize categories
print("\n--- Step 3: Standardize Categories ---")
df['department'] = df['department'].str.upper()
print(f"✓ Standardized department: {df['department'].unique()}")

# Step 4: Handle outliers
print("\n--- Step 4: Handle Outliers ---")
print(f"Rating range: [{df['rating'].min()}, {df['rating'].max()}]")
df.loc[(df['rating'] < 0) | (df['rating'] > 5), 'rating'] = np.nan
print("✓ Set invalid ratings to NaN")

# Step 5: Handle missing values
print("\n--- Step 5: Handle Missing Values ---")
print("Missing before:")
print(df.isnull().sum())

df['age'] = df['age'].fillna(df['age'].median())
df['salary'] = df['salary'].fillna(df['salary'].median())
df['rating'] = df['rating'].fillna(df['rating'].mean())

print("\nMissing after:")
print(df.isnull().sum())

# Step 6: Encoding
print("\n--- Step 6: Encode Department ---")
df_encoded = pd.get_dummies(df, columns=['department'], prefix='dept')
print(f"✓ One-hot encoded department")

print("\nFinal cleaned dataset:")
print(df_encoded)

print("\n" + "="*80)
print("VALIDATION")
print("="*80)
print(f"Duplicates: {df_encoded.duplicated().sum()}")
print(f"Missing values: {df_encoded.isnull().sum().sum()}")
print(f"Rows: {len(df_encoded)}")
print(f"Columns: {len(df_encoded.columns)}")
print("\n✓ COMPLETE PREPROCESSING SUCCESS!")
print("="*80)
