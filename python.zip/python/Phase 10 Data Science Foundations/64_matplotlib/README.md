# Matplotlib Complete Course for Undergraduates
## Comprehensive Python Plotting Tutorial

### Course Overview
This comprehensive matplotlib course is designed for undergraduate computer science students in a one-year Python programming course. The curriculum progresses systematically from beginner to advanced topics with heavily commented code, detailed explanations, and practical exercises.

---

## 📚 Course Structure

### **01_beginner/** - Foundational Concepts
Introduction to matplotlib basics and core concepts.

#### Files:
1. **01_introduction_and_first_plot.py** (30 min)
   - What is matplotlib and why use it
   - Importing matplotlib.pyplot
   - Creating your first plots
   - Basic line plots with plot()
   - Adding labels, titles, and legends
   - Saving figures
   - Line styles, colors, and markers

2. **02_two_plotting_styles.py** (45 min)
   - **MATLAB-style** (pyplot interface): `plt.plot()`, `plt.xlabel()`, etc.
   - **OOP-style** (object-oriented): `fig, ax = plt.subplots()`
   - Understanding Figure and Axes objects
   - **Critical: Method name differences**
     - `plt.xlabel()` → `ax.set_xlabel()`
     - `plt.ylabel()` → `ax.set_ylabel()`
     - `plt.title()` → `ax.set_title()`
   - When to use each style
   - Converting between styles

3. **03_subplots_and_axes_array.py** (60 min)
   - Creating multiple subplots with `plt.subplots(nrows, ncols)`
   - **Understanding axes as a NumPy array**
   - **Counter-intuitive shape: axes[row, col]**
   - Why row comes before column (matrix convention)
   - Visual examples of indexing
   - Single plot vs 1D array vs 2D array
   - Using `flatten()` and `ravel()` for easy iteration
   - The `squeeze` parameter

**Estimated Time: 2.5 hours**

---

### **02_intermediate/** - Mastering Core Functions

#### Files:
1. **01_complete_guide_to_plot.py** (90 min)
   - **Comprehensive plt.plot() documentation**
   - Complete function signature and parameters
   - Format strings: `'[marker][line][color]'`
   - All line properties:
     - color, linestyle, linewidth
     - marker, markersize, markerfacecolor, markeredgecolor
     - alpha (transparency)
   - Multiple ways to call plot()
   - Using Line2D return objects
   - Combining format strings with keyword arguments
   - Best practices for multiple lines
   - Publication-quality plotting example

2. **02_complete_guide_to_hist.py** (90 min)
   - **Comprehensive plt.hist() documentation**
   - Complete function signature and return values
   - **Critical: Understanding return values**
     - `n, bins, patches = plt.hist(...)`
     - n: histogram values (counts or densities)
     - bins: bin edges (length = n + 1)
     - patches: bar objects
   - **bins parameter - Two modes:**
     - `bins=int`: Number of equal-width bins
     - `bins=array`: Explicit bin edges (can be unequal!)
   - **Understanding bin edges and boundaries**
     - bins[i] to bins[i+1] defines bin i
     - Bin centers vs bin edges
   - **density parameter - THE CRITICAL DIFFERENCE:**
     - `density=False`: Y-axis shows counts
     - `density=True`: Y-axis shows probability density
     - Formula: density[i] = count[i] / (N × bin_width[i])
     - Total area = 1.0 with density=True
   - When to use density=True (overlaying PDFs)
   - Overlaying theoretical distributions
   - Color-coding bars by frequency
   - Cumulative histograms

3. **03_advanced_customization.py** (60 min)
   - Axes limits and ranges
   - Customizing ticks and tick labels
   - Grid customization (major/minor, styles)
   - Spine customization (hide, reposition, style)
   - Adding text and annotations
   - Advanced legend customization
   - Using colormaps for multiple lines
   - Figure size and DPI
   - Publication-quality examples

**Estimated Time: 4 hours**

---

### **03_advanced/** - Complex Layouts and Techniques

#### Files:
1. **01_complex_layouts_gridspec.py** (90 min)
   - Review of basic subplots
   - Sharing axes (`sharex`, `sharey`)
   - **Introduction to GridSpec**
   - Creating subplots with different sizes
   - GridSpec indexing: `gs[row_start:row_end, col_start:col_end]`
   - Custom spacing control (wspace, hspace)
   - Dashboard-style layouts
   - Nested GridSpecs (grids within grids)
   - Alternative: `subplot2grid()`
   - Width and height ratios
   - Real-world scientific figure examples

**Estimated Time: 1.5 hours**

---

### **04_exercises/** - Practice Problems

#### Files:
1. **exercise_01_basic.py**
   - 10 exercises testing beginner concepts
   - MATLAB vs OOP style
   - Method name conversions
   - Axes array indexing
   - Line customization
   - Format strings
   - Debugging common errors
   - Creative challenge problem

2. **exercise_02_histograms.py**
   - 10 exercises focused on histograms
   - Understanding return values
   - bins parameter (int vs array)
   - density parameter
   - Overlaying distributions
   - Color-coding by frequency
   - Manual density calculations
   - Cumulative histograms
   - Multi-distribution comparisons
   - Dashboard challenge

**Estimated Time: 3-4 hours for completion**

---

### **05_solutions/** - Complete Solutions

#### Files:
1. **solution_01_basic.py**
   - Detailed solutions to all basic exercises
   - Explanatory comments
   - Alternative approaches where applicable

2. **solution_02_histograms.py**
   - Detailed solutions to histogram exercises
   - Verification code included
   - Best practices demonstrated

---

## 🎯 Key Learning Objectives

By completing this course, students will:

### Core Competencies:
1. ✅ Master both MATLAB-style and OOP-style plotting interfaces
2. ✅ Understand the critical differences in method names between styles
3. ✅ Navigate the axes array structure confidently (including the counter-intuitive [row, col] indexing)
4. ✅ Use `plt.plot()` with complete mastery of all parameters
5. ✅ Use `plt.hist()` with deep understanding of:
   - Return values (n, bins, patches)
   - bins parameter (integer vs array)
   - density parameter (counts vs probability density)
   - Bin edges and boundaries
6. ✅ Create publication-quality figures
7. ✅ Build complex multi-panel layouts
8. ✅ Debug common matplotlib errors

---

## 📋 Prerequisites

### Required Knowledge:
- Python basics (variables, functions, loops, conditionals)
- Basic NumPy (arrays, array indexing, linspace, array operations)
- Understanding of basic statistics (mean, standard deviation)
- Familiarity with probability concepts (for density histograms)

### Required Libraries:
```python
import matplotlib.pyplot as plt
import numpy as np
```

### Installation:
```bash
pip install matplotlib numpy
```

---

## 🚀 How to Use This Course

### For Students:

1. **Follow Sequential Order**
   - Start with `01_beginner/`
   - Progress through each file in numerical order
   - Don't skip ahead until you understand current material

2. **Active Learning**
   - Read all comments carefully
   - Run each code block
   - Experiment by modifying parameters
   - Try to predict output before running

3. **Practice Exercises**
   - Complete exercises without looking at solutions
   - Test your code thoroughly
   - Only check solutions after attempting
   - Understand why the solution works

4. **Key Concepts to Master**
   - The two plotting styles and when to use each
   - Method name differences (`xlabel` vs `set_xlabel`)
   - Axes array indexing (`axes[row, col]`)
   - plot() parameters and customization
   - hist() return values and parameters
   - density vs count in histograms

### For Instructors:

1. **Course Integration**
   - Each file is a self-contained lesson
   - Estimated times provided for planning
   - Can be assigned as homework or lab work
   - Exercises suitable for assessments

2. **Teaching Approach**
   - Demonstrate concepts live
   - Have students run code along with you
   - Emphasize critical concepts marked in comments
   - Use exercises for skill verification

3. **Assessment Options**
   - Use exercise files for homework
   - Create quizzes based on key concepts
   - Assign creative plotting projects
   - Assess understanding of return values

---

## 📖 Critical Concepts Emphasized

### 1. Two Plotting Styles
```python
# MATLAB-style
plt.plot(x, y)
plt.xlabel('x')
plt.title('My Plot')

# OOP-style (RECOMMENDED for complex plots)
fig, ax = plt.subplots()
ax.plot(x, y)
ax.set_xlabel('x')  # Note: set_xlabel!
ax.set_title('My Plot')  # Note: set_title!
```

### 2. Axes Array Shape (Counter-intuitive!)
```python
fig, axes = plt.subplots(2, 3)  # 2 rows, 3 columns
print(axes.shape)  # (2, 3)

# Access: axes[row, col]
axes[0, 0]  # Top-left
axes[0, 2]  # Top-right
axes[1, 0]  # Bottom-left
axes[1, 2]  # Bottom-right
```

### 3. Histogram Return Values
```python
n, bins, patches = plt.hist(data, bins=20)
# n: array of counts/densities (length = 20)
# bins: array of bin edges (length = 21)
# patches: list of bar objects
```

### 4. Density vs Counts
```python
# Counts (frequency)
plt.hist(data, density=False)  # Y-axis = number of points

# Probability density
plt.hist(data, density=True)   # Y-axis = probability density
                                # Total AREA = 1.0
```

### 5. bins Parameter
```python
# Number of bins
plt.hist(data, bins=20)  # 20 equal-width bins

# Explicit edges
plt.hist(data, bins=[0, 1, 2, 5, 10])  # Variable-width bins
```

---

## 💡 Tips for Success

1. **Code Along**: Don't just read, type and run the code yourself
2. **Experiment**: Modify parameters to see what happens
3. **Visualize**: Draw diagrams for axes indexing
4. **Document**: Add your own comments to remember key points
5. **Practice**: Complete all exercises before moving forward
6. **Reference**: Keep this course as a reference guide

---

## 🔍 Quick Reference

### Common Method Name Differences
| MATLAB-style | OOP-style |
|-------------|-----------|
| `plt.xlabel()` | `ax.set_xlabel()` |
| `plt.ylabel()` | `ax.set_ylabel()` |
| `plt.title()` | `ax.set_title()` |
| `plt.xlim()` | `ax.set_xlim()` |
| `plt.ylim()` | `ax.set_ylim()` |
| `plt.xticks()` | `ax.set_xticks()` |
| `plt.yticks()` | `ax.set_yticks()` |
| `plt.legend()` | `ax.legend()` *(same!)* |
| `plt.grid()` | `ax.grid()` *(same!)* |
| `plt.plot()` | `ax.plot()` *(same!)* |

### Essential plot() Parameters
- `color` / `c`: line color
- `linestyle` / `ls`: '-', '--', '-.', ':'
- `linewidth` / `lw`: line thickness
- `marker`: marker style ('o', 's', '^', etc.)
- `markersize` / `ms`: marker size
- `alpha`: transparency (0-1)
- `label`: for legend

### Essential hist() Parameters
- `bins`: int or array of edges
- `density`: False (counts) or True (probability density)
- `cumulative`: False or True
- `alpha`: transparency
- `edgecolor`: color of bar edges

---

## 📊 Course Statistics

- **Total Files**: 13 tutorial files + 2 exercise files + 2 solution files
- **Total Concepts**: 50+ key concepts
- **Code Examples**: 100+ fully commented examples
- **Exercises**: 20 practice problems
- **Estimated Study Time**: 12-15 hours for complete mastery

---

## ✨ What Makes This Course Unique

1. **Heavily Commented**: Every line explained
2. **Progressive Difficulty**: Builds naturally from simple to complex
3. **Real-World Focus**: Practical examples and publication-quality plots
4. **Critical Concepts Emphasized**: Key points clearly marked
5. **Complete Coverage**: Both plot() and hist() explained exhaustively
6. **Two Styles**: Both MATLAB and OOP styles thoroughly covered
7. **Practical Exercises**: Hands-on practice with solutions
8. **Reference Quality**: Can be used as documentation

---

## 📝 Course Philosophy

This course is built on three principles:

1. **Understanding Over Memorization**: Understand why, not just how
2. **Practice Makes Perfect**: Theory + exercises = mastery
3. **Reference Quality**: Serve as future documentation

---

## 🎓 Next Steps After Completion

After mastering this course, students can explore:
- 3D plotting with mplot3d
- Animation with matplotlib.animation
- Interactive plots with widgets
- Seaborn for statistical visualization
- Plotly for interactive web-based plots
- Specialized plot types (violin, box, contour, etc.)

---

## 📞 Additional Resources

- **Matplotlib Official Documentation**: https://matplotlib.org/
- **Matplotlib Gallery**: https://matplotlib.org/stable/gallery/
- **NumPy Documentation**: https://numpy.org/doc/

---

## 📄 License and Usage

This educational material is designed for:
- Academic instruction
- Self-study
- Reference documentation
- Classroom use

Feel free to:
- Use in courses
- Modify for your needs
- Share with students
- Adapt examples

---

## 🙏 Acknowledgments

Developed for undergraduate computer science education with focus on:
- Clarity and completeness
- Progressive learning
- Practical applications
- Professional standards

---

**Happy Plotting! 📊🎨**

*Version 1.0 - Complete Matplotlib Course*
*Designed for undergraduate CS education*
