"""
Tutorial 07: Multi-Plot Grids
FacetGrid, PairGrid, JointGrid for complex layouts
Level: Intermediate
"""
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

sns.set_style("whitegrid")
tips = sns.load_dataset('tips')
iris = sns.load_dataset('iris')

# FacetGrid - create grid of plots by categories
g = sns.FacetGrid(tips, col='time', row='sex', height=4, aspect=1.2)
g.map(sns.scatterplot, 'total_bill', 'tip')
g.add_legend()
g.set_axis_labels("Total Bill ($)", "Tip ($)")
g.set_titles("Sex: {row_name} | Time: {col_name}")
plt.show()

# PairGrid - pairwise relationships
g = sns.PairGrid(iris, hue='species', height=2.5)
g.map_upper(sns.scatterplot)
g.map_lower(sns.kdeplot)
g.map_diag(sns.histplot)
g.add_legend()
plt.show()

# JointGrid - joint and marginal distributions
g = sns.JointGrid(data=tips, x='total_bill', y='tip', height=8)
g.plot_joint(sns.scatterplot)
g.plot_marginals(sns.histplot)
plt.show()

print("Tutorial 07 demonstrates multi-plot grid systems")
print("Key classes: FacetGrid, PairGrid, JointGrid")
