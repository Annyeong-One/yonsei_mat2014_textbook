"""
Tutorial 09: Advanced Styling and Themes
Color palettes, custom themes, publication-quality plots
Level: Advanced
"""
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd

tips = sns.load_dataset('tips')

# Built-in themes
styles = ['darkgrid', 'whitegrid', 'dark', 'white', 'ticks']
fig, axes = plt.subplots(1, 5, figsize=(20, 4))
for i, style in enumerate(styles):
    sns.set_style(style)
    sns.scatterplot(data=tips, x='total_bill', y='tip', ax=axes[i])
    axes[i].set_title(f"Style: {style}")
plt.tight_layout()
plt.show()

# Color palettes
palettes = ['deep', 'muted', 'pastel', 'bright', 'dark', 'colorblind']
fig, axes = plt.subplots(2, 3, figsize=(15, 8))
axes = axes.flatten()
for i, palette in enumerate(palettes):
    sns.set_palette(palette)
    sns.barplot(data=tips, x='day', y='tip', ax=axes[i])
    axes[i].set_title(f"Palette: {palette}")
plt.tight_layout()
plt.show()

# Custom color palette
custom_palette = ["#FF6B6B", "#4ECDC4", "#45B7D1", "#FFA07A"]
plt.figure(figsize=(10, 6))
sns.barplot(data=tips, x='day', y='tip', palette=custom_palette)
plt.title('Custom Color Palette', fontsize=14, fontweight='bold')
plt.show()

# Context scaling
contexts = ['paper', 'notebook', 'talk', 'poster']
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
axes = axes.flatten()
for i, context in enumerate(contexts):
    sns.set_context(context)
    sns.scatterplot(data=tips, x='total_bill', y='tip', ax=axes[i])
    axes[i].set_title(f"Context: {context}")
plt.tight_layout()
plt.show()

print("Tutorial 09 demonstrates advanced styling techniques")
print("Key functions: set_style(), set_palette(), set_context()")
