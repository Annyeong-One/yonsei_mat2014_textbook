"""
Tutorial 10: Complex Visualizations
Combining techniques for publication-quality figures
Level: Advanced
"""
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

sns.set_style("whitegrid")
sns.set_context("notebook")

tips = sns.load_dataset('tips')
iris = sns.load_dataset('iris')

# Complex multi-panel figure
fig = plt.figure(figsize=(16, 10))
gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)

# Main scatter plot
ax1 = fig.add_subplot(gs[0:2, 0:2])
sns.scatterplot(data=tips, x='total_bill', y='tip', hue='time', style='sex', s=100, ax=ax1)
ax1.set_title('Main: Tips vs Total Bill', fontsize=14, fontweight='bold')

# Marginal distributions
ax2 = fig.add_subplot(gs[0:2, 2])
sns.violinplot(data=tips, y='tip', ax=ax2)
ax2.set_title('Tip Distribution')

ax3 = fig.add_subplot(gs[2, 0:2])
sns.histplot(data=tips, x='total_bill', bins=20, ax=ax3)
ax3.set_title('Bill Distribution')

# Summary statistics
ax4 = fig.add_subplot(gs[2, 2])
summary = tips.groupby('day')['tip'].mean()
ax4.bar(range(len(summary)), summary.values, color='steelblue')
ax4.set_xticks(range(len(summary)))
ax4.set_xticklabels(summary.index, rotation=45)
ax4.set_title('Avg Tip by Day')

plt.suptitle('Comprehensive Analysis Dashboard', fontsize=16, fontweight='bold', y=0.995)
plt.show()

# Faceted analysis with multiple plot types
g = sns.FacetGrid(tips, col='time', row='sex', height=4, aspect=1.2)
g.map_dataframe(sns.scatterplot, x='total_bill', y='tip')
g.map_dataframe(sns.regplot, x='total_bill', y='tip', scatter=False, color='red')
g.set_axis_labels("Total Bill ($)", "Tip ($)")
g.set_titles("Sex: {row_name} | Time: {col_name}")
g.add_legend()
plt.show()

print("Tutorial 10 demonstrates complex visualization techniques")
print("Combine multiple skills for publication-quality figures")
