"""
Advanced Exercises - Tutorials 08-10
Statistical Estimation, Advanced Styling, Complex Visualizations
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

print("="*80)
print("ADVANCED EXERCISES")
print("="*80)

# Exercise 1: Bootstrap Confidence Intervals
print("\nEXERCISE 1: Bootstrap Confidence Intervals")
print("-" * 80)
"""
1. Create synthetic data: two groups with different means
2. Use barplot to show means with 95% CI
3. Use pointplot to show the same with connecting lines
4. Compare which visualization is clearer
"""

# YOUR CODE HERE

# Exercise 2: Custom Theme Creation
print("\nEXERCISE 2: Custom Theme Creation")
print("-" * 80)
"""
1. Create a custom style dictionary
2. Apply it using sns.set_theme()
3. Create a complex plot using this theme
4. Save with publication-quality settings
"""

# YOUR CODE HERE

# Exercise 3: Comprehensive Dashboard
print("\nEXERCISE 3: Comprehensive Dashboard")
print("-" * 80)
"""
Create a publication-quality dashboard with:
1. Main plot: large scatter with regression
2. Top marginal: histogram
3. Right marginal: KDE
4. Bottom: summary statistics as bar plot
5. Professional styling throughout
"""

# YOUR CODE HERE

print("\n" + "="*80)
print("Check solutions_advanced.py for answers")
