"""
Beginner Exercises - Tutorials 01-03
Seaborn Basics, Basic Plots, Distribution Plots

Instructions: Complete each exercise without looking at solutions first.
Test your code after each exercise to ensure it works.
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Set up styling
sns.set_style("whitegrid")
sns.set_context("notebook")

print("="*80)
print("BEGINNER EXERCISES - Seaborn Fundamentals")
print("="*80)

# =============================================================================
# EXERCISE 1: Loading and Exploring Data
# =============================================================================
print("\nEXERCISE 1: Loading and Exploring Data")
print("-" * 80)
"""
Tasks:
1. Load the 'penguins' dataset using sns.load_dataset()
2. Print the first 10 rows
3. Print the column names and their data types
4. Print basic statistics using .describe()
5. How many unique species are in the dataset?
6. What are the names of these species?
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 2: Basic Scatter Plot
# =============================================================================
print("\nEXERCISE 2: Basic Scatter Plot")
print("-" * 80)
"""
Using the penguins dataset:
1. Create a scatter plot with bill_length_mm on x-axis and bill_depth_mm on y-axis
2. Add appropriate axis labels
3. Add a descriptive title
4. What pattern do you observe in the data?
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 3: Scatter Plot with Color
# =============================================================================
print("\nEXERCISE 3: Scatter Plot with Color")
print("-" * 80)
"""
Using the penguins dataset:
1. Create a scatter plot of flipper_length_mm vs body_mass_g
2. Color the points by 'species'
3. Add appropriate labels and title
4. Include a legend
5. Save the plot as 'penguin_scatter.png' with dpi=300
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 4: Line Plot
# =============================================================================
print("\nEXERCISE 4: Line Plot")
print("-" * 80)
"""
Using the 'flights' dataset:
1. Load the flights dataset
2. Create a line plot showing passengers over year
3. Show separate lines for just three months: 'Jan', 'Jun', 'Dec'
4. Add markers to the lines
5. Include appropriate labels, title, and legend
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 5: Bar Plot Comparison
# =============================================================================
print("\nEXERCISE 5: Bar Plot Comparison")
print("-" * 80)
"""
Using the 'tips' dataset:
1. Load the tips dataset
2. Create a bar plot showing average total_bill by day
3. Add grouping by 'time' (Lunch/Dinner)
4. Make it a horizontal bar plot
5. Customize the colors using a Seaborn palette of your choice
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 6: Distribution Analysis
# =============================================================================
print("\nEXERCISE 6: Distribution Analysis")
print("-" * 80)
"""
Using the 'diamonds' dataset (or 'tips' if diamonds not available):
1. Load the dataset
2. Create a histogram of a continuous variable of your choice
3. Add a KDE overlay to the histogram
4. Describe the shape of the distribution (symmetric, skewed, bimodal?)
5. Add appropriate title and labels
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 7: Comparing Distributions
# =============================================================================
print("\nEXERCISE 7: Comparing Distributions")
print("-" * 80)
"""
Using the 'penguins' dataset:
1. Create overlaid KDE plots showing body_mass_g for each species
2. Use different colors for each species
3. Fill the areas under the curves with transparency
4. Add a legend
5. Which species tends to be heaviest?
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 8: Multi-Plot Grid
# =============================================================================
print("\nEXERCISE 8: Multi-Plot Grid")
print("-" * 80)
"""
Using the 'tips' dataset:
1. Create a 2x2 grid of subplots
2. Plot 1 (top-left): Scatter plot of total_bill vs tip
3. Plot 2 (top-right): Bar plot of average tip by day
4. Plot 3 (bottom-left): Count plot of customers by time
5. Plot 4 (bottom-right): Your choice of any plot!
6. Add a main title for the entire figure
7. Ensure proper spacing between plots
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 9: Displot Faceting
# =============================================================================
print("\nEXERCISE 9: Displot Faceting")
print("-" * 80)
"""
Using the 'tips' dataset:
1. Use sns.displot() to create faceted histograms
2. Show the distribution of 'total_bill'
3. Create separate plots for each day (use col parameter)
4. Add KDE overlays
5. Set col_wrap=2 to arrange plots in 2 columns
"""

# YOUR CODE HERE
pass


# =============================================================================
# EXERCISE 10: Comprehensive Visualization
# =============================================================================
print("\nEXERCISE 10: Comprehensive Visualization")
print("-" * 80)
"""
Create a comprehensive analysis of the 'tips' dataset:
1. Create a figure with 3 subplots (1 row, 3 columns)
2. Subplot 1: Histogram with KDE of tip amounts
3. Subplot 2: ECDF plot of total_bill
4. Subplot 3: Scatter plot of total_bill vs tip with regression line
   (Hint: you can add a regression line using plt.plot or just show scatter)
5. Add proper titles, labels, and styling to all plots
6. Save the entire figure as 'tips_analysis.png'
"""

# YOUR CODE HERE
pass


print("\n" + "="*80)
print("BEGINNER EXERCISES COMPLETE!")
print("="*80)
print("Check your solutions against solutions_beginner.py")
print("Remember: There are often multiple correct ways to solve each problem!")
