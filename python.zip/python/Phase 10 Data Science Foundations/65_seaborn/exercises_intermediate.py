"""
Intermediate Exercises - Tutorials 04-07
Categorical Plots, Regression Plots, Matrix Plots, Multi-Plot Grids
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

sns.set_style("whitegrid")

print("="*80)
print("INTERMEDIATE EXERCISES")
print("="*80)

# Exercise 1: Box and Violin Plot Comparison
print("\nEXERCISE 1: Box and Violin Plot Comparison")
print("-" * 80)
"""
1. Load the 'tips' dataset
2. Create a figure with 2 subplots side by side
3. Left: Box plot of total_bill by day
4. Right: Violin plot of total_bill by day
5. Add appropriate titles
6. Which plot gives you more information about the distribution shape?
"""

# YOUR CODE HERE

# Exercise 2: Combined Categorical Plot
print("\nEXERCISE 2: Combined Categorical Plot")
print("-" * 80)
"""
1. Create a violin plot showing tip by day
2. Overlay a swarm plot on top
3. Color the violin plots light blue and swarm points black
4. Use alpha=0.5 for the swarm points
"""

# YOUR CODE HERE

# Exercise 3: Regression Analysis
print("\nEXERCISE 3: Regression Analysis")
print("-" * 80)
"""
1. Using lmplot, create regression plots for total_bill vs tip
2. Create separate plots for each value of 'time' (use col parameter)
3. Set height=5 and aspect=1.2
4. Add appropriate titles and labels
"""

# YOUR CODE HERE

# Exercise 4: Correlation Heatmap
print("\nEXERCISE 4: Correlation Heatmap")
print("-" * 80)
"""
1. Load the 'iris' dataset
2. Create a correlation matrix of all numerical columns
3. Display as a heatmap with:
   - annotations showing correlation values
   - 'coolwarm' colormap centered at 0
   - square cells
4. What are the two most strongly correlated features?
"""

# YOUR CODE HERE

# Exercise 5: FacetGrid Custom Plot
print("\nEXERCISE 5: FacetGrid Custom Plot")
print("-" * 80)
"""
1. Create a FacetGrid with tips dataset
2. Use 'time' for columns and 'sex' for rows
3. Map a scatter plot of total_bill vs tip to each facet
4. Add regression lines using g.map()
5. Set proper titles and labels
"""

# YOUR CODE HERE

# Exercise 6: PairGrid Analysis
print("\nEXERCISE 6: PairGrid Analysis")
print("-" * 80)
"""
1. Load the 'penguins' dataset
2. Select only numerical columns and remove NaN values
3. Create a PairGrid colored by species
4. Upper triangle: scatter plots
5. Lower triangle: KDE plots
6. Diagonal: histograms
"""

# YOUR CODE HERE

# Exercise 7: Pivot Heatmap
print("\nEXERCISE 7: Pivot Heatmap")
print("-" * 80)
"""
1. Using tips dataset, create a pivot table:
   - Index: day
   - Columns: time
   - Values: mean of tip
2. Display as a heatmap with annotations
3. Use 'YlOrRd' colormap
4. Format annotations to 2 decimal places
"""

# YOUR CODE HERE

# Exercise 8: JointGrid with Marginals
print("\nEXERCISE 8: JointGrid with Marginals")
print("-" * 80)
"""
1. Create a JointGrid with tips data
2. X: total_bill, Y: tip
3. Main plot: hexbin plot (use plot_joint)
4. Marginal plots: KDE plots
5. Set height=8
"""

# YOUR CODE HERE

print("\n" + "="*80)
print("Check solutions_intermediate.py for answers")
