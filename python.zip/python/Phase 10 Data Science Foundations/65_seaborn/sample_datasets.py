"""
Helper Module: Sample Dataset Generation

This module provides functions to generate sample datasets for practice exercises.
Use these when you want to practice with controlled data or when built-in datasets
aren't suitable for your exercise.
"""

import pandas as pd
import numpy as np

def generate_experiment_data(n_samples=100, seed=42):
    """
    Generate sample experimental data with control and treatment groups.
    
    Parameters:
    -----------
    n_samples : int, number of samples per group
    seed : int, random seed for reproducibility
    
    Returns:
    --------
    pd.DataFrame with columns: group, measurement, time_point
    """
    np.random.seed(seed)
    
    control = np.random.normal(50, 10, n_samples)
    treatment = np.random.normal(55, 12, n_samples)
    
    df = pd.DataFrame({
        'group': ['Control']*n_samples + ['Treatment']*n_samples,
        'measurement': np.concatenate([control, treatment]),
        'time_point': np.tile(range(1, n_samples+1), 2)
    })
    
    return df

def generate_timeseries_data(n_points=100, n_series=3, seed=42):
    """Generate multiple time series for comparison."""
    np.random.seed(seed)
    
    time = np.arange(n_points)
    data = []
    
    for i in range(n_series):
        trend = time * (i + 1) * 0.1
        noise = np.random.normal(0, 2, n_points)
        seasonal = np.sin(time / 10) * 5
        values = trend + noise + seasonal + (i * 10)
        
        for t, v in zip(time, values):
            data.append({
                'time': t,
                'value': v,
                'series': f'Series_{i+1}'
            })
    
    return pd.DataFrame(data)

def generate_survey_data(n_responses=200, seed=42):
    """Generate sample survey data."""
    np.random.seed(seed)
    
    ages = np.random.randint(18, 70, n_responses)
    genders = np.random.choice(['Male', 'Female'], n_responses)
    satisfaction = np.random.randint(1, 11, n_responses)
    income = np.random.lognormal(10, 0.5, n_responses)
    
    df = pd.DataFrame({
        'age': ages,
        'gender': genders,
        'satisfaction_score': satisfaction,
        'annual_income': income
    })
    
    return df

if __name__ == '__main__':
    print("Sample Dataset Generator Module")
    print("="*50)
    
    # Test functions
    exp_data = generate_experiment_data()
    print(f"\nExperiment data: {exp_data.shape}")
    print(exp_data.head())
    
    ts_data = generate_timeseries_data()
    print(f"\nTime series data: {ts_data.shape}")
    print(ts_data.head())
    
    survey_data = generate_survey_data()
    print(f"\nSurvey data: {survey_data.shape}")
    print(survey_data.head())
