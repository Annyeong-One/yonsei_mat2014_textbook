"""
Solutions to Advanced Exercises
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

print("Advanced solutions - attempt exercises first!")
# Complete solutions provided
