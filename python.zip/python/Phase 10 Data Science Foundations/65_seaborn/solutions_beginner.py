"""
Solutions to Beginner Exercises
Compare your solutions with these after attempting the exercises yourself.
"""

import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

sns.set_style("whitegrid")
sns.set_context("notebook")

print("="*80)
print("BEGINNER EXERCISES - SOLUTIONS")
print("="*80)

# SOLUTION 1
print("\nSOLUTION 1: Loading and Exploring Data")
print("-" * 80)
penguins = sns.load_dataset('penguins')
print("First 10 rows:")
print(penguins.head(10))
print("\nColumn names and types:")
print(penguins.dtypes)
print("\nBasic statistics:")
print(penguins.describe())
print(f"\nNumber of unique species: {penguins['species'].nunique()}")
print(f"Species names: {penguins['species'].unique()}")

# SOLUTION 2
print("\nSOLUTION 2: Basic Scatter Plot")
print("-" * 80)
plt.figure(figsize=(10, 6))
sns.scatterplot(data=penguins, x='bill_length_mm', y='bill_depth_mm')
plt.xlabel('Bill Length (mm)', fontsize=12)
plt.ylabel('Bill Depth (mm)', fontsize=12)
plt.title('Penguin Bill Dimensions', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('solution_02.png', dpi=300, bbox_inches='tight')
plt.show()
print("Pattern: The data shows distinct clusters, suggesting different species")

# SOLUTION 3
print("\nSOLUTION 3: Scatter Plot with Color")
print("-" * 80)
plt.figure(figsize=(10, 6))
sns.scatterplot(data=penguins, x='flipper_length_mm', y='body_mass_g', hue='species', s=60)
plt.xlabel('Flipper Length (mm)', fontsize=12)
plt.ylabel('Body Mass (g)', fontsize=12)
plt.title('Penguin Body Measurements by Species', fontsize=14, fontweight='bold')
plt.legend(title='Species', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.savefig('penguin_scatter.png', dpi=300, bbox_inches='tight')
plt.show()

# SOLUTION 4
print("\nSOLUTION 4: Line Plot")
print("-" * 80)
flights = sns.load_dataset('flights')
selected_months = flights[flights['month'].isin(['Jan', 'Jun', 'Dec'])]
plt.figure(figsize=(10, 6))
sns.lineplot(data=selected_months, x='year', y='passengers', hue='month', markers=True, style='month')
plt.xlabel('Year', fontsize=12)
plt.ylabel('Number of Passengers', fontsize=12)
plt.title('Airline Passengers Over Time (Selected Months)', fontsize=14, fontweight='bold')
plt.legend(title='Month')
plt.tight_layout()
plt.show()

# SOLUTION 5
print("\nSOLUTION 5: Bar Plot Comparison")
print("-" * 80)
tips = sns.load_dataset('tips')
plt.figure(figsize=(10, 6))
sns.barplot(data=tips, y='day', x='total_bill', hue='time', orient='h', palette='Set2')
plt.ylabel('Day of Week', fontsize=12)
plt.xlabel('Average Total Bill ($)', fontsize=12)
plt.title('Average Bill by Day and Time', fontsize=14, fontweight='bold')
plt.legend(title='Time of Day')
plt.tight_layout()
plt.show()

# SOLUTION 6
print("\nSOLUTION 6: Distribution Analysis")
print("-" * 80)
plt.figure(figsize=(10, 6))
sns.histplot(data=tips, x='total_bill', kde=True, bins=25, color='steelblue', edgecolor='black', linewidth=0.5)
plt.xlabel('Total Bill ($)', fontsize=12)
plt.ylabel('Frequency', fontsize=12)
plt.title('Distribution of Total Bills', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.show()
print("Distribution shape: Right-skewed (longer tail on the right)")

# SOLUTION 7
print("\nSOLUTION 7: Comparing Distributions")
print("-" * 80)
plt.figure(figsize=(10, 6))
for species in penguins['species'].unique():
    if pd.notna(species):
        subset = penguins[penguins['species'] == species]
        sns.kdeplot(data=subset, x='body_mass_g', label=species, fill=True, alpha=0.5, linewidth=2)
plt.xlabel('Body Mass (g)', fontsize=12)
plt.ylabel('Density', fontsize=12)
plt.title('Body Mass Distribution by Penguin Species', fontsize=14, fontweight='bold')
plt.legend(title='Species')
plt.tight_layout()
plt.show()
print("Observation: Gentoo penguins tend to be the heaviest on average")

# SOLUTION 8
print("\nSOLUTION 8: Multi-Plot Grid")
print("-" * 80)
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Tips Dataset Analysis Dashboard', fontsize=16, fontweight='bold')
sns.scatterplot(data=tips, x='total_bill', y='tip', ax=axes[0, 0])
axes[0, 0].set_title('Tips vs Total Bill')
sns.barplot(data=tips, x='day', y='tip', ax=axes[0, 1])
axes[0, 1].set_title('Average Tip by Day')
sns.countplot(data=tips, x='time', ax=axes[1, 0])
axes[1, 0].set_title('Customer Count by Time')
sns.violinplot(data=tips, x='day', y='total_bill', ax=axes[1, 1])
axes[1, 1].set_title('Bill Distribution by Day')
plt.tight_layout()
plt.show()

# SOLUTION 9
print("\nSOLUTION 9: Displot Faceting")
print("-" * 80)
g = sns.displot(data=tips, x='total_bill', col='day', col_wrap=2, kind='hist', kde=True, bins=15, height=4, aspect=1.2)
g.set_titles("Day: {col_name}")
g.set_axis_labels("Total Bill ($)", "Count")
plt.tight_layout()
plt.show()

# SOLUTION 10
print("\nSOLUTION 10: Comprehensive Visualization")
print("-" * 80)
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
sns.histplot(data=tips, x='tip', kde=True, bins=20, ax=axes[0])
axes[0].set_title('Tip Distribution', fontweight='bold')
axes[0].set_xlabel('Tip ($)')
sns.ecdfplot(data=tips, x='total_bill', ax=axes[1])
axes[1].set_title('Cumulative Distribution of Bill', fontweight='bold')
axes[1].set_xlabel('Total Bill ($)')
axes[1].grid(True, alpha=0.3)
sns.scatterplot(data=tips, x='total_bill', y='tip', alpha=0.6, ax=axes[2])
axes[2].set_title('Bill vs Tip Relationship', fontweight='bold')
axes[2].set_xlabel('Total Bill ($)')
axes[2].set_ylabel('Tip ($)')
plt.tight_layout()
plt.savefig('tips_analysis.png', dpi=300, bbox_inches='tight')
plt.show()

print("\n" + "="*80)
print("All solutions provided!")
print("="*80)
