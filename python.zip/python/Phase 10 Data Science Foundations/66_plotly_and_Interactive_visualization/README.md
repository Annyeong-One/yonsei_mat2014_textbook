# Plotly & Interactive Visualization - Complete Python Course

A comprehensive, undergraduate-level curriculum for learning Plotly and interactive data visualization in Python. This course progresses from basic plots to advanced interactive dashboards with heavily commented code and practical exercises.

## 📚 Course Overview

This course is designed for undergraduate computer science students learning data visualization. Each module includes:
- **Heavily commented Python files** explaining every concept
- **Progressive difficulty levels** (Beginner → Intermediate → Advanced)
- **Practical exercises** with complete solutions
- **Real-world examples** demonstrating best practices

## 🗂️ Course Structure

```
plotly_course/
├── 01_beginner/           # Foundational Plotly concepts
├── 02_intermediate/       # Advanced plot types and layouts
├── 03_advanced/           # Animations, dashboards, and styling
├── 04_exercises/          # Practice problems for each level
├── 05_exercise_solutions/ # Complete solutions with explanations
└── README.md             # This file
```

## 📖 Course Contents

### Level 1: Beginner (01_beginner/)

**01_basic_line_plots.py**
- Creating simple and multiple line plots
- Customizing line appearance (colors, styles, widths)
- Adding titles, labels, and legends
- Understanding Figure and Trace objects
- Plotly Express vs Graph Objects introduction

**02_scatter_plots.py**
- Basic scatter plot creation
- Marker customization (size, color, symbols)
- Color-coded scatter plots (3D visualization in 2D)
- Bubble charts (size-coded scatter plots)
- Categorical grouping with Plotly Express
- Trend lines and statistical overlays
- Custom hover information

**03_bar_charts.py**
- Vertical and horizontal bar charts
- Grouped bar charts for comparisons
- Stacked bar charts for composition
- Adding value labels to bars
- Error bars for uncertainty visualization
- Waterfall charts for sequential changes
- Custom color schemes

**04_pie_charts.py**
- Basic pie chart creation
- Donut charts with center annotations
- Pull-out slices for emphasis
- Sunburst charts for hierarchical data
- Color customization
- Text positioning and formatting

**05_histograms.py**
- Creating distribution histograms
- Customizing bin sizes and ranges
- Overlaid histograms for comparison
- Cumulative histograms
- 2D histograms (density maps)
- Statistical annotations

### Level 2: Intermediate (02_intermediate/)

**01_subplots_layouts.py**
- Creating grid layouts (2x2, 3x3, etc.)
- Shared axes between subplots
- Custom subplot arrangements
- Mixed plot types in one figure
- Subplot spacing and sizing
- Complex dashboard layouts

**02_3d_plots.py**
- 3D scatter plots
- 3D surface plots from mesh grids
- 3D line plots (parametric curves)
- 3D mesh visualization
- Camera positioning and angles
- Lighting and appearance customization

**03_statistical_plots.py**
- Box plots for distribution comparison
- Violin plots showing full distributions
- Correlation matrix heatmaps
- Distribution plots with KDE curves
- Statistical annotations
- Confidence intervals

**04_heatmaps_contours.py**
- Basic heatmap creation from matrix data
- Annotated heatmaps with cell values
- Contour plots for 2D functions
- Filled contour plots
- Custom color scales
- Hierarchical clustering visualization

**05_time_series.py**
- Time series line plots
- Date formatting and handling
- Range sliders for interactive zooming
- Range selector buttons (1m, 6m, 1y, etc.)
- Candlestick charts for financial data
- Multiple time series comparison
- Unified hover mode for time series

### Level 3: Advanced (03_advanced/)

**01_animations.py**
- Frame-based animations
- Play/pause controls
- Animated scatter plots
- Animated line plots (waves, etc.)
- Animated bar charts with Plotly Express
- Animated bubble charts
- Custom animation parameters
- Frame duration and transitions

**02_dashboards.py**
- Multi-panel dashboard layouts
- KPI indicators with deltas
- Linked visualizations
- Interactive filtering
- Responsive design principles
- Professional dashboard styling

**03_custom_hover.py**
- HTML formatting in hover templates
- Multi-line hover information
- Number and date formatting
- Conditional hover content
- Custom data arrays
- Removing secondary hover boxes
- Rich hover experiences

**04_express_vs_objects.py**
- When to use Plotly Express
- When to use Graph Objects
- Converting between APIs
- Combining both approaches
- Performance considerations
- Best practices for each API

**05_advanced_styling.py**
- Custom color schemes and themes
- Professional publication-ready plots
- Custom color scales
- Template system
- Font and typography control
- Grid and axis customization
- Figure sizing and resolution
- Exporting high-quality images

## 🎯 Exercises

Each difficulty level has a corresponding exercise file:

- **exercise_01_beginner.py**: 6 exercises covering basic plots
- **exercise_02_intermediate.py**: 6 exercises on subplots and 3D visualization
- **exercise_03_advanced.py**: 3 challenging exercises on animations and dashboards

All exercises include:
- Clear problem descriptions
- Requirements and specifications
- TODO sections for student implementation
- Comments explaining expected output

## ✅ Solutions

Complete, well-commented solutions are provided in `05_exercise_solutions/`:

- **solution_01_beginner.py**: All beginner exercise solutions
- **solution_02_intermediate.py**: All intermediate exercise solutions
- **solution_03_advanced.py**: All advanced exercise solutions

Each solution includes:
- Complete working code
- Detailed comments explaining the approach
- Best practices demonstration
- Alternative approaches where applicable

## 🚀 Getting Started

### Prerequisites

```bash
# Required libraries
pip install plotly pandas numpy scipy
```

### Installation

1. Download and extract the course files
2. Navigate to the course directory
3. Start with beginner tutorials

### Recommended Learning Path

1. **Week 1-2: Beginner Level**
   - Work through 01_beginner files in order
   - Run each example and modify parameters
   - Complete beginner exercises

2. **Week 3-4: Intermediate Level**
   - Study 02_intermediate tutorials
   - Experiment with subplots and 3D plots
   - Complete intermediate exercises

3. **Week 5-6: Advanced Level**
   - Learn animations and dashboards
   - Study advanced styling techniques
   - Complete advanced exercises

4. **Week 7-8: Projects**
   - Build complete visualization projects
   - Create interactive dashboards
   - Present your work

## 💻 How to Use

### Running Tutorial Files

```python
# Method 1: Run entire file
python 01_beginner/01_basic_line_plots.py

# Method 2: Import and use individual functions
from basic_line_plots import create_simple_line_plot
fig = create_simple_line_plot()
fig.show()

# Method 3: Interactive exploration in Jupyter
import plotly.graph_objects as go
# Copy code from tutorials and experiment
```

### Working on Exercises

```python
# 1. Open exercise file
# 2. Read the TODO comments
# 3. Implement the solution
# 4. Test by uncommenting the test section
# 5. Compare with provided solutions

# Example workflow:
def exercise_1():
    # TODO: Your implementation here
    x = [1, 2, 3, 4, 5]
    y = [10, 15, 13, 17, 20]
    # ... your code ...
    return fig

# Test it:
fig = exercise_1()
fig.show()
```

## 📊 Key Concepts Covered

### Core Visualization Types
- Line plots, scatter plots, bar charts
- Pie charts, histograms, box plots
- Heatmaps, contour plots, 3D plots
- Time series, candlestick charts

### Interactive Features
- Hover templates and custom tooltips
- Zoom, pan, and range selection
- Linked brushing between plots
- Play/pause animations
- Dynamic filtering

### Design Principles
- Color theory for data visualization
- Typography and readability
- Layout and composition
- Professional styling for publications
- Accessibility considerations

### Technical Skills
- Working with pandas DataFrames
- NumPy array manipulation
- Date/time handling
- Statistical visualization
- Performance optimization

## 🎨 Plotly Fundamentals

### Two Main APIs

**Plotly Express (px)**: High-level, concise
```python
import plotly.express as px
fig = px.scatter(df, x='col1', y='col2', color='col3')
```

**Graph Objects (go)**: Low-level, full control
```python
import plotly.graph_objects as go
fig = go.Figure()
fig.add_trace(go.Scatter(x=x, y=y))
```

### Figure Structure
```
Figure
├── Data (traces)
│   ├── Scatter
│   ├── Bar
│   └── ...
└── Layout
    ├── Title
    ├── Axes
    ├── Legend
    └── Annotations
```

## 🔧 Troubleshooting

### Common Issues

**Problem**: Plots don't display
```python
# Solution: Make sure to call .show()
fig.show()

# For Jupyter notebooks:
import plotly.io as pio
pio.renderers.default = "notebook"
```

**Problem**: Import errors
```bash
# Solution: Install missing packages
pip install plotly pandas numpy

# Update to latest version
pip install --upgrade plotly
```

**Problem**: Slow performance with large datasets
```python
# Solution: Sample your data
df_sample = df.sample(n=1000)

# Or use Plotly's WebGL mode
fig = go.Figure(go.Scattergl(x=x, y=y))  # Note: Scattergl, not Scatter
```

## 📚 Additional Resources

### Official Documentation
- [Plotly Python Documentation](https://plotly.com/python/)
- [Plotly Figure Reference](https://plotly.com/python/reference/)
- [Plotly Community Forum](https://community.plotly.com/)

### Recommended Reading
- Edward Tufte - "The Visual Display of Quantitative Information"
- Alberto Cairo - "The Functional Art"
- Cole Nussbaumer Knaflic - "Storytelling with Data"

### Online Resources
- [Plotly Python Tutorial](https://plotly.com/python/getting-started/)
- [Stack Overflow - Plotly Tag](https://stackoverflow.com/questions/tagged/plotly)
- [Plotly GitHub Examples](https://github.com/plotly/plotly.py)

## 🎓 Teaching Notes

### For Instructors

This curriculum is designed for:
- **Course length**: 8-10 weeks (2-3 hours per week)
- **Prerequisites**: Basic Python programming
- **Assessment**: Exercises + final project
- **Format**: Lectures + lab sessions

### Suggested Projects
1. **Data Dashboard**: Create an interactive dashboard for a dataset
2. **Time Series Analysis**: Visualize stock prices or climate data
3. **3D Visualization**: Explore scientific or geographic data
4. **Animation**: Show data evolution over time
5. **Publication Plots**: Create journal-quality figures

### Grading Rubric (Example)
- Exercises (40%): Completion and correctness
- Project (40%): Functionality, design, documentation
- Code Quality (20%): Comments, organization, best practices

## 🤝 Best Practices

### Code Style
```python
# Good: Descriptive variable names
sales_by_quarter = [100, 120, 115, 130]

# Bad: Cryptic abbreviations
sbq = [100, 120, 115, 130]

# Good: Comments explaining "why"
# Use log scale because data spans orders of magnitude
fig.update_yaxis(type='log')

# Bad: Comments explaining "what" (obvious from code)
# Set y-axis to log
fig.update_yaxis(type='log')
```

### Design Principles
1. **Less is more**: Remove unnecessary elements
2. **Color with purpose**: Use color to encode information
3. **Clear labels**: Always label axes and include units
4. **Consistent style**: Maintain uniform appearance
5. **Accessibility**: Consider colorblind-friendly palettes

### Performance Tips
1. Sample large datasets before plotting
2. Use WebGL for >1000 points (`Scattergl`)
3. Avoid excessive animations
4. Optimize subplot layouts
5. Consider static exports for final figures

## 📝 License and Usage

This educational material is provided for academic use. Students are encouraged to:
- Study and learn from all code examples
- Complete exercises independently
- Modify examples for learning purposes
- Build upon concepts for projects

## 🙋 Support

For questions or issues with the course materials:
1. Review the relevant tutorial file comments
2. Check the solutions for reference implementations
3. Consult official Plotly documentation
4. Experiment with parameter variations

## 🎯 Learning Outcomes

By completing this course, students will be able to:

✓ Create all major plot types in Plotly
✓ Design interactive visualizations
✓ Build multi-panel dashboards
✓ Customize plots for professional presentation
✓ Choose appropriate visualizations for different data types
✓ Apply data visualization best practices
✓ Debug and troubleshoot Plotly code
✓ Optimize performance for large datasets

## 📈 Course Progression

```
Beginner (Weeks 1-2)
├── Basic plot types
├── Customization fundamentals
└── First exercises
    ↓
Intermediate (Weeks 3-4)
├── Complex layouts
├── 3D visualization
└── Statistical plots
    ↓
Advanced (Weeks 5-6)
├── Animations
├── Dashboards
└── Professional styling
    ↓
Projects (Weeks 7-8)
├── Real-world datasets
├── Complete applications
└── Presentation
```

## 🌟 Tips for Success

1. **Practice regularly**: Work through examples daily
2. **Experiment freely**: Modify parameters to see effects
3. **Read documentation**: Consult official docs when stuck
4. **Build incrementally**: Start simple, add complexity gradually
5. **Focus on clarity**: Prioritize clear communication over complexity
6. **Get feedback**: Share your visualizations with others
7. **Study examples**: Look at professional dashboards for inspiration

## 📞 Contact

For course-related inquiries or feedback, please contact your instructor.

---

**Version**: 1.0  
**Last Updated**: 2024  
**Authors**: Educational Python Course Development Team  
**Target Audience**: Undergraduate Computer Science Students

Happy Learning! 📊✨
