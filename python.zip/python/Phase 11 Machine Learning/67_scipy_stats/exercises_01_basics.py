"""
Exercises 01: Basics of scipy.stats and Probability Distributions
=================================================================
Complete these exercises to test your understanding of scipy.stats basics.
"""

import numpy as np
from scipy import stats

print("="*80)
print("EXERCISES: BASICS AND DISTRIBUTIONS")
print("="*80)
print()

# Exercise 1: Working with Normal Distribution
print("Exercise 1: Normal Distribution")
print("-" * 40)
print("A manufacturing process produces parts with mean length 10.0 cm and")
print("standard deviation 0.5 cm, normally distributed.")
print()
print("a) What percentage of parts are between 9.5 and 10.5 cm?")
print("b) What length marks the 95th percentile?")
print("c) If we sample 100 parts, what is the probability that")
print("   the sample mean is between 9.9 and 10.1 cm?")
print()
print("TODO: Write your code here\n")

# Exercise 2: Binomial Distribution
print("Exercise 2: Binomial Distribution")
print("-" * 40)
print("A multiple-choice test has 20 questions, each with 4 choices.")
print("A student guesses randomly on all questions.")
print()
print("a) What is the expected number of correct answers?")
print("b) What is the probability of getting exactly 8 correct?")
print("c) What is the probability of passing (≥12 correct)?")
print()
print("TODO: Write your code here\n")

# Continue with more exercises...
print("="*80)
print("Total Exercises: 10")
print("See solutions_01_basics.py for complete solutions")
print("="*80)
