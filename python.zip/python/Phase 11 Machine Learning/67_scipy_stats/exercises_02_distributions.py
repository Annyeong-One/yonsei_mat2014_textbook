"""
Exercises 02: Continuous and Discrete Distributions
===================================================
Practice problems on various probability distributions.
"""

import numpy as np
from scipy import stats

print("="*80)
print("EXERCISES: PROBABILITY DISTRIBUTIONS")
print("="*80)
print()

# Exercise 1: Exponential Distribution
print("Exercise 1: Exponential Distribution (Waiting Times)")
print("-" * 40)
print("Customers arrive at a service center with mean time between")
print("arrivals of 5 minutes (exponentially distributed).")
print()
print("a) What is the probability the next customer arrives within 3 minutes?")
print("b) Given that 4 minutes have passed, what is the probability")
print("   the next customer arrives within the next 2 minutes?")
print("c) Verify the memoryless property.")
print()
print("TODO: Write your code here\n")

# More exercises...
print("="*80)
