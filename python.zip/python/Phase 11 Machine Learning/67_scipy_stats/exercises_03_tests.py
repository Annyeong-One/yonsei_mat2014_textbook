"""
Exercises 03: Statistical Hypothesis Tests
==========================================
Practice problems on various statistical tests.
"""

import numpy as np
from scipy import stats

print("="*80)
print("EXERCISES: STATISTICAL TESTS")
print("="*80)
print()

# Exercise 1: Two-sample t-test
print("Exercise 1: Comparing Two Teaching Methods")
print("-" * 40)
print("Test scores from two teaching methods:")
method_A = np.array([78, 82, 75, 88, 72, 90, 85, 77, 83, 79])
method_B = np.array([85, 88, 91, 84, 89, 92, 87, 90, 86, 93])
print(f"Method A: {method_A}")
print(f"Method B: {method_B}")
print()
print("a) Test if methods produce different results (α=0.05)")
print("b) Calculate and interpret Cohen\'s d")
print("c) What is the 95% confidence interval for the difference?")
print()
print("TODO: Write your code here\n")

# More exercises...
print("="*80)
