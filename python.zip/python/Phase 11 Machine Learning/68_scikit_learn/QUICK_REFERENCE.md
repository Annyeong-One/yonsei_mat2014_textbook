# Scikit-learn Quick Reference Sheet

## 🔄 The Sklearn Workflow

```python
# 1. Import
from sklearn.algorithm import Model

# 2. Split Data
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# 3. Preprocess (if needed)
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 4. Instantiate & Train
model = Model(parameters)
model.fit(X_train, y_train)

# 5. Predict & Evaluate
y_pred = model.predict(X_test)
score = model.score(X_test, y_test)
```

## 📊 Common Algorithms Cheat Sheet

### Classification
```python
# Logistic Regression
from sklearn.linear_model import LogisticRegression
model = LogisticRegression(max_iter=1000)

# SVM
from sklearn.svm import SVC
model = SVC(kernel='rbf', C=1.0, gamma='scale')

# Random Forest
from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators=100, max_depth=10)

# Decision Tree
from sklearn.tree import DecisionTreeClassifier
model = DecisionTreeClassifier(max_depth=5)
```

### Regression
```python
# Linear Regression
from sklearn.linear_model import LinearRegression
model = LinearRegression()

# Ridge (L2)
from sklearn.linear_model import Ridge
model = Ridge(alpha=1.0)

# Lasso (L1)
from sklearn.linear_model import Lasso
model = Lasso(alpha=0.1)

# Random Forest Regressor
from sklearn.ensemble import RandomForestRegressor
model = RandomForestRegressor(n_estimators=100)
```

### Clustering
```python
# K-Means
from sklearn.cluster import KMeans
model = KMeans(n_clusters=3, random_state=42)

# Hierarchical
from sklearn.cluster import AgglomerativeClustering
model = AgglomerativeClustering(n_clusters=3)
```

## 🛠️ Preprocessing

```python
# Scaling
from sklearn.preprocessing import StandardScaler, MinMaxScaler
scaler = StandardScaler()  # mean=0, std=1
scaler = MinMaxScaler()    # range [0,1]

# Encoding
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
le = LabelEncoder()
ohe = OneHotEncoder()

# Missing Data
from sklearn.impute import SimpleImputer
imputer = SimpleImputer(strategy='mean')  # or 'median', 'most_frequent'
```

## 📈 Evaluation Metrics

### Classification
```python
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)
```

### Regression
```python
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    r2_score
)
```

## 🔍 Model Selection

```python
# Cross-Validation
from sklearn.model_selection import cross_val_score
scores = cross_val_score(model, X, y, cv=5)

# Grid Search
from sklearn.model_selection import GridSearchCV
param_grid = {'C': [0.1, 1, 10], 'gamma': [0.01, 0.1, 1]}
grid = GridSearchCV(model, param_grid, cv=5)
grid.fit(X_train, y_train)
best_model = grid.best_estimator_
```

## 🔧 Pipelines

```python
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression

pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('pca', PCA(n_components=10)),
    ('classifier', LogisticRegression())
])

pipeline.fit(X_train, y_train)
```

## ⚠️ Common Gotchas

1. **Always fit on training data only**
2. **Transform both train and test with same scaler**
3. **Use stratify=y for imbalanced classes**
4. **Scale features for SVM, LogReg, KNN**
5. **Use random_state for reproducibility**
6. **Check for data leakage**

## 📚 When to Use What

**Need interpretable model?** → Linear Regression, Logistic Regression, Decision Tree

**High-dimensional data?** → SVM, Random Forest, Regularized Linear Models

**Non-linear relationships?** → SVM (kernel), Random Forest, Neural Networks

**Very large dataset?** → SGDClassifier, MiniBatchKMeans

**Categorical features?** → Decision Trees, Random Forest

**Need probability estimates?** → Logistic Regression, Random Forest

**Outliers present?** → RobustScaler, Random Forest

**Imbalanced classes?** → Use class_weight='balanced', SMOTE, stratified sampling
