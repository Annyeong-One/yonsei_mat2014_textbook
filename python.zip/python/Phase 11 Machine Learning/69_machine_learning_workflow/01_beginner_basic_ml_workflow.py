"""
Machine Learning Workflow - Beginner Level
==========================================

This module introduces the fundamental steps of a machine learning workflow.
Students will learn the basic pipeline from data loading to model evaluation.

Learning Objectives:
- Understand the complete ML workflow
- Load and explore datasets
- Split data into training and testing sets
- Train a simple classifier
- Evaluate model performance

Author: Educational Materials for Undergraduate CS
"""

# Import necessary libraries
import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')


def step1_load_data():
    """
    Step 1: Load Data
    -----------------
    Loading data is the first step in any ML workflow.
    We use the famous Iris dataset as an example.
    
    Returns:
        tuple: Features (X) and labels (y) as numpy arrays
    """
    print("=" * 60)
    print("STEP 1: LOADING DATA")
    print("=" * 60)
    
    # Load the Iris dataset
    # The Iris dataset contains measurements of 150 iris flowers
    # from three different species
    iris = load_iris()
    
    # X contains the features (measurements)
    # Features: sepal length, sepal width, petal length, petal width
    X = iris.data
    
    # y contains the labels (species)
    # Labels: 0 = setosa, 1 = versicolor, 2 = virginica
    y = iris.target
    
    print(f"Dataset loaded: Iris")
    print(f"Number of samples: {X.shape[0]}")
    print(f"Number of features: {X.shape[1]}")
    print(f"Number of classes: {len(np.unique(y))}")
    print(f"Feature names: {iris.feature_names}")
    print(f"Target names: {iris.target_names}")
    print()
    
    return X, y, iris.feature_names, iris.target_names


def step2_explore_data(X, y, feature_names, target_names):
    """
    Step 2: Explore Data
    --------------------
    Understanding your data is crucial before building models.
    We examine basic statistics and distributions.
    
    Args:
        X: Feature matrix
        y: Label vector
        feature_names: Names of features
        target_names: Names of target classes
    """
    print("=" * 60)
    print("STEP 2: EXPLORING DATA")
    print("=" * 60)
    
    # Convert to DataFrame for easier exploration
    df = pd.DataFrame(X, columns=feature_names)
    df['target'] = y
    
    # Display first few rows
    print("\nFirst 5 samples:")
    print(df.head())
    
    # Basic statistics
    print("\nBasic Statistics:")
    print(df.describe())
    
    # Class distribution
    print("\nClass Distribution:")
    unique, counts = np.unique(y, return_counts=True)
    for label, count in zip(unique, counts):
        print(f"  {target_names[label]}: {count} samples")
    
    # Check for missing values
    print(f"\nMissing values: {df.isnull().sum().sum()}")
    print()


def step3_split_data(X, y):
    """
    Step 3: Split Data
    ------------------
    We divide data into training and testing sets.
    Training set: Used to train the model
    Testing set: Used to evaluate the model on unseen data
    
    Args:
        X: Feature matrix
        y: Label vector
    
    Returns:
        tuple: X_train, X_test, y_train, y_test
    """
    print("=" * 60)
    print("STEP 3: SPLITTING DATA")
    print("=" * 60)
    
    # Split data: 80% training, 20% testing
    # random_state ensures reproducibility
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, 
        test_size=0.2,      # 20% for testing
        random_state=42,     # Fixed seed for reproducibility
        stratify=y           # Maintain class distribution in both sets
    )
    
    print(f"Training set size: {X_train.shape[0]} samples")
    print(f"Testing set size: {X_test.shape[0]} samples")
    print(f"Training set proportion: {X_train.shape[0] / X.shape[0]:.1%}")
    print(f"Testing set proportion: {X_test.shape[0] / X.shape[0]:.1%}")
    print()
    
    return X_train, X_test, y_train, y_test


def step4_train_model(X_train, y_train):
    """
    Step 4: Train Model
    -------------------
    We create and train a machine learning model.
    Here we use a Decision Tree classifier as a simple example.
    
    Args:
        X_train: Training features
        y_train: Training labels
    
    Returns:
        Trained model
    """
    print("=" * 60)
    print("STEP 4: TRAINING MODEL")
    print("=" * 60)
    
    # Create a Decision Tree classifier
    # max_depth limits tree depth to prevent overfitting
    model = DecisionTreeClassifier(
        max_depth=3,         # Maximum depth of tree
        random_state=42      # For reproducibility
    )
    
    print("Model created: Decision Tree Classifier")
    print(f"Parameters: max_depth=3")
    
    # Train the model
    # The model learns patterns from training data
    print("\nTraining model...")
    model.fit(X_train, y_train)
    print("Model training complete!")
    print()
    
    return model


def step5_make_predictions(model, X_test):
    """
    Step 5: Make Predictions
    ------------------------
    Use the trained model to predict labels for test data.
    
    Args:
        model: Trained model
        X_test: Test features
    
    Returns:
        numpy.ndarray: Predicted labels
    """
    print("=" * 60)
    print("STEP 5: MAKING PREDICTIONS")
    print("=" * 60)
    
    # Generate predictions
    y_pred = model.predict(X_test)
    
    print(f"Predictions made for {len(y_pred)} samples")
    print(f"First 10 predictions: {y_pred[:10]}")
    print()
    
    return y_pred


def step6_evaluate_model(y_test, y_pred, target_names):
    """
    Step 6: Evaluate Model
    ----------------------
    Assess how well the model performs on test data.
    
    Args:
        y_test: True labels
        y_pred: Predicted labels
        target_names: Names of target classes
    """
    print("=" * 60)
    print("STEP 6: EVALUATING MODEL")
    print("=" * 60)
    
    # Calculate accuracy
    # Accuracy = (Number of correct predictions) / (Total predictions)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Detailed classification report
    # Includes precision, recall, and F1-score for each class
    print("\nDetailed Classification Report:")
    print(classification_report(y_test, y_pred, target_names=target_names))
    
    # Show some example predictions
    print("Sample Predictions vs Actual:")
    print(f"{'Predicted':<15} {'Actual':<15} {'Correct?':<10}")
    print("-" * 40)
    for i in range(min(10, len(y_test))):
        pred_name = target_names[y_pred[i]]
        actual_name = target_names[y_test[i]]
        correct = "✓" if y_pred[i] == y_test[i] else "✗"
        print(f"{pred_name:<15} {actual_name:<15} {correct:<10}")
    print()


def complete_ml_workflow():
    """
    Complete Machine Learning Workflow
    ----------------------------------
    This function demonstrates the entire ML workflow from start to finish.
    Each step is clearly separated and explained.
    """
    print("\n" + "=" * 60)
    print("COMPLETE MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    # Step 1: Load data
    X, y, feature_names, target_names = step1_load_data()
    
    # Step 2: Explore data
    step2_explore_data(X, y, feature_names, target_names)
    
    # Step 3: Split data
    X_train, X_test, y_train, y_test = step3_split_data(X, y)
    
    # Step 4: Train model
    model = step4_train_model(X_train, y_train)
    
    # Step 5: Make predictions
    y_pred = step5_make_predictions(model, X_test)
    
    # Step 6: Evaluate model
    step6_evaluate_model(y_test, y_pred, target_names)
    
    print("=" * 60)
    print("WORKFLOW COMPLETE!")
    print("=" * 60)
    print("\nKey Takeaways:")
    print("1. ML workflow has 6 main steps")
    print("2. Always split data before training")
    print("3. Train on training set, evaluate on test set")
    print("4. Accuracy is one measure of model performance")
    print("5. Never use test data during training!")


if __name__ == "__main__":
    """
    Main execution block
    This runs when the script is executed directly.
    """
    complete_ml_workflow()
