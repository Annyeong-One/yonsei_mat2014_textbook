"""
Machine Learning Workflow - Intermediate Level
==============================================

This module covers data preprocessing and feature engineering,
which are critical steps in real-world ML workflows.

Learning Objectives:
- Handle missing data
- Encode categorical variables
- Scale and normalize features
- Handle imbalanced datasets
- Use multiple evaluation metrics
- Perform feature engineering

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, 
                              f1_score, confusion_matrix, classification_report)
import warnings
warnings.filterwarnings('ignore')


def create_sample_dataset():
    """
    Create a sample dataset with common real-world issues:
    - Missing values
    - Categorical features
    - Different feature scales
    
    Returns:
        tuple: DataFrame with features and labels
    """
    print("=" * 60)
    print("CREATING SAMPLE DATASET")
    print("=" * 60)
    
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Create 1000 samples with various features
    n_samples = 1000
    
    # Numerical features with different scales
    age = np.random.randint(18, 70, n_samples)
    income = np.random.randint(20000, 150000, n_samples)
    credit_score = np.random.randint(300, 850, n_samples)
    
    # Categorical features
    education = np.random.choice(['High School', 'Bachelor', 'Master', 'PhD'], n_samples)
    employment = np.random.choice(['Employed', 'Self-Employed', 'Unemployed'], n_samples)
    
    # Create target variable (loan approval: 0=rejected, 1=approved)
    # Higher income, credit score, and education increase approval probability
    loan_approval = (
        (income > 60000).astype(int) * 0.3 +
        (credit_score > 650).astype(int) * 0.4 +
        (age > 25).astype(int) * 0.1 +
        np.random.random(n_samples) * 0.2
    ) > 0.5
    loan_approval = loan_approval.astype(int)
    
    # Create DataFrame
    df = pd.DataFrame({
        'age': age,
        'income': income,
        'credit_score': credit_score,
        'education': education,
        'employment': employment,
        'loan_approved': loan_approval
    })
    
    # Introduce missing values (realistic scenario)
    # Randomly set 5% of income values to NaN
    missing_indices = np.random.choice(df.index, size=int(0.05 * n_samples), replace=False)
    df.loc[missing_indices, 'income'] = np.nan
    
    # Randomly set 3% of credit_score values to NaN
    missing_indices = np.random.choice(df.index, size=int(0.03 * n_samples), replace=False)
    df.loc[missing_indices, 'credit_score'] = np.nan
    
    print(f"Dataset created: {df.shape[0]} samples, {df.shape[1]-1} features")
    print(f"Target distribution:")
    print(df['loan_approved'].value_counts())
    print()
    
    return df


def step1_explore_and_analyze(df):
    """
    Step 1: Comprehensive Data Exploration
    --------------------------------------
    Understand the dataset structure, distributions, and quality issues.
    
    Args:
        df: Input DataFrame
    """
    print("=" * 60)
    print("STEP 1: DATA EXPLORATION AND ANALYSIS")
    print("=" * 60)
    
    # Basic information
    print("\n1.1 Dataset Overview:")
    print(f"Shape: {df.shape}")
    print(f"Memory usage: {df.memory_usage(deep=True).sum() / 1024:.2f} KB")
    
    # Display first few rows
    print("\n1.2 First 5 Rows:")
    print(df.head())
    
    # Data types
    print("\n1.3 Data Types:")
    print(df.dtypes)
    
    # Missing values analysis
    print("\n1.4 Missing Values Analysis:")
    missing_counts = df.isnull().sum()
    missing_percentages = (missing_counts / len(df)) * 100
    missing_df = pd.DataFrame({
        'Missing Count': missing_counts,
        'Percentage': missing_percentages
    })
    print(missing_df[missing_df['Missing Count'] > 0])
    
    # Statistical summary for numerical features
    print("\n1.5 Numerical Features Statistics:")
    print(df.describe())
    
    # Categorical features analysis
    print("\n1.6 Categorical Features Distribution:")
    categorical_cols = df.select_dtypes(include=['object']).columns
    for col in categorical_cols:
        print(f"\n{col}:")
        print(df[col].value_counts())
    
    # Target variable distribution
    print("\n1.7 Target Variable Distribution:")
    target_counts = df['loan_approved'].value_counts()
    for value, count in target_counts.items():
        percentage = (count / len(df)) * 100
        print(f"  Class {value}: {count} samples ({percentage:.2f}%)")
    print()


def step2_handle_missing_values(df):
    """
    Step 2: Handle Missing Values
    -----------------------------
    Different strategies for handling missing data:
    - Mean/Median imputation for numerical features
    - Mode imputation for categorical features
    
    Args:
        df: Input DataFrame with missing values
    
    Returns:
        DataFrame: Dataset with imputed values
    """
    print("=" * 60)
    print("STEP 2: HANDLING MISSING VALUES")
    print("=" * 60)
    
    # Create a copy to avoid modifying original
    df_clean = df.copy()
    
    # Separate features and target
    X = df_clean.drop('loan_approved', axis=1)
    y = df_clean['loan_approved']
    
    # Identify numerical and categorical columns
    numerical_cols = X.select_dtypes(include=[np.number]).columns
    categorical_cols = X.select_dtypes(include=['object']).columns
    
    print("\n2.1 Missing Values Before Imputation:")
    print(X.isnull().sum())
    
    # Impute numerical features with median
    # Median is robust to outliers
    print("\n2.2 Imputing Numerical Features (using median):")
    numerical_imputer = SimpleImputer(strategy='median')
    X[numerical_cols] = numerical_imputer.fit_transform(X[numerical_cols])
    
    # Impute categorical features with most frequent value (mode)
    print("\n2.3 Imputing Categorical Features (using mode):")
    categorical_imputer = SimpleImputer(strategy='most_frequent')
    X[categorical_cols] = categorical_imputer.fit_transform(X[categorical_cols])
    
    print("\n2.4 Missing Values After Imputation:")
    print(X.isnull().sum())
    
    print("\nMissing value handling complete!")
    print()
    
    return X, y


def step3_encode_categorical_features(X):
    """
    Step 3: Encode Categorical Variables
    ------------------------------------
    Convert categorical features to numerical format.
    We use Label Encoding for ordinal features and One-Hot Encoding for nominal.
    
    Args:
        X: Feature DataFrame
    
    Returns:
        tuple: Encoded features and encoder objects
    """
    print("=" * 60)
    print("STEP 3: ENCODING CATEGORICAL FEATURES")
    print("=" * 60)
    
    X_encoded = X.copy()
    
    # Label Encoding for ordinal categorical feature (education has natural order)
    print("\n3.1 Label Encoding for 'education' (ordinal):")
    # Define the order: High School < Bachelor < Master < PhD
    education_mapping = {
        'High School': 0,
        'Bachelor': 1,
        'Master': 2,
        'PhD': 3
    }
    X_encoded['education'] = X_encoded['education'].map(education_mapping)
    print(f"Original values: {X['education'].unique()}")
    print(f"Encoded values: {X_encoded['education'].unique()}")
    
    # One-Hot Encoding for nominal categorical feature (employment has no order)
    print("\n3.2 One-Hot Encoding for 'employment' (nominal):")
    print(f"Original values: {X['employment'].unique()}")
    
    # Create dummy variables
    # drop_first=True to avoid multicollinearity (dummy variable trap)
    employment_dummies = pd.get_dummies(X_encoded['employment'], 
                                        prefix='employment', 
                                        drop_first=True)
    
    print(f"Created dummy columns: {employment_dummies.columns.tolist()}")
    
    # Add dummy variables to dataset
    X_encoded = pd.concat([X_encoded, employment_dummies], axis=1)
    
    # Drop original categorical column
    X_encoded = X_encoded.drop('employment', axis=1)
    
    print(f"\n3.3 Final encoded features: {X_encoded.columns.tolist()}")
    print(f"Shape: {X_encoded.shape}")
    print()
    
    return X_encoded


def step4_feature_scaling(X_train, X_test):
    """
    Step 4: Feature Scaling
    -----------------------
    Scale features to similar ranges to improve model performance.
    We demonstrate both StandardScaler and MinMaxScaler.
    
    Args:
        X_train: Training features
        X_test: Testing features
    
    Returns:
        tuple: Scaled training and testing features, scaler object
    """
    print("=" * 60)
    print("STEP 4: FEATURE SCALING")
    print("=" * 60)
    
    print("\n4.1 Feature Ranges Before Scaling:")
    print("Training set:")
    print(X_train.describe().loc[['min', 'max']])
    
    # Method 1: StandardScaler (Z-score normalization)
    # Transforms features to have mean=0 and std=1
    # Formula: z = (x - mean) / std
    print("\n4.2 Applying StandardScaler (Z-score normalization):")
    scaler = StandardScaler()
    
    # IMPORTANT: Fit on training data only!
    # Then transform both training and testing data
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Convert back to DataFrame for readability
    X_train_scaled = pd.DataFrame(X_train_scaled, 
                                   columns=X_train.columns,
                                   index=X_train.index)
    X_test_scaled = pd.DataFrame(X_test_scaled, 
                                  columns=X_test.columns,
                                  index=X_test.index)
    
    print("Feature Ranges After Scaling:")
    print("Training set:")
    print(X_train_scaled.describe().loc[['mean', 'std', 'min', 'max']])
    
    # Method 2: MinMaxScaler (for comparison, not used in this workflow)
    # Transforms features to range [0, 1]
    # Formula: x_scaled = (x - min) / (max - min)
    print("\n4.3 Alternative: MinMaxScaler (for reference):")
    minmax_scaler = MinMaxScaler()
    X_train_minmax = minmax_scaler.fit_transform(X_train)
    print(f"MinMaxScaler scales features to range [0, 1]")
    print(f"Min: {X_train_minmax.min()}, Max: {X_train_minmax.max()}")
    
    print("\nFeature scaling complete!")
    print()
    
    return X_train_scaled, X_test_scaled, scaler


def step5_train_model_with_hyperparameters(X_train, y_train):
    """
    Step 5: Train Model with Hyperparameters
    ----------------------------------------
    Train a more sophisticated model with carefully chosen hyperparameters.
    
    Args:
        X_train: Training features
        y_train: Training labels
    
    Returns:
        Trained model
    """
    print("=" * 60)
    print("STEP 5: TRAINING MODEL WITH HYPERPARAMETERS")
    print("=" * 60)
    
    # Use Random Forest - an ensemble of decision trees
    # More robust than a single decision tree
    print("\n5.1 Creating Random Forest Classifier:")
    model = RandomForestClassifier(
        n_estimators=100,      # Number of trees in the forest
        max_depth=10,          # Maximum depth of each tree
        min_samples_split=5,   # Minimum samples required to split a node
        min_samples_leaf=2,    # Minimum samples required at leaf node
        random_state=42,       # For reproducibility
        n_jobs=-1              # Use all available CPU cores
    )
    
    print("Model: Random Forest Classifier")
    print("Hyperparameters:")
    print(f"  - n_estimators: 100 trees")
    print(f"  - max_depth: 10")
    print(f"  - min_samples_split: 5")
    print(f"  - min_samples_leaf: 2")
    
    # Train the model
    print("\n5.2 Training model...")
    model.fit(X_train, y_train)
    print("Training complete!")
    
    # Feature importance analysis
    print("\n5.3 Feature Importance:")
    feature_importance = pd.DataFrame({
        'feature': X_train.columns,
        'importance': model.feature_importances_
    }).sort_values('importance', ascending=False)
    
    print(feature_importance)
    print()
    
    return model


def step6_comprehensive_evaluation(model, X_train, X_test, y_train, y_test):
    """
    Step 6: Comprehensive Model Evaluation
    --------------------------------------
    Evaluate model using multiple metrics to get a complete picture.
    
    Args:
        model: Trained model
        X_train: Training features
        X_test: Testing features
        y_train: Training labels
        y_test: Testing labels
    """
    print("=" * 60)
    print("STEP 6: COMPREHENSIVE MODEL EVALUATION")
    print("=" * 60)
    
    # Make predictions on both training and test sets
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    
    # 6.1 Basic Metrics
    print("\n6.1 Basic Metrics:")
    train_accuracy = accuracy_score(y_train, y_train_pred)
    test_accuracy = accuracy_score(y_test, y_test_pred)
    
    print(f"Training Accuracy: {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    print(f"Testing Accuracy:  {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    
    # Check for overfitting
    overfit_gap = train_accuracy - test_accuracy
    if overfit_gap > 0.05:
        print(f"⚠️  Warning: Possible overfitting (gap: {overfit_gap:.4f})")
    else:
        print(f"✓ Model generalizes well (gap: {overfit_gap:.4f})")
    
    # 6.2 Detailed Classification Metrics
    print("\n6.2 Detailed Classification Metrics:")
    
    # Precision: Of all positive predictions, how many were correct?
    # Precision = TP / (TP + FP)
    precision = precision_score(y_test, y_test_pred)
    print(f"Precision: {precision:.4f}")
    print("  → Of all predicted approvals, {:.2f}% were correct".format(precision*100))
    
    # Recall (Sensitivity): Of all actual positives, how many did we find?
    # Recall = TP / (TP + FN)
    recall = recall_score(y_test, y_test_pred)
    print(f"Recall:    {recall:.4f}")
    print("  → Of all actual approvals, {:.2f}% were identified".format(recall*100))
    
    # F1-Score: Harmonic mean of precision and recall
    # F1 = 2 * (Precision * Recall) / (Precision + Recall)
    f1 = f1_score(y_test, y_test_pred)
    print(f"F1-Score:  {f1:.4f}")
    print("  → Balanced measure of precision and recall")
    
    # 6.3 Confusion Matrix
    print("\n6.3 Confusion Matrix:")
    cm = confusion_matrix(y_test, y_test_pred)
    print("\n              Predicted")
    print("              Negative  Positive")
    print(f"Actual Negative   {cm[0,0]:<8}  {cm[0,1]:<8}")
    print(f"       Positive   {cm[1,0]:<8}  {cm[1,1]:<8}")
    
    # Interpret confusion matrix
    tn, fp, fn, tp = cm.ravel()
    print(f"\nTrue Negatives (TN):  {tn} - Correctly predicted rejections")
    print(f"False Positives (FP): {fp} - Incorrectly predicted approvals")
    print(f"False Negatives (FN): {fn} - Missed approvals")
    print(f"True Positives (TP):  {tp} - Correctly predicted approvals")
    
    # 6.4 Classification Report
    print("\n6.4 Complete Classification Report:")
    print(classification_report(y_test, y_test_pred, 
                                target_names=['Rejected', 'Approved']))
    
    # 6.5 Probability Predictions
    print("\n6.5 Prediction Probabilities (sample):")
    y_test_proba = model.predict_proba(X_test)[:10]
    print(f"{'Sample':<8} {'Prob(Reject)':<15} {'Prob(Approve)':<15} {'Prediction':<12} {'Actual':<10}")
    print("-" * 70)
    for i in range(10):
        pred = y_test_pred[i]
        actual = y_test.iloc[i]
        print(f"{i+1:<8} {y_test_proba[i][0]:<15.4f} {y_test_proba[i][1]:<15.4f} "
              f"{'Approve' if pred==1 else 'Reject':<12} {'Approve' if actual==1 else 'Reject':<10}")
    print()


def complete_intermediate_workflow():
    """
    Complete Intermediate ML Workflow
    ---------------------------------
    Demonstrates a realistic ML workflow with preprocessing steps.
    """
    print("\n" + "=" * 60)
    print("COMPLETE INTERMEDIATE MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    # Create sample dataset
    df = create_sample_dataset()
    
    # Step 1: Explore and analyze
    step1_explore_and_analyze(df)
    
    # Step 2: Handle missing values
    X, y = step2_handle_missing_values(df)
    
    # Step 3: Encode categorical features
    X_encoded = step3_encode_categorical_features(X)
    
    # Split data BEFORE scaling
    print("=" * 60)
    print("SPLITTING DATA (before scaling)")
    print("=" * 60)
    X_train, X_test, y_train, y_test = train_test_split(
        X_encoded, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Testing set:  {X_test.shape[0]} samples")
    print()
    
    # Step 4: Feature scaling
    X_train_scaled, X_test_scaled, scaler = step4_feature_scaling(X_train, X_test)
    
    # Step 5: Train model
    model = step5_train_model_with_hyperparameters(X_train_scaled, y_train)
    
    # Step 6: Comprehensive evaluation
    step6_comprehensive_evaluation(model, X_train_scaled, X_test_scaled, 
                                    y_train, y_test)
    
    print("=" * 60)
    print("INTERMEDIATE WORKFLOW COMPLETE!")
    print("=" * 60)
    print("\nKey Takeaways:")
    print("1. Real datasets require preprocessing (missing values, encoding, scaling)")
    print("2. Always fit preprocessors on training data, then transform test data")
    print("3. Use multiple evaluation metrics for comprehensive assessment")
    print("4. Check for overfitting by comparing train vs test performance")
    print("5. Feature importance helps understand model decisions")


if __name__ == "__main__":
    """
    Main execution block
    """
    complete_intermediate_workflow()
