"""
Machine Learning Workflow - Advanced Level
==========================================

This module covers advanced ML workflow techniques including:
- Scikit-learn Pipelines
- Cross-validation
- Hyperparameter tuning with Grid Search
- Model comparison
- Model persistence

Learning Objectives:
- Build end-to-end ML pipelines
- Perform k-fold cross-validation
- Tune hyperparameters systematically
- Compare multiple models
- Save and load trained models

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import (train_test_split, cross_val_score, 
                                      GridSearchCV, StratifiedKFold)
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, roc_auc_score, roc_curve,
                              classification_report, confusion_matrix)
import warnings
warnings.filterwarnings('ignore')


def load_and_prepare_data():
    """
    Load and prepare dataset for advanced workflow demonstration.
    
    Returns:
        tuple: Features, labels, and column information
    """
    print("=" * 70)
    print("LOADING AND PREPARING DATA")
    print("=" * 70)
    
    # Create a more complex dataset
    np.random.seed(42)
    n_samples = 2000
    
    # Features
    age = np.random.randint(18, 70, n_samples)
    income = np.random.randint(20000, 200000, n_samples)
    credit_score = np.random.randint(300, 850, n_samples)
    debt_ratio = np.random.uniform(0, 1, n_samples)
    years_employed = np.random.randint(0, 30, n_samples)
    
    education = np.random.choice(['HS', 'Bachelor', 'Master', 'PhD'], n_samples)
    home_ownership = np.random.choice(['Rent', 'Own', 'Mortgage'], n_samples)
    loan_purpose = np.random.choice(['Personal', 'Business', 'Education', 'Home'], n_samples)
    
    # Create target with complex relationship
    target_score = (
        (income / 1000) * 0.002 +
        (credit_score / 100) * 0.15 +
        (1 - debt_ratio) * 0.3 +
        (years_employed) * 0.02 +
        (age / 100) * 0.1 +
        np.random.normal(0, 0.1, n_samples)
    )
    loan_approved = (target_score > np.median(target_score)).astype(int)
    
    # Create DataFrame
    df = pd.DataFrame({
        'age': age,
        'income': income,
        'credit_score': credit_score,
        'debt_ratio': debt_ratio,
        'years_employed': years_employed,
        'education': education,
        'home_ownership': home_ownership,
        'loan_purpose': loan_purpose,
        'approved': loan_approved
    })
    
    # Introduce missing values
    for col in ['income', 'credit_score', 'debt_ratio']:
        missing_idx = np.random.choice(df.index, size=int(0.05 * n_samples), replace=False)
        df.loc[missing_idx, col] = np.nan
    
    print(f"Dataset created: {df.shape[0]} samples, {df.shape[1]-1} features")
    print(f"Missing values: {df.isnull().sum().sum()}")
    print(f"Target distribution: {loan_approved.sum()} approved, {len(loan_approved) - loan_approved.sum()} rejected")
    print()
    
    # Separate features and target
    X = df.drop('approved', axis=1)
    y = df['approved']
    
    # Define column types for preprocessing
    numerical_features = ['age', 'income', 'credit_score', 'debt_ratio', 'years_employed']
    categorical_features = ['education', 'home_ownership', 'loan_purpose']
    
    return X, y, numerical_features, categorical_features


def step1_build_preprocessing_pipeline(numerical_features, categorical_features):
    """
    Step 1: Build Preprocessing Pipeline
    ------------------------------------
    Create a pipeline that handles all preprocessing steps automatically.
    
    Pipelines ensure:
    - Consistent preprocessing
    - No data leakage
    - Easy deployment
    - Reproducible results
    
    Args:
        numerical_features: List of numerical column names
        categorical_features: List of categorical column names
    
    Returns:
        ColumnTransformer: Preprocessing pipeline
    """
    print("=" * 70)
    print("STEP 1: BUILDING PREPROCESSING PIPELINE")
    print("=" * 70)
    
    # Numerical pipeline
    # 1. Impute missing values with median
    # 2. Scale features to zero mean and unit variance
    print("\n1.1 Numerical Pipeline:")
    print("  - SimpleImputer (strategy='median')")
    print("  - StandardScaler()")
    
    numerical_pipeline = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    
    # Categorical pipeline
    # 1. Impute missing values with most frequent value
    # 2. One-hot encode categories
    print("\n1.2 Categorical Pipeline:")
    print("  - SimpleImputer (strategy='most_frequent')")
    print("  - OneHotEncoder (handle_unknown='ignore', sparse_output=False)")
    
    categorical_pipeline = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    
    # Combine both pipelines using ColumnTransformer
    # This applies different preprocessing to different columns
    print("\n1.3 Combined Preprocessing Pipeline:")
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_pipeline, numerical_features),
            ('cat', categorical_pipeline, categorical_features)
        ],
        remainder='drop'  # Drop any columns not specified
    )
    
    print("  - Numerical features:", numerical_features)
    print("  - Categorical features:", categorical_features)
    print("\nPreprocessing pipeline created!")
    print()
    
    return preprocessor


def step2_create_full_pipeline(preprocessor, model):
    """
    Step 2: Create Full ML Pipeline
    -------------------------------
    Combine preprocessing and model into a single pipeline.
    
    Args:
        preprocessor: Preprocessing pipeline
        model: ML model
    
    Returns:
        Pipeline: Complete ML pipeline
    """
    print("=" * 70)
    print("STEP 2: CREATING FULL ML PIPELINE")
    print("=" * 70)
    
    # Create end-to-end pipeline
    # Preprocessing → Model
    full_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('classifier', model)
    ])
    
    print("\nFull Pipeline Structure:")
    print("  1. Preprocessor (handles missing values, scaling, encoding)")
    print("  2. Classifier (machine learning model)")
    print("\nAdvantages of pipelines:")
    print("  - Single fit/predict call for entire workflow")
    print("  - Prevents data leakage")
    print("  - Easy to deploy")
    print("  - Reproducible")
    print()
    
    return full_pipeline


def step3_cross_validation(pipeline, X, y):
    """
    Step 3: Cross-Validation
    ------------------------
    Evaluate model using k-fold cross-validation for robust performance estimate.
    
    Cross-validation:
    - Splits data into k folds
    - Trains on k-1 folds, tests on remaining fold
    - Repeats k times
    - Reports average performance
    
    Args:
        pipeline: ML pipeline
        X: Features
        y: Labels
    
    Returns:
        dict: Cross-validation scores
    """
    print("=" * 70)
    print("STEP 3: CROSS-VALIDATION")
    print("=" * 70)
    
    # Define stratified k-fold cross-validation
    # Stratified ensures each fold has same class distribution
    print("\n3.1 Setting up 5-Fold Stratified Cross-Validation:")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    print("  - Number of folds: 5")
    print("  - Stratified: Yes (maintains class distribution)")
    print("  - Shuffle: Yes (randomize before splitting)")
    
    # Perform cross-validation with multiple metrics
    print("\n3.2 Performing Cross-Validation...")
    
    # Accuracy
    accuracy_scores = cross_val_score(pipeline, X, y, cv=cv, 
                                       scoring='accuracy', n_jobs=-1)
    
    # Precision
    precision_scores = cross_val_score(pipeline, X, y, cv=cv,
                                        scoring='precision', n_jobs=-1)
    
    # Recall
    recall_scores = cross_val_score(pipeline, X, y, cv=cv,
                                     scoring='recall', n_jobs=-1)
    
    # F1-Score
    f1_scores = cross_val_score(pipeline, X, y, cv=cv,
                                 scoring='f1', n_jobs=-1)
    
    # ROC-AUC
    roc_auc_scores = cross_val_score(pipeline, X, y, cv=cv,
                                      scoring='roc_auc', n_jobs=-1)
    
    print("\n3.3 Cross-Validation Results:")
    print(f"{'Metric':<15} {'Mean':<10} {'Std':<10} {'Min':<10} {'Max':<10}")
    print("-" * 55)
    
    metrics = {
        'Accuracy': accuracy_scores,
        'Precision': precision_scores,
        'Recall': recall_scores,
        'F1-Score': f1_scores,
        'ROC-AUC': roc_auc_scores
    }
    
    cv_results = {}
    for metric_name, scores in metrics.items():
        mean_score = scores.mean()
        std_score = scores.std()
        min_score = scores.min()
        max_score = scores.max()
        
        print(f"{metric_name:<15} {mean_score:<10.4f} {std_score:<10.4f} "
              f"{min_score:<10.4f} {max_score:<10.4f}")
        
        cv_results[metric_name] = {
            'mean': mean_score,
            'std': std_score,
            'scores': scores
        }
    
    # Interpretation
    print("\n3.4 Interpretation:")
    if cv_results['Accuracy']['std'] < 0.05:
        print("  ✓ Low standard deviation indicates stable model performance")
    else:
        print("  ⚠️  High standard deviation suggests performance varies across folds")
    
    print()
    return cv_results


def step4_hyperparameter_tuning(preprocessor, X_train, y_train):
    """
    Step 4: Hyperparameter Tuning with Grid Search
    ----------------------------------------------
    Systematically search for optimal hyperparameters.
    
    Args:
        preprocessor: Preprocessing pipeline
        X_train: Training features
        y_train: Training labels
    
    Returns:
        Best model from grid search
    """
    print("=" * 70)
    print("STEP 4: HYPERPARAMETER TUNING WITH GRID SEARCH")
    print("=" * 70)
    
    # Create pipeline with Random Forest
    pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(random_state=42, n_jobs=-1))
    ])
    
    # Define parameter grid
    # We'll search through different combinations
    print("\n4.1 Parameter Grid:")
    param_grid = {
        'classifier__n_estimators': [50, 100, 200],           # Number of trees
        'classifier__max_depth': [5, 10, 15, None],           # Tree depth
        'classifier__min_samples_split': [2, 5, 10],          # Min samples to split
        'classifier__min_samples_leaf': [1, 2, 4]             # Min samples at leaf
    }
    
    for param, values in param_grid.items():
        print(f"  {param}: {values}")
    
    total_combinations = np.prod([len(v) for v in param_grid.values()])
    print(f"\nTotal combinations to test: {total_combinations}")
    
    # Setup Grid Search with cross-validation
    print("\n4.2 Setting up GridSearchCV:")
    print("  - Cross-validation folds: 3")
    print("  - Scoring metric: F1-score")
    print("  - Using all CPU cores")
    
    grid_search = GridSearchCV(
        pipeline,
        param_grid,
        cv=3,                      # 3-fold CV for each combination
        scoring='f1',              # Optimize for F1-score
        n_jobs=-1,                 # Use all cores
        verbose=1,                 # Show progress
        return_train_score=True
    )
    
    # Perform grid search
    print("\n4.3 Performing Grid Search...")
    print("This may take a few minutes...\n")
    grid_search.fit(X_train, y_train)
    
    # Display results
    print("\n4.4 Grid Search Results:")
    print(f"Best F1-score: {grid_search.best_score_:.4f}")
    print(f"\nBest Parameters:")
    for param, value in grid_search.best_params_.items():
        print(f"  {param}: {value}")
    
    # Show top 5 parameter combinations
    print("\n4.5 Top 5 Parameter Combinations:")
    results_df = pd.DataFrame(grid_search.cv_results_)
    results_df = results_df.sort_values('rank_test_score')
    
    print(f"{'Rank':<6} {'Mean Test F1':<15} {'Std Test F1':<15} {'Parameters':<50}")
    print("-" * 90)
    
    for idx, row in results_df.head().iterrows():
        rank = int(row['rank_test_score'])
        mean_score = row['mean_test_score']
        std_score = row['std_test_score']
        params_str = str(row['params'])[:47] + "..."
        print(f"{rank:<6} {mean_score:<15.4f} {std_score:<15.4f} {params_str:<50}")
    
    print()
    return grid_search.best_estimator_


def step5_compare_models(preprocessor, X_train, X_test, y_train, y_test):
    """
    Step 5: Compare Multiple Models
    -------------------------------
    Train and evaluate different types of models.
    
    Args:
        preprocessor: Preprocessing pipeline
        X_train, X_test: Training and testing features
        y_train, y_test: Training and testing labels
    
    Returns:
        dict: Comparison results
    """
    print("=" * 70)
    print("STEP 5: COMPARING MULTIPLE MODELS")
    print("=" * 70)
    
    # Define multiple models to compare
    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
        'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
        'SVM': SVC(probability=True, random_state=42)
    }
    
    print(f"\n5.1 Models to Compare: {len(models)}")
    for model_name in models.keys():
        print(f"  - {model_name}")
    
    # Train and evaluate each model
    print("\n5.2 Training and Evaluating Models...\n")
    
    results = {}
    for model_name, model in models.items():
        print(f"Training {model_name}...")
        
        # Create pipeline
        pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('classifier', model)
        ])
        
        # Train
        pipeline.fit(X_train, y_train)
        
        # Predict
        y_pred = pipeline.predict(X_test)
        y_proba = pipeline.predict_proba(X_test)[:, 1]
        
        # Calculate metrics
        results[model_name] = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred),
            'recall': recall_score(y_test, y_pred),
            'f1': f1_score(y_test, y_pred),
            'roc_auc': roc_auc_score(y_test, y_proba)
        }
    
    # Display comparison table
    print("\n5.3 Model Comparison Results:")
    print(f"{'Model':<20} {'Accuracy':<12} {'Precision':<12} {'Recall':<12} "
          f"{'F1':<12} {'ROC-AUC':<12}")
    print("-" * 80)
    
    for model_name, metrics in results.items():
        print(f"{model_name:<20} "
              f"{metrics['accuracy']:<12.4f} "
              f"{metrics['precision']:<12.4f} "
              f"{metrics['recall']:<12.4f} "
              f"{metrics['f1']:<12.4f} "
              f"{metrics['roc_auc']:<12.4f}")
    
    # Find best model
    best_model = max(results.items(), key=lambda x: x[1]['f1'])
    print(f"\n5.4 Best Model: {best_model[0]} (F1-score: {best_model[1]['f1']:.4f})")
    print()
    
    return results


def step6_save_and_load_model(model, X_test, y_test):
    """
    Step 6: Save and Load Model
    ---------------------------
    Demonstrate model persistence for deployment.
    
    Args:
        model: Trained model
        X_test: Test features
        y_test: Test labels
    """
    print("=" * 70)
    print("STEP 6: MODEL PERSISTENCE (SAVE AND LOAD)")
    print("=" * 70)
    
    # Save model
    model_filename = '/home/claude/ml_workflow_package/trained_model.joblib'
    print(f"\n6.1 Saving model to: {model_filename}")
    joblib.dump(model, model_filename)
    print("  ✓ Model saved successfully!")
    
    # Load model
    print(f"\n6.2 Loading model from: {model_filename}")
    loaded_model = joblib.load(model_filename)
    print("  ✓ Model loaded successfully!")
    
    # Verify loaded model works
    print("\n6.3 Verifying Loaded Model:")
    y_pred = loaded_model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"  Accuracy: {accuracy:.4f}")
    print("  ✓ Loaded model produces correct predictions!")
    
    # Show model size
    import os
    model_size = os.path.getsize(model_filename) / (1024 * 1024)  # Convert to MB
    print(f"\n6.4 Model Information:")
    print(f"  File size: {model_size:.2f} MB")
    print(f"  Format: joblib (compressed pickle)")
    print()


def complete_advanced_workflow():
    """
    Complete Advanced ML Workflow
    -----------------------------
    Demonstrates production-ready ML workflow with best practices.
    """
    print("\n" + "=" * 70)
    print("COMPLETE ADVANCED MACHINE LEARNING WORKFLOW")
    print("=" * 70 + "\n")
    
    # Load data
    X, y, numerical_features, categorical_features = load_and_prepare_data()
    
    # Split data first
    print("=" * 70)
    print("SPLITTING DATA")
    print("=" * 70)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Training set: {X_train.shape[0]} samples ({X_train.shape[0]/len(X)*100:.1f}%)")
    print(f"Testing set:  {X_test.shape[0]} samples ({X_test.shape[0]/len(X)*100:.1f}%)")
    print()
    
    # Step 1: Build preprocessing pipeline
    preprocessor = step1_build_preprocessing_pipeline(numerical_features, 
                                                       categorical_features)
    
    # Step 2: Create full pipeline (for cross-validation)
    initial_model = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    pipeline = step2_create_full_pipeline(preprocessor, initial_model)
    
    # Step 3: Cross-validation (on training data only)
    cv_results = step3_cross_validation(pipeline, X_train, y_train)
    
    # Step 4: Hyperparameter tuning (on training data only)
    best_model = step4_hyperparameter_tuning(preprocessor, X_train, y_train)
    
    # Step 5: Compare models (using train/test split)
    model_comparison = step5_compare_models(preprocessor, X_train, X_test, 
                                             y_train, y_test)
    
    # Step 6: Save and load final model
    step6_save_and_load_model(best_model, X_test, y_test)
    
    print("=" * 70)
    print("ADVANCED WORKFLOW COMPLETE!")
    print("=" * 70)
    print("\nKey Takeaways:")
    print("1. Pipelines automate preprocessing and prevent data leakage")
    print("2. Cross-validation provides robust performance estimates")
    print("3. Grid search systematically finds optimal hyperparameters")
    print("4. Always compare multiple models before choosing")
    print("5. Save trained models for deployment")
    print("6. Never use test data for any training decisions!")


if __name__ == "__main__":
    """
    Main execution block
    """
    complete_advanced_workflow()
