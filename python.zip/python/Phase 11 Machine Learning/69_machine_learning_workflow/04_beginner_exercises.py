"""
Machine Learning Workflow - Beginner Exercises
==============================================

Practice exercises for understanding basic ML workflow.
Complete the TODO sections to build your understanding.

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.datasets import load_wine, load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# EXERCISE 1: Load and Explore the Wine Dataset
# =============================================================================
def exercise1_load_wine():
    """
    Exercise 1: Load and Explore Data
    ---------------------------------
    
    Tasks:
    1. Load the wine dataset from sklearn
    2. Print the number of samples and features
    3. Print the number of classes
    4. Display the first 5 samples
    
    Hint: Use load_wine() from sklearn.datasets
    """
    print("=" * 60)
    print("EXERCISE 1: Load and Explore Wine Dataset")
    print("=" * 60)
    
    # TODO: Load the wine dataset
    # wine = load_wine()
    # X = ...
    # y = ...
    
    # TODO: Print dataset information
    # Number of samples: ?
    # Number of features: ?
    # Number of classes: ?
    
    # TODO: Convert to DataFrame and display first 5 samples
    # df = pd.DataFrame(...)
    # print(df.head())
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 2: Split Data with Different Ratios
# =============================================================================
def exercise2_split_data():
    """
    Exercise 2: Data Splitting
    --------------------------
    
    Tasks:
    1. Load the breast cancer dataset
    2. Split the data with 70% training, 30% testing
    3. Print the size of each set
    4. Split again with 80% training, 20% testing
    5. Compare the sizes
    
    Questions to answer:
    - How does the split ratio affect dataset sizes?
    - When might you use different split ratios?
    """
    print("=" * 60)
    print("EXERCISE 2: Data Splitting with Different Ratios")
    print("=" * 60)
    
    # Load dataset
    cancer = load_breast_cancer()
    X, y = cancer.data, cancer.target
    print(f"Total samples: {X.shape[0]}\n")
    
    # TODO: Split 1 - 70/30 split
    # X_train1, X_test1, y_train1, y_test1 = train_test_split(...)
    
    print("Split 1 (70/30):")
    # TODO: Print sizes
    
    # TODO: Split 2 - 80/20 split
    # X_train2, X_test2, y_train2, y_test2 = train_test_split(...)
    
    print("\nSplit 2 (80/20):")
    # TODO: Print sizes
    
    # TODO: Answer the questions
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 3: Train Different Models
# =============================================================================
def exercise3_train_models():
    """
    Exercise 3: Train and Compare Models
    ------------------------------------
    
    Tasks:
    1. Load the wine dataset
    2. Split into train/test (80/20)
    3. Train a Decision Tree classifier
    4. Train a K-Nearest Neighbors classifier
    5. Compare their accuracies
    
    Questions:
    - Which model performs better?
    - Why might one model outperform another?
    """
    print("=" * 60)
    print("EXERCISE 3: Train and Compare Different Models")
    print("=" * 60)
    
    # Load and split data
    wine = load_wine()
    X, y = wine.data, wine.target
    
    # TODO: Split the data
    # X_train, X_test, y_train, y_test = ...
    
    # TODO: Train Decision Tree
    # dt_model = DecisionTreeClassifier(...)
    # dt_model.fit(...)
    # dt_pred = ...
    # dt_accuracy = ...
    
    print("Decision Tree Results:")
    # TODO: Print accuracy
    
    # TODO: Train K-Nearest Neighbors (k=5)
    # knn_model = KNeighborsClassifier(...)
    # knn_model.fit(...)
    # knn_pred = ...
    # knn_accuracy = ...
    
    print("\nK-Nearest Neighbors Results:")
    # TODO: Print accuracy
    
    # TODO: Compare models
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 4: Analyze Classification Report
# =============================================================================
def exercise4_classification_metrics():
    """
    Exercise 4: Understanding Classification Metrics
    -----------------------------------------------
    
    Tasks:
    1. Load breast cancer dataset
    2. Train a classifier
    3. Generate predictions
    4. Print and interpret the classification report
    
    Questions to answer:
    - What does precision mean in this context?
    - What does recall mean?
    - What is F1-score?
    - Which metric is most important for cancer detection? Why?
    """
    print("=" * 60)
    print("EXERCISE 4: Classification Metrics Analysis")
    print("=" * 60)
    
    # Load dataset
    cancer = load_breast_cancer()
    X, y = cancer.data, cancer.target
    
    # TODO: Split data (80/20)
    # X_train, X_test, y_train, y_test = ...
    
    # TODO: Train a model
    # model = DecisionTreeClassifier(max_depth=5, random_state=42)
    # model.fit(...)
    
    # TODO: Make predictions
    # y_pred = ...
    
    # TODO: Print classification report
    # print(classification_report(y_test, y_pred, 
    #                             target_names=cancer.target_names))
    
    # TODO: Answer the questions
    """
    Precision: ...
    Recall: ...
    F1-Score: ...
    Most important metric for cancer detection: ... because ...
    """
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 5: Complete Workflow Challenge
# =============================================================================
def exercise5_complete_workflow():
    """
    Exercise 5: Complete ML Workflow Challenge
    -----------------------------------------
    
    Build a complete ML workflow from scratch:
    
    1. Load the wine dataset
    2. Explore the data (print basic statistics)
    3. Split into train/test (75/25)
    4. Train a Decision Tree classifier with max_depth=5
    5. Make predictions on test set
    6. Calculate and display:
       - Accuracy
       - Detailed classification report
    7. Show 10 sample predictions vs actual values
    
    Challenge: Try to achieve accuracy > 0.90
    """
    print("=" * 60)
    print("EXERCISE 5: Complete ML Workflow Challenge")
    print("=" * 60)
    
    # TODO: Step 1 - Load data
    print("\nStep 1: Loading data...")
    
    # TODO: Step 2 - Explore data
    print("\nStep 2: Exploring data...")
    
    # TODO: Step 3 - Split data
    print("\nStep 3: Splitting data...")
    
    # TODO: Step 4 - Train model
    print("\nStep 4: Training model...")
    
    # TODO: Step 5 - Make predictions
    print("\nStep 5: Making predictions...")
    
    # TODO: Step 6 - Evaluate model
    print("\nStep 6: Evaluating model...")
    
    # TODO: Step 7 - Show sample predictions
    print("\nStep 7: Sample predictions...")
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# BONUS EXERCISE: Effect of Random State
# =============================================================================
def bonus_exercise_random_state():
    """
    Bonus Exercise: Understanding Random State
    -----------------------------------------
    
    Tasks:
    1. Load wine dataset
    2. Split and train with random_state=42
    3. Record the accuracy
    4. Split and train with random_state=100
    5. Record the accuracy
    6. Split and train with random_state=None (different each time)
    7. Compare results
    
    Questions:
    - Why do we use random_state?
    - When should we use random_state=None?
    - How much does accuracy vary with different random states?
    """
    print("=" * 60)
    print("BONUS: Understanding Random State")
    print("=" * 60)
    
    wine = load_wine()
    X, y = wine.data, wine.target
    
    # TODO: Test with random_state=42
    print("\nTest 1: random_state=42")
    # ...
    
    # TODO: Test with random_state=100
    print("\nTest 2: random_state=100")
    # ...
    
    # TODO: Test with random_state=None (try 3 times)
    print("\nTest 3: random_state=None (run 3 times)")
    # for i in range(3):
    #     ...
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


def run_all_exercises():
    """
    Run all exercises
    """
    print("\n" + "=" * 60)
    print("BEGINNER EXERCISES - MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    exercise1_load_wine()
    exercise2_split_data()
    exercise3_train_models()
    exercise4_classification_metrics()
    exercise5_complete_workflow()
    bonus_exercise_random_state()
    
    print("=" * 60)
    print("EXERCISES COMPLETE!")
    print("=" * 60)
    print("\nNext Steps:")
    print("1. Check your solutions against the solution file")
    print("2. Experiment with different parameters")
    print("3. Try other datasets from sklearn.datasets")
    print("4. Move on to intermediate exercises")


if __name__ == "__main__":
    """
    Main execution
    """
    run_all_exercises()
