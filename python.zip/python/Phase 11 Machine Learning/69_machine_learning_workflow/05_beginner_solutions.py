"""
Machine Learning Workflow - Beginner Exercises SOLUTIONS
========================================================

Complete solutions for beginner exercises.
Study these solutions to understand the correct implementation.

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.datasets import load_wine, load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# SOLUTION 1: Load and Explore the Wine Dataset
# =============================================================================
def solution1_load_wine():
    """
    Solution 1: Load and Explore Data
    """
    print("=" * 60)
    print("SOLUTION 1: Load and Explore Wine Dataset")
    print("=" * 60)
    
    # Load the wine dataset
    wine = load_wine()
    X = wine.data
    y = wine.target
    
    # Print dataset information
    print(f"\nDataset: Wine Recognition")
    print(f"Number of samples: {X.shape[0]}")
    print(f"Number of features: {X.shape[1]}")
    print(f"Number of classes: {len(np.unique(y))}")
    print(f"Feature names: {wine.feature_names[:3]}... (showing first 3)")
    print(f"Target names: {wine.target_names}")
    
    # Convert to DataFrame and display first 5 samples
    df = pd.DataFrame(X, columns=wine.feature_names)
    df['target'] = y
    print("\nFirst 5 samples:")
    print(df.head())
    print()


# =============================================================================
# SOLUTION 2: Split Data with Different Ratios
# =============================================================================
def solution2_split_data():
    """
    Solution 2: Data Splitting
    """
    print("=" * 60)
    print("SOLUTION 2: Data Splitting with Different Ratios")
    print("=" * 60)
    
    # Load dataset
    cancer = load_breast_cancer()
    X, y = cancer.data, cancer.target
    print(f"Total samples: {X.shape[0]}\n")
    
    # Split 1 - 70/30 split
    X_train1, X_test1, y_train1, y_test1 = train_test_split(
        X, y, test_size=0.30, random_state=42
    )
    
    print("Split 1 (70/30):")
    print(f"  Training samples: {X_train1.shape[0]} ({X_train1.shape[0]/X.shape[0]*100:.1f}%)")
    print(f"  Testing samples:  {X_test1.shape[0]} ({X_test1.shape[0]/X.shape[0]*100:.1f}%)")
    
    # Split 2 - 80/20 split
    X_train2, X_test2, y_train2, y_test2 = train_test_split(
        X, y, test_size=0.20, random_state=42
    )
    
    print("\nSplit 2 (80/20):")
    print(f"  Training samples: {X_train2.shape[0]} ({X_train2.shape[0]/X.shape[0]*100:.1f}%)")
    print(f"  Testing samples:  {X_test2.shape[0]} ({X_test2.shape[0]/X.shape[0]*100:.1f}%)")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS:")
    print("-" * 60)
    print("How does split ratio affect dataset sizes?")
    print("  → Larger training sets provide more data for learning")
    print("  → Smaller test sets may give less reliable evaluation")
    print("\nWhen to use different split ratios?")
    print("  → 80/20 or 70/30: Standard for medium-large datasets")
    print("  → 90/10: When data is very large")
    print("  → 60/40: When data is small and need robust testing")
    print()


# =============================================================================
# SOLUTION 3: Train Different Models
# =============================================================================
def solution3_train_models():
    """
    Solution 3: Train and Compare Models
    """
    print("=" * 60)
    print("SOLUTION 3: Train and Compare Different Models")
    print("=" * 60)
    
    # Load and split data
    wine = load_wine()
    X, y = wine.data, wine.target
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"Training samples: {X_train.shape[0]}")
    print(f"Testing samples:  {X_test.shape[0]}\n")
    
    # Train Decision Tree
    dt_model = DecisionTreeClassifier(max_depth=5, random_state=42)
    dt_model.fit(X_train, y_train)
    dt_pred = dt_model.predict(X_test)
    dt_accuracy = accuracy_score(y_test, dt_pred)
    
    print("Decision Tree Results:")
    print(f"  Accuracy: {dt_accuracy:.4f} ({dt_accuracy*100:.2f}%)")
    
    # Train K-Nearest Neighbors
    knn_model = KNeighborsClassifier(n_neighbors=5)
    knn_model.fit(X_train, y_train)
    knn_pred = knn_model.predict(X_test)
    knn_accuracy = accuracy_score(y_test, knn_pred)
    
    print("\nK-Nearest Neighbors Results:")
    print(f"  Accuracy: {knn_accuracy:.4f} ({knn_accuracy*100:.2f}%)")
    
    # Compare models
    print("\n" + "-" * 60)
    print("MODEL COMPARISON:")
    print("-" * 60)
    if dt_accuracy > knn_accuracy:
        print(f"Decision Tree performs better by {(dt_accuracy-knn_accuracy)*100:.2f}%")
        print("\nPossible reasons:")
        print("  → Decision trees handle non-linear relationships well")
        print("  → Wine features may have clear decision boundaries")
    else:
        print(f"K-NN performs better by {(knn_accuracy-dt_accuracy)*100:.2f}%")
        print("\nPossible reasons:")
        print("  → Similar wines are close in feature space")
        print("  → K-NN captures local patterns effectively")
    print()


# =============================================================================
# SOLUTION 4: Analyze Classification Report
# =============================================================================
def solution4_classification_metrics():
    """
    Solution 4: Understanding Classification Metrics
    """
    print("=" * 60)
    print("SOLUTION 4: Classification Metrics Analysis")
    print("=" * 60)
    
    # Load dataset
    cancer = load_breast_cancer()
    X, y = cancer.data, cancer.target
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Train model
    model = DecisionTreeClassifier(max_depth=5, random_state=42)
    model.fit(X_train, y_train)
    
    # Make predictions
    y_pred = model.predict(X_test)
    
    # Print classification report
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, 
                                target_names=cancer.target_names))
    
    # Detailed explanations
    print("-" * 60)
    print("METRIC EXPLANATIONS:")
    print("-" * 60)
    
    print("\n1. PRECISION:")
    print("   Definition: Of all predicted positive cases, how many are actually positive?")
    print("   Formula: TP / (TP + FP)")
    print("   Context: If precision is 0.95 for 'malignant', then 95% of")
    print("            predicted malignant tumors are actually malignant")
    
    print("\n2. RECALL (Sensitivity):")
    print("   Definition: Of all actual positive cases, how many did we find?")
    print("   Formula: TP / (TP + FN)")
    print("   Context: If recall is 0.90 for 'malignant', then we detected")
    print("            90% of all actual malignant tumors")
    
    print("\n3. F1-SCORE:")
    print("   Definition: Harmonic mean of precision and recall")
    print("   Formula: 2 * (Precision * Recall) / (Precision + Recall)")
    print("   Context: Balanced measure when you need both metrics")
    
    print("\n4. MOST IMPORTANT METRIC FOR CANCER DETECTION:")
    print("   → RECALL is most critical!")
    print("   → Reason: Missing a malignant tumor (false negative) is much")
    print("             worse than a false alarm (false positive)")
    print("   → We want to catch ALL cancer cases, even if it means some")
    print("             false alarms that can be verified with more tests")
    print()


# =============================================================================
# SOLUTION 5: Complete Workflow Challenge
# =============================================================================
def solution5_complete_workflow():
    """
    Solution 5: Complete ML Workflow Challenge
    """
    print("=" * 60)
    print("SOLUTION 5: Complete ML Workflow Challenge")
    print("=" * 60)
    
    # Step 1 - Load data
    print("\nStep 1: Loading data...")
    wine = load_wine()
    X, y = wine.data, wine.target
    print(f"  ✓ Loaded {X.shape[0]} samples with {X.shape[1]} features")
    
    # Step 2 - Explore data
    print("\nStep 2: Exploring data...")
    df = pd.DataFrame(X, columns=wine.feature_names)
    print(f"  Basic Statistics (first 3 features):")
    print(df.iloc[:, :3].describe())
    print(f"  Class distribution: {np.bincount(y)}")
    
    # Step 3 - Split data
    print("\nStep 3: Splitting data...")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    print(f"  Training set: {X_train.shape[0]} samples")
    print(f"  Testing set:  {X_test.shape[0]} samples")
    
    # Step 4 - Train model
    print("\nStep 4: Training model...")
    model = DecisionTreeClassifier(max_depth=5, random_state=42)
    model.fit(X_train, y_train)
    print(f"  ✓ Model trained: Decision Tree (max_depth=5)")
    
    # Step 5 - Make predictions
    print("\nStep 5: Making predictions...")
    y_pred = model.predict(X_test)
    print(f"  ✓ Generated predictions for {len(y_pred)} test samples")
    
    # Step 6 - Evaluate model
    print("\nStep 6: Evaluating model...")
    accuracy = accuracy_score(y_test, y_pred)
    print(f"  Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    if accuracy > 0.90:
        print(f"  🎉 Challenge completed! Achieved {accuracy*100:.2f}% > 90%")
    else:
        print(f"  ⚠️  Accuracy {accuracy*100:.2f}% < 90%. Try adjusting max_depth!")
    
    print("\n  Detailed Report:")
    print(classification_report(y_test, y_pred, target_names=wine.target_names))
    
    # Step 7 - Show sample predictions
    print("\nStep 7: Sample predictions...")
    print(f"{'Sample':<8} {'Predicted':<15} {'Actual':<15} {'Match':<8}")
    print("-" * 50)
    for i in range(min(10, len(y_test))):
        pred_name = wine.target_names[y_pred[i]]
        actual_name = wine.target_names[y_test[i]]
        match = "✓" if y_pred[i] == y_test[i] else "✗"
        print(f"{i+1:<8} {pred_name:<15} {actual_name:<15} {match:<8}")
    print()


# =============================================================================
# BONUS SOLUTION: Effect of Random State
# =============================================================================
def bonus_solution_random_state():
    """
    Bonus Solution: Understanding Random State
    """
    print("=" * 60)
    print("BONUS SOLUTION: Understanding Random State")
    print("=" * 60)
    
    wine = load_wine()
    X, y = wine.data, wine.target
    
    # Test with random_state=42
    print("\nTest 1: random_state=42")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    model = DecisionTreeClassifier(max_depth=5, random_state=42)
    model.fit(X_train, y_train)
    accuracy1 = accuracy_score(y_test, model.predict(X_test))
    print(f"  Accuracy: {accuracy1:.4f}")
    
    # Test with random_state=100
    print("\nTest 2: random_state=100")
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=100
    )
    model = DecisionTreeClassifier(max_depth=5, random_state=100)
    model.fit(X_train, y_train)
    accuracy2 = accuracy_score(y_test, model.predict(X_test))
    print(f"  Accuracy: {accuracy2:.4f}")
    print(f"  Difference from Test 1: {abs(accuracy2-accuracy1):.4f}")
    
    # Test with random_state=None (3 times)
    print("\nTest 3: random_state=None (run 3 times)")
    accuracies = []
    for i in range(3):
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=None
        )
        model = DecisionTreeClassifier(max_depth=5, random_state=None)
        model.fit(X_train, y_train)
        acc = accuracy_score(y_test, model.predict(X_test))
        accuracies.append(acc)
        print(f"  Run {i+1}: {acc:.4f}")
    
    print(f"\n  Mean accuracy: {np.mean(accuracies):.4f}")
    print(f"  Std deviation: {np.std(accuracies):.4f}")
    print(f"  Range: {max(accuracies) - min(accuracies):.4f}")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS:")
    print("-" * 60)
    print("Why use random_state?")
    print("  → Ensures reproducible results")
    print("  → Critical for debugging and comparison")
    print("  → Allows others to verify your work")
    
    print("\nWhen to use random_state=None?")
    print("  → When testing model robustness")
    print("  → To estimate performance variance")
    print("  → In production for diverse training")
    
    print("\nAccuracy variance:")
    print(f"  → With fixed random_state: {abs(accuracy2-accuracy1):.4f}")
    print(f"  → With random splits: {np.std(accuracies):.4f}")
    print("  → Small variance indicates stable model")
    print()


def run_all_solutions():
    """
    Run all solutions
    """
    print("\n" + "=" * 60)
    print("BEGINNER SOLUTIONS - MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    solution1_load_wine()
    solution2_split_data()
    solution3_train_models()
    solution4_classification_metrics()
    solution5_complete_workflow()
    bonus_solution_random_state()
    
    print("=" * 60)
    print("ALL SOLUTIONS DEMONSTRATED!")
    print("=" * 60)
    print("\nLearning Outcomes:")
    print("✓ Data loading and exploration")
    print("✓ Train-test splitting strategies")
    print("✓ Model training and comparison")
    print("✓ Understanding evaluation metrics")
    print("✓ Complete ML workflow implementation")
    print("✓ Importance of random state")


if __name__ == "__main__":
    """
    Main execution
    """
    run_all_solutions()
