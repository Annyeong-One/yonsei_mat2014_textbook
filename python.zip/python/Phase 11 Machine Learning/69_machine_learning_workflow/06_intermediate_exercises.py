"""
Machine Learning Workflow - Intermediate Exercises
==================================================

Practice exercises for data preprocessing and advanced evaluation.
Complete the TODO sections to build your understanding.

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, confusion_matrix, classification_report)
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# EXERCISE 1: Handle Missing Values
# =============================================================================
def exercise1_missing_values():
    """
    Exercise 1: Handle Missing Values
    ---------------------------------
    
    Tasks:
    1. Create a dataset with missing values
    2. Count missing values in each column
    3. Impute numerical columns with median
    4. Impute categorical columns with mode
    5. Verify no missing values remain
    """
    print("=" * 60)
    print("EXERCISE 1: Handle Missing Values")
    print("=" * 60)
    
    # Create sample data with missing values
    np.random.seed(42)
    df = pd.DataFrame({
        'age': [25, np.nan, 35, 40, np.nan, 55],
        'income': [50000, 60000, np.nan, 80000, 70000, np.nan],
        'education': ['BS', 'MS', np.nan, 'PhD', 'BS', 'MS'],
        'score': [85, 90, 78, np.nan, 88, 92]
    })
    
    print("\nOriginal Data:")
    print(df)
    
    # TODO: Count missing values in each column
    print("\nMissing Values:")
    # ...
    
    # TODO: Separate numerical and categorical columns
    # numerical_cols = ...
    # categorical_cols = ...
    
    # TODO: Impute numerical columns with median
    # numerical_imputer = ...
    # df[numerical_cols] = ...
    
    # TODO: Impute categorical columns with mode
    # categorical_imputer = ...
    # df[categorical_cols] = ...
    
    # TODO: Verify no missing values
    print("\nMissing Values After Imputation:")
    # ...
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 2: Encode Categorical Variables
# =============================================================================
def exercise2_encoding():
    """
    Exercise 2: Encode Categorical Variables
    ----------------------------------------
    
    Tasks:
    1. Create a dataset with different types of categorical variables
    2. Use Label Encoding for ordinal features
    3. Use One-Hot Encoding for nominal features
    4. Print the shape before and after encoding
    
    Questions:
    - When should you use Label Encoding vs One-Hot Encoding?
    - What is the "dummy variable trap"?
    """
    print("=" * 60)
    print("EXERCISE 2: Encode Categorical Variables")
    print("=" * 60)
    
    # Create sample data
    df = pd.DataFrame({
        'education': ['High School', 'Bachelor', 'Master', 'Bachelor', 'PhD'],
        'city': ['NYC', 'LA', 'Chicago', 'NYC', 'LA'],
        'color': ['Red', 'Blue', 'Green', 'Red', 'Blue']
    })
    
    print("\nOriginal Data:")
    print(df)
    print(f"Shape: {df.shape}")
    
    # TODO: Apply Label Encoding to 'education' (ordinal)
    # Define order: High School < Bachelor < Master < PhD
    # education_mapping = {...}
    # df['education_encoded'] = ...
    
    print("\nAfter Label Encoding 'education':")
    # ...
    
    # TODO: Apply One-Hot Encoding to 'city' and 'color' (nominal)
    # city_dummies = ...
    # color_dummies = ...
    # df_encoded = pd.concat(...)
    
    print("\nAfter One-Hot Encoding:")
    # ...
    print(f"Shape: {df_encoded.shape}")
    
    # TODO: Answer the questions
    print("\n⚠️  TODO: Complete this exercise and answer questions!")
    print()


# =============================================================================
# EXERCISE 3: Feature Scaling Comparison
# =============================================================================
def exercise3_scaling():
    """
    Exercise 3: Compare Feature Scaling Methods
    -------------------------------------------
    
    Tasks:
    1. Create a dataset with features at different scales
    2. Apply StandardScaler
    3. Apply MinMaxScaler
    4. Compare the results
    5. Explain when to use each method
    
    Questions:
    - What are the mean and std of StandardScaler output?
    - What are the min and max of MinMaxScaler output?
    - Which scaler is more robust to outliers?
    """
    print("=" * 60)
    print("EXERCISE 3: Compare Feature Scaling Methods")
    print("=" * 60)
    
    # Create data with different scales
    np.random.seed(42)
    df = pd.DataFrame({
        'age': [25, 35, 45, 55, 65],
        'income': [30000, 50000, 70000, 90000, 110000],
        'credit_score': [650, 700, 750, 800, 850]
    })
    
    print("\nOriginal Data:")
    print(df)
    print("\nOriginal Statistics:")
    print(df.describe())
    
    # TODO: Apply StandardScaler
    # scaler_standard = StandardScaler()
    # df_standard = ...
    
    print("\nAfter StandardScaler:")
    # print(df_standard)
    # print("\nStandardScaler Statistics:")
    # print(pd.DataFrame(df_standard, columns=df.columns).describe())
    
    # TODO: Apply MinMaxScaler
    # scaler_minmax = MinMaxScaler()
    # df_minmax = ...
    
    print("\nAfter MinMaxScaler:")
    # print(df_minmax)
    # print("\nMinMaxScaler Statistics:")
    # print(pd.DataFrame(df_minmax, columns=df.columns).describe())
    
    # TODO: Answer the questions
    print("\n⚠️  TODO: Complete this exercise and answer questions!")
    print()


# =============================================================================
# EXERCISE 4: Comprehensive Model Evaluation
# =============================================================================
def exercise4_evaluation():
    """
    Exercise 4: Comprehensive Model Evaluation
    -----------------------------------------
    
    Tasks:
    1. Create a binary classification dataset
    2. Train a model
    3. Calculate and interpret:
       - Accuracy
       - Precision
       - Recall
       - F1-Score
       - Confusion Matrix
    4. Determine if the model is overfitting
    
    Questions:
    - What does each metric tell you?
    - When would you prioritize precision over recall?
    - How do you detect overfitting?
    """
    print("=" * 60)
    print("EXERCISE 4: Comprehensive Model Evaluation")
    print("=" * 60)
    
    # Create sample dataset
    np.random.seed(42)
    n_samples = 1000
    
    X = np.random.randn(n_samples, 5)
    y = (X[:, 0] + X[:, 1] - X[:, 2] + np.random.randn(n_samples) * 0.5 > 0).astype(int)
    
    # TODO: Split the data
    # X_train, X_test, y_train, y_test = ...
    
    # TODO: Train a model
    # model = RandomForestClassifier(...)
    # model.fit(...)
    
    # TODO: Make predictions on BOTH train and test sets
    # y_train_pred = ...
    # y_test_pred = ...
    
    # TODO: Calculate metrics for both sets
    print("\nTraining Set Performance:")
    # train_accuracy = ...
    # train_precision = ...
    # train_recall = ...
    # train_f1 = ...
    
    print("\nTesting Set Performance:")
    # test_accuracy = ...
    # test_precision = ...
    # test_recall = ...
    # test_f1 = ...
    
    # TODO: Generate confusion matrix
    print("\nConfusion Matrix:")
    # cm = confusion_matrix(...)
    # print(cm)
    
    # TODO: Check for overfitting
    # Compare train vs test accuracy
    
    print("\n⚠️  TODO: Complete this exercise and answer questions!")
    print()


# =============================================================================
# EXERCISE 5: Complete Preprocessing Pipeline
# =============================================================================
def exercise5_preprocessing_pipeline():
    """
    Exercise 5: Build Complete Preprocessing Pipeline
    ------------------------------------------------
    
    Tasks:
    1. Create a dataset with:
       - Missing values
       - Categorical features
       - Numerical features at different scales
    2. Handle missing values
    3. Encode categorical features
    4. Scale numerical features
    5. Train and evaluate a model
    
    Challenge: Achieve accuracy > 0.85 on test set
    """
    print("=" * 60)
    print("EXERCISE 5: Complete Preprocessing Pipeline")
    print("=" * 60)
    
    # Create complex dataset
    np.random.seed(42)
    n_samples = 800
    
    df = pd.DataFrame({
        'age': np.random.randint(20, 70, n_samples),
        'income': np.random.randint(30000, 120000, n_samples),
        'education': np.random.choice(['HS', 'BS', 'MS', 'PhD'], n_samples),
        'city': np.random.choice(['NYC', 'LA', 'Chicago'], n_samples),
        'score': np.random.randint(60, 100, n_samples)
    })
    
    # Create target
    df['approved'] = ((df['income'] > 60000) & (df['score'] > 75)).astype(int)
    
    # Add missing values
    df.loc[df.sample(frac=0.1).index, 'income'] = np.nan
    df.loc[df.sample(frac=0.05).index, 'education'] = np.nan
    
    print("\nDataset Info:")
    print(f"Shape: {df.shape}")
    print(f"Missing values: {df.isnull().sum().sum()}")
    
    # TODO: Step 1 - Separate features and target
    # X = ...
    # y = ...
    
    # TODO: Step 2 - Handle missing values
    # ...
    
    # TODO: Step 3 - Encode categorical features
    # ...
    
    # TODO: Step 4 - Split data
    # ...
    
    # TODO: Step 5 - Scale features
    # ...
    
    # TODO: Step 6 - Train model
    # ...
    
    # TODO: Step 7 - Evaluate
    # ...
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# BONUS EXERCISE: Feature Importance Analysis
# =============================================================================
def bonus_exercise_feature_importance():
    """
    Bonus Exercise: Analyze Feature Importance
    -----------------------------------------
    
    Tasks:
    1. Create a dataset with multiple features
    2. Train a Random Forest model
    3. Extract and visualize feature importances
    4. Identify the most important features
    5. Retrain with only top 3 features
    6. Compare performance
    
    Questions:
    - Does using fewer features improve or hurt performance?
    - Why might you want to use fewer features?
    """
    print("=" * 60)
    print("BONUS: Feature Importance Analysis")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    n_samples = 1000
    
    X = pd.DataFrame({
        'feature1': np.random.randn(n_samples),
        'feature2': np.random.randn(n_samples),
        'feature3': np.random.randn(n_samples),
        'feature4': np.random.randn(n_samples),
        'feature5': np.random.randn(n_samples),
        'noise1': np.random.randn(n_samples),
        'noise2': np.random.randn(n_samples)
    })
    
    # Target depends mainly on first 3 features
    y = (X['feature1'] + 2*X['feature2'] - X['feature3'] + 
         np.random.randn(n_samples)*0.5 > 0).astype(int)
    
    # TODO: Split data
    # ...
    
    # TODO: Train Random Forest with all features
    # ...
    
    # TODO: Get feature importances
    # importances = model.feature_importances_
    # ...
    
    # TODO: Create importance DataFrame and sort
    # ...
    
    # TODO: Identify top 3 features
    # ...
    
    # TODO: Retrain with only top 3 features
    # ...
    
    # TODO: Compare accuracies
    # ...
    
    print("\n⚠️  TODO: Complete this exercise and answer questions!")
    print()


def run_all_exercises():
    """
    Run all exercises
    """
    print("\n" + "=" * 60)
    print("INTERMEDIATE EXERCISES - MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    exercise1_missing_values()
    exercise2_encoding()
    exercise3_scaling()
    exercise4_evaluation()
    exercise5_preprocessing_pipeline()
    bonus_exercise_feature_importance()
    
    print("=" * 60)
    print("EXERCISES COMPLETE!")
    print("=" * 60)
    print("\nNext Steps:")
    print("1. Check solutions for correct implementations")
    print("2. Experiment with different preprocessing strategies")
    print("3. Try different models and compare results")
    print("4. Move on to advanced exercises")


if __name__ == "__main__":
    """
    Main execution
    """
    run_all_exercises()
