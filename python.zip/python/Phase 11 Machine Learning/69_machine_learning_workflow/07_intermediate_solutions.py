"""
Machine Learning Workflow - Intermediate Exercises SOLUTIONS
============================================================

Complete solutions for intermediate exercises.

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, confusion_matrix, classification_report)
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# SOLUTION 1: Handle Missing Values
# =============================================================================
def solution1_missing_values():
    """
    Solution 1: Handle Missing Values
    """
    print("=" * 60)
    print("SOLUTION 1: Handle Missing Values")
    print("=" * 60)
    
    # Create sample data with missing values
    np.random.seed(42)
    df = pd.DataFrame({
        'age': [25, np.nan, 35, 40, np.nan, 55],
        'income': [50000, 60000, np.nan, 80000, 70000, np.nan],
        'education': ['BS', 'MS', np.nan, 'PhD', 'BS', 'MS'],
        'score': [85, 90, 78, np.nan, 88, 92]
    })
    
    print("\nOriginal Data:")
    print(df)
    
    # Count missing values
    print("\nMissing Values:")
    print(df.isnull().sum())
    
    # Separate numerical and categorical columns
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = df.select_dtypes(include=['object']).columns.tolist()
    
    print(f"\nNumerical columns: {numerical_cols}")
    print(f"Categorical columns: {categorical_cols}")
    
    # Impute numerical columns with median
    numerical_imputer = SimpleImputer(strategy='median')
    df[numerical_cols] = numerical_imputer.fit_transform(df[numerical_cols])
    
    print("\nAfter imputing numerical columns (median):")
    print(df[numerical_cols])
    
    # Impute categorical columns with mode
    categorical_imputer = SimpleImputer(strategy='most_frequent')
    df[categorical_cols] = categorical_imputer.fit_transform(df[categorical_cols])
    
    print("\nAfter imputing categorical columns (mode):")
    print(df[categorical_cols])
    
    # Verify no missing values
    print("\nMissing Values After Imputation:")
    print(df.isnull().sum())
    print("\n✓ All missing values handled!")
    print()


# =============================================================================
# SOLUTION 2: Encode Categorical Variables
# =============================================================================
def solution2_encoding():
    """
    Solution 2: Encode Categorical Variables
    """
    print("=" * 60)
    print("SOLUTION 2: Encode Categorical Variables")
    print("=" * 60)
    
    # Create sample data
    df = pd.DataFrame({
        'education': ['High School', 'Bachelor', 'Master', 'Bachelor', 'PhD'],
        'city': ['NYC', 'LA', 'Chicago', 'NYC', 'LA'],
        'color': ['Red', 'Blue', 'Green', 'Red', 'Blue']
    })
    
    print("\nOriginal Data:")
    print(df)
    print(f"Shape: {df.shape}")
    
    # Apply Label Encoding to 'education' (ordinal)
    education_mapping = {
        'High School': 0,
        'Bachelor': 1,
        'Master': 2,
        'PhD': 3
    }
    df['education_encoded'] = df['education'].map(education_mapping)
    
    print("\nAfter Label Encoding 'education':")
    print(df[['education', 'education_encoded']])
    print("Encoding preserves order: High School(0) < Bachelor(1) < Master(2) < PhD(3)")
    
    # Apply One-Hot Encoding to 'city' and 'color' (nominal)
    city_dummies = pd.get_dummies(df['city'], prefix='city', drop_first=True)
    color_dummies = pd.get_dummies(df['color'], prefix='color', drop_first=True)
    
    df_encoded = pd.concat([df, city_dummies, color_dummies], axis=1)
    df_encoded = df_encoded.drop(['education', 'city', 'color'], axis=1)
    
    print("\nAfter One-Hot Encoding:")
    print(df_encoded)
    print(f"Shape: {df_encoded.shape}")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS:")
    print("-" * 60)
    print("When to use Label Encoding vs One-Hot Encoding?")
    print("\nLabel Encoding:")
    print("  → For ORDINAL features (natural order)")
    print("  → Examples: education level, rating (low/med/high)")
    print("  → Preserves ordinal relationship")
    
    print("\nOne-Hot Encoding:")
    print("  → For NOMINAL features (no natural order)")
    print("  → Examples: city, color, category")
    print("  → Prevents model from assuming order")
    
    print("\nDummy Variable Trap:")
    print("  → When using one-hot encoding, we drop first category")
    print("  → Reason: Prevents perfect multicollinearity")
    print("  → Example: If not LA and not Chicago → must be NYC")
    print("  → Using drop_first=True avoids this issue")
    print()


# =============================================================================
# SOLUTION 3: Feature Scaling Comparison
# =============================================================================
def solution3_scaling():
    """
    Solution 3: Compare Feature Scaling Methods
    """
    print("=" * 60)
    print("SOLUTION 3: Compare Feature Scaling Methods")
    print("=" * 60)
    
    # Create data with different scales
    np.random.seed(42)
    df = pd.DataFrame({
        'age': [25, 35, 45, 55, 65],
        'income': [30000, 50000, 70000, 90000, 110000],
        'credit_score': [650, 700, 750, 800, 850]
    })
    
    print("\nOriginal Data:")
    print(df)
    print("\nOriginal Statistics:")
    print(df.describe())
    
    # Apply StandardScaler
    scaler_standard = StandardScaler()
    df_standard = scaler_standard.fit_transform(df)
    
    print("\n" + "=" * 60)
    print("STANDARDSCALER (Z-score Normalization)")
    print("=" * 60)
    print("Formula: z = (x - mean) / std")
    print("\nScaled Data:")
    print(pd.DataFrame(df_standard, columns=df.columns))
    print("\nStandardScaler Statistics:")
    stats_standard = pd.DataFrame(df_standard, columns=df.columns).describe()
    print(stats_standard)
    print(f"\n✓ Mean ≈ 0: {stats_standard.loc['mean'].abs().max() < 1e-15}")
    print(f"✓ Std ≈ 1: {abs(stats_standard.loc['std'].mean() - 1) < 0.01}")
    
    # Apply MinMaxScaler
    scaler_minmax = MinMaxScaler()
    df_minmax = scaler_minmax.fit_transform(df)
    
    print("\n" + "=" * 60)
    print("MINMAXSCALER (Range Normalization)")
    print("=" * 60)
    print("Formula: x_scaled = (x - min) / (max - min)")
    print("\nScaled Data:")
    print(pd.DataFrame(df_minmax, columns=df.columns))
    print("\nMinMaxScaler Statistics:")
    stats_minmax = pd.DataFrame(df_minmax, columns=df.columns).describe()
    print(stats_minmax)
    print(f"\n✓ Min = 0: {stats_minmax.loc['min'].max() < 1e-15}")
    print(f"✓ Max = 1: {abs(stats_minmax.loc['max'].max() - 1) < 1e-15}")
    
    # Analysis
    print("\n" + "-" * 60)
    print("COMPARISON AND ANALYSIS:")
    print("-" * 60)
    
    print("\nStandardScaler characteristics:")
    print("  → Mean = 0, Standard Deviation = 1")
    print("  → Unbounded (no fixed min/max)")
    print("  → More robust to outliers")
    print("  → Best for: Gaussian-distributed data")
    
    print("\nMinMaxScaler characteristics:")
    print("  → Range = [0, 1]")
    print("  → Bounded values")
    print("  → Sensitive to outliers")
    print("  → Best for: Neural networks, when bounded range needed")
    
    print("\nWhich is more robust to outliers?")
    print("  → StandardScaler is MORE robust")
    print("  → Reason: Uses mean and std (influenced less by extremes)")
    print("  → MinMaxScaler uses actual min/max (heavily affected by outliers)")
    
    # Demonstration with outlier
    print("\n" + "-" * 60)
    print("OUTLIER DEMONSTRATION:")
    print("-" * 60)
    
    df_outlier = df.copy()
    df_outlier.loc[len(df_outlier)] = [25, 1000000, 650]  # Add outlier
    
    print("\nWith outlier (income = 1,000,000):")
    
    scaled_standard_outlier = scaler_standard.fit_transform(df_outlier)
    scaled_minmax_outlier = scaler_minmax.fit_transform(df_outlier)
    
    print("\nStandardScaler - Normal values still spread:")
    print(pd.DataFrame(scaled_standard_outlier, columns=df.columns)['income'].describe())
    
    print("\nMinMaxScaler - Normal values compressed near 0:")
    print(pd.DataFrame(scaled_minmax_outlier, columns=df.columns)['income'].describe())
    print("\n→ MinMaxScaler compresses normal values when outlier present")
    print()


# =============================================================================
# SOLUTION 4: Comprehensive Model Evaluation
# =============================================================================
def solution4_evaluation():
    """
    Solution 4: Comprehensive Model Evaluation
    """
    print("=" * 60)
    print("SOLUTION 4: Comprehensive Model Evaluation")
    print("=" * 60)
    
    # Create sample dataset
    np.random.seed(42)
    n_samples = 1000
    
    X = np.random.randn(n_samples, 5)
    y = (X[:, 0] + X[:, 1] - X[:, 2] + np.random.randn(n_samples) * 0.5 > 0).astype(int)
    
    # Split the data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\nDataset: {n_samples} samples, {X.shape[1]} features")
    print(f"Training set: {len(X_train)} samples")
    print(f"Testing set: {len(X_test)} samples")
    
    # Train model
    model = RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42)
    model.fit(X_train, y_train)
    
    # Make predictions on BOTH sets
    y_train_pred = model.predict(X_train)
    y_test_pred = model.predict(X_test)
    
    # Calculate metrics for training set
    train_accuracy = accuracy_score(y_train, y_train_pred)
    train_precision = precision_score(y_train, y_train_pred)
    train_recall = recall_score(y_train, y_train_pred)
    train_f1 = f1_score(y_train, y_train_pred)
    
    print("\n" + "=" * 60)
    print("TRAINING SET PERFORMANCE:")
    print("=" * 60)
    print(f"Accuracy:  {train_accuracy:.4f} ({train_accuracy*100:.2f}%)")
    print(f"Precision: {train_precision:.4f}")
    print(f"Recall:    {train_recall:.4f}")
    print(f"F1-Score:  {train_f1:.4f}")
    
    # Calculate metrics for testing set
    test_accuracy = accuracy_score(y_test, y_test_pred)
    test_precision = precision_score(y_test, y_test_pred)
    test_recall = recall_score(y_test, y_test_pred)
    test_f1 = f1_score(y_test, y_test_pred)
    
    print("\n" + "=" * 60)
    print("TESTING SET PERFORMANCE:")
    print("=" * 60)
    print(f"Accuracy:  {test_accuracy:.4f} ({test_accuracy*100:.2f}%)")
    print(f"Precision: {test_precision:.4f}")
    print(f"Recall:    {test_recall:.4f}")
    print(f"F1-Score:  {test_f1:.4f}")
    
    # Confusion matrix
    print("\n" + "=" * 60)
    print("CONFUSION MATRIX (Test Set):")
    print("=" * 60)
    cm = confusion_matrix(y_test, y_test_pred)
    print("\n              Predicted")
    print("              Negative  Positive")
    print(f"Actual Negative   {cm[0,0]:<8}  {cm[0,1]:<8}")
    print(f"       Positive   {cm[1,0]:<8}  {cm[1,1]:<8}")
    
    tn, fp, fn, tp = cm.ravel()
    print(f"\nTrue Negatives:  {tn}")
    print(f"False Positives: {fp}")
    print(f"False Negatives: {fn}")
    print(f"True Positives:  {tp}")
    
    # Check for overfitting
    print("\n" + "=" * 60)
    print("OVERFITTING ANALYSIS:")
    print("=" * 60)
    
    overfit_gap = train_accuracy - test_accuracy
    print(f"Training Accuracy: {train_accuracy:.4f}")
    print(f"Testing Accuracy:  {test_accuracy:.4f}")
    print(f"Gap:               {overfit_gap:.4f}")
    
    if overfit_gap > 0.10:
        print("\n⚠️  SEVERE OVERFITTING DETECTED!")
        print("   Model memorizes training data but doesn't generalize")
    elif overfit_gap > 0.05:
        print("\n⚠️  Moderate overfitting detected")
        print("   Consider: reducing model complexity or adding regularization")
    else:
        print("\n✓ Model generalizes well!")
        print("  Small gap indicates good generalization")
    
    # Metric interpretations
    print("\n" + "=" * 60)
    print("METRIC INTERPRETATIONS:")
    print("=" * 60)
    
    print("\n1. ACCURACY: Overall correctness")
    print(f"   → {test_accuracy*100:.1f}% of predictions are correct")
    
    print("\n2. PRECISION: Quality of positive predictions")
    print(f"   → When model predicts positive, it's correct {test_precision*100:.1f}% of time")
    print("   → Important when false positives are costly")
    
    print("\n3. RECALL: Coverage of actual positives")
    print(f"   → Model finds {test_recall*100:.1f}% of all actual positives")
    print("   → Important when false negatives are costly")
    
    print("\n4. F1-SCORE: Balance of precision and recall")
    print(f"   → Harmonic mean: {test_f1:.4f}")
    print("   → Useful when you need both precision and recall")
    
    # When to prioritize which metric
    print("\n" + "-" * 60)
    print("WHEN TO PRIORITIZE WHICH METRIC:")
    print("-" * 60)
    
    print("\nPrioritize PRECISION when:")
    print("  → False positives are costly")
    print("  → Example: Spam detection (marking real email as spam is bad)")
    print("  → Example: Fraud detection in automated systems")
    
    print("\nPrioritize RECALL when:")
    print("  → False negatives are costly")
    print("  → Example: Cancer detection (missing cancer is very bad)")
    print("  → Example: Security threat detection")
    
    print("\nHow to detect overfitting:")
    print("  1. Compare train vs test accuracy")
    print("  2. Large gap (>5%) indicates overfitting")
    print("  3. Solutions:")
    print("     - Reduce model complexity")
    print("     - Add regularization")
    print("     - Get more training data")
    print("     - Use cross-validation")
    print()


# =============================================================================
# SOLUTION 5: Complete Preprocessing Pipeline
# =============================================================================
def solution5_preprocessing_pipeline():
    """
    Solution 5: Build Complete Preprocessing Pipeline
    """
    print("=" * 60)
    print("SOLUTION 5: Complete Preprocessing Pipeline")
    print("=" * 60)
    
    # Create complex dataset
    np.random.seed(42)
    n_samples = 800
    
    df = pd.DataFrame({
        'age': np.random.randint(20, 70, n_samples),
        'income': np.random.randint(30000, 120000, n_samples),
        'education': np.random.choice(['HS', 'BS', 'MS', 'PhD'], n_samples),
        'city': np.random.choice(['NYC', 'LA', 'Chicago'], n_samples),
        'score': np.random.randint(60, 100, n_samples)
    })
    
    # Create target
    df['approved'] = ((df['income'] > 60000) & (df['score'] > 75)).astype(int)
    
    # Add missing values
    df.loc[df.sample(frac=0.1, random_state=42).index, 'income'] = np.nan
    df.loc[df.sample(frac=0.05, random_state=42).index, 'education'] = np.nan
    
    print("\nDataset Info:")
    print(f"Shape: {df.shape}")
    print(f"Missing values: {df.isnull().sum().sum()}")
    print(f"\nTarget distribution:")
    print(df['approved'].value_counts())
    
    # Step 1: Separate features and target
    print("\n" + "=" * 60)
    print("STEP 1: Separating Features and Target")
    print("=" * 60)
    X = df.drop('approved', axis=1)
    y = df['approved']
    print(f"Features shape: {X.shape}")
    print(f"Target shape: {y.shape}")
    
    # Step 2: Handle missing values
    print("\n" + "=" * 60)
    print("STEP 2: Handling Missing Values")
    print("=" * 60)
    
    numerical_cols = X.select_dtypes(include=[np.number]).columns.tolist()
    categorical_cols = X.select_dtypes(include=['object']).columns.tolist()
    
    print(f"Numerical columns: {numerical_cols}")
    print(f"Categorical columns: {categorical_cols}")
    print(f"\nMissing values before:")
    print(X.isnull().sum())
    
    # Impute numerical
    num_imputer = SimpleImputer(strategy='median')
    X[numerical_cols] = num_imputer.fit_transform(X[numerical_cols])
    
    # Impute categorical
    cat_imputer = SimpleImputer(strategy='most_frequent')
    X[categorical_cols] = cat_imputer.fit_transform(X[categorical_cols])
    
    print(f"\nMissing values after:")
    print(X.isnull().sum())
    
    # Step 3: Encode categorical features
    print("\n" + "=" * 60)
    print("STEP 3: Encoding Categorical Features")
    print("=" * 60)
    
    # Label encode education (ordinal)
    education_map = {'HS': 0, 'BS': 1, 'MS': 2, 'PhD': 3}
    X['education'] = X['education'].map(education_map)
    
    # One-hot encode city (nominal)
    city_dummies = pd.get_dummies(X['city'], prefix='city', drop_first=True)
    X = pd.concat([X, city_dummies], axis=1)
    X = X.drop('city', axis=1)
    
    print(f"Final features: {X.columns.tolist()}")
    print(f"Shape after encoding: {X.shape}")
    
    # Step 4: Split data
    print("\n" + "=" * 60)
    print("STEP 4: Splitting Data")
    print("=" * 60)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Testing set: {X_test.shape[0]} samples")
    
    # Step 5: Scale features
    print("\n" + "=" * 60)
    print("STEP 5: Scaling Features")
    print("=" * 60)
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Convert back to DataFrame
    X_train_scaled = pd.DataFrame(X_train_scaled, columns=X_train.columns)
    X_test_scaled = pd.DataFrame(X_test_scaled, columns=X_test.columns)
    
    print("Features scaled using StandardScaler")
    print(f"Mean after scaling (should be ≈0): {X_train_scaled.mean().abs().max():.6f}")
    print(f"Std after scaling (should be ≈1): {X_train_scaled.std().mean():.6f}")
    
    # Step 6: Train model
    print("\n" + "=" * 60)
    print("STEP 6: Training Model")
    print("=" * 60)
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        min_samples_split=5,
        random_state=42,
        n_jobs=-1
    )
    model.fit(X_train_scaled, y_train)
    print("✓ Random Forest model trained")
    
    # Step 7: Evaluate
    print("\n" + "=" * 60)
    print("STEP 7: Evaluating Model")
    print("=" * 60)
    
    y_pred = model.predict(X_test_scaled)
    
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    
    print(f"Accuracy:  {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"Precision: {precision:.4f}")
    print(f"Recall:    {recall:.4f}")
    print(f"F1-Score:  {f1:.4f}")
    
    if accuracy > 0.85:
        print(f"\n🎉 Challenge completed! Achieved {accuracy*100:.2f}% > 85%")
    else:
        print(f"\n⚠️  Accuracy {accuracy*100:.2f}% < 85%")
        print("Try: adjusting hyperparameters or feature engineering")
    
    print("\n✓ Complete preprocessing pipeline executed successfully!")
    print()


# =============================================================================
# BONUS SOLUTION: Feature Importance Analysis
# =============================================================================
def bonus_solution_feature_importance():
    """
    Bonus Solution: Analyze Feature Importance
    """
    print("=" * 60)
    print("BONUS SOLUTION: Feature Importance Analysis")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    n_samples = 1000
    
    X = pd.DataFrame({
        'feature1': np.random.randn(n_samples),
        'feature2': np.random.randn(n_samples),
        'feature3': np.random.randn(n_samples),
        'feature4': np.random.randn(n_samples),
        'feature5': np.random.randn(n_samples),
        'noise1': np.random.randn(n_samples),
        'noise2': np.random.randn(n_samples)
    })
    
    # Target depends mainly on first 3 features
    y = (X['feature1'] + 2*X['feature2'] - X['feature3'] + 
         np.random.randn(n_samples)*0.5 > 0).astype(int)
    
    print(f"\nDataset: {X.shape[0]} samples, {X.shape[1]} features")
    print("Target depends on: feature1 + 2*feature2 - feature3")
    print("Noise features: noise1, noise2 (should have low importance)")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Train Random Forest with all features
    print("\n" + "=" * 60)
    print("TRAINING WITH ALL FEATURES")
    print("=" * 60)
    
    model_all = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    model_all.fit(X_train, y_train)
    
    accuracy_all = accuracy_score(y_test, model_all.predict(X_test))
    print(f"Accuracy with all features: {accuracy_all:.4f}")
    
    # Get feature importances
    importances = model_all.feature_importances_
    
    # Create importance DataFrame and sort
    importance_df = pd.DataFrame({
        'feature': X.columns,
        'importance': importances
    }).sort_values('importance', ascending=False)
    
    print("\n" + "=" * 60)
    print("FEATURE IMPORTANCES (Sorted)")
    print("=" * 60)
    print(importance_df.to_string(index=False))
    
    # Visualize
    print("\nVisualization:")
    max_importance = importance_df['importance'].max()
    for _, row in importance_df.iterrows():
        bar_length = int((row['importance'] / max_importance) * 40)
        bar = '█' * bar_length
        print(f"{row['feature']:<12} {bar} {row['importance']:.4f}")
    
    # Identify top 3 features
    top3_features = importance_df.head(3)['feature'].tolist()
    print(f"\nTop 3 features: {top3_features}")
    
    # Retrain with only top 3 features
    print("\n" + "=" * 60)
    print("TRAINING WITH TOP 3 FEATURES")
    print("=" * 60)
    
    X_train_top3 = X_train[top3_features]
    X_test_top3 = X_test[top3_features]
    
    model_top3 = RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1)
    model_top3.fit(X_train_top3, y_train)
    
    accuracy_top3 = accuracy_score(y_test, model_top3.predict(X_test_top3))
    print(f"Accuracy with top 3 features: {accuracy_top3:.4f}")
    
    # Compare
    print("\n" + "=" * 60)
    print("COMPARISON")
    print("=" * 60)
    print(f"All features ({X.shape[1]}): {accuracy_all:.4f}")
    print(f"Top 3 features:      {accuracy_top3:.4f}")
    print(f"Difference:          {abs(accuracy_all - accuracy_top3):.4f}")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS")
    print("-" * 60)
    
    if accuracy_top3 >= accuracy_all - 0.02:
        print("✓ Top 3 features maintain performance!")
        print("\nBenefits of using fewer features:")
        print("  → Faster training and prediction")
        print("  → Less memory usage")
        print("  → Simpler, more interpretable model")
        print("  → Reduced risk of overfitting")
        print("  → Easier data collection")
    else:
        print("⚠️  Significant performance drop with fewer features")
        print("\nIn this case, other features contribute meaningfully")
    
    print("\nKey Insight:")
    print("  Feature importance helps identify which features matter")
    print("  Can reduce dimensionality without losing performance")
    print("  Random Forest feature importance is based on:")
    print("    → How much each feature decreases impurity")
    print("    → Averaged across all trees in the forest")
    print()


def run_all_solutions():
    """
    Run all solutions
    """
    print("\n" + "=" * 60)
    print("INTERMEDIATE SOLUTIONS - MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    solution1_missing_values()
    solution2_encoding()
    solution3_scaling()
    solution4_evaluation()
    solution5_preprocessing_pipeline()
    bonus_solution_feature_importance()
    
    print("=" * 60)
    print("ALL SOLUTIONS DEMONSTRATED!")
    print("=" * 60)
    print("\nLearning Outcomes:")
    print("✓ Missing value imputation strategies")
    print("✓ Categorical encoding techniques")
    print("✓ Feature scaling methods and comparison")
    print("✓ Comprehensive model evaluation")
    print("✓ Complete preprocessing pipeline")
    print("✓ Feature importance analysis")


if __name__ == "__main__":
    """
    Main execution
    """
    run_all_solutions()
