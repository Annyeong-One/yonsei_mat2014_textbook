"""
Machine Learning Workflow - Advanced Exercises
==============================================

Practice exercises for pipelines, cross-validation, and hyperparameter tuning.
Complete the TODO sections to master advanced ML workflows.

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import (train_test_split, cross_val_score,
                                      GridSearchCV, StratifiedKFold)
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score, classification_report
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# EXERCISE 1: Build a Simple Pipeline
# =============================================================================
def exercise1_simple_pipeline():
    """
    Exercise 1: Build a Simple Pipeline
    -----------------------------------
    
    Tasks:
    1. Create sample data
    2. Build a pipeline with:
       - StandardScaler
       - LogisticRegression
    3. Fit the pipeline on training data
    4. Evaluate on test data
    
    Questions:
    - What are the advantages of using pipelines?
    - Why is it important to fit scaler only on training data?
    """
    print("=" * 60)
    print("EXERCISE 1: Build a Simple Pipeline")
    print("=" * 60)
    
    # Create sample data
    np.random.seed(42)
    X = np.random.randn(1000, 5)
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    
    # TODO: Split data
    # X_train, X_test, y_train, y_test = ...
    
    # TODO: Build pipeline
    # pipeline = Pipeline([
    #     ('scaler', ...),
    #     ('classifier', ...)
    # ])
    
    # TODO: Fit pipeline
    # pipeline.fit(...)
    
    # TODO: Evaluate
    # y_pred = ...
    # accuracy = ...
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 2: Build ColumnTransformer Pipeline
# =============================================================================
def exercise2_column_transformer():
    """
    Exercise 2: Build ColumnTransformer Pipeline
    --------------------------------------------
    
    Tasks:
    1. Create dataset with mixed feature types
    2. Build separate pipelines for:
       - Numerical features (impute + scale)
       - Categorical features (impute + one-hot encode)
    3. Combine using ColumnTransformer
    4. Add classifier to create full pipeline
    5. Train and evaluate
    
    Challenge: Understand the shape transformations at each step
    """
    print("=" * 60)
    print("EXERCISE 2: ColumnTransformer Pipeline")
    print("=" * 60)
    
    # Create mixed-type dataset
    np.random.seed(42)
    n_samples = 800
    
    df = pd.DataFrame({
        'age': np.random.randint(20, 70, n_samples),
        'income': np.random.randint(30000, 120000, n_samples),
        'education': np.random.choice(['HS', 'BS', 'MS'], n_samples),
        'city': np.random.choice(['NYC', 'LA', 'SF'], n_samples),
        'approved': ((np.random.rand(n_samples) > 0.5).astype(int))
    })
    
    # Add some missing values
    df.loc[df.sample(frac=0.1).index, 'income'] = np.nan
    df.loc[df.sample(frac=0.05).index, 'education'] = np.nan
    
    X = df.drop('approved', axis=1)
    y = df['approved']
    
    print(f"Dataset shape: {X.shape}")
    print(f"Missing values: {X.isnull().sum().sum()}")
    
    # TODO: Define column types
    # numerical_features = [...]
    # categorical_features = [...]
    
    # TODO: Build numerical pipeline
    # numerical_pipeline = Pipeline([...])
    
    # TODO: Build categorical pipeline
    # categorical_pipeline = Pipeline([...])
    
    # TODO: Combine with ColumnTransformer
    # preprocessor = ColumnTransformer([...])
    
    # TODO: Build full pipeline
    # full_pipeline = Pipeline([
    #     ('preprocessor', ...),
    #     ('classifier', ...)
    # ])
    
    # TODO: Split, train, evaluate
    # ...
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 3: Cross-Validation
# =============================================================================
def exercise3_cross_validation():
    """
    Exercise 3: Implement Cross-Validation
    --------------------------------------
    
    Tasks:
    1. Load or create dataset
    2. Build a pipeline
    3. Perform 5-fold cross-validation
    4. Calculate mean and std of scores
    5. Compare with simple train-test split
    
    Questions:
    - Why is cross-validation better than single train-test split?
    - What does standard deviation tell you?
    - When might you use more or fewer folds?
    """
    print("=" * 60)
    print("EXERCISE 3: Cross-Validation")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    X = np.random.randn(1000, 10)
    y = (X[:, 0] + 2*X[:, 1] - X[:, 2] + np.random.randn(1000)*0.5 > 0).astype(int)
    
    # TODO: Build pipeline
    # pipeline = Pipeline([...])
    
    # TODO: Perform 5-fold cross-validation
    # cv_scores = cross_val_score(...)
    
    # TODO: Calculate statistics
    # mean_score = ...
    # std_score = ...
    
    print("\nCross-Validation Results:")
    # TODO: Print results
    
    # TODO: Compare with single train-test split
    # X_train, X_test, y_train, y_test = ...
    # pipeline.fit(...)
    # single_score = ...
    
    print("\nComparison:")
    # TODO: Print comparison
    
    print("\n⚠️  TODO: Complete this exercise and answer questions!")
    print()


# =============================================================================
# EXERCISE 4: Grid Search for Hyperparameter Tuning
# =============================================================================
def exercise4_grid_search():
    """
    Exercise 4: Hyperparameter Tuning with Grid Search
    --------------------------------------------------
    
    Tasks:
    1. Create dataset and pipeline
    2. Define parameter grid for Random Forest:
       - n_estimators: [50, 100, 200]
       - max_depth: [5, 10, None]
       - min_samples_split: [2, 5, 10]
    3. Perform Grid Search with cross-validation
    4. Print best parameters and score
    5. Compare with default parameters
    
    Challenge: Calculate total number of combinations tested
    """
    print("=" * 60)
    print("EXERCISE 4: Grid Search Hyperparameter Tuning")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    X = np.random.randn(1000, 8)
    y = (X[:, 0] + X[:, 1] - X[:, 2] + X[:, 3] > 0).astype(int)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # TODO: Build pipeline
    # pipeline = Pipeline([
    #     ('scaler', ...),
    #     ('classifier', RandomForestClassifier(random_state=42))
    # ])
    
    # TODO: Define parameter grid
    # param_grid = {
    #     'classifier__n_estimators': [...],
    #     'classifier__max_depth': [...],
    #     'classifier__min_samples_split': [...]
    # }
    
    # TODO: Calculate total combinations
    # total_combinations = ...
    
    # TODO: Perform Grid Search
    # grid_search = GridSearchCV(...)
    # grid_search.fit(...)
    
    # TODO: Print best parameters and score
    print("\nBest Parameters:")
    # ...
    
    print("\nBest Cross-Validation Score:")
    # ...
    
    # TODO: Compare with default parameters
    print("\nComparison with defaults:")
    # ...
    
    print("\n⚠️  TODO: Complete this exercise!")
    print()


# =============================================================================
# EXERCISE 5: Compare Multiple Models
# =============================================================================
def exercise5_model_comparison():
    """
    Exercise 5: Compare Multiple Models
    -----------------------------------
    
    Tasks:
    1. Prepare dataset with preprocessing pipeline
    2. Define 4 different models to compare:
       - Logistic Regression
       - Random Forest
       - Gradient Boosting
       - SVM
    3. Train each model
    4. Evaluate using multiple metrics
    5. Create comparison table
    6. Select best model
    
    Questions:
    - Which model performs best?
    - Which metric is most important for your use case?
    - Are there trade-offs between models (speed vs accuracy)?
    """
    print("=" * 60)
    print("EXERCISE 5: Compare Multiple Models")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    n_samples = 1500
    
    X = np.random.randn(n_samples, 10)
    y = (X[:, 0] + 2*X[:, 1] - X[:, 2] + X[:, 3] + 
         np.random.randn(n_samples)*0.5 > 0).astype(int)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # TODO: Define preprocessing
    # preprocessor = Pipeline([...])
    
    # TODO: Define models
    # models = {
    #     'Logistic Regression': ...,
    #     'Random Forest': ...,
    #     'Gradient Boosting': ...,
    #     'SVM': ...
    # }
    
    # TODO: Train and evaluate each model
    # results = {}
    # for name, model in models.items():
    #     pipeline = Pipeline([...])
    #     ...
    
    # TODO: Create comparison table
    print("\nModel Comparison:")
    # ...
    
    # TODO: Select best model
    print("\nBest Model:")
    # ...
    
    print("\n⚠️  TODO: Complete this exercise and answer questions!")
    print()


# =============================================================================
# BONUS EXERCISE: Nested Cross-Validation
# =============================================================================
def bonus_exercise_nested_cv():
    """
    Bonus Exercise: Nested Cross-Validation
    ---------------------------------------
    
    Tasks:
    1. Understand nested cross-validation concept
    2. Implement outer CV loop (model evaluation)
    3. Implement inner CV loop (hyperparameter tuning)
    4. Compare results with regular grid search
    
    Questions:
    - Why use nested cross-validation?
    - What's the difference between inner and outer loops?
    - When is nested CV necessary?
    
    Note: This is an advanced technique!
    """
    print("=" * 60)
    print("BONUS: Nested Cross-Validation")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    X = np.random.randn(500, 6)
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    
    print("\nNested Cross-Validation Structure:")
    print("Outer loop: Evaluates final model performance")
    print("Inner loop: Tunes hyperparameters")
    print()
    
    # TODO: Define pipeline and parameter grid
    # pipeline = Pipeline([...])
    # param_grid = {...}
    
    # TODO: Outer cross-validation
    # outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    # TODO: Nested CV loop
    # nested_scores = []
    # for train_idx, test_idx in outer_cv.split(X, y):
    #     # Inner CV: hyperparameter tuning
    #     # Train on best params
    #     # Evaluate on outer test fold
    #     ...
    
    # TODO: Compare with regular grid search
    # ...
    
    print("\n⚠️  TODO: Complete this advanced exercise!")
    print()


def run_all_exercises():
    """
    Run all exercises
    """
    print("\n" + "=" * 60)
    print("ADVANCED EXERCISES - MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    exercise1_simple_pipeline()
    exercise2_column_transformer()
    exercise3_cross_validation()
    exercise4_grid_search()
    exercise5_model_comparison()
    bonus_exercise_nested_cv()
    
    print("=" * 60)
    print("EXERCISES COMPLETE!")
    print("=" * 60)
    print("\nNext Steps:")
    print("1. Check solutions for implementations")
    print("2. Experiment with different hyperparameters")
    print("3. Apply these techniques to real datasets")
    print("4. Build end-to-end ML projects")


if __name__ == "__main__":
    """
    Main execution
    """
    run_all_exercises()
