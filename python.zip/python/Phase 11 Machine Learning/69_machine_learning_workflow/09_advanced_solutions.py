"""
Machine Learning Workflow - Advanced Exercises SOLUTIONS
========================================================

Complete solutions for advanced exercises.

Author: Educational Materials for Undergraduate CS
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import (train_test_split, cross_val_score,
                                      GridSearchCV, StratifiedKFold)
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import (accuracy_score, f1_score, classification_report,
                              precision_score, recall_score)
import time
import warnings
warnings.filterwarnings('ignore')


# =============================================================================
# SOLUTION 1: Build a Simple Pipeline
# =============================================================================
def solution1_simple_pipeline():
    """
    Solution 1: Build a Simple Pipeline
    """
    print("=" * 60)
    print("SOLUTION 1: Build a Simple Pipeline")
    print("=" * 60)
    
    # Create sample data
    np.random.seed(42)
    X = np.random.randn(1000, 5)
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    
    print(f"\nDataset: {X.shape[0]} samples, {X.shape[1]} features")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Testing set: {X_test.shape[0]} samples")
    
    # Build pipeline
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', LogisticRegression(random_state=42, max_iter=1000))
    ])
    
    print("\nPipeline Structure:")
    print("  1. StandardScaler - scales features")
    print("  2. LogisticRegression - classifier")
    
    # Fit pipeline (both steps in one call!)
    pipeline.fit(X_train, y_train)
    print("\n✓ Pipeline fitted on training data")
    
    # Evaluate
    y_pred = pipeline.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\nTest Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Advantages of pipelines
    print("\n" + "-" * 60)
    print("ADVANTAGES OF PIPELINES:")
    print("-" * 60)
    print("1. Single fit/predict call for entire workflow")
    print("2. Prevents data leakage (scaler fitted only on train)")
    print("3. Makes code cleaner and more maintainable")
    print("4. Easy to deploy (save single object)")
    print("5. Ensures consistency between train and test")
    
    print("\nWhy fit scaler only on training data?")
    print("  → Test data represents future unseen data")
    print("  → Using test statistics would leak information")
    print("  → In production, you won't have test data statistics")
    print("  → Fit on train, transform both train and test")
    print()


# =============================================================================
# SOLUTION 2: Build ColumnTransformer Pipeline
# =============================================================================
def solution2_column_transformer():
    """
    Solution 2: Build ColumnTransformer Pipeline
    """
    print("=" * 60)
    print("SOLUTION 2: ColumnTransformer Pipeline")
    print("=" * 60)
    
    # Create mixed-type dataset
    np.random.seed(42)
    n_samples = 800
    
    df = pd.DataFrame({
        'age': np.random.randint(20, 70, n_samples),
        'income': np.random.randint(30000, 120000, n_samples),
        'education': np.random.choice(['HS', 'BS', 'MS'], n_samples),
        'city': np.random.choice(['NYC', 'LA', 'SF'], n_samples),
        'approved': ((np.random.rand(n_samples) > 0.5).astype(int))
    })
    
    # Add missing values
    df.loc[df.sample(frac=0.1, random_state=42).index, 'income'] = np.nan
    df.loc[df.sample(frac=0.05, random_state=42).index, 'education'] = np.nan
    
    X = df.drop('approved', axis=1)
    y = df['approved']
    
    print(f"\nDataset shape: {X.shape}")
    print(f"Missing values: {X.isnull().sum().sum()}")
    
    # Define column types
    numerical_features = ['age', 'income']
    categorical_features = ['education', 'city']
    
    print(f"\nNumerical features: {numerical_features}")
    print(f"Categorical features: {categorical_features}")
    
    # Build numerical pipeline
    numerical_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    
    print("\nNumerical Pipeline:")
    print("  1. SimpleImputer(median) - handles missing values")
    print("  2. StandardScaler - normalizes to mean=0, std=1")
    
    # Build categorical pipeline
    categorical_pipeline = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False))
    ])
    
    print("\nCategorical Pipeline:")
    print("  1. SimpleImputer(mode) - handles missing values")
    print("  2. OneHotEncoder - converts to binary features")
    
    # Combine with ColumnTransformer
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_pipeline, numerical_features),
            ('cat', categorical_pipeline, categorical_features)
        ]
    )
    
    print("\nColumnTransformer combines both pipelines")
    
    # Build full pipeline
    full_pipeline = Pipeline([
        ('preprocessor', preprocessor),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    
    print("\nFull Pipeline Structure:")
    print("  1. ColumnTransformer (handles all preprocessing)")
    print("  2. RandomForestClassifier")
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Track shapes through pipeline
    print("\n" + "=" * 60)
    print("SHAPE TRANSFORMATIONS:")
    print("=" * 60)
    
    print(f"\n1. Original data:")
    print(f"   Shape: {X_train.shape}")
    print(f"   Columns: {X_train.columns.tolist()}")
    
    # Fit and transform to see intermediate shapes
    X_train_preprocessed = preprocessor.fit_transform(X_train)
    
    print(f"\n2. After preprocessing:")
    print(f"   Shape: {X_train_preprocessed.shape}")
    print(f"   Explanation:")
    print(f"   - {len(numerical_features)} numerical features → {len(numerical_features)} scaled features")
    
    # Get categorical feature names after one-hot encoding
    cat_encoder = preprocessor.named_transformers_['cat'].named_steps['onehot']
    cat_feature_names = cat_encoder.get_feature_names_out(categorical_features)
    print(f"   - {len(categorical_features)} categorical features → {len(cat_feature_names)} one-hot features")
    print(f"     Categories encoded: {list(cat_feature_names)}")
    
    # Train full pipeline
    print(f"\n3. Training full pipeline...")
    full_pipeline.fit(X_train, y_train)
    
    # Evaluate
    y_pred = full_pipeline.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"\nTest Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    print("\n✓ ColumnTransformer pipeline handles mixed data types automatically!")
    print()


# =============================================================================
# SOLUTION 3: Cross-Validation
# =============================================================================
def solution3_cross_validation():
    """
    Solution 3: Implement Cross-Validation
    """
    print("=" * 60)
    print("SOLUTION 3: Cross-Validation")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    X = np.random.randn(1000, 10)
    y = (X[:, 0] + 2*X[:, 1] - X[:, 2] + np.random.randn(1000)*0.5 > 0).astype(int)
    
    print(f"\nDataset: {X.shape[0]} samples, {X.shape[1]} features")
    
    # Build pipeline
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])
    
    # Perform 5-fold cross-validation
    print("\nPerforming 5-Fold Cross-Validation...")
    cv_scores = cross_val_score(
        pipeline, X, y,
        cv=5,
        scoring='accuracy',
        n_jobs=-1
    )
    
    # Calculate statistics
    mean_score = cv_scores.mean()
    std_score = cv_scores.std()
    
    print("\n" + "=" * 60)
    print("CROSS-VALIDATION RESULTS:")
    print("=" * 60)
    
    print(f"\nScores from each fold:")
    for i, score in enumerate(cv_scores, 1):
        print(f"  Fold {i}: {score:.4f}")
    
    print(f"\nMean Accuracy: {mean_score:.4f} (± {std_score:.4f})")
    print(f"Range: [{cv_scores.min():.4f}, {cv_scores.max():.4f}]")
    
    # Compare with single train-test split
    print("\n" + "=" * 60)
    print("COMPARISON WITH SINGLE SPLIT:")
    print("=" * 60)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    pipeline.fit(X_train, y_train)
    single_score = pipeline.score(X_test, y_test)
    
    print(f"\nSingle train-test split: {single_score:.4f}")
    print(f"Cross-validation mean:   {mean_score:.4f}")
    print(f"Difference:              {abs(single_score - mean_score):.4f}")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS:")
    print("-" * 60)
    
    print("\nWhy is cross-validation better?")
    print("  1. Uses all data for both training and testing")
    print("  2. Provides more reliable performance estimate")
    print("  3. Reduces impact of random train-test split")
    print("  4. Shows performance variability (std dev)")
    print("  5. Less prone to overfitting to specific test set")
    
    print("\nWhat does standard deviation tell you?")
    if std_score < 0.02:
        print(f"  → Low std ({std_score:.4f}) = Stable, consistent performance")
    elif std_score < 0.05:
        print(f"  → Moderate std ({std_score:.4f}) = Acceptable variation")
    else:
        print(f"  → High std ({std_score:.4f}) = Unstable, inconsistent model")
    
    print("\nWhen to use more or fewer folds?")
    print("  • More folds (10-20):")
    print("    - When dataset is small")
    print("    - Need most accurate estimate")
    print("    - Can afford longer computation")
    print("  • Fewer folds (3-5):")
    print("    - When dataset is large")
    print("    - Computational resources limited")
    print("    - Quick experimentation")
    print("  • Leave-One-Out (n folds):")
    print("    - Extremely small datasets (<100 samples)")
    print("    - Maximum data usage")
    print()


# =============================================================================
# SOLUTION 4: Grid Search for Hyperparameter Tuning
# =============================================================================
def solution4_grid_search():
    """
    Solution 4: Hyperparameter Tuning with Grid Search
    """
    print("=" * 60)
    print("SOLUTION 4: Grid Search Hyperparameter Tuning")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    X = np.random.randn(1000, 8)
    y = (X[:, 0] + X[:, 1] - X[:, 2] + X[:, 3] > 0).astype(int)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\nDataset: {X.shape[0]} samples, {X.shape[1]} features")
    print(f"Training: {X_train.shape[0]}, Testing: {X_test.shape[0]}")
    
    # Build pipeline
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(random_state=42, n_jobs=-1))
    ])
    
    # Define parameter grid
    param_grid = {
        'classifier__n_estimators': [50, 100, 200],
        'classifier__max_depth': [5, 10, None],
        'classifier__min_samples_split': [2, 5, 10]
    }
    
    print("\nParameter Grid:")
    for param, values in param_grid.items():
        print(f"  {param}: {values}")
    
    # Calculate total combinations
    total_combinations = 1
    for values in param_grid.values():
        total_combinations *= len(values)
    
    print(f"\nTotal combinations: {total_combinations}")
    print(f"With 3-fold CV: {total_combinations * 3} total fits")
    
    # Perform Grid Search
    print("\nPerforming Grid Search (this may take a moment)...")
    
    start_time = time.time()
    grid_search = GridSearchCV(
        pipeline,
        param_grid,
        cv=3,
        scoring='accuracy',
        n_jobs=-1,
        verbose=0,
        return_train_score=True
    )
    
    grid_search.fit(X_train, y_train)
    elapsed_time = time.time() - start_time
    
    print(f"✓ Grid search completed in {elapsed_time:.2f} seconds")
    
    # Print best parameters and score
    print("\n" + "=" * 60)
    print("BEST PARAMETERS:")
    print("=" * 60)
    for param, value in grid_search.best_params_.items():
        print(f"  {param}: {value}")
    
    print(f"\nBest Cross-Validation Score: {grid_search.best_score_:.4f}")
    
    # Test set performance with best model
    y_pred = grid_search.best_estimator_.predict(X_test)
    test_accuracy = accuracy_score(y_test, y_pred)
    print(f"Test Set Accuracy: {test_accuracy:.4f}")
    
    # Compare with default parameters
    print("\n" + "=" * 60)
    print("COMPARISON WITH DEFAULTS:")
    print("=" * 60)
    
    default_pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(random_state=42))
    ])
    
    default_pipeline.fit(X_train, y_train)
    default_accuracy = default_pipeline.score(X_test, y_test)
    
    print(f"\nDefault parameters accuracy: {default_accuracy:.4f}")
    print(f"Tuned parameters accuracy:   {test_accuracy:.4f}")
    print(f"Improvement:                 {(test_accuracy - default_accuracy):.4f}")
    
    if test_accuracy > default_accuracy:
        improvement_pct = ((test_accuracy - default_accuracy) / default_accuracy) * 100
        print(f"                             ({improvement_pct:.2f}% increase)")
    
    # Show top 5 configurations
    print("\n" + "=" * 60)
    print("TOP 5 CONFIGURATIONS:")
    print("=" * 60)
    
    results_df = pd.DataFrame(grid_search.cv_results_)
    results_df = results_df.sort_values('rank_test_score')
    
    print(f"\n{'Rank':<6} {'CV Score':<12} {'n_est':<8} {'max_d':<8} {'min_sp':<8}")
    print("-" * 50)
    
    for idx, row in results_df.head(5).iterrows():
        rank = int(row['rank_test_score'])
        score = row['mean_test_score']
        n_est = row['param_classifier__n_estimators']
        max_d = row['param_classifier__max_depth']
        min_sp = row['param_classifier__min_samples_split']
        
        max_d_str = str(max_d) if max_d is not None else 'None'
        
        print(f"{rank:<6} {score:<12.4f} {n_est:<8} {max_d_str:<8} {min_sp:<8}")
    
    print("\n✓ Grid search systematically finds optimal hyperparameters!")
    print()


# =============================================================================
# SOLUTION 5: Compare Multiple Models
# =============================================================================
def solution5_model_comparison():
    """
    Solution 5: Compare Multiple Models
    """
    print("=" * 60)
    print("SOLUTION 5: Compare Multiple Models")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    n_samples = 1500
    
    X = np.random.randn(n_samples, 10)
    y = (X[:, 0] + 2*X[:, 1] - X[:, 2] + X[:, 3] + 
         np.random.randn(n_samples)*0.5 > 0).astype(int)
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\nDataset: {X.shape[0]} samples, {X.shape[1]} features")
    print(f"Training: {X_train.shape[0]}, Testing: {X_test.shape[0]}")
    
    # Define preprocessing
    preprocessor = Pipeline([
        ('scaler', StandardScaler())
    ])
    
    # Define models
    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Random Forest': RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=-1),
        'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, random_state=42),
        'SVM': SVC(random_state=42, probability=True)
    }
    
    print(f"\nComparing {len(models)} models...")
    
    # Train and evaluate each model
    results = {}
    
    print("\n" + "=" * 60)
    print("TRAINING AND EVALUATION:")
    print("=" * 60)
    
    for name, model in models.items():
        print(f"\nTraining {name}...")
        
        # Create pipeline
        pipeline = Pipeline([
            ('preprocessor', preprocessor),
            ('classifier', model)
        ])
        
        # Train
        start_time = time.time()
        pipeline.fit(X_train, y_train)
        train_time = time.time() - start_time
        
        # Predict
        start_time = time.time()
        y_pred = pipeline.predict(X_test)
        predict_time = time.time() - start_time
        
        # Calculate metrics
        results[name] = {
            'accuracy': accuracy_score(y_test, y_pred),
            'precision': precision_score(y_test, y_pred),
            'recall': recall_score(y_test, y_pred),
            'f1': f1_score(y_test, y_pred),
            'train_time': train_time,
            'predict_time': predict_time
        }
        
        print(f"  ✓ Accuracy: {results[name]['accuracy']:.4f}")
    
    # Create comparison table
    print("\n" + "=" * 60)
    print("MODEL COMPARISON TABLE:")
    print("=" * 60)
    
    print(f"\n{'Model':<22} {'Accuracy':<12} {'Precision':<12} {'Recall':<12} {'F1':<12}")
    print("-" * 70)
    
    for model_name, metrics in results.items():
        print(f"{model_name:<22} "
              f"{metrics['accuracy']:<12.4f} "
              f"{metrics['precision']:<12.4f} "
              f"{metrics['recall']:<12.4f} "
              f"{metrics['f1']:<12.4f}")
    
    # Timing comparison
    print(f"\n{'Model':<22} {'Train Time':<15} {'Predict Time':<15}")
    print("-" * 55)
    
    for model_name, metrics in results.items():
        print(f"{model_name:<22} "
              f"{metrics['train_time']:<15.4f}s "
              f"{metrics['predict_time']:<15.6f}s")
    
    # Select best model
    print("\n" + "=" * 60)
    print("BEST MODEL SELECTION:")
    print("=" * 60)
    
    best_accuracy = max(results.items(), key=lambda x: x[1]['accuracy'])
    best_f1 = max(results.items(), key=lambda x: x[1]['f1'])
    fastest = min(results.items(), key=lambda x: x[1]['train_time'])
    
    print(f"\nBest Accuracy: {best_accuracy[0]} ({best_accuracy[1]['accuracy']:.4f})")
    print(f"Best F1-Score: {best_f1[0]} ({best_f1[1]['f1']:.4f})")
    print(f"Fastest Training: {fastest[0]} ({fastest[1]['train_time']:.4f}s)")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS:")
    print("-" * 60)
    
    print("\nWhich model performs best?")
    if best_accuracy[0] == best_f1[0]:
        print(f"  → {best_accuracy[0]} leads in both accuracy and F1-score")
    else:
        print(f"  → Depends on metric: {best_accuracy[0]} (accuracy) vs {best_f1[0]} (F1)")
    
    print("\nWhich metric is most important?")
    print("  → Balanced dataset: Accuracy is fine")
    print("  → Imbalanced dataset: F1-score better")
    print("  → Cost-sensitive: Consider precision vs recall")
    
    print("\nTrade-offs:")
    print("  → Random Forest: Good performance, moderate speed")
    print("  → Gradient Boosting: Best performance, slower training")
    print("  → Logistic Regression: Fast, interpretable, linear only")
    print("  → SVM: Good for smaller datasets, slow for large data")
    print()


# =============================================================================
# BONUS SOLUTION: Nested Cross-Validation
# =============================================================================
def bonus_solution_nested_cv():
    """
    Bonus Solution: Nested Cross-Validation
    """
    print("=" * 60)
    print("BONUS SOLUTION: Nested Cross-Validation")
    print("=" * 60)
    
    # Create dataset
    np.random.seed(42)
    X = np.random.randn(500, 6)
    y = (X[:, 0] + X[:, 1] > 0).astype(int)
    
    print(f"\nDataset: {X.shape[0]} samples, {X.shape[1]} features")
    
    # Define pipeline and parameter grid
    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(random_state=42))
    ])
    
    param_grid = {
        'classifier__n_estimators': [50, 100],
        'classifier__max_depth': [3, 5, None]
    }
    
    print("\nNested Cross-Validation Structure:")
    print("  Outer loop (5 folds): Model evaluation")
    print("  Inner loop (3 folds): Hyperparameter tuning")
    
    # Outer cross-validation
    outer_cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    # Nested CV loop
    print("\nPerforming Nested Cross-Validation...")
    nested_scores = []
    best_params_list = []
    
    for fold, (train_idx, test_idx) in enumerate(outer_cv.split(X, y), 1):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]
        
        # Inner CV: hyperparameter tuning
        inner_cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
        grid_search = GridSearchCV(
            pipeline, param_grid,
            cv=inner_cv,
            scoring='accuracy',
            n_jobs=-1
        )
        
        # Fit on this outer fold's training data
        grid_search.fit(X_train, y_train)
        
        # Evaluate on outer fold's test data
        score = grid_search.score(X_test, y_test)
        nested_scores.append(score)
        best_params_list.append(grid_search.best_params_)
        
        print(f"  Outer Fold {fold}: {score:.4f} | "
              f"Best params: {grid_search.best_params_}")
    
    # Results
    print("\n" + "=" * 60)
    print("NESTED CV RESULTS:")
    print("=" * 60)
    
    nested_mean = np.mean(nested_scores)
    nested_std = np.std(nested_scores)
    
    print(f"\nScores: {[f'{s:.4f}' for s in nested_scores]}")
    print(f"Mean: {nested_mean:.4f} (± {nested_std:.4f})")
    
    # Compare with regular grid search
    print("\n" + "=" * 60)
    print("COMPARISON WITH REGULAR GRID SEARCH:")
    print("=" * 60)
    
    regular_grid = GridSearchCV(
        pipeline, param_grid,
        cv=5,
        scoring='accuracy',
        n_jobs=-1
    )
    regular_grid.fit(X, y)
    regular_score = regular_grid.best_score_
    
    print(f"\nRegular Grid Search CV score: {regular_score:.4f}")
    print(f"Nested CV mean score:         {nested_mean:.4f}")
    print(f"Difference:                   {abs(regular_score - nested_mean):.4f}")
    
    # Analysis
    print("\n" + "-" * 60)
    print("ANALYSIS:")
    print("-" * 60)
    
    print("\nWhy use nested cross-validation?")
    print("  1. Provides unbiased estimate of model performance")
    print("  2. Regular CV can be optimistic (test data influences tuning)")
    print("  3. Nested CV: test data never seen during tuning")
    print("  4. More realistic estimate for new data")
    
    print("\nDifference between inner and outer loops:")
    print("  • Inner loop: Tunes hyperparameters")
    print("    - Finds best parameters for each fold")
    print("    - Uses cross-validation itself")
    print("  • Outer loop: Evaluates final model")
    print("    - Tests generalization ability")
    print("    - Completely independent from tuning")
    
    print("\nWhen is nested CV necessary?")
    print("  → Research: Need unbiased performance estimate")
    print("  → Model comparison: Fair comparison between models")
    print("  → Small datasets: Every sample matters")
    print("  → Not needed: Large datasets with separate test set")
    
    print("\nComputational cost:")
    total_fits = 5 * (3 * len(param_grid['classifier__n_estimators']) * 
                      len(param_grid['classifier__max_depth']))
    print(f"  This example: ~{total_fits} model fits")
    print(f"  Can be expensive for complex models/grids!")
    print()


def run_all_solutions():
    """
    Run all solutions
    """
    print("\n" + "=" * 60)
    print("ADVANCED SOLUTIONS - MACHINE LEARNING WORKFLOW")
    print("=" * 60 + "\n")
    
    solution1_simple_pipeline()
    solution2_column_transformer()
    solution3_cross_validation()
    solution4_grid_search()
    solution5_model_comparison()
    bonus_solution_nested_cv()
    
    print("=" * 60)
    print("ALL SOLUTIONS DEMONSTRATED!")
    print("=" * 60)
    print("\nLearning Outcomes:")
    print("✓ Building ML pipelines")
    print("✓ Handling mixed data types with ColumnTransformer")
    print("✓ Cross-validation for robust evaluation")
    print("✓ Hyperparameter tuning with Grid Search")
    print("✓ Comparing multiple models systematically")
    print("✓ Nested cross-validation for unbiased estimates")


if __name__ == "__main__":
    """
    Main execution
    """
    run_all_solutions()
