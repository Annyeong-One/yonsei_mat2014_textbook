"""
============================================================================
BEGINNER LEVEL: Basic Feature Creation
============================================================================

Course: Undergraduate Python Programming
Module: Feature Engineering - Feature Creation and Selection
Level: Beginner
Topic: Basic Feature Creation Techniques

Learning Objectives:
-------------------
1. Understand what feature engineering is and why it matters
2. Learn to create basic numerical features from existing data
3. Extract features from datetime data
4. Create simple categorical features
5. Generate text-based features
6. Understand the importance of domain knowledge in feature engineering

Prerequisites:
--------------
- Basic Python programming
- Pandas fundamentals
- NumPy basics
- Understanding of data types

Estimated Time: 60-90 minutes
============================================================================
"""

# Import necessary libraries
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("BEGINNER: Basic Feature Creation")
print("=" * 80)
print()

# ============================================================================
# SECTION 1: Introduction to Feature Engineering
# ============================================================================
print("SECTION 1: Introduction to Feature Engineering")
print("-" * 80)

"""
WHAT IS FEATURE ENGINEERING?

Feature engineering is the process of using domain knowledge to create new
features (variables) from raw data that make machine learning algorithms work
better.

WHY IS IT IMPORTANT?

1. Better features often improve model performance more than better algorithms
2. Domain knowledge can be encoded into features
3. Features can make relationships more obvious to models
4. Can reduce the need for complex models

TYPES OF FEATURES:
- Numerical: Continuous or discrete numbers (age, price, count)
- Categorical: Categories or groups (color, city, product type)
- Ordinal: Ordered categories (low, medium, high)
- Boolean: True/False or Yes/No
- Datetime: Date and time information
- Text: Free-form text data
"""

# Let's create a sample dataset to work with
# This represents a simple e-commerce dataset
np.random.seed(42)

# Generate sample data
n_samples = 100

data = {
    'customer_id': range(1, n_samples + 1),
    'purchase_date': pd.date_range(start='2023-01-01', periods=n_samples, freq='D'),
    'age': np.random.randint(18, 70, n_samples),
    'income': np.random.randint(20000, 150000, n_samples),
    'purchase_amount': np.random.uniform(10, 1000, n_samples),
    'num_items': np.random.randint(1, 20, n_samples),
    'product_category': np.random.choice(['Electronics', 'Clothing', 'Food', 'Books', 'Home'], n_samples),
    'shipping_method': np.random.choice(['Standard', 'Express', 'Next-Day'], n_samples),
    'is_member': np.random.choice([True, False], n_samples),
    'review_text': ['Great product! ' * np.random.randint(1, 5) for _ in range(n_samples)]
}

df = pd.DataFrame(data)

print("\nOriginal Dataset (first 5 rows):")
print(df.head())
print(f"\nDataset shape: {df.shape}")
print(f"Columns: {list(df.columns)}")
print()

# ============================================================================
# SECTION 2: Basic Numerical Feature Creation
# ============================================================================
print("\nSECTION 2: Basic Numerical Feature Creation")
print("-" * 80)

"""
NUMERICAL FEATURE CREATION TECHNIQUES:

1. Arithmetic Operations: Create new features using +, -, *, /
2. Aggregations: Sum, mean, max, min, std, etc.
3. Ratios: Divide one feature by another
4. Differences: Subtract features
5. Products: Multiply features
6. Mathematical Functions: log, sqrt, power, etc.

These operations help reveal relationships that might not be obvious.
"""

# 2.1: Creating Ratio Features
# Ratios can reveal important relationships
print("\n2.1: Ratio Features")
print("-" * 40)

# Average price per item
# This tells us if someone buys expensive items or many cheap items
df['avg_price_per_item'] = df['purchase_amount'] / df['num_items']

print("Created: avg_price_per_item = purchase_amount / num_items")
print(df[['purchase_amount', 'num_items', 'avg_price_per_item']].head())
print()

# 2.2: Creating Aggregation Features
# Aggregations summarize information in useful ways
print("\n2.2: Aggregation Features")
print("-" * 40)

# Total spending capacity indicator
# Combines income and spending to understand purchasing power
df['spending_capacity'] = df['income'] + df['purchase_amount']

print("Created: spending_capacity = income + purchase_amount")
print(df[['income', 'purchase_amount', 'spending_capacity']].head())
print()

# 2.3: Creating Percentage Features
# Percentages help normalize values for comparison
print("\n2.3: Percentage Features")
print("-" * 40)

# What percentage of their income did they spend?
# This is a powerful feature showing spending behavior
df['spend_to_income_ratio'] = (df['purchase_amount'] / df['income']) * 100

print("Created: spend_to_income_ratio = (purchase_amount / income) * 100")
print(df[['purchase_amount', 'income', 'spend_to_income_ratio']].head())
print()

# 2.4: Creating Binned Features
# Converting continuous variables into categories
print("\n2.4: Binned Features (Discretization)")
print("-" * 40)

"""
Binning is useful when:
- Relationships are non-linear
- You want to reduce noise
- You need to create categorical features from numerical ones
"""

# Create age groups
# This can capture different life stages with different behaviors
df['age_group'] = pd.cut(df['age'], 
                          bins=[0, 25, 35, 50, 100], 
                          labels=['Young', 'Adult', 'Middle-Age', 'Senior'])

print("Created: age_group from age using bins [0, 25, 35, 50, 100]")
print(df[['age', 'age_group']].head(10))
print()

# Create income brackets
df['income_bracket'] = pd.cut(df['income'],
                               bins=[0, 40000, 70000, 100000, 200000],
                               labels=['Low', 'Medium', 'High', 'Very High'])

print("Created: income_bracket from income")
print(df[['income', 'income_bracket']].head(10))
print()

# 2.5: Mathematical Transformations
# Transformations can help with skewed distributions
print("\n2.5: Mathematical Transformations")
print("-" * 40)

"""
Common transformations:
- Log: Reduces right skewness, useful for exponential relationships
- Square Root: Mild transformation for right skewness
- Square/Power: For left skewness
- Reciprocal: For very skewed data
"""

# Log transformation for purchase amount
# Useful when dealing with wide range of values
df['log_purchase_amount'] = np.log1p(df['purchase_amount'])  # log1p = log(1 + x) to handle zeros

print("Created: log_purchase_amount = log(1 + purchase_amount)")
print(df[['purchase_amount', 'log_purchase_amount']].head())
print()

# Square root transformation
df['sqrt_income'] = np.sqrt(df['income'])

print("Created: sqrt_income = sqrt(income)")
print(df[['income', 'sqrt_income']].head())
print()

# ============================================================================
# SECTION 3: DateTime Feature Extraction
# ============================================================================
print("\nSECTION 3: DateTime Feature Extraction")
print("-" * 80)

"""
DATETIME FEATURES ARE POWERFUL!

From a single datetime column, we can extract:
- Year, Month, Day
- Day of week, Day of year
- Hour, Minute, Second
- Is weekend? Is holiday?
- Season
- Time since epoch
- Days until/since specific date

These features can capture temporal patterns and seasonality.
"""

# 3.1: Basic Date Components
print("\n3.1: Basic Date Components")
print("-" * 40)

# Extract year, month, day
df['purchase_year'] = df['purchase_date'].dt.year
df['purchase_month'] = df['purchase_date'].dt.month
df['purchase_day'] = df['purchase_date'].dt.day

print("Extracted: year, month, day from purchase_date")
print(df[['purchase_date', 'purchase_year', 'purchase_month', 'purchase_day']].head())
print()

# 3.2: Day of Week Features
print("\n3.2: Day of Week Features")
print("-" * 40)

# Day of week (0=Monday, 6=Sunday)
df['purchase_dayofweek'] = df['purchase_date'].dt.dayofweek

# Day name (more readable)
df['purchase_dayname'] = df['purchase_date'].dt.day_name()

print("Extracted: day of week and day name")
print(df[['purchase_date', 'purchase_dayofweek', 'purchase_dayname']].head(10))
print()

# 3.3: Weekend Indicator
print("\n3.3: Weekend Indicator")
print("-" * 40)

# Create binary feature: is it a weekend?
# This is useful because shopping behavior differs on weekends
df['is_weekend'] = df['purchase_dayofweek'].isin([5, 6]).astype(int)

print("Created: is_weekend (1 if Saturday or Sunday, 0 otherwise)")
print(df[['purchase_date', 'purchase_dayname', 'is_weekend']].head(10))
print()

# 3.4: Season Extraction
print("\n3.4: Season Extraction")
print("-" * 40)

"""
Seasons can have strong effects on purchasing behavior:
- Winter: Holiday shopping
- Spring: Renewal, outdoor items
- Summer: Vacation, outdoor
- Fall: Back to school
"""

def get_season(month):
    """
    Determine season based on month.
    
    Parameters:
    -----------
    month : int
        Month number (1-12)
    
    Returns:
    --------
    str : Season name
    """
    if month in [12, 1, 2]:
        return 'Winter'
    elif month in [3, 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8]:
        return 'Summer'
    else:
        return 'Fall'

df['purchase_season'] = df['purchase_month'].apply(get_season)

print("Created: purchase_season based on month")
print(df[['purchase_date', 'purchase_month', 'purchase_season']].head(12))
print()

# 3.5: Time-based Features
print("\n3.5: Time-based Features")
print("-" * 40)

# Days since first purchase (relative time)
# This can indicate customer lifecycle
first_purchase_date = df['purchase_date'].min()
df['days_since_first'] = (df['purchase_date'] - first_purchase_date).dt.days

print(f"Created: days_since_first (relative to {first_purchase_date.date()})")
print(df[['purchase_date', 'days_since_first']].head(10))
print()

# Quarter of year
df['purchase_quarter'] = df['purchase_date'].dt.quarter

print("Created: purchase_quarter")
print(df[['purchase_date', 'purchase_quarter']].head(12))
print()

# ============================================================================
# SECTION 4: Categorical Feature Creation
# ============================================================================
print("\nSECTION 4: Categorical Feature Creation")
print("-" * 80)

"""
CATEGORICAL FEATURE TECHNIQUES:

1. Combining categories
2. Creating binary flags
3. Grouping rare categories
4. Creating hierarchies
5. Interaction features
"""

# 4.1: Binary Flag Creation
print("\n4.1: Binary Flag Creation")
print("-" * 40)

# Create flags for specific conditions
# These are simple but powerful features

# Is the customer a high spender?
df['is_high_spender'] = (df['purchase_amount'] > df['purchase_amount'].quantile(0.75)).astype(int)

print("Created: is_high_spender (1 if purchase_amount > 75th percentile)")
print(df[['purchase_amount', 'is_high_spender']].value_counts(normalize=True) * 100)
print()

# Is this an electronics purchase?
df['is_electronics'] = (df['product_category'] == 'Electronics').astype(int)

print("Created: is_electronics")
print(df[['product_category', 'is_electronics']].head(10))
print()

# 4.2: Category Combination
print("\n4.2: Category Combination")
print("-" * 40)

# Combine multiple categorical features
# This creates more specific segments
df['member_shipping'] = df['is_member'].astype(str) + '_' + df['shipping_method']

print("Created: member_shipping (combination of is_member and shipping_method)")
print(df[['is_member', 'shipping_method', 'member_shipping']].head(10))
print(f"\nUnique combinations: {df['member_shipping'].nunique()}")
print(df['member_shipping'].value_counts())
print()

# 4.3: Frequency-based Features
print("\n4.3: Frequency-based Features")
print("-" * 40)

"""
Frequency encoding: Replace categories with their frequency
Useful when frequency is informative
"""

# How common is each product category?
category_freq = df['product_category'].value_counts()
df['category_frequency'] = df['product_category'].map(category_freq)

print("Created: category_frequency (count of each category)")
print(df[['product_category', 'category_frequency']].head(10))
print()

# Percentage of each category
category_pct = df['product_category'].value_counts(normalize=True) * 100
df['category_percentage'] = df['product_category'].map(category_pct)

print("Created: category_percentage")
print(df[['product_category', 'category_percentage']].head(10))
print()

# ============================================================================
# SECTION 5: Text Feature Creation
# ============================================================================
print("\nSECTION 5: Text Feature Creation")
print("-" * 80)

"""
TEXT FEATURE EXTRACTION:

From text data, we can create:
- Length features (characters, words)
- Count features (specific words, punctuation)
- Binary features (contains specific word?)
- Statistical features (average word length)
"""

# 5.1: Basic Text Length Features
print("\n5.1: Basic Text Length Features")
print("-" * 40)

# Character count
df['review_length'] = df['review_text'].str.len()

print("Created: review_length (number of characters)")
print(df[['review_text', 'review_length']].head())
print()

# Word count
df['review_word_count'] = df['review_text'].str.split().str.len()

print("Created: review_word_count (number of words)")
print(df[['review_text', 'review_word_count']].head())
print()

# Average word length
df['avg_word_length'] = df['review_length'] / df['review_word_count']

print("Created: avg_word_length")
print(df[['review_text', 'review_length', 'review_word_count', 'avg_word_length']].head())
print()

# 5.2: Punctuation and Special Character Features
print("\n5.2: Punctuation Features")
print("-" * 40)

# Count exclamation marks (might indicate enthusiasm)
df['exclamation_count'] = df['review_text'].str.count('!')

print("Created: exclamation_count")
print(df[['review_text', 'exclamation_count']].head(10))
print()

# Count uppercase words (might indicate emphasis)
df['uppercase_count'] = df['review_text'].apply(lambda x: sum(1 for word in x.split() if word.isupper()))

print("Created: uppercase_count")
print(df[['review_text', 'uppercase_count']].head())
print()

# ============================================================================
# SECTION 6: Feature Interaction
# ============================================================================
print("\nSECTION 6: Feature Interaction")
print("-" * 80)

"""
FEATURE INTERACTIONS:

Sometimes the combination of features is more informative than individual features.
For example:
- Income AND age together define purchasing power better
- Product category AND season together predict sales better
"""

# 6.1: Numerical Interactions
print("\n6.1: Numerical Interactions")
print("-" * 40)

# Interaction between age and income
# Younger high earners behave differently than older high earners
df['age_income_interaction'] = df['age'] * df['income']

print("Created: age_income_interaction = age * income")
print(df[['age', 'income', 'age_income_interaction']].head())
print()

# Interaction between spending and number of items
df['total_item_value'] = df['purchase_amount'] * df['num_items']

print("Created: total_item_value = purchase_amount * num_items")
print(df[['purchase_amount', 'num_items', 'total_item_value']].head())
print()

# 6.2: Categorical Interactions
print("\n6.2: Categorical Interactions")
print("-" * 40)

# Combine category and season
# Some products sell better in certain seasons
df['category_season'] = df['product_category'] + '_' + df['purchase_season']

print("Created: category_season")
print(df[['product_category', 'purchase_season', 'category_season']].head(10))
print(f"\nUnique combinations: {df['category_season'].nunique()}")
print()

# ============================================================================
# SECTION 7: Summary and Best Practices
# ============================================================================
print("\nSECTION 7: Summary and Best Practices")
print("-" * 80)

print("\nFinal dataset shape:", df.shape)
print(f"Original features: {len(data.keys())}")
print(f"Engineered features: {df.shape[1] - len(data.keys())}")
print(f"Total features: {df.shape[1]}")
print()

print("All Features:")
print("-" * 40)
for i, col in enumerate(df.columns, 1):
    print(f"{i:2d}. {col}")
print()

"""
BEST PRACTICES FOR FEATURE ENGINEERING:

1. UNDERSTAND YOUR DATA
   - Know what each feature represents
   - Understand the domain (business context)
   - Look at distributions and relationships

2. START SIMPLE
   - Begin with obvious features
   - Add complexity gradually
   - Test each feature's impact

3. USE DOMAIN KNOWLEDGE
   - Think about what matters in the real world
   - Consult domain experts
   - Read research in the field

4. AVOID DATA LEAKAGE
   - Don't use information from the future
   - Don't use target variable to create features
   - Be careful with time-series data

5. VALIDATE YOUR FEATURES
   - Check if features improve model performance
   - Use cross-validation
   - Look for correlation with target

6. HANDLE MISSING VALUES
   - Decide before creating features
   - Consider missingness as information
   - Be consistent in train and test sets

7. DOCUMENT YOUR WORK
   - Keep track of features created
   - Note why each feature might be useful
   - Record any domain assumptions

8. ITERATE
   - Feature engineering is iterative
   - Try different approaches
   - Learn from model performance

COMMON MISTAKES TO AVOID:

❌ Creating too many features without testing
❌ Using future information (data leakage)
❌ Not handling missing values properly
❌ Forgetting to apply same transformations to test data
❌ Creating features without understanding why
❌ Not checking for correlations between features
❌ Overfitting to training data
❌ Ignoring computational cost
"""

print("\n" + "=" * 80)
print("BEGINNER TUTORIAL COMPLETED!")
print("=" * 80)
print()
print("Key Takeaways:")
print("-" * 80)
print("1. Feature engineering is creating new features from existing data")
print("2. Good features often improve models more than better algorithms")
print("3. Domain knowledge is crucial for creating meaningful features")
print("4. Common techniques: ratios, aggregations, datetime extraction, binning")
print("5. Always validate features and avoid data leakage")
print("6. Start simple and add complexity gradually")
print()
print("Next Steps:")
print("-" * 80)
print("1. Complete the exercise file to practice these concepts")
print("2. Try creating your own features with different datasets")
print("3. Move to intermediate level to learn encoding techniques")
print("=" * 80)
