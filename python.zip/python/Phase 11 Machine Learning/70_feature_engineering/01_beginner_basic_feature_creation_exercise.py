"""
============================================================================
BEGINNER LEVEL: Basic Feature Creation - EXERCISE
============================================================================

Course: Undergraduate Python Programming
Module: Feature Engineering - Feature Creation and Selection
Level: Beginner
Type: Practice Exercises

Instructions:
-------------
1. Read each exercise carefully
2. Write your code in the designated areas
3. Test your code to ensure it works
4. Compare your solution with the solution file after attempting
5. Don't hesitate to experiment and try different approaches

Time Estimate: 45-60 minutes
============================================================================
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

print("=" * 80)
print("BEGINNER EXERCISES: Basic Feature Creation")
print("=" * 80)
print()

# ============================================================================
# DATASET PREPARATION
# ============================================================================
print("Loading Dataset...")
print("-" * 80)

# Create a fitness app dataset
np.random.seed(42)
n_users = 150

fitness_data = {
    'user_id': range(1, n_users + 1),
    'signup_date': pd.date_range(start='2023-01-01', periods=n_users, freq='D'),
    'age': np.random.randint(18, 65, n_users),
    'weight_kg': np.random.uniform(50, 120, n_users),
    'height_cm': np.random.uniform(150, 200, n_users),
    'workout_duration_min': np.random.randint(10, 120, n_users),
    'calories_burned': np.random.randint(100, 800, n_users),
    'steps_count': np.random.randint(1000, 20000, n_users),
    'heart_rate_avg': np.random.randint(60, 120, n_users),
    'workout_type': np.random.choice(['Running', 'Cycling', 'Swimming', 'Gym', 'Yoga'], n_users),
    'subscription_type': np.random.choice(['Free', 'Basic', 'Premium'], n_users),
    'is_premium': np.random.choice([True, False], n_users),
    'workout_notes': ['Felt great today! ' * np.random.randint(1, 4) for _ in range(n_users)]
}

df = pd.DataFrame(fitness_data)

print("Fitness App Dataset Loaded!")
print(f"Shape: {df.shape}")
print(f"\nFirst 5 rows:")
print(df.head())
print(f"\nData types:")
print(df.dtypes)
print()

# ============================================================================
# EXERCISE 1: Basic Numerical Features (15 points)
# ============================================================================
print("\n" + "=" * 80)
print("EXERCISE 1: Basic Numerical Features")
print("=" * 80)
print()

"""
TASK 1.1: Calculate BMI (Body Mass Index)
Formula: BMI = weight_kg / (height_m)^2
Note: height is in cm, convert to meters first

Create a new feature called 'bmi'
"""
print("Task 1.1: Calculate BMI")
print("-" * 40)

# YOUR CODE HERE
# df['bmi'] = ?

# Uncomment to test your answer:
# print("BMI Statistics:")
# print(df[['weight_kg', 'height_cm', 'bmi']].describe())
# print()

"""
TASK 1.2: Calculate Calorie Burn Rate
Calculate calories burned per minute of workout

Create a new feature called 'calorie_burn_rate'
"""
print("\nTask 1.2: Calculate Calorie Burn Rate")
print("-" * 40)

# YOUR CODE HERE
# df['calorie_burn_rate'] = ?

# Uncomment to test your answer:
# print("Calorie Burn Rate Statistics:")
# print(df[['calories_burned', 'workout_duration_min', 'calorie_burn_rate']].head(10))
# print()

"""
TASK 1.3: Calculate Exercise Intensity Score
Create a score based on: (calories_burned * heart_rate_avg) / workout_duration_min
This gives us an intensity metric

Create a new feature called 'intensity_score'
"""
print("\nTask 1.3: Calculate Exercise Intensity Score")
print("-" * 40)

# YOUR CODE HERE
# df['intensity_score'] = ?

# Uncomment to test your answer:
# print("Intensity Score Statistics:")
# print(df['intensity_score'].describe())
# print()

"""
TASK 1.4: Create Age Groups
Create age categories:
- 'Young': 18-30
- 'Adult': 31-45
- 'Middle': 46-60
- 'Senior': 61+

Create a new feature called 'age_category'
"""
print("\nTask 1.4: Create Age Groups")
print("-" * 40)

# YOUR CODE HERE
# Use pd.cut() to create age categories
# df['age_category'] = ?

# Uncomment to test your answer:
# print("Age Category Distribution:")
# print(df['age_category'].value_counts().sort_index())
# print()

# ============================================================================
# EXERCISE 2: DateTime Features (15 points)
# ============================================================================
print("\n" + "=" * 80)
print("EXERCISE 2: DateTime Features")
print("=" * 80)
print()

"""
TASK 2.1: Extract Signup Month and Year
Extract the month and year from signup_date

Create features: 'signup_month' and 'signup_year'
"""
print("Task 2.1: Extract Signup Month and Year")
print("-" * 40)

# YOUR CODE HERE
# df['signup_month'] = ?
# df['signup_year'] = ?

# Uncomment to test your answer:
# print("Signup Month Distribution:")
# print(df['signup_month'].value_counts().sort_index())
# print()

"""
TASK 2.2: Calculate Days Since Signup
Calculate how many days have passed since each user signed up
Use today's date as reference: datetime.now()

Create a new feature called 'days_since_signup'
"""
print("\nTask 2.2: Calculate Days Since Signup")
print("-" * 40)

# YOUR CODE HERE
# today = datetime.now()
# df['days_since_signup'] = ?

# Uncomment to test your answer:
# print("Days Since Signup Statistics:")
# print(df[['signup_date', 'days_since_signup']].head(10))
# print()

"""
TASK 2.3: Determine Signup Quarter
Determine which quarter of the year each user signed up
(Q1: Jan-Mar, Q2: Apr-Jun, Q3: Jul-Sep, Q4: Oct-Dec)

Create a new feature called 'signup_quarter'
"""
print("\nTask 2.3: Determine Signup Quarter")
print("-" * 40)

# YOUR CODE HERE
# df['signup_quarter'] = ?

# Uncomment to test your answer:
# print("Signup Quarter Distribution:")
# print(df['signup_quarter'].value_counts().sort_index())
# print()

"""
TASK 2.4: Create Weekend Signup Indicator
Determine if the user signed up on a weekend (Saturday or Sunday)

Create a new feature called 'signup_weekend' (1 for weekend, 0 for weekday)
"""
print("\nTask 2.4: Create Weekend Signup Indicator")
print("-" * 40)

# YOUR CODE HERE
# df['signup_weekend'] = ?

# Uncomment to test your answer:
# print("Weekend Signup Distribution:")
# print(df['signup_weekend'].value_counts())
# print()

# ============================================================================
# EXERCISE 3: Categorical Features (10 points)
# ============================================================================
print("\n" + "=" * 80)
print("EXERCISE 3: Categorical Features")
print("=" * 80)
print()

"""
TASK 3.1: Create High Activity Indicator
Create a binary feature indicating if steps_count > 10000

Create a new feature called 'is_high_activity' (1 if > 10000, else 0)
"""
print("Task 3.1: Create High Activity Indicator")
print("-" * 40)

# YOUR CODE HERE
# df['is_high_activity'] = ?

# Uncomment to test your answer:
# print("High Activity Distribution:")
# print(df['is_high_activity'].value_counts())
# print()

"""
TASK 3.2: Calculate Workout Type Frequency
For each workout type, calculate how many times it appears
Map this frequency back to each row

Create a new feature called 'workout_type_frequency'
"""
print("\nTask 3.2: Calculate Workout Type Frequency")
print("-" * 40)

# YOUR CODE HERE
# workout_freq = ?
# df['workout_type_frequency'] = ?

# Uncomment to test your answer:
# print("Workout Type Frequency:")
# print(df[['workout_type', 'workout_type_frequency']].head(10))
# print()

"""
TASK 3.3: Create Combined Feature
Combine subscription_type and workout_type to create segments

Create a new feature called 'user_segment'
Format: "subscription_workout" (e.g., "Premium_Running")
"""
print("\nTask 3.3: Create Combined Feature")
print("-" * 40)

# YOUR CODE HERE
# df['user_segment'] = ?

# Uncomment to test your answer:
# print("User Segments:")
# print(df['user_segment'].value_counts())
# print()

# ============================================================================
# EXERCISE 4: Text Features (10 points)
# ============================================================================
print("\n" + "=" * 80)
print("EXERCISE 4: Text Features")
print("=" * 80)
print()

"""
TASK 4.1: Calculate Note Length
Count the number of characters in workout_notes

Create a new feature called 'note_length'
"""
print("Task 4.1: Calculate Note Length")
print("-" * 40)

# YOUR CODE HERE
# df['note_length'] = ?

# Uncomment to test your answer:
# print("Note Length Statistics:")
# print(df[['workout_notes', 'note_length']].head(10))
# print()

"""
TASK 4.2: Count Words in Notes
Count the number of words in workout_notes

Create a new feature called 'note_word_count'
"""
print("\nTask 4.2: Count Words in Notes")
print("-" * 40)

# YOUR CODE HERE
# df['note_word_count'] = ?

# Uncomment to test your answer:
# print("Word Count Statistics:")
# print(df[['workout_notes', 'note_word_count']].head(10))
# print()

"""
TASK 4.3: Count Exclamation Marks
Count how many exclamation marks (!) appear in workout_notes
This might indicate enthusiasm!

Create a new feature called 'excitement_level'
"""
print("\nTask 4.3: Count Exclamation Marks")
print("-" * 40)

# YOUR CODE HERE
# df['excitement_level'] = ?

# Uncomment to test your answer:
# print("Excitement Level Distribution:")
# print(df['excitement_level'].value_counts().sort_index())
# print()

# ============================================================================
# EXERCISE 5: Feature Interactions (10 points)
# ============================================================================
print("\n" + "=" * 80)
print("EXERCISE 5: Feature Interactions")
print("=" * 80)
print()

"""
TASK 5.1: Create BMI-Age Interaction
Multiply BMI by age to create an interaction feature
This might help identify health risk patterns

Create a new feature called 'bmi_age_interaction'
Note: You need to have completed Task 1.1 first
"""
print("Task 5.1: Create BMI-Age Interaction")
print("-" * 40)

# YOUR CODE HERE
# df['bmi_age_interaction'] = ?

# Uncomment to test your answer:
# print("BMI-Age Interaction Statistics:")
# print(df['bmi_age_interaction'].describe())
# print()

"""
TASK 5.2: Create Efficiency Score
Calculate: (steps_count * calories_burned) / workout_duration_min
This gives us an overall workout efficiency metric

Create a new feature called 'workout_efficiency'
"""
print("\nTask 5.2: Create Efficiency Score")
print("-" * 40)

# YOUR CODE HERE
# df['workout_efficiency'] = ?

# Uncomment to test your answer:
# print("Workout Efficiency Statistics:")
# print(df['workout_efficiency'].describe())
# print()

# ============================================================================
# BONUS CHALLENGES (Optional - 10 extra points)
# ============================================================================
print("\n" + "=" * 80)
print("BONUS CHALLENGES (Optional)")
print("=" * 80)
print()

"""
BONUS 1: Create Activity Level Categories
Based on steps_count, categorize users:
- 'Sedentary': < 5000 steps
- 'Lightly Active': 5000-7499 steps
- 'Moderately Active': 7500-9999 steps
- 'Active': 10000-12499 steps
- 'Very Active': >= 12500 steps

Create a new feature called 'activity_level'
"""
print("Bonus 1: Create Activity Level Categories")
print("-" * 40)

# YOUR CODE HERE
# df['activity_level'] = ?

# Uncomment to test your answer:
# print("Activity Level Distribution:")
# print(df['activity_level'].value_counts())
# print()

"""
BONUS 2: Create Season Feature
Based on signup_month, determine the season:
- Winter: 12, 1, 2
- Spring: 3, 4, 5
- Summer: 6, 7, 8
- Fall: 9, 10, 11

Create a new feature called 'signup_season'
Hint: Write a function and use .apply()
"""
print("\nBonus 2: Create Season Feature")
print("-" * 40)

# YOUR CODE HERE
# def get_season(month):
#     # Your logic here
#     pass

# df['signup_season'] = ?

# Uncomment to test your answer:
# print("Signup Season Distribution:")
# print(df['signup_season'].value_counts())
# print()

"""
BONUS 3: Create Normalized Features
Normalize (scale to 0-1) the following features:
- workout_duration_min
- calories_burned
- steps_count

Formula: (value - min) / (max - min)

Create features: 'workout_duration_norm', 'calories_norm', 'steps_norm'
"""
print("\nBonus 3: Create Normalized Features")
print("-" * 40)

# YOUR CODE HERE
# df['workout_duration_norm'] = ?
# df['calories_norm'] = ?
# df['steps_norm'] = ?

# Uncomment to test your answer:
# print("Normalized Features Statistics:")
# print(df[['workout_duration_norm', 'calories_norm', 'steps_norm']].describe())
# print()

# ============================================================================
# FINAL CHECK
# ============================================================================
print("\n" + "=" * 80)
print("EXERCISE COMPLETION CHECK")
print("=" * 80)
print()

"""
Once you've completed all exercises, uncomment the code below to see
all the features you've created!
"""

# print("Final Dataset Shape:", df.shape)
# print("\nAll Features Created:")
# print("-" * 40)
# for i, col in enumerate(df.columns, 1):
#     original = col in fitness_data.keys()
#     feature_type = "ORIGINAL" if original else "ENGINEERED"
#     print(f"{i:2d}. {col:30s} [{feature_type}]")
# print()

# new_features = [col for col in df.columns if col not in fitness_data.keys()]
# print(f"\nTotal Engineered Features: {len(new_features)}")
# print("=" * 80)

print("\n" + "=" * 80)
print("EXERCISE INSTRUCTIONS")
print("=" * 80)
print("""
1. Complete each task by writing code in the designated areas
2. Test your code by uncommenting the test sections
3. Make sure your code runs without errors
4. Compare your solutions with the solution file
5. Experiment with different approaches
6. Ask questions if you get stuck!

SCORING GUIDE (out of 60 points + 10 bonus):
- Exercise 1 (Numerical Features): 15 points
- Exercise 2 (DateTime Features): 15 points
- Exercise 3 (Categorical Features): 10 points
- Exercise 4 (Text Features): 10 points
- Exercise 5 (Feature Interactions): 10 points
- Bonus Challenges: 10 extra points

Good luck! Remember: Feature engineering is as much art as science.
Think about what features might be useful for predicting user behavior!
""")
print("=" * 80)
