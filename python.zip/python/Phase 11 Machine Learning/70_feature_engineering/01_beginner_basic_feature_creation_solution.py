"""
============================================================================
BEGINNER LEVEL: Basic Feature Creation - SOLUTION
============================================================================

Course: Undergraduate Python Programming
Module: Feature Engineering - Feature Creation and Selection
Level: Beginner
Type: Exercise Solutions with Explanations

This file contains complete solutions to all beginner exercises.
Each solution includes detailed explanations of the approach.
============================================================================
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

print("=" * 80)
print("BEGINNER SOLUTIONS: Basic Feature Creation")
print("=" * 80)
print()

# ============================================================================
# DATASET PREPARATION
# ============================================================================
print("Loading Dataset...")
print("-" * 80)

np.random.seed(42)
n_users = 150

fitness_data = {
    'user_id': range(1, n_users + 1),
    'signup_date': pd.date_range(start='2023-01-01', periods=n_users, freq='D'),
    'age': np.random.randint(18, 65, n_users),
    'weight_kg': np.random.uniform(50, 120, n_users),
    'height_cm': np.random.uniform(150, 200, n_users),
    'workout_duration_min': np.random.randint(10, 120, n_users),
    'calories_burned': np.random.randint(100, 800, n_users),
    'steps_count': np.random.randint(1000, 20000, n_users),
    'heart_rate_avg': np.random.randint(60, 120, n_users),
    'workout_type': np.random.choice(['Running', 'Cycling', 'Swimming', 'Gym', 'Yoga'], n_users),
    'subscription_type': np.random.choice(['Free', 'Basic', 'Premium'], n_users),
    'is_premium': np.random.choice([True, False], n_users),
    'workout_notes': ['Felt great today! ' * np.random.randint(1, 4) for _ in range(n_users)]
}

df = pd.DataFrame(fitness_data)
print("Dataset Loaded!")
print()

# ============================================================================
# SOLUTION 1: Basic Numerical Features
# ============================================================================
print("=" * 80)
print("SOLUTION 1: Basic Numerical Features")
print("=" * 80)
print()

# SOLUTION 1.1: Calculate BMI
print("Solution 1.1: Calculate BMI")
print("-" * 40)
"""
BMI Formula: weight_kg / (height_m)^2
Steps:
1. Convert height from cm to meters: height_cm / 100
2. Square the height in meters: (height_m)^2
3. Divide weight by squared height
"""
df['bmi'] = df['weight_kg'] / (df['height_cm'] / 100) ** 2
print("✓ BMI calculated successfully!")
print(df[['weight_kg', 'height_cm', 'bmi']].head(10))
print(f"\nBMI Statistics:")
print(df['bmi'].describe())
print()

# SOLUTION 1.2: Calculate Calorie Burn Rate
print("Solution 1.2: Calculate Calorie Burn Rate")
print("-" * 40)
"""
Calorie Burn Rate: calories per minute
Simple division: calories_burned / workout_duration_min
This tells us efficiency of workout
"""
df['calorie_burn_rate'] = df['calories_burned'] / df['workout_duration_min']
print("✓ Calorie burn rate calculated!")
print(df[['calories_burned', 'workout_duration_min', 'calorie_burn_rate']].head(10))
print()

# SOLUTION 1.3: Calculate Exercise Intensity Score
print("Solution 1.3: Calculate Exercise Intensity Score")
print("-" * 40)
"""
Intensity Score combines:
- Calories burned (energy expenditure)
- Heart rate (cardiovascular effort)
- Time (efficiency)

Formula: (calories_burned * heart_rate_avg) / workout_duration_min
"""
df['intensity_score'] = (df['calories_burned'] * df['heart_rate_avg']) / df['workout_duration_min']
print("✓ Intensity score calculated!")
print(df['intensity_score'].describe())
print()

# SOLUTION 1.4: Create Age Groups
print("Solution 1.4: Create Age Groups")
print("-" * 40)
"""
Using pd.cut() for binning:
- bins: Define boundaries
- labels: Names for each category
- include_lowest: Include first boundary
"""
df['age_category'] = pd.cut(df['age'], 
                             bins=[18, 30, 45, 60, 100], 
                             labels=['Young', 'Adult', 'Middle', 'Senior'],
                             include_lowest=True)
print("✓ Age categories created!")
print(df['age_category'].value_counts().sort_index())
print()

# ============================================================================
# SOLUTION 2: DateTime Features
# ============================================================================
print("=" * 80)
print("SOLUTION 2: DateTime Features")
print("=" * 80)
print()

# SOLUTION 2.1: Extract Signup Month and Year
print("Solution 2.1: Extract Signup Month and Year")
print("-" * 40)
"""
Using .dt accessor for datetime operations:
- .dt.year: Extract year
- .dt.month: Extract month (1-12)
- .dt.day: Extract day of month
"""
df['signup_month'] = df['signup_date'].dt.month
df['signup_year'] = df['signup_date'].dt.year
print("✓ Month and year extracted!")
print(df[['signup_date', 'signup_month', 'signup_year']].head(10))
print()

# SOLUTION 2.2: Calculate Days Since Signup
print("Solution 2.2: Calculate Days Since Signup")
print("-" * 40)
"""
Calculate time difference:
1. Get today's date: datetime.now()
2. Subtract signup_date from today
3. Extract days using .dt.days
"""
today = datetime.now()
df['days_since_signup'] = (today - df['signup_date']).dt.days
print("✓ Days since signup calculated!")
print(df[['signup_date', 'days_since_signup']].head(10))
print()

# SOLUTION 2.3: Determine Signup Quarter
print("Solution 2.3: Determine Signup Quarter")
print("-" * 40)
"""
Using .dt.quarter:
Automatically converts month to quarter (1-4)
Q1: Jan-Mar, Q2: Apr-Jun, Q3: Jul-Sep, Q4: Oct-Dec
"""
df['signup_quarter'] = df['signup_date'].dt.quarter
print("✓ Signup quarter determined!")
print(df['signup_quarter'].value_counts().sort_index())
print()

# SOLUTION 2.4: Create Weekend Signup Indicator
print("Solution 2.4: Create Weekend Signup Indicator")
print("-" * 40)
"""
Steps:
1. Get day of week: .dt.dayofweek (0=Monday, 6=Sunday)
2. Check if in [5, 6] (Saturday, Sunday)
3. Convert boolean to int (1/0)
"""
df['signup_weekend'] = df['signup_date'].dt.dayofweek.isin([5, 6]).astype(int)
print("✓ Weekend indicator created!")
print(df['signup_weekend'].value_counts())
print()

# ============================================================================
# SOLUTION 3: Categorical Features
# ============================================================================
print("=" * 80)
print("SOLUTION 3: Categorical Features")
print("=" * 80)
print()

# SOLUTION 3.1: Create High Activity Indicator
print("Solution 3.1: Create High Activity Indicator")
print("-" * 40)
"""
Binary indicator:
1. Compare steps_count > 10000
2. Convert boolean to int
"""
df['is_high_activity'] = (df['steps_count'] > 10000).astype(int)
print("✓ High activity indicator created!")
print(df['is_high_activity'].value_counts())
print()

# SOLUTION 3.2: Calculate Workout Type Frequency
print("Solution 3.2: Calculate Workout Type Frequency")
print("-" * 40)
"""
Frequency encoding:
1. Count occurrences of each workout type
2. Map counts back to original dataframe
"""
workout_freq = df['workout_type'].value_counts()
df['workout_type_frequency'] = df['workout_type'].map(workout_freq)
print("✓ Workout type frequency calculated!")
print(df[['workout_type', 'workout_type_frequency']].head(10))
print()

# SOLUTION 3.3: Create Combined Feature
print("Solution 3.3: Create Combined Feature")
print("-" * 40)
"""
Combine two categorical variables:
Use string concatenation with separator
"""
df['user_segment'] = df['subscription_type'] + '_' + df['workout_type']
print("✓ User segments created!")
print(f"Unique segments: {df['user_segment'].nunique()}")
print(df['user_segment'].value_counts().head(10))
print()

# ============================================================================
# SOLUTION 4: Text Features
# ============================================================================
print("=" * 80)
print("SOLUTION 4: Text Features")
print("=" * 80)
print()

# SOLUTION 4.1: Calculate Note Length
print("Solution 4.1: Calculate Note Length")
print("-" * 40)
"""
String length: .str.len()
Counts all characters including spaces
"""
df['note_length'] = df['workout_notes'].str.len()
print("✓ Note length calculated!")
print(df[['workout_notes', 'note_length']].head(10))
print()

# SOLUTION 4.2: Count Words in Notes
print("Solution 4.2: Count Words in Notes")
print("-" * 40)
"""
Word count:
1. Split string by spaces: .str.split()
2. Count number of elements: .str.len()
"""
df['note_word_count'] = df['workout_notes'].str.split().str.len()
print("✓ Word count calculated!")
print(df[['workout_notes', 'note_word_count']].head(10))
print()

# SOLUTION 4.3: Count Exclamation Marks
print("Solution 4.3: Count Exclamation Marks")
print("-" * 40)
"""
Character count: .str.count()
Counts occurrences of specific character
"""
df['excitement_level'] = df['workout_notes'].str.count('!')
print("✓ Excitement level calculated!")
print(df['excitement_level'].value_counts().sort_index())
print()

# ============================================================================
# SOLUTION 5: Feature Interactions
# ============================================================================
print("=" * 80)
print("SOLUTION 5: Feature Interactions")
print("=" * 80)
print()

# SOLUTION 5.1: Create BMI-Age Interaction
print("Solution 5.1: Create BMI-Age Interaction")
print("-" * 40)
"""
Simple multiplication of two features
Captures joint effect of BMI and age
"""
df['bmi_age_interaction'] = df['bmi'] * df['age']
print("✓ BMI-age interaction created!")
print(df['bmi_age_interaction'].describe())
print()

# SOLUTION 5.2: Create Efficiency Score
print("Solution 5.2: Create Efficiency Score")
print("-" * 40)
"""
Combined metric:
(steps * calories) / time
Measures overall workout effectiveness
"""
df['workout_efficiency'] = (df['steps_count'] * df['calories_burned']) / df['workout_duration_min']
print("✓ Workout efficiency calculated!")
print(df['workout_efficiency'].describe())
print()

# ============================================================================
# BONUS SOLUTIONS
# ============================================================================
print("=" * 80)
print("BONUS SOLUTIONS")
print("=" * 80)
print()

# BONUS 1: Create Activity Level Categories
print("Bonus 1: Create Activity Level Categories")
print("-" * 40)
"""
Multi-level binning with specific thresholds
Based on health guidelines for daily steps
"""
df['activity_level'] = pd.cut(df['steps_count'],
                               bins=[0, 5000, 7500, 10000, 12500, 100000],
                               labels=['Sedentary', 'Lightly Active', 'Moderately Active', 
                                       'Active', 'Very Active'])
print("✓ Activity levels categorized!")
print(df['activity_level'].value_counts())
print()

# BONUS 2: Create Season Feature
print("Bonus 2: Create Season Feature")
print("-" * 40)
"""
Custom function with .apply()
Maps months to seasons
"""
def get_season(month):
    if month in [12, 1, 2]:
        return 'Winter'
    elif month in [3, 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8]:
        return 'Summer'
    else:
        return 'Fall'

df['signup_season'] = df['signup_month'].apply(get_season)
print("✓ Seasons determined!")
print(df['signup_season'].value_counts())
print()

# BONUS 3: Create Normalized Features
print("Bonus 3: Create Normalized Features")
print("-" * 40)
"""
Min-Max Normalization: (x - min) / (max - min)
Scales values to [0, 1] range
"""
df['workout_duration_norm'] = (df['workout_duration_min'] - df['workout_duration_min'].min()) / \
                               (df['workout_duration_min'].max() - df['workout_duration_min'].min())

df['calories_norm'] = (df['calories_burned'] - df['calories_burned'].min()) / \
                       (df['calories_burned'].max() - df['calories_burned'].min())

df['steps_norm'] = (df['steps_count'] - df['steps_count'].min()) / \
                    (df['steps_count'].max() - df['steps_count'].min())

print("✓ Features normalized!")
print(df[['workout_duration_norm', 'calories_norm', 'steps_norm']].describe())
print()

# ============================================================================
# FINAL SUMMARY
# ============================================================================
print("=" * 80)
print("SOLUTION SUMMARY")
print("=" * 80)
print()

print(f"Final Dataset Shape: {df.shape}")
print(f"Original Features: {len(fitness_data.keys())}")
print(f"Engineered Features: {df.shape[1] - len(fitness_data.keys())}")
print()

print("All Features Created:")
print("-" * 40)
for i, col in enumerate(df.columns, 1):
    original = col in fitness_data.keys()
    feature_type = "ORIGINAL" if original else "ENGINEERED"
    print(f"{i:2d}. {col:35s} [{feature_type}]")
print()

new_features = [col for col in df.columns if col not in fitness_data.keys()]
print(f"Total Engineered Features: {len(new_features)}")
print()

print("=" * 80)
print("KEY LEARNING POINTS")
print("=" * 80)
print("""
1. NUMERICAL FEATURES:
   - Use mathematical operations (division, multiplication)
   - Think about meaningful ratios and combinations
   - Consider domain knowledge (e.g., BMI formula)

2. DATETIME FEATURES:
   - Extract components (.dt.year, .dt.month, etc.)
   - Calculate differences for time-based features
   - Create binary indicators (weekend, quarter, etc.)

3. CATEGORICAL FEATURES:
   - Create binary flags with boolean conditions
   - Calculate frequencies for encoding
   - Combine categories for segmentation

4. TEXT FEATURES:
   - Use .str accessor for string operations
   - Count characters, words, special symbols
   - Think about what text characteristics matter

5. FEATURE INTERACTIONS:
   - Multiply/combine features to capture joint effects
   - Consider domain: which features naturally interact?
   - Test if interactions improve predictions

COMMON PATTERNS:
- Ratios reveal relationships
- Binning reduces noise and creates categories
- Datetime extraction captures temporal patterns
- Frequency encoding leverages category popularity
- Interactions capture non-linear relationships

Remember: Good features come from understanding your data and domain!
""")
print("=" * 80)
