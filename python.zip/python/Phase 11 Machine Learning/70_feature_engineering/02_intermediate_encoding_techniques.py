"""
============================================================================
INTERMEDIATE LEVEL: Encoding Techniques
============================================================================

Course: Undergraduate Python Programming
Module: Feature Engineering - Feature Creation and Selection
Level: Intermediate
Topic: Categorical Variable Encoding Methods

Learning Objectives:
-------------------
1. Understand different types of categorical encoding
2. Implement One-Hot Encoding for nominal variables
3. Use Label Encoding for ordinal variables
4. Apply Target Encoding for high-cardinality features
5. Implement Frequency and Binary Encoding
6. Understand when to use each encoding method
7. Handle high cardinality categorical variables

Prerequisites:
--------------
- Completed beginner level feature creation
- Understanding of categorical vs numerical data
- Familiarity with sklearn

Estimated Time: 90 minutes
============================================================================
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

print("=" * 80)
print("INTERMEDIATE: Encoding Techniques")
print("=" * 80)
print()

# ============================================================================
# SECTION 1: Introduction to Encoding
# ============================================================================
print("SECTION 1: Introduction to Encoding")
print("-" * 80)

"""
WHY DO WE NEED ENCODING?

Most machine learning algorithms require numerical input. Categorical variables
(like color, city, product type) need to be converted to numbers.

ENCODING METHODS:

1. LABEL ENCODING: Assign integers to categories (0, 1, 2, ...)
   - Pros: Memory efficient, simple
   - Cons: Implies ordering where none exists
   - Use: Ordinal variables (low, medium, high)

2. ONE-HOT ENCODING: Create binary column for each category
   - Pros: No false ordering, clear interpretation
   - Cons: Creates many columns (curse of dimensionality)
   - Use: Nominal variables with few categories

3. TARGET ENCODING: Replace category with mean of target variable
   - Pros: Handles high cardinality, captures predictive power
   - Cons: Risk of overfitting, requires target variable
   - Use: High cardinality features in supervised learning

4. FREQUENCY ENCODING: Replace category with its frequency
   - Pros: Simple, handles high cardinality
   - Cons: Multiple categories may have same frequency
   - Use: When frequency is informative

5. BINARY ENCODING: Convert to binary, then split digits into columns
   - Pros: Fewer columns than one-hot, no false ordering
   - Cons: Less interpretable
   - Use: High cardinality nominal variables

IMPORTANT CONSIDERATIONS:
- Train/test split BEFORE encoding to avoid data leakage
- Save encoders to apply same transformation to test/new data
- Handle unseen categories in test data
"""

# Create sample dataset
np.random.seed(42)
n_samples = 1000

# Generate diverse categorical data
cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 
          'Philadelphia', 'San Antonio', 'San Diego', 'Dallas', 'San Jose']
          
education_levels = ['High School', 'Bachelor', 'Master', 'PhD']
departments = ['Engineering', 'Sales', 'Marketing', 'HR', 'Finance']
sizes = ['Small', 'Medium', 'Large', 'X-Large']

data = {
    'employee_id': range(1, n_samples + 1),
    'city': np.random.choice(cities, n_samples),
    'education': np.random.choice(education_levels, n_samples),
    'department': np.random.choice(departments, n_samples),
    'company_size': np.random.choice(sizes, n_samples),
    'years_experience': np.random.randint(0, 30, n_samples),
    'age': np.random.randint(22, 65, n_samples),
    'salary': np.random.randint(30000, 150000, n_samples)
}

df = pd.DataFrame(data)

print("Sample Dataset:")
print(df.head(10))
print(f"\nDataset shape: {df.shape}")
print(f"\nCategorical columns: {df.select_dtypes(include='object').columns.tolist()}")
print(f"\nNumerical columns: {df.select_dtypes(include=[np.number]).columns.tolist()}")
print()

# Check cardinality of categorical features
print("Cardinality (unique values) of categorical features:")
for col in df.select_dtypes(include='object').columns:
    print(f"  {col}: {df[col].nunique()} unique values")
print()

# ============================================================================
# SECTION 2: Label Encoding
# ============================================================================
print("\nSECTION 2: Label Encoding")
print("-" * 80)

"""
LABEL ENCODING converts categories to integers (0, 1, 2, ...).

WHEN TO USE:
✓ Ordinal variables (natural ordering exists)
✓ Tree-based models (can handle arbitrary numbers)
✗ Linear models (implies false ordering)
✗ Nominal variables without order

EXAMPLE: Education levels have natural order:
High School < Bachelor < Master < PhD
"""

# 2.1: Manual Label Encoding with Mapping
print("\n2.1: Manual Label Encoding (with Control)")
print("-" * 40)

"""
For ordinal variables, define the order explicitly
This gives you control over the mapping
"""

# Define education level order
education_mapping = {
    'High School': 0,
    'Bachelor': 1,
    'Master': 2,
    'PhD': 3
}

df['education_encoded'] = df['education'].map(education_mapping)

print("Education Label Encoding:")
print(pd.DataFrame({
    'Original': df['education'].unique(),
    'Encoded': [education_mapping[e] for e in df['education'].unique()]
}).sort_values('Encoded'))
print()

# Verify encoding
print("Sample encoded values:")
print(df[['education', 'education_encoded']].head(10))
print()

# 2.2: Sklearn Label Encoding
print("\n2.2: Sklearn LabelEncoder")
print("-" * 40)

"""
LabelEncoder automatically assigns integers
WARNING: Order is alphabetical, not meaningful!
Use manual mapping for ordinal variables
"""

# Example with department (nominal - order doesn't matter)
le_dept = LabelEncoder()
df['department_encoded'] = le_dept.fit_transform(df['department'])

print("Department Label Encoding (alphabetical order):")
print(pd.DataFrame({
    'Original': le_dept.classes_,
    'Encoded': range(len(le_dept.classes_))
}))
print()

# How to decode back to original
print("Decoding example:")
sample_codes = [0, 1, 2]
print(f"Codes {sample_codes} →", le_dept.inverse_transform(sample_codes))
print()

# 2.3: Company Size - Ordinal Encoding
print("\n2.3: Ordinal Encoding for Company Size")
print("-" * 40)

"""
Company size has natural order: Small < Medium < Large < X-Large
"""

size_mapping = {
    'Small': 0,
    'Medium': 1,
    'Large': 2,
    'X-Large': 3
}

df['size_encoded'] = df['company_size'].map(size_mapping)

print("Company Size Encoding:")
print(df[['company_size', 'size_encoded']].value_counts().sort_index())
print()

# ============================================================================
# SECTION 3: One-Hot Encoding
# ============================================================================
print("\nSECTION 3: One-Hot Encoding")
print("-" * 80)

"""
ONE-HOT ENCODING creates binary columns for each category.

WHEN TO USE:
✓ Nominal variables (no natural order)
✓ Linear models, neural networks
✓ Low cardinality (< 10-15 categories)
✗ High cardinality (creates too many columns)
✗ Tree-based models (unnecessary complexity)

EXAMPLE: Department has no order, so use one-hot encoding
"""

# 3.1: Pandas get_dummies
print("\n3.1: Pandas get_dummies (Simple Method)")
print("-" * 40)

"""
pd.get_dummies() is the easiest way to one-hot encode
Creates new DataFrame with binary columns
"""

# One-hot encode department
dept_onehot = pd.get_dummies(df['department'], prefix='dept')

print("One-Hot Encoded Department:")
print(dept_onehot.head(10))
print(f"\nShape: {dept_onehot.shape}")
print(f"Columns created: {dept_onehot.columns.tolist()}")
print()

# Join with original dataframe
df_with_onehot = pd.concat([df, dept_onehot], axis=1)
print("Sample of combined data:")
print(df_with_onehot[['department'] + dept_onehot.columns.tolist()].head(10))
print()

# 3.2: Handling Multiple Columns
print("\n3.2: Multiple Column One-Hot Encoding")
print("-" * 40)

"""
Encode multiple columns at once
drop_first=True removes one column per feature (avoids multicollinearity)
"""

# Select columns to encode
cols_to_encode = ['department', 'company_size']

# One-hot encode with drop_first
df_encoded = pd.get_dummies(df, 
                             columns=cols_to_encode, 
                             prefix=cols_to_encode,
                             drop_first=True)  # Avoid dummy variable trap

print(f"Original shape: {df.shape}")
print(f"After encoding shape: {df_encoded.shape}")
print(f"Columns added: {df_encoded.shape[1] - df.shape[1]}")
print()

print("New columns created:")
new_cols = [col for col in df_encoded.columns if col not in df.columns]
for col in new_cols:
    print(f"  - {col}")
print()

# 3.3: Sklearn OneHotEncoder
print("\n3.3: Sklearn OneHotEncoder (More Control)")
print("-" * 40)

"""
Sklearn's OneHotEncoder provides:
- Handle unknown categories in test data
- Sparse matrix output (memory efficient)
- Easy to save and reuse
"""

from sklearn.preprocessing import OneHotEncoder

# Initialize encoder
ohe = OneHotEncoder(sparse_output=False,  # Return dense array
                    drop='first',  # Drop first category
                    handle_unknown='ignore')  # Ignore unknown categories

# Fit and transform
dept_array = df[['department']].values
dept_encoded = ohe.fit_transform(dept_array)

# Create DataFrame
dept_encoded_df = pd.DataFrame(
    dept_encoded,
    columns=ohe.get_feature_names_out(['department'])
)

print("Sklearn OneHotEncoder result:")
print(dept_encoded_df.head(10))
print()

# Show how to handle new data
print("Handling unseen categories:")
new_data = pd.DataFrame({'department': ['Engineering', 'Unknown_Dept']})
new_encoded = ohe.transform(new_data[['department']].values)
print(f"Unknown category handled: {new_encoded[1]}")  # All zeros
print()

# ============================================================================
# SECTION 4: Target Encoding (Mean Encoding)
# ============================================================================
print("\nSECTION 4: Target Encoding (Mean Encoding)")
print("-" * 80)

"""
TARGET ENCODING replaces categories with mean of target variable.

WHEN TO USE:
✓ High cardinality categorical variables
✓ Feature has predictive power
✓ Supervised learning problems
✗ Risk of overfitting
✗ Data leakage if not done carefully

IMPORTANT: Always use cross-validation or separate folds to prevent leakage!
"""

# 4.1: Basic Target Encoding
print("\n4.1: Basic Target Encoding")
print("-" * 40)

"""
For each category, calculate mean salary
Replace category with this mean
"""

# Calculate mean salary by city
city_means = df.groupby('city')['salary'].mean().to_dict()

df['city_target_encoded'] = df['city'].map(city_means)

print("City Target Encoding (Mean Salary by City):")
city_encoding_df = pd.DataFrame({
    'City': list(city_means.keys()),
    'Mean_Salary': list(city_means.values())
}).sort_values('Mean_Salary', ascending=False)
print(city_encoding_df)
print()

print("Sample encoded values:")
print(df[['city', 'salary', 'city_target_encoded']].head(10))
print()

# 4.2: Target Encoding with Cross-Validation (Proper Way)
print("\n4.2: Proper Target Encoding (Avoid Overfitting)")
print("-" * 40)

"""
To avoid overfitting:
1. Split data into train/validation
2. Calculate target means only on training data
3. Apply to validation data
4. Use out-of-fold predictions for training data
"""

from sklearn.model_selection import KFold

def target_encode_cv(df, column, target, n_splits=5):
    """
    Target encoding with cross-validation to prevent overfitting.
    
    Parameters:
    -----------
    df : DataFrame
    column : str, column to encode
    target : str, target column
    n_splits : int, number of CV folds
    
    Returns:
    --------
    Series : Encoded values
    """
    encoded = pd.Series(index=df.index, dtype=float)
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    
    for train_idx, val_idx in kf.split(df):
        # Calculate means on training fold
        train_means = df.iloc[train_idx].groupby(column)[target].mean()
        
        # Apply to validation fold
        encoded.iloc[val_idx] = df.iloc[val_idx][column].map(train_means)
        
        # Fill unseen categories with global mean
        global_mean = df.iloc[train_idx][target].mean()
        encoded.iloc[val_idx] = encoded.iloc[val_idx].fillna(global_mean)
    
    return encoded

# Apply proper target encoding
df['city_target_cv'] = target_encode_cv(df, 'city', 'salary')

print("Cross-validated Target Encoding:")
print(df[['city', 'salary', 'city_target_cv']].head(10))
print()

print("Comparison of methods:")
print(f"Basic target encoding correlation with salary: {df['city_target_encoded'].corr(df['salary']):.4f}")
print(f"CV target encoding correlation with salary: {df['city_target_cv'].corr(df['salary']):.4f}")
print("(CV method should have lower correlation to prevent overfitting)")
print()

# ============================================================================
# SECTION 5: Frequency Encoding
# ============================================================================
print("\nSECTION 5: Frequency Encoding")
print("-" * 80)

"""
FREQUENCY ENCODING replaces categories with their frequency (count or percentage).

WHEN TO USE:
✓ Frequency itself is informative
✓ High cardinality variables
✓ When more common categories might be more important
✗ When multiple categories have same frequency
"""

# 5.1: Count-based Frequency Encoding
print("\n5.1: Count-based Frequency Encoding")
print("-" * 40)

# Calculate frequencies
city_freq = df['city'].value_counts()
df['city_frequency'] = df['city'].map(city_freq)

print("City Frequency Encoding:")
print(pd.DataFrame({
    'City': city_freq.index,
    'Count': city_freq.values
}).head(10))
print()

print("Sample encoded values:")
print(df[['city', 'city_frequency']].head(10))
print()

# 5.2: Percentage-based Frequency Encoding
print("\n5.2: Percentage-based Frequency Encoding")
print("-" * 40)

# Calculate percentages
city_pct = df['city'].value_counts(normalize=True) * 100
df['city_frequency_pct'] = df['city'].map(city_pct)

print("City Frequency Percentage:")
print(df[['city', 'city_frequency', 'city_frequency_pct']].head(10))
print()

# ============================================================================
# SECTION 6: Binary Encoding
# ============================================================================
print("\nSECTION 6: Binary Encoding")
print("-" * 80)

"""
BINARY ENCODING:
1. Assign integer to each category (like label encoding)
2. Convert integers to binary
3. Split binary digits into separate columns

ADVANTAGES:
- Fewer columns than one-hot encoding
- No false ordering like label encoding
- Good for high cardinality

EXAMPLE: 5 categories
- One-hot: 5 columns
- Binary: 3 columns (2^3 = 8 can represent 5 categories)
"""

# 6.1: Manual Binary Encoding
print("\n6.1: Understanding Binary Encoding")
print("-" * 40)

"""
Let's manually encode city to understand the process
"""

# Step 1: Label encode
le_city = LabelEncoder()
city_labels = le_city.fit_transform(df['city'])

print(f"Cities: {len(le_city.classes_)} unique values")
print(f"Binary columns needed: {int(np.ceil(np.log2(len(le_city.classes_))))} columns")
print()

# Step 2: Convert to binary
def int_to_binary_columns(numbers, n_bits):
    """Convert integers to binary columns."""
    binary_cols = []
    for i in range(n_bits):
        col = [(n >> i) & 1 for n in numbers]
        binary_cols.append(col)
    return np.array(binary_cols).T

n_bits = int(np.ceil(np.log2(len(le_city.classes_))))
binary_encoded = int_to_binary_columns(city_labels, n_bits)

# Create DataFrame
binary_cols = [f'city_binary_{i}' for i in range(n_bits)]
df_binary = pd.DataFrame(binary_encoded, columns=binary_cols)

print("Binary Encoding Example:")
print(pd.DataFrame({
    'city': df['city'].head(10),
    **{col: df_binary[col].head(10) for col in binary_cols}
}))
print()

print(f"Original one-hot would need: {len(le_city.classes_)} columns")
print(f"Binary encoding needs only: {n_bits} columns")
print(f"Space saving: {((len(le_city.classes_) - n_bits) / len(le_city.classes_) * 100):.1f}%")
print()

# ============================================================================
# SECTION 7: Comparison and Selection Guide
# ============================================================================
print("\nSECTION 7: Comparison and Selection Guide")
print("-" * 80)

print("""
ENCODING SELECTION GUIDE:
========================

+-------------------+------------------+-------------------+--------------+
| Encoding Type     | Best For         | Pros              | Cons         |
+-------------------+------------------+-------------------+--------------+
| Label Encoding    | - Ordinal vars   | - Simple          | - False      |
|                   | - Tree models    | - Memory efficient|   ordering   |
+-------------------+------------------+-------------------+--------------+
| One-Hot Encoding  | - Nominal vars   | - No false order  | - Many cols  |
|                   | - Low cardinality| - Interpretable   | - Sparse     |
|                   | - Linear models  |                   |              |
+-------------------+------------------+-------------------+--------------+
| Target Encoding   | - High cardinali | - Captures power  | - Overfitting|
|                   | - Supervised     | - Few columns     | - Leakage    |
+-------------------+------------------+-------------------+--------------+
| Frequency Encod.  | - Frequency is   | - Simple          | - Collisions |
|                   |   informative    | - Works for high  |              |
|                   |                  |   cardinality     |              |
+-------------------+------------------+-------------------+--------------+
| Binary Encoding   | - High cardinali | - Fewer columns   | - Less       |
|                   | - Nominal vars   |   than one-hot    |   interpret. |
+-------------------+------------------+-------------------+--------------+

DECISION TREE:
=============

1. Is the variable ORDINAL (natural order)?
   YES → Use Label Encoding or Ordinal Encoding
   NO  → Continue

2. How many unique categories?
   < 10  → Use One-Hot Encoding
   10-50 → Consider Binary Encoding or Target Encoding
   > 50  → Use Target Encoding or Frequency Encoding

3. Do you have a target variable?
   YES → Consider Target Encoding (with CV!)
   NO  → Use Frequency or Binary Encoding

4. What model are you using?
   Tree-based → Can use Label Encoding even for nominal
   Linear      → Must use One-Hot, Target, or Binary Encoding
   Neural Net  → Prefer One-Hot or Embeddings

AVOIDING COMMON PITFALLS:
========================

1. DATA LEAKAGE:
   ❌ Fit encoder on entire dataset
   ✓ Fit only on training data

2. TARGET LEAKAGE:
   ❌ Use target encoding without CV
   ✓ Use cross-validated target encoding

3. UNSEEN CATEGORIES:
   ❌ Ignore test-time unknowns
   ✓ Handle with 'unknown' category or global mean

4. MULTICOLLINEARITY:
   ❌ Keep all one-hot columns
   ✓ Use drop_first=True

5. MEMORY ISSUES:
   ❌ One-hot encode high cardinality
   ✓ Use target/frequency/binary encoding
""")

# ============================================================================
# SECTION 8: Practical Example - Complete Pipeline
# ============================================================================
print("\nSECTION 8: Complete Encoding Pipeline")
print("-" * 80)

"""
Let's put it all together with a proper train/test split
"""

# Split data
X = df[['city', 'education', 'department', 'company_size', 'years_experience', 'age']]
y = df['salary']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Training set: {X_train.shape}")
print(f"Test set: {X_test.shape}")
print()

# Create encoding pipeline
X_train_encoded = X_train.copy()
X_test_encoded = X_test.copy()

# 1. Ordinal encoding for education and size
education_map = {'High School': 0, 'Bachelor': 1, 'Master': 2, 'PhD': 3}
size_map = {'Small': 0, 'Medium': 1, 'Large': 2, 'X-Large': 3}

X_train_encoded['education'] = X_train_encoded['education'].map(education_map)
X_test_encoded['education'] = X_test_encoded['education'].map(education_map)

X_train_encoded['company_size'] = X_train_encoded['company_size'].map(size_map)
X_test_encoded['company_size'] = X_test_encoded['company_size'].map(size_map)

# 2. Target encoding for city (high cardinality)
city_means_train = X_train.join(y_train).groupby('city')['salary'].mean()
global_mean = y_train.mean()

X_train_encoded['city'] = X_train_encoded['city'].map(city_means_train).fillna(global_mean)
X_test_encoded['city'] = X_test_encoded['city'].map(city_means_train).fillna(global_mean)

# 3. One-hot encoding for department (low cardinality, nominal)
dept_onehot_train = pd.get_dummies(X_train_encoded['department'], prefix='dept', drop_first=True)
dept_onehot_test = pd.get_dummies(X_test_encoded['department'], prefix='dept', drop_first=True)

# Ensure same columns
for col in dept_onehot_train.columns:
    if col not in dept_onehot_test.columns:
        dept_onehot_test[col] = 0

X_train_encoded = pd.concat([X_train_encoded.drop('department', axis=1), dept_onehot_train], axis=1)
X_test_encoded = pd.concat([X_test_encoded.drop('department', axis=1), dept_onehot_test], axis=1)

print("Final encoded features:")
print("Training set:", X_train_encoded.shape)
print("Test set:", X_test_encoded.shape)
print()
print("Columns:", X_train_encoded.columns.tolist())
print()

print("=" * 80)
print("INTERMEDIATE TUTORIAL COMPLETED!")
print("=" * 80)
print("""
KEY TAKEAWAYS:
1. Choose encoding based on variable type and cardinality
2. Always fit encoders on training data only
3. Use target encoding with CV to prevent overfitting
4. One-hot encoding creates many columns for high cardinality
5. Consider memory and interpretability trade-offs
6. Handle unseen categories in test data
7. Different models prefer different encodings

NEXT STEPS:
- Complete exercise file to practice encoding techniques
- Experiment with different encodings on same data
- Compare model performance with different encodings
- Move to advanced level for feature selection methods
""")
print("=" * 80)
