"""
============================================================================
INTERMEDIATE LEVEL: Encoding Techniques - EXERCISE
============================================================================
Instructions: Complete each encoding task. Test your implementations.
Time Estimate: 60 minutes
============================================================================
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split

np.random.seed(42)

# Create customer dataset
n = 500
data = {
    'customer_id': range(1, n+1),
    'country': np.random.choice(['USA', 'UK', 'Canada', 'Germany', 'France', 'Spain', 'Italy'], n),
    'product_category': np.random.choice(['Electronics', 'Clothing', 'Food', 'Books', 'Home', 'Sports'], n),
    'satisfaction': np.random.choice(['Very Low', 'Low', 'Medium', 'High', 'Very High'], n),
    'membership_level': np.random.choice(['Bronze', 'Silver', 'Gold', 'Platinum'], n),
    'purchase_amount': np.random.uniform(10, 1000, n),
    'age': np.random.randint(18, 80, n)
}
df = pd.DataFrame(data)

print("Dataset loaded:")
print(df.head())
print()

# EXERCISE 1: Label Encoding
print("="*80)
print("EXERCISE 1: Label Encoding (15 points)")
print("="*80)
"""
TASK 1.1: Create ordinal encoding for membership_level
Order: Bronze < Silver < Gold < Platinum
Create new column: membership_encoded
"""
# YOUR CODE HERE

"""
TASK 1.2: Create ordinal encoding for satisfaction
Order: Very Low < Low < Medium < High < Very High
Create new column: satisfaction_encoded
"""
# YOUR CODE HERE

# EXERCISE 2: One-Hot Encoding
print("="*80)
print("EXERCISE 2: One-Hot Encoding (20 points)")
print("="*80)
"""
TASK 2.1: One-hot encode product_category using pd.get_dummies
Use prefix='product' and drop_first=True
"""
# YOUR CODE HERE

"""
TASK 2.2: One-hot encode country using sklearn OneHotEncoder
Set handle_unknown='ignore' and sparse_output=False
"""
# YOUR CODE HERE

# EXERCISE 3: Target Encoding
print("="*80)
print("EXERCISE 3: Target Encoding (20 points)")
print("="*80)
"""
TASK 3.1: Create target encoding for country based on purchase_amount
Calculate mean purchase_amount for each country
Create new column: country_target_encoded
"""
# YOUR CODE HERE

"""
TASK 3.2: Create cross-validated target encoding for country
Use 5-fold cross-validation to avoid overfitting
Create new column: country_target_cv
"""
# YOUR CODE HERE

# EXERCISE 4: Frequency Encoding
print("="*80)
print("EXERCISE 4: Frequency Encoding (15 points)")
print("="*80)
"""
TASK 4.1: Create frequency encoding for product_category
Replace each category with its count
Create new column: category_frequency
"""
# YOUR CODE HERE

"""
TASK 4.2: Create percentage-based frequency encoding
Replace each category with its percentage (0-100)
Create new column: category_frequency_pct
"""
# YOUR CODE HERE

# EXERCISE 5: Complete Pipeline
print("="*80)
print("EXERCISE 5: Complete Pipeline (30 points)")
print("="*80)
"""
TASK 5.1: Split data into train/test (80/20)
"""
# YOUR CODE HERE

"""
TASK 5.2: Encode all categorical variables appropriately:
- membership_level: ordinal encoding
- satisfaction: ordinal encoding
- product_category: one-hot encoding
- country: target encoding (using only training data)
Make sure to handle test data correctly!
"""
# YOUR CODE HERE

print("Exercises complete! Check solution file for answers.")
