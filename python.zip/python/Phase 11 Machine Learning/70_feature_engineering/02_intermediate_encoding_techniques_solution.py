"""
============================================================================
INTERMEDIATE LEVEL: Encoding Techniques - SOLUTION
============================================================================
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split, KFold

np.random.seed(42)
n = 500
data = {
    'customer_id': range(1, n+1),
    'country': np.random.choice(['USA', 'UK', 'Canada', 'Germany', 'France', 'Spain', 'Italy'], n),
    'product_category': np.random.choice(['Electronics', 'Clothing', 'Food', 'Books', 'Home', 'Sports'], n),
    'satisfaction': np.random.choice(['Very Low', 'Low', 'Medium', 'High', 'Very High'], n),
    'membership_level': np.random.choice(['Bronze', 'Silver', 'Gold', 'Platinum'], n),
    'purchase_amount': np.random.uniform(10, 1000, n),
    'age': np.random.randint(18, 80, n)
}
df = pd.DataFrame(data)

# SOLUTION 1: Label Encoding
print("SOLUTION 1: Label Encoding")
membership_map = {'Bronze': 0, 'Silver': 1, 'Gold': 2, 'Platinum': 3}
df['membership_encoded'] = df['membership_level'].map(membership_map)

satisfaction_map = {'Very Low': 0, 'Low': 1, 'Medium': 2, 'High': 3, 'Very High': 4}
df['satisfaction_encoded'] = df['satisfaction'].map(satisfaction_map)
print("✓ Ordinal encoding completed")
print(df[['membership_level', 'membership_encoded', 'satisfaction', 'satisfaction_encoded']].head())

# SOLUTION 2: One-Hot Encoding
print("\nSOLUTION 2: One-Hot Encoding")
product_dummies = pd.get_dummies(df['product_category'], prefix='product', drop_first=True)
print("✓ One-hot encoding completed")
print(f"Columns created: {product_dummies.columns.tolist()}")

ohe = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
country_encoded = ohe.fit_transform(df[['country']])
print(f"✓ Sklearn encoding completed, shape: {country_encoded.shape}")

# SOLUTION 3: Target Encoding
print("\nSOLUTION 3: Target Encoding")
country_means = df.groupby('country')['purchase_amount'].mean()
df['country_target_encoded'] = df['country'].map(country_means)
print("✓ Target encoding completed")
print(df[['country', 'purchase_amount', 'country_target_encoded']].head())

def target_encode_cv(df, column, target, n_splits=5):
    encoded = pd.Series(index=df.index, dtype=float)
    kf = KFold(n_splits=n_splits, shuffle=True, random_state=42)
    for train_idx, val_idx in kf.split(df):
        train_means = df.iloc[train_idx].groupby(column)[target].mean()
        encoded.iloc[val_idx] = df.iloc[val_idx][column].map(train_means)
        global_mean = df.iloc[train_idx][target].mean()
        encoded.iloc[val_idx] = encoded.iloc[val_idx].fillna(global_mean)
    return encoded

df['country_target_cv'] = target_encode_cv(df, 'country', 'purchase_amount')
print("✓ CV target encoding completed")

# SOLUTION 4: Frequency Encoding
print("\nSOLUTION 4: Frequency Encoding")
category_freq = df['product_category'].value_counts()
df['category_frequency'] = df['product_category'].map(category_freq)
category_pct = df['product_category'].value_counts(normalize=True) * 100
df['category_frequency_pct'] = df['product_category'].map(category_pct)
print("✓ Frequency encoding completed")
print(df[['product_category', 'category_frequency', 'category_frequency_pct']].head())

# SOLUTION 5: Complete Pipeline
print("\nSOLUTION 5: Complete Pipeline")
X = df[['country', 'product_category', 'satisfaction', 'membership_level', 'age']]
y = df['purchase_amount']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

X_train_enc = X_train.copy()
X_test_enc = X_test.copy()

# Ordinal encoding
membership_map = {'Bronze': 0, 'Silver': 1, 'Gold': 2, 'Platinum': 3}
satisfaction_map = {'Very Low': 0, 'Low': 1, 'Medium': 2, 'High': 3, 'Very High': 4}

X_train_enc['membership_level'] = X_train_enc['membership_level'].map(membership_map)
X_test_enc['membership_level'] = X_test_enc['membership_level'].map(membership_map)
X_train_enc['satisfaction'] = X_train_enc['satisfaction'].map(satisfaction_map)
X_test_enc['satisfaction'] = X_test_enc['satisfaction'].map(satisfaction_map)

# Target encoding
country_means_train = X_train.join(y_train).groupby('country')['purchase_amount'].mean()
global_mean = y_train.mean()
X_train_enc['country'] = X_train_enc['country'].map(country_means_train).fillna(global_mean)
X_test_enc['country'] = X_test_enc['country'].map(country_means_train).fillna(global_mean)

# One-hot encoding
prod_train = pd.get_dummies(X_train_enc['product_category'], prefix='prod', drop_first=True)
prod_test = pd.get_dummies(X_test_enc['product_category'], prefix='prod', drop_first=True)

for col in prod_train.columns:
    if col not in prod_test.columns:
        prod_test[col] = 0

X_train_enc = pd.concat([X_train_enc.drop('product_category', axis=1), prod_train], axis=1)
X_test_enc = pd.concat([X_test_enc.drop('product_category', axis=1), prod_test], axis=1)

print("✓ Pipeline completed")
print(f"Training shape: {X_train_enc.shape}")
print(f"Test shape: {X_test_enc.shape}")
print("\nAll solutions completed successfully!")
