"""
============================================================================
INTERMEDIATE LEVEL: Feature Transformation
============================================================================
Learning Objectives:
1. Master feature scaling techniques
2. Apply binning and discretization
3. Create polynomial features
4. Use mathematical transformations
5. Handle skewed distributions

Time: 90 minutes
============================================================================
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import (StandardScaler, MinMaxScaler, RobustScaler,
                                   PolynomialFeatures, PowerTransformer)
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("INTERMEDIATE: Feature Transformation")
print("="*80)

# Create sample dataset
np.random.seed(42)
n = 1000
data = {
    'price': np.random.exponential(100, n),  # Skewed
    'quantity': np.random.randint(1, 100, n),
    'rating': np.random.uniform(1, 5, n),
    'age': np.random.randint(18, 80, n),
    'income': np.random.lognormal(10, 1, n),  # Right-skewed
    'sales': np.random.uniform(0, 10000, n)
}
df = pd.DataFrame(data)

print("Original Data:")
print(df.describe())
print()

# SECTION 1: Feature Scaling
print("SECTION 1: Feature Scaling")
print("-"*80)
"""
WHY SCALE?
- Gradient descent converges faster
- Distance-based algorithms need equal scales
- Regularization is scale-dependent

METHODS:
1. StandardScaler: (x - mean) / std
2. MinMaxScaler: (x - min) / (max - min)
3. RobustScaler: Use median and IQR (robust to outliers)
"""

# 1.1 Standard Scaling
print("1.1 Standard Scaling (Z-score normalization)")
scaler = StandardScaler()
df['price_standard'] = scaler.fit_transform(df[['price']])
print(f"Mean: {df['price_standard'].mean():.6f} (should be ~0)")
print(f"Std: {df['price_standard'].std():.6f} (should be ~1)")

# 1.2 Min-Max Scaling
print("\\n1.2 Min-Max Scaling (0-1 range)")
minmax = MinMaxScaler()
df['price_minmax'] = minmax.fit_transform(df[['price']])
print(f"Min: {df['price_minmax'].min():.6f} (should be 0)")
print(f"Max: {df['price_minmax'].max():.6f} (should be 1)")

# 1.3 Robust Scaling
print("\\n1.3 Robust Scaling (median and IQR)")
robust = RobustScaler()
df['price_robust'] = robust.fit_transform(df[['price']])
print(f"Median: {df['price_robust'].median():.6f} (should be ~0)")
print(f"IQR: {df['price_robust'].quantile(0.75) - df['price_robust'].quantile(0.25):.2f}")

# SECTION 2: Binning & Discretization
print("\\nSECTION 2: Binning & Discretization")
print("-"*80)

# 2.1 Equal-width binning
df['age_bins_width'] = pd.cut(df['age'], bins=5, labels=['A', 'B', 'C', 'D', 'E'])
print("Equal-width binning:")
print(df['age_bins_width'].value_counts().sort_index())

# 2.2 Equal-frequency binning
df['age_bins_freq'] = pd.qcut(df['age'], q=5, labels=['Q1', 'Q2', 'Q3', 'Q4', 'Q5'])
print("\\nEqual-frequency binning:")
print(df['age_bins_freq'].value_counts().sort_index())

# 2.3 Custom binning
df['rating_category'] = pd.cut(df['rating'], 
                                bins=[0, 2, 3.5, 5], 
                                labels=['Poor', 'Good', 'Excellent'])
print("\\nCustom binning:")
print(df['rating_category'].value_counts())

# SECTION 3: Polynomial Features
print("\\nSECTION 3: Polynomial Features")
print("-"*80)
"""
Create interaction and polynomial terms
Example: [x1, x2] → [1, x1, x2, x1², x1*x2, x2²]
"""

poly = PolynomialFeatures(degree=2, include_bias=False)
features = df[['quantity', 'rating']].values
poly_features = poly.fit_transform(features)
poly_names = poly.get_feature_names_out(['quantity', 'rating'])

print(f"Original features: {features.shape[1]}")
print(f"Polynomial features: {poly_features.shape[1]}")
print(f"Feature names: {poly_names}")

# SECTION 4: Mathematical Transformations
print("\\nSECTION 4: Mathematical Transformations")
print("-"*80)

# 4.1 Log transformation
df['income_log'] = np.log1p(df['income'])  # log(1+x) to handle zeros
print("Log transformation reduces right skew")
print(f"Original skew: {df['income'].skew():.2f}")
print(f"Log skew: {df['income_log'].skew():.2f}")

# 4.2 Square root transformation
df['price_sqrt'] = np.sqrt(df['price'])
print(f"\\nSqrt transformation")
print(f"Original skew: {df['price'].skew():.2f}")
print(f"Sqrt skew: {df['price_sqrt'].skew():.2f}")

# 4.3 Box-Cox transformation
from scipy import stats
df['sales_boxcox'], lambda_param = stats.boxcox(df['sales'] + 1)
print(f"\\nBox-Cox transformation (lambda={lambda_param:.3f})")
print(f"Original skew: {df['sales'].skew():.2f}")
print(f"Box-Cox skew: {df['sales_boxcox'].skew():.2f}")

# SECTION 5: Power Transformer
print("\\nSECTION 5: Power Transformer (Yeo-Johnson)")
print("-"*80)
"""
Yeo-Johnson: Handles positive and negative values
Box-Cox: Only positive values
"""
pt = PowerTransformer(method='yeo-johnson')
df['income_power'] = pt.fit_transform(df[['income']])
print(f"Original skew: {df['income'].skew():.2f}")
print(f"Power transform skew: {df['income_power'].skew():.2f}")

print("\\n" + "="*80)
print("TUTORIAL COMPLETED!")
print("="*80)
print("""
KEY TAKEAWAYS:
1. Scale features for gradient-based and distance-based algorithms
2. Use RobustScaler when data has outliers
3. Binning creates categorical features from continuous
4. Polynomial features capture interactions
5. Log/sqrt transformations reduce right skew
6. Power transformations make data more Gaussian

WHEN TO USE WHAT:
- Linear models: StandardScaler + log transform skewed features
- Tree models: Often don't need scaling or transformation
- Neural networks: MinMaxScaler or StandardScaler
- KNN/SVM: Always scale features
""")
