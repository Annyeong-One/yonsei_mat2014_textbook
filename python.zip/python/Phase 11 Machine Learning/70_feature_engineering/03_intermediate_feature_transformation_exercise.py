"""
INTERMEDIATE: Feature Transformation - EXERCISE
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler, RobustScaler

np.random.seed(42)
df = pd.DataFrame({
    'price': np.random.exponential(50, 500),
    'age': np.random.randint(18, 70, 500),
    'score': np.random.uniform(0, 100, 500),
    'income': np.random.lognormal(10, 1, 500)
})

print("EXERCISES:")
print("1. Apply StandardScaler to 'price' → Create 'price_scaled'")
print("2. Apply MinMaxScaler to 'score' → Create 'score_normalized'")
print("3. Create age bins: [18-30, 31-45, 46-60, 61+] → Create 'age_group'")
print("4. Apply log transformation to 'income' → Create 'income_log'")
print("5. Calculate skewness before and after log transformation")
# YOUR CODE HERE
