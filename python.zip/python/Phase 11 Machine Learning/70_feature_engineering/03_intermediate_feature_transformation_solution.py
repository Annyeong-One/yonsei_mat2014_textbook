"""
INTERMEDIATE: Feature Transformation - SOLUTION
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler

np.random.seed(42)
df = pd.DataFrame({
    'price': np.random.exponential(50, 500),
    'age': np.random.randint(18, 70, 500),
    'score': np.random.uniform(0, 100, 500),
    'income': np.random.lognormal(10, 1, 500)
})

# SOLUTION 1: StandardScaler
scaler = StandardScaler()
df['price_scaled'] = scaler.fit_transform(df[['price']])
print("1. StandardScaler applied")
print(f"   Mean: {df['price_scaled'].mean():.6f}")
print(f"   Std: {df['price_scaled'].std():.6f}")

# SOLUTION 2: MinMaxScaler
minmax = MinMaxScaler()
df['score_normalized'] = minmax.fit_transform(df[['score']])
print("\n2. MinMaxScaler applied")
print(f"   Min: {df['score_normalized'].min():.6f}")
print(f"   Max: {df['score_normalized'].max():.6f}")

# SOLUTION 3: Age bins
df['age_group'] = pd.cut(df['age'], bins=[18, 30, 45, 60, 100], 
                         labels=['18-30', '31-45', '46-60', '61+'])
print("\n3. Age bins created")
print(df['age_group'].value_counts().sort_index())

# SOLUTION 4: Log transformation
df['income_log'] = np.log1p(df['income'])
print("\n4. Log transformation applied")

# SOLUTION 5: Skewness
print("\n5. Skewness comparison:")
print(f"   Income original skew: {df['income'].skew():.3f}")
print(f"   Income log skew: {df['income_log'].skew():.3f}")
print("   (Log transformation reduced skewness!)")
