"""
============================================================================
ADVANCED LEVEL: Feature Selection
============================================================================
Learning Objectives:
1. Understand filter, wrapper, and embedded methods
2. Apply correlation-based selection
3. Use mutual information and chi-square
4. Implement RFE and forward/backward selection
5. Use model-based feature importance
6. Combine multiple selection methods

Time: 120 minutes
============================================================================
"""
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.feature_selection import (SelectKBest, chi2, f_classif, mutual_info_classif,
                                       RFE, SelectFromModel, VarianceThreshold)
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression, LassoCV
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("ADVANCED: Feature Selection")
print("="*80)

# Generate synthetic dataset
X, y = make_classification(n_samples=1000, n_features=50, n_informative=15, 
                          n_redundant=20, n_repeated=5, random_state=42)
feature_names = [f'feature_{i}' for i in range(X.shape[1])]
df = pd.DataFrame(X, columns=feature_names)
df['target'] = y

print(f"Dataset: {df.shape}")
print(f"Features: {X.shape[1]}")
print(f"Target distribution: {pd.Series(y).value_counts().to_dict()}")
print()

# SECTION 1: Filter Methods
print("SECTION 1: Filter Methods")
print("-"*80)
"""
Filter methods evaluate features independently using statistical tests.
Fast, but don't consider feature interactions.
"""

# 1.1 Variance Threshold
print("1.1 Variance Threshold")
print("-"*40)
selector = VarianceThreshold(threshold=0.1)
X_var = selector.fit_transform(X)
print(f"Features before: {X.shape[1]}")
print(f"Features after: {X_var.shape[1]}")
print(f"Removed: {X.shape[1] - X_var.shape[1]} features")

# 1.2 Correlation with target
print("\n1.2 Correlation with Target")
print("-"*40)
correlations = df.corr()['target'].drop('target').abs().sort_values(ascending=False)
print("Top 10 features by correlation:")
print(correlations.head(10))

# 1.3 Chi-square test
print("\n1.3 Chi-Square Test")
print("-"*40)
X_positive = X - X.min() + 1  # Chi2 requires non-negative
selector = SelectKBest(chi2, k=10)
X_chi2 = selector.fit_transform(X_positive, y)
selected_features = [feature_names[i] for i in selector.get_support(indices=True)]
print(f"Selected features: {selected_features[:10]}")

# 1.4 Mutual Information
print("\n1.4 Mutual Information")
print("-"*40)
mi_scores = mutual_info_classif(X, y, random_state=42)
mi_df = pd.DataFrame({'feature': feature_names, 'mi_score': mi_scores})
mi_df = mi_df.sort_values('mi_score', ascending=False)
print("Top 10 by MI:")
print(mi_df.head(10))

# SECTION 2: Wrapper Methods
print("\nSECTION 2: Wrapper Methods")
print("-"*80)
"""
Wrapper methods evaluate feature subsets using a model.
Computationally expensive but consider feature interactions.
"""

# 2.1 Recursive Feature Elimination
print("2.1 Recursive Feature Elimination (RFE)")
print("-"*40)
model = LogisticRegression(max_iter=1000, random_state=42)
rfe = RFE(estimator=model, n_features_to_select=15)
X_rfe = rfe.fit_transform(X, y)
selected_rfe = [feature_names[i] for i in rfe.get_support(indices=True)]
print(f"RFE selected {len(selected_rfe)} features:")
print(selected_rfe)

# SECTION 3: Embedded Methods
print("\nSECTION 3: Embedded Methods")
print("-"*80)
"""
Embedded methods perform feature selection during model training.
Balance between speed and accuracy.
"""

# 3.1 L1 Regularization (Lasso)
print("3.1 L1 Regularization (Lasso)")
print("-"*40)
lasso = LassoCV(cv=5, random_state=42, max_iter=10000)
lasso.fit(X, y)
coef_df = pd.DataFrame({'feature': feature_names, 'coef': abs(lasso.coef_)})
coef_df = coef_df[coef_df['coef'] > 0].sort_values('coef', ascending=False)
print(f"Lasso selected {len(coef_df)} features")
print(coef_df.head(10))

# 3.2 Tree-based Feature Importance
print("\n3.2 Tree-based Feature Importance")
print("-"*40)
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X, y)
importance_df = pd.DataFrame({
    'feature': feature_names,
    'importance': rf.feature_importances_
}).sort_values('importance', ascending=False)
print("Top 10 by importance:")
print(importance_df.head(10))

# 3.3 SelectFromModel
print("\n3.3 SelectFromModel (Threshold-based)")
print("-"*40)
selector = SelectFromModel(rf, threshold='median', prefit=True)
X_sfm = selector.transform(X)
selected_sfm = [feature_names[i] for i in selector.get_support(indices=True)]
print(f"Selected {len(selected_sfm)} features above median importance")

# SECTION 4: Combining Methods
print("\nSECTION 4: Combining Multiple Methods")
print("-"*80)
"""
Combine different selection methods for robustness.
Features selected by multiple methods are more likely to be important.
"""

# Get features from each method
mi_top = set(mi_df.head(15)['feature'])
corr_top = set(correlations.head(15).index)
rfe_top = set(selected_rfe)
rf_top = set(importance_df.head(15)['feature'])

# Find intersection
common_features = mi_top & corr_top & rfe_top & rf_top
print(f"Features selected by all 4 methods: {len(common_features)}")
print(common_features)

# Find union (at least 2 methods)
from collections import Counter
all_selections = list(mi_top) + list(corr_top) + list(rfe_top) + list(rf_top)
feature_votes = Counter(all_selections)
robust_features = {f for f, count in feature_votes.items() if count >= 3}
print(f"\nFeatures selected by 3+ methods: {len(robust_features)}")
print(robust_features)

print("\n" + "="*80)
print("TUTORIAL COMPLETED!")
print("="*80)
print("""
KEY TAKEAWAYS:

1. FILTER METHODS:
   - Fast, scalable
   - Univariate (don't consider interactions)
   - Use: Initial screening, very high-dimensional data
   
2. WRAPPER METHODS:
   - Consider feature interactions
   - Computationally expensive
   - Use: Small-medium datasets, when performance is critical
   
3. EMBEDDED METHODS:
   - Good balance of speed and accuracy
   - Model-specific feature importance
   - Use: L1 for sparse solutions, trees for non-linear relationships

4. COMBINATION:
   - More robust than single method
   - Consensus features are likely important
   - Use: Production systems, important decisions

SELECTION STRATEGY:
1. Start with variance threshold (remove constants)
2. Use correlation/MI for quick screening
3. Apply embedded methods (Lasso/RF)
4. Validate with wrapper methods (RFE)
5. Cross-validate results
6. Choose features appearing in multiple methods
""")
