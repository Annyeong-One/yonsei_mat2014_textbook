"""
ADVANCED: Feature Selection - EXERCISE
"""
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.feature_selection import SelectKBest, f_classif, RFE
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

X, y = make_classification(n_samples=500, n_features=30, n_informative=10, 
                          n_redundant=10, random_state=42)

print("EXERCISES:")
print("1. Remove features with variance < 0.05")
print("2. Select top 10 features using f_classif")
print("3. Use RFE with LogisticRegression to select 8 features")
print("4. Get feature importances from RandomForestClassifier")
print("5. Find features selected by both f_classif and RF importance")
# YOUR CODE HERE
