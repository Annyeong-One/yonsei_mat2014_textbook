"""
ADVANCED: Feature Selection - SOLUTION
"""
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.feature_selection import SelectKBest, f_classif, RFE, VarianceThreshold
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

X, y = make_classification(n_samples=500, n_features=30, n_informative=10, 
                          n_redundant=10, random_state=42)
feature_names = [f'f_{i}' for i in range(X.shape[1])]

# SOLUTION 1: Variance threshold
print("SOLUTION 1: Variance Threshold")
vt = VarianceThreshold(threshold=0.05)
X_vt = vt.fit_transform(X)
print(f"Features: {X.shape[1]} → {X_vt.shape[1]}")

# SOLUTION 2: SelectKBest
print("\nSOLUTION 2: SelectKBest")
selector = SelectKBest(f_classif, k=10)
X_kb = selector.fit_transform(X, y)
kb_features = [feature_names[i] for i in selector.get_support(indices=True)]
print(f"Selected: {kb_features}")

# SOLUTION 3: RFE
print("\nSOLUTION 3: RFE")
rfe = RFE(LogisticRegression(max_iter=1000), n_features_to_select=8)
X_rfe = rfe.fit_transform(X, y)
rfe_features = [feature_names[i] for i in rfe.get_support(indices=True)]
print(f"Selected: {rfe_features}")

# SOLUTION 4: RF Importance
print("\nSOLUTION 4: Random Forest Importance")
rf = RandomForestClassifier(n_estimators=100, random_state=42)
rf.fit(X, y)
importance = pd.DataFrame({
    'feature': feature_names,
    'importance': rf.feature_importances_
}).sort_values('importance', ascending=False)
print("Top 10:")
print(importance.head(10))

# SOLUTION 5: Intersection
print("\nSOLUTION 5: Feature Intersection")
rf_top10 = set(importance.head(10)['feature'])
kb_set = set(kb_features)
common = rf_top10 & kb_set
print(f"Features in both: {common}")
print(f"Count: {len(common)}")
