"""
============================================================================
ADVANCED LEVEL: Automated Feature Engineering
============================================================================
Learning Objectives:
1. Understand automated feature generation
2. Create polynomial and interaction features systematically
3. Apply dimensionality reduction (PCA, LDA)
4. Build feature engineering pipelines
5. Combine manual and automated approaches

Time: 120 minutes
============================================================================
"""
import pandas as pd
import numpy as np
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn.pipeline import Pipeline
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
import warnings
warnings.filterwarnings('ignore')

print("="*80)
print("ADVANCED: Automated Feature Engineering")
print("="*80)

# Generate sample data
from sklearn.datasets import make_classification
X, y = make_classification(n_samples=1000, n_features=20, n_informative=10,
                          n_redundant=5, random_state=42)
df = pd.DataFrame(X, columns=[f'f{i}' for i in range(X.shape[1])])
df['target'] = y

print(f"Dataset shape: {df.shape}")
print()

# SECTION 1: Polynomial Features
print("SECTION 1: Polynomial Feature Generation")
print("-"*80)
"""
Automatically generate polynomial and interaction terms.
degree=2: Add x², x*y for all feature pairs
degree=3: Add x³, x²*y, etc.
"""

# Basic polynomial features
poly = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly.fit_transform(X[:, :5])  # Use first 5 features
print(f"Original features: {X[:, :5].shape[1]}")
print(f"Polynomial features: {X_poly.shape[1]}")
print(f"Feature names: {poly.get_feature_names_out([f'f{i}' for i in range(5)])[:10]}")

# Only interaction terms
poly_inter = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
X_inter = poly_inter.fit_transform(X[:, :5])
print(f"\nInteraction-only features: {X_inter.shape[1]}")

# SECTION 2: Dimensionality Reduction
print("\nSECTION 2: Dimensionality Reduction")
print("-"*80)

# 2.1 Principal Component Analysis (PCA)
print("2.1 PCA (unsupervised)")
print("-"*40)
"""
PCA finds linear combinations that maximize variance.
Use when: Features are correlated, want to reduce dimensions
"""
pca = PCA(n_components=10)
X_pca = pca.fit_transform(X)
print(f"Original: {X.shape[1]} features")
print(f"PCA: {X_pca.shape[1]} components")
print(f"Variance explained: {pca.explained_variance_ratio_.sum():.2%}")
print(f"\nFirst 5 components explained variance:")
for i, var in enumerate(pca.explained_variance_ratio_[:5]):
    print(f"  PC{i+1}: {var:.2%}")

# 2.2 Linear Discriminant Analysis (LDA)
print("\n2.2 LDA (supervised)")
print("-"*40)
"""
LDA maximizes class separation.
Use when: Have labels, want discriminative features
"""
lda = LDA(n_components=1)  # Binary classification: max 1 component
X_lda = lda.fit_transform(X, y)
print(f"LDA components: {X_lda.shape[1]}")
print(f"Explained variance ratio: {lda.explained_variance_ratio_}")

# SECTION 3: Automated Feature Generation Strategies
print("\nSECTION 3: Automated Feature Generation")
print("-"*80)

# 3.1 Mathematical transformations
print("3.1 Systematic Mathematical Transformations")
print("-"*40)
"""
Apply common transformations to all numerical features.
"""
X_sample = X[:, :3]
transformations = {
    'log': lambda x: np.log1p(np.abs(x)),
    'sqrt': lambda x: np.sqrt(np.abs(x)),
    'square': lambda x: x**2,
    'reciprocal': lambda x: 1 / (x + 1e-10)
}

X_transformed = X_sample.copy()
for name, func in transformations.items():
    X_transformed = np.hstack([X_transformed, func(X_sample)])

print(f"Original: {X_sample.shape[1]} features")
print(f"After transformations: {X_transformed.shape[1]} features")

# 3.2 Statistical aggregations
print("\n3.2 Statistical Aggregations")
print("-"*40)
"""
Create features from statistical properties of groups.
"""
# Group features and create statistics
feature_groups = [X[:, :5], X[:, 5:10], X[:, 10:15]]
stats_features = []

for i, group in enumerate(feature_groups):
    stats_features.append(np.mean(group, axis=1, keepdims=True))
    stats_features.append(np.std(group, axis=1, keepdims=True))
    stats_features.append(np.max(group, axis=1, keepdims=True))
    stats_features.append(np.min(group, axis=1, keepdims=True))

X_stats = np.hstack(stats_features)
print(f"Created {X_stats.shape[1]} statistical features from groups")

# SECTION 4: Feature Engineering Pipeline
print("\nSECTION 4: Feature Engineering Pipeline")
print("-"*80)
"""
Create reproducible pipeline for feature engineering.
"""

# Define pipeline
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('poly', PolynomialFeatures(degree=2, interaction_only=True)),
    ('pca', PCA(n_components=15)),
    ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
])

# Evaluate pipeline
scores = cross_val_score(pipeline, X, y, cv=5, scoring='accuracy')
print(f"Pipeline CV accuracy: {scores.mean():.3f} (+/- {scores.std():.3f})")

# Compare with baseline (no feature engineering)
baseline = Pipeline([
    ('scaler', StandardScaler()),
    ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
])
baseline_scores = cross_val_score(baseline, X, y, cv=5, scoring='accuracy')
print(f"Baseline CV accuracy: {baseline_scores.mean():.3f} (+/- {baseline_scores.std():.3f})")
print(f"Improvement: {(scores.mean() - baseline_scores.mean()):.3f}")

# SECTION 5: Feature Generation Best Practices
print("\nSECTION 5: Best Practices")
print("-"*80)
print("""
1. START SIMPLE:
   - Begin with domain-knowledge features
   - Add automated features gradually
   - Test impact of each addition

2. AVOID OVERFITTING:
   - Use cross-validation
   - Regularization when many features
   - Feature selection after generation

3. COMPUTATIONAL COST:
   - Polynomial features explode quickly
   - degree=3 on 10 features → 286 features
   - degree=3 on 20 features → 1771 features!

4. FEATURE SELECTION AFTER GENERATION:
   - Generate many candidates
   - Select best subset
   - Reduces overfitting and computation

5. PIPELINE BENEFITS:
   - Reproducible
   - Prevents data leakage
   - Easy to deploy
   - Grid search compatible

6. DOMAIN KNOWLEDGE > AUTOMATION:
   - Automated features are generic
   - Domain features are specific
   - Best: Combine both approaches

RECOMMENDED WORKFLOW:
====================
1. Exploratory Data Analysis
2. Manual feature engineering (domain knowledge)
3. Automated feature generation (interactions, transforms)
4. Feature selection (reduce to best subset)
5. Model training with selected features
6. Validate on holdout set
7. Deploy pipeline
""")

# SECTION 6: Practical Example
print("\nSECTION 6: Complete Example")
print("-"*80)

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create comprehensive pipeline
from sklearn.feature_selection import SelectKBest, f_classif

full_pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('poly', PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)),
    ('selector', SelectKBest(f_classif, k=30)),  # Select best 30 features
    ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
])

# Train
full_pipeline.fit(X_train, y_train)

# Evaluate
y_pred = full_pipeline.predict(X_test)
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Feature transformation details
poly_transformer = full_pipeline.named_steps['poly']
print(f"\nFeatures after polynomial: {poly_transformer.n_output_features_}")
print(f"Features after selection: 30")

print("\n" + "="*80)
print("TUTORIAL COMPLETED!")
print("="*80)
print("""
You've learned:
✓ Automated polynomial feature generation
✓ Dimensionality reduction (PCA, LDA)
✓ Systematic transformations
✓ Feature engineering pipelines
✓ Combining manual and automated approaches
✓ Best practices for automation

Remember: Automation accelerates feature engineering, but domain
knowledge ensures meaningful features. Use both!
""")
