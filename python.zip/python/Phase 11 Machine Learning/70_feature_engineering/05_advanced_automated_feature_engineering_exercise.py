"""
ADVANCED: Automated Feature Engineering - EXERCISE
"""
import numpy as np
from sklearn.datasets import make_classification
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

X, y = make_classification(n_samples=800, n_features=15, n_informative=8, random_state=42)

print("EXERCISES:")
print("1. Create polynomial features (degree=2, interaction_only=True)")
print("2. Apply PCA to reduce to 10 components")
print("3. Create pipeline: StandardScaler → PolynomialFeatures → PCA → RF")
print("4. Evaluate pipeline using 5-fold CV")
print("5. Compare with baseline (no feature engineering)")
# YOUR CODE HERE
