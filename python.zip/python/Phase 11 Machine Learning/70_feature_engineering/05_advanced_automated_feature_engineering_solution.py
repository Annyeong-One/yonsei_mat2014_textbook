"""
ADVANCED: Automated Feature Engineering - SOLUTION
"""
import numpy as np
from sklearn.datasets import make_classification
from sklearn.preprocessing import PolynomialFeatures, StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score

X, y = make_classification(n_samples=800, n_features=15, n_informative=8, random_state=42)

# SOLUTION 1: Polynomial features
print("SOLUTION 1: Polynomial Features")
poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
X_poly = poly.fit_transform(X)
print(f"Original: {X.shape[1]} features")
print(f"Polynomial: {X_poly.shape[1]} features")

# SOLUTION 2: PCA
print("\nSOLUTION 2: PCA")
pca = PCA(n_components=10)
X_pca = pca.fit_transform(X_poly)
print(f"PCA components: {X_pca.shape[1]}")
print(f"Variance explained: {pca.explained_variance_ratio_.sum():.2%}")

# SOLUTION 3: Pipeline
print("\nSOLUTION 3: Pipeline")
pipeline = Pipeline([
    ('scaler', StandardScaler()),
    ('poly', PolynomialFeatures(degree=2, interaction_only=True)),
    ('pca', PCA(n_components=10)),
    ('rf', RandomForestClassifier(n_estimators=100, random_state=42))
])
print("Pipeline created")

# SOLUTION 4: Cross-validation
print("\nSOLUTION 4: Cross-validation")
scores = cross_val_score(pipeline, X, y, cv=5, scoring='accuracy')
print(f"CV Accuracy: {scores.mean():.3f} (+/- {scores.std():.3f})")

# SOLUTION 5: Baseline comparison
print("\nSOLUTION 5: Baseline Comparison")
baseline = Pipeline([
    ('scaler', StandardScaler()),
    ('rf', RandomForestClassifier(n_estimators=100, random_state=42))
])
baseline_scores = cross_val_score(baseline, X, y, cv=5, scoring='accuracy')
print(f"Baseline: {baseline_scores.mean():.3f} (+/- {baseline_scores.std():.3f})")
print(f"Improvement: {(scores.mean() - baseline_scores.mean()):.3f}")
print("\nFeature engineering improved the model!" if scores.mean() > baseline_scores.mean() else "Baseline was better")
