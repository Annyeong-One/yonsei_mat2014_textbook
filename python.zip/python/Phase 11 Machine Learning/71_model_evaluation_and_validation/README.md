# Model Evaluation & Validation
## Comprehensive Python Tutorial Package for Undergraduate Education

**Author:** Educational Python Series  
**Topic:** Model Evaluation & Validation - Cross-validation and Metrics  
**Level:** Beginner through Advanced

---

## 📚 Package Overview

This comprehensive educational package covers model evaluation and validation techniques essential for machine learning. The materials progress from fundamental concepts to advanced methodologies, suitable for a full-year undergraduate Python course.

### What You'll Learn

- **Train-Test Split:** Proper data splitting strategies and best practices
- **Evaluation Metrics:** Classification and regression metrics with interpretations
- **Cross-Validation:** Multiple CV strategies including k-fold, stratified, time series, and LOOCV
- **ROC Curves & AUC:** Probability-based evaluation and threshold optimization
- **Learning Curves:** Diagnosing bias and variance problems
- **Nested Cross-Validation:** Unbiased hyperparameter tuning methodology
- **Custom Metrics:** Creating domain-specific evaluation functions
- **Model Selection:** Comprehensive strategies for comparing and selecting models

---

## 📂 Package Structure

```
model_evaluation_validation/
│
├── README.md                          # This file
│
├── beginner/                          # 🟢 Beginner Level
│   ├── 01_train_test_split.py       # Train-test split fundamentals
│   └── 02_basic_metrics.py          # Basic evaluation metrics
│
├── intermediate/                      # 🟡 Intermediate Level
│   ├── 01_cross_validation.py       # Cross-validation techniques
│   ├── 02_roc_auc_curves.py         # ROC curves and AUC
│   └── 03_learning_curves.py        # Learning and validation curves
│
├── advanced/                          # 🔴 Advanced Level
│   ├── 01_nested_cross_validation.py # Nested CV for hyperparameter tuning
│   ├── 02_custom_metrics.py         # Custom scoring functions
│   └── 03_model_selection_strategies.py # Comprehensive model comparison
│
├── exercises/                         # 💪 Practice Exercises
│   ├── exercise_01_basics.py        # Train-test split exercises
│   ├── exercise_02_metrics.py       # Advanced metrics exercises
│   └── exercise_03_cv.py            # Cross-validation exercises
│
└── solutions/                         # ✅ Complete Solutions
    ├── solution_01_basics.py        # Solutions for exercise 1
    ├── solution_02_metrics.py       # Solutions for exercise 2
    └── solution_03_cv.py            # Solutions for exercise 3
```

---

## 🎯 Learning Path

### Beginner Level (Weeks 1-3)

**Prerequisites:** Basic Python, NumPy, scikit-learn basics

#### Module 1: Train-Test Split (`beginner/01_train_test_split.py`)
- Why we split data
- Using `train_test_split()`
- Different split ratios (80-20, 70-30, etc.)
- Random state and reproducibility
- Stratified splitting for imbalanced data
- Common mistakes and best practices

**Key Functions:**
```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, 
    test_size=0.2,      # 20% for testing
    random_state=42,    # Reproducibility
    stratify=y          # Preserve class distribution
)
```

#### Module 2: Basic Metrics (`beginner/02_basic_metrics.py`)
- **Classification Metrics:**
  - Accuracy and its limitations
  - Confusion matrix interpretation
  - Precision, Recall, F1-Score
  - Classification report
  
- **Regression Metrics:**
  - Mean Squared Error (MSE)
  - Root Mean Squared Error (RMSE)
  - Mean Absolute Error (MAE)
  - R² Score (Coefficient of Determination)

**Key Functions:**
```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report,
    mean_squared_error, mean_absolute_error, r2_score
)
```

**Practice:** Complete `exercises/exercise_01_basics.py`

---

### Intermediate Level (Weeks 4-8)

**Prerequisites:** Completed beginner level, understanding of train-test split and basic metrics

#### Module 3: Cross-Validation (`intermediate/01_cross_validation.py`)
- Motivation for cross-validation
- K-Fold Cross-Validation
- Stratified K-Fold for classification
- Leave-One-Out Cross-Validation (LOOCV)
- Time Series Cross-Validation
- Using `cross_val_score()` and `cross_validate()`
- Choosing the right CV strategy

**Key Functions:**
```python
from sklearn.model_selection import (
    cross_val_score, cross_validate,
    KFold, StratifiedKFold, LeaveOneOut, TimeSeriesSplit
)

# Simple cross-validation
scores = cross_val_score(model, X, y, cv=5)

# Multiple metrics with training scores
results = cross_validate(
    model, X, y, cv=5,
    scoring=['accuracy', 'precision', 'recall'],
    return_train_score=True
)
```

**Decision Guide:**
- **Time series data?** → Use `TimeSeriesSplit`
- **Small dataset (n < 100)?** → Consider `LeaveOneOut`
- **Classification?** → Use `StratifiedKFold`
- **General case?** → Use `KFold` with k=5 or k=10

#### Module 4: ROC Curves & AUC (`intermediate/02_roc_auc_curves.py`)
- Probability predictions
- ROC (Receiver Operating Characteristic) curves
- AUC (Area Under the Curve) interpretation
- Precision-Recall curves
- Threshold optimization
- When to use ROC vs PR curves

**Key Functions:**
```python
from sklearn.metrics import roc_curve, auc, roc_auc_score

# Get probabilities
y_proba = model.predict_proba(X_test)[:, 1]

# Calculate ROC curve
fpr, tpr, thresholds = roc_curve(y_test, y_proba)
roc_auc = auc(fpr, tpr)

# Or directly
auc_score = roc_auc_score(y_test, y_proba)
```

#### Module 5: Learning Curves (`intermediate/03_learning_curves.py`)
- Understanding learning curves
- Diagnosing high bias (underfitting)
- Diagnosing high variance (overfitting)
- Validation curves for hyperparameter tuning
- Determining if more data will help

**Key Functions:**
```python
from sklearn.model_selection import learning_curve, validation_curve

# Learning curve: performance vs training size
train_sizes, train_scores, val_scores = learning_curve(
    model, X, y, cv=5,
    train_sizes=np.linspace(0.1, 1.0, 10)
)

# Validation curve: performance vs hyperparameter
train_scores, val_scores = validation_curve(
    model, X, y,
    param_name="max_depth",
    param_range=np.arange(1, 21),
    cv=5
)
```

**Practice:** Complete `exercises/exercise_02_metrics.py` and `exercise_03_cv.py`

---

### Advanced Level (Weeks 9-12)

**Prerequisites:** Solid understanding of cross-validation and metrics

#### Module 6: Nested Cross-Validation (`advanced/01_nested_cross_validation.py`)
- Problem: Biased performance estimates from GridSearchCV
- Nested CV structure: outer loop for evaluation, inner loop for selection
- Implementing nested cross-validation
- Comparison with simple GridSearchCV
- When nested CV is necessary

**Key Concept:**
```python
from sklearn.model_selection import GridSearchCV, KFold

outer_cv = KFold(n_splits=5)  # Performance estimation
inner_cv = KFold(n_splits=3)  # Hyperparameter selection

for train_idx, test_idx in outer_cv.split(X):
    X_train, X_test = X[train_idx], X[test_idx]
    
    # Inner CV: find best hyperparameters
    grid_search = GridSearchCV(model, param_grid, cv=inner_cv)
    grid_search.fit(X_train, y_train)
    
    # Evaluate on outer test fold
    score = grid_search.score(X_test, y_test)
```

#### Module 7: Custom Metrics (`advanced/02_custom_metrics.py`)
- Creating custom scoring functions
- Using `make_scorer()` for cross-validation
- Asymmetric cost functions
- Business-specific metrics
- Domain-specific evaluation

**Key Functions:**
```python
from sklearn.metrics import make_scorer

def custom_metric(y_true, y_pred):
    # Your custom logic
    return score

custom_scorer = make_scorer(custom_metric)
cross_val_score(model, X, y, cv=5, scoring=custom_scorer)
```

#### Module 8: Model Selection Strategies (`advanced/03_model_selection_strategies.py`)
- Comparing multiple models
- Multiple metrics simultaneously
- Statistical significance testing
- Computational considerations
- Best practices for model selection

---

## 🚀 Getting Started

### Installation Requirements

```bash
# Required packages
pip install numpy pandas scikit-learn matplotlib seaborn

# Optional for additional functionality
pip install jupyter notebook
```

### Running the Modules

Each Python file is self-contained and can be run independently:

```bash
# Beginner level
python beginner/01_train_test_split.py
python beginner/02_basic_metrics.py

# Intermediate level
python intermediate/01_cross_validation.py
python intermediate/02_roc_auc_curves.py
python intermediate/03_learning_curves.py

# Advanced level
python advanced/01_nested_cross_validation.py
python advanced/02_custom_metrics.py
python advanced/03_model_selection_strategies.py
```

### Working with Exercises

1. **Start with exercises:** Open any exercise file in `exercises/`
2. **Read the tasks:** Each function has clear TODO comments
3. **Implement solutions:** Write your code to complete each task
4. **Check solutions:** Compare with corresponding file in `solutions/`
5. **Run solutions:** Execute solution files to see complete implementations

---

## 📊 Key Metrics Summary

### Classification Metrics

| Metric | Formula | When to Use | Range |
|--------|---------|-------------|-------|
| **Accuracy** | (TP + TN) / Total | Balanced datasets | [0, 1] |
| **Precision** | TP / (TP + FP) | Minimize false positives | [0, 1] |
| **Recall** | TP / (TP + FN) | Minimize false negatives | [0, 1] |
| **F1-Score** | 2 × (P × R) / (P + R) | Balance precision & recall | [0, 1] |
| **ROC-AUC** | Area under ROC curve | Threshold-independent | [0, 1] |

### Regression Metrics

| Metric | Formula | When to Use | Range |
|--------|---------|-------------|-------|
| **MSE** | (1/n) Σ(y - ŷ)² | Penalize large errors | [0, ∞) |
| **RMSE** | √MSE | Same units as target | [0, ∞) |
| **MAE** | (1/n) Σ\|y - ŷ\| | Robust to outliers | [0, ∞) |
| **R²** | 1 - SS_res/SS_tot | Variance explained | (-∞, 1] |

---

## 🎓 Teaching Guidelines

### For Instructors

**Semester Plan:**
- **Weeks 1-3:** Beginner modules (foundation building)
- **Weeks 4-5:** Cross-validation techniques
- **Weeks 6-7:** ROC curves and learning curves
- **Weeks 8-10:** Advanced topics
- **Weeks 11-12:** Practice exercises and projects

**Assessment Suggestions:**
1. Weekly coding assignments using exercises
2. Mid-term: Implement full model evaluation pipeline
3. Final project: Comprehensive model comparison with report

**Lab Sessions:**
- Run live demonstrations from module files
- Have students modify parameters and observe results
- Encourage experimentation with different datasets

### For Students

**Study Tips:**
1. Run every example in the modules
2. Modify parameters to understand their effects
3. Complete all exercises before checking solutions
4. Create your own datasets to practice
5. Document your observations in comments

**Common Pitfalls to Avoid:**
- ❌ Testing on training data
- ❌ Not using random_state (irreproducible results)
- ❌ Ignoring class imbalance in classification
- ❌ Using regular K-Fold for time series data
- ❌ Relying solely on accuracy for imbalanced datasets
- ❌ Fitting preprocessing on entire dataset before splitting

---

## 📖 Additional Resources

### Documentation
- [scikit-learn User Guide](https://scikit-learn.org/stable/user_guide.html)
- [Model Evaluation](https://scikit-learn.org/stable/modules/model_evaluation.html)
- [Cross-validation](https://scikit-learn.org/stable/modules/cross_validation.html)

### Further Reading
- "The Elements of Statistical Learning" - Hastie, Tibshirani, Friedman
- "Pattern Recognition and Machine Learning" - Christopher Bishop
- "Hands-On Machine Learning with Scikit-Learn" - Aurélien Géron

---

## 🤝 Best Practices Checklist

### Data Splitting
- [ ] Always split data BEFORE any preprocessing
- [ ] Use stratification for classification problems
- [ ] Set random_state for reproducibility
- [ ] Use 70-30 or 80-20 split ratios
- [ ] Never touch test data until final evaluation

### Cross-Validation
- [ ] Use StratifiedKFold for classification
- [ ] Use TimeSeriesSplit for temporal data
- [ ] Typically use k=5 or k=10 folds
- [ ] Report mean ± std of CV scores
- [ ] Use nested CV for hyperparameter tuning

### Metrics
- [ ] Use multiple metrics, not just one
- [ ] Consider the cost of different error types
- [ ] For imbalanced data: precision, recall, F1, ROC-AUC
- [ ] For regression: RMSE or MAE (interpretable units)
- [ ] Always evaluate on held-out test data

---

## 🐛 Troubleshooting

### Common Issues

**ImportError: No module named 'sklearn'**
```bash
pip install scikit-learn
```

**Convergence Warnings**
```python
# Increase max_iter for LogisticRegression
model = LogisticRegression(max_iter=1000)
```

**Memory Issues with Large Datasets**
```python
# Use fewer CV folds or smaller training sizes
cross_val_score(model, X, y, cv=3)  # Instead of cv=10
```

**Plots Not Showing**
```python
# Add this at the end of scripts
plt.show()

# Or run in Jupyter notebooks for inline plots
```

---

## 📝 Notes for Development

### Code Style
- **Extensive comments:** Every section thoroughly documented
- **Educational focus:** Code optimized for learning, not just performance
- **Progressive complexity:** Each module builds on previous concepts
- **Consistent structure:** All modules follow the same organization pattern

### Module Features
- Complete mathematical explanations
- Visual demonstrations with matplotlib
- Real-world examples and analogies
- Common mistakes highlighted
- Best practices emphasized

---

## ✨ Version Information

**Version:** 1.0  
**Last Updated:** 2025  
**Python:** 3.8+  
**scikit-learn:** 1.0+

---

## 📧 Support

For questions about this educational package:
1. Review the relevant module file
2. Check the solutions for worked examples
3. Consult scikit-learn documentation
4. Review the troubleshooting section above

---

## 🎉 Summary

This package provides everything needed to master model evaluation and validation:

- ✅ **12 comprehensive modules** with detailed explanations
- ✅ **Progressive difficulty** from beginner to advanced
- ✅ **Extensive comments** explaining every concept
- ✅ **Visual demonstrations** for better understanding
- ✅ **Practice exercises** with complete solutions
- ✅ **Best practices** and common pitfalls highlighted
- ✅ **Real-world applications** and examples

**Happy Learning! 🚀**

---

*This educational package was created to provide undergraduate students with a comprehensive, well-documented resource for mastering model evaluation and validation techniques in machine learning.*
