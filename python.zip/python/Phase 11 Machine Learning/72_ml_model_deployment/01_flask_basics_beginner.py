"""
ML Model Deployment - Lesson 01: Flask Basics (BEGINNER)

This module introduces Flask, a lightweight web framework for Python.
Flask is commonly used to create RESTful APIs for serving machine learning models.

Topics covered:
- Installing and importing Flask
- Creating a simple Flask application
- Defining routes and endpoints
- Running a development server
- Understanding HTTP methods (GET, POST)

Learning objectives:
- Understand what a web API is
- Create basic Flask routes
- Handle simple HTTP requests
"""

# Flask is a micro web framework for Python
# Install: pip install flask
from flask import Flask, request, jsonify

# ============================================================================
# SECTION 1: Creating a Flask Application
# ============================================================================

# Create a Flask application instance
# __name__ helps Flask determine the root path of the application
app = Flask(__name__)

# ============================================================================
# SECTION 2: Defining Routes (Endpoints)
# ============================================================================

# A route is a URL pattern that the application responds to
# The @app.route() decorator binds a function to a URL

@app.route('/')
def home():
    """
    Home endpoint - responds to GET requests at the root URL
    
    Returns:
        str: A simple welcome message
    """
    return "Welcome to ML Model Deployment API!"


@app.route('/hello')
def hello():
    """
    Simple greeting endpoint
    
    Returns:
        str: A greeting message
    """
    return "Hello from Flask!"


# ============================================================================
# SECTION 3: Returning JSON Responses
# ============================================================================

@app.route('/api/info')
def api_info():
    """
    Returns JSON data about the API
    
    JSON (JavaScript Object Notation) is the standard format for API responses
    
    Returns:
        dict: JSON response with API information
    """
    # jsonify() converts Python dictionaries to JSON format
    return jsonify({
        'name': 'ML Deployment API',
        'version': '1.0',
        'status': 'active'
    })


# ============================================================================
# SECTION 4: Handling URL Parameters
# ============================================================================

@app.route('/greet/<name>')
def greet(name):
    """
    Dynamic route with URL parameter
    
    The <name> in the route captures the value from the URL
    Example: /greet/John will capture "John" as the name parameter
    
    Args:
        name (str): Name captured from URL
        
    Returns:
        dict: JSON response with personalized greeting
    """
    return jsonify({
        'message': f'Hello, {name}!',
        'endpoint': '/greet/<name>'
    })


# ============================================================================
# SECTION 5: Handling Query Parameters
# ============================================================================

@app.route('/calculate')
def calculate():
    """
    Demonstrates handling query parameters
    
    Query parameters are passed in the URL after '?'
    Example: /calculate?x=5&y=3
    
    Returns:
        dict: JSON response with calculation result
    """
    # request.args is a dictionary-like object containing query parameters
    # get() method safely retrieves parameters with a default value
    x = request.args.get('x', default=0, type=int)
    y = request.args.get('y', default=0, type=int)
    
    result = x + y
    
    return jsonify({
        'x': x,
        'y': y,
        'sum': result
    })


# ============================================================================
# SECTION 6: Handling POST Requests
# ============================================================================

@app.route('/echo', methods=['POST'])
def echo():
    """
    Handles POST requests with JSON data
    
    POST requests are used to send data to the server
    This is essential for sending data to ML models for prediction
    
    Expects JSON data in the request body
    
    Returns:
        dict: JSON response echoing the received data
    """
    # request.get_json() parses JSON data from the request body
    data = request.get_json()
    
    return jsonify({
        'received': data,
        'message': 'Data received successfully'
    })


# ============================================================================
# SECTION 7: Multiple HTTP Methods on Same Endpoint
# ============================================================================

@app.route('/data', methods=['GET', 'POST'])
def handle_data():
    """
    Endpoint that handles both GET and POST requests
    
    Returns:
        dict: Different responses based on request method
    """
    if request.method == 'GET':
        # GET request - typically used to retrieve data
        return jsonify({
            'method': 'GET',
            'message': 'Use POST to send data'
        })
    
    elif request.method == 'POST':
        # POST request - typically used to send data
        data = request.get_json()
        return jsonify({
            'method': 'POST',
            'received_data': data,
            'message': 'Data processed'
        })


# ============================================================================
# SECTION 8: Error Handling
# ============================================================================

@app.route('/divide')
def divide():
    """
    Demonstrates basic error handling
    
    Returns:
        dict: JSON response with division result or error message
    """
    try:
        # Get parameters from query string
        a = request.args.get('a', type=float)
        b = request.args.get('b', type=float)
        
        # Check if parameters were provided
        if a is None or b is None:
            return jsonify({
                'error': 'Missing parameters',
                'message': 'Please provide both a and b parameters'
            }), 400  # 400 = Bad Request
        
        # Perform division
        result = a / b
        
        return jsonify({
            'a': a,
            'b': b,
            'result': result
        })
        
    except ZeroDivisionError:
        # Handle division by zero
        return jsonify({
            'error': 'Division by zero',
            'message': 'Cannot divide by zero'
        }), 400


# ============================================================================
# SECTION 9: Running the Application
# ============================================================================

if __name__ == '__main__':
    """
    Main execution block
    
    The Flask development server is started here
    Note: This is for development only, not for production use
    """
    
    print("=" * 60)
    print("Flask API Server Starting...")
    print("=" * 60)
    print("\nAvailable Endpoints:")
    print("  GET  /                 - Home page")
    print("  GET  /hello            - Simple greeting")
    print("  GET  /api/info         - API information")
    print("  GET  /greet/<name>     - Personalized greeting")
    print("  GET  /calculate?x=&y=  - Calculate sum")
    print("  POST /echo             - Echo JSON data")
    print("  GET/POST /data         - Handle multiple methods")
    print("  GET  /divide?a=&b=     - Division with error handling")
    print("\n" + "=" * 60)
    print("Server running at: http://127.0.0.1:5000")
    print("Press Ctrl+C to stop the server")
    print("=" * 60 + "\n")
    
    # Start the Flask development server
    # debug=True enables auto-reload and detailed error messages
    # This should be False in production
    app.run(debug=True, host='0.0.0.0', port=5000)


# ============================================================================
# TESTING THE API
# ============================================================================
"""
To test this API, you can use:

1. Web browser (for GET requests):
   - http://127.0.0.1:5000/
   - http://127.0.0.1:5000/greet/John
   - http://127.0.0.1:5000/calculate?x=5&y=3

2. cURL (command line):
   # GET request
   curl http://127.0.0.1:5000/api/info
   
   # POST request with JSON data
   curl -X POST http://127.0.0.1:5000/echo \
        -H "Content-Type: application/json" \
        -d '{"name": "John", "age": 25}'

3. Python requests library:
   import requests
   
   # GET request
   response = requests.get('http://127.0.0.1:5000/api/info')
   print(response.json())
   
   # POST request
   data = {'name': 'John', 'age': 25}
   response = requests.post('http://127.0.0.1:5000/echo', json=data)
   print(response.json())

4. Postman or other API testing tools
"""

# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. Flask Application:
   - Created with Flask(__name__)
   - Routes defined with @app.route()
   - Run with app.run()

2. HTTP Methods:
   - GET: Retrieve data (default method)
   - POST: Send data to server
   - PUT: Update existing data
   - DELETE: Remove data

3. Request Handling:
   - URL parameters: /user/<id>
   - Query parameters: /search?q=term
   - JSON body: request.get_json()

4. Response Format:
   - JSON is standard for APIs
   - Use jsonify() to return JSON
   - Include appropriate status codes

5. Error Handling:
   - Try-except blocks for exceptions
   - Return appropriate HTTP status codes
   - Provide clear error messages
"""
