"""
ML Model Deployment - Lesson 02: FastAPI Basics (BEGINNER)

This module introduces FastAPI, a modern, fast web framework for building APIs.
FastAPI is particularly well-suited for ML model deployment due to its:
- Automatic data validation
- Built-in API documentation
- High performance (based on Starlette and Pydantic)
- Type hints and async support

Topics covered:
- Installing and importing FastAPI
- Creating FastAPI applications
- Defining endpoints with type hints
- Automatic data validation with Pydantic
- Built-in API documentation (Swagger UI)

Learning objectives:
- Understand FastAPI advantages for ML deployment
- Use type hints for automatic validation
- Access interactive API documentation
"""

# FastAPI is a modern web framework for building APIs
# Install: pip install fastapi uvicorn
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field, validator
from typing import List, Optional
import uvicorn

# ============================================================================
# SECTION 1: Creating a FastAPI Application
# ============================================================================

# Create a FastAPI application instance
# title, description, and version appear in the automatic documentation
app = FastAPI(
    title="ML Model Deployment API",
    description="A beginner's guide to FastAPI for ML model serving",
    version="1.0.0"
)

# ============================================================================
# SECTION 2: Basic Routes with Type Hints
# ============================================================================

@app.get("/")
def home():
    """
    Home endpoint - root URL
    
    FastAPI automatically generates documentation from docstrings
    
    Returns:
        dict: Welcome message
    """
    return {"message": "Welcome to FastAPI ML Deployment!"}


@app.get("/info")
def api_info():
    """
    API information endpoint
    
    Returns:
        dict: API metadata
    """
    return {
        "name": "ML Deployment API",
        "version": "1.0.0",
        "framework": "FastAPI",
        "status": "operational"
    }


# ============================================================================
# SECTION 3: Path Parameters with Type Hints
# ============================================================================

@app.get("/users/{user_id}")
def get_user(user_id: int):
    """
    Get user by ID with automatic type validation
    
    FastAPI automatically:
    - Validates that user_id is an integer
    - Returns 422 error if validation fails
    - Converts the path parameter to int
    
    Args:
        user_id: User ID (automatically validated as integer)
        
    Returns:
        dict: User information
    """
    return {
        "user_id": user_id,
        "user_id_type": type(user_id).__name__,
        "message": f"Retrieved user {user_id}"
    }


@app.get("/greet/{name}")
def greet(name: str):
    """
    Personalized greeting endpoint
    
    Args:
        name: User's name (validated as string)
        
    Returns:
        dict: Greeting message
    """
    return {
        "greeting": f"Hello, {name}!",
        "name_length": len(name)
    }


# ============================================================================
# SECTION 4: Query Parameters with Validation
# ============================================================================

@app.get("/calculate")
def calculate(
    x: float = Query(..., description="First number"),
    y: float = Query(..., description="Second number"),
    operation: str = Query("add", description="Operation: add, subtract, multiply, divide")
):
    """
    Calculator endpoint with query parameters
    
    Query(...) allows adding descriptions and constraints
    ... means the parameter is required (no default)
    
    Args:
        x: First number
        y: Second number
        operation: Mathematical operation to perform
        
    Returns:
        dict: Calculation result
    """
    if operation == "add":
        result = x + y
    elif operation == "subtract":
        result = x - y
    elif operation == "multiply":
        result = x * y
    elif operation == "divide":
        if y == 0:
            raise HTTPException(status_code=400, detail="Cannot divide by zero")
        result = x / y
    else:
        raise HTTPException(status_code=400, detail="Invalid operation")
    
    return {
        "x": x,
        "y": y,
        "operation": operation,
        "result": result
    }


@app.get("/search")
def search(
    query: str,
    limit: int = Query(10, ge=1, le=100, description="Number of results (1-100)"),
    offset: int = Query(0, ge=0, description="Starting position")
):
    """
    Search endpoint with constrained query parameters
    
    ge = greater than or equal to
    le = less than or equal to
    
    Args:
        query: Search term
        limit: Maximum number of results (1-100)
        offset: Starting position
        
    Returns:
        dict: Search results
    """
    return {
        "query": query,
        "limit": limit,
        "offset": offset,
        "message": f"Searching for '{query}' with limit {limit} and offset {offset}"
    }


# ============================================================================
# SECTION 5: Pydantic Models for Request Bodies
# ============================================================================

class Item(BaseModel):
    """
    Pydantic model for item data
    
    Pydantic models provide:
    - Automatic data validation
    - Type checking
    - JSON schema generation
    - Clear API documentation
    """
    name: str = Field(..., description="Item name", min_length=1)
    description: Optional[str] = Field(None, description="Item description")
    price: float = Field(..., gt=0, description="Item price (must be positive)")
    quantity: int = Field(1, ge=0, description="Item quantity (non-negative)")
    
    class Config:
        """Configuration for Pydantic model"""
        schema_extra = {
            "example": {
                "name": "Machine Learning Model",
                "description": "Pre-trained image classifier",
                "price": 99.99,
                "quantity": 1
            }
        }


@app.post("/items")
def create_item(item: Item):
    """
    Create a new item using Pydantic model
    
    FastAPI automatically:
    - Parses JSON request body
    - Validates data against Item model
    - Returns 422 error if validation fails
    - Generates API documentation
    
    Args:
        item: Item data (automatically validated)
        
    Returns:
        dict: Created item with calculated total
    """
    total_price = item.price * item.quantity
    
    return {
        "item": item.dict(),
        "total_price": total_price,
        "message": "Item created successfully"
    }


# ============================================================================
# SECTION 6: Pydantic Model for ML Predictions
# ============================================================================

class PredictionInput(BaseModel):
    """
    Model for ML prediction input
    
    This demonstrates a typical structure for sending data to an ML model
    """
    feature1: float = Field(..., description="First feature value")
    feature2: float = Field(..., description="Second feature value")
    feature3: float = Field(..., description="Third feature value")
    
    @validator('feature1', 'feature2', 'feature3')
    def check_range(cls, v):
        """
        Custom validator to ensure features are in valid range
        
        Args:
            v: Feature value to validate
            
        Returns:
            float: Validated value
            
        Raises:
            ValueError: If value is out of range
        """
        if v < -10 or v > 10:
            raise ValueError('Features must be between -10 and 10')
        return v
    
    class Config:
        schema_extra = {
            "example": {
                "feature1": 2.5,
                "feature2": -1.3,
                "feature3": 0.8
            }
        }


class PredictionOutput(BaseModel):
    """
    Model for ML prediction output
    """
    prediction: float = Field(..., description="Model prediction")
    confidence: float = Field(..., ge=0, le=1, description="Prediction confidence (0-1)")
    model_version: str = Field(..., description="Model version used")


@app.post("/predict", response_model=PredictionOutput)
def predict(input_data: PredictionInput):
    """
    Mock ML prediction endpoint
    
    response_model ensures the output matches PredictionOutput schema
    
    Args:
        input_data: Input features for prediction
        
    Returns:
        PredictionOutput: Prediction result
    """
    # Mock prediction (in real scenario, this would call your ML model)
    # Simple linear combination for demonstration
    prediction = (
        input_data.feature1 * 0.5 + 
        input_data.feature2 * 0.3 + 
        input_data.feature3 * 0.2
    )
    
    # Mock confidence score
    confidence = 0.85
    
    return PredictionOutput(
        prediction=prediction,
        confidence=confidence,
        model_version="1.0.0"
    )


# ============================================================================
# SECTION 7: Batch Predictions
# ============================================================================

class BatchPredictionInput(BaseModel):
    """Model for batch prediction requests"""
    samples: List[PredictionInput] = Field(..., description="List of samples to predict")
    
    class Config:
        schema_extra = {
            "example": {
                "samples": [
                    {"feature1": 2.5, "feature2": -1.3, "feature3": 0.8},
                    {"feature1": 1.0, "feature2": 0.5, "feature3": -0.3}
                ]
            }
        }


@app.post("/predict/batch")
def predict_batch(batch_input: BatchPredictionInput):
    """
    Batch prediction endpoint
    
    Processes multiple samples in a single request
    
    Args:
        batch_input: Batch of input samples
        
    Returns:
        dict: List of predictions
    """
    predictions = []
    
    for sample in batch_input.samples:
        # Mock prediction for each sample
        prediction = (
            sample.feature1 * 0.5 + 
            sample.feature2 * 0.3 + 
            sample.feature3 * 0.2
        )
        
        predictions.append({
            "input": sample.dict(),
            "prediction": prediction,
            "confidence": 0.85
        })
    
    return {
        "num_samples": len(batch_input.samples),
        "predictions": predictions,
        "model_version": "1.0.0"
    }


# ============================================================================
# SECTION 8: Health Check Endpoint
# ============================================================================

@app.get("/health")
def health_check():
    """
    Health check endpoint
    
    Used by load balancers and monitoring systems to check if API is running
    
    Returns:
        dict: Health status
    """
    return {
        "status": "healthy",
        "version": "1.0.0",
        "message": "API is operational"
    }


# ============================================================================
# SECTION 9: Running the Application
# ============================================================================

if __name__ == "__main__":
    """
    Main execution block
    
    Uvicorn is an ASGI server for running FastAPI applications
    """
    
    print("=" * 70)
    print("FastAPI Server Starting...")
    print("=" * 70)
    print("\nAPI Documentation available at:")
    print("  Swagger UI:  http://127.0.0.1:8000/docs")
    print("  ReDoc:       http://127.0.0.1:8000/redoc")
    print("  OpenAPI:     http://127.0.0.1:8000/openapi.json")
    print("\nAvailable Endpoints:")
    print("  GET  /              - Home page")
    print("  GET  /info          - API information")
    print("  GET  /users/{id}    - Get user by ID")
    print("  GET  /greet/{name}  - Personalized greeting")
    print("  GET  /calculate     - Calculator with query params")
    print("  GET  /search        - Search with constraints")
    print("  POST /items         - Create item")
    print("  POST /predict       - Single prediction")
    print("  POST /predict/batch - Batch predictions")
    print("  GET  /health        - Health check")
    print("\n" + "=" * 70)
    print("Server running at: http://127.0.0.1:8000")
    print("Press Ctrl+C to stop the server")
    print("=" * 70 + "\n")
    
    # Start uvicorn server
    # reload=True enables auto-reload during development
    uvicorn.run(
        "02_fastapi_basics_beginner:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )


# ============================================================================
# TESTING THE API
# ============================================================================
"""
To test this FastAPI application:

1. Interactive Documentation:
   Open browser and go to: http://127.0.0.1:8000/docs
   You can test all endpoints directly from the browser!

2. Python requests:
   import requests
   
   # Single prediction
   data = {
       "feature1": 2.5,
       "feature2": -1.3,
       "feature3": 0.8
   }
   response = requests.post('http://127.0.0.1:8000/predict', json=data)
   print(response.json())
   
   # Batch prediction
   batch_data = {
       "samples": [
           {"feature1": 2.5, "feature2": -1.3, "feature3": 0.8},
           {"feature1": 1.0, "feature2": 0.5, "feature3": -0.3}
       ]
   }
   response = requests.post('http://127.0.0.1:8000/predict/batch', json=batch_data)
   print(response.json())

3. cURL:
   # Single prediction
   curl -X POST "http://127.0.0.1:8000/predict" \
        -H "Content-Type: application/json" \
        -d '{"feature1": 2.5, "feature2": -1.3, "feature3": 0.8}'
"""

# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. FastAPI Advantages:
   - Automatic data validation with Pydantic
   - Built-in API documentation (Swagger/ReDoc)
   - Type hints for better code quality
   - High performance (async support)
   - Less boilerplate code than Flask

2. Pydantic Models:
   - Define data structures with type hints
   - Automatic validation and parsing
   - Custom validators with @validator
   - JSON schema generation

3. Query Parameters:
   - Use Query() for validation and documentation
   - Add constraints (ge, le, min_length, etc.)
   - Provide descriptions for documentation

4. Response Models:
   - Use response_model to specify output schema
   - Ensures consistency in API responses
   - Automatic documentation of response format

5. Interactive Documentation:
   - /docs provides Swagger UI
   - /redoc provides ReDoc interface
   - Test endpoints directly from browser
   - No additional setup required

6. FastAPI vs Flask:
   - FastAPI: Type hints, auto-validation, faster
   - Flask: More flexible, simpler for basic needs
   - Both are excellent for ML model deployment
"""
