"""
ML Model Deployment - Lesson 03: Serving Scikit-learn Models (BEGINNER)

This module demonstrates how to deploy a simple machine learning model
using Flask. We'll train a basic model and serve it via a REST API.

Topics covered:
- Training a simple ML model (Logistic Regression)
- Saving models with pickle/joblib
- Loading models in Flask application
- Creating prediction endpoints
- Handling input data for predictions

Learning objectives:
- Understand the ML model deployment workflow
- Save and load trained models
- Create prediction APIs
- Handle real-world prediction requests
"""

import pickle
import numpy as np
from flask import Flask, request, jsonify
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
import os

# ============================================================================
# SECTION 1: Training and Saving the Model
# ============================================================================

def train_and_save_model(model_path='iris_model.pkl'):
    """
    Train a logistic regression model on the Iris dataset and save it
    
    The Iris dataset contains measurements of iris flowers:
    - 4 features: sepal length, sepal width, petal length, petal width
    - 3 classes: setosa, versicolor, virginica
    
    Args:
        model_path: Path where the model will be saved
        
    Returns:
        tuple: Trained model and test accuracy
    """
    print("=" * 60)
    print("Training Iris Classification Model")
    print("=" * 60)
    
    # Load the Iris dataset
    # This is a classic dataset included in scikit-learn
    iris = load_iris()
    X = iris.data  # Features: sepal/petal measurements
    y = iris.target  # Target: species (0, 1, or 2)
    
    print(f"\nDataset shape: {X.shape}")
    print(f"Number of samples: {X.shape[0]}")
    print(f"Number of features: {X.shape[1]}")
    print(f"Number of classes: {len(np.unique(y))}")
    print(f"Feature names: {iris.feature_names}")
    print(f"Target names: {iris.target_names}")
    
    # Split data into training and testing sets
    # 80% for training, 20% for testing
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    print(f"\nTraining set size: {X_train.shape[0]}")
    print(f"Testing set size: {X_test.shape[0]}")
    
    # Create and train the logistic regression model
    # max_iter: maximum number of iterations for convergence
    # random_state: ensures reproducibility
    model = LogisticRegression(max_iter=200, random_state=42)
    
    print("\nTraining model...")
    model.fit(X_train, y_train)
    
    # Evaluate the model
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"Model trained successfully!")
    print(f"Test accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Save the model using pickle
    # Pickle serializes Python objects to bytes
    with open(model_path, 'wb') as f:
        pickle.dump(model, f)
    
    print(f"\nModel saved to: {model_path}")
    print("=" * 60 + "\n")
    
    return model, accuracy


def load_model(model_path='iris_model.pkl'):
    """
    Load a trained model from disk
    
    Args:
        model_path: Path to the saved model file
        
    Returns:
        Trained model object
        
    Raises:
        FileNotFoundError: If model file doesn't exist
    """
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Model file not found: {model_path}")
    
    # Load the model from pickle file
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    
    print(f"Model loaded from: {model_path}")
    return model


# ============================================================================
# SECTION 2: Creating the Flask Application
# ============================================================================

# Create Flask app
app = Flask(__name__)

# Global variable to store the loaded model
# This is loaded once when the server starts
MODEL = None
MODEL_PATH = 'iris_model.pkl'

# Class names for predictions
CLASS_NAMES = ['setosa', 'versicolor', 'virginica']

# Feature names for validation
FEATURE_NAMES = [
    'sepal_length',
    'sepal_width',
    'petal_length',
    'petal_width'
]


@app.before_first_request
def initialize():
    """
    Initialize the model before handling first request
    
    This decorator ensures the model is loaded only once
    when the first request is received
    """
    global MODEL
    
    # Check if model exists, if not, train it
    if not os.path.exists(MODEL_PATH):
        print("Model not found. Training new model...")
        train_and_save_model(MODEL_PATH)
    
    # Load the model
    MODEL = load_model(MODEL_PATH)
    print("Model ready for predictions!")


# ============================================================================
# SECTION 3: Basic Endpoints
# ============================================================================

@app.route('/')
def home():
    """
    Home endpoint with API information
    
    Returns:
        dict: API information
    """
    return jsonify({
        'name': 'Iris Classification API',
        'version': '1.0.0',
        'model': 'Logistic Regression',
        'dataset': 'Iris',
        'endpoints': {
            '/': 'API information',
            '/health': 'Health check',
            '/model/info': 'Model information',
            '/predict': 'Single prediction (POST)',
            '/predict/batch': 'Batch predictions (POST)'
        }
    })


@app.route('/health')
def health():
    """
    Health check endpoint
    
    Returns:
        dict: Health status and model availability
    """
    return jsonify({
        'status': 'healthy',
        'model_loaded': MODEL is not None,
        'message': 'API is operational'
    })


@app.route('/model/info')
def model_info():
    """
    Get information about the model
    
    Returns:
        dict: Model metadata
    """
    if MODEL is None:
        return jsonify({'error': 'Model not loaded'}), 500
    
    return jsonify({
        'model_type': type(MODEL).__name__,
        'classes': CLASS_NAMES,
        'features': FEATURE_NAMES,
        'num_features': len(FEATURE_NAMES),
        'num_classes': len(CLASS_NAMES)
    })


# ============================================================================
# SECTION 4: Prediction Endpoints
# ============================================================================

@app.route('/predict', methods=['POST'])
def predict():
    """
    Single prediction endpoint
    
    Expects JSON with feature values:
    {
        "sepal_length": 5.1,
        "sepal_width": 3.5,
        "petal_length": 1.4,
        "petal_width": 0.2
    }
    
    Returns:
        dict: Prediction result with class and probabilities
    """
    if MODEL is None:
        return jsonify({'error': 'Model not loaded'}), 500
    
    try:
        # Get JSON data from request
        data = request.get_json()
        
        # Validate that all required features are present
        missing_features = [f for f in FEATURE_NAMES if f not in data]
        if missing_features:
            return jsonify({
                'error': 'Missing features',
                'missing': missing_features,
                'required': FEATURE_NAMES
            }), 400
        
        # Extract features in the correct order
        # This is crucial - features must be in the same order as training
        features = [data[f] for f in FEATURE_NAMES]
        
        # Convert to numpy array with shape (1, 4)
        # (1, 4) means 1 sample with 4 features
        X = np.array(features).reshape(1, -1)
        
        # Make prediction
        # predict() returns class label (0, 1, or 2)
        prediction = MODEL.predict(X)[0]
        
        # Get prediction probabilities for all classes
        # predict_proba() returns probability for each class
        probabilities = MODEL.predict_proba(X)[0]
        
        # Get the predicted class name
        predicted_class = CLASS_NAMES[prediction]
        
        # Create probability dictionary
        class_probabilities = {
            CLASS_NAMES[i]: float(probabilities[i]) 
            for i in range(len(CLASS_NAMES))
        }
        
        # Determine confidence (max probability)
        confidence = float(max(probabilities))
        
        # Return prediction result
        return jsonify({
            'prediction': predicted_class,
            'prediction_id': int(prediction),
            'confidence': confidence,
            'probabilities': class_probabilities,
            'input_features': {
                FEATURE_NAMES[i]: features[i] 
                for i in range(len(FEATURE_NAMES))
            }
        })
        
    except ValueError as e:
        # Handle invalid feature values (e.g., non-numeric)
        return jsonify({
            'error': 'Invalid feature values',
            'message': str(e)
        }), 400
    
    except Exception as e:
        # Handle unexpected errors
        return jsonify({
            'error': 'Prediction failed',
            'message': str(e)
        }), 500


@app.route('/predict/batch', methods=['POST'])
def predict_batch():
    """
    Batch prediction endpoint
    
    Expects JSON with list of samples:
    {
        "samples": [
            {
                "sepal_length": 5.1,
                "sepal_width": 3.5,
                "petal_length": 1.4,
                "petal_width": 0.2
            },
            {
                "sepal_length": 6.2,
                "sepal_width": 2.8,
                "petal_length": 4.8,
                "petal_width": 1.8
            }
        ]
    }
    
    Returns:
        dict: List of predictions for all samples
    """
    if MODEL is None:
        return jsonify({'error': 'Model not loaded'}), 500
    
    try:
        # Get JSON data
        data = request.get_json()
        
        # Validate that 'samples' key exists
        if 'samples' not in data:
            return jsonify({
                'error': 'Missing "samples" key',
                'message': 'Request must contain "samples" array'
            }), 400
        
        samples = data['samples']
        
        # Validate that samples is a list
        if not isinstance(samples, list):
            return jsonify({
                'error': 'Invalid format',
                'message': '"samples" must be an array'
            }), 400
        
        # Process each sample
        predictions = []
        
        for idx, sample in enumerate(samples):
            # Validate features for this sample
            missing = [f for f in FEATURE_NAMES if f not in sample]
            if missing:
                return jsonify({
                    'error': f'Missing features in sample {idx}',
                    'missing': missing,
                    'sample_index': idx
                }), 400
            
            # Extract features
            features = [sample[f] for f in FEATURE_NAMES]
            X = np.array(features).reshape(1, -1)
            
            # Make prediction
            pred = MODEL.predict(X)[0]
            proba = MODEL.predict_proba(X)[0]
            
            # Store result
            predictions.append({
                'sample_index': idx,
                'prediction': CLASS_NAMES[pred],
                'prediction_id': int(pred),
                'confidence': float(max(proba)),
                'probabilities': {
                    CLASS_NAMES[i]: float(proba[i]) 
                    for i in range(len(CLASS_NAMES))
                }
            })
        
        return jsonify({
            'num_samples': len(samples),
            'predictions': predictions
        })
        
    except Exception as e:
        return jsonify({
            'error': 'Batch prediction failed',
            'message': str(e)
        }), 500


# ============================================================================
# SECTION 5: Running the Application
# ============================================================================

if __name__ == '__main__':
    """
    Main execution block
    """
    
    print("\n" + "=" * 70)
    print("Iris Classification API")
    print("=" * 70)
    print("\nStarting server...")
    print("\nEndpoints:")
    print("  GET  /              - API information")
    print("  GET  /health        - Health check")
    print("  GET  /model/info    - Model information")
    print("  POST /predict       - Single prediction")
    print("  POST /predict/batch - Batch predictions")
    print("\nExample prediction request:")
    print('  curl -X POST http://127.0.0.1:5000/predict \\')
    print('       -H "Content-Type: application/json" \\')
    print('       -d \'{"sepal_length": 5.1, "sepal_width": 3.5,')
    print('            "petal_length": 1.4, "petal_width": 0.2}\'')
    print("\n" + "=" * 70)
    print("Server: http://127.0.0.1:5000")
    print("Press Ctrl+C to stop")
    print("=" * 70 + "\n")
    
    # Run the Flask application
    app.run(debug=True, host='0.0.0.0', port=5000)


# ============================================================================
# TESTING THE API
# ============================================================================
"""
Testing examples:

1. Using Python requests:
   
   import requests
   
   # Single prediction
   url = "http://127.0.0.1:5000/predict"
   data = {
       "sepal_length": 5.1,
       "sepal_width": 3.5,
       "petal_length": 1.4,
       "petal_width": 0.2
   }
   response = requests.post(url, json=data)
   print(response.json())
   
   # Batch prediction
   url = "http://127.0.0.1:5000/predict/batch"
   data = {
       "samples": [
           {"sepal_length": 5.1, "sepal_width": 3.5, 
            "petal_length": 1.4, "petal_width": 0.2},
           {"sepal_length": 6.2, "sepal_width": 2.8, 
            "petal_length": 4.8, "petal_width": 1.8}
       ]
   }
   response = requests.post(url, json=data)
   print(response.json())

2. Using cURL:
   
   # Single prediction
   curl -X POST http://127.0.0.1:5000/predict \
        -H "Content-Type: application/json" \
        -d '{"sepal_length": 5.1, "sepal_width": 3.5, 
             "petal_length": 1.4, "petal_width": 0.2}'
"""

# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. Model Lifecycle:
   - Train model on historical data
   - Save model to disk (pickle/joblib)
   - Load model in API application
   - Use model for predictions

2. Model Persistence:
   - pickle: Standard Python serialization
   - joblib: Better for large numpy arrays
   - Save model parameters, not training code
   - Version your models!

3. Prediction API Design:
   - Single prediction: /predict
   - Batch prediction: /predict/batch
   - Always validate input data
   - Return confidence scores

4. Error Handling:
   - Validate feature presence
   - Check feature types/values
   - Handle model loading errors
   - Return appropriate status codes

5. Best Practices:
   - Load model once at startup
   - Validate inputs thoroughly
   - Return structured responses
   - Include confidence/probabilities
   - Log predictions for monitoring

6. Important Considerations:
   - Feature order matters!
   - Feature scaling (if used in training)
   - Model versioning
   - Performance monitoring
   - Error logging
"""
