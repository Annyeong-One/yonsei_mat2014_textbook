"""
ML Model Deployment - Lesson 04: Serving PyTorch Models (INTERMEDIATE)

This module demonstrates how to deploy PyTorch deep learning models via API.
PyTorch models require special handling compared to scikit-learn models.

Topics covered:
- Creating and training a PyTorch neural network
- Saving PyTorch models (state_dict vs entire model)
- Loading PyTorch models for inference
- Preprocessing input data for neural networks
- Serving PyTorch models with FastAPI
- Handling tensor conversions

Learning objectives:
- Understand PyTorch model serialization
- Implement proper inference mode (model.eval())
- Handle device management (CPU/GPU)
- Preprocess data for neural networks
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, validator
from typing import List
import uvicorn

# ============================================================================
# SECTION 1: Define PyTorch Neural Network
# ============================================================================

class IrisNet(nn.Module):
    """
    Simple feedforward neural network for Iris classification
    
    Architecture:
    - Input layer: 4 features
    - Hidden layer 1: 16 neurons (ReLU activation)
    - Hidden layer 2: 8 neurons (ReLU activation)
    - Output layer: 3 classes (Softmax)
    """
    
    def __init__(self, input_size=4, hidden_size1=16, hidden_size2=8, num_classes=3):
        """
        Initialize the neural network
        
        Args:
            input_size: Number of input features (4 for Iris)
            hidden_size1: Neurons in first hidden layer
            hidden_size2: Neurons in second hidden layer
            num_classes: Number of output classes (3 for Iris)
        """
        super(IrisNet, self).__init__()
        
        # Define network layers
        # nn.Linear creates fully connected layer: y = xW^T + b
        self.fc1 = nn.Linear(input_size, hidden_size1)
        self.relu1 = nn.ReLU()  # ReLU activation: max(0, x)
        
        self.fc2 = nn.Linear(hidden_size1, hidden_size2)
        self.relu2 = nn.ReLU()
        
        self.fc3 = nn.Linear(hidden_size2, num_classes)
        # No softmax here - CrossEntropyLoss includes it
        
    def forward(self, x):
        """
        Forward pass through the network
        
        Args:
            x: Input tensor of shape (batch_size, input_size)
            
        Returns:
            Output tensor of shape (batch_size, num_classes)
        """
        # Pass through first hidden layer
        x = self.fc1(x)
        x = self.relu1(x)
        
        # Pass through second hidden layer
        x = self.fc2(x)
        x = self.relu2(x)
        
        # Output layer
        x = self.fc3(x)
        
        return x


# ============================================================================
# SECTION 2: Training and Saving PyTorch Model
# ============================================================================

def train_pytorch_model(model_path='iris_pytorch_model.pth', epochs=100):
    """
    Train a PyTorch neural network on Iris dataset
    
    Args:
        model_path: Path to save the trained model
        epochs: Number of training epochs
        
    Returns:
        Trained model
    """
    print("=" * 70)
    print("Training PyTorch Neural Network")
    print("=" * 70)
    
    # Load Iris dataset
    from sklearn.datasets import load_iris
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import StandardScaler
    
    iris = load_iris()
    X, y = iris.data, iris.target
    
    # Split data
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Feature scaling is important for neural networks
    # StandardScaler: (x - mean) / std
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)
    
    # Convert to PyTorch tensors
    # float32 is standard for neural networks
    X_train_tensor = torch.FloatTensor(X_train_scaled)
    y_train_tensor = torch.LongTensor(y_train)  # LongTensor for class indices
    X_test_tensor = torch.FloatTensor(X_test_scaled)
    y_test_tensor = torch.LongTensor(y_test)
    
    # Create DataLoader for batching
    train_dataset = TensorDataset(X_train_tensor, y_train_tensor)
    train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True)
    
    print(f"Training samples: {len(X_train)}")
    print(f"Testing samples: {len(X_test)}")
    print(f"Feature scaling applied: StandardScaler")
    
    # Initialize model
    model = IrisNet()
    
    # Define loss function and optimizer
    criterion = nn.CrossEntropyLoss()  # For multi-class classification
    optimizer = optim.Adam(model.parameters(), lr=0.01)
    
    print(f"\nModel Architecture:")
    print(model)
    print(f"\nTraining for {epochs} epochs...")
    
    # Training loop
    model.train()  # Set model to training mode
    
    for epoch in range(epochs):
        epoch_loss = 0.0
        
        for batch_X, batch_y in train_loader:
            # Zero gradients from previous iteration
            optimizer.zero_grad()
            
            # Forward pass
            outputs = model(batch_X)
            
            # Compute loss
            loss = criterion(outputs, batch_y)
            
            # Backward pass
            loss.backward()
            
            # Update weights
            optimizer.step()
            
            epoch_loss += loss.item()
        
        # Print progress every 20 epochs
        if (epoch + 1) % 20 == 0:
            avg_loss = epoch_loss / len(train_loader)
            print(f"Epoch [{epoch+1}/{epochs}], Loss: {avg_loss:.4f}")
    
    # Evaluate model
    model.eval()  # Set model to evaluation mode
    with torch.no_grad():  # Disable gradient computation
        outputs = model(X_test_tensor)
        _, predicted = torch.max(outputs, 1)  # Get class with highest score
        accuracy = (predicted == y_test_tensor).sum().item() / len(y_test)
    
    print(f"\nTest Accuracy: {accuracy:.4f} ({accuracy*100:.2f}%)")
    
    # Save model and scaler
    # Method 1: Save only state_dict (recommended)
    torch.save({
        'model_state_dict': model.state_dict(),
        'scaler_mean': scaler.mean_,
        'scaler_scale': scaler.scale_
    }, model_path)
    
    print(f"Model saved to: {model_path}")
    print("=" * 70 + "\n")
    
    return model, scaler


def load_pytorch_model(model_path='iris_pytorch_model.pth'):
    """
    Load a trained PyTorch model
    
    Args:
        model_path: Path to saved model
        
    Returns:
        tuple: (model, scaler_params)
    """
    # Initialize model architecture
    model = IrisNet()
    
    # Load checkpoint
    checkpoint = torch.load(model_path, map_location='cpu')
    
    # Load model weights
    model.load_state_dict(checkpoint['model_state_dict'])
    
    # Set to evaluation mode
    model.eval()
    
    # Extract scaler parameters
    scaler_params = {
        'mean': checkpoint['scaler_mean'],
        'scale': checkpoint['scaler_scale']
    }
    
    print(f"Model loaded from: {model_path}")
    return model, scaler_params


# ============================================================================
# SECTION 3: FastAPI Application
# ============================================================================

app = FastAPI(
    title="PyTorch Iris Classification API",
    description="Serve PyTorch neural network for Iris classification",
    version="1.0.0"
)

# Global variables
MODEL = None
SCALER_PARAMS = None
CLASS_NAMES = ['setosa', 'versicolor', 'virginica']


# ============================================================================
# SECTION 4: Pydantic Models
# ============================================================================

class IrisFeatures(BaseModel):
    """Input model for Iris features"""
    sepal_length: float = Field(..., ge=0, le=10, description="Sepal length (cm)")
    sepal_width: float = Field(..., ge=0, le=10, description="Sepal width (cm)")
    petal_length: float = Field(..., ge=0, le=10, description="Petal length (cm)")
    petal_width: float = Field(..., ge=0, le=10, description="Petal width (cm)")
    
    class Config:
        schema_extra = {
            "example": {
                "sepal_length": 5.1,
                "sepal_width": 3.5,
                "petal_length": 1.4,
                "petal_width": 0.2
            }
        }


class PredictionResponse(BaseModel):
    """Output model for predictions"""
    prediction: str = Field(..., description="Predicted class")
    prediction_id: int = Field(..., description="Class ID (0-2)")
    confidence: float = Field(..., ge=0, le=1, description="Prediction confidence")
    probabilities: dict = Field(..., description="Probabilities for all classes")


class BatchInput(BaseModel):
    """Input model for batch predictions"""
    samples: List[IrisFeatures]


# ============================================================================
# SECTION 5: Helper Functions
# ============================================================================

def preprocess_features(features: IrisFeatures) -> torch.Tensor:
    """
    Preprocess input features for neural network
    
    Steps:
    1. Convert to numpy array
    2. Apply feature scaling
    3. Convert to PyTorch tensor
    
    Args:
        features: Input features
        
    Returns:
        Preprocessed tensor of shape (1, 4)
    """
    # Extract features as array
    feature_array = np.array([
        features.sepal_length,
        features.sepal_width,
        features.petal_length,
        features.petal_width
    ])
    
    # Apply standardization: (x - mean) / scale
    scaled_features = (feature_array - SCALER_PARAMS['mean']) / SCALER_PARAMS['scale']
    
    # Convert to PyTorch tensor
    tensor = torch.FloatTensor(scaled_features).unsqueeze(0)  # Add batch dimension
    
    return tensor


def predict_with_model(features: IrisFeatures):
    """
    Make prediction using PyTorch model
    
    Args:
        features: Input features
        
    Returns:
        dict: Prediction result
    """
    # Preprocess input
    input_tensor = preprocess_features(features)
    
    # Make prediction
    with torch.no_grad():  # Disable gradient computation for inference
        outputs = MODEL(input_tensor)
        
        # Apply softmax to get probabilities
        probabilities = torch.softmax(outputs, dim=1)[0]
        
        # Get predicted class
        predicted_class = torch.argmax(probabilities).item()
        confidence = probabilities[predicted_class].item()
    
    # Create probability dictionary
    prob_dict = {
        CLASS_NAMES[i]: float(probabilities[i])
        for i in range(len(CLASS_NAMES))
    }
    
    return {
        'prediction': CLASS_NAMES[predicted_class],
        'prediction_id': predicted_class,
        'confidence': confidence,
        'probabilities': prob_dict
    }


# ============================================================================
# SECTION 6: API Endpoints
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Initialize model on startup"""
    global MODEL, SCALER_PARAMS
    
    import os
    model_path = 'iris_pytorch_model.pth'
    
    # Train model if it doesn't exist
    if not os.path.exists(model_path):
        print("Model not found. Training new model...")
        train_pytorch_model(model_path)
    
    # Load model
    MODEL, SCALER_PARAMS = load_pytorch_model(model_path)
    print("PyTorch model loaded and ready!")


@app.get("/")
def home():
    """Home endpoint"""
    return {
        "name": "PyTorch Iris Classification API",
        "model": "Neural Network (PyTorch)",
        "framework": "FastAPI",
        "version": "1.0.0"
    }


@app.get("/health")
def health():
    """Health check"""
    return {
        "status": "healthy",
        "model_loaded": MODEL is not None,
        "model_type": "PyTorch Neural Network"
    }


@app.post("/predict", response_model=PredictionResponse)
def predict(features: IrisFeatures):
    """
    Single prediction endpoint
    
    Args:
        features: Input features
        
    Returns:
        Prediction result
    """
    if MODEL is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    try:
        result = predict_with_model(features)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@app.post("/predict/batch")
def predict_batch(batch: BatchInput):
    """
    Batch prediction endpoint
    
    Args:
        batch: Batch of input samples
        
    Returns:
        List of predictions
    """
    if MODEL is None:
        raise HTTPException(status_code=500, detail="Model not loaded")
    
    try:
        predictions = []
        for idx, features in enumerate(batch.samples):
            result = predict_with_model(features)
            result['sample_index'] = idx
            predictions.append(result)
        
        return {
            "num_samples": len(batch.samples),
            "predictions": predictions
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {str(e)}")


# ============================================================================
# SECTION 7: Running the Application
# ============================================================================

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("PyTorch Model Serving API")
    print("=" * 70)
    print("\nAPI Documentation: http://127.0.0.1:8000/docs")
    print("=" * 70 + "\n")
    
    uvicorn.run("04_pytorch_model_serving_intermediate:app", 
                host="0.0.0.0", port=8000, reload=True)


# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. PyTorch Model Saving:
   - state_dict: Saves only weights (recommended)
   - Entire model: Saves architecture + weights (less flexible)
   - Always save preprocessing parameters (scaler)

2. Inference Mode:
   - model.eval(): Disables dropout, batch norm updates
   - torch.no_grad(): Disables gradient computation
   - Essential for production serving

3. Preprocessing:
   - Feature scaling must match training
   - Save scaler parameters with model
   - Apply same transformations at inference

4. Tensor Handling:
   - Convert numpy → torch.Tensor
   - Add batch dimension with unsqueeze(0)
   - Convert back to Python types for JSON

5. PyTorch Best Practices:
   - Load model once at startup
   - Use torch.no_grad() for inference
   - Handle device placement (CPU/GPU)
   - Version model checkpoints

6. Neural Network Considerations:
   - Feature scaling is critical
   - Softmax for probability interpretation
   - torch.argmax for predicted class
   - Return confidence scores
"""
