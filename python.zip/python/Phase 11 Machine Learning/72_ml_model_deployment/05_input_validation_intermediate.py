"""
ML Model Deployment - Lesson 05: Input Validation and Preprocessing (INTERMEDIATE)

This module focuses on robust input validation and preprocessing for ML APIs.
Proper validation prevents errors, security issues, and poor predictions.

Topics covered:
- Comprehensive input validation strategies
- Data type validation and conversion
- Range and constraint checking
- Missing value handling
- Feature engineering in production
- Custom Pydantic validators
- Error handling and user feedback

Learning objectives:
- Implement multi-layer validation
- Handle edge cases gracefully
- Provide clear error messages
- Maintain data quality in production
"""

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field, validator, root_validator
from typing import List, Optional, Dict, Any
import numpy as np
from enum import Enum
import re
import uvicorn

# ============================================================================
# SECTION 1: Validation Levels
# ============================================================================

"""
Multi-layer validation approach:

Layer 1: Schema Validation (Pydantic)
- Data types
- Required fields
- Basic constraints

Layer 2: Business Logic Validation
- Value ranges
- Relationships between fields
- Domain-specific rules

Layer 3: Model-Specific Validation
- Feature distributions
- Outlier detection
- Data drift detection

Layer 4: Post-Processing Validation
- Prediction sanity checks
- Confidence thresholds
- Output constraints
"""

# ============================================================================
# SECTION 2: Define Validation Enums and Constants
# ============================================================================

class ModelVersion(str, Enum):
    """Allowed model versions"""
    V1 = "v1"
    V2 = "v2"
    LATEST = "latest"


class PredictionMode(str, Enum):
    """Prediction modes"""
    FAST = "fast"
    ACCURATE = "accurate"
    ENSEMBLE = "ensemble"


# Validation constants
MIN_FEATURE_VALUE = -10.0
MAX_FEATURE_VALUE = 10.0
REQUIRED_FEATURES = ['feature_1', 'feature_2', 'feature_3', 'feature_4']

# ============================================================================
# SECTION 3: Custom Validators and Helpers
# ============================================================================

def is_valid_email(email: str) -> bool:
    """
    Validate email format
    
    Args:
        email: Email address to validate
        
    Returns:
        bool: True if valid
    """
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def check_feature_distribution(features: List[float], feature_name: str) -> None:
    """
    Check if feature values match expected distribution
    
    In production, you might compare against training statistics
    
    Args:
        features: List of feature values
        feature_name: Name of the feature
        
    Raises:
        ValueError: If distribution is anomalous
    """
    if not features:
        return
    
    mean = np.mean(features)
    std = np.std(features)
    
    # Example: Check if mean is within expected range
    # In real scenario, use training statistics
    if abs(mean) > 5.0:
        raise ValueError(
            f"{feature_name} mean ({mean:.2f}) is outside expected range"
        )


def detect_outliers(values: List[float], threshold: float = 3.0) -> List[int]:
    """
    Detect outliers using z-score method
    
    Args:
        values: List of values
        threshold: Z-score threshold (default: 3.0)
        
    Returns:
        List of outlier indices
    """
    if len(values) < 2:
        return []
    
    mean = np.mean(values)
    std = np.std(values)
    
    if std == 0:
        return []
    
    z_scores = [(v - mean) / std for v in values]
    outliers = [i for i, z in enumerate(z_scores) if abs(z) > threshold]
    
    return outliers


# ============================================================================
# SECTION 4: Pydantic Models with Advanced Validation
# ============================================================================

class UserInfo(BaseModel):
    """
    User information with validation
    """
    user_id: str = Field(..., min_length=3, max_length=50, 
                         description="Unique user identifier")
    email: Optional[str] = Field(None, description="User email")
    age: Optional[int] = Field(None, ge=0, le=120, description="User age")
    
    @validator('user_id')
    def validate_user_id(cls, v):
        """
        Custom validator for user_id
        
        Args:
            v: Value to validate
            
        Returns:
            Validated value
            
        Raises:
            ValueError: If validation fails
        """
        # Must be alphanumeric with optional underscores/hyphens
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError(
                'user_id must contain only alphanumeric characters, '
                'underscores, and hyphens'
            )
        return v
    
    @validator('email')
    def validate_email(cls, v):
        """Validate email format"""
        if v is not None and not is_valid_email(v):
            raise ValueError('Invalid email format')
        return v
    
    class Config:
        schema_extra = {
            "example": {
                "user_id": "user_12345",
                "email": "user@example.com",
                "age": 30
            }
        }


class FeatureInput(BaseModel):
    """
    Feature input with comprehensive validation
    """
    feature_1: float = Field(..., ge=MIN_FEATURE_VALUE, le=MAX_FEATURE_VALUE,
                            description=f"Feature 1 ({MIN_FEATURE_VALUE} to {MAX_FEATURE_VALUE})")
    feature_2: float = Field(..., ge=MIN_FEATURE_VALUE, le=MAX_FEATURE_VALUE,
                            description=f"Feature 2 ({MIN_FEATURE_VALUE} to {MAX_FEATURE_VALUE})")
    feature_3: float = Field(..., ge=MIN_FEATURE_VALUE, le=MAX_FEATURE_VALUE,
                            description=f"Feature 3 ({MIN_FEATURE_VALUE} to {MAX_FEATURE_VALUE})")
    feature_4: float = Field(..., ge=MIN_FEATURE_VALUE, le=MAX_FEATURE_VALUE,
                            description=f"Feature 4 ({MIN_FEATURE_VALUE} to {MAX_FEATURE_VALUE})")
    
    # Optional metadata
    timestamp: Optional[str] = Field(None, description="Request timestamp")
    source: Optional[str] = Field(None, description="Data source")
    
    @root_validator
    def check_feature_relationships(cls, values):
        """
        Validate relationships between features
        
        This is a root validator that has access to all fields
        
        Args:
            values: Dictionary of all field values
            
        Returns:
            Validated values
            
        Raises:
            ValueError: If validation fails
        """
        f1 = values.get('feature_1')
        f2 = values.get('feature_2')
        f3 = values.get('feature_3')
        f4 = values.get('feature_4')
        
        # Example business rule: feature_1 + feature_2 should be positive
        # when feature_3 is positive
        if f3 > 0 and (f1 + f2) < 0:
            raise ValueError(
                'When feature_3 is positive, sum of feature_1 and feature_2 '
                'must be non-negative'
            )
        
        # Example: Magnitude check
        magnitude = np.sqrt(f1**2 + f2**2 + f3**2 + f4**2)
        if magnitude > 15.0:
            raise ValueError(
                f'Feature magnitude ({magnitude:.2f}) exceeds threshold (15.0)'
            )
        
        return values
    
    def to_array(self) -> np.ndarray:
        """Convert features to numpy array"""
        return np.array([
            self.feature_1,
            self.feature_2,
            self.feature_3,
            self.feature_4
        ])
    
    class Config:
        schema_extra = {
            "example": {
                "feature_1": 2.5,
                "feature_2": -1.3,
                "feature_3": 0.8,
                "feature_4": 1.2,
                "timestamp": "2024-01-15T10:30:00Z",
                "source": "web_app"
            }
        }


class PredictionRequest(BaseModel):
    """
    Complete prediction request with user info and features
    """
    user_info: UserInfo
    features: FeatureInput
    model_version: ModelVersion = Field(ModelVersion.LATEST, 
                                       description="Model version to use")
    mode: PredictionMode = Field(PredictionMode.ACCURATE,
                                 description="Prediction mode")
    return_probabilities: bool = Field(True, 
                                      description="Return class probabilities")
    
    class Config:
        schema_extra = {
            "example": {
                "user_info": {
                    "user_id": "user_12345",
                    "email": "user@example.com",
                    "age": 30
                },
                "features": {
                    "feature_1": 2.5,
                    "feature_2": -1.3,
                    "feature_3": 0.8,
                    "feature_4": 1.2
                },
                "model_version": "latest",
                "mode": "accurate",
                "return_probabilities": True
            }
        }


class BatchPredictionRequest(BaseModel):
    """
    Batch prediction request with validation
    """
    user_info: UserInfo
    samples: List[FeatureInput] = Field(..., min_items=1, max_items=100,
                                       description="Batch samples (1-100)")
    model_version: ModelVersion = ModelVersion.LATEST
    mode: PredictionMode = PredictionMode.FAST
    
    @validator('samples')
    def check_batch_consistency(cls, v):
        """
        Validate batch consistency
        
        Args:
            v: List of samples
            
        Returns:
            Validated samples
        """
        if not v:
            raise ValueError('Batch must contain at least one sample')
        
        # Check for outliers in the batch
        all_features = [
            [s.feature_1, s.feature_2, s.feature_3, s.feature_4]
            for s in v
        ]
        
        # Check each feature across batch
        for i in range(4):
            feature_values = [f[i] for f in all_features]
            outlier_indices = detect_outliers(feature_values)
            
            if outlier_indices:
                # Warning: In production, might log this instead of raising
                pass  # For now, we allow outliers
        
        return v
    
    class Config:
        schema_extra = {
            "example": {
                "user_info": {
                    "user_id": "user_12345"
                },
                "samples": [
                    {
                        "feature_1": 2.5,
                        "feature_2": -1.3,
                        "feature_3": 0.8,
                        "feature_4": 1.2
                    },
                    {
                        "feature_1": 1.0,
                        "feature_2": 0.5,
                        "feature_3": -0.3,
                        "feature_4": 0.7
                    }
                ],
                "model_version": "latest",
                "mode": "fast"
            }
        }


# ============================================================================
# SECTION 5: Response Models
# ============================================================================

class ValidationError(BaseModel):
    """Detailed validation error"""
    field: str
    message: str
    received_value: Any


class PredictionResponse(BaseModel):
    """Response with validation metadata"""
    prediction: float
    confidence: float
    model_version: str
    validation_warnings: List[str] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)


# ============================================================================
# SECTION 6: FastAPI Application
# ============================================================================

app = FastAPI(
    title="Input Validation API",
    description="Comprehensive input validation for ML models",
    version="1.0.0"
)


@app.get("/")
def home():
    """Home endpoint"""
    return {
        "name": "Input Validation API",
        "validation_layers": [
            "Schema validation (Pydantic)",
            "Business logic validation",
            "Distribution checks",
            "Outlier detection"
        ]
    }


@app.post("/validate")
def validate_input(request: PredictionRequest):
    """
    Validate input without making prediction
    
    Useful for testing input validation before actual prediction
    
    Args:
        request: Prediction request
        
    Returns:
        Validation results
    """
    warnings = []
    
    # Additional validation beyond Pydantic
    features_array = request.features.to_array()
    
    # Check for unusual patterns
    if np.all(features_array == features_array[0]):
        warnings.append("All features have the same value - check input data")
    
    if np.all(features_array == 0):
        warnings.append("All features are zero - unusual pattern detected")
    
    # Check feature ranges relative to each other
    feature_range = features_array.max() - features_array.min()
    if feature_range < 0.1:
        warnings.append(f"Features have very small range ({feature_range:.4f})")
    
    return {
        "validation_status": "passed",
        "warnings": warnings,
        "features": {
            "min": float(features_array.min()),
            "max": float(features_array.max()),
            "mean": float(features_array.mean()),
            "std": float(features_array.std())
        },
        "model_version": request.model_version,
        "mode": request.mode
    }


@app.post("/predict")
def predict(request: PredictionRequest):
    """
    Make prediction with comprehensive validation
    
    Args:
        request: Prediction request
        
    Returns:
        Prediction response
    """
    try:
        warnings = []
        
        # Extract and validate features
        features = request.features.to_array()
        
        # Mock prediction (replace with actual model)
        prediction = float(np.sum(features * [0.25, 0.25, 0.25, 0.25]))
        confidence = 0.85
        
        # Post-prediction validation
        if confidence < 0.5:
            warnings.append("Low confidence prediction - review results carefully")
        
        # Check if prediction is in expected range
        if abs(prediction) > 8.0:
            warnings.append("Prediction outside typical range")
        
        return PredictionResponse(
            prediction=prediction,
            confidence=confidence,
            model_version=request.model_version.value,
            validation_warnings=warnings,
            metadata={
                "user_id": request.user_info.user_id,
                "mode": request.mode.value,
                "feature_magnitude": float(np.linalg.norm(features))
            }
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Prediction failed: {str(e)}"
        )


@app.post("/predict/batch")
def predict_batch(request: BatchPredictionRequest):
    """
    Batch prediction with validation
    
    Args:
        request: Batch prediction request
        
    Returns:
        Batch prediction results
    """
    predictions = []
    overall_warnings = []
    
    for idx, sample in enumerate(request.samples):
        try:
            features = sample.to_array()
            
            # Mock prediction
            prediction = float(np.sum(features * [0.25, 0.25, 0.25, 0.25]))
            confidence = 0.85
            
            predictions.append({
                "sample_index": idx,
                "prediction": prediction,
                "confidence": confidence
            })
            
        except Exception as e:
            predictions.append({
                "sample_index": idx,
                "error": str(e)
            })
            overall_warnings.append(f"Sample {idx}: {str(e)}")
    
    return {
        "num_samples": len(request.samples),
        "successful_predictions": len([p for p in predictions if 'error' not in p]),
        "failed_predictions": len([p for p in predictions if 'error' in p]),
        "predictions": predictions,
        "warnings": overall_warnings
    }


if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("Input Validation API")
    print("=" * 70)
    print("\nDocumentation: http://127.0.0.1:8000/docs")
    print("=" * 70 + "\n")
    
    uvicorn.run("05_input_validation_intermediate:app",
                host="0.0.0.0", port=8000, reload=True)


# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. Multi-Layer Validation:
   - Schema (Pydantic automatic)
   - Business logic (custom validators)
   - Statistical checks (distribution, outliers)
   - Post-processing (prediction sanity)

2. Pydantic Validators:
   - @validator: Single field validation
   - @root_validator: Multi-field validation
   - Field(): Constraints and documentation

3. Error Handling:
   - Clear error messages
   - Specify which field failed
   - Provide expected format/range
   - Use appropriate HTTP status codes

4. Production Considerations:
   - Log validation failures
   - Monitor validation patterns
   - A/B test validation rules
   - Graceful degradation

5. Best Practices:
   - Validate early and often
   - Provide helpful error messages
   - Document all constraints
   - Version your validation rules
   - Monitor data drift

6. Common Pitfalls:
   - Not validating relationships between features
   - Accepting any numeric value
   - Poor error messages
   - No outlier detection
   - Ignoring data distribution shifts
"""
