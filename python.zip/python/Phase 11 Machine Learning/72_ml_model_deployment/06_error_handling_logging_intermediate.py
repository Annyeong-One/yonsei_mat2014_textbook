"""
ML Model Deployment - Lesson 06: Error Handling and Logging (INTERMEDIATE)

This module covers comprehensive error handling and logging strategies
for production ML APIs. Proper error handling and logging are critical
for debugging, monitoring, and maintaining reliable services.

Topics covered:
- Structured error responses
- Exception handling strategies
- Logging configuration
- Request/response logging
- Error tracking and monitoring
- Custom exception classes

Learning objectives:
- Implement robust error handling
- Configure production-grade logging
- Track and debug API errors
- Monitor API health and performance
"""

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, Field, ValidationError
import logging
import logging.config
import json
import time
import traceback
from datetime import datetime
from typing import Optional, Dict, Any
import sys
import uuid
import uvicorn

# ============================================================================
# SECTION 1: Logging Configuration
# ============================================================================

# Configure structured logging
LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        },
        "detailed": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s",
        },
        "json": {
            "()": "pythonjsonlogger.jsonlogger.JsonFormatter",
            "format": "%(asctime)s %(name)s %(levelname)s %(message)s",
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "default",
            "stream": "ext://sys.stdout",
        },
        "file": {
            "class": "logging.FileHandler",
            "level": "DEBUG",
            "formatter": "detailed",
            "filename": "api.log",
            "mode": "a",
        },
        "error_file": {
            "class": "logging.FileHandler",
            "level": "ERROR",
            "formatter": "detailed",
            "filename": "error.log",
            "mode": "a",
        },
    },
    "loggers": {
        "": {  # Root logger
            "handlers": ["console", "file", "error_file"],
            "level": "INFO",
        },
        "api": {  # API-specific logger
            "handlers": ["console", "file"],
            "level": "DEBUG",
            "propagate": False,
        },
    },
}

# Apply logging configuration
logging.config.dictConfig(LOGGING_CONFIG)
logger = logging.getLogger("api")

# ============================================================================
# SECTION 2: Custom Exception Classes
# ============================================================================

class APIException(Exception):
    """
    Base exception class for API errors
    
    All custom exceptions should inherit from this class
    """
    def __init__(self, message: str, status_code: int = 500, details: Optional[Dict] = None):
        self.message = message
        self.status_code = status_code
        self.details = details or {}
        super().__init__(self.message)


class ModelNotLoadedError(APIException):
    """Raised when model is not loaded"""
    def __init__(self, message: str = "Model not loaded"):
        super().__init__(message, status_code=503, details={"type": "model_error"})


class InvalidInputError(APIException):
    """Raised for invalid input data"""
    def __init__(self, message: str, field: Optional[str] = None):
        details = {"type": "validation_error"}
        if field:
            details["field"] = field
        super().__init__(message, status_code=400, details=details)


class PredictionError(APIException):
    """Raised when prediction fails"""
    def __init__(self, message: str, model_version: Optional[str] = None):
        details = {"type": "prediction_error"}
        if model_version:
            details["model_version"] = model_version
        super().__init__(message, status_code=500, details=details)


class RateLimitError(APIException):
    """Raised when rate limit is exceeded"""
    def __init__(self, message: str = "Rate limit exceeded"):
        super().__init__(message, status_code=429, details={"type": "rate_limit"})


# ============================================================================
# SECTION 3: Error Response Models
# ============================================================================

class ErrorDetail(BaseModel):
    """Detailed error information"""
    type: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    field: Optional[str] = Field(None, description="Field that caused error")
    code: Optional[str] = Field(None, description="Error code")


class ErrorResponse(BaseModel):
    """
    Standardized error response
    
    All API errors should return this structure for consistency
    """
    error: bool = Field(True, description="Error flag")
    message: str = Field(..., description="Human-readable error message")
    error_type: str = Field(..., description="Type of error")
    status_code: int = Field(..., description="HTTP status code")
    request_id: str = Field(..., description="Unique request identifier")
    timestamp: str = Field(..., description="Error timestamp")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
    
    class Config:
        schema_extra = {
            "example": {
                "error": True,
                "message": "Model not loaded",
                "error_type": "ModelNotLoadedError",
                "status_code": 503,
                "request_id": "req_abc123",
                "timestamp": "2024-01-15T10:30:00Z",
                "details": {"type": "model_error"}
            }
        }


# ============================================================================
# SECTION 4: Request Logging Middleware
# ============================================================================

class RequestLoggingMiddleware:
    """
    Middleware for logging all requests and responses
    
    Logs request details, response status, and processing time
    """
    def __init__(self, app):
        self.app = app
    
    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        
        # Generate unique request ID
        request_id = str(uuid.uuid4())
        scope["request_id"] = request_id
        
        # Start timer
        start_time = time.time()
        
        # Log request
        logger.info(
            f"Request started",
            extra={
                "request_id": request_id,
                "method": scope["method"],
                "path": scope["path"],
                "client": scope.get("client", ["unknown"])[0],
            }
        )
        
        # Process request
        await self.app(scope, receive, send)
        
        # Calculate processing time
        process_time = time.time() - start_time
        
        # Log completion
        logger.info(
            f"Request completed",
            extra={
                "request_id": request_id,
                "process_time": f"{process_time:.4f}s",
            }
        )


# ============================================================================
# SECTION 5: FastAPI Application with Error Handlers
# ============================================================================

app = FastAPI(
    title="Error Handling & Logging API",
    description="Demonstrates comprehensive error handling and logging",
    version="1.0.0"
)

# Add logging middleware
# app.add_middleware(RequestLoggingMiddleware)  # Simplified for this example


@app.middleware("http")
async def log_requests(request: Request, call_next):
    """
    Middleware to log requests and add request ID
    
    Args:
        request: Incoming request
        call_next: Next middleware/endpoint
        
    Returns:
        Response
    """
    # Generate unique request ID
    request_id = str(uuid.uuid4())
    request.state.request_id = request_id
    
    # Log request
    start_time = time.time()
    logger.info(
        "Request started",
        extra={
            "request_id": request_id,
            "method": request.method,
            "url": str(request.url),
            "client_host": request.client.host if request.client else "unknown",
        }
    )
    
    try:
        # Process request
        response = await call_next(request)
        
        # Log response
        process_time = time.time() - start_time
        logger.info(
            "Request completed",
            extra={
                "request_id": request_id,
                "status_code": response.status_code,
                "process_time_ms": int(process_time * 1000),
            }
        )
        
        # Add request ID to response headers
        response.headers["X-Request-ID"] = request_id
        
        return response
        
    except Exception as e:
        # Log error
        process_time = time.time() - start_time
        logger.error(
            f"Request failed: {str(e)}",
            extra={
                "request_id": request_id,
                "error_type": type(e).__name__,
                "process_time_ms": int(process_time * 1000),
            },
            exc_info=True
        )
        raise


# ============================================================================
# SECTION 6: Global Exception Handlers
# ============================================================================

@app.exception_handler(APIException)
async def api_exception_handler(request: Request, exc: APIException):
    """
    Handler for custom API exceptions
    
    Args:
        request: Request that caused the exception
        exc: The exception instance
        
    Returns:
        JSON error response
    """
    request_id = getattr(request.state, "request_id", "unknown")
    
    logger.error(
        f"API exception: {exc.message}",
        extra={
            "request_id": request_id,
            "error_type": type(exc).__name__,
            "status_code": exc.status_code,
            "details": exc.details,
        }
    )
    
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": True,
            "message": exc.message,
            "error_type": type(exc).__name__,
            "status_code": exc.status_code,
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat(),
            "details": exc.details,
        }
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """
    Handler for Pydantic validation errors
    
    Args:
        request: Request that caused the exception
        exc: The validation exception
        
    Returns:
        JSON error response with validation details
    """
    request_id = getattr(request.state, "request_id", "unknown")
    
    # Extract validation error details
    errors = []
    for error in exc.errors():
        errors.append({
            "loc": error["loc"],
            "msg": error["msg"],
            "type": error["type"],
        })
    
    logger.warning(
        "Validation error",
        extra={
            "request_id": request_id,
            "validation_errors": errors,
        }
    )
    
    return JSONResponse(
        status_code=422,
        content={
            "error": True,
            "message": "Validation error",
            "error_type": "ValidationError",
            "status_code": 422,
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat(),
            "details": {
                "validation_errors": errors
            }
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """
    Catch-all handler for unexpected exceptions
    
    Args:
        request: Request that caused the exception
        exc: The exception instance
        
    Returns:
        JSON error response
    """
    request_id = getattr(request.state, "request_id", "unknown")
    
    # Get full traceback
    tb = traceback.format_exc()
    
    logger.critical(
        f"Unexpected exception: {str(exc)}",
        extra={
            "request_id": request_id,
            "error_type": type(exc).__name__,
            "traceback": tb,
        }
    )
    
    # Don't expose internal error details in production
    return JSONResponse(
        status_code=500,
        content={
            "error": True,
            "message": "Internal server error",
            "error_type": "InternalServerError",
            "status_code": 500,
            "request_id": request_id,
            "timestamp": datetime.utcnow().isoformat(),
        }
    )


# ============================================================================
# SECTION 7: API Endpoints with Error Handling
# ============================================================================

class PredictionInput(BaseModel):
    """Input for predictions"""
    value: float = Field(..., ge=-10, le=10)
    user_id: Optional[str] = None


@app.get("/")
def home():
    """Home endpoint"""
    logger.debug("Home endpoint accessed")
    return {"message": "Error Handling & Logging API"}


@app.get("/health")
def health_check():
    """
    Health check endpoint
    
    Returns API health status
    """
    logger.debug("Health check performed")
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.post("/predict")
def predict(input_data: PredictionInput):
    """
    Prediction endpoint with error handling
    
    Args:
        input_data: Input for prediction
        
    Returns:
        Prediction result
        
    Raises:
        ModelNotLoadedError: If model is not available
        PredictionError: If prediction fails
    """
    logger.info(f"Prediction request received", extra={"input": input_data.dict()})
    
    try:
        # Simulate model availability check
        model_loaded = True  # Change to False to test error
        
        if not model_loaded:
            raise ModelNotLoadedError()
        
        # Simulate prediction
        prediction = input_data.value * 2.0
        
        # Simulate prediction failure for certain inputs
        if abs(prediction) > 15:
            raise PredictionError(
                "Prediction out of range",
                model_version="v1.0"
            )
        
        logger.info(f"Prediction successful", extra={"prediction": prediction})
        
        return {
            "prediction": prediction,
            "model_version": "v1.0",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except (ModelNotLoadedError, PredictionError):
        # Re-raise custom exceptions (handled by exception handler)
        raise
    
    except Exception as e:
        # Wrap unexpected errors
        logger.error(f"Unexpected error during prediction: {str(e)}", exc_info=True)
        raise PredictionError(f"Prediction failed: {str(e)}")


@app.get("/trigger-error/{error_type}")
def trigger_error(error_type: str):
    """
    Endpoint to trigger different types of errors (for testing)
    
    Args:
        error_type: Type of error to trigger
        
    Returns:
        Never returns normally
    """
    logger.warning(f"Triggering error: {error_type}")
    
    if error_type == "model":
        raise ModelNotLoadedError("Model is not available")
    elif error_type == "validation":
        raise InvalidInputError("Invalid input provided", field="test_field")
    elif error_type == "prediction":
        raise PredictionError("Prediction failed unexpectedly")
    elif error_type == "rate_limit":
        raise RateLimitError()
    elif error_type == "unexpected":
        # Trigger unexpected error
        result = 1 / 0  # ZeroDivisionError
    else:
        raise HTTPException(status_code=400, detail="Unknown error type")


if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("Error Handling & Logging API")
    print("=" * 70)
    print("\nDocumentation: http://127.0.0.1:8000/docs")
    print("\nTest error handlers:")
    print("  GET /trigger-error/model")
    print("  GET /trigger-error/validation")
    print("  GET /trigger-error/prediction")
    print("  GET /trigger-error/unexpected")
    print("=" * 70 + "\n")
    
    uvicorn.run("06_error_handling_logging_intermediate:app",
                host="0.0.0.0", port=8000, reload=True)


# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. Error Handling Strategy:
   - Custom exception classes
   - Consistent error responses
   - Appropriate HTTP status codes
   - Don't expose internal details

2. Logging Best Practices:
   - Structured logging
   - Different log levels
   - Request/response logging
   - Unique request IDs
   - Log rotation

3. Exception Hierarchy:
   - Base APIException class
   - Specific exception types
   - Include relevant context
   - Separate user vs system errors

4. Error Response Structure:
   - Consistent format
   - Include request ID
   - Timestamp
   - Error details
   - Don't leak sensitive info

5. Middleware:
   - Log all requests
   - Add request IDs
   - Measure processing time
   - Catch unhandled errors

6. Production Considerations:
   - Log to files and console
   - Aggregate logs (ELK, Splunk)
   - Alert on errors
   - Monitor error rates
   - Track error patterns
"""
