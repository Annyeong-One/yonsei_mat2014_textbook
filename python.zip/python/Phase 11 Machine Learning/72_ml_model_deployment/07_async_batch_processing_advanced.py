"""
ML Model Deployment - Lesson 07: Async & Batch Processing (ADVANCED)

This module covers asynchronous request handling and batch processing
for high-throughput ML model serving.

Topics covered:
- Async/await in FastAPI
- Background tasks
- Batch prediction optimization
- Request queuing
- Concurrent request handling
- Performance optimization

Learning objectives:
- Implement async endpoints
- Handle concurrent predictions
- Optimize batch processing
- Use background tasks effectively
"""

from fastapi import FastAPI, BackgroundTasks, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
import asyncio
import numpy as np
from datetime import datetime
from collections import deque
import uuid
import time
import uvicorn

# ============================================================================
# SECTION 1: Async Model Wrapper
# ============================================================================

class AsyncModelPredictor:
    """
    Async wrapper for ML model predictions
    
    Simulates an ML model with async I/O operations
    """
    
    def __init__(self, model_name: str = "async_model"):
        self.model_name = model_name
        self.prediction_count = 0
        self.last_prediction_time = None
        
    async def predict_single(self, features: np.ndarray, delay: float = 0.1) -> Dict:
        """
        Async prediction for single sample
        
        Args:
            features: Input features
            delay: Simulated processing time
            
        Returns:
            Prediction result
        """
        # Simulate async I/O (e.g., calling external service, GPU inference)
        await asyncio.sleep(delay)
        
        # Simple prediction
        prediction = float(np.sum(features))
        confidence = 0.85
        
        self.prediction_count += 1
        self.last_prediction_time = datetime.utcnow()
        
        return {
            "prediction": prediction,
            "confidence": confidence,
            "model": self.model_name
        }
    
    async def predict_batch(self, batch_features: List[np.ndarray]) -> List[Dict]:
        """
        Optimized batch prediction
        
        Process multiple samples concurrently
        
        Args:
            batch_features: List of feature arrays
            
        Returns:
            List of predictions
        """
        # Create async tasks for all samples
        tasks = [
            self.predict_single(features, delay=0.05)  # Faster for batch
            for features in batch_features
        ]
        
        # Run all predictions concurrently
        results = await asyncio.gather(*tasks)
        
        return results


# ============================================================================
# SECTION 2: Request Queue Manager
# ============================================================================

class RequestQueue:
    """
    Manages prediction request queue
    
    Batches requests for efficient processing
    """
    
    def __init__(self, max_batch_size: int = 32, max_wait_time: float = 0.1):
        self.max_batch_size = max_batch_size
        self.max_wait_time = max_wait_time
        self.queue = deque()
        self.results = {}
        self.lock = asyncio.Lock()
        
    async def add_request(self, request_id: str, features: np.ndarray) -> Dict:
        """
        Add request to queue and wait for result
        
        Args:
            request_id: Unique request identifier
            features: Input features
            
        Returns:
            Prediction result
        """
        # Create future for this request
        future = asyncio.Future()
        
        async with self.lock:
            self.queue.append({
                "request_id": request_id,
                "features": features,
                "future": future,
                "timestamp": time.time()
            })
        
        # Wait for result
        result = await future
        return result
    
    async def process_queue(self, model: AsyncModelPredictor):
        """
        Process queued requests in batches
        
        Background task that continuously processes queue
        
        Args:
            model: Model to use for predictions
        """
        while True:
            await asyncio.sleep(0.01)  # Small delay
            
            async with self.lock:
                if not self.queue:
                    continue
                
                # Get batch
                batch_size = min(len(self.queue), self.max_batch_size)
                batch = [self.queue.popleft() for _ in range(batch_size)]
            
            # Extract features
            features_batch = [item["features"] for item in batch]
            
            # Make batch prediction
            results = await model.predict_batch(features_batch)
            
            # Complete futures
            for item, result in zip(batch, results):
                item["future"].set_result(result)


# ============================================================================
# SECTION 3: FastAPI Application
# ============================================================================

app = FastAPI(
    title="Async & Batch Processing API",
    description="High-throughput ML model serving with async",
    version="1.0.0"
)

# Global model and queue
model = AsyncModelPredictor()
request_queue = RequestQueue(max_batch_size=32)

# ============================================================================
# SECTION 4: Pydantic Models
# ============================================================================

class AsyncPredictionInput(BaseModel):
    """Input for async prediction"""
    features: List[float] = Field(..., min_items=4, max_items=4)
    
    class Config:
        schema_extra = {
            "example": {
                "features": [1.0, 2.0, 3.0, 4.0]
            }
        }


class BatchPredictionInput(BaseModel):
    """Input for batch prediction"""
    samples: List[List[float]] = Field(..., min_items=1, max_items=100)
    
    class Config:
        schema_extra = {
            "example": {
                "samples": [
                    [1.0, 2.0, 3.0, 4.0],
                    [2.0, 3.0, 4.0, 5.0],
                    [3.0, 4.0, 5.0, 6.0]
                ]
            }
        }


class JobStatus(BaseModel):
    """Background job status"""
    job_id: str
    status: str
    result: Optional[Dict] = None
    submitted_at: str
    completed_at: Optional[str] = None


# Job storage
background_jobs: Dict[str, JobStatus] = {}


# ============================================================================
# SECTION 5: Background Task Functions
# ============================================================================

async def process_prediction_background(job_id: str, features: List[float]):
    """
    Background task for processing prediction
    
    Args:
        job_id: Unique job identifier
        features: Input features
    """
    try:
        # Update status
        background_jobs[job_id].status = "processing"
        
        # Simulate long-running task
        await asyncio.sleep(2.0)
        
        # Make prediction
        result = await model.predict_single(np.array(features), delay=0.5)
        
        # Update job with result
        background_jobs[job_id].status = "completed"
        background_jobs[job_id].result = result
        background_jobs[job_id].completed_at = datetime.utcnow().isoformat()
        
    except Exception as e:
        background_jobs[job_id].status = "failed"
        background_jobs[job_id].result = {"error": str(e)}


# ============================================================================
# SECTION 6: API Endpoints
# ============================================================================

@app.on_event("startup")
async def startup_event():
    """Start background queue processor"""
    asyncio.create_task(request_queue.process_queue(model))
    print("Background queue processor started")


@app.get("/")
async def home():
    """Home endpoint"""
    return {
        "name": "Async & Batch Processing API",
        "features": [
            "Async predictions",
            "Batch processing",
            "Request queuing",
            "Background tasks"
        ]
    }


@app.post("/predict/sync")
def predict_sync(input_data: AsyncPredictionInput):
    """
    Synchronous prediction (blocking)
    
    NOT RECOMMENDED for production - blocks event loop
    
    Args:
        input_data: Input features
        
    Returns:
        Prediction result
    """
    features = np.array(input_data.features)
    
    # Blocking operation - BAD PRACTICE
    prediction = float(np.sum(features))
    
    return {
        "prediction": prediction,
        "mode": "synchronous"
    }


@app.post("/predict/async")
async def predict_async(input_data: AsyncPredictionInput):
    """
    Asynchronous prediction (non-blocking)
    
    RECOMMENDED for I/O-bound operations
    
    Args:
        input_data: Input features
        
    Returns:
        Prediction result
    """
    features = np.array(input_data.features)
    
    # Non-blocking async call
    result = await model.predict_single(features)
    
    return {
        **result,
        "mode": "asynchronous"
    }


@app.post("/predict/queued")
async def predict_queued(input_data: AsyncPredictionInput):
    """
    Queued prediction with automatic batching
    
    Requests are batched automatically for efficiency
    
    Args:
        input_data: Input features
        
    Returns:
        Prediction result
    """
    request_id = str(uuid.uuid4())
    features = np.array(input_data.features)
    
    # Add to queue and wait for result
    result = await request_queue.add_request(request_id, features)
    
    return {
        **result,
        "mode": "queued"
    }


@app.post("/predict/batch")
async def predict_batch(input_data: BatchPredictionInput):
    """
    Batch prediction endpoint
    
    Processes multiple samples concurrently
    
    Args:
        input_data: Batch of samples
        
    Returns:
        Batch results
    """
    # Convert to numpy arrays
    features_batch = [np.array(sample) for sample in input_data.samples]
    
    # Process batch
    start_time = time.time()
    results = await model.predict_batch(features_batch)
    process_time = time.time() - start_time
    
    return {
        "num_samples": len(input_data.samples),
        "predictions": results,
        "process_time_ms": int(process_time * 1000),
        "throughput": len(input_data.samples) / process_time
    }


@app.post("/predict/background")
async def predict_background(
    input_data: AsyncPredictionInput,
    background_tasks: BackgroundTasks
):
    """
    Background prediction (fire-and-forget)
    
    Returns immediately with job ID
    Client polls for results
    
    Args:
        input_data: Input features
        background_tasks: FastAPI background tasks
        
    Returns:
        Job ID
    """
    job_id = str(uuid.uuid4())
    
    # Create job status
    background_jobs[job_id] = JobStatus(
        job_id=job_id,
        status="submitted",
        submitted_at=datetime.utcnow().isoformat()
    )
    
    # Add background task
    background_tasks.add_task(
        process_prediction_background,
        job_id,
        input_data.features
    )
    
    return {
        "job_id": job_id,
        "status": "submitted",
        "status_url": f"/predict/status/{job_id}"
    }


@app.get("/predict/status/{job_id}")
async def get_job_status(job_id: str):
    """
    Get background job status
    
    Args:
        job_id: Job identifier
        
    Returns:
        Job status
    """
    if job_id not in background_jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    
    return background_jobs[job_id]


@app.get("/stats")
async def get_stats():
    """Get API statistics"""
    return {
        "total_predictions": model.prediction_count,
        "last_prediction": model.last_prediction_time.isoformat() if model.last_prediction_time else None,
        "queue_size": len(request_queue.queue),
        "background_jobs": len(background_jobs)
    }


if __name__ == "__main__":
    print("\\n" + "=" * 70)
    print("Async & Batch Processing API")
    print("=" * 70)
    print("\\nDocumentation: http://127.0.0.1:8000/docs")
    print("=" * 70 + "\\n")
    
    uvicorn.run("07_async_batch_processing_advanced:app",
                host="0.0.0.0", port=8000, reload=True)


# ============================================================================
# KEY CONCEPTS SUMMARY
# ============================================================================
"""
1. Async/Await:
   - Non-blocking I/O operations
   - Better resource utilization
   - Higher throughput
   - Use for I/O-bound tasks

2. Batch Processing:
   - Process multiple samples together
   - Better GPU utilization
   - Reduced overhead
   - Use asyncio.gather()

3. Request Queuing:
   - Automatic batching
   - Smooth request handling
   - Better throughput
   - Trade latency for throughput

4. Background Tasks:
   - Long-running operations
   - Fire-and-forget pattern
   - Status polling
   - Resource management

5. Performance Optimization:
   - Concurrent processing
   - Batch inference
   - Request batching
   - Async I/O

6. Best Practices:
   - Use async for I/O-bound
   - Batch where possible
   - Monitor queue sizes
   - Set appropriate timeouts
   - Handle backpressure
"""
