"""
ML Model Deployment - Lesson 08: Model Versioning (ADVANCED)

This module covers model versioning strategies for production ML systems.
Proper versioning enables A/B testing, rollbacks, and gradual rollouts.

Topics covered:
- Model versioning strategies
- A/B testing
- Canary deployments
- Model registry patterns
- Version selection logic
- Rollback mechanisms

Learning objectives:
- Implement model versioning
- Support multiple model versions
- Switch between models dynamically
- Track model performance by version
"""

from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field
from typing import Dict, List, Optional
from enum import Enum
import numpy as np
from datetime import datetime
import uvicorn

# Model registry - stores multiple model versions
MODEL_REGISTRY: Dict[str, Dict] = {}

class ModelVersion:
    """
    Represents a versioned ML model
    
    Attributes:
        version: Version identifier
        model: The actual model object
        metadata: Model metadata (training date, metrics, etc.)
        is_active: Whether this version is active
    """
    def __init__(self, version: str, model, metadata: Dict):
        self.version = version
        self.model = model
        self.metadata = metadata
        self.is_active = True
        self.prediction_count = 0
        self.created_at = datetime.utcnow()
    
    def predict(self, features: np.ndarray) -> Dict:
        """Make prediction with this model version"""
        # Simple mock prediction
        prediction = float(np.sum(features) * float(self.version.replace('v', '')))
        self.prediction_count += 1
        
        return {
            'prediction': prediction,
            'model_version': self.version,
            'model_metrics': self.metadata.get('metrics', {})
        }

# Initialize model registry
def init_models():
    """Initialize multiple model versions"""
    # Version 1.0 - baseline model
    MODEL_REGISTRY['v1.0'] = ModelVersion(
        version='v1.0',
        model=None,  # Mock model
        metadata={
            'trained_date': '2024-01-01',
            'metrics': {'accuracy': 0.85, 'f1': 0.83},
            'training_data': 'dataset_v1',
            'description': 'Baseline logistic regression'
        }
    )
    
    # Version 1.1 - improved model
    MODEL_REGISTRY['v1.1'] = ModelVersion(
        version='v1.1',
        model=None,
        metadata={
            'trained_date': '2024-02-01',
            'metrics': {'accuracy': 0.88, 'f1': 0.86},
            'training_data': 'dataset_v2',
            'description': 'Improved with feature engineering'
        }
    )
    
    # Version 2.0 - neural network
    MODEL_REGISTRY['v2.0'] = ModelVersion(
        version='v2.0',
        model=None,
        metadata={
            'trained_date': '2024-03-01',
            'metrics': {'accuracy': 0.92, 'f1': 0.90},
            'training_data': 'dataset_v3',
            'description': 'Deep learning model'
        }
    )

app = FastAPI(title="Model Versioning API", version="1.0.0")

# Initialize models on startup
@app.on_event("startup")
async def startup():
    init_models()
    print(f"Loaded {len(MODEL_REGISTRY)} model versions")

class PredictionInput(BaseModel):
    features: List[float] = Field(..., min_items=4, max_items=4)
    version: Optional[str] = Field(None, description="Specific model version")

@app.get("/models")
async def list_models():
    """List all available model versions"""
    return {
        'models': [
            {
                'version': v,
                'metadata': model.metadata,
                'is_active': model.is_active,
                'prediction_count': model.prediction_count
            }
            for v, model in MODEL_REGISTRY.items()
        ]
    }

@app.post("/predict")
async def predict(
    input_data: PredictionInput,
    x_user_id: Optional[str] = Header(None)
):
    """
    Make prediction with version selection
    
    Version selection strategy:
    1. Use specified version if provided
    2. A/B test based on user_id
    3. Default to latest version
    """
    # Determine version to use
    if input_data.version:
        version = input_data.version
    elif x_user_id and int(x_user_id.split('_')[-1], 16) % 2 == 0:
        version = 'v1.1'  # 50% to v1.1
    else:
        version = 'v2.0'  # 50% to v2.0
    
    if version not in MODEL_REGISTRY:
        raise HTTPException(404, f"Model version {version} not found")
    
    model = MODEL_REGISTRY[version]
    if not model.is_active:
        raise HTTPException(400, f"Model version {version} is inactive")
    
    # Make prediction
    result = model.predict(np.array(input_data.features))
    result['selected_version'] = version
    
    return result

@app.post("/models/{version}/activate")
async def activate_model(version: str):
    """Activate a model version"""
    if version not in MODEL_REGISTRY:
        raise HTTPException(404, f"Version {version} not found")
    MODEL_REGISTRY[version].is_active = True
    return {'message': f'Version {version} activated'}

@app.post("/models/{version}/deactivate")
async def deactivate_model(version: str):
    """Deactivate a model version (for rollback)"""
    if version not in MODEL_REGISTRY:
        raise HTTPException(404, f"Version {version} not found")
    MODEL_REGISTRY[version].is_active = False
    return {'message': f'Version {version} deactivated'}

if __name__ == "__main__":
    uvicorn.run("08_model_versioning_advanced:app", host="0.0.0.0", port=8000)

# KEY CONCEPTS:
# - Model registry for version management
# - A/B testing based on user ID
# - Version activation/deactivation
# - Rollback capability
# - Version-specific metadata tracking
"""