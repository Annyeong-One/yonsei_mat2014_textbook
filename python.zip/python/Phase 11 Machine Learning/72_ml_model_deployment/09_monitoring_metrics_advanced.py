"""
ML Model Deployment - Lesson 09: Monitoring & Metrics (ADVANCED)

This module covers monitoring ML model APIs in production.
Monitoring is critical for detecting issues, performance degradation,
and ensuring reliability.

Topics covered:
- API metrics collection
- Model performance monitoring
- Request/response tracking
- Prometheus integration
- Health checks
- Alerting patterns

Learning objectives:
- Implement comprehensive monitoring
- Track key metrics
- Detect model degradation
- Set up health checks
"""

from fastapi import FastAPI, Request
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response
from pydantic import BaseModel
from typing import Dict
import time
import psutil
import numpy as np
import uvicorn

app = FastAPI(title="Monitoring & Metrics API", version="1.0.0")

# Define Prometheus metrics
REQUEST_COUNT = Counter(
    'api_requests_total',
    'Total API requests',
    ['method', 'endpoint', 'status']
)

REQUEST_LATENCY = Histogram(
    'api_request_duration_seconds',
    'API request latency',
    ['method', 'endpoint']
)

PREDICTION_COUNT = Counter(
    'predictions_total',
    'Total predictions made',
    ['model_version']
)

PREDICTION_LATENCY = Histogram(
    'prediction_duration_seconds',
    'Prediction latency',
    ['model_version']
)

ERROR_COUNT = Counter(
    'api_errors_total',
    'Total API errors',
    ['error_type']
)

MODEL_ACCURACY = Gauge(
    'model_accuracy',
    'Current model accuracy',
    ['model_version']
)

ACTIVE_REQUESTS = Gauge(
    'active_requests',
    'Number of active requests'
)

CPU_USAGE = Gauge('cpu_usage_percent', 'CPU usage percentage')
MEMORY_USAGE = Gauge('memory_usage_percent', 'Memory usage percentage')

@app.middleware("http")
async def monitor_requests(request: Request, call_next):
    """Middleware to monitor all requests"""
    ACTIVE_REQUESTS.inc()
    start_time = time.time()
    
    try:
        response = await call_next(request)
        
        # Record metrics
        duration = time.time() - start_time
        REQUEST_LATENCY.labels(
            method=request.method,
            endpoint=request.url.path
        ).observe(duration)
        
        REQUEST_COUNT.labels(
            method=request.method,
            endpoint=request.url.path,
            status=response.status_code
        ).inc()
        
        return response
    
    except Exception as e:
        ERROR_COUNT.labels(error_type=type(e).__name__).inc()
        raise
    finally:
        ACTIVE_REQUESTS.dec()

class PredictionInput(BaseModel):
    features: list[float]

@app.post("/predict")
async def predict(input_data: PredictionInput):
    """Prediction endpoint with monitoring"""
    model_version = "v1.0"
    
    start_time = time.time()
    
    # Make prediction
    prediction = float(np.sum(input_data.features))
    
    # Record prediction metrics
    duration = time.time() - start_time
    PREDICTION_LATENCY.labels(model_version=model_version).observe(duration)
    PREDICTION_COUNT.labels(model_version=model_version).inc()
    
    return {
        'prediction': prediction,
        'model_version': model_version
    }

@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    # Update system metrics
    CPU_USAGE.set(psutil.cpu_percent())
    MEMORY_USAGE.set(psutil.virtual_memory().percent)
    
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

@app.get("/health")
async def health_check():
    """Comprehensive health check"""
    return {
        'status': 'healthy',
        'cpu_percent': psutil.cpu_percent(),
        'memory_percent': psutil.virtual_memory().percent,
        'disk_percent': psutil.disk_usage('/').percent
    }

if __name__ == "__main__":
    uvicorn.run("09_monitoring_metrics_advanced:app", host="0.0.0.0", port=8000)

# KEY CONCEPTS:
# - Prometheus metrics integration
# - Request/response monitoring
# - System resource tracking
# - Error rate monitoring
# - Model performance metrics
"""