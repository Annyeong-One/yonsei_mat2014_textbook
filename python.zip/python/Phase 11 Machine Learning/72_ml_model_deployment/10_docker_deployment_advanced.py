"""
ML Model Deployment - Lesson 10: Docker Deployment (ADVANCED)

This module covers containerizing ML models with Docker.
Docker ensures consistent deployment across environments.

Topics covered:
- Creating Dockerfiles
- Multi-stage builds
- Container optimization
- Docker Compose
- Environment configuration
- Best practices

Learning objectives:
- Containerize ML APIs
- Optimize Docker images
- Configure containers
- Deploy with Docker Compose
"""

# This file contains Docker-related code and documentation

DOCKERFILE_CONTENT = """
# Multi-stage Docker build for ML model serving

# Stage 1: Builder
FROM python:3.11-slim as builder

WORKDIR /app

# Install build dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .

# Install Python dependencies
RUN pip install --no-cache-dir --user -r requirements.txt

# Stage 2: Runtime
FROM python:3.11-slim

WORKDIR /app

# Copy Python dependencies from builder
COPY --from=builder /root/.local /root/.local

# Copy application code
COPY . .

# Make sure scripts are executable
ENV PATH=/root/.local/bin:$PATH

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD python -c "import requests; requests.get('http://localhost:8000/health')"

# Run application
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""

DOCKER_COMPOSE_CONTENT = """
version: '3.8'

services:
  api:
    build: .
    ports:
      - "8000:8000"
    environment:
      - MODEL_VERSION=v1.0
      - LOG_LEVEL=INFO
    volumes:
      - ./models:/app/models
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
  
  prometheus:
    image: prom/prometheus
    ports:
      - "9090:9090"
    volumes:
      - ./prometheus.yml:/etc/prometheus/prometheus.yml
    command:
      - '--config.file=/etc/prometheus/prometheus.yml'
  
  grafana:
    image: grafana/grafana
    ports:
      - "3000:3000"
    environment:
      - GF_SECURITY_ADMIN_PASSWORD=admin
    volumes:
      - grafana-storage:/var/lib/grafana

volumes:
  grafana-storage:
"""

DOCKERIGNORE_CONTENT = """
__pycache__
*.pyc
*.pyo
*.pyd
.Python
env/
venv/
.venv/
pip-log.txt
pip-delete-this-directory.txt
.tox/
.coverage
.coverage.*
.cache
nosetests.xml
coverage.xml
*.cover
*.log
.git
.gitignore
.mypy_cache
.pytest_cache
.hypothesis
*.md
!README.md
.DS_Store
"""

def create_docker_files():
    """Create Docker-related files"""
    with open('Dockerfile', 'w') as f:
        f.write(DOCKERFILE_CONTENT)
    
    with open('docker-compose.yml', 'w') as f:
        f.write(DOCKER_COMPOSE_CONTENT)
    
    with open('.dockerignore', 'w') as f:
        f.write(DOCKERIGNORE_CONTENT)
    
    print("Docker files created successfully!")
    print("\nTo build and run:")
    print("  docker build -t ml-api .")
    print("  docker run -p 8000:8000 ml-api")
    print("\nOr with Docker Compose:")
    print("  docker-compose up -d")

if __name__ == "__main__":
    create_docker_files()

# KEY CONCEPTS:
# - Multi-stage builds for smaller images
# - Health checks in containers
# - Environment configuration
# - Volume mounts for models
# - Docker Compose for multi-service
# - .dockerignore for optimization
"""