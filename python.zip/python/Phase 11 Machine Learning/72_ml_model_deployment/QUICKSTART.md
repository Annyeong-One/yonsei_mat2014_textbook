# Quick Start Guide

## 5-Minute Setup

### Step 1: Install Dependencies (2 minutes)
```bash
pip install flask fastapi uvicorn scikit-learn numpy torch pydantic
```

### Step 2: Run Your First API (1 minute)
```bash
python 01_flask_basics_beginner.py
```

Open browser: http://localhost:5000

### Step 3: Try Interactive Docs (1 minute)
```bash
python 02_fastapi_basics_beginner.py
```

Open browser: http://localhost:8000/docs

### Step 4: Make a Prediction (1 minute)
```bash
python 03_sklearn_model_serving_beginner.py
```

Test with:
```bash
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{"sepal_length": 5.1, "sepal_width": 3.5, "petal_length": 1.4, "petal_width": 0.2}'
```

## Common Commands

### Test Endpoints
```bash
# GET request
curl http://localhost:5000/health

# POST with JSON
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"features": [1.0, 2.0, 3.0, 4.0]}'
```

### Using Python
```python
import requests

response = requests.post(
    'http://localhost:8000/predict',
    json={'features': [1.0, 2.0, 3.0, 4.0]}
)
print(response.json())
```

## Troubleshooting

**Port in use?**
Change port in code: `app.run(port=5001)`

**Module not found?**
Install: `pip install <module-name>`

**Need help?**
Check README.md for detailed instructions!
