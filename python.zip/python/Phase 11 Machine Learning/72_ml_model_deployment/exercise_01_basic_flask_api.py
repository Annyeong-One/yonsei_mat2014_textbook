"""
EXERCISE 01: Build a Basic Flask API (BEGINNER)

Task:
Create a Flask API with the following endpoints:
1. GET /hello - Returns a greeting message
2. POST /echo - Echoes back the JSON data sent
3. GET /add?x=&y= - Returns the sum of x and y
4. POST /square - Takes a number and returns its square

Requirements:
- Use proper error handling
- Return JSON responses
- Validate input data
- Include helpful error messages

TODO: Complete the implementation below
"""

from flask import Flask, request, jsonify

app = Flask(__name__)

# TODO: Implement endpoint 1
@app.route('/hello')
def hello():
    # Return a JSON response with a greeting
    pass

# TODO: Implement endpoint 2
@app.route('/echo', methods=['POST'])
def echo():
    # Get JSON data from request and echo it back
    pass

# TODO: Implement endpoint 3
@app.route('/add')
def add():
    # Get x and y from query parameters
    # Validate they are numbers
    # Return their sum
    pass

# TODO: Implement endpoint 4
@app.route('/square', methods=['POST'])
def square():
    # Get number from JSON body
    # Validate it's a number
    # Return its square
    pass

if __name__ == '__main__':
    app.run(debug=True)

# TESTING:
# 1. curl http://localhost:5000/hello
# 2. curl -X POST http://localhost:5000/echo -H "Content-Type: application/json" -d '{"name": "test"}'
# 3. curl "http://localhost:5000/add?x=5&y=3"
# 4. curl -X POST http://localhost:5000/square -H "Content-Type: application/json" -d '{"number": 4}'
"""