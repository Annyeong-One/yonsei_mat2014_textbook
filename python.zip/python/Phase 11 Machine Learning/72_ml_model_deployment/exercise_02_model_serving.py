"""
EXERCISE 02: Serve a Simple Model (INTERMEDIATE)

Task:
Create a FastAPI application that serves a simple linear regression model.

Requirements:
1. Train a linear model on a simple dataset
2. Save the model
3. Create an API endpoint to make predictions
4. Add input validation
5. Return prediction with confidence interval

TODO: Complete the implementation
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import numpy as np
import pickle

app = FastAPI()

# TODO: Define input model with validation
class PredictionInput(BaseModel):
    # Add features with appropriate validation
    pass

# TODO: Load or train a simple model
def load_model():
    # Train a simple linear model
    # Save and load it
    pass

# TODO: Implement prediction endpoint
@app.post("/predict")
async def predict(input_data: PredictionInput):
    # Validate input
    # Make prediction
    # Return result with confidence
    pass

# TODO: Add health check endpoint
@app.get("/health")
async def health():
    pass

# BONUS: Add batch prediction endpoint
# BONUS: Add model info endpoint
"""