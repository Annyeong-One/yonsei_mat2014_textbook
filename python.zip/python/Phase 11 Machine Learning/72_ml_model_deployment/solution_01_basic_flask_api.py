"""
SOLUTION 01: Basic Flask API

This is the solution to Exercise 01.
"""

from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/hello')
def hello():
    """Returns a greeting message"""
    return jsonify({
        'message': 'Hello from Flask API!',
        'status': 'success'
    })

@app.route('/echo', methods=['POST'])
def echo():
    """Echoes back the JSON data sent"""
    try:
        data = request.get_json()
        
        if data is None:
            return jsonify({
                'error': 'No JSON data provided'
            }), 400
        
        return jsonify({
            'echo': data,
            'message': 'Data received successfully'
        })
    
    except Exception as e:
        return jsonify({
            'error': f'Error processing request: {str(e)}'
        }), 500

@app.route('/add')
def add():
    """Returns the sum of x and y"""
    try:
        # Get query parameters
        x = request.args.get('x')
        y = request.args.get('y')
        
        # Validate parameters exist
        if x is None or y is None:
            return jsonify({
                'error': 'Both x and y parameters are required'
            }), 400
        
        # Convert to float
        try:
            x = float(x)
            y = float(y)
        except ValueError:
            return jsonify({
                'error': 'x and y must be valid numbers'
            }), 400
        
        # Calculate sum
        result = x + y
        
        return jsonify({
            'x': x,
            'y': y,
            'sum': result
        })
    
    except Exception as e:
        return jsonify({
            'error': f'Error: {str(e)}'
        }), 500

@app.route('/square', methods=['POST'])
def square():
    """Takes a number and returns its square"""
    try:
        # Get JSON data
        data = request.get_json()
        
        if data is None:
            return jsonify({
                'error': 'No JSON data provided'
            }), 400
        
        # Check if 'number' field exists
        if 'number' not in data:
            return jsonify({
                'error': 'Field "number" is required'
            }), 400
        
        # Get and validate number
        try:
            number = float(data['number'])
        except (ValueError, TypeError):
            return jsonify({
                'error': '"number" must be a valid number'
            }), 400
        
        # Calculate square
        result = number ** 2
        
        return jsonify({
            'input': number,
            'square': result
        })
    
    except Exception as e:
        return jsonify({
            'error': f'Error: {str(e)}'
        }), 500

if __name__ == '__main__':
    print("Flask API Server")
    print("Endpoints:")
    print("  GET  /hello")
    print("  POST /echo")
    print("  GET  /add?x=&y=")
    print("  POST /square")
    print("\nServer running at http://127.0.0.1:5000")
    app.run(debug=True)
"""