"""
SOLUTION 02: Model Serving

Complete implementation of Exercise 02.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
import numpy as np
import pickle
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import os
import uvicorn

app = FastAPI(title="Linear Regression API", version="1.0.0")

# Global model variable
MODEL = None
MODEL_PATH = "linear_model.pkl"

class PredictionInput(BaseModel):
    """Input model with validation"""
    x: float = Field(..., ge=-100, le=100, description="Input feature x")
    
    class Config:
        schema_extra = {
            "example": {
                "x": 5.0
            }
        }

class PredictionOutput(BaseModel):
    """Output model"""
    prediction: float
    confidence_interval: dict

def train_and_save_model():
    """Train a simple linear model"""
    # Generate synthetic data: y = 2x + 1 + noise
    np.random.seed(42)
    X = np.random.randn(100, 1) * 10
    y = 2 * X.ravel() + 1 + np.random.randn(100) * 2
    
    # Train model
    model = LinearRegression()
    model.fit(X, y)
    
    # Save model
    with open(MODEL_PATH, 'wb') as f:
        pickle.dump(model, f)
    
    print(f"Model trained and saved to {MODEL_PATH}")
    print(f"Model coefficients: {model.coef_}")
    print(f"Model intercept: {model.intercept_}")
    
    return model

def load_model():
    """Load the trained model"""
    if not os.path.exists(MODEL_PATH):
        print("Model not found. Training new model...")
        return train_and_save_model()
    
    with open(MODEL_PATH, 'rb') as f:
        model = pickle.load(f)
    
    print("Model loaded successfully")
    return model

@app.on_event("startup")
async def startup_event():
    """Load model on startup"""
    global MODEL
    MODEL = load_model()

@app.get("/")
async def home():
    """Home endpoint"""
    return {
        "name": "Linear Regression API",
        "version": "1.0.0",
        "model": "Linear Regression",
        "endpoints": {
            "/predict": "Make prediction",
            "/predict/batch": "Batch predictions",
            "/model/info": "Model information",
            "/health": "Health check"
        }
    }

@app.get("/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model_loaded": MODEL is not None
    }

@app.get("/model/info")
async def model_info():
    """Get model information"""
    if MODEL is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    return {
        "model_type": "Linear Regression",
        "coefficients": MODEL.coef_.tolist(),
        "intercept": float(MODEL.intercept_),
        "formula": f"y = {MODEL.coef_[0]:.2f}x + {MODEL.intercept_:.2f}"
    }

@app.post("/predict", response_model=PredictionOutput)
async def predict(input_data: PredictionInput):
    """
    Make prediction with confidence interval
    
    Args:
        input_data: Input features
        
    Returns:
        Prediction with confidence interval
    """
    if MODEL is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    try:
        # Prepare input
        X = np.array([[input_data.x]])
        
        # Make prediction
        prediction = float(MODEL.predict(X)[0])
        
        # Calculate simple confidence interval (for demonstration)
        # In practice, use proper statistical methods
        std_error = 2.0  # Simplified
        confidence_interval = {
            "lower": prediction - 1.96 * std_error,
            "upper": prediction + 1.96 * std_error,
            "level": 0.95
        }
        
        return PredictionOutput(
            prediction=prediction,
            confidence_interval=confidence_interval
        )
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Prediction failed: {str(e)}"
        )

@app.post("/predict/batch")
async def predict_batch(inputs: list[PredictionInput]):
    """
    Batch prediction endpoint
    
    Args:
        inputs: List of input features
        
    Returns:
        List of predictions
    """
    if MODEL is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    if len(inputs) > 100:
        raise HTTPException(
            status_code=400,
            detail="Batch size too large (max 100)"
        )
    
    predictions = []
    for input_data in inputs:
        X = np.array([[input_data.x]])
        prediction = float(MODEL.predict(X)[0])
        predictions.append({
            "input": input_data.x,
            "prediction": prediction
        })
    
    return {
        "num_samples": len(inputs),
        "predictions": predictions
    }

if __name__ == "__main__":
    print("\nLinear Regression API")
    print("Documentation: http://127.0.0.1:8000/docs")
    uvicorn.run("solution_02_model_serving:app", 
                host="0.0.0.0", port=8000, reload=True)
"""