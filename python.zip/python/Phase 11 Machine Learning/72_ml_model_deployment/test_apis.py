"""
Simple test script to verify APIs are working

This script helps students test if their API implementations are correct.
"""

import requests
import time
import sys

def test_flask_api(port=5000):
    """Test Flask API endpoints"""
    base_url = f"http://localhost:{port}"
    
    print("\nTesting Flask API...")
    print("=" * 50)
    
    try:
        # Test home endpoint
        response = requests.get(f"{base_url}/")
        print(f"✓ GET / - Status: {response.status_code}")
        
        # Test health endpoint
        response = requests.get(f"{base_url}/health")
        print(f"✓ GET /health - Status: {response.status_code}")
        
        print("\nFlask API tests passed!")
        return True
    
    except requests.exceptions.ConnectionError:
        print("✗ Flask API not running!")
        print(f"  Start it with: python 01_flask_basics_beginner.py")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_fastapi(port=8000):
    """Test FastAPI endpoints"""
    base_url = f"http://localhost:{port}"
    
    print("\nTesting FastAPI...")
    print("=" * 50)
    
    try:
        # Test home endpoint
        response = requests.get(f"{base_url}/")
        print(f"✓ GET / - Status: {response.status_code}")
        
        # Test health endpoint
        response = requests.get(f"{base_url}/health")
        print(f"✓ GET /health - Status: {response.status_code}")
        
        print("\nFastAPI tests passed!")
        return True
    
    except requests.exceptions.ConnectionError:
        print("✗ FastAPI not running!")
        print(f"  Start it with: python 02_fastapi_basics_beginner.py")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_model_serving(port=5000):
    """Test model serving endpoint"""
    base_url = f"http://localhost:{port}"
    
    print("\nTesting Model Serving API...")
    print("=" * 50)
    
    try:
        # Test prediction
        data = {
            "sepal_length": 5.1,
            "sepal_width": 3.5,
            "petal_length": 1.4,
            "petal_width": 0.2
        }
        
        response = requests.post(f"{base_url}/predict", json=data)
        print(f"✓ POST /predict - Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"  Prediction: {result.get('prediction')}")
            print(f"  Confidence: {result.get('confidence')}")
        
        print("\nModel serving tests passed!")
        return True
    
    except requests.exceptions.ConnectionError:
        print("✗ Model serving API not running!")
        print(f"  Start it with: python 03_sklearn_model_serving_beginner.py")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def main():
    """Run all tests"""
    print("\n" + "=" * 50)
    print("API Testing Tool")
    print("=" * 50)
    print("\nMake sure your API is running before testing!")
    print("This script will try to connect to running servers.\n")
    
    if len(sys.argv) > 1:
        test_type = sys.argv[1]
        if test_type == "flask":
            test_flask_api()
        elif test_type == "fastapi":
            test_fastapi()
        elif test_type == "model":
            test_model_serving()
        else:
            print(f"Unknown test type: {test_type}")
            print("Usage: python test_apis.py [flask|fastapi|model]")
    else:
        print("Usage: python test_apis.py [flask|fastapi|model]")
        print("\nExample:")
        print("  python test_apis.py flask")
        print("  python test_apis.py fastapi")
        print("  python test_apis.py model")

if __name__ == "__main__":
    main()
