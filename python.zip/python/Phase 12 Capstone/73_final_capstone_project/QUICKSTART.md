# Quick Start Guide

Get up and running with the Weather Data Analytics Pipeline in 5 minutes!

## Prerequisites

- Python 3.9+ installed
- pip package manager
- OpenWeatherMap API key (free tier: https://openweathermap.org/api)

## 1. Setup Environment

```bash
# Navigate to project directory
cd 64_final_capstone_project

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 2. Configure API Key

Get your free API key from https://openweathermap.org/api, then:

```bash
# On macOS/Linux:
export OPENWEATHER_API_KEY='your_api_key_here'

# On Windows:
set OPENWEATHER_API_KEY=your_api_key_here
```

Or create a `.env` file:
```
OPENWEATHER_API_KEY=your_api_key_here
```

## 3. Try the Examples

### Level 1: Beginner

Run individual examples to learn concepts:

```bash
# Basic API usage
python level_1_beginner/simple_api.py

# Database operations
python level_1_beginner/simple_database.py

# Data analysis
python level_1_beginner/simple_analysis.py

# Visualization
python level_1_beginner/simple_visualization.py
```

### Level 3: Advanced (Full Pipeline)

```bash
# Fetch weather data for cities
python -m level_3_advanced.main fetch "London" "New York" "Tokyo"

# Analyze a city
python -m level_3_advanced.main analyze --city "London" --days 7

# Show database statistics
python -m level_3_advanced.main stats
```

## 4. Run Tests

```bash
# Run all tests
pytest

# Run with coverage report
pytest --cov=level_3_advanced --cov-report=html

# View coverage report
open htmlcov/index.html  # macOS
# or
start htmlcov/index.html  # Windows
# or
xdg-open htmlcov/index.html  # Linux
```

## 5. Use Programmatically

```python
from level_3_advanced import WeatherPipeline, PipelineConfig

# Initialize pipeline
config = PipelineConfig(db_path="my_weather.db")
pipeline = WeatherPipeline(config)

# Fetch and store data
cities = ["London", "Paris", "Tokyo"]
results = pipeline.run_full_pipeline(cities, analyze=True)

# View results
print(f"Successful: {results['successful_fetches']}")
for city, summary in results['summaries'].items():
    print(f"{city}: {summary['avg_temperature']:.1f}°C")
```

## Common Issues

### API Key Error
```
❌ API key is required
```
**Solution**: Set the `OPENWEATHER_API_KEY` environment variable

### Import Error
```
ModuleNotFoundError: No module named 'requests'
```
**Solution**: Install dependencies with `pip install -r requirements.txt`

### Database Locked
```
sqlite3.OperationalError: database is locked
```
**Solution**: Close other connections to the database

## Next Steps

1. Read the full README.md for detailed documentation
2. Review TOPICS_COVERAGE.md to see how each topic is implemented
3. Explore Level 2 for intermediate implementations
4. Modify and extend the code for your own projects

## Learning Path

Recommended order for students:

1. **Level 1** files (one by one) - Learn individual concepts
2. **Level 2** files - See concepts combined
3. **Level 3** package - Production-ready integration
4. **Tests** - Learn testing practices
5. **Build your own project** using this as a template!

## Resources

- OpenWeatherMap API: https://openweathermap.org/api
- pandas docs: https://pandas.pydata.org/docs/
- matplotlib gallery: https://matplotlib.org/stable/gallery/
- pytest docs: https://docs.pytest.org/
- Type hints: https://docs.python.org/3/library/typing.html

---

**Happy coding! 🚀**
