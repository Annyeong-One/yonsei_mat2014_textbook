"""
Setup script for Weather Data Analytics Pipeline package.
Demonstrates package structure (Topics 37-38).
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read README for long description
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

# Read requirements
requirements_file = Path(__file__).parent / "requirements.txt"
if requirements_file.exists():
    with open(requirements_file) as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith("#")]
else:
    requirements = []

setup(
    # Package metadata
    name="weather-analytics-pipeline",
    version="1.0.0",
    author="Student Name",
    author_email="student@university.edu",
    description="A complete data analytics pipeline for weather data",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/username/weather-analytics-pipeline",
    
    # Package discovery
    packages=find_packages(exclude=["tests", "tests.*"]),
    
    # Python version requirement
    python_requires=">=3.9",
    
    # Dependencies
    install_requires=requirements,
    
    # Optional dependencies
    extras_require={
        "dev": [
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
        ],
        "postgresql": [
            "psycopg2-binary>=2.9.0",
        ],
        "web": [
            "flask>=3.0.0",
        ],
    },
    
    # Package classification
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Atmospheric Science",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    
    # Keywords for discovery
    keywords="weather data-science analytics pipeline education",
    
    # Entry points for CLI
    entry_points={
        "console_scripts": [
            "weather-pipeline=level_3_advanced.main:main",
        ],
    },
    
    # Include non-Python files
    include_package_data=True,
    zip_safe=False,
)
