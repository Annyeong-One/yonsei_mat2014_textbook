# Python Functions

## Table of Contents
1. [Introduction](#introduction)
2. [Defining Functions](#defining-functions)
3. [Function Parameters](#function-parameters)
4. [Return Values](#return-values)
5. [Scope and Lifetime](#scope-and-lifetime)
6. [Default Parameters](#default-parameters)
7. [Keyword Arguments](#keyword-arguments)
8. [Variable-Length Arguments](#variable-length-arguments)
9. [Lambda Functions](#lambda-functions)
10. [Docstrings](#docstrings)
11. [Best Practices](#best-practices)

---

## Introduction

**Functions** are reusable blocks of code that perform specific tasks. They help organize code, reduce repetition, and make programs more maintainable.

### Why Functions Matter

- **Reusability**: Write once, use many times
- **Organization**: Break complex problems into smaller pieces
- **Maintainability**: Update code in one place
- **Testing**: Test individual components
- **Abstraction**: Hide implementation details

---

## Defining Functions

### Syntax

```python
def function_name(parameters):
    """Docstring (optional but recommended)"""
    # Function body
    return value  # Optional
```

### Basic Example

```python
def greet():
    print("Hello, World!")

# Call the function
greet()  # Output: Hello, World!
```

### Key Components

1. **`def` keyword**: Starts function definition
2. **Function name**: Follows variable naming rules
3. **Parameters** (optional): Input values in parentheses
4. **Colon**: Ends function signature
5. **Body**: Indented code block
6. **Return** (optional): Send value back to caller

---

## Function Parameters

Parameters allow functions to accept input values.

### Positional Parameters

```python
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")  # Hello, Alice!
greet("Bob")    # Hello, Bob!
```

### Multiple Parameters

```python
def add(a, b):
    return a + b

result = add(5, 3)
print(result)  # 8
```

### Parameters vs Arguments

- **Parameter**: Variable in function definition
- **Argument**: Actual value passed when calling

```python
def greet(name):  # 'name' is a parameter
    print(f"Hello, {name}!")

greet("Alice")  # "Alice" is an argument
```

---

## Return Values

Functions can send values back using `return`.

### Basic Return

```python
def square(x):
    return x ** 2

result = square(5)
print(result)  # 25
```

### Multiple Return Values

```python
def get_min_max(numbers):
    return min(numbers), max(numbers)

minimum, maximum = get_min_max([1, 5, 3, 9, 2])
print(f"Min: {minimum}, Max: {maximum}")
```

### Return vs Print

```python
# With return (better)
def add(a, b):
    return a + b

result = add(3, 4)  # Can use result later
print(result * 2)   # 14

# With print (limited)
def add_print(a, b):
    print(a + b)

result = add_print(3, 4)  # Prints 7, but returns None
print(result)  # None
```

### Early Return

```python
def is_adult(age):
    if age < 0:
        return "Invalid age"
    if age >= 18:
        return True
    return False
```

---

## Scope and Lifetime

### Local Scope

```python
def my_function():
    x = 10  # Local variable
    print(x)

my_function()  # 10
# print(x)  # Error: x doesn't exist here
```

### Global Scope

```python
x = 10  # Global variable

def my_function():
    print(x)  # Can read global

my_function()  # 10
```

### Modifying Global Variables

```python
counter = 0  # Global

def increment():
    global counter  # Declare global
    counter += 1

increment()
print(counter)  # 1
```

### Best Practice: Avoid Globals

```python
# ❌ BAD - Using global
total = 0
def add_to_total(x):
    global total
    total += x

# ✅ GOOD - Pass as parameter
def add_to_total(total, x):
    return total + x
```

---

## Default Parameters

Provide default values for parameters.

### Syntax

```python
def greet(name="Guest"):
    print(f"Hello, {name}!")

greet()          # Hello, Guest!
greet("Alice")   # Hello, Alice!
```

### Multiple Defaults

```python
def power(base, exponent=2):
    return base ** exponent

print(power(5))      # 25 (5^2)
print(power(5, 3))   # 125 (5^3)
```

### Important: Mutable Defaults

```python
# ❌ DANGEROUS - Mutable default
def append_to(element, target=[]):
    target.append(element)
    return target

print(append_to(1))  # [1]
print(append_to(2))  # [1, 2] - Oops!

# ✅ CORRECT - Use None
def append_to(element, target=None):
    if target is None:
        target = []
    target.append(element)
    return target

print(append_to(1))  # [1]
print(append_to(2))  # [2] - Correct!
```

---

## Keyword Arguments

Pass arguments by parameter name.

### Benefits

- Order doesn't matter
- More readable
- Can skip defaults

```python
def describe_person(name, age, city):
    print(f"{name} is {age} years old and lives in {city}")

# Positional
describe_person("Alice", 30, "NYC")

# Keyword arguments
describe_person(city="NYC", name="Alice", age=30)

# Mixed (positional first)
describe_person("Alice", city="NYC", age=30)
```

---

## Variable-Length Arguments

### *args - Variable Positional Arguments

```python
def sum_all(*numbers):
    total = 0
    for num in numbers:
        total += num
    return total

print(sum_all(1, 2, 3))        # 6
print(sum_all(1, 2, 3, 4, 5))  # 15
```

### **kwargs - Variable Keyword Arguments

```python
def print_info(**kwargs):
    for key, value in kwargs.items():
        print(f"{key}: {value}")

print_info(name="Alice", age=30, city="NYC")
```

### Combining All Types

```python
def complex_function(pos1, pos2, *args, default=10, **kwargs):
    print(f"Positional: {pos1}, {pos2}")
    print(f"*args: {args}")
    print(f"Default: {default}")
    print(f"**kwargs: {kwargs}")

complex_function(1, 2, 3, 4, default=20, extra="info")
```

---

## Lambda Functions

Anonymous, one-line functions.

### Syntax

```python
lambda parameters: expression
```

### Examples

```python
# Regular function
def square(x):
    return x ** 2

# Lambda equivalent
square = lambda x: x ** 2

# With multiple parameters
add = lambda x, y: x + y
print(add(3, 4))  # 7
```

### Common Use Cases

```python
# Sorting
points = [(1, 2), (3, 1), (5, 0)]
points.sort(key=lambda p: p[1])
print(points)  # [(5, 0), (3, 1), (1, 2)]

# Mapping
numbers = [1, 2, 3, 4, 5]
squared = list(map(lambda x: x**2, numbers))
print(squared)  # [1, 4, 9, 16, 25]

# Filtering
numbers = [1, 2, 3, 4, 5, 6]
evens = list(filter(lambda x: x % 2 == 0, numbers))
print(evens)  # [2, 4, 6]
```

---

## Docstrings

Document your functions with docstrings.

### Format

```python
def function_name(param1, param2):
    """
    Brief description.
    
    Detailed description (optional).
    
    Args:
        param1: Description of param1
        param2: Description of param2
    
    Returns:
        Description of return value
    """
    return result
```

### Example

```python
def calculate_area(length, width):
    """
    Calculate area of a rectangle.
    
    Args:
        length: Length of rectangle
        width: Width of rectangle
    
    Returns:
        Area as a float
    """
    return length * width

# Access docstring
print(calculate_area.__doc__)
```

---

## Best Practices

### 1. Single Responsibility

```python
# ❌ BAD - Does too much
def process_data(data):
    # Clean data
    # Analyze data
    # Save to file
    # Send email
    pass

# ✅ GOOD - One task per function
def clean_data(data):
    # Just clean
    pass

def analyze_data(data):
    # Just analyze
    pass
```

### 2. Meaningful Names

```python
# ❌ BAD
def func(x, y):
    return x + y

# ✅ GOOD
def calculate_total_price(item_price, tax_rate):
    return item_price * (1 + tax_rate)
```

### 3. Keep Functions Short

```python
# Aim for ~20 lines or less
# If longer, consider breaking into smaller functions
```

### 4. Use Type Hints (Python 3.5+)

```python
def greet(name: str) -> str:
    return f"Hello, {name}!"

def add(a: int, b: int) -> int:
    return a + b
```

### 5. Avoid Side Effects

```python
# ❌ BAD - Modifies global state
total = 0
def add_to_total(x):
    global total
    total += x

# ✅ GOOD - Pure function
def add(a, b):
    return a + b
```

---

## Summary

### Key Takeaways

- Functions organize code into reusable blocks
- Use `def` to define functions
- Parameters accept input, `return` sends output
- Default parameters provide flexibility
- `*args` and `**kwargs` allow variable arguments
- Lambda for simple, one-line functions
- Docstrings document your functions
- Keep functions focused and well-named

### Function Template

```python
def function_name(required_param, default_param=default_value):
    """
    Brief description.
    
    Args:
        required_param: Description
        default_param: Description
    
    Returns:
        Description
    """
    # Function body
    result = required_param + default_param
    return result
```

---

## Next Steps

Master functions, then learn about:
- Modules and packages
- Object-Oriented Programming
- Decorators
- Generators

Practice makes perfect!
