"""
Python Functions - Practice Exercises
"""

print("Exercise 1: Create a Greeting Function")
print("-"*60)
print("Task: Create function greet(name) that prints 'Hello, {name}!'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 2: Calculator Function")
print("-"*60)
print("Task: Create multiply(a, b) that returns a * b")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 3: Is Positive")
print("-"*60)
print("Task: Create is_positive(num) that returns True if num > 0")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 4: Find Maximum")
print("-"*60)
print("Task: Create find_max(a, b, c) returning largest of three numbers")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 5: Calculate Area")
print("-"*60)
print("Task: Create circle_area(radius) that returns π*r²")
print("Use 3.14159 for π")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 6: Count Vowels")
print("-"*60)
print("Task: Create count_vowels(text) that returns vowel count")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 7: Default Parameter")
print("-"*60)
print("Task: Create power(base, exponent=2) that returns base^exponent")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 8: List Sum")
print("-"*60)
print("Task: Create sum_list(numbers) that returns sum of list")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 9: Temperature Converter")
print("-"*60)
print("Task: Create fahrenheit_to_celsius(f) converting F to C")
print("Formula: C = (F - 32) * 5/9")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 10: Is Palindrome")
print("-"*60)
print("Task: Create is_palindrome(text) checking if text reads same forwards/backwards")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 11: Factorial")
print("-"*60)
print("Task: Create factorial(n) calculating n! (n * (n-1) * ... * 1)")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 12: Variable Arguments")
print("-"*60)
print("Task: Create average(*numbers) calculating average of any number of args")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 13: Grade Calculator")
print("-"*60)
print("Task: Create get_grade(score) returning letter grade")
print("90+: A, 80-89: B, 70-79: C, 60-69: D, Below 60: F")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 14: Lambda for Squaring")
print("-"*60)
print("Task: Create a lambda function that squares a number")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 15: FizzBuzz Function")
print("-"*60)
print("Task: Create fizzbuzz(n) that prints:")
print("Numbers 1 to n, but 'Fizz' for multiples of 3,")
print("'Buzz' for multiples of 5, 'FizzBuzz' for both")
print()
# Write your code below:


print("\n"+"="*60+"\n")
print("Exercises completed! Check solutions.py")
