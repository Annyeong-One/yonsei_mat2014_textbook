"""
Python Functions - Exercise Solutions
"""

print("="*60)
print("Exercise 1 Solution")
print("="*60)
def greet(name):
    print(f"Hello, {name}!")
greet("Alice")
print()

print("="*60)
print("Exercise 2 Solution")
print("="*60)
def multiply(a, b):
    return a * b
print(f"5 × 3 = {multiply(5, 3)}")
print()

print("="*60)
print("Exercise 3 Solution")
print("="*60)
def is_positive(num):
    return num > 0
print(f"5 is positive: {is_positive(5)}")
print(f"-3 is positive: {is_positive(-3)}")
print()

print("="*60)
print("Exercise 4 Solution")
print("="*60)
def find_max(a, b, c):
    return max(a, b, c)
print(f"Max of 5, 12, 8: {find_max(5, 12, 8)}")
print()

print("="*60)
print("Exercise 5 Solution")
print("="*60)
def circle_area(radius):
    return 3.14159 * radius ** 2
print(f"Area of circle (r=5): {circle_area(5):.2f}")
print()

print("="*60)
print("Exercise 6 Solution")
print("="*60)
def count_vowels(text):
    vowels = "aeiouAEIOU"
    count = 0
    for char in text:
        if char in vowels:
            count += 1
    return count
print(f"Vowels in 'Hello World': {count_vowels('Hello World')}")
print()

print("="*60)
print("Exercise 7 Solution")
print("="*60)
def power(base, exponent=2):
    return base ** exponent
print(f"5^2 = {power(5)}")
print(f"2^5 = {power(2, 5)}")
print()

print("="*60)
print("Exercise 8 Solution")
print("="*60)
def sum_list(numbers):
    return sum(numbers)
print(f"Sum of [1,2,3,4,5]: {sum_list([1,2,3,4,5])}")
print()

print("="*60)
print("Exercise 9 Solution")
print("="*60)
def fahrenheit_to_celsius(f):
    return (f - 32) * 5/9
print(f"77°F = {fahrenheit_to_celsius(77):.1f}°C")
print()

print("="*60)
print("Exercise 10 Solution")
print("="*60)
def is_palindrome(text):
    text = text.lower().replace(" ", "")
    return text == text[::-1]
print(f"'racecar' is palindrome: {is_palindrome('racecar')}")
print(f"'hello' is palindrome: {is_palindrome('hello')}")
print()

print("="*60)
print("Exercise 11 Solution")
print("="*60)
def factorial(n):
    if n <= 1:
        return 1
    result = 1
    for i in range(2, n+1):
        result *= i
    return result
print(f"5! = {factorial(5)}")
print()

print("="*60)
print("Exercise 12 Solution")
print("="*60)
def average(*numbers):
    if len(numbers) == 0:
        return 0
    return sum(numbers) / len(numbers)
print(f"Average of 1,2,3,4,5: {average(1,2,3,4,5)}")
print()

print("="*60)
print("Exercise 13 Solution")
print("="*60)
def get_grade(score):
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "F"
print(f"Score 85: Grade {get_grade(85)}")
print()

print("="*60)
print("Exercise 14 Solution")
print("="*60)
square = lambda x: x ** 2
print(f"Square of 7: {square(7)}")
print()

print("="*60)
print("Exercise 15 Solution")
print("="*60)
def fizzbuzz(n):
    for i in range(1, n+1):
        if i % 15 == 0:
            print("FizzBuzz")
        elif i % 3 == 0:
            print("Fizz")
        elif i % 5 == 0:
            print("Buzz")
        else:
            print(i)
fizzbuzz(15)
print()

print("="*60)
print("All solutions completed!")
print("="*60)
print("\nKey Takeaways:")
print("✓ Functions organize code into reusable blocks")
print("✓ Parameters allow input, return provides output")
print("✓ Default parameters add flexibility")
print("✓ *args and **kwargs handle variable arguments")
print("✓ Lambda for simple, one-line functions")
print("✓ Good naming and documentation are crucial")
