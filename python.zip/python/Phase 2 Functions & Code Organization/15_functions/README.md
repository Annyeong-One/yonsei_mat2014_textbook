# Python Functions

## 📚 Contents

1. **01_tutorial.md** - Comprehensive guide to functions
2. **02_examples.py** - 15 practical demonstrations
3. **03_exercises.py** - 15 practice exercises
4. **04_solutions.py** - Detailed solutions

## 🎯 Learning Objectives

- ✅ Define and call functions
- ✅ Use parameters and return values
- ✅ Understand scope (local vs global)
- ✅ Apply default parameters
- ✅ Use keyword arguments
- ✅ Work with *args and **kwargs
- ✅ Create lambda functions
- ✅ Write clear docstrings

## 🚀 Quick Start

```bash
python 02_examples.py
python 03_exercises.py
python 04_solutions.py
```

## 💡 Key Concepts

### Basic Function
```python
def function_name(parameters):
    # code
    return value
```

### With Default Parameter
```python
def greet(name="Guest"):
    return f"Hello, {name}!"
```

### Variable Arguments
```python
def sum_all(*args):
    return sum(args)
```

### Lambda Function
```python
square = lambda x: x ** 2
```

## ⏱️ Time: ~2-3 hours

## 🎓 Why Functions Matter

- **Reusability**: Write once, use many times
- **Organization**: Break complex problems down
- **Maintainability**: Update in one place
- **Testing**: Test components independently

## 📖 Topics Covered

- Function definition and calling
- Parameters and arguments
- Return values
- Scope and lifetime
- Default parameters
- Keyword arguments
- *args and **kwargs
- Lambda functions
- Docstrings
- Best practices

## 🔗 Complete Learning Path

```
Variables → Data Types → Operators → 
Control Flow → Loops → Functions → ...
                        ↑ YOU ARE HERE
```

Happy Coding! 🐍
