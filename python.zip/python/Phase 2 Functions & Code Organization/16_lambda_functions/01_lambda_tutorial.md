# Lambda Functions Tutorial

## What are Lambda Functions?

Lambda functions (also called anonymous functions) are small, one-line functions defined without a name. They're perfect for simple operations that you don't need to reuse elsewhere in your code.

## Syntax

```python
lambda arguments: expression
```

- **lambda**: The keyword that defines a lambda function
- **arguments**: Input parameters (can be zero or more)
- **expression**: A single expression that gets evaluated and returned

## Basic Examples

### Example 1: Simple Lambda
```python
# Regular function
def square(x):
    return x ** 2

# Lambda equivalent
square_lambda = lambda x: x ** 2

print(square_lambda(5))  # Output: 25
```

### Example 2: Multiple Parameters
```python
# Lambda with two parameters
add = lambda x, y: x + y
print(add(3, 5))  # Output: 8

# Lambda with three parameters
multiply_three = lambda x, y, z: x * y * z
print(multiply_three(2, 3, 4))  # Output: 24
```

### Example 3: No Parameters
```python
# Lambda with no parameters
get_pi = lambda: 3.14159
print(get_pi())  # Output: 3.14159
```

## Common Use Cases

### 1. With map()
Apply a function to every item in a list.

```python
numbers = [1, 2, 3, 4, 5]
squared = list(map(lambda x: x ** 2, numbers))
print(squared)  # Output: [1, 4, 9, 16, 25]
```

### 2. With filter()
Filter items based on a condition.

```python
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
evens = list(filter(lambda x: x % 2 == 0, numbers))
print(evens)  # Output: [2, 4, 6, 8, 10]
```

### 3. With sorted()
Custom sorting logic.

```python
students = [
    {'name': 'Alice', 'grade': 85},
    {'name': 'Bob', 'grade': 92},
    {'name': 'Charlie', 'grade': 78}
]

# Sort by grade
sorted_students = sorted(students, key=lambda student: student['grade'])
print(sorted_students)
```

### 4. With reduce()
Combine all elements using a function.

```python
from functools import reduce

numbers = [1, 2, 3, 4, 5]
product = reduce(lambda x, y: x * y, numbers)
print(product)  # Output: 120 (1*2*3*4*5)
```

## Lambda vs Regular Functions

### When to Use Lambda:
- Simple, one-line operations
- Used once (throwaway function)
- As arguments to higher-order functions (map, filter, sorted)
- When readability isn't compromised

### When to Use Regular Functions:
- Complex logic requiring multiple statements
- Functions you'll reuse multiple times
- When you need documentation (docstrings)
- When debugging is important (lambdas are harder to debug)

## Important Limitations

1. **Single Expression Only**: Lambdas can only contain one expression, not statements.
   ```python
   # This won't work:
   # lambda x: if x > 0: return x
   
   # This works:
   lambda x: x if x > 0 else 0
   ```

2. **No Type Hints**: Lambda functions don't support type annotations.

3. **Limited Readability**: Complex lambdas can be hard to read.
   ```python
   # Hard to read
   result = lambda x: x if x % 2 == 0 else x * 2 if x % 3 == 0 else x + 1
   
   # Better as a regular function
   def process_number(x):
       if x % 2 == 0:
           return x
       elif x % 3 == 0:
           return x * 2
       else:
           return x + 1
   ```

## Best Practices

1. **Keep it Simple**: If your lambda is getting complex, use a regular function
2. **Use Descriptive Variable Names**: Even in lambdas
3. **Don't Assign Lambdas to Variables**: If you're doing this, just use def
   ```python
   # Avoid this
   square = lambda x: x ** 2
   
   # Prefer this
   def square(x):
       return x ** 2
   ```

## Practice Questions

1. Write a lambda function that takes a temperature in Celsius and converts it to Fahrenheit.
2. Use a lambda with `filter()` to get all strings longer than 5 characters from a list.
3. Use a lambda with `sorted()` to sort a list of tuples by the second element.
4. Write a lambda that takes two numbers and returns the larger one.
5. Use `map()` with a lambda to convert a list of strings to uppercase.

## Summary

Lambda functions are powerful tools for writing concise, functional-style Python code. They shine when used with functions like `map()`, `filter()`, and `sorted()`, but should be reserved for simple operations where readability isn't sacrificed.
