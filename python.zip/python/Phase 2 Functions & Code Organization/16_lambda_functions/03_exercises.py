"""
Lambda Functions - Practice Exercises

Complete these exercises to practice using lambda functions.
Try to solve them on your own before checking the solutions file!
"""

print("=" * 70)
print("LAMBDA FUNCTIONS - PRACTICE EXERCISES")
print("=" * 70)

# ========================================================================
# EXERCISE 1: Basic Lambda Functions
# ========================================================================
print("\nEXERCISE 1: Basic Lambda Functions")
print("-" * 70)
print("Create lambda functions to perform the following operations:")
print("a) Calculate the area of a circle (π * r²)")
print("b) Convert kilometers to miles (1 km = 0.621371 miles)")
print("c) Check if a number is even (return True or False)")
print("d) Concatenate two strings with a space between them")

# Your code here:
# area_circle = 
# km_to_miles = 
# is_even = 
# concat_strings = 

# Test your functions:
# print(f"Area of circle with radius 5: {area_circle(5)}")
# print(f"10 km in miles: {km_to_miles(10)}")
# print(f"Is 8 even? {is_even(8)}")
# print(f"Concat 'Hello' and 'World': {concat_strings('Hello', 'World')}")

# ========================================================================
# EXERCISE 2: Lambda with map()
# ========================================================================
print("\n\nEXERCISE 2: Lambda with map()")
print("-" * 70)
print("Use map() with lambda functions for the following tasks:")

# a) Square all numbers in the list
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(f"a) Square these numbers: {numbers}")
# squared = 
# print(f"   Result: {squared}")

# b) Convert these names to title case
names = ["alice", "bob", "charlie", "DAVID", "eve"]
print(f"\nb) Convert to title case: {names}")
# title_names = 
# print(f"   Result: {title_names}")

# c) Add 10 to each number
values = [5, 15, 25, 35, 45]
print(f"\nc) Add 10 to each: {values}")
# added = 
# print(f"   Result: {added}")

# d) Get the length of each word
words = ["Python", "programming", "is", "fun"]
print(f"\nd) Get length of each word: {words}")
# lengths = 
# print(f"   Result: {lengths}")

# ========================================================================
# EXERCISE 3: Lambda with filter()
# ========================================================================
print("\n\nEXERCISE 3: Lambda with filter()")
print("-" * 70)
print("Use filter() with lambda functions for the following tasks:")

# a) Filter positive numbers
numbers = [-5, 3, -1, 7, -3, 9, -7, 2, 0]
print(f"a) Get positive numbers from: {numbers}")
# positive = 
# print(f"   Result: {positive}")

# b) Filter strings that start with 'P'
words = ["Python", "Java", "PHP", "C++", "Perl", "Ruby"]
print(f"\nb) Get words starting with 'P': {words}")
# p_words = 
# print(f"   Result: {p_words}")

# c) Filter numbers divisible by 3
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
print(f"\nc) Get numbers divisible by 3: {numbers}")
# div_by_3 = 
# print(f"   Result: {div_by_3}")

# d) Filter palindromes
words = ["radar", "hello", "level", "world", "noon", "python"]
print(f"\nd) Get palindromes: {words}")
# palindromes = 
# print(f"   Result: {palindromes}")

# ========================================================================
# EXERCISE 4: Lambda with sorted()
# ========================================================================
print("\n\nEXERCISE 4: Lambda with sorted()")
print("-" * 70)
print("Use sorted() with lambda functions for the following tasks:")

# a) Sort by absolute value
numbers = [-5, 3, -1, 7, -3, 9, -7, 2]
print(f"a) Sort by absolute value: {numbers}")
# sorted_abs = 
# print(f"   Result: {sorted_abs}")

# b) Sort strings by last character
words = ["apple", "banana", "cherry", "date", "fig"]
print(f"\nb) Sort by last character: {words}")
# sorted_last = 
# print(f"   Result: {sorted_last}")

# c) Sort list of tuples by second element (descending)
data = [("Alice", 85), ("Bob", 92), ("Charlie", 78), ("Diana", 95)]
print(f"\nc) Sort by grade (descending): {data}")
# sorted_grades = 
# print(f"   Result: {sorted_grades}")

# d) Sort dictionaries by age
people = [
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25},
    {"name": "Charlie", "age": 35},
    {"name": "Diana", "age": 28}
]
print(f"\nd) Sort people by age: {people}")
# sorted_people = 
# print(f"   Result: {sorted_people}")

# ========================================================================
# EXERCISE 5: Lambda with reduce()
# ========================================================================
print("\n\nEXERCISE 5: Lambda with reduce()")
print("-" * 70)
print("Use reduce() with lambda functions for the following tasks:")
print("Remember to import reduce from functools!")

# from functools import reduce

# a) Find the product of all numbers
numbers = [2, 3, 4, 5]
print(f"a) Find product of: {numbers}")
# product = 
# print(f"   Result: {product}")

# b) Find the maximum value
values = [23, 67, 12, 89, 45, 34]
print(f"\nb) Find maximum of: {values}")
# maximum = 
# print(f"   Result: {maximum}")

# c) Concatenate all words with ' | ' separator
words = ["apple", "banana", "cherry", "date"]
print(f"\nc) Join with ' | ': {words}")
# joined = 
# print(f"   Result: {joined}")

# ========================================================================
# EXERCISE 6: Challenge Problems
# ========================================================================
print("\n\nEXERCISE 6: Challenge Problems")
print("-" * 70)

# a) Create a lambda that takes a list and returns the sum of squares of even numbers
print("a) Sum of squares of even numbers")
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
print(f"   Numbers: {numbers}")
# Hint: Use filter, map, and sum or reduce
# result = 
# print(f"   Result: {result}")

# b) Sort a list of strings by the number of vowels (descending)
print("\nb) Sort by vowel count (descending)")
words = ["hello", "world", "python", "programming", "data"]
print(f"   Words: {words}")
# Hint: Create a helper lambda to count vowels
# sorted_words = 
# print(f"   Result: {sorted_words}")

# c) Use map and filter to get squares of odd numbers greater than 5
print("\nc) Squares of odd numbers > 5")
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
print(f"   Numbers: {numbers}")
# result = 
# print(f"   Result: {result}")

# d) Create a lambda that categorizes numbers as "small" (<10), "medium" (10-50), "large" (>50)
print("\nd) Categorize numbers")
numbers = [5, 15, 55, 8, 45, 100, 3, 75]
print(f"   Numbers: {numbers}")
# categorize = 
# categories = 
# print(f"   Result: {categories}")

print("\n" + "=" * 70)
print("END OF EXERCISES - Check solutions.py when you're done!")
print("=" * 70)
