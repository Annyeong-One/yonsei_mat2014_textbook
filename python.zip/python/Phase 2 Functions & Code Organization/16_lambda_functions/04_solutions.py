"""
Lambda Functions - Practice Exercise Solutions

Here are the solutions to the practice exercises.
Try to solve them yourself first before looking at these!
"""

print("=" * 70)
print("LAMBDA FUNCTIONS - SOLUTIONS")
print("=" * 70)

# ========================================================================
# EXERCISE 1: Basic Lambda Functions
# ========================================================================
print("\nEXERCISE 1: Basic Lambda Functions")
print("-" * 70)

import math

# a) Calculate the area of a circle
area_circle = lambda r: math.pi * r ** 2
print(f"a) Area of circle with radius 5: {area_circle(5):.2f}")

# b) Convert kilometers to miles
km_to_miles = lambda km: km * 0.621371
print(f"b) 10 km in miles: {km_to_miles(10):.2f}")

# c) Check if a number is even
is_even = lambda n: n % 2 == 0
print(f"c) Is 8 even? {is_even(8)}")
print(f"   Is 7 even? {is_even(7)}")

# d) Concatenate two strings with a space
concat_strings = lambda s1, s2: s1 + " " + s2
print(f"d) Concat 'Hello' and 'World': {concat_strings('Hello', 'World')}")

# ========================================================================
# EXERCISE 2: Lambda with map()
# ========================================================================
print("\n\nEXERCISE 2: Lambda with map()")
print("-" * 70)

# a) Square all numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
squared = list(map(lambda x: x ** 2, numbers))
print(f"a) Original: {numbers}")
print(f"   Squared: {squared}")

# b) Convert names to title case
names = ["alice", "bob", "charlie", "DAVID", "eve"]
title_names = list(map(lambda name: name.title(), names))
print(f"\nb) Original: {names}")
print(f"   Title case: {title_names}")

# c) Add 10 to each number
values = [5, 15, 25, 35, 45]
added = list(map(lambda x: x + 10, values))
print(f"\nc) Original: {values}")
print(f"   Added 10: {added}")

# d) Get length of each word
words = ["Python", "programming", "is", "fun"]
lengths = list(map(lambda word: len(word), words))
print(f"\nd) Words: {words}")
print(f"   Lengths: {lengths}")

# ========================================================================
# EXERCISE 3: Lambda with filter()
# ========================================================================
print("\n\nEXERCISE 3: Lambda with filter()")
print("-" * 70)

# a) Filter positive numbers
numbers = [-5, 3, -1, 7, -3, 9, -7, 2, 0]
positive = list(filter(lambda x: x > 0, numbers))
print(f"a) Original: {numbers}")
print(f"   Positive: {positive}")

# b) Filter strings that start with 'P'
words = ["Python", "Java", "PHP", "C++", "Perl", "Ruby"]
p_words = list(filter(lambda word: word.startswith('P'), words))
print(f"\nb) Original: {words}")
print(f"   Starts with 'P': {p_words}")

# c) Filter numbers divisible by 3
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
div_by_3 = list(filter(lambda x: x % 3 == 0, numbers))
print(f"\nc) Original: {numbers}")
print(f"   Divisible by 3: {div_by_3}")

# d) Filter palindromes
words = ["radar", "hello", "level", "world", "noon", "python"]
palindromes = list(filter(lambda word: word == word[::-1], words))
print(f"\nd) Original: {words}")
print(f"   Palindromes: {palindromes}")

# ========================================================================
# EXERCISE 4: Lambda with sorted()
# ========================================================================
print("\n\nEXERCISE 4: Lambda with sorted()")
print("-" * 70)

# a) Sort by absolute value
numbers = [-5, 3, -1, 7, -3, 9, -7, 2]
sorted_abs = sorted(numbers, key=lambda x: abs(x))
print(f"a) Original: {numbers}")
print(f"   Sorted by absolute value: {sorted_abs}")

# b) Sort strings by last character
words = ["apple", "banana", "cherry", "date", "fig"]
sorted_last = sorted(words, key=lambda word: word[-1])
print(f"\nb) Original: {words}")
print(f"   Sorted by last character: {sorted_last}")

# c) Sort list of tuples by second element (descending)
data = [("Alice", 85), ("Bob", 92), ("Charlie", 78), ("Diana", 95)]
sorted_grades = sorted(data, key=lambda student: student[1], reverse=True)
print(f"\nc) Original: {data}")
print(f"   Sorted by grade (descending): {sorted_grades}")

# d) Sort dictionaries by age
people = [
    {"name": "Alice", "age": 30},
    {"name": "Bob", "age": 25},
    {"name": "Charlie", "age": 35},
    {"name": "Diana", "age": 28}
]
sorted_people = sorted(people, key=lambda person: person["age"])
print(f"\nd) Original: {people}")
print(f"   Sorted by age: {sorted_people}")

# ========================================================================
# EXERCISE 5: Lambda with reduce()
# ========================================================================
print("\n\nEXERCISE 5: Lambda with reduce()")
print("-" * 70)

from functools import reduce

# a) Find product of all numbers
numbers = [2, 3, 4, 5]
product = reduce(lambda x, y: x * y, numbers)
print(f"a) Numbers: {numbers}")
print(f"   Product: {product}")

# b) Find maximum value
values = [23, 67, 12, 89, 45, 34]
maximum = reduce(lambda x, y: x if x > y else y, values)
print(f"\nb) Values: {values}")
print(f"   Maximum: {maximum}")

# c) Concatenate all words with ' | ' separator
words = ["apple", "banana", "cherry", "date"]
joined = reduce(lambda x, y: x + " | " + y, words)
print(f"\nc) Words: {words}")
print(f"   Joined: {joined}")

# ========================================================================
# EXERCISE 6: Challenge Problems
# ========================================================================
print("\n\nEXERCISE 6: Challenge Problems")
print("-" * 70)

# a) Sum of squares of even numbers
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
result = sum(map(lambda x: x ** 2, filter(lambda x: x % 2 == 0, numbers)))
print(f"a) Numbers: {numbers}")
print(f"   Sum of squares of even numbers: {result}")
print(f"   Breakdown: 2² + 4² + 6² + 8² + 10² = 4 + 16 + 36 + 64 + 100 = 220")

# b) Sort by vowel count (descending)
words = ["hello", "world", "python", "programming", "data"]
count_vowels = lambda word: sum(1 for char in word.lower() if char in 'aeiou')
sorted_words = sorted(words, key=count_vowels, reverse=True)
print(f"\nb) Words: {words}")
print(f"   Sorted by vowel count (descending): {sorted_words}")
for word in sorted_words:
    print(f"   {word}: {count_vowels(word)} vowels")

# c) Squares of odd numbers greater than 5
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
result = list(map(lambda x: x ** 2, filter(lambda x: x % 2 != 0 and x > 5, numbers)))
print(f"\nc) Numbers: {numbers}")
print(f"   Squares of odd numbers > 5: {result}")

# d) Categorize numbers
numbers = [5, 15, 55, 8, 45, 100, 3, 75]
categorize = lambda n: "small" if n < 10 else "medium" if n <= 50 else "large"
categories = list(map(categorize, numbers))
print(f"\nd) Numbers: {numbers}")
print(f"   Categories: {categories}")
for num, cat in zip(numbers, categories):
    print(f"   {num} -> {cat}")

print("\n" + "=" * 70)
print("END OF SOLUTIONS")
print("=" * 70)

# ========================================================================
# BONUS: Additional Insights
# ========================================================================
print("\n\nBONUS INSIGHTS:")
print("-" * 70)
print("""
Key Takeaways:
1. Lambdas are perfect for simple, one-line operations
2. They work great with map(), filter(), sorted(), and reduce()
3. For complex logic, use regular functions instead
4. Readability should never be sacrificed for brevity
5. Lambda functions can be composed and chained

Common Patterns:
- map(lambda x: expression, iterable) - Transform elements
- filter(lambda x: condition, iterable) - Select elements
- sorted(iterable, key=lambda x: expression) - Custom sorting
- reduce(lambda x, y: operation, iterable) - Aggregate values

Practice makes perfect! Try creating your own lambda functions
for everyday coding tasks.
""")
