# Lambda Functions - Quick Reference Cheat Sheet

## Basic Syntax
```python
lambda arguments: expression
```

## Single Parameter
```python
square = lambda x: x ** 2
square(5)  # Returns 25
```

## Multiple Parameters
```python
add = lambda x, y: x + y
multiply = lambda x, y, z: x * y * z
```

## No Parameters
```python
get_pi = lambda: 3.14159
```

## Common Use Cases

### 1. map() - Transform all elements
```python
# Syntax
map(lambda x: expression, iterable)

# Examples
list(map(lambda x: x * 2, [1, 2, 3]))  # [2, 4, 6]
list(map(lambda x: x.upper(), ['a', 'b']))  # ['A', 'B']
list(map(lambda x: x ** 2, range(5)))  # [0, 1, 4, 9, 16]
```

### 2. filter() - Select specific elements
```python
# Syntax
filter(lambda x: condition, iterable)

# Examples
list(filter(lambda x: x > 0, [-2, 0, 3, -1, 5]))  # [3, 5]
list(filter(lambda x: x % 2 == 0, range(10)))  # [0, 2, 4, 6, 8]
list(filter(lambda x: len(x) > 3, ['hi', 'hello']))  # ['hello']
```

### 3. sorted() - Custom sorting
```python
# Syntax
sorted(iterable, key=lambda x: expression)

# Examples
sorted([3, 1, 4, 1, 5], key=lambda x: -x)  # [5, 4, 3, 1, 1]
sorted(['ab', 'a', 'abc'], key=lambda x: len(x))  # ['a', 'ab', 'abc']
sorted([('a', 2), ('b', 1)], key=lambda x: x[1])  # [('b', 1), ('a', 2)]
```

### 4. reduce() - Aggregate values
```python
from functools import reduce

# Syntax
reduce(lambda x, y: operation, iterable)

# Examples
reduce(lambda x, y: x + y, [1, 2, 3, 4])  # 10
reduce(lambda x, y: x * y, [1, 2, 3, 4])  # 24
reduce(lambda x, y: x if x > y else y, [3, 7, 2, 9])  # 9
```

## Conditional Expressions
```python
# if-else
lambda x: x if x > 0 else 0

# if-elif-else
lambda x: 'A' if x >= 90 else 'B' if x >= 80 else 'C'

# Boolean operations
lambda x: x > 0 and x < 10
lambda x: x % 2 == 0 or x % 3 == 0
```

## Working with Collections

### Lists
```python
# Sum of squares
sum(map(lambda x: x ** 2, [1, 2, 3]))  # 14

# Filter and transform
list(map(lambda x: x * 2, filter(lambda x: x > 2, [1, 2, 3, 4])))  # [6, 8]
```

### Tuples
```python
# Sort by second element
sorted([(1, 'z'), (2, 'a')], key=lambda x: x[1])  # [(2, 'a'), (1, 'z')]
```

### Dictionaries
```python
# Sort by value
sorted({'a': 3, 'b': 1}.items(), key=lambda x: x[1])  # [('b', 1), ('a', 3)]

# Extract values
list(map(lambda x: x['name'], [{'name': 'Alice'}, {'name': 'Bob'}]))  # ['Alice', 'Bob']
```

### Strings
```python
# Transform strings
list(map(lambda s: s.upper(), ['hello', 'world']))  # ['HELLO', 'WORLD']

# Filter by length
list(filter(lambda s: len(s) > 3, ['hi', 'hello']))  # ['hello']
```

## Common Patterns

### Chain operations
```python
# Filter then map
result = list(map(lambda x: x ** 2, filter(lambda x: x % 2 == 0, range(10))))
# [0, 4, 16, 36, 64]
```

### Multiple conditions
```python
# AND condition
filter(lambda x: x > 0 and x < 10, range(20))

# OR condition
filter(lambda x: x % 2 == 0 or x % 3 == 0, range(20))
```

### Nested lambdas
```python
# Lambda returning lambda
multiply_by = lambda x: lambda y: x * y
times_3 = multiply_by(3)
times_3(4)  # 12
```

## Quick Tips

✅ **DO:**
- Use for simple, one-line operations
- Use with map, filter, sorted, reduce
- Keep it readable

❌ **DON'T:**
- Use for complex logic (use def instead)
- Assign to variables unnecessarily
- Sacrifice readability for brevity

## Comparison

### Lambda vs Regular Function

```python
# Lambda (good for simple cases)
double = lambda x: x * 2

# Regular function (better for complex cases)
def double(x):
    """Double the input value."""
    return x * 2
```

## Practice Patterns

```python
# 1. Double all numbers
list(map(lambda x: x * 2, [1, 2, 3]))

# 2. Get even numbers
list(filter(lambda x: x % 2 == 0, [1, 2, 3, 4]))

# 3. Sort by length
sorted(['aaa', 'b', 'cc'], key=lambda x: len(x))

# 4. Sum all numbers
from functools import reduce
reduce(lambda x, y: x + y, [1, 2, 3, 4])

# 5. Convert to uppercase
list(map(lambda s: s.upper(), ['a', 'b', 'c']))

# 6. Filter positive numbers
list(filter(lambda x: x > 0, [-1, 2, -3, 4]))

# 7. Get absolute values
list(map(lambda x: abs(x), [-1, -2, 3]))

# 8. Check if all even
all(map(lambda x: x % 2 == 0, [2, 4, 6]))

# 9. Get first letter
list(map(lambda s: s[0], ['apple', 'banana']))

# 10. Count vowels
count_vowels = lambda s: sum(1 for c in s if c in 'aeiou')
```

## Remember
- Lambda is just shorthand for simple functions
- Readability matters more than brevity
- Use regular functions for anything complex
- Great with functional programming patterns
