# Lambda Functions - Learning Materials

Welcome to the Lambda Functions learning module! This package contains comprehensive materials to help you master lambda functions in Python.

## 📦 Package Contents

### 1. **01_lambda_tutorial.md**
A comprehensive tutorial covering:
- What lambda functions are
- Basic syntax and structure
- Common use cases with map(), filter(), sorted(), and reduce()
- Lambda vs regular functions
- Best practices and limitations
- Practice questions

### 2. **02_examples.py**
Practical, runnable examples demonstrating:
- Basic lambda syntax
- Lambda with map() for transformations
- Lambda with filter() for selections
- Lambda with sorted() for custom sorting
- Lambda with reduce() for aggregations
- Nested and complex lambdas
- Real-world scenarios

**To run:** `python 02_examples.py`

### 3. **03_exercises.py**
Practice exercises organized by difficulty:
- Basic lambda functions
- Using lambda with map()
- Using lambda with filter()
- Using lambda with sorted()
- Using lambda with reduce()
- Challenge problems

**To use:** Try to complete each exercise before checking the solutions!

### 4. **04_solutions.py**
Complete solutions to all exercises with:
- Working code for each problem
- Explanatory comments
- Breakdown of complex solutions
- Additional insights and tips

**To run:** `python 04_solutions.py`

### 5. **05_cheat_sheet.md**
Quick reference guide with:
- Syntax reminders
- Common patterns
- Quick examples for each use case
- Do's and don'ts
- Practice patterns you can try immediately

## 🎯 Learning Path

### For Beginners:
1. Read `01_lambda_tutorial.md` thoroughly
2. Run `02_examples.py` and study the output
3. Try `03_exercises.py` (start with Exercise 1)
4. Check your work against `04_solutions.py`
5. Keep `05_cheat_sheet.md` handy for reference

### For Quick Review:
1. Start with `05_cheat_sheet.md`
2. Run `02_examples.py` to see lambda in action
3. Try the challenge problems in `03_exercises.py`

### For Practice:
1. Complete all exercises in `03_exercises.py`
2. Run `04_solutions.py` to verify your answers
3. Modify examples in `02_examples.py` with your own data

## 💡 Key Concepts Covered

- **Lambda Syntax**: `lambda arguments: expression`
- **map()**: Transform all elements in a collection
- **filter()**: Select elements based on conditions
- **sorted()**: Custom sorting logic
- **reduce()**: Aggregate values into a single result
- **Conditional Expressions**: Using if-else in lambdas
- **Best Practices**: When to use (and not use) lambdas

## 🔧 Requirements

- Python 3.x
- No external packages required (uses only standard library)

## 📝 Tips for Success

1. **Start Simple**: Master basic lambdas before moving to complex patterns
2. **Run the Code**: Don't just read - execute the examples and experiment
3. **Practice Regularly**: Try creating lambdas for everyday coding tasks
4. **Prioritize Readability**: If a lambda is hard to read, use a regular function
5. **Use Real Data**: Apply these concepts to your own projects

## 🎓 Learning Objectives

After completing this module, you should be able to:
- ✅ Write basic lambda functions with multiple parameters
- ✅ Use lambda with map(), filter(), sorted(), and reduce()
- ✅ Choose between lambda and regular functions appropriately
- ✅ Apply lambda functions to real-world programming tasks
- ✅ Understand when lambdas improve (or hurt) code readability

## 🚀 Next Steps

After mastering lambda functions, consider exploring:
- List comprehensions (often more Pythonic than map/filter)
- Generator expressions
- Decorators and closures
- Functional programming concepts
- Advanced iterator tools (itertools module)

## 📚 Additional Resources

- Python Official Documentation: https://docs.python.org/3/tutorial/controlflow.html#lambda-expressions
- Real Python Lambda Tutorial: https://realpython.com/python-lambda/
- Functional Programming in Python: https://docs.python.org/3/howto/functional.html

## ❓ Common Questions

**Q: Should I use lambdas or regular functions?**
A: Use lambdas for simple, one-line operations (especially with map/filter/sorted). Use regular functions for anything complex or reusable.

**Q: Can lambdas have multiple statements?**
A: No, lambdas can only contain a single expression. Use a regular function for multiple statements.

**Q: Are lambdas faster than regular functions?**
A: No significant performance difference. Choose based on readability and code style.

**Q: Can I use lambdas with async/await?**
A: Not directly. Use regular async functions instead.

## 🤝 Happy Learning!

Remember: The goal isn't to use lambdas everywhere, but to recognize when they make your code clearer and more concise. Practice, experiment, and enjoy functional programming in Python!

---

**Month 4: Modular Programming - Lambda Functions**
Part of the comprehensive Python programming curriculum.
