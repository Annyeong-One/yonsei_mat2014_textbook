"""
03_functional_builtins.py - any(), all(), sum() with predicates
"""

print("=" * 70)
print("FUNCTIONAL BUILT-IN FUNCTIONS")
print("=" * 70)

# Review: any() and all()
print("\n1. any() - At least one True")
numbers = [0, 0, 1, 0]
print(f"any({numbers}) = {any(numbers)}")
print(f"Any even: {any(n % 2 == 0 for n in [1, 3, 5, 8, 9])}")

print("\n2. all() - All True")
numbers = [2, 4, 6, 8]
print(f"all({numbers}) = {all(numbers)}")
print(f"All even: {all(n % 2 == 0 for n in numbers)}")

# sum() with generator expressions
print("\n3. sum() with conditions")
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
even_sum = sum(n for n in numbers if n % 2 == 0)
print(f"Sum of evens in {numbers[:5]}...: {even_sum}")

# Practical Examples
print("\n" + "=" * 70)
print("PRACTICAL EXAMPLES")
print("=" * 70)

# Validation
print("\nValidate password requirements:")
password = "MyPass123"
checks = [
    len(password) >= 8,
    any(c.isupper() for c in password),
    any(c.islower() for c in password),
    any(c.isdigit() for c in password)
]
print(f"All requirements met: {all(checks)}")

# Statistics
print("\nData analysis:")
scores = [85, 92, 78, 95, 88, 76]
print(f"All passed (>=60): {all(s >= 60 for s in scores)}")
print(f"Any excellent (>=90): {any(s >= 90 for s in scores)}")
print(f"Total points: {sum(scores)}")

print("\nSee exercises.py for practice!")
