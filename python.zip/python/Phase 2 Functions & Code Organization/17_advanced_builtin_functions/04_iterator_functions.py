"""
04_iterator_functions.py - iter(), next(), reversed()
"""

print("=" * 70)
print("ITERATOR FUNCTIONS")
print("=" * 70)

# iter() and next() - Manual iteration
print("\n1. iter() and next()")
numbers = [1, 2, 3, 4, 5]
iterator = iter(numbers)
print(f"Created iterator from {numbers}")
print(f"next(): {next(iterator)}")
print(f"next(): {next(iterator)}")
print(f"next(): {next(iterator)}")

# reversed() - Reverse iteration
print("\n2. reversed()")
numbers = [1, 2, 3, 4, 5]
print(f"Original: {numbers}")
print(f"Reversed: {list(reversed(numbers))}")
print(f"String: {list(reversed('Python'))}")

# Practical use
print("\n3. Practical Example")
print("Reading items one at a time:")
items = ["first", "second", "third"]
it = iter(items)
while True:
    try:
        item = next(it)
        print(f"  Processing: {item}")
    except StopIteration:
        print("  Done!")
        break

print("\nSee exercises.py for practice!")
