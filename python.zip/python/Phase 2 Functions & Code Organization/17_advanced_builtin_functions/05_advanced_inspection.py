"""
05_advanced_inspection.py - Advanced inspection functions
"""

print("=" * 70)
print("ADVANCED INSPECTION FUNCTIONS")
print("=" * 70)

# getattr(), setattr(), hasattr()
print("\n1. Dynamic attribute access")

class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

person = Person("Alice", 25)

# hasattr - check if attribute exists
print(f"hasattr(person, 'name'): {hasattr(person, 'name')}")
print(f"hasattr(person, 'salary'): {hasattr(person, 'salary')}")

# getattr - get attribute value
name = getattr(person, 'name')
print(f"getattr(person, 'name'): {name}")

# getattr with default
salary = getattr(person, 'salary', 'Not set')
print(f"getattr(person, 'salary', 'Not set'): {salary}")

# setattr - set attribute value
setattr(person, 'city', 'NYC')
print(f"After setattr: person.city = {person.city}")

# vars() - get object's __dict__
print(f"\n2. vars(person): {vars(person)}")

# callable() - check if object can be called
print(f"\n3. callable() checks")
def my_func():
    pass
print(f"callable(my_func): {callable(my_func)}")
print(f"callable(print): {callable(print)}")
print(f"callable(42): {callable(42)}")
print(f"callable('hello'): {callable('hello')}")

print("\nSee exercises.py for practice!")
