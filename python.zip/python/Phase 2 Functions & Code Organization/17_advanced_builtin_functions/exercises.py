"""
exercises.py - Advanced Built-in Functions Exercises
"""

print("=" * 70)
print("ADVANCED BUILT-IN FUNCTIONS - EXERCISES")
print("=" * 70)

print("\nSECTION 1: map() and filter()")
print("-" * 70)
print("""
1. Use map() to convert ["1", "2", "3"] to integers
2. Use map() to get length of each word in ["hello", "world", "python"]
3. Use filter() to get numbers > 10 from [5, 12, 8, 20, 3, 15]
4. Use map() and filter() to get squares of even numbers [1-10]
5. Convert list of tuples [(1,2), (3,4), (5,6)] to list of sums

6. Use map() with multiple lists: add [1,2,3] and [10,20,30]
7. Filter words longer than 5 chars from ["hello", "world", "python", "code"]
8. Convert Celsius [0, 10, 20, 30] to Fahrenheit using map()
9. Keep only positive numbers from [-5, 10, -3, 8, -1, 15]
10. Get uppercase versions of strings in ["python", "java", "c++"]
""")

print("\nSECTION 2: zip() and enumerate()")
print("-" * 70)
print("""
1. Zip ["a", "b", "c"] with [1, 2, 3]
2. Create dict from keys=["x","y","z"] and values=[10,20,30]
3. Iterate over ["apple", "banana"] with enumerate (start=1)
4. Unzip [(1,"a"), (2,"b"), (3,"c")] into two lists
5. Find indices where [5,10,15,20,25] > 15

6. Combine three lists: names, ages, cities into tuples
7. Number lines of text using enumerate
8. Zip two lists of different lengths - what happens?
9. Create parallel iteration over names and scores
10. Find positions of vowels in "hello world"
""")

print("\nSECTION 3: Functional Built-ins")
print("-" * 70)
print("""
1. Check if any number in [2,4,6,8,10] is odd
2. Check if all numbers in [2,4,6,8,10] are even
3. Sum of squares: sum(x**2 for x in [1,2,3,4,5])
4. Check if any string in ["hello", "world"] starts with 'w'
5. Validate all emails have '@': ["a@b.com", "test@test.org"]

6. Count evens in [1,2,3,4,5,6,7,8,9,10]
7. Check if all grades >= 60: [70, 85, 92, 65, 78]
8. Sum of numbers divisible by 3 in range(1,101)
9. Check if any char in password is special char
10. Validate all items in cart have price > 0
""")

print("\nSECTION 4: Iterators")
print("-" * 70)
print("""
1. Create iterator from list and call next() 3 times
2. Reverse string "Python" using reversed()
3. Manually iterate through [1,2,3] using iter/next
4. Check if object is iterable
5. Convert iterator to list

6. Reverse a list without modifying original
7. Iterate backwards through range(10)
8. Process items one at a time with next()
9. Handle StopIteration gracefully
10. Create custom iterator class
""")

print("\nSECTION 5: Advanced Inspection")
print("-" * 70)
print("""
1. Check if object has attribute 'name'
2. Get attribute with default value
3. Set attribute dynamically
4. Check if print is callable
5. Get all attributes of an object with vars()

6. Use getattr to safely access possibly missing attribute
7. Check if list of functions are all callable
8. Dynamically set multiple attributes on object
9. Compare hasattr vs try/except for attribute check
10. Get dict of object's attributes
""")

print("\nSee solutions.py for complete answers!")
