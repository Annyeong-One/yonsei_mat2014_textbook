"""
solutions.py - Advanced Built-in Functions Solutions
"""

print("=" * 70)
print("ADVANCED BUILT-IN FUNCTIONS - SOLUTIONS")
print("=" * 70)

# SECTION 1: map() and filter()
print("\nSECTION 1: map() and filter() Solutions")
print("-" * 70)

# Exercise 1
print("\n1. String to int with map()")
strings = ["1", "2", "3"]
integers = list(map(int, strings))
print(f"Result: {integers}")

# Exercise 2
print("\n2. Length of words")
words = ["hello", "world", "python"]
lengths = list(map(len, words))
print(f"Lengths: {lengths}")

# Exercise 3
print("\n3. Filter numbers > 10")
numbers = [5, 12, 8, 20, 3, 15]
filtered = list(filter(lambda x: x > 10, numbers))
print(f"Result: {filtered}")

# Exercise 4
print("\n4. Squares of evens")
numbers = range(1, 11)
result = list(map(lambda x: x**2, filter(lambda x: x % 2 == 0, numbers)))
print(f"Result: {result}")

# Exercise 8
print("\n8. Celsius to Fahrenheit")
celsius = [0, 10, 20, 30]
fahrenheit = list(map(lambda c: c * 9/5 + 32, celsius))
print(f"Fahrenheit: {fahrenheit}")

# SECTION 2: zip() and enumerate()
print("\n" + "=" * 70)
print("SECTION 2: zip() and enumerate() Solutions")
print("-" * 70)

# Exercise 1
print("\n1. Zip lists")
result = list(zip(["a", "b", "c"], [1, 2, 3]))
print(f"Result: {result}")

# Exercise 2
print("\n2. Create dict")
keys = ["x", "y", "z"]
values = [10, 20, 30]
result = dict(zip(keys, values))
print(f"Dict: {result}")

# Exercise 3
print("\n3. Enumerate with start")
fruits = ["apple", "banana"]
for i, fruit in enumerate(fruits, start=1):
    print(f"  {i}. {fruit}")

# Exercise 5
print("\n5. Find indices > 15")
numbers = [5, 10, 15, 20, 25]
for i, num in enumerate(numbers):
    if num > 15:
        print(f"  Index {i}: {num}")

# SECTION 3: Functional Built-ins
print("\n" + "=" * 70)
print("SECTION 3: Functional Built-ins Solutions")
print("-" * 70)

# Exercise 1
print("\n1. Any odd?")
numbers = [2, 4, 6, 8, 10]
result = any(n % 2 != 0 for n in numbers)
print(f"Result: {result}")

# Exercise 2
print("\n2. All even?")
result = all(n % 2 == 0 for n in numbers)
print(f"Result: {result}")

# Exercise 3
print("\n3. Sum of squares")
result = sum(x**2 for x in [1, 2, 3, 4, 5])
print(f"Result: {result}")

# Exercise 8
print("\n8. Sum divisible by 3")
result = sum(x for x in range(1, 101) if x % 3 == 0)
print(f"Result: {result}")

# SECTION 4: Iterators
print("\n" + "=" * 70)
print("SECTION 4: Iterator Solutions")
print("-" * 70)

# Exercise 1
print("\n1. Iterator and next()")
numbers = [1, 2, 3, 4, 5]
it = iter(numbers)
print(f"next(): {next(it)}")
print(f"next(): {next(it)}")
print(f"next(): {next(it)}")

# Exercise 2
print("\n2. Reverse string")
text = "Python"
reversed_text = ''.join(reversed(text))
print(f"Reversed: {reversed_text}")

# SECTION 5: Advanced Inspection
print("\n" + "=" * 70)
print("SECTION 5: Advanced Inspection Solutions")
print("-" * 70)

# Exercise 1-3
print("\n1-3. Dynamic attributes")
class Person:
    pass

person = Person()
print(f"Has 'name': {hasattr(person, 'name')}")
name = getattr(person, 'name', 'Unknown')
print(f"Get with default: {name}")
setattr(person, 'name', 'Alice')
print(f"After setattr: {person.name}")

# Exercise 4
print("\n4. Check callable")
print(f"callable(print): {callable(print)}")
print(f"callable(42): {callable(42)}")

print("\n" + "=" * 70)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 70)
