# Python LEGB Rule - Complete Tutorial

## Table of Contents
1. [Introduction](#introduction)
2. [What is LEGB?](#what-is-legb)
3. [The Four Scopes](#the-four-scopes)
4. [How Name Resolution Works](#how-name-resolution-works)
5. [The global Keyword](#the-global-keyword)
6. [The nonlocal Keyword](#the-nonlocal-keyword)
7. [Common Pitfalls](#common-pitfalls)
8. [Advanced Topics](#advanced-topics)
9. [Best Practices](#best-practices)

---

## Introduction

Have you ever wondered why this Python code works:

```python
x = 10  # Global

def func():
    print(x)  # Can access x!

func()  # Prints: 10
```

But this code raises an error:

```python
x = 10  # Global

def func():
    print(x)  # Error: referenced before assignment
    x = 20   # Local

func()
```

The answer lies in Python's **LEGB rule** - the system that determines which variable Python uses when you reference a name.

---

## What is LEGB?

**LEGB** stands for:
- **L**ocal
- **E**nclosing  
- **G**lobal
- **B**uilt-in

This is the **exact order** Python searches for variable names. When you reference a variable, Python:
1. Checks Local scope first
2. Then Enclosing scope
3. Then Global scope
4. Finally Built-in scope
5. If not found anywhere, raises `NameError`

Think of it like searching for your keys:
1. Check your pocket (Local)
2. Check your bag (Enclosing)
3. Check the room (Global)
4. Check lost-and-found (Built-in)

---

## The Four Scopes

### 1. Local Scope (L)

**Definition**: Variables defined inside the current function.

**Created**: When a function is called  
**Destroyed**: When the function returns

```python
def greet():
    message = "Hello"  # Local variable
    print(message)

greet()  # Works
print(message)  # NameError: message not found
```

**Key Points:**
- Each function call creates a new local scope
- Parameters are also local variables
- Local variables don't exist outside their function

```python
def calculate(a, b):  # a and b are local
    result = a + b    # result is local
    return result

print(calculate(5, 3))  # 8
print(result)  # NameError
```

### 2. Enclosing Scope (E)

**Definition**: Variables in outer functions (for nested functions).

**Created**: When an outer function contains an inner function  
**Accessible**: Only by inner functions

```python
def outer():
    x = "enclosing"  # Enclosing scope for inner()
    
    def inner():
        print(x)  # Can access enclosing x
    
    inner()  # Prints: enclosing

outer()
```

**Nested Scopes Example:**

```python
def level1():
    x = "level 1"
    
    def level2():
        y = "level 2"
        
        def level3():
            z = "level 3"
            print(x)  # From level1 (enclosing)
            print(y)  # From level2 (enclosing)
            print(z)  # From level3 (local)
        
        level3()
    
    level2()

level1()
```

**Key Points:**
- Enclosing scope is **read-only** by default
- Inner functions can access outer function variables
- Multiple levels of nesting are possible

### 3. Global Scope (G)

**Definition**: Variables defined at the module level (outside all functions).

**Created**: When the module is loaded  
**Destroyed**: When the program ends

```python
# Global scope
module_name = "my_module"
version = 1.0

def show_info():
    print(module_name)  # Can read global
    print(version)      # Can read global

show_info()
```

**Key Points:**
- Shared across all functions in the module
- Exists for the entire program lifetime
- Can be accessed from anywhere in the module

### 4. Built-in Scope (B)

**Definition**: Python's pre-defined names.

**Created**: When Python interpreter starts  
**Includes**: Functions like `print()`, `len()`, `int()`, exceptions like `ValueError`, etc.

```python
# These are all built-ins
print("Hello")      # print is built-in
length = len([1,2,3])  # len is built-in
number = int("42")  # int is built-in
```

**Viewing Built-ins:**

```python
import builtins
print(dir(builtins))
# Shows all built-in names
```

**Key Points:**
- Always available everywhere
- Should not be shadowed (overridden)
- Last resort in name resolution

---

## How Name Resolution Works

### The Search Process

When Python encounters a variable name, it:

```
1. Check LOCAL scope
   ↓ Not found?
2. Check ENCLOSING scope(s)
   ↓ Not found?
3. Check GLOBAL scope
   ↓ Not found?
4. Check BUILT-IN scope
   ↓ Not found?
5. Raise NameError
```

### Example: Following the LEGB Chain

```python
x = "global x"  # Global

def outer():
    x = "enclosing x"  # Enclosing
    
    def inner():
        x = "local x"  # Local
        print(x)
    
    inner()

outer()
# Output: "local x" (Local wins!)
```

**Step-by-step search:**
1. Python sees `print(x)` in `inner()`
2. Checks **Local** scope: Found `x = "local x"` ✓
3. Stops searching - uses local x

### Example: Skipping Scopes

```python
x = "global x"

def outer():
    # No x here (skips Enclosing)
    
    def inner():
        # No x here (skips Local)
        print(x)  # Goes to Global
    
    inner()

outer()
# Output: "global x" (Found in Global)
```

### Example: Using Built-in

```python
def test():
    # No local 'len'
    result = len([1, 2, 3])  # Uses built-in len
    print(result)

test()  # Output: 3
```

---

## The `global` Keyword

### The Problem

By default, assignment creates a **local** variable:

```python
counter = 0  # Global

def increment():
    counter = counter + 1  # Error!
    
increment()
# UnboundLocalError: local variable 'counter' 
# referenced before assignment
```

**Why the error?**
1. Python sees `counter = ...` (assignment)
2. Decides `counter` is a **local** variable
3. Right side reads `counter` before it's defined locally
4. Error!

### The Solution

Use `global` keyword to tell Python: "Use the global variable, don't create a local one"

```python
counter = 0  # Global

def increment():
    global counter  # Use global counter
    counter = counter + 1

increment()
print(counter)  # 1
```

### Syntax

```python
global variable_name
```

- Must appear **before** using the variable
- Can declare multiple: `global x, y, z`
- Only needed for **assignment**, not reading

### Reading vs. Writing

```python
x = 10

# Reading - no global needed
def read_x():
    print(x)  # OK

# Writing - global needed
def write_x():
    global x
    x = 20  # OK

read_x()
write_x()
```

### Multiple Variables

```python
a, b, c = 1, 2, 3

def modify_all():
    global a, b, c
    a = 10
    b = 20
    c = 30

modify_all()
print(a, b, c)  # 10 20 30
```

### When to Use `global`

✅ **Good uses:**
- Configuration settings
- Counters/stats
- Caching
- Application state

❌ **Better alternatives:**
- Function parameters
- Return values
- Class attributes
- Database/file storage

---

## The `nonlocal` Keyword

### The Problem

Can't modify enclosing scope variables by default:

```python
def outer():
    count = 0  # Enclosing
    
    def inner():
        count = count + 1  # Creates local count!
        print(f"Inner: {count}")
    
    inner()
    print(f"Outer: {count}")  # Still 0!

outer()
# Inner: 1
# Outer: 0
```

### The Solution

Use `nonlocal` to access enclosing scope:

```python
def outer():
    count = 0  # Enclosing
    
    def inner():
        nonlocal count  # Use enclosing count
        count = count + 1
        print(f"Inner: {count}")
    
    inner()
    print(f"Outer: {count}")  # Now 1!

outer()
# Inner: 1
# Outer: 1
```

### Syntax

```python
nonlocal variable_name
```

- Searches enclosing scopes (not global!)
- Must already exist in an enclosing scope
- Can't create new variables

### `nonlocal` vs. `global`

```python
x = "global"

def outer():
    x = "enclosing"
    
    def inner1():
        nonlocal x  # Gets enclosing x
        print(x)
    
    def inner2():
        global x  # Gets global x
        print(x)
    
    inner1()  # Prints: enclosing
    inner2()  # Prints: global

outer()
```

### Practical Example: Closure with State

```python
def make_counter():
    count = 0
    
    def increment():
        nonlocal count
        count += 1
        return count
    
    return increment

counter = make_counter()
print(counter())  # 1
print(counter())  # 2
print(counter())  # 3
```

---

## Common Pitfalls

### Pitfall 1: UnboundLocalError

```python
x = 10

def func():
    print(x)  # Want to print global x
    x = 20    # But this makes x local!

func()
# UnboundLocalError
```

**Fix:**

```python
x = 10

def func():
    global x
    print(x)
    x = 20

func()
```

### Pitfall 2: Shadowing Variables

```python
# Bad: Shadows built-in
def process():
    list = [1, 2, 3]  # Shadows built-in list()!
    # Now can't use list() constructor
    
# Good: Use different name
def process():
    items = [1, 2, 3]
```

### Pitfall 3: Mutable Defaults

```python
def add_item(item, items=[]):  # Danger!
    items.append(item)
    return items

print(add_item(1))  # [1]
print(add_item(2))  # [1, 2] - Oops!
```

**Why?** Default `[]` is created once in global scope!

**Fix:**

```python
def add_item(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items
```

### Pitfall 4: Loop Variables in Closures

```python
functions = []
for i in range(3):
    functions.append(lambda: i)

for func in functions:
    print(func())  # All print 2!
```

**Why?** All lambdas reference same `i` (late binding).

**Fix 1: Default argument**

```python
functions = []
for i in range(3):
    functions.append(lambda x=i: x)

for func in functions:
    print(func())  # 0, 1, 2
```

**Fix 2: Closure factory**

```python
def make_func(x):
    return lambda: x

functions = [make_func(i) for i in range(3)]
```

### Pitfall 5: Global in Class Methods

```python
counter = 0

class MyClass:
    def increment(self):
        global counter  # Still need global
        counter += 1
```

---

## Advanced Topics

### Inspecting Scopes

```python
def outer():
    x = "enclosing"
    
    def inner():
        y = "local"
        print("Local:", locals())
        print("Global:", list(globals().keys())[:5])
    
    inner()

outer()
```

### Free Variables

Variables from enclosing scope captured by inner function:

```python
def outer(x):
    def inner():
        return x  # x is a "free variable"
    return inner

func = outer(10)
print(func.__code__.co_freevars)  # ('x',)
```

### Closures

When inner function references enclosing scope:

```python
def make_multiplier(n):
    def multiply(x):
        return x * n  # Closure over n
    return multiply

times_2 = make_multiplier(2)
times_3 = make_multiplier(3)

print(times_2(5))  # 10
print(times_3(5))  # 15
```

### Name Resolution at Compile Time

Python determines scope at **compile time**, not runtime:

```python
x = 10

def func():
    if False:
        x = 20  # Never executes
    print(x)  # But Python sees assignment

func()  # UnboundLocalError!
```

---

## Best Practices

### 1. Minimize Global Usage

```python
# ❌ Bad
counter = 0

def increment():
    global counter
    counter += 1

# ✅ Good
def increment(counter):
    return counter + 1

counter = 0
counter = increment(counter)
```

### 2. Use Function Parameters

```python
# ❌ Bad
x = 10

def calculate():
    global x
    return x * 2

# ✅ Good
def calculate(x):
    return x * 2

result = calculate(10)
```

### 3. Return, Don't Modify

```python
# ❌ Bad
result = []

def process(item):
    global result
    result.append(item * 2)

# ✅ Good
def process(item):
    return item * 2

result = [process(x) for x in range(5)]
```

### 4. Clear Variable Names

```python
# ❌ Bad: Shadows
def process(list):  # Shadows built-in
    max = 0  # Shadows built-in
    ...

# ✅ Good
def process(items):
    maximum = 0
    ...
```

### 5. Keep Functions Small

Smaller functions = easier to track scope:

```python
# ✅ Good: Easy to understand scope
def validate_email(email):
    return '@' in email

def send_email(to, subject, body):
    if not validate_email(to):
        raise ValueError("Invalid email")
    # send email...
```

---

## Summary

### Key Takeaways

1. **LEGB Order**: Local → Enclosing → Global → Built-in
2. **global**: Access global scope for writing
3. **nonlocal**: Access enclosing scope for writing
4. **Reading is free**: Can read outer scopes without keywords
5. **Writing needs permission**: `global` or `nonlocal` for assignment
6. **Scope is compile-time**: Determined when Python parses code

### Quick Reference

```python
# Reading outer scopes (no keyword needed)
x = 10
def func():
    print(x)  # OK

# Writing to global
x = 10
def func():
    global x
    x = 20  # OK

# Writing to enclosing
def outer():
    x = 10
    def inner():
        nonlocal x
        x = 20  # OK
    inner()

# Checking scope
locals()   # Current scope
globals()  # Global scope
```

### When to Use What

| Situation | Use |
|-----------|-----|
| Read outer variable | Nothing (automatic) |
| Modify global variable | `global` keyword |
| Modify enclosing variable | `nonlocal` keyword |
| Pass data to function | Parameters |
| Return data from function | `return` statement |
| Share state between calls | Closure or class |

---

## Next Steps

1. Run the examples in `02_legb_examples.py`
2. Test yourself with `03_legb_exercises.py`
3. Check solutions in `04_legb_solutions.py`
4. Practice with your own code!

Happy Learning! 🎉
