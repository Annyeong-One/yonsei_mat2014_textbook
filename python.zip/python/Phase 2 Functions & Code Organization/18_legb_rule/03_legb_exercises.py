#!/usr/bin/env python3
"""
LEGB Rule - Practice Exercises
===============================

Complete these 15 exercises to test your understanding of Python's LEGB rule.

Instructions:
1. Try to solve each exercise on your own first
2. Think about which scope each variable comes from
3. Run the code to test your answer
4. Check 04_legb_solutions.py for detailed explanations

Difficulty levels:
★☆☆ - Basic
★★☆ - Intermediate
★★★ - Advanced
"""

print("=" * 70)
print("LEGB RULE - PRACTICE EXERCISES")
print("=" * 70)
print()

# ============================================================================
# EXERCISE 1: Basic Scope Identification ★☆☆
# ============================================================================

print("Exercise 1: Basic Scope Identification ★☆☆")
print("-" * 70)
print("""
What will this code print?

x = "global"

def func():
    print(x)

func()

Your answer:
""")

# Uncomment to test:
# x = "global"
# def func():
#     print(x)
# func()

print()

# ============================================================================
# EXERCISE 2: Local vs. Global ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 2: Local vs. Global ★☆☆")
print("-" * 70)
print("""
What will this code print?

x = 10

def func():
    x = 20
    print(x)

func()
print(x)

Your answer:
""")

# Uncomment to test:
# x = 10
# def func():
#     x = 20
#     print(x)
# func()
# print(x)

print()

# ============================================================================
# EXERCISE 3: Error Detection ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 3: Error Detection ★☆☆")
print("-" * 70)
print("""
Will this code raise an error? If yes, what error?

x = 10

def func():
    print(x)
    x = 20

func()

Your answer:
""")

# Uncomment to test:
# x = 10
# def func():
#     print(x)
#     x = 20
# func()

print()

# ============================================================================
# EXERCISE 4: Using global Keyword ★☆☆
# ============================================================================

print("=" * 70)
print("Exercise 4: Using global Keyword ★☆☆")
print("-" * 70)
print("""
What will this code print?

counter = 0

def increment():
    global counter
    counter += 1

increment()
increment()
print(counter)

Your answer:
""")

# Uncomment to test:
# counter = 0
# def increment():
#     global counter
#     counter += 1
# increment()
# increment()
# print(counter)

print()

# ============================================================================
# EXERCISE 5: Enclosing Scope ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 5: Enclosing Scope ★★☆")
print("-" * 70)
print("""
What will this code print?

def outer():
    x = "outer"
    
    def inner():
        print(x)
    
    inner()

outer()

Your answer:
""")

# Uncomment to test:
# def outer():
#     x = "outer"
#     
#     def inner():
#         print(x)
#     
#     inner()
# outer()

print()

# ============================================================================
# EXERCISE 6: Using nonlocal ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 6: Using nonlocal ★★☆")
print("-" * 70)
print("""
What will this code print?

def outer():
    x = 10
    
    def inner():
        nonlocal x
        x = 20
    
    inner()
    print(x)

outer()

Your answer:
""")

# Uncomment to test:
# def outer():
#     x = 10
#     
#     def inner():
#         nonlocal x
#         x = 20
#     
#     inner()
#     print(x)
# outer()

print()

# ============================================================================
# EXERCISE 7: Multiple Scopes ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 7: Multiple Scopes ★★☆")
print("-" * 70)
print("""
What will this code print? (List all outputs)

x = "global"

def outer():
    x = "outer"
    
    def inner():
        x = "inner"
        print(f"inner: {x}")
    
    inner()
    print(f"outer: {x}")

outer()
print(f"global: {x}")

Your answer:
""")

# Uncomment to test:
# x = "global"
# def outer():
#     x = "outer"
#     
#     def inner():
#         x = "inner"
#         print(f"inner: {x}")
#     
#     inner()
#     print(f"outer: {x}")
# outer()
# print(f"global: {x}")

print()

# ============================================================================
# EXERCISE 8: Closure Behavior ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 8: Closure Behavior ★★☆")
print("-" * 70)
print("""
What will this code print?

def make_adder(n):
    def add(x):
        return x + n
    return add

add_5 = make_adder(5)
add_10 = make_adder(10)

print(add_5(3))
print(add_10(3))

Your answer:
""")

# Uncomment to test:
# def make_adder(n):
#     def add(x):
#         return x + n
#     return add
# add_5 = make_adder(5)
# add_10 = make_adder(10)
# print(add_5(3))
# print(add_10(3))

print()

# ============================================================================
# EXERCISE 9: Missing nonlocal ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 9: Missing nonlocal ★★☆")
print("-" * 70)
print("""
What will this code print?

def outer():
    count = 0
    
    def inner():
        count = count + 1  # No nonlocal!
        return count
    
    try:
        print(inner())
    except UnboundLocalError:
        print("UnboundLocalError!")

outer()

Your answer:
""")

# Uncomment to test:
# def outer():
#     count = 0
#     
#     def inner():
#         count = count + 1
#         return count
#     
#     try:
#         print(inner())
#     except UnboundLocalError:
#         print("UnboundLocalError!")
# outer()

print()

# ============================================================================
# EXERCISE 10: global vs. nonlocal ★★★
# ============================================================================

print("=" * 70)
print("Exercise 10: global vs. nonlocal ★★★")
print("-" * 70)
print("""
What will this code print? (List all outputs)

x = "global"

def outer():
    x = "outer"
    
    def use_global():
        global x
        print(f"use_global: {x}")
    
    def use_nonlocal():
        nonlocal x
        print(f"use_nonlocal: {x}")
    
    use_global()
    use_nonlocal()

outer()

Your answer:
""")

# Uncomment to test:
# x = "global"
# def outer():
#     x = "outer"
#     
#     def use_global():
#         global x
#         print(f"use_global: {x}")
#     
#     def use_nonlocal():
#         nonlocal x
#         print(f"use_nonlocal: {x}")
#     
#     use_global()
#     use_nonlocal()
# outer()

print()

# ============================================================================
# EXERCISE 11: Modifying Enclosing ★★★
# ============================================================================

print("=" * 70)
print("Exercise 11: Modifying Enclosing ★★★")
print("-" * 70)
print("""
What will this code print? (List all outputs)

def outer():
    x = 1
    
    def middle():
        x = 2
        
        def inner():
            nonlocal x
            x = 3
            print(f"inner: {x}")
        
        inner()
        print(f"middle: {x}")
    
    middle()
    print(f"outer: {x}")

outer()

Your answer:
""")

# Uncomment to test:
# def outer():
#     x = 1
#     
#     def middle():
#         x = 2
#         
#         def inner():
#             nonlocal x
#             x = 3
#             print(f"inner: {x}")
#         
#         inner()
#         print(f"middle: {x}")
#     
#     middle()
#     print(f"outer: {x}")
# outer()

print()

# ============================================================================
# EXERCISE 12: Loop Variable Closure ★★★
# ============================================================================

print("=" * 70)
print("Exercise 12: Loop Variable Closure ★★★")
print("-" * 70)
print("""
What will this code print?

functions = []
for i in range(3):
    def func():
        return i
    functions.append(func)

for f in functions:
    print(f())

Your answer:
""")

# Uncomment to test:
# functions = []
# for i in range(3):
#     def func():
#         return i
#     functions.append(func)
# for f in functions:
#     print(f())

print()

# ============================================================================
# EXERCISE 13: Shadowing Built-ins ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 13: Shadowing Built-ins ★★☆")
print("-" * 70)
print("""
Will this code work? If not, why?

def process():
    list = [1, 2, 3]
    print(list)
    
    # Try to convert string to list
    result = list("abc")
    print(result)

process()

Your answer:
""")

# Uncomment to test:
# def process():
#     list = [1, 2, 3]
#     print(list)
#     
#     result = list("abc")
#     print(result)
# process()

print()

# ============================================================================
# EXERCISE 14: Multiple Global Variables ★★☆
# ============================================================================

print("=" * 70)
print("Exercise 14: Multiple Global Variables ★★☆")
print("-" * 70)
print("""
What will this code print?

a = 1
b = 2
c = 3

def modify_all():
    global a, c
    a = 10
    b = 20
    c = 30

modify_all()
print(a, b, c)

Your answer:
""")

# Uncomment to test:
# a = 1
# b = 2
# c = 3
# def modify_all():
#     global a, c
#     a = 10
#     b = 20
#     c = 30
# modify_all()
# print(a, b, c)

print()

# ============================================================================
# EXERCISE 15: Complex Closure ★★★
# ============================================================================

print("=" * 70)
print("Exercise 15: Complex Closure ★★★")
print("-" * 70)
print("""
What will this code print? (List all outputs)

def create_functions():
    x = 1
    
    def increment():
        nonlocal x
        x += 1
        return x
    
    def decrement():
        nonlocal x
        x -= 1
        return x
    
    def get():
        return x
    
    return increment, decrement, get

inc, dec, get = create_functions()

print(get())
print(inc())
print(inc())
print(dec())
print(get())

Your answer:
""")

# Uncomment to test:
# def create_functions():
#     x = 1
#     
#     def increment():
#         nonlocal x
#         x += 1
#         return x
#     
#     def decrement():
#         nonlocal x
#         x -= 1
#         return x
#     
#     def get():
#         return x
#     
#     return increment, decrement, get
# inc, dec, get = create_functions()
# print(get())
# print(inc())
# print(inc())
# print(dec())
# print(get())

print()

# ============================================================================
# BONUS EXERCISE: Fix the Bug ★★★
# ============================================================================

print("=" * 70)
print("BONUS: Fix the Bug ★★★")
print("-" * 70)
print("""
This code has a bug. Identify and fix it:

total = 0

def add_to_total(value):
    total = total + value
    return total

print(add_to_total(5))
print(add_to_total(10))

Problem:
Solution:
""")

print()

print("=" * 70)
print("CONGRATULATIONS!")
print("=" * 70)
print("""
You've completed all LEGB exercises!

Next steps:
1. Check your answers in 04_legb_solutions.py
2. Understand the explanations
3. Practice with your own examples
4. Master Python scope!
""")
