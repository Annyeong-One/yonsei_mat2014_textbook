#!/usr/bin/env python3
"""
LEGB Rule - Exercise Solutions
===============================

Detailed solutions and explanations for all 15 exercises.

Each solution includes:
1. The expected output
2. Step-by-step explanation
3. Key concepts demonstrated
4. Common mistakes to avoid
"""

print("=" * 70)
print("LEGB RULE - EXERCISE SOLUTIONS")
print("=" * 70)
print()

# ============================================================================
# SOLUTION 1: Basic Scope Identification
# ============================================================================

print("Solution 1: Basic Scope Identification ★☆☆")
print("-" * 70)

x = "global"

def func():
    print(x)

func()

print("\nExpected Output: global")
print("\nExplanation:")
print("1. func() references 'x' but doesn't assign to it")
print("2. Python searches: Local (not found) → Global (found!)")
print("3. Reads the global variable x")
print("\nKey Concept: Reading outer scope variables requires no keyword")
print()

# ============================================================================
# SOLUTION 2: Local vs. Global
# ============================================================================

print("=" * 70)
print("Solution 2: Local vs. Global ★☆☆")
print("-" * 70)

x = 10

def func():
    x = 20  # Creates LOCAL variable
    print(x)

func()
print(x)

print("\nExpected Output:")
print("20")
print("10")
print("\nExplanation:")
print("1. func() creates a LOCAL variable x = 20")
print("2. This shadows (hides) the global x")
print("3. First print uses local x (20)")
print("4. Second print uses global x (10)")
print("5. Global x is never modified")
print("\nKey Concept: Assignment creates local variable by default")
print()

# ============================================================================
# SOLUTION 3: Error Detection
# ============================================================================

print("=" * 70)
print("Solution 3: Error Detection ★☆☆")
print("-" * 70)

x = 10

def func():
    try:
        print(x)  # Tries to read x
        x = 20    # But x is local!
    except UnboundLocalError as e:
        print(f"UnboundLocalError: {e}")

func()

print("\nExpected Output: UnboundLocalError")
print("\nExplanation:")
print("1. Python sees 'x = 20' and decides x is LOCAL")
print("2. This happens at compile time, before execution")
print("3. print(x) tries to read local x before it's assigned")
print("4. Result: UnboundLocalError")
print("\nHow to fix:")
print("• Use 'global x' before print(x)")
print("• Or use different variable name")
print("\nKey Concept: Python determines scope at compile time")
print()

# ============================================================================
# SOLUTION 4: Using global Keyword
# ============================================================================

print("=" * 70)
print("Solution 4: Using global Keyword ★☆☆")
print("-" * 70)

counter = 0

def increment():
    global counter  # Use global counter
    counter += 1

increment()
increment()
print(counter)

print("\nExpected Output: 2")
print("\nExplanation:")
print("1. 'global counter' tells Python to use global variable")
print("2. First increment: counter becomes 1")
print("3. Second increment: counter becomes 2")
print("4. Global variable is modified")
print("\nKey Concept: 'global' keyword needed to modify global variables")
print()

# ============================================================================
# SOLUTION 5: Enclosing Scope
# ============================================================================

print("=" * 70)
print("Solution 5: Enclosing Scope ★★☆")
print("-" * 70)

def outer():
    x = "outer"  # Enclosing scope for inner()
    
    def inner():
        print(x)  # Accesses enclosing x
    
    inner()

outer()

print("\nExpected Output: outer")
print("\nExplanation:")
print("1. inner() references x but doesn't assign to it")
print("2. Python searches: Local (not found) → Enclosing (found!)")
print("3. Reads x from outer() function")
print("\nKey Concept: Inner functions can read enclosing scope")
print()

# ============================================================================
# SOLUTION 6: Using nonlocal
# ============================================================================

print("=" * 70)
print("Solution 6: Using nonlocal ★★☆")
print("-" * 70)

def outer():
    x = 10  # Enclosing variable
    
    def inner():
        nonlocal x  # Modify enclosing x
        x = 20
    
    inner()
    print(x)

outer()

print("\nExpected Output: 20")
print("\nExplanation:")
print("1. 'nonlocal x' tells Python to use enclosing x")
print("2. inner() modifies outer's x to 20")
print("3. outer() prints the modified x")
print("\nKey Concept: 'nonlocal' needed to modify enclosing variables")
print()

# ============================================================================
# SOLUTION 7: Multiple Scopes
# ============================================================================

print("=" * 70)
print("Solution 7: Multiple Scopes ★★☆")
print("-" * 70)

x = "global"

def outer():
    x = "outer"
    
    def inner():
        x = "inner"
        print(f"inner: {x}")
    
    inner()
    print(f"outer: {x}")

outer()
print(f"global: {x}")

print("\nExpected Output:")
print("inner: inner")
print("outer: outer")
print("global: global")
print("\nExplanation:")
print("1. Each scope has its own 'x'")
print("2. inner() uses its local x")
print("3. outer() uses its local x")
print("4. Global uses global x")
print("5. No scope modifies another")
print("\nKey Concept: Each scope maintains independent variables")
print()

# ============================================================================
# SOLUTION 8: Closure Behavior
# ============================================================================

print("=" * 70)
print("Solution 8: Closure Behavior ★★☆")
print("-" * 70)

def make_adder(n):
    def add(x):
        return x + n  # Captures n from enclosing scope
    return add

add_5 = make_adder(5)
add_10 = make_adder(10)

print(add_5(3))
print(add_10(3))

print("\nExpected Output:")
print("8")
print("13")
print("\nExplanation:")
print("1. make_adder(5) creates closure with n=5")
print("2. make_adder(10) creates closure with n=10")
print("3. add_5(3) returns 3 + 5 = 8")
print("4. add_10(3) returns 3 + 10 = 13")
print("5. Each closure remembers its own n")
print("\nKey Concept: Closures capture and remember enclosing variables")
print()

# ============================================================================
# SOLUTION 9: Missing nonlocal
# ============================================================================

print("=" * 70)
print("Solution 9: Missing nonlocal ★★☆")
print("-" * 70)

def outer():
    count = 0
    
    def inner():
        try:
            count = count + 1  # No nonlocal!
            return count
        except UnboundLocalError:
            return "UnboundLocalError!"
    
    print(inner())

outer()

print("\nExpected Output: UnboundLocalError!")
print("\nExplanation:")
print("1. 'count = count + 1' makes count local")
print("2. Right side reads count before it's assigned")
print("3. Python raises UnboundLocalError")
print("\nHow to fix:")
print("Add 'nonlocal count' before the assignment")
print("\nKey Concept: Assignment creates local variable without keyword")
print()

# ============================================================================
# SOLUTION 10: global vs. nonlocal
# ============================================================================

print("=" * 70)
print("Solution 10: global vs. nonlocal ★★★")
print("-" * 70)

x = "global"

def outer():
    x = "outer"
    
    def use_global():
        global x
        print(f"use_global: {x}")
    
    def use_nonlocal():
        nonlocal x
        print(f"use_nonlocal: {x}")
    
    use_global()
    use_nonlocal()

outer()

print("\nExpected Output:")
print("use_global: global")
print("use_nonlocal: outer")
print("\nExplanation:")
print("1. 'global x' accesses global scope x")
print("2. 'nonlocal x' accesses enclosing scope x (from outer)")
print("3. use_global sees 'global'")
print("4. use_nonlocal sees 'outer'")
print("\nKey Concept: global and nonlocal access different scopes")
print()

# ============================================================================
# SOLUTION 11: Modifying Enclosing
# ============================================================================

print("=" * 70)
print("Solution 11: Modifying Enclosing ★★★")
print("-" * 70)

def outer():
    x = 1
    
    def middle():
        x = 2  # Local to middle
        
        def inner():
            nonlocal x  # Refers to middle's x
            x = 3
            print(f"inner: {x}")
        
        inner()
        print(f"middle: {x}")
    
    middle()
    print(f"outer: {x}")

outer()

print("\nExpected Output:")
print("inner: 3")
print("middle: 3")
print("outer: 1")
print("\nExplanation:")
print("1. outer has x=1")
print("2. middle has its own x=2")
print("3. inner's 'nonlocal x' refers to middle's x (nearest enclosing)")
print("4. inner modifies middle's x to 3")
print("5. outer's x remains 1")
print("\nKey Concept: nonlocal accesses nearest enclosing scope")
print()

# ============================================================================
# SOLUTION 12: Loop Variable Closure
# ============================================================================

print("=" * 70)
print("Solution 12: Loop Variable Closure ★★★")
print("-" * 70)

functions = []
for i in range(3):
    def func():
        return i
    functions.append(func)

for f in functions:
    print(f())

print("\nExpected Output:")
print("2")
print("2")
print("2")
print("\nExplanation:")
print("1. All functions capture the same variable 'i'")
print("2. Loop finishes with i=2")
print("3. All functions return 2 (late binding)")
print("\nHow to fix:")
print("Use default argument: lambda x=i: x")
print("\nKey Concept: Closures capture variables, not values")
print()

# ============================================================================
# SOLUTION 13: Shadowing Built-ins
# ============================================================================

print("=" * 70)
print("Solution 13: Shadowing Built-ins ★★☆")
print("-" * 70)

def process():
    list = [1, 2, 3]  # Shadows built-in 'list'
    print(list)
    
    try:
        result = list("abc")  # Tries to call [1,2,3]("abc")
        print(result)
    except TypeError as e:
        print(f"TypeError: {e}")

process()

print("\nExpected Output:")
print("[1, 2, 3]")
print("TypeError: 'list' object is not callable")
print("\nExplanation:")
print("1. Variable 'list' shadows built-in list class")
print("2. 'list' now refers to [1, 2, 3], not the class")
print("3. Can't call list() anymore in this scope")
print("\nHow to fix:")
print("Use different name: items, values, data, etc.")
print("\nKey Concept: Don't shadow built-in names")
print()

# ============================================================================
# SOLUTION 14: Multiple Global Variables
# ============================================================================

print("=" * 70)
print("Solution 14: Multiple Global Variables ★★☆")
print("-" * 70)

a = 1
b = 2
c = 3

def modify_all():
    global a, c  # Only a and c are global
    a = 10
    b = 20  # Creates LOCAL b
    c = 30

modify_all()
print(a, b, c)

print("\nExpected Output: 10 2 30")
print("\nExplanation:")
print("1. 'global a, c' declares only a and c as global")
print("2. 'b = 20' creates LOCAL variable (not in global statement)")
print("3. Global a modified to 10")
print("4. Global b unchanged (2)")
print("5. Global c modified to 30")
print("\nKey Concept: Must declare each global variable explicitly")
print()

# ============================================================================
# SOLUTION 15: Complex Closure
# ============================================================================

print("=" * 70)
print("Solution 15: Complex Closure ★★★")
print("-" * 70)

def create_functions():
    x = 1
    
    def increment():
        nonlocal x
        x += 1
        return x
    
    def decrement():
        nonlocal x
        x -= 1
        return x
    
    def get():
        return x
    
    return increment, decrement, get

inc, dec, get = create_functions()

print(get())    # 1
print(inc())    # 2
print(inc())    # 3
print(dec())    # 2
print(get())    # 2

print("\nExpected Output:")
print("1")
print("2")
print("3")
print("2")
print("2")
print("\nExplanation:")
print("1. All three functions share the same x")
print("2. get() returns current x (1)")
print("3. inc() increases x to 2, returns 2")
print("4. inc() increases x to 3, returns 3")
print("5. dec() decreases x to 2, returns 2")
print("6. get() returns current x (2)")
print("\nKey Concept: Multiple closures can share the same state")
print()

# ============================================================================
# BONUS SOLUTION: Fix the Bug
# ============================================================================

print("=" * 70)
print("BONUS Solution: Fix the Bug ★★★")
print("-" * 70)

print("Original Code (with bug):")
print("""
total = 0

def add_to_total(value):
    total = total + value  # UnboundLocalError!
    return total
""")

print("\nProblem:")
print("• Assignment 'total = ...' makes total local")
print("• Right side reads total before assignment")
print("• Result: UnboundLocalError")

print("\nSolution 1: Use global keyword")
total = 0

def add_to_total_v1(value):
    global total
    total = total + value
    return total

print(f"add_to_total_v1(5) = {add_to_total_v1(5)}")
print(f"add_to_total_v1(10) = {add_to_total_v1(10)}")

print("\nSolution 2: Use parameter (better!)")
def add_to_total_v2(current_total, value):
    return current_total + value

total = 0
total = add_to_total_v2(total, 5)
print(f"After adding 5: {total}")
total = add_to_total_v2(total, 10)
print(f"After adding 10: {total}")

print("\nSolution 3: Use closure")
def make_accumulator():
    total = 0
    
    def add(value):
        nonlocal total
        total += value
        return total
    
    return add

add_to_total_v3 = make_accumulator()
print(f"add_to_total_v3(5) = {add_to_total_v3(5)}")
print(f"add_to_total_v3(10) = {add_to_total_v3(10)}")

print("\nBest Practice: Prefer solution 2 (parameters) over global")
print()

# ============================================================================
# FINAL SUMMARY
# ============================================================================

print("=" * 70)
print("CONGRATULATIONS! 🎉")
print("=" * 70)
print("""
You've completed all LEGB exercises and reviewed the solutions!

Key Takeaways:

1. LEGB Order: Local → Enclosing → Global → Built-in

2. Reading vs Writing:
   • Reading outer scopes: automatic
   • Writing to global: needs 'global' keyword
   • Writing to enclosing: needs 'nonlocal' keyword

3. Common Mistakes:
   • UnboundLocalError: assignment without global/nonlocal
   • Shadowing: hiding outer scope variables
   • Loop closures: late binding issue

4. Best Practices:
   • Minimize global usage
   • Prefer parameters over global
   • Don't shadow built-ins
   • Keep functions small and focused

5. Advanced Concepts:
   • Closures capture variables, not values
   • Scope determined at compile time
   • Multiple functions can share state via closures

Next Steps:
• Practice with your own code
• Look for scope-related bugs in existing code
• Use closures for state management
• Write cleaner, more maintainable Python!

Happy Coding! 🐍
""")
