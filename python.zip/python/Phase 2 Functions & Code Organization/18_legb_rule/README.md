# Python LEGB Rule - Complete Learning Package 🐍

## 📦 What's Inside

This package contains everything you need to master Python's LEGB rule for name resolution and scope management.

**Files included:**
1. **01_legb_tutorial.md** - Comprehensive guide to LEGB rule
2. **02_legb_examples.py** - 15 practical demonstrations
3. **03_legb_exercises.py** - 15 challenging exercises
4. **04_legb_solutions.py** - Detailed solutions with explanations

---

## 🎯 What is LEGB?

**LEGB** is Python's name resolution order:

- **L**ocal - Variables in the current function
- **E**nclosing - Variables in outer functions (nested scopes)
- **G**lobal - Module-level variables
- **B**uilt-in - Python's built-in names (print, len, etc.)

When Python encounters a variable name, it searches in this exact order: L → E → G → B

---

## 🚀 Quick Start

### Step 1: Read the Tutorial
```bash
# Open 01_legb_tutorial.md
# Learn the theory behind LEGB
```

### Step 2: Run Examples
```bash
python 02_legb_examples.py
# See LEGB in action with 15 examples
```

### Step 3: Practice
```bash
python 03_legb_exercises.py
# Solve 15 exercises to test your understanding
```

### Step 4: Check Solutions
```bash
python 04_legb_solutions.py
# Compare your answers with detailed explanations
```

---

## 💡 Key Topics Covered

### 1. The Four Scopes
- Local scope (function-level)
- Enclosing scope (nested functions)
- Global scope (module-level)
- Built-in scope (Python internals)

### 2. Name Resolution
- How Python looks up variables
- The search order (LEGB)
- When each scope is checked

### 3. Modifying Outer Scopes
- The `global` keyword
- The `nonlocal` keyword
- When and how to use them

### 4. Common Pitfalls
- Shadowing variables
- Unintentional local variables
- Closure behavior
- Mutable default arguments in scope

### 5. Advanced Concepts
- Closures and free variables
- Namespace inspection
- Scope debugging techniques

---

## 📊 Visual Reference

```
┌─────────────────────────────────────────┐
│         LEGB Search Order               │
├─────────────────────────────────────────┤
│                                         │
│  1. LOCAL (L)                           │
│     ↓ Current function                  │
│     └─ If not found, go to E            │
│                                         │
│  2. ENCLOSING (E)                       │
│     ↓ Outer function(s)                 │
│     └─ If not found, go to G            │
│                                         │
│  3. GLOBAL (G)                          │
│     ↓ Module level                      │
│     └─ If not found, go to B            │
│                                         │
│  4. BUILT-IN (B)                        │
│     ↓ Python's built-ins                │
│     └─ If not found, NameError!         │
│                                         │
└─────────────────────────────────────────┘
```

---

## ⏱️ Time Estimate

- **Tutorial**: 45-60 minutes
- **Examples**: 20-30 minutes  
- **Exercises**: 60-90 minutes
- **Total**: ~2-3 hours

---

## 🎓 Learning Outcomes

After completing this package, you will:

✅ Understand all four namespace types  
✅ Know exactly how Python resolves variable names  
✅ Use `global` and `nonlocal` correctly  
✅ Avoid common scoping mistakes  
✅ Debug scope-related issues confidently  
✅ Write cleaner, more predictable code  
✅ Ace Python interview questions on scope  

---

## 📚 Prerequisites

Basic knowledge required:
- Python variables and assignment
- Functions and parameters
- Basic data types

---

## 🔥 Why This Matters

Understanding LEGB helps you:

1. **Prevent bugs** - Know which variable you're actually using
2. **Write better code** - Proper scope management
3. **Debug faster** - Understand unexpected behavior
4. **Pass interviews** - Common technical question
5. **Use closures** - Foundation for decorators and more

---

## 🎯 Real-World Applications

- **Web Development**: Managing request/response scope
- **Data Science**: Avoiding variable conflicts in notebooks
- **Game Development**: Managing game state and entities
- **General Programming**: Writing maintainable code

---

## 📝 Quick Reference

### Checking Current Scope
```python
locals()   # Local namespace
globals()  # Global namespace
```

### Modifying Outer Scopes
```python
global var    # Access global variable
nonlocal var  # Access enclosing variable
```

### Common Mistakes to Avoid
```python
# ❌ Don't do this
x = 10
def func():
    x = x + 1  # UnboundLocalError!

# ✅ Do this instead
x = 10
def func():
    global x
    x = x + 1
```

---

## 🆘 Getting Help

If you're stuck:
1. Review the tutorial section on that topic
2. Look at similar examples
3. Check the solution explanations
4. Experiment in the Python REPL

---

## 🌟 Best Practices

1. **Minimize global usage** - Prefer function parameters
2. **Use nonlocal sparingly** - Can make code hard to follow
3. **Name variables clearly** - Avoid shadowing
4. **Keep functions small** - Easier to track scope
5. **Use locals() for debugging** - See what's in scope

---

## 🎉 Ready to Start?

Begin with `01_legb_tutorial.md` and work through each file in order. Take your time, run the examples, and practice with the exercises. By the end, you'll have a deep understanding of Python's scoping rules!

**Happy Learning! 🚀**
