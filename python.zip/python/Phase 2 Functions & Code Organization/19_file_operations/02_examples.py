"""
PRACTICAL EXAMPLES - File Operations
=====================================

Real-world examples demonstrating file operations.
"""

from pathlib import Path
import json
import csv
from datetime import datetime

# =============================================================================
# EXAMPLE 1: Log File Analyzer
# =============================================================================

print("=" * 60)
print("EXAMPLE 1: Log File Analyzer")
print("=" * 60)

# Create sample log file
log_content = """2024-11-04 10:15:23 INFO User logged in
2024-11-04 10:16:45 ERROR Database connection failed
2024-11-04 10:17:12 INFO File uploaded successfully
2024-11-04 10:18:33 WARNING Low disk space
2024-11-04 10:19:01 ERROR Payment processing failed
2024-11-04 10:20:15 INFO User logged out
2024-11-04 10:21:42 ERROR API timeout
2024-11-04 10:22:18 INFO System backup completed
"""

with open('application.log', 'w') as f:
    f.write(log_content)

class LogAnalyzer:
    def __init__(self, log_file):
        self.log_file = Path(log_file)
        self.logs = []
        self.parse_logs()
    
    def parse_logs(self):
        """Parse log file into structured data"""
        with open(self.log_file, 'r') as f:
            for line in f:
                parts = line.strip().split(maxsplit=3)
                if len(parts) == 4:
                    self.logs.append({
                        'date': parts[0],
                        'time': parts[1],
                        'level': parts[2],
                        'message': parts[3]
                    })
    
    def count_by_level(self):
        """Count log entries by level"""
        counts = {}
        for log in self.logs:
            level = log['level']
            counts[level] = counts.get(level, 0) + 1
        return counts
    
    def get_errors(self):
        """Get all error messages"""
        return [log for log in self.logs if log['level'] == 'ERROR']
    
    def write_summary(self, output_file):
        """Write analysis summary to file"""
        with open(output_file, 'w') as f:
            f.write("LOG ANALYSIS SUMMARY\n")
            f.write("=" * 50 + "\n\n")
            
            f.write(f"Total entries: {len(self.logs)}\n\n")
            
            f.write("Entries by level:\n")
            for level, count in self.count_by_level().items():
                f.write(f"  {level}: {count}\n")
            
            f.write("\nError messages:\n")
            for error in self.get_errors():
                f.write(f"  [{error['time']}] {error['message']}\n")

# Usage
analyzer = LogAnalyzer('application.log')
print(f"Total logs: {len(analyzer.logs)}")
print(f"Counts: {analyzer.count_by_level()}")
analyzer.write_summary('log_summary.txt')
print("Summary written to log_summary.txt")
print()

# =============================================================================
# EXAMPLE 2: Configuration File Manager
# =============================================================================

print("=" * 60)
print("EXAMPLE 2: Configuration File Manager")
print("=" * 60)

class ConfigManager:
    def __init__(self, config_file='config.json'):
        self.config_file = Path(config_file)
        self.config = self.load_config()
    
    def load_config(self):
        """Load configuration from JSON file"""
        if self.config_file.exists():
            with open(self.config_file, 'r') as f:
                return json.load(f)
        else:
            # Return default configuration
            return {
                'app': {
                    'name': 'MyApp',
                    'version': '1.0.0',
                    'debug': False
                },
                'database': {
                    'host': 'localhost',
                    'port': 5432,
                    'name': 'mydb'
                },
                'server': {
                    'host': '0.0.0.0',
                    'port': 8080,
                    'workers': 4
                }
            }
    
    def save_config(self):
        """Save configuration to file"""
        with open(self.config_file, 'w') as f:
            json.dump(self.config, f, indent=2)
    
    def get(self, key_path):
        """Get configuration value using dot notation"""
        keys = key_path.split('.')
        value = self.config
        for key in keys:
            value = value.get(key)
            if value is None:
                return None
        return value
    
    def set(self, key_path, value):
        """Set configuration value using dot notation"""
        keys = key_path.split('.')
        config = self.config
        for key in keys[:-1]:
            if key not in config:
                config[key] = {}
            config = config[key]
        config[keys[-1]] = value
        self.save_config()

# Usage
config = ConfigManager('app_config.json')
print(f"App name: {config.get('app.name')}")
print(f"Database port: {config.get('database.port')}")

config.set('app.debug', True)
config.set('server.workers', 8)
print("Configuration updated and saved")
print()

# =============================================================================
# EXAMPLE 3: CSV Data Processor
# =============================================================================

print("=" * 60)
print("EXAMPLE 3: CSV Data Processor")
print("=" * 60)

# Create sample sales data
sales_data = [
    ['Date', 'Product', 'Quantity', 'Price'],
    ['2024-11-01', 'Laptop', '2', '999.99'],
    ['2024-11-01', 'Mouse', '5', '29.99'],
    ['2024-11-02', 'Keyboard', '3', '79.99'],
    ['2024-11-02', 'Monitor', '1', '299.99'],
    ['2024-11-03', 'Laptop', '1', '999.99'],
    ['2024-11-03', 'Mouse', '10', '29.99']
]

with open('sales.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(sales_data)

class SalesProcessor:
    def __init__(self, csv_file):
        self.csv_file = csv_file
        self.data = []
        self.load_data()
    
    def load_data(self):
        """Load CSV data"""
        with open(self.csv_file, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                row['Quantity'] = int(row['Quantity'])
                row['Price'] = float(row['Price'])
                row['Total'] = row['Quantity'] * row['Price']
                self.data.append(row)
    
    def total_sales(self):
        """Calculate total sales"""
        return sum(item['Total'] for item in self.data)
    
    def sales_by_product(self):
        """Calculate sales by product"""
        products = {}
        for item in self.data:
            product = item['Product']
            if product not in products:
                products[product] = 0
            products[product] += item['Total']
        return products
    
    def export_summary(self, output_file):
        """Export summary to CSV"""
        summary = []
        for product, total in self.sales_by_product().items():
            summary.append({'Product': product, 'Total Sales': total})
        
        with open(output_file, 'w', newline='') as f:
            fieldnames = ['Product', 'Total Sales']
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(summary)

# Usage
processor = SalesProcessor('sales.csv')
print(f"Total sales: ${processor.total_sales():,.2f}")
print(f"Sales by product: {processor.sales_by_product()}")
processor.export_summary('sales_summary.csv')
print("Summary exported to sales_summary.csv")
print()

# =============================================================================
# EXAMPLE 4: Simple Contact Book (JSON Storage)
# =============================================================================

print("=" * 60)
print("EXAMPLE 4: Contact Book with JSON Storage")
print("=" * 60)

class ContactBook:
    def __init__(self, storage_file='contacts.json'):
        self.storage_file = Path(storage_file)
        self.contacts = self.load_contacts()
    
    def load_contacts(self):
        """Load contacts from JSON file"""
        if self.storage_file.exists():
            with open(self.storage_file, 'r') as f:
                return json.load(f)
        return []
    
    def save_contacts(self):
        """Save contacts to JSON file"""
        with open(self.storage_file, 'w') as f:
            json.dump(self.contacts, f, indent=2)
    
    def add_contact(self, name, phone, email):
        """Add a new contact"""
        contact = {
            'id': len(self.contacts) + 1,
            'name': name,
            'phone': phone,
            'email': email,
            'created': datetime.now().isoformat()
        }
        self.contacts.append(contact)
        self.save_contacts()
        print(f"✓ Added contact: {name}")
    
    def search(self, query):
        """Search contacts by name"""
        query = query.lower()
        results = [c for c in self.contacts if query in c['name'].lower()]
        return results
    
    def delete_contact(self, contact_id):
        """Delete contact by ID"""
        self.contacts = [c for c in self.contacts if c['id'] != contact_id]
        self.save_contacts()
    
    def export_to_csv(self, filename):
        """Export contacts to CSV"""
        with open(filename, 'w', newline='') as f:
            if self.contacts:
                fieldnames = ['id', 'name', 'phone', 'email']
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for contact in self.contacts:
                    writer.writerow({k: contact[k] for k in fieldnames})

# Usage
contacts = ContactBook('my_contacts.json')
contacts.add_contact('Alice Johnson', '555-1234', 'alice@email.com')
contacts.add_contact('Bob Smith', '555-5678', 'bob@email.com')
contacts.add_contact('Charlie Brown', '555-9012', 'charlie@email.com')

results = contacts.search('alice')
print(f"\nSearch results: {results}")

contacts.export_to_csv('contacts_export.csv')
print("Contacts exported to CSV")
print()

# =============================================================================
# EXAMPLE 5: File Backup System
# =============================================================================

print("=" * 60)
print("EXAMPLE 5: File Backup System")
print("=" * 60)

import shutil
from datetime import datetime

class BackupSystem:
    def __init__(self, backup_dir='backups'):
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(exist_ok=True)
    
    def backup_file(self, file_path):
        """Create timestamped backup of file"""
        file_path = Path(file_path)
        
        if not file_path.exists():
            print(f"File not found: {file_path}")
            return None
        
        # Create timestamp
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_name = f"{file_path.stem}_{timestamp}{file_path.suffix}"
        backup_path = self.backup_dir / backup_name
        
        # Copy file
        shutil.copy2(file_path, backup_path)
        print(f"✓ Backed up: {file_path.name} -> {backup_name}")
        return backup_path
    
    def list_backups(self, original_name):
        """List all backups of a file"""
        stem = Path(original_name).stem
        backups = sorted(self.backup_dir.glob(f"{stem}_*"))
        return backups
    
    def restore_latest(self, original_name, restore_path):
        """Restore the latest backup"""
        backups = self.list_backups(original_name)
        if not backups:
            print(f"No backups found for {original_name}")
            return False
        
        latest = backups[-1]
        shutil.copy2(latest, restore_path)
        print(f"✓ Restored from: {latest.name}")
        return True

# Usage
backup_sys = BackupSystem()

# Create and backup a file
test_file = Path('important.txt')
test_file.write_text('Important data v1\n')
backup_sys.backup_file(test_file)

# Modify and backup again
test_file.write_text('Important data v2\n')
backup_sys.backup_file(test_file)

# List backups
backups = backup_sys.list_backups('important.txt')
print(f"Available backups: {[b.name for b in backups]}")
print()

# =============================================================================
# EXAMPLE 6: Text File Search Tool
# =============================================================================

print("=" * 60)
print("EXAMPLE 6: Text File Search Tool")
print("=" * 60)

class FileSearcher:
    def __init__(self, directory='.'):
        self.directory = Path(directory)
    
    def search_in_file(self, file_path, search_term):
        """Search for term in a file"""
        results = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                for line_num, line in enumerate(f, 1):
                    if search_term.lower() in line.lower():
                        results.append({
                            'line_num': line_num,
                            'line': line.strip()
                        })
        except Exception as e:
            pass
        return results
    
    def search_directory(self, search_term, file_pattern='*.txt'):
        """Search for term in all matching files"""
        results = {}
        for file_path in self.directory.rglob(file_pattern):
            if file_path.is_file():
                matches = self.search_in_file(file_path, search_term)
                if matches:
                    results[str(file_path)] = matches
        return results
    
    def save_results(self, results, output_file):
        """Save search results to file"""
        with open(output_file, 'w') as f:
            f.write(f"SEARCH RESULTS\n")
            f.write("=" * 60 + "\n\n")
            
            for file_path, matches in results.items():
                f.write(f"File: {file_path}\n")
                f.write(f"Matches: {len(matches)}\n")
                for match in matches:
                    f.write(f"  Line {match['line_num']}: {match['line']}\n")
                f.write("\n")

# Usage
searcher = FileSearcher('.')
results = searcher.search_directory('file', '*.txt')
print(f"Found '{len(results)}' files with matches")
if results:
    searcher.save_results(results, 'search_results.txt')
    print("Results saved to search_results.txt")
print()

# =============================================================================
# EXAMPLE 7: File Organizer
# =============================================================================

print("=" * 60)
print("EXAMPLE 7: File Organizer by Extension")
print("=" * 60)

class FileOrganizer:
    def __init__(self, source_dir):
        self.source_dir = Path(source_dir)
    
    def organize_by_extension(self):
        """Organize files into folders by extension"""
        if not self.source_dir.exists():
            print(f"Directory not found: {self.source_dir}")
            return
        
        # Get all files
        files = [f for f in self.source_dir.iterdir() if f.is_file()]
        
        # Group by extension
        extensions = {}
        for file in files:
            ext = file.suffix.lower() or '.no_extension'
            if ext not in extensions:
                extensions[ext] = []
            extensions[ext].append(file)
        
        # Create folders and move files
        for ext, files in extensions.items():
            folder_name = ext[1:] if ext.startswith('.') else ext
            folder_path = self.source_dir / folder_name
            folder_path.mkdir(exist_ok=True)
            
            for file in files:
                # Don't move if already in correct folder
                if file.parent != folder_path:
                    new_path = folder_path / file.name
                    # Handle duplicates
                    if new_path.exists():
                        stem = file.stem
                        suffix = file.suffix
                        counter = 1
                        while new_path.exists():
                            new_path = folder_path / f"{stem}_{counter}{suffix}"
                            counter += 1
                    print(f"Moving: {file.name} -> {folder_name}/")
                    # file.rename(new_path)  # Commented to avoid actual moving

# Usage (demonstration only - not actually moving files)
print("File organizer demonstrated (files not actually moved)")
print()

print("=" * 60)
print("EXAMPLES COMPLETE!")
print("=" * 60)
