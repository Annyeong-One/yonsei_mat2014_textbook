"""
EXERCISES - File Operations
============================

Practice problems to master file operations. Solutions are in 04_solutions.py
Try to solve these on your own first!

Difficulty levels: ⭐ Easy | ⭐⭐ Medium | ⭐⭐⭐ Hard
"""

# =============================================================================
# SECTION 1: BASIC FILE OPERATIONS
# =============================================================================

print("=" * 60)
print("SECTION 1: BASIC FILE OPERATIONS")
print("=" * 60)

# Exercise 1.1 ⭐
# Write text to a file
def exercise_1_1():
    """
    Create a file called 'hello.txt' and write 'Hello, World!' to it
    """
    # Your code here
    pass

# Exercise 1.2 ⭐
# Read entire file
def exercise_1_2():
    """
    Read and print the contents of 'hello.txt'
    """
    # Your code here
    pass

# Exercise 1.3 ⭐
# Append to file
def exercise_1_3():
    """
    Append 'This is a new line' to 'hello.txt'
    """
    # Your code here
    pass

# Exercise 1.4 ⭐⭐
# Read file line by line
def exercise_1_4():
    """
    Read 'hello.txt' line by line and print each line with its line number
    """
    # Your code here
    pass

# Exercise 1.5 ⭐⭐
# Count lines, words, and characters
def exercise_1_5(filename):
    """
    Count lines, words, and characters in a file
    Return as tuple: (lines, words, chars)
    """
    # Your code here
    pass

# =============================================================================
# SECTION 2: PATH OPERATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 2: PATH OPERATIONS")
print("=" * 60)

# Exercise 2.1 ⭐
# Check if file exists
def exercise_2_1(filename):
    """
    Check if a file exists using pathlib
    """
    # Your code here
    pass

# Exercise 2.2 ⭐
# Get file extension
def exercise_2_2(filename):
    """
    Get the file extension using pathlib
    """
    # Your code here
    pass

# Exercise 2.3 ⭐⭐
# Create directory if not exists
def exercise_2_3(directory_name):
    """
    Create a directory if it doesn't exist
    """
    # Your code here
    pass

# Exercise 2.4 ⭐⭐
# List all files with specific extension
def exercise_2_4(directory, extension):
    """
    List all files with given extension in a directory
    Return list of Path objects
    """
    # Your code here
    pass

# Exercise 2.5 ⭐⭐⭐
# Find largest file in directory
def exercise_2_5(directory):
    """
    Find the largest file in a directory
    Return (filename, size_in_bytes)
    """
    # Your code here
    pass

# =============================================================================
# SECTION 3: CSV FILES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 3: CSV FILES")
print("=" * 60)

# Exercise 3.1 ⭐
# Write data to CSV
def exercise_3_1():
    """
    Write this data to 'students.csv':
    Name, Age, Grade
    Alice, 20, A
    Bob, 21, B
    Charlie, 19, A
    """
    # Your code here
    pass

# Exercise 3.2 ⭐⭐
# Read CSV and filter
def exercise_3_2():
    """
    Read 'students.csv' and print only students with grade 'A'
    """
    # Your code here
    pass

# Exercise 3.3 ⭐⭐
# Add column to CSV
def exercise_3_3():
    """
    Read 'students.csv', add a 'Pass' column (True for all),
    and save to 'students_updated.csv'
    """
    # Your code here
    pass

# Exercise 3.4 ⭐⭐⭐
# Merge two CSV files
def exercise_3_4(file1, file2, output_file):
    """
    Merge two CSV files with same headers into one
    """
    # Your code here
    pass

# =============================================================================
# SECTION 4: JSON FILES
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 4: JSON FILES")
print("=" * 60)

# Exercise 4.1 ⭐
# Write dict to JSON
def exercise_4_1():
    """
    Write this dictionary to 'person.json':
    {'name': 'Alice', 'age': 30, 'city': 'NYC'}
    """
    # Your code here
    pass

# Exercise 4.2 ⭐
# Read JSON file
def exercise_4_2():
    """
    Read 'person.json' and print the person's name
    """
    # Your code here
    pass

# Exercise 4.3 ⭐⭐
# Update JSON file
def exercise_4_3():
    """
    Read 'person.json', add a 'country': 'USA' field,
    and save it back
    """
    # Your code here
    pass

# Exercise 4.4 ⭐⭐⭐
# JSON database
def exercise_4_4():
    """
    Create a simple JSON database:
    - add_user(name, email)
    - get_user(name)
    - delete_user(name)
    - list_all_users()
    Store in 'users.json'
    """
    # Your code here
    pass

# =============================================================================
# SECTION 5: ERROR HANDLING
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 5: ERROR HANDLING")
print("=" * 60)

# Exercise 5.1 ⭐
# Handle file not found
def exercise_5_1(filename):
    """
    Try to read a file, handle FileNotFoundError gracefully
    Return file content or None if not found
    """
    # Your code here
    pass

# Exercise 5.2 ⭐⭐
# Safe file write
def exercise_5_2(filename, content):
    """
    Write to file with proper error handling
    Handle PermissionError and other exceptions
    Return True if successful, False otherwise
    """
    # Your code here
    pass

# Exercise 5.3 ⭐⭐⭐
# Atomic write with backup
def exercise_5_3(filename, content):
    """
    Write to file atomically:
    1. Create backup if file exists
    2. Write to temporary file
    3. Rename temp file to target
    4. Handle all possible errors
    """
    # Your code here
    pass

# =============================================================================
# SECTION 6: FILE PROCESSING
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 6: FILE PROCESSING")
print("=" * 60)

# Exercise 6.1 ⭐⭐
# Find and replace in file
def exercise_6_1(filename, find_text, replace_text):
    """
    Find and replace text in a file
    Save result to new file with '_modified' suffix
    """
    # Your code here
    pass

# Exercise 6.2 ⭐⭐
# Remove blank lines
def exercise_6_2(input_file, output_file):
    """
    Remove all blank lines from a file
    """
    # Your code here
    pass

# Exercise 6.3 ⭐⭐⭐
# Sort lines in file
def exercise_6_3(input_file, output_file):
    """
    Sort all lines in a file alphabetically
    """
    # Your code here
    pass

# Exercise 6.4 ⭐⭐⭐
# Merge multiple files
def exercise_6_4(input_files, output_file):
    """
    Merge multiple text files into one
    Add filename header before each file's content
    """
    # Your code here
    pass

# =============================================================================
# SECTION 7: REAL-WORLD APPLICATIONS
# =============================================================================

print("\n" + "=" * 60)
print("SECTION 7: REAL-WORLD APPLICATIONS")
print("=" * 60)

# Exercise 7.1 ⭐⭐⭐
# Simple note-taking app
def exercise_7_1():
    """
    Create a note-taking app:
    - add_note(title, content)
    - view_note(title)
    - list_notes()
    - delete_note(title)
    Store notes in separate files in 'notes/' directory
    """
    # Your code here
    pass

# Exercise 7.2 ⭐⭐⭐
# Configuration manager
def exercise_7_2():
    """
    Create a configuration manager:
    - load_config(filename)
    - get_value(key)
    - set_value(key, value)
    - save_config()
    Support both JSON and simple key=value format
    """
    # Your code here
    pass

# Exercise 7.3 ⭐⭐⭐
# Log file analyzer
def exercise_7_3(log_file):
    """
    Analyze a log file:
    - Count entries by log level (INFO, WARNING, ERROR)
    - Find most recent error
    - Extract timestamps
    - Generate summary report
    """
    # Your code here
    pass

# Exercise 7.4 ⭐⭐⭐
# CSV to JSON converter
def exercise_7_4(csv_file, json_file):
    """
    Convert CSV file to JSON file
    Each CSV row becomes a JSON object
    """
    # Your code here
    pass

# Exercise 7.5 ⭐⭐⭐
# File-based cache
def exercise_7_5():
    """
    Create a file-based cache system:
    - set(key, value, ttl=None)
    - get(key)
    - delete(key)
    - clear()
    Store in JSON with timestamp for TTL
    """
    # Your code here
    pass

# =============================================================================
# BONUS CHALLENGES
# =============================================================================

print("\n" + "=" * 60)
print("BONUS CHALLENGES")
print("=" * 60)

# Bonus 1 ⭐⭐⭐
# File diff tool
def file_diff(file1, file2):
    """
    Compare two files and show differences
    Return list of (line_num, line1, line2) for different lines
    """
    # Your code here
    pass

# Bonus 2 ⭐⭐⭐
# File encryption/decryption
def encrypt_file(input_file, output_file, key):
    """
    Simple XOR encryption of file
    """
    # Your code here
    pass

def decrypt_file(input_file, output_file, key):
    """
    Decrypt XOR encrypted file
    """
    # Your code here
    pass

# Bonus 3 ⭐⭐⭐
# Directory synchronizer
def sync_directories(source_dir, target_dir):
    """
    Sync files from source to target directory
    - Copy new files
    - Update modified files
    - Optionally delete removed files
    """
    # Your code here
    pass

# Bonus 4 ⭐⭐⭐
# Simple database
class FileDatabase:
    """
    Create a simple file-based database:
    - insert(table, record)
    - select(table, condition)
    - update(table, condition, updates)
    - delete(table, condition)
    Store each table as a JSON file
    """
    # Your code here
    pass

# Bonus 5 ⭐⭐⭐
# File versioning system
class FileVersioning:
    """
    Create a simple file versioning system:
    - save_version(filename)
    - list_versions(filename)
    - restore_version(filename, version)
    - diff_versions(filename, v1, v2)
    """
    # Your code here
    pass

print("\n" + "=" * 60)
print("EXERCISES COMPLETE!")
print("Check 04_solutions.py for answers")
print("=" * 60)
