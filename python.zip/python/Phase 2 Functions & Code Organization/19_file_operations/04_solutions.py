"""
SOLUTIONS - File Operations
============================

Solutions to all exercises in 03_exercises.py
"""

from pathlib import Path
import csv
import json
import shutil
from datetime import datetime

# =============================================================================
# SECTION 1: BASIC FILE OPERATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 1: BASIC FILE OPERATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 1.1 Solution
def exercise_1_1():
    with open('hello.txt', 'w') as f:
        f.write('Hello, World!')
    print("✓ File created")

exercise_1_1()

# Exercise 1.2 Solution
def exercise_1_2():
    with open('hello.txt', 'r') as f:
        content = f.read()
        print(f"Content: {content}")

exercise_1_2()

# Exercise 1.3 Solution
def exercise_1_3():
    with open('hello.txt', 'a') as f:
        f.write('\nThis is a new line')
    print("✓ Line appended")

exercise_1_3()

# Exercise 1.4 Solution
def exercise_1_4():
    with open('hello.txt', 'r') as f:
        for line_num, line in enumerate(f, 1):
            print(f"  Line {line_num}: {line.rstrip()}")

exercise_1_4()

# Exercise 1.5 Solution
def exercise_1_5(filename):
    with open(filename, 'r') as f:
        content = f.read()
        lines = content.count('\n') + (1 if content else 0)
        words = len(content.split())
        chars = len(content)
        return (lines, words, chars)

stats = exercise_1_5('hello.txt')
print(f"Stats: {stats[0]} lines, {stats[1]} words, {stats[2]} chars")
print()

# =============================================================================
# SECTION 2: PATH OPERATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 2: PATH OPERATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 2.1 Solution
def exercise_2_1(filename):
    return Path(filename).exists()

print(f"hello.txt exists: {exercise_2_1('hello.txt')}")

# Exercise 2.2 Solution
def exercise_2_2(filename):
    return Path(filename).suffix

print(f"Extension: {exercise_2_2('hello.txt')}")

# Exercise 2.3 Solution
def exercise_2_3(directory_name):
    Path(directory_name).mkdir(exist_ok=True)
    print(f"✓ Directory created/verified: {directory_name}")

exercise_2_3('test_dir')

# Exercise 2.4 Solution
def exercise_2_4(directory, extension):
    return list(Path(directory).glob(f'*{extension}'))

txt_files = exercise_2_4('.', '.txt')
print(f"Found {len(txt_files)} .txt files")

# Exercise 2.5 Solution
def exercise_2_5(directory):
    files = [f for f in Path(directory).iterdir() if f.is_file()]
    if not files:
        return None
    largest = max(files, key=lambda f: f.stat().st_size)
    return (largest.name, largest.stat().st_size)

result = exercise_2_5('.')
if result:
    print(f"Largest file: {result[0]} ({result[1]} bytes)")
print()

# =============================================================================
# SECTION 3: CSV FILES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 3: CSV FILES - SOLUTIONS")
print("=" * 60)

# Exercise 3.1 Solution
def exercise_3_1():
    data = [
        ['Name', 'Age', 'Grade'],
        ['Alice', '20', 'A'],
        ['Bob', '21', 'B'],
        ['Charlie', '19', 'A']
    ]
    with open('students.csv', 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerows(data)
    print("✓ CSV created")

exercise_3_1()

# Exercise 3.2 Solution
def exercise_3_2():
    with open('students.csv', 'r') as f:
        reader = csv.DictReader(f)
        print("Students with grade A:")
        for row in reader:
            if row['Grade'] == 'A':
                print(f"  {row['Name']}")

exercise_3_2()

# Exercise 3.3 Solution
def exercise_3_3():
    rows = []
    with open('students.csv', 'r') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames + ['Pass']
        for row in reader:
            row['Pass'] = 'True'
            rows.append(row)
    
    with open('students_updated.csv', 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print("✓ CSV updated")

exercise_3_3()

# Exercise 3.4 Solution
def exercise_3_4(file1, file2, output_file):
    rows = []
    
    with open(file1, 'r') as f:
        reader = csv.DictReader(f)
        rows.extend(list(reader))
    
    with open(file2, 'r') as f:
        reader = csv.DictReader(f)
        rows.extend(list(reader))
    
    if rows:
        with open(output_file, 'w', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        print(f"✓ Merged to {output_file}")

print()

# =============================================================================
# SECTION 4: JSON FILES - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 4: JSON FILES - SOLUTIONS")
print("=" * 60)

# Exercise 4.1 Solution
def exercise_4_1():
    person = {'name': 'Alice', 'age': 30, 'city': 'NYC'}
    with open('person.json', 'w') as f:
        json.dump(person, f, indent=2)
    print("✓ JSON created")

exercise_4_1()

# Exercise 4.2 Solution
def exercise_4_2():
    with open('person.json', 'r') as f:
        person = json.load(f)
        print(f"Name: {person['name']}")

exercise_4_2()

# Exercise 4.3 Solution
def exercise_4_3():
    with open('person.json', 'r') as f:
        person = json.load(f)
    
    person['country'] = 'USA'
    
    with open('person.json', 'w') as f:
        json.dump(person, f, indent=2)
    print("✓ JSON updated")

exercise_4_3()

# Exercise 4.4 Solution
def exercise_4_4():
    class JSONDatabase:
        def __init__(self, filename='users.json'):
            self.filename = filename
            self.users = self.load()
        
        def load(self):
            if Path(self.filename).exists():
                with open(self.filename, 'r') as f:
                    return json.load(f)
            return []
        
        def save(self):
            with open(self.filename, 'w') as f:
                json.dump(self.users, f, indent=2)
        
        def add_user(self, name, email):
            self.users.append({'name': name, 'email': email})
            self.save()
        
        def get_user(self, name):
            for user in self.users:
                if user['name'] == name:
                    return user
            return None
        
        def delete_user(self, name):
            self.users = [u for u in self.users if u['name'] != name]
            self.save()
        
        def list_all_users(self):
            return self.users
    
    db = JSONDatabase()
    db.add_user('Alice', 'alice@email.com')
    db.add_user('Bob', 'bob@email.com')
    print(f"All users: {db.list_all_users()}")

exercise_4_4()
print()

# =============================================================================
# SECTION 5: ERROR HANDLING - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 5: ERROR HANDLING - SOLUTIONS")
print("=" * 60)

# Exercise 5.1 Solution
def exercise_5_1(filename):
    try:
        with open(filename, 'r') as f:
            return f.read()
    except FileNotFoundError:
        print(f"File not found: {filename}")
        return None

content = exercise_5_1('hello.txt')
print(f"Read successful: {content is not None}")

# Exercise 5.2 Solution
def exercise_5_2(filename, content):
    try:
        with open(filename, 'w') as f:
            f.write(content)
        return True
    except PermissionError:
        print(f"Permission denied: {filename}")
        return False
    except Exception as e:
        print(f"Error: {e}")
        return False

result = exercise_5_2('test_write.txt', 'Test content')
print(f"Write successful: {result}")

# Exercise 5.3 Solution
def exercise_5_3(filename, content):
    try:
        file_path = Path(filename)
        
        # Create backup
        if file_path.exists():
            backup = Path(f"{filename}.bak")
            shutil.copy2(file_path, backup)
        
        # Write to temp file
        temp_file = Path(f"{filename}.tmp")
        with open(temp_file, 'w') as f:
            f.write(content)
        
        # Atomic rename
        temp_file.replace(file_path)
        return True
    except Exception as e:
        print(f"Error: {e}")
        return False

result = exercise_5_3('atomic_test.txt', 'Atomic write content')
print(f"Atomic write successful: {result}")
print()

# =============================================================================
# SECTION 6: FILE PROCESSING - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 6: FILE PROCESSING - SOLUTIONS")
print("=" * 60)

# Exercise 6.1 Solution
def exercise_6_1(filename, find_text, replace_text):
    with open(filename, 'r') as f:
        content = f.read()
    
    modified = content.replace(find_text, replace_text)
    
    output = Path(filename).stem + '_modified' + Path(filename).suffix
    with open(output, 'w') as f:
        f.write(modified)
    print(f"✓ Modified file: {output}")

# Exercise 6.2 Solution
def exercise_6_2(input_file, output_file):
    with open(input_file, 'r') as f:
        lines = [line for line in f if line.strip()]
    
    with open(output_file, 'w') as f:
        f.writelines(lines)
    print(f"✓ Removed blank lines")

# Exercise 6.3 Solution
def exercise_6_3(input_file, output_file):
    with open(input_file, 'r') as f:
        lines = sorted(f.readlines())
    
    with open(output_file, 'w') as f:
        f.writelines(lines)
    print(f"✓ Lines sorted")

# Exercise 6.4 Solution
def exercise_6_4(input_files, output_file):
    with open(output_file, 'w') as out:
        for input_file in input_files:
            out.write(f"\n{'='*60}\n")
            out.write(f"FILE: {input_file}\n")
            out.write(f"{'='*60}\n\n")
            
            with open(input_file, 'r') as f:
                out.write(f.read())
                out.write('\n')
    print(f"✓ Files merged")

print()

# =============================================================================
# SECTION 7: REAL-WORLD APPLICATIONS - SOLUTIONS
# =============================================================================

print("=" * 60)
print("SECTION 7: REAL-WORLD APPLICATIONS - SOLUTIONS")
print("=" * 60)

# Exercise 7.1 Solution
def exercise_7_1():
    class NoteApp:
        def __init__(self, notes_dir='notes'):
            self.notes_dir = Path(notes_dir)
            self.notes_dir.mkdir(exist_ok=True)
        
        def add_note(self, title, content):
            note_file = self.notes_dir / f"{title}.txt"
            with open(note_file, 'w') as f:
                f.write(content)
            print(f"✓ Note added: {title}")
        
        def view_note(self, title):
            note_file = self.notes_dir / f"{title}.txt"
            if note_file.exists():
                return note_file.read_text()
            return None
        
        def list_notes(self):
            return [f.stem for f in self.notes_dir.glob('*.txt')]
        
        def delete_note(self, title):
            note_file = self.notes_dir / f"{title}.txt"
            if note_file.exists():
                note_file.unlink()
                print(f"✓ Note deleted: {title}")
    
    app = NoteApp()
    app.add_note('meeting', 'Discuss project timeline')
    print(f"Notes: {app.list_notes()}")

exercise_7_1()

# Exercise 7.2 Solution
def exercise_7_2():
    class ConfigManager:
        def __init__(self, filename='config.json'):
            self.filename = filename
            self.config = self.load_config()
        
        def load_config(self):
            if Path(self.filename).exists():
                with open(self.filename, 'r') as f:
                    return json.load(f)
            return {}
        
        def save_config(self):
            with open(self.filename, 'w') as f:
                json.dump(self.config, f, indent=2)
        
        def get_value(self, key):
            return self.config.get(key)
        
        def set_value(self, key, value):
            self.config[key] = value
            self.save_config()
    
    config = ConfigManager('app.json')
    config.set_value('debug', True)
    print(f"Config debug: {config.get_value('debug')}")

exercise_7_2()

# Exercise 7.3 Solution
def exercise_7_3(log_file):
    counts = {}
    errors = []
    
    with open(log_file, 'r') as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 3:
                level = parts[2]
                counts[level] = counts.get(level, 0) + 1
                
                if level == 'ERROR':
                    errors.append(line.strip())
    
    return {
        'counts': counts,
        'latest_error': errors[-1] if errors else None,
        'total_errors': len(errors)
    }

# Exercise 7.4 Solution
def exercise_7_4(csv_file, json_file):
    data = []
    with open(csv_file, 'r') as f:
        reader = csv.DictReader(f)
        data = list(reader)
    
    with open(json_file, 'w') as f:
        json.dump(data, f, indent=2)
    print(f"✓ Converted {csv_file} to {json_file}")

exercise_7_4('students.csv', 'students.json')

# Exercise 7.5 Solution
def exercise_7_5():
    class FileCache:
        def __init__(self, cache_file='cache.json'):
            self.cache_file = cache_file
            self.cache = self.load()
        
        def load(self):
            if Path(self.cache_file).exists():
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            return {}
        
        def save(self):
            with open(self.cache_file, 'w') as f:
                json.dump(self.cache, f, indent=2)
        
        def set(self, key, value, ttl=None):
            self.cache[key] = {
                'value': value,
                'timestamp': datetime.now().isoformat(),
                'ttl': ttl
            }
            self.save()
        
        def get(self, key):
            if key in self.cache:
                entry = self.cache[key]
                # Check TTL if set
                if entry.get('ttl'):
                    created = datetime.fromisoformat(entry['timestamp'])
                    if (datetime.now() - created).seconds > entry['ttl']:
                        del self.cache[key]
                        self.save()
                        return None
                return entry['value']
            return None
        
        def delete(self, key):
            if key in self.cache:
                del self.cache[key]
                self.save()
        
        def clear(self):
            self.cache = {}
            self.save()
    
    cache = FileCache()
    cache.set('user', 'Alice', ttl=60)
    print(f"Cached user: {cache.get('user')}")

exercise_7_5()
print()

print("=" * 60)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 60)
