# Module 14: File Operations 📁

This comprehensive module covers everything you need to know about working with files and directories in Python - from basic file reading/writing to advanced topics like CSV, JSON, and temporary files.

## 📋 Prerequisites

**Required:** Before starting this module, you should have completed:
- **Module 13: Console I/O** - Understanding of input/output basics and formatting
- **Module 12: Functions** - Ability to create reusable code
- **Module 06-07: Control Flow** - Working with loops and conditionals
- **Module 08-11: Data Structures** - Understanding of lists, dictionaries

## 🎯 What You'll Learn

This module progresses from basic to advanced file operations:

### Part 1: Basics (Essential Foundation)
- Opening and closing files
- Context managers (`with` statement)
- File modes (r, w, a, x, b, +)
- Reading files (read, readline, readlines)
- Writing files (write, writelines)
- File positions (seek, tell)
- Basic error handling (FileNotFoundError, PermissionError)

### Part 2: Advanced Topics
- **Working with Paths** - pathlib module for modern path handling
- **Directory Operations** - Creating, listing, navigating directories
- **CSV Files** - Reading and writing structured data
- **JSON Files** - Working with JSON format
- **Binary Files** - Handling non-text files
- **File Information** - Getting file metadata and stats
- **Advanced Patterns** - Memory-efficient processing, atomic writes
- **Encoding** - UTF-8, ASCII, and other encodings
- **Temporary Files** - Using tempfile module

## 📁 Module Structure

```
14_file_operations/
├── README.md                          # This file
├── 01_file_operations_tutorial.py     # Complete tutorial (Part 1 & 2)
├── 02_examples.py                     # Practical examples
├── 03_exercises.py                    # Practice problems
├── 04_solutions.py                    # Exercise solutions
└── sample_files/                      # Sample files for practice
    ├── sample_text.txt
    ├── employees.csv
    ├── config.json
    └── ...
```

## 🚀 Getting Started

### 1. Read the Tutorial
Start with `01_file_operations_tutorial.py`:
```bash
python 01_file_operations_tutorial.py
```

The tutorial is comprehensive and covers everything from basics to advanced topics. Read it section by section.

### 2. Study the Examples
Check out `02_examples.py` for practical, real-world examples:
```bash
python 02_examples.py
```

### 3. Practice with Exercises
Complete the exercises in `03_exercises.py`:
```bash
python 03_exercises.py
```

### 4. Check Solutions
Compare your work with `04_solutions.py` to see different approaches.

## 💡 Quick Reference

### Opening Files
```python
# Reading
with open('file.txt', 'r') as f:
    content = f.read()

# Writing
with open('file.txt', 'w') as f:
    f.write('Hello, World!')

# Appending
with open('file.txt', 'a') as f:
    f.write('More text')
```

### File Modes
- `'r'` - Read (default) - file must exist
- `'w'` - Write (creates/overwrites)
- `'a'` - Append (adds to end)
- `'x'` - Exclusive creation (fails if exists)
- `'b'` - Binary mode
- `'t'` - Text mode (default)
- `'+'` - Read and write

### Common Operations
```python
# Read all content
content = f.read()

# Read lines into list
lines = f.readlines()

# Iterate line by line (memory efficient)
for line in f:
    print(line.strip())

# Write text
f.write('text\n')

# Write multiple lines
f.writelines(['line1\n', 'line2\n'])

# Use print to file
print('text', file=f)
```

### Working with Paths (pathlib)
```python
from pathlib import Path

# Create path object
p = Path('folder/file.txt')

# Check existence
if p.exists():
    print("File exists")

# Create directory
p.parent.mkdir(parents=True, exist_ok=True)

# Get file info
print(f"Name: {p.name}")
print(f"Extension: {p.suffix}")
print(f"Parent: {p.parent}")

# Read/write with pathlib
text = p.read_text()
p.write_text('New content')
```

### CSV Files
```python
import csv

# Reading CSV
with open('data.csv', 'r') as f:
    reader = csv.reader(f)
    for row in reader:
        print(row)

# Reading with headers (DictReader)
with open('data.csv', 'r') as f:
    reader = csv.DictReader(f)
    for row in reader:
        print(row['Name'], row['Age'])

# Writing CSV
with open('data.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['Name', 'Age', 'City'])
    writer.writerow(['Alice', 30, 'NY'])
```

### JSON Files
```python
import json

# Reading JSON
with open('data.json', 'r') as f:
    data = json.load(f)

# Writing JSON
with open('data.json', 'w') as f:
    json.dump(data, f, indent=2)

# JSON string operations
json_str = json.dumps(data, indent=2)
data = json.loads(json_str)
```

## ⚠️ Common Mistakes to Avoid

1. **Not using context managers**
   ```python
   # Wrong
   f = open('file.txt')
   content = f.read()
   f.close()  # Might not close if error occurs
   
   # Correct
   with open('file.txt') as f:
       content = f.read()
   # File automatically closes
   ```

2. **Using 'w' mode when you meant 'a'**
   ```python
   # This OVERWRITES the file!
   with open('log.txt', 'w') as f:
       f.write('New log entry')
   
   # This APPENDS to the file
   with open('log.txt', 'a') as f:
       f.write('New log entry')
   ```

3. **Not handling errors**
   ```python
   # Wrong
   with open('file.txt') as f:  # Crashes if file doesn't exist
       content = f.read()
   
   # Correct
   try:
       with open('file.txt') as f:
           content = f.read()
   except FileNotFoundError:
       print("File not found!")
   ```

4. **Not specifying encoding**
   ```python
   # Better practice (especially for non-ASCII)
   with open('file.txt', 'r', encoding='utf-8') as f:
       content = f.read()
   ```

## 🎓 Key Concepts

- **Context Manager** - Always use `with` statement for automatic cleanup
- **File Modes** - Choose the correct mode for your operation
- **Error Handling** - Handle FileNotFoundError, PermissionError gracefully
- **Binary vs Text** - Know when to use 'b' mode
- **Buffering** - Files are buffered by default for efficiency
- **Encoding** - Always specify encoding for text files (default UTF-8)
- **Path Operations** - Use pathlib for modern, cross-platform path handling
- **Memory Efficiency** - Iterate through large files instead of loading all at once

## 📚 Best Practices

1. **Always use context managers** (`with` statement)
2. **Specify encoding** for text files
3. **Handle exceptions** properly
4. **Use pathlib** for path operations (not os.path)
5. **Validate file exists** before operations
6. **Close files** or use context managers
7. **Use appropriate modes** (don't use 'w' when you mean 'a')
8. **Process large files** line by line for memory efficiency

## 🔗 What's Next?

After completing this module, you'll be ready for:

- **Module 15: LEGB Rule** - Understanding scope and namespaces
- **Module 16: Recursion** - Master recursive functions  
- **Module 17: Memory and Namespace** - Deep understanding of Python internals

## 📖 Additional Resources

- [Python Official Documentation - File I/O](https://docs.python.org/3/tutorial/inputoutput.html#reading-and-writing-files)
- [pathlib Documentation](https://docs.python.org/3/library/pathlib.html)
- [CSV Module](https://docs.python.org/3/library/csv.html)
- [JSON Module](https://docs.python.org/3/library/json.html)

## 🤝 Need Help?

- Review the comprehensive tutorial file
- Study the examples for practical patterns
- Try the exercises one by one
- Compare your solutions with the provided ones
- Break complex problems into smaller steps

## ⭐ Tips for Success

1. **Practice regularly** - Work with different file types
2. **Always validate** - Check if files exist before operations
3. **Use pathlib** - It's more readable and cross-platform
4. **Handle errors** - File operations can fail in many ways
5. **Think about memory** - Process large files efficiently
6. **Specify encoding** - Avoid encoding issues
7. **Test edge cases** - Empty files, missing files, permission errors

---

**Ready to start?** Run `01_file_operations_tutorial.py` and begin mastering file operations! 🚀

**Note:** This module builds on Module 13 (Console I/O). Make sure you're comfortable with console input/output before proceeding.
