"""
Python Regular Expressions - Tutorial 04: Anchors and Boundaries
================================================================

LEARNING OBJECTIVES:
-------------------
1. Understand anchors (^, $) for position matching
2. Use word boundaries (\b, \B) effectively
3. Apply multiline mode for line-based matching
4. Distinguish between \A, \Z and ^, $
5. Combine anchors with other regex patterns

PREREQUISITES:
-------------
- Tutorials 01-03 (Basics, Character Classes, Quantifiers)

DIFFICULTY: INTERMEDIATE
"""

import re

# ==============================================================================
# SECTION 1: INTRODUCTION TO ANCHORS
# ==============================================================================

"""
ANCHORS don't match characters - they match POSITIONS in the string.

Main anchors:
  ^     Start of string (or line in multiline mode)
  $     End of string (or line in multiline mode)
  \A    Start of string (always)
  \Z    End of string (always)
  \b    Word boundary
  \B    Not a word boundary
"""

print("="*70)
print("SECTION 1: START AND END ANCHORS (^ and $)")
print("="*70)

# Example 1: Start anchor ^
# -------------------------
text1 = "hello world"

# Match "hello" only at the start
pattern_start = r"^hello"
match = re.search(pattern_start, text1)
print(f"Text: '{text1}'")
print(f"Pattern '^hello' (hello at start): {bool(match)}")

# This won't match because "world" is not at the start
pattern_not_start = r"^world"
match2 = re.search(pattern_not_start, text1)
print(f"Pattern '^world' (world at start): {bool(match2)}")

print()

# Example 2: End anchor $
# -----------------------
text2 = "hello world"

# Match "world" only at the end
pattern_end = r"world$"
match3 = re.search(pattern_end, text2)
print(f"Text: '{text2}'")
print(f"Pattern 'world$' (world at end): {bool(match3)}")

# This won't match because "hello" is not at the end
pattern_not_end = r"hello$"
match4 = re.search(pattern_not_end, text2)
print(f"Pattern 'hello$' (hello at end): {bool(match4)}")

print()

# Example 3: Combining ^ and $ for exact match
# --------------------------------------------
"""
Using both ^ and $ ensures the pattern matches the ENTIRE string.
This is very useful for validation!
"""

text3 = "hello"
pattern_exact = r"^hello$"  # Entire string must be exactly "hello"

test_strings = ["hello", "hello world", "hi hello", "  hello  "]
print(f"Pattern: '{pattern_exact}' (exact match)")
for test in test_strings:
    match = re.search(pattern_exact, test)
    result = "✓ Match" if match else "✗ No match"
    print(f"  '{test}': {result}")

print()

# ==============================================================================
# SECTION 2: WORD BOUNDARIES (\b and \B)
# ==============================================================================

"""
WORD BOUNDARIES (\b) match positions where:
- A word character (\w) is adjacent to a non-word character (\W)
- At the start/end of the string if it starts/ends with a word character

\B matches positions that are NOT word boundaries.
"""

print("="*70)
print("SECTION 2: WORD BOUNDARIES")
print("="*70)

# Example 4: Finding whole words with \b
# ---------------------------------------
text4 = "the cat in the cathedral"

# Without word boundary - matches partial words
pattern_no_boundary = r"cat"
matches_partial = re.findall(pattern_no_boundary, text4)
print(f"Text: '{text4}'")
print(f"Pattern 'cat' (no boundary):")
print(f"  Matches: {matches_partial}")
print(f"  (Note: matches 'cat' in 'cathedral' too)")

# With word boundary - matches only complete words
pattern_with_boundary = r"\bcat\b"
matches_whole = re.findall(pattern_with_boundary, text4)
print(f"Pattern '\\bcat\\b' (with boundary):")
print(f"  Matches: {matches_whole}")
print(f"  (Only matches 'cat' as a complete word)")

print()

# Example 5: Word boundary at start or end only
# ---------------------------------------------
text5 = "python is pythonic, not pythonesque"

# Match "python" only at the start of words
pattern_start_word = r"\bpython"
matches_start = re.findall(pattern_start_word, text5)
print(f"Text: '{text5}'")
print(f"Pattern '\\bpython' (python at word start):")
print(f"  Matches: {matches_start}")

# Match "python" only at the end of words  
pattern_end_word = r"python\b"
matches_end = re.findall(pattern_end_word, text5)
print(f"Pattern 'python\\b' (python at word end):")
print(f"  Matches: {matches_end}")

print()

# Example 6: Non-word boundary \B
# --------------------------------
text6 = "the cat in the cathedral"

# Match "cat" only when it's NOT a complete word
pattern_non_boundary = r"\Bcat|cat\B"
matches = re.findall(pattern_non_boundary, text6)
print(f"Text: '{text6}'")
print(f"Pattern '\\Bcat|cat\\B' (cat not at word boundary):")
print(f"  Matches: {matches}")

print()

# ==============================================================================
# SECTION 3: MULTILINE MODE
# ==============================================================================

"""
MULTILINE MODE changes how ^ and $ behave:
- Without re.MULTILINE: ^ matches start of string, $ matches end of string
- With re.MULTILINE: ^ matches start of each line, $ matches end of each line
"""

print("="*70)
print("SECTION 3: MULTILINE MODE")
print("="*70)

# Example 7: Single-line vs multi-line mode
# -----------------------------------------
text7 = """first line
second line
third line"""

# Without multiline mode - ^ only matches start of entire string
pattern7 = r"^\w+"
matches_no_multiline = re.findall(pattern7, text7)
print("Without MULTILINE flag:")
print(f"  Pattern: '^\\w+' (word at start)")
print(f"  Matches: {matches_no_multiline}")
print(f"  (Only matches first line)")

# With multiline mode - ^ matches start of each line
matches_multiline = re.findall(pattern7, text7, re.MULTILINE)
print("With MULTILINE flag:")
print(f"  Pattern: '^\\w+' (word at start of each line)")
print(f"  Matches: {matches_multiline}")
print(f"  (Matches beginning of every line)")

print()

# Example 8: End-of-line matching in multiline mode
# -------------------------------------------------
text8 = """hello world
goodbye world
test world"""

# Match "world" at the end of lines
pattern8 = r"world$"
matches = re.findall(pattern8, text8, re.MULTILINE)
print(f"Pattern: 'world$' (with MULTILINE)")
print(f"Text has {len(matches)} lines ending with 'world'")

print()

# ==============================================================================
# SECTION 4: \A and \Z ANCHORS
# ==============================================================================

"""
\A and \Z are like ^ and $, but they ALWAYS match string boundaries,
regardless of MULTILINE mode.

\A : Start of string (always)
\Z : End of string (always)
"""

print("="*70)
print("SECTION 4: ABSOLUTE ANCHORS (\\A and \\Z)")
print("="*70)

# Example 9: Difference between ^ and \A
# ---------------------------------------
text9 = """first line
second line"""

# ^ with MULTILINE matches each line start
pattern_caret = r"^\w+"
matches_caret = re.findall(pattern_caret, text9, re.MULTILINE)
print("With MULTILINE mode:")
print(f"  '^\\w+': {matches_caret}")

# \A always matches only the string start
pattern_A = r"\A\w+"
matches_A = re.findall(pattern_A, text9, re.MULTILINE)
print(f"  '\\A\\w+': {matches_A}")
print(f"  (\\A ignores MULTILINE, only matches string start)")

print()

# ==============================================================================
# SECTION 5: PRACTICAL VALIDATION PATTERNS
# ==============================================================================

print("="*70)
print("SECTION 5: PRACTICAL VALIDATION PATTERNS")
print("="*70)

# Example 10: Validating email format (simplified)
# ------------------------------------------------
def validate_email_simple(email):
    # Pattern: start, word chars with dots, @, domain, dot, extension, end
    pattern = r"^[\w.]+@[\w]+\.[a-z]{2,}$"
    return bool(re.match(pattern, email, re.IGNORECASE))

emails = [
    "user@example.com",
    "john.doe@test.org",
    "invalid@",
    "@invalid.com",
    "no-domain@.com",
    "spaces are@bad.com"
]

print("Email validation:")
for email in emails:
    valid = validate_email_simple(email)
    status = "✓" if valid else "✗"
    print(f"  {status} {email}")

print()

# Example 11: Validating username
# -------------------------------
def validate_username(username):
    """
    Valid username:
    - 3-16 characters long
    - Starts with a letter
    - Contains only letters, numbers, underscore
    """
    pattern = r"^[a-zA-Z][\w]{2,15}$"
    return bool(re.match(pattern, username))

usernames = [
    "john_doe",
    "user123",
    "_invalid",  # Starts with underscore
    "ab",  # Too short
    "1user",  # Starts with number
    "valid_user_name"
]

print("Username validation:")
for username in usernames:
    valid = validate_username(username)
    status = "✓" if valid else "✗"
    print(f"  {status} {username}")

print()

# Example 12: Extracting complete lines
# -------------------------------------
text12 = """TODO: finish documentation
NOTE: review this section
FIXME: fix this bug
Remember to test"""

# Extract lines starting with keywords
pattern12 = r"^(TODO|NOTE|FIXME):.*$"
important_lines = re.findall(pattern12, text12, re.MULTILINE)
print("Lines starting with TODO/NOTE/FIXME:")
for line in important_lines:
    print(f"  - {line}")

print()

# ==============================================================================
# SECTION 6: COMBINING ANCHORS WITH OTHER PATTERNS
# ==============================================================================

print("="*70)
print("SECTION 6: ADVANCED ANCHOR COMBINATIONS")
print("="*70)

# Example 13: Match entire lines matching pattern
# -----------------------------------------------
text13 = """import os
import re
from sys import argv
import json
print('hello')"""

# Match lines that are import statements
pattern13 = r"^import\s+\w+$"
imports = re.findall(pattern13, text13, re.MULTILINE)
print("Simple import statements:")
for imp in imports:
    print(f"  {imp}")

print()

# Example 14: Validating IP addresses
# -----------------------------------
def validate_ip(ip):
    """
    Validate IPv4 address format (simplified).
    Each octet should be 0-255.
    """
    # Pattern: start, 4 groups of 1-3 digits separated by dots, end
    pattern = r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"
    if not re.match(pattern, ip):
        return False
    
    # Additional check: each octet should be 0-255
    octets = ip.split('.')
    return all(0 <= int(octet) <= 255 for octet in octets)

ip_addresses = [
    "192.168.1.1",
    "255.255.255.255",
    "256.1.1.1",  # Invalid: 256 > 255
    "192.168.1",  # Invalid: only 3 octets
    "192.168.1.1.1"  # Invalid: 5 octets
]

print("IP address validation:")
for ip in ip_addresses:
    valid = validate_ip(ip)
    status = "✓" if valid else "✗"
    print(f"  {status} {ip}")

print()

# ==============================================================================
# SECTION 7: COMMON PITFALLS
# ==============================================================================

print("="*70)
print("SECTION 7: COMMON PITFALLS AND SOLUTIONS")
print("="*70)

# Pitfall 1: Forgetting that ^ and $ positions change with MULTILINE
# ------------------------------------------------------------------
print("Pitfall 1: Multiline mode behavior\n")

text_pitfall = """header
content
footer"""

# Intention: match "content" only if it's the entire string
# Problem: with MULTILINE, this matches the line "content"
pattern_wrong = r"^content$"
match_wrong = re.search(pattern_wrong, text_pitfall, re.MULTILINE)
print(f"Pattern '^content$' with MULTILINE: {bool(match_wrong)}")
print("  (Matches because 'content' is a complete line)")

# Solution: use \A and \Z for absolute string boundaries
pattern_correct = r"\Acontent\Z"
match_correct = re.search(pattern_correct, text_pitfall)
print(f"Pattern '\\Acontent\\Z': {bool(match_correct)}")
print("  (Doesn't match because string has more than just 'content')")

print()

# Pitfall 2: Word boundaries don't work with non-word characters
# --------------------------------------------------------------
print("Pitfall 2: Word boundaries and special characters\n")

text_pitfall2 = "email@domain.com"

# This won't work as expected because @ is not a word character
pattern_pitfall2 = r"\b@\b"
match_pitfall2 = re.search(pattern_pitfall2, text_pitfall2)
print(f"Text: '{text_pitfall2}'")
print(f"Pattern '\\b@\\b': {bool(match_pitfall2)}")
print("  (@ is not a word character, so \\b doesn't help here)")

print()

# ==============================================================================
# SECTION 8: SUMMARY
# ==============================================================================

print("="*70)
print("ANCHORS AND BOUNDARIES CHEAT SHEET")
print("="*70)

cheat_sheet = """
POSITION ANCHORS:
  ^           Start of string (or line with MULTILINE)
  $           End of string (or line with MULTILINE)
  \\A          Start of string (always, ignores MULTILINE)
  \\Z          End of string (always, ignores MULTILINE)

WORD BOUNDARIES:
  \\b          Word boundary (between \\w and \\W)
  \\B          Not a word boundary

COMMON PATTERNS:
  ^pattern$   Exact match (entire string)
  ^pattern    String starts with pattern
  pattern$    String ends with pattern
  \\bword\\b   Match complete word only
  ^.*$        Match entire line (with MULTILINE)

FLAGS:
  re.MULTILINE or re.M
    - Makes ^ match start of each line
    - Makes $ match end of each line

VALIDATION TEMPLATE:
  ^[valid_chars]{min,max}$
  - Use to validate entire input
  - Ensures nothing extra before or after

KEY POINTS:
  1. Anchors match POSITIONS, not characters
  2. ^ and $ behavior changes with MULTILINE flag
  3. \\A and \\Z always match string boundaries
  4. Use \\b for whole word matching
  5. Combine ^ and $ for exact string validation
"""

print(cheat_sheet)

# ==============================================================================
# PRACTICE EXERCISES
# ==============================================================================

print("="*70)
print("PRACTICE CHALLENGES")
print("="*70)

"""
Try these exercises:

1. Write a pattern to match lines that start with '#' (comments)
2. Validate URLs that start with 'http://' or 'https://'
3. Match email addresses at the end of lines
4. Find all complete words that are exactly 5 letters long
5. Extract lines that contain only digits
6. Match strings that start and end with the same letter
7. Validate phone numbers: must be exactly (XXX) XXX-XXXX format
8. Find all lines in a file that are blank or contain only whitespace
9. Match variable names that start with underscore
10. Validate that a string is a valid Python identifier

Solutions in exercises_02_intermediate.py
"""

# ==============================================================================
# END OF TUTORIAL 04
# ==============================================================================

print("\n" + "="*70)
print("END OF TUTORIAL - Anchors and Boundaries mastered!")
print("Next: Tutorial 05 - Groups and Capturing")
print("="*70)
