# Python Regular Expressions - Comprehensive Course

## Course Overview

This comprehensive course package teaches Regular Expressions (regex) in Python from fundamental concepts to advanced applications. Designed for undergraduate computer science students, it provides progressive learning with heavily commented code examples and practical exercises.

## Package Contents

### Tutorial Files (Progressive Difficulty)

1. **01_regex_basics.py** - BEGINNER
   - Introduction to regular expressions
   - Basic pattern matching with `re.match()`, `re.search()`, `re.findall()`
   - Simple literal patterns
   - Understanding match objects

2. **02_character_classes.py** - BEGINNER
   - Character classes `[abc]`, `[^abc]`
   - Predefined character classes `\d`, `\w`, `\s`
   - Character ranges `[a-z]`, `[0-9]`
   - Negated classes

3. **03_quantifiers.py** - INTERMEDIATE
   - Repetition quantifiers `*`, `+`, `?`, `{m,n}`
   - Greedy vs. non-greedy matching
   - Optional patterns
   - Exact repetition counts

4. **04_anchors_boundaries.py** - INTERMEDIATE
   - Start and end anchors `^`, `$`
   - Word boundaries `\b`, `\B`
   - Multiline matching
   - String boundaries

5. **05_groups_capturing.py** - INTERMEDIATE
   - Capturing groups `(pattern)`
   - Non-capturing groups `(?:pattern)`
   - Named groups `(?P<name>pattern)`
   - Backreferences
   - Group extraction

6. **06_lookahead_lookbehind.py** - ADVANCED
   - Positive lookahead `(?=pattern)`
   - Negative lookahead `(?!pattern)`
   - Positive lookbehind `(?<=pattern)`
   - Negative lookbehind `(?<!pattern)`
   - Complex assertions

7. **07_practical_applications.py** - ADVANCED
   - Email validation
   - URL parsing
   - Phone number formatting
   - Data extraction from text
   - Text processing pipelines
   - Performance considerations

### Exercise Files

- **exercises_01_basics.py** - Basic pattern matching exercises
- **exercises_02_intermediate.py** - Intermediate regex challenges
- **exercises_03_advanced.py** - Advanced real-world problems

### Solution Files

- **solutions_01_basics.py** - Solutions with detailed explanations
- **solutions_02_intermediate.py** - Solutions with detailed explanations
- **solutions_03_advanced.py** - Solutions with detailed explanations

## Learning Path

### Week 1-2: Foundations
- Study `01_regex_basics.py`
- Study `02_character_classes.py`
- Complete `exercises_01_basics.py`

### Week 3-4: Intermediate Concepts
- Study `03_quantifiers.py`
- Study `04_anchors_boundaries.py`
- Study `05_groups_capturing.py`
- Complete `exercises_02_intermediate.py`

### Week 5-6: Advanced Techniques
- Study `06_lookahead_lookbehind.py`
- Study `07_practical_applications.py`
- Complete `exercises_03_advanced.py`

## Python `re` Module Reference

### Main Functions

- `re.match(pattern, string)` - Match at the beginning of string
- `re.search(pattern, string)` - Search anywhere in string
- `re.findall(pattern, string)` - Find all non-overlapping matches
- `re.finditer(pattern, string)` - Iterator of match objects
- `re.sub(pattern, repl, string)` - Replace matches
- `re.split(pattern, string)` - Split string by pattern
- `re.compile(pattern)` - Compile pattern for reuse

### Flags

- `re.IGNORECASE` or `re.I` - Case-insensitive matching
- `re.MULTILINE` or `re.M` - `^` and `$` match line boundaries
- `re.DOTALL` or `re.S` - `.` matches newlines too
- `re.VERBOSE` or `re.X` - Allow comments in regex
- `re.ASCII` or `re.A` - ASCII-only matching for `\w`, `\d`, etc.

## Regular Expression Syntax Quick Reference

### Literals
- `abc` - Matches the exact string "abc"

### Character Classes
- `.` - Any character (except newline)
- `[abc]` - Any of a, b, or c
- `[^abc]` - Not a, b, or c
- `[a-z]` - Any lowercase letter
- `[0-9]` - Any digit
- `\d` - Any digit `[0-9]`
- `\D` - Not a digit `[^0-9]`
- `\w` - Word character `[a-zA-Z0-9_]`
- `\W` - Not a word character
- `\s` - Whitespace `[ \t\n\r\f\v]`
- `\S` - Not whitespace

### Quantifiers
- `*` - 0 or more
- `+` - 1 or more
- `?` - 0 or 1
- `{m}` - Exactly m occurrences
- `{m,n}` - Between m and n occurrences
- `{m,}` - m or more occurrences
- `*?`, `+?`, `??` - Non-greedy versions

### Anchors
- `^` - Start of string (or line in multiline mode)
- `$` - End of string (or line in multiline mode)
- `\b` - Word boundary
- `\B` - Not a word boundary
- `\A` - Start of string
- `\Z` - End of string

### Groups
- `(abc)` - Capturing group
- `(?:abc)` - Non-capturing group
- `(?P<name>abc)` - Named capturing group
- `\1`, `\2` - Backreference to group 1, 2
- `(?P=name)` - Backreference to named group

### Lookarounds
- `(?=abc)` - Positive lookahead
- `(?!abc)` - Negative lookahead
- `(?<=abc)` - Positive lookbehind
- `(?<!abc)` - Negative lookbehind

### Special
- `|` - OR operator
- `\` - Escape special character
- `()` - Grouping

## Common Patterns Library

```python
# Email (basic)
r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

# URL (basic)
r'https?://(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&/=]*)'

# Phone (US)
r'\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}'

# IP Address (IPv4)
r'\b(?:\d{1,3}\.){3}\d{1,3}\b'

# Date (YYYY-MM-DD)
r'\d{4}-\d{2}-\d{2}'

# Time (HH:MM)
r'([01]?[0-9]|2[0-3]):[0-5][0-9]'

# Hex Color
r'#[0-9A-Fa-f]{6}'

# Credit Card (basic format check)
r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'
```

## Best Practices

1. **Use Raw Strings**: Always use `r''` for regex patterns to avoid backslash escaping issues
2. **Compile for Reuse**: If using a pattern multiple times, compile it with `re.compile()`
3. **Be Specific**: More specific patterns are faster and more accurate
4. **Test Thoroughly**: Use online regex testers (regex101.com) during development
5. **Comment Complex Patterns**: Use `re.VERBOSE` flag for complex patterns
6. **Consider Alternatives**: Sometimes string methods are simpler than regex
7. **Watch for Catastrophic Backtracking**: Be careful with nested quantifiers

## Performance Tips

1. Compile patterns that are used multiple times
2. Use non-capturing groups `(?:)` when you don't need the captured text
3. Be specific with character classes instead of using `.`
4. Anchor patterns when possible (`^`, `$`)
5. Use `re.search()` instead of `re.match()` + loop
6. Consider using `re.finditer()` for large texts instead of `re.findall()`

## Common Pitfalls

1. **Forgetting to escape special characters**: Use `\` or `re.escape()`
2. **Using `.` without realizing it doesn't match newlines**: Use `re.DOTALL` if needed
3. **Greedy quantifiers**: Remember `*` and `+` are greedy; use `*?` and `+?` for non-greedy
4. **Backslash escaping**: Always use raw strings `r''`
5. **Not testing edge cases**: Empty strings, very long strings, special characters

## Additional Resources

- Python `re` documentation: https://docs.python.org/3/library/re.html
- Regex101 (online tester): https://regex101.com/
- Regular-Expressions.info: https://www.regular-expressions.info/
- Regex Crossword (practice): https://regexcrossword.com/

## Teaching Notes

- Start with simple literal matches before introducing special characters
- Use real-world examples to motivate regex usage
- Emphasize the importance of testing patterns thoroughly
- Discuss when NOT to use regex (when simple string methods suffice)
- Encourage students to use visualization tools
- Practice reading regex patterns aloud to build understanding

## Assessment Suggestions

- Pattern writing exercises (given description, write regex)
- Pattern reading exercises (given regex, describe what it matches)
- Debugging exercises (fix broken patterns)
- Optimization exercises (make patterns more efficient)
- Real-world application projects (log parsing, data validation, etc.)

---

**Author**: Python Regex Course
**Target Audience**: Undergraduate Computer Science Students
**Prerequisites**: Basic Python knowledge (strings, functions, loops)
**Estimated Time**: 6 weeks (2 hours/week)
