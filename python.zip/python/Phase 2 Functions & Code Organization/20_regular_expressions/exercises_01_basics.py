"""
Regular Expressions - Basic Exercises
=====================================

Complete these exercises to practice regex basics and character classes.
"""

import re

print("BASIC REGEX EXERCISES")
print("="*70)

# Exercise 1: Find all vowels in a string
# TODO: Write pattern to match all vowels (a,e,i,o,u) case-insensitive
text1 = "Hello World"
pattern1 = r"[TODO]"  # Your pattern here
# Expected: ['e', 'o', 'o']

# Exercise 2: Extract all numbers from text
# TODO: Write pattern to find all digit sequences
text2 = "I have 3 cats and 12 dogs"
pattern2 = r"TODO"  # Your pattern here
# Expected: ['3', '12']

# Exercise 3: Find all words starting with capital letter
# TODO: Write pattern to match words that start with uppercase
text3 = "Python is Great and Easy to learn"
pattern3 = r"TODO"  # Your pattern here
# Expected: ['Python', 'Great', 'Easy']

# Exercise 4: Match email pattern
# TODO: Write simple email pattern (word chars @ word chars . word chars)
emails = ["test@example.com", "invalid@", "user.name@domain.co"]
pattern4 = r"TODO"  # Your pattern here
# Should match: test@example.com, user.name@domain.co

# Exercise 5: Find all hex color codes
# TODO: Write pattern for #ABC or #ABCDEF format
text5 = "Colors: #FFF, #123ABC, #GG, #123"
pattern5 = r"TODO"  # Your pattern here
# Expected: ['#FFF', '#123ABC']

# Exercise 6: Match phone numbers
# TODO: Write pattern for XXX-XXX-XXXX
text6 = "Call 555-123-4567 or 800-555-0199"
pattern6 = r"TODO"  # Your pattern here
# Expected: ['555-123-4567', '800-555-0199']

# Exercise 7: Extract words between quotes
# TODO: Write pattern to find text between double quotes
text7 = 'He said "Hello" and "Goodbye"'
pattern7 = r"TODO"  # Your pattern here
# Expected: ['Hello', 'Goodbye']

# Exercise 8: Find all hashtags
# TODO: Write pattern for #word format
text8 = "Love #python #coding and #AI"
pattern8 = r"TODO"  # Your pattern here
# Expected: ['#python', '#coding', '#AI']

# Exercise 9: Match dates in YYYY-MM-DD format
# TODO: Write pattern for date format
text9 = "Events: 2024-03-15, 2024-12-31"
pattern9 = r"TODO"  # Your pattern here
# Expected: ['2024-03-15', '2024-12-31']

# Exercise 10: Find all file extensions
# TODO: Write pattern to extract .ext from filenames
text10 = "Files: doc.txt, image.png, script.py"
pattern10 = r"TODO"  # Your pattern here
# Expected: ['.txt', '.png', '.py']

print("\nComplete these exercises then check solutions_01_basics.py")
