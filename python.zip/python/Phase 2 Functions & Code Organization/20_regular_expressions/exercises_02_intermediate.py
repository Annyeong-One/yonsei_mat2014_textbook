"""
Regular Expressions - Intermediate Exercises
============================================

Practice quantifiers, anchors, and groups.
"""

import re

print("INTERMEDIATE REGEX EXERCISES")
print("="*70)

# Exercise 1: Validate username (3-16 chars, starts with letter)
# TODO: Write validation pattern
def validate_username(username):
    pattern = r"TODO"
    return bool(re.match(pattern, username))

# Exercise 2: Extract all URLs from text
# TODO: Pattern for http(s)://domain.com/path
text2 = "Visit https://example.com or http://test.org/page"
pattern2 = r"TODO"

# Exercise 3: Match repeated words
# TODO: Use backreferences to find duplicate words
text3 = "the the cat sat on the mat mat"
pattern3 = r"TODO"

# Exercise 4: Format phone numbers
# TODO: Change XXX-XXX-XXXX to (XXX) XXX-XXXX
text4 = "Call 555-123-4567"
pattern4 = r"TODO"
replacement4 = r"TODO"

# Exercise 5: Extract email parts
# TODO: Capture username, domain, and TLD separately
email5 = "john.doe@example.com"
pattern5 = r"TODO"

# Exercise 6: Match lines starting with TODO or FIXME
# TODO: Pattern with multiline mode
text6 = """TODO: finish this
NOTE: review
FIXME: bug here"""
pattern6 = r"TODO"

# Exercise 7: Validate strong password
# TODO: Min 8 chars, has digit, letter, special char
def validate_password(pwd):
    pattern = r"TODO"
    return bool(re.match(pattern, pwd))

# Exercise 8: Extract hashtags (minimum 3 chars)
# TODO: Pattern for #word with at least 3 letters
text8 = "#hi #python #AI #test"
pattern8 = r"TODO"

# Exercise 9: Parse CSV line
# TODO: Split on comma, handle quotes
csv_line = 'John,Doe,"123 Main St",30'
pattern9 = r"TODO"

# Exercise 10: Match words with 5-8 letters
# TODO: Use word boundaries and quantifiers
text10 = "short words and longerwords mixedtogether"
pattern10 = r"TODO"

print("\nComplete these exercises then check solutions_02_intermediate.py")
