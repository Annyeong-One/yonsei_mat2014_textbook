"""
Regular Expressions - Advanced Exercises
========================================

Practice lookarounds and complex patterns.
"""

import re

print("ADVANCED REGEX EXERCISES")
print("="*70)

# Exercise 1: Password with all requirements
# TODO: 8+ chars, uppercase, lowercase, digit, special char
def validate_strong_password(pwd):
    pattern = r"TODO"  # Use multiple lookaheads
    return bool(re.match(pattern, pwd))

# Exercise 2: Extract @mentions but not emails
# TODO: Match @username but not in email addresses
text2 = "Hi @john! Contact: user@example.com, @alice"
pattern2 = r"TODO"

# Exercise 3: Match numbers not in equations
# TODO: Find standalone numbers
text3 = "Age: 25, Score: 3+7=10, Price: 30"
pattern3 = r"TODO"

# Exercise 4: Validate credit card with spaces/dashes
# TODO: Match XXXX-XXXX-XXXX-XXXX or XXXX XXXX XXXX XXXX
cards = ["1234-5678-9012-3456", "1234 5678 9012 3456"]
pattern4 = r"TODO"

# Exercise 5: Extract prices in specific currency
# TODO: Match $XX.XX but not €XX.XX
text5 = "$10.99 €20.50 $5.00 £30.00"
pattern5 = r"TODO"

# Exercise 6: Match HTML tags with specific attributes
# TODO: Match <div class="..."> but not other tags
html6 = '<div class="container">Text</div><span>Other</span>'
pattern6 = r"TODO"

# Exercise 7: Find words between specific markers
# TODO: Match words between START and END
text7 = "START apple banana END ignore START cherry END"
pattern7 = r"TODO"

# Exercise 8: Validate IPv4 with proper ranges
# TODO: Each octet must be 0-255
def validate_ip(ip):
    pattern = r"TODO"
    # Additional logic for 0-255 range
    pass

# Exercise 9: Remove HTML tags but keep content
# TODO: Pattern to replace tags
html9 = "<p>Hello <b>World</b></p>"
pattern9 = r"TODO"

# Exercise 10: Extract function calls from code
# TODO: Match function_name(args)
code = "result = calculate(10, 20) + process(data)"
pattern10 = r"TODO"

print("\nComplete these exercises then check solutions_03_advanced.py")
