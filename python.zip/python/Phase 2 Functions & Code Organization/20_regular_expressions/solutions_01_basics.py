"""
Regular Expressions - Basic Exercise Solutions
==============================================
"""

import re

print("BASIC REGEX EXERCISE SOLUTIONS")
print("="*70)

# Solution 1: Find all vowels
print("\n1. Find all vowels:")
text1 = "Hello World"
pattern1 = r"[aeiouAEIOU]"
result1 = re.findall(pattern1, text1)
print(f"   Text: '{text1}'")
print(f"   Pattern: {pattern1}")
print(f"   Result: {result1}")

# Solution 2: Extract all numbers
print("\n2. Extract all numbers:")
text2 = "I have 3 cats and 12 dogs"
pattern2 = r"\d+"
result2 = re.findall(pattern2, text2)
print(f"   Text: '{text2}'")
print(f"   Pattern: {pattern2}")
print(f"   Result: {result2}")

# Solution 3: Words starting with capital
print("\n3. Words starting with capital letter:")
text3 = "Python is Great and Easy to learn"
pattern3 = r"\b[A-Z]\w*"
result3 = re.findall(pattern3, text3)
print(f"   Text: '{text3}'")
print(f"   Pattern: {pattern3}")
print(f"   Result: {result3}")

# Solution 4: Email pattern
print("\n4. Match email pattern:")
emails = ["test@example.com", "invalid@", "user.name@domain.co"]
pattern4 = r"[\w.]+@[\w.]+\.[a-zA-Z]+"
print(f"   Pattern: {pattern4}")
for email in emails:
    match = bool(re.match(pattern4, email))
    print(f"   {'✓' if match else '✗'} {email}")

# Solution 5: Hex color codes
print("\n5. Find hex color codes:")
text5 = "Colors: #FFF, #123ABC, #GG, #123"
pattern5 = r"#[0-9A-Fa-f]{3}(?:[0-9A-Fa-f]{3})?"
result5 = re.findall(pattern5, text5)
print(f"   Text: '{text5}'")
print(f"   Pattern: {pattern5}")
print(f"   Result: {result5}")

# Solution 6: Phone numbers
print("\n6. Match phone numbers:")
text6 = "Call 555-123-4567 or 800-555-0199"
pattern6 = r"\d{3}-\d{3}-\d{4}"
result6 = re.findall(pattern6, text6)
print(f"   Text: '{text6}'")
print(f"   Pattern: {pattern6}")
print(f"   Result: {result6}")

# Solution 7: Text between quotes
print("\n7. Extract text between quotes:")
text7 = 'He said "Hello" and "Goodbye"'
pattern7 = r'"([^"]*)"'
result7 = re.findall(pattern7, text7)
print(f"   Text: {text7}")
print(f"   Pattern: {pattern7}")
print(f"   Result: {result7}")

# Solution 8: Hashtags
print("\n8. Find hashtags:")
text8 = "Love #python #coding and #AI"
pattern8 = r"#\w+"
result8 = re.findall(pattern8, text8)
print(f"   Text: '{text8}'")
print(f"   Pattern: {pattern8}")
print(f"   Result: {result8}")

# Solution 9: Dates in YYYY-MM-DD format
print("\n9. Match dates:")
text9 = "Events: 2024-03-15, 2024-12-31"
pattern9 = r"\d{4}-\d{2}-\d{2}"
result9 = re.findall(pattern9, text9)
print(f"   Text: '{text9}'")
print(f"   Pattern: {pattern9}")
print(f"   Result: {result9}")

# Solution 10: File extensions
print("\n10. Find file extensions:")
text10 = "Files: doc.txt, image.png, script.py"
pattern10 = r"\.\w+"
result10 = re.findall(pattern10, text10)
print(f"   Text: '{text10}'")
print(f"   Pattern: {pattern10}")
print(f"   Result: {result10}")

print("\n" + "="*70)
print("All basic exercises completed!")
