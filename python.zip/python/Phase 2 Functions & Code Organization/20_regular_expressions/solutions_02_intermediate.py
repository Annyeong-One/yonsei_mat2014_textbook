"""
Regular Expressions - Intermediate Exercise Solutions
=====================================================
"""

import re

print("INTERMEDIATE REGEX EXERCISE SOLUTIONS")
print("="*70)

# Solution 1: Validate username
print("\n1. Validate username:")
def validate_username(username):
    pattern = r"^[a-zA-Z]\w{2,15}$"
    return bool(re.match(pattern, username))

usernames = ["john_doe", "_invalid", "ab", "user123"]
for username in usernames:
    valid = validate_username(username)
    print(f"   {'✓' if valid else '✗'} {username}")

# Solution 2: Extract URLs
print("\n2. Extract URLs:")
text2 = "Visit https://example.com or http://test.org/page"
pattern2 = r"https?://[\w.-]+(?:/[\w./-]*)?"
result2 = re.findall(pattern2, text2)
print(f"   URLs: {result2}")

# Solution 3: Repeated words
print("\n3. Match repeated words:")
text3 = "the the cat sat on the mat mat"
pattern3 = r"\b(\w+)\s+\1\b"
result3 = re.findall(pattern3, text3)
print(f"   Repeated: {result3}")

# Solution 4: Format phone numbers
print("\n4. Format phone numbers:")
text4 = "Call 555-123-4567"
pattern4 = r"(\d{3})-(\d{3})-(\d{4})"
replacement4 = r"(\1) \2-\3"
result4 = re.sub(pattern4, replacement4, text4)
print(f"   Before: {text4}")
print(f"   After: {result4}")

# Solution 5: Extract email parts
print("\n5. Extract email parts:")
email5 = "john.doe@example.com"
pattern5 = r"([\w.+-]+)@([\w.-]+)\.([a-zA-Z]+)"
match5 = re.match(pattern5, email5)
if match5:
    print(f"   User: {match5.group(1)}")
    print(f"   Domain: {match5.group(2)}")
    print(f"   TLD: {match5.group(3)}")

# Solution 6: Lines with TODO/FIXME
print("\n6. Match TODO/FIXME lines:")
text6 = """TODO: finish this
NOTE: review
FIXME: bug here"""
pattern6 = r"^(TODO|FIXME):.*$"
result6 = re.findall(pattern6, text6, re.MULTILINE)
print(f"   Found: {result6}")

# Solution 7: Strong password validation
print("\n7. Validate strong password:")
def validate_password(pwd):
    if len(pwd) < 8:
        return False
    pattern = r"^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])"
    return bool(re.search(pattern, pwd))

passwords = ["weak", "Strong123!", "pass123"]
for pwd in passwords:
    valid = validate_password(pwd)
    print(f"   {'✓' if valid else '✗'} {pwd}")

# Solution 8: Hashtags (min 3 chars)
print("\n8. Extract hashtags (3+ chars):")
text8 = "#hi #python #AI #test"
pattern8 = r"#\w{3,}"
result8 = re.findall(pattern8, text8)
print(f"   Result: {result8}")

# Solution 9: Parse CSV
print("\n9. Parse CSV line:")
csv_line = 'John,Doe,"123 Main St",30'
pattern9 = r'(?:"([^"]*)"|([^,]+))'
result9 = re.findall(pattern9, csv_line)
parsed = [m[0] or m[1] for m in result9]
print(f"   Parsed: {parsed}")

# Solution 10: Words with 5-8 letters
print("\n10. Match words with 5-8 letters:")
text10 = "short words and longerwords mixedtogether"
pattern10 = r"\b\w{5,8}\b"
result10 = re.findall(pattern10, text10)
print(f"   Result: {result10}")

print("\n" + "="*70)
print("All intermediate exercises completed!")
