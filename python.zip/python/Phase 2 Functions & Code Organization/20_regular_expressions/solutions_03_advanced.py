"""
Regular Expressions - Advanced Exercise Solutions
=================================================
"""

import re

print("ADVANCED REGEX EXERCISE SOLUTIONS")
print("="*70)

# Solution 1: Strong password with all requirements
print("\n1. Strong password validation:")
def validate_strong_password(pwd):
    if len(pwd) < 8:
        return False
    pattern = r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
    return bool(re.match(pattern, pwd))

passwords = ["Weak1!", "Strong1@Pass", "nodigit@Pass"]
for pwd in passwords:
    valid = validate_strong_password(pwd)
    print(f"   {'✓' if valid else '✗'} {pwd}")

# Solution 2: @mentions but not emails
print("\n2. Extract @mentions (not emails):")
text2 = "Hi @john! Contact: user@example.com, @alice"
pattern2 = r"(?<!\w)@\w+(?![\w.])"
result2 = re.findall(pattern2, text2)
print(f"   Mentions: {result2}")

# Solution 3: Numbers not in equations
print("\n3. Match standalone numbers:")
text3 = "Age: 25, Score: 3+7=10, Price: 30"
pattern3 = r"(?<![+=])\b\d+\b(?![+=])"
result3 = re.findall(pattern3, text3)
print(f"   Numbers: {result3}")

# Solution 4: Credit card validation
print("\n4. Validate credit cards:")
cards = ["1234-5678-9012-3456", "1234 5678 9012 3456", "invalid"]
pattern4 = r"^\d{4}[- ]\d{4}[- ]\d{4}[- ]\d{4}$"
for card in cards:
    valid = bool(re.match(pattern4, card))
    print(f"   {'✓' if valid else '✗'} {card}")

# Solution 5: Extract dollar prices
print("\n5. Extract dollar prices:")
text5 = "$10.99 €20.50 $5.00 £30.00"
pattern5 = r"(?<=\$)\d+\.\d{2}"
result5 = re.findall(pattern5, text5)
print(f"   Prices: {['$' + p for p in result5]}")

# Solution 6: Match div tags with class
print("\n6. Match <div class=...>:")
html6 = '<div class="container">Text</div><span>Other</span>'
pattern6 = r'<div\s+class="[^"]*">'
result6 = re.findall(pattern6, html6)
print(f"   Found: {result6}")

# Solution 7: Words between markers
print("\n7. Words between START and END:")
text7 = "START apple banana END ignore START cherry END"
pattern7 = r"(?<=START )\w+(?= (?:\w+ )*END)"
result7 = re.findall(pattern7, text7)
print(f"   Words: {result7}")

# Solution 8: Validate IPv4
print("\n8. Validate IPv4 addresses:")
def validate_ip(ip):
    pattern = r"^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$"
    match = re.match(pattern, ip)
    if not match:
        return False
    return all(0 <= int(octet) <= 255 for octet in match.groups())

ips = ["192.168.1.1", "256.1.1.1", "10.0.0.1"]
for ip in ips:
    valid = validate_ip(ip)
    print(f"   {'✓' if valid else '✗'} {ip}")

# Solution 9: Remove HTML tags
print("\n9. Remove HTML tags:")
html9 = "<p>Hello <b>World</b></p>"
pattern9 = r"<[^>]+>"
result9 = re.sub(pattern9, "", html9)
print(f"   Before: {html9}")
print(f"   After: {result9}")

# Solution 10: Extract function calls
print("\n10. Extract function calls:")
code = "result = calculate(10, 20) + process(data)"
pattern10 = r"\b\w+\([^)]*\)"
result10 = re.findall(pattern10, code)
print(f"   Functions: {result10}")

print("\n" + "="*70)
print("All advanced exercises completed!")
