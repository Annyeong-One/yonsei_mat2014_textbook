# Python Modules and Packages - Complete Educational Package

A comprehensive educational resource for teaching undergraduate students about Python modules and packages.

## 📚 Overview

This package provides a complete curriculum for teaching Python modules and packages, progressing from basic concepts to advanced topics. It includes:

- **Heavily commented code examples**
- **Progressive difficulty levels** (Beginner → Intermediate → Advanced)
- **Practical exercises with solutions**
- **Real-world examples and use cases**
- **Best practices and design patterns**

## 📂 Package Structure

```
python_modules_packages/
│
├── 01_beginner/                 # Beginner Level Materials
│   ├── math_operations.py       # Basic module creation
│   ├── constants.py             # Module-level variables and constants
│   ├── using_modules.py         # Different import methods
│   └── module_system.py         # How Python finds modules
│
├── 02_intermediate/             # Intermediate Level Materials
│   ├── mypackage/               # Complete package example
│   │   ├── __init__.py          # Package initialization
│   │   ├── math/                # Math subpackage
│   │   │   ├── __init__.py
│   │   │   ├── basic.py         # Basic operations
│   │   │   ├── advanced.py      # Advanced math functions
│   │   │   └── statistics.py    # Statistical functions
│   │   ├── string/              # String subpackage
│   │   │   ├── __init__.py
│   │   │   ├── operations.py    # String manipulation
│   │   │   └── analysis.py      # Text analysis
│   │   └── utils/               # Utilities subpackage
│   │       ├── __init__.py
│   │       ├── helpers.py       # Helper functions
│   │       └── decorators.py    # Function decorators
│   └── using_packages.py        # How to use packages
│
├── 03_advanced/                 # Advanced Level Materials
│   ├── imports_deep_dive.py     # Advanced import concepts
│   ├── namespace_packages.py    # Namespace packages (PEP 420)
│   └── setup_py_example.py      # Package distribution
│
├── exercises/                   # Practice Exercises
│   ├── exercise_01_basic_module.py
│   ├── exercise_02_package.py
│   ├── exercise_03_imports.py
│   └── solutions/               # Exercise solutions
│       ├── exercise_01_solution.py
│       ├── texttools/            # Package solution
│       └── test_texttools.py
│
└── README.md                    # This file
```

## 🎯 Learning Objectives

By working through this package, students will learn:

### Beginner Level
- What modules are and why we use them
- How to create and use simple modules
- Different import methods (`import`, `from...import`, aliases)
- Module-level variables and constants
- The `__name__` variable and `if __name__ == "__main__"`
- How Python finds and loads modules (sys.path)

### Intermediate Level
- Package structure and organization
- The role of `__init__.py`
- Creating and using subpackages
- Relative vs absolute imports
- The `__all__` variable
- Package-level imports and API design
- Function decorators

### Advanced Level
- Namespace packages (PEP 420)
- Dynamic imports with importlib
- Circular import problems and solutions
- Package distribution with setup.py
- Plugin architectures
- Import optimization

## 🚀 Getting Started

### For Students

1. **Start with Beginner Level**
   ```bash
   cd 01_beginner
   python math_operations.py
   python constants.py
   python using_modules.py
   ```

2. **Progress to Intermediate Level**
   ```bash
   cd 02_intermediate
   python using_packages.py
   ```

3. **Explore Advanced Topics**
   ```bash
   cd 03_advanced
   python imports_deep_dive.py
   python namespace_packages.py
   ```

4. **Practice with Exercises**
   ```bash
   cd exercises
   # Complete each exercise, then check solutions
   ```

### For Instructors

Each file is designed to be:
- **Self-contained**: Can be taught independently
- **Well-documented**: Extensive comments explain every concept
- **Demonstrable**: Includes runnable examples
- **Progressive**: Builds on previous concepts

Suggested teaching order:
1. Week 1-2: Beginner level (modules)
2. Week 3-4: Intermediate level (packages)
3. Week 5-6: Advanced level (distribution, plugins)
4. Week 7-8: Exercises and projects

## 📖 Detailed Content Guide

### Beginner Level (01_beginner/)

#### math_operations.py
- Creating your first module
- Writing functions with docstrings
- Module-level code execution
- The `__name__` variable
- Test code with `if __name__ == "__main__"`

**Key Concepts**: Module basics, function definitions, testing

#### constants.py
- Module-level constants (UPPERCASE naming)
- Configuration variables
- Helper functions using constants
- Module metadata

**Key Concepts**: Constants, module variables, namespaces

#### using_modules.py
- Five different import methods
- When to use each import style
- Import best practices
- Exploring module attributes with `dir()`
- Practical examples combining modules

**Key Concepts**: Import syntax, best practices, module inspection

#### module_system.py
- How Python finds modules (sys.path)
- Adding directories to the search path
- Module caching (sys.modules)
- Reloading modules with importlib
- Common import errors and solutions
- Built-in modules overview

**Key Concepts**: Import system, debugging imports, sys.path

### Intermediate Level (02_intermediate/)

#### mypackage/ - Complete Package Example
A fully functional package demonstrating:
- Package initialization with `__init__.py`
- Subpackage organization
- Relative imports within packages
- Package-level convenience imports
- Public API definition with `__all__`

**Subpackages**:
- **math**: Mathematical operations (basic, advanced, statistics)
- **string**: Text processing (operations, analysis)
- **utils**: Utilities (helpers, decorators)

#### using_packages.py
- Four methods of importing from packages
- Using subpackages
- Package-level vs module-level imports
- Practical examples combining package components
- Accessing package information

**Key Concepts**: Package usage, API design, practical patterns

### Advanced Level (03_advanced/)

#### imports_deep_dive.py
Comprehensive coverage of:
- Absolute vs relative imports (when to use each)
- Lazy imports for performance
- Dynamic imports with importlib
- Circular import problems and solutions
- The `__all__` variable in detail
- Import optimization techniques

**Key Concepts**: Advanced imports, performance, troubleshooting

#### namespace_packages.py
Modern package organization:
- What namespace packages are (PEP 420)
- Use cases (plugins, distributed packages)
- Creating namespace packages
- Comparison with regular packages
- Plugin system example
- Best practices

**Key Concepts**: Namespace packages, plugin architecture

#### setup_py_example.py
Package distribution:
- Creating setup.py
- Package metadata
- Dependency management
- Entry points and console scripts
- Building distributions
- Publishing to PyPI
- Version management

**Key Concepts**: Distribution, packaging, publishing

### Exercises (exercises/)

#### Exercise 1: Basic Module Creation
**Topics**: Module creation, functions, docstrings, testing
**Difficulty**: Beginner
**Includes**: Calculator module implementation

#### Exercise 2: Creating a Package
**Topics**: Package structure, `__init__.py`, imports, `__all__`
**Difficulty**: Intermediate
**Includes**: Complete texttools package with submodules

#### Exercise 3: Understanding Imports
**Topics**: Import methods, circular imports, dynamic imports
**Difficulty**: Intermediate
**Includes**: Practical challenges and theoretical questions

## 💡 Key Concepts Summary

### Modules
- A module is a Python file (.py) containing definitions and statements
- Modules help organize code and promote reusability
- Import modules with: `import module_name`

### Packages
- A package is a directory containing `__init__.py` and module files
- Packages organize related modules hierarchically
- Create subpackages for better organization

### Import Methods
```python
import math                          # Import entire module
from math import sqrt                # Import specific item
from math import sqrt, cos           # Import multiple items
import numpy as np                   # Import with alias
from mypackage.math import basic     # Import from package
from .sibling import function        # Relative import
```

### Best Practices
1. **Always use docstrings** for modules, functions, and classes
2. **Group imports** (standard library, third-party, local)
3. **Use relative imports** within packages
4. **Define `__all__`** to control public API
5. **Avoid `import *`** in production code
6. **Keep modules focused** on a single purpose
7. **Use meaningful names** for modules and packages

## 🎓 Teaching Tips

### For Instructors

1. **Start Simple**: Begin with single-file modules before packages
2. **Use Examples**: Every concept has a runnable example
3. **Encourage Experimentation**: Have students modify the examples
4. **Emphasize Organization**: Teach good project structure early
5. **Practice Debugging**: Work through common import errors
6. **Real Projects**: Have students organize their own projects

### Common Student Mistakes to Address
- Forgetting `__init__.py` in packages
- Confusing relative vs absolute imports
- Circular imports
- Running modules that use relative imports directly
- Not understanding `__name__` variable

## 🔧 Requirements

- **Python Version**: 3.7 or higher
- **No external dependencies** for basic examples
- **Optional**: setuptools, wheel (for distribution examples)

## 📝 Additional Resources

### Python Documentation
- [Modules Documentation](https://docs.python.org/3/tutorial/modules.html)
- [Packages Documentation](https://docs.python.org/3/tutorial/modules.html#packages)
- [Import System](https://docs.python.org/3/reference/import.html)
- [PEP 420 - Namespace Packages](https://www.python.org/dev/peps/pep-0420/)

### Best Practices
- [PEP 8 - Style Guide](https://www.python.org/dev/peps/pep-0008/)
- [Python Packaging User Guide](https://packaging.python.org/)

## 🤝 Contributing

This is an educational resource. Suggestions for improvements:
- Additional examples
- More exercises
- Corrections or clarifications
- Real-world use cases

## 📜 License

This educational package is provided for teaching purposes.
Feel free to use and adapt for your courses.

## ✨ Features

- ✅ Comprehensive coverage from basics to advanced
- ✅ Every example is fully functional and tested
- ✅ Extensive inline comments for self-study
- ✅ Progressive difficulty levels
- ✅ Practical exercises with detailed solutions
- ✅ Real-world examples and best practices
- ✅ No external dependencies required
- ✅ Ready for classroom use

## 📞 Support

For questions or issues:
1. Review the comments in each file
2. Check the exercise solutions
3. Refer to Python's official documentation
4. Experiment with the examples

---

**Happy Teaching and Learning! 🐍**

*This package was created specifically for undergraduate Python education with a focus on practical, hands-on learning.*
