"""
VIRTUAL ENVIRONMENTS & PACKAGE MANAGEMENT - LESSON 1
====================================================
Topic: Why Virtual Environments Are Needed
Level: Beginner
Prerequisites: Basic Python knowledge, command line familiarity

LEARNING OBJECTIVES:
- Understand the "dependency hell" problem
- Recognize why system-wide package installation is problematic
- Learn how virtual environments solve isolation issues
- Identify real-world scenarios where virtual environments are essential

This file provides conceptual understanding through examples and demonstrations.
Each section builds upon the previous to create a complete mental model.
"""

# ============================================================================
# SECTION 1: THE PROBLEM - SYSTEM-WIDE PACKAGE INSTALLATION
# ============================================================================

"""
THE SCENARIO: You have one Python installation on your computer

When you install a package using pip without a virtual environment:
    pip install requests

The package gets installed to your system Python's site-packages directory.
This seems convenient at first, but creates serious problems.
"""

# Problem demonstration (conceptual - not actual code to run)
"""
Example Scenario:
-----------------
You're working on two projects:

Project A: Web scraper built in 2023
    - Requires: requests==2.28.0
    - Requires: beautifulsoup4==4.11.0

Project B: API client built in 2025
    - Requires: requests==2.31.0  (different version!)
    - Requires: beautifulsoup4==4.12.0  (different version!)

PROBLEM: You can only have ONE version of requests installed at a time!
"""

# ----------------------------------------------------------------------------
# WHY THIS IS A PROBLEM:
# ----------------------------------------------------------------------------

# Problem 1: VERSION CONFLICTS
# When you install requests 2.31.0 for Project B, it overwrites 2.28.0
# Now Project A might break because it depends on specific features or bug fixes
# from version 2.28.0 that changed in 2.31.0

# Problem 2: DEPENDENCY CASCADES
# Package A might depend on Package B version 1.0
# Package C might depend on Package B version 2.0
# You can only have one version of Package B installed
# This creates an impossible situation called "dependency hell"

# Problem 3: SYSTEM POLLUTION
# Your system Python gets cluttered with packages from all projects
# This makes it hard to know what's actually needed
# Uninstalling becomes risky - you might break something else

# Problem 4: REPRODUCIBILITY
# Your colleague can't easily recreate your exact environment
# "It works on my machine" becomes a real problem
# Deployment to servers becomes unreliable


# ============================================================================
# SECTION 2: REAL-WORLD EXAMPLES OF THE PROBLEM
# ============================================================================

"""
Example 1: The Version Conflict
--------------------------------
"""
# Imagine you're maintaining a legacy Django application
# Legacy App: Django 2.2 (released 2019, still maintained for some companies)
#             Uses old-style middleware, old URL patterns
# New Project: Django 4.2 (latest version, modern features)
#             Different API, new async support, different structure

# If you install Django 4.2 for the new project:
#   pip install Django==4.2
# Your legacy app will break immediately!

# Django 4.2 removed features that Django 2.2 had
# The legacy code will raise ImportError or AttributeError
# You cannot work on both projects without virtual environments


"""
Example 2: The Testing Problem
-------------------------------
"""
# You're developing a Python library that should support multiple Python versions
# Python 3.8: Uses older typing syntax
# Python 3.11: Has new typing features, performance improvements
# Python 3.12: Latest features and optimizations

# Problem: You need to test your code on ALL these Python versions
# Solution requires: Multiple Python installations + Virtual environments
# Without this, you can only test on your system Python version


"""
Example 3: The Deployment Disaster
-----------------------------------
"""
# Development machine: 
#   - Has 200+ packages installed from various experiments
#   - Some are outdated, some are cutting-edge
#   - Some you installed months ago and forgot about

# Production server:
#   - Needs ONLY the packages your application uses
#   - Must be minimal for security and performance
#   - Needs exact versions for reproducibility

# Question: Which of those 200 packages does your app actually need?
# Without virtual environments, you don't know!
# This leads to bloated deployments and potential security issues


# ============================================================================
# SECTION 3: HOW VIRTUAL ENVIRONMENTS SOLVE THESE PROBLEMS
# ============================================================================

"""
A virtual environment is a self-contained directory that contains:
1. A Python interpreter (linked to your system Python)
2. A separate site-packages directory for installing packages
3. Scripts to activate/deactivate the environment

Think of it like this:
    - System Python = Your house's main kitchen
    - Virtual Environment = A portable kitchen you set up for each recipe
    - Each virtual kitchen has its own ingredients (packages)
    - They don't interfere with each other
    - You can have many virtual kitchens for different recipes
"""

# SOLUTION ILLUSTRATION:
# ----------------------
"""
With Virtual Environments:

my_computer/
├── system_python/              ← Your system Python (untouched)
│   └── site-packages/          ← System packages (minimal)
│
├── project_a/                  ← Project A directory
│   └── venv/                   ← Project A's virtual environment
│       └── site-packages/      ← requests 2.28.0, beautifulsoup4 4.11.0
│
└── project_b/                  ← Project B directory
    └── venv/                   ← Project B's virtual environment
        └── site-packages/      ← requests 2.31.0, beautifulsoup4 4.12.0

KEY INSIGHT: Each project has its own separate package directory!
             They don't interfere with each other or the system Python.
"""


# ============================================================================
# SECTION 4: BENEFITS OF VIRTUAL ENVIRONMENTS
# ============================================================================

"""
Benefit 1: ISOLATION
--------------------
Each project has its own set of packages.
Installing, updating, or removing a package in one project doesn't affect others.

Example:
    Project A uses NumPy 1.21.0
    Project B uses NumPy 1.24.0
    Both can coexist peacefully on the same computer.
"""

"""
Benefit 2: REPRODUCIBILITY
---------------------------
You can capture the exact package versions your project uses.
Anyone can recreate your environment exactly.

Example:
    Create requirements.txt: lists all packages and versions
    Share with team or deploy to server
    Others run: pip install -r requirements.txt
    Result: Everyone has identical environment
"""

"""
Benefit 3: CLEAN SYSTEM PYTHON
-------------------------------
Your system Python remains clean with only essential packages.
No risk of breaking system tools that depend on Python.

Example:
    System Python: Only basic tools (pip, setuptools)
    All project packages: In their respective virtual environments
    System remains stable and clean
"""

"""
Benefit 4: EASY EXPERIMENTATION
--------------------------------
Want to try a new package? Create a test environment!
If it doesn't work out, just delete the environment.
No mess left behind in your system Python.

Example:
    Create test_venv for experiments
    Install various packages
    Test and learn
    Delete entire test_venv directory
    System Python is unchanged
"""

"""
Benefit 5: MULTIPLE PYTHON VERSIONS
------------------------------------
Different projects might need different Python versions.
Virtual environments (with tools like pyenv or conda) can handle this.

Example:
    Legacy project: Python 3.8
    New project: Python 3.11
    Each has its own virtual environment with the appropriate Python version
"""


# ============================================================================
# SECTION 5: WHEN TO USE VIRTUAL ENVIRONMENTS
# ============================================================================

"""
SHORT ANSWER: Always! 

LONG ANSWER: Use a virtual environment for:
"""

# 1. NEW PROJECTS
#    Start every Python project with a fresh virtual environment
#    This prevents future headaches and establishes good habits

# 2. LEARNING NEW PACKAGES
#    Trying out a new library? Create a learning environment
#    Keep experiments separate from real projects

# 3. LEGACY CODE MAINTENANCE
#    Old code often depends on old package versions
#    Virtual environments let you maintain old code while working on new projects

# 4. PRODUCTION DEPLOYMENTS
#    Servers should have minimal, isolated environments
#    Only install what's needed, with exact versions

# 5. COLLABORATIVE WORK
#    Team members need identical environments
#    Virtual environments + requirements.txt solve this

# 6. CONTINUOUS INTEGRATION (CI)
#    Automated testing systems need reproducible environments
#    CI servers create fresh virtual environments for each test run


# ============================================================================
# SECTION 6: COMMON MISCONCEPTIONS AND CLARIFICATIONS
# ============================================================================

"""
Misconception 1: "Virtual environments waste disk space"
---------------------------------------------------------
Reality: Modern virtual environments are lightweight (10-50 MB each)
         They create symbolic links to the system Python rather than copying it
         The space savings from avoiding conflicts far outweigh the minimal space used

Typical virtual environment size:
    - Empty venv: ~10 MB (just pip and setuptools)
    - Small project: ~50 MB (with common packages)
    - Large project: 200-500 MB (with scientific computing packages)
    
This is tiny compared to modern storage capacities.
"""

"""
Misconception 2: "I can just be careful with versions"
-------------------------------------------------------
Reality: Package dependencies form complex graphs
         One package may depend on dozens of others
         Manually managing this is error-prone and time-consuming
         
Example dependency tree:
    Your app depends on: flask
    Flask depends on: werkzeug, jinja2, click
    Werkzeug depends on: markupsafe
    Jinja2 depends on: markupsafe
    
    If flask version X needs markupsafe version Y
    But you manually installed markupsafe version Z
    Your app might break in subtle, hard-to-debug ways
"""

"""
Misconception 3: "Virtual environments are only for big projects"
------------------------------------------------------------------
Reality: Even small scripts benefit from virtual environments
         
Benefits for small projects:
    - Clear documentation of dependencies
    - Easy sharing with others
    - Protection against system changes
    - Good habit formation
    
A 50-line script might only need 2-3 packages
But using a virtual environment documents this clearly
"""

"""
Misconception 4: "Activating environments is too much work"
------------------------------------------------------------
Reality: Activation is a single command
         Modern IDEs (VS Code, PyCharm) do this automatically
         The 2 seconds to activate saves hours of debugging
         
Typical workflow:
    1. Open terminal
    2. Navigate to project: cd my_project
    3. Activate environment: source venv/bin/activate  (1 second)
    4. Work normally
    
Many developers create aliases to make this even faster!
"""


# ============================================================================
# SECTION 7: VISUAL ANALOGY - THE APARTMENT BUILDING
# ============================================================================

"""
Think of your computer as an apartment building:

SYSTEM PYTHON = Building's Common Area (lobby, gym, pool)
    - Shared by all residents
    - Keep it minimal and well-maintained
    - Only put essential items here
    - Changing things here affects everyone

VIRTUAL ENVIRONMENT = Individual Apartment
    - Each project gets its own apartment (virtual environment)
    - Decorate (install packages) however you want
    - Changes don't affect other apartments
    - Can have different furniture (package versions) in each apartment
    - Easy to move out (delete) without affecting the building

PROJECT WITHOUT VENV = Storing all your stuff in the common area
    - Clutters the space
    - Your stuff mixes with others' stuff
    - Hard to know what belongs to whom
    - Conflicts arise when people want different things
    - Removing your stuff might damage others' belongings

BEST PRACTICE = Each resident (project) has their own apartment (venv)
    - Common area stays clean and functional
    - Each apartment is customized for its needs
    - No conflicts between residents
    - Easy to manage and maintain
"""


# ============================================================================
# SECTION 8: TECHNICAL EXPLANATION - HOW IT WORKS
# ============================================================================

"""
Under the hood, a virtual environment is a directory structure:

my_venv/
├── bin/                    (or Scripts/ on Windows)
│   ├── python              ← Symlink to system Python
│   ├── pip                 ← Environment's pip
│   └── activate            ← Activation script
├── lib/
│   └── python3.x/
│       └── site-packages/  ← Where packages are installed
└── pyvenv.cfg              ← Configuration file

When you activate a virtual environment:
1. The PATH environment variable is modified
2. Your shell now finds the venv's Python first
3. The venv's pip is used for package installation
4. Packages are installed to the venv's site-packages

When you run 'python' after activation:
1. Shell looks in PATH for 'python' command
2. Finds venv/bin/python first (because PATH was modified)
3. This Python knows to look in venv/lib/python3.x/site-packages
4. Your packages are found and imported correctly

This is why activation is important:
Without activation, your shell uses system Python and system packages
With activation, your shell uses venv Python and venv packages
"""


# ============================================================================
# SECTION 9: PREPARING FOR HANDS-ON WORK
# ============================================================================

"""
Now that you understand WHY virtual environments are essential,
the next files will teach you HOW to use them:

Next Topics:
-----------
1. Creating virtual environments (venv, virtualenv)
2. Activating and deactivating environments
3. Installing packages with pip
4. Managing requirements.txt files
5. Working with conda environments
6. Advanced tools (Poetry, pipenv)

Key Takeaways from This Lesson:
-------------------------------
✓ System-wide package installation causes version conflicts
✓ Virtual environments provide isolation for each project
✓ Virtual environments enable reproducibility
✓ Always use virtual environments, even for small projects
✓ Virtual environments are lightweight and easy to use
✓ Modern development workflows require virtual environments
"""


# ============================================================================
# SECTION 10: QUICK REFERENCE - PROBLEMS AND SOLUTIONS
# ============================================================================

"""
PROBLEM: I have 50 projects and packages are conflicting
SOLUTION: Create one virtual environment per project
         Each project's packages are isolated
         
PROBLEM: My colleague can't run my code - "Module not found"
SOLUTION: Share requirements.txt from your virtual environment
         They recreate your environment exactly
         
PROBLEM: My app works locally but fails on the server
SOLUTION: Server needs same package versions as your local environment
         Use virtual environment + requirements.txt for deployment
         
PROBLEM: I want to try a new package without messing things up
SOLUTION: Create a temporary virtual environment
         Experiment freely, delete when done
         
PROBLEM: I need to use both Django 2.2 and Django 4.2
SOLUTION: Two projects, two virtual environments
         Each has its appropriate Django version
         
PROBLEM: Installing packages requires sudo and I get permission errors
SOLUTION: Never use sudo with pip!
         Use virtual environments instead
         Virtual environments don't need admin privileges
"""


# ============================================================================
# SELF-CHECK QUESTIONS
# ============================================================================

"""
Test your understanding:

1. Why can't you have two versions of the same package installed system-wide?
   (Answer: Python's import system can only find one version)

2. What are three benefits of using virtual environments?
   (Answer: Isolation, reproducibility, clean system Python)

3. When should you use a virtual environment?
   (Answer: Always! For every project, no matter how small)

4. What gets installed in a virtual environment?
   (Answer: Packages specific to that project)

5. Does creating a virtual environment copy your entire Python installation?
   (Answer: No, it creates symbolic links to save space)

6. If you install a package in venv_A, is it available in venv_B?
   (Answer: No, virtual environments are isolated)

7. Why is sharing requirements.txt important for teams?
   (Answer: Ensures everyone has identical package versions)

8. What's the risk of installing packages to system Python?
   (Answer: Version conflicts, system pollution, reproducibility issues)
"""


# ============================================================================
# CONCLUSION
# ============================================================================

"""
Virtual environments are not optional in modern Python development.
They are fundamental to professional Python programming.

The small upfront investment in learning virtual environments pays off
immediately by preventing hours of debugging dependency issues.

In the next lesson, you'll learn hands-on how to:
- Create a virtual environment
- Activate and use it
- Install packages
- Deactivate when done

Let's get practical! Move on to: 02_basic_venv_usage.py
"""

# ============================================================================
# END OF FILE
# ============================================================================
