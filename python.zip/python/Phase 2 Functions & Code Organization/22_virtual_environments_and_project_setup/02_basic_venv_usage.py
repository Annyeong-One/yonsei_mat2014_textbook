"""
VIRTUAL ENVIRONMENTS & PACKAGE MANAGEMENT - LESSON 2
====================================================
Topic: Basic Virtual Environment Usage (venv)
Level: Beginner
Prerequisites: Lesson 1 (Why Virtual Environments)

LEARNING OBJECTIVES:
- Create virtual environments using the venv module
- Understand the directory structure of a virtual environment
- Activate and deactivate virtual environments
- Verify which Python and pip are being used
- Work with activated environments
- Understand platform differences (Windows vs Unix-like systems)

This file contains practical, executable examples.
Follow along by creating your own virtual environments.
"""

import sys
import os
import subprocess

# ============================================================================
# SECTION 1: CREATING A VIRTUAL ENVIRONMENT
# ============================================================================

"""
The venv module is built into Python 3.3+ (no installation needed)
It's the standard, recommended way to create virtual environments.

BASIC SYNTAX:
    python -m venv <environment_name>
    
Where:
    python       = Your Python interpreter (python3 on some systems)
    -m venv      = Run the venv module
    <environment_name> = Name for your virtual environment directory
"""

# ----------------------------------------------------------------------------
# Example 1: Creating Your First Virtual Environment
# ----------------------------------------------------------------------------

"""
COMMAND LINE EXAMPLE (run in terminal, not in Python):

# Navigate to your project directory
cd ~/my_project

# Create a virtual environment named 'venv'
python -m venv venv

# Wait a few seconds while it's created...
# You'll see a new 'venv' directory appear

WHAT JUST HAPPENED:
-------------------
1. Python created a new directory called 'venv'
2. Inside, it set up a minimal Python environment
3. It included pip and setuptools
4. It created activation scripts

NOTE: 'venv' is a popular naming convention, but you can use any name:
    python -m venv my_env
    python -m venv env
    python -m venv .venv  (hidden on Unix-like systems)
"""

# ----------------------------------------------------------------------------
# Example 2: Exploring the Virtual Environment Structure
# ----------------------------------------------------------------------------

"""
After creating a venv, examine its structure:

UNIX-LIKE SYSTEMS (Linux, macOS):
---------------------------------
venv/
├── bin/                    ← Executable files
│   ├── python              ← Python interpreter (symlink)
│   ├── python3             ← Another link to same interpreter
│   ├── pip                 ← Pip for this environment
│   ├── pip3                ← Another link to pip
│   ├── activate            ← Bash/Zsh activation script
│   ├── activate.csh        ← C shell activation script
│   ├── activate.fish       ← Fish shell activation script
│   └── Activate.ps1        ← PowerShell activation script
├── include/                ← C headers (for packages with C extensions)
├── lib/
│   └── python3.x/
│       └── site-packages/  ← Where packages are installed
└── pyvenv.cfg              ← Configuration (Python version, etc.)

WINDOWS:
--------
venv/
├── Scripts/                ← Executable files (note: 'Scripts' not 'bin')
│   ├── python.exe          ← Python interpreter (copy)
│   ├── pip.exe             ← Pip for this environment
│   ├── activate.bat        ← CMD activation script
│   └── Activate.ps1        ← PowerShell activation script
├── Include/                ← C headers
├── Lib/
│   └── site-packages/      ← Where packages are installed
└── pyvenv.cfg              ← Configuration

KEY DIFFERENCES:
----------------
- Unix uses 'bin', Windows uses 'Scripts'
- Unix uses symlinks, Windows copies files
- Activation scripts differ between platforms
"""

# PRACTICAL EXAMPLE: Let's examine a venv programmatically
def examine_venv_structure(venv_path):
    """
    This function explores and prints the structure of a virtual environment.
    
    Parameters:
    -----------
    venv_path : str
        Path to the virtual environment directory
    
    Educational Note:
    ----------------
    This demonstrates how to programmatically inspect directory structures.
    Understanding what's inside a venv helps demystify how it works.
    """
    # Check if the venv exists
    if not os.path.exists(venv_path):
        print(f"Virtual environment not found at: {venv_path}")
        return
    
    print(f"Examining virtual environment: {venv_path}")
    print("=" * 60)
    
    # Determine platform-specific directory names
    # On Windows: Scripts, Include, Lib
    # On Unix: bin, include, lib
    if sys.platform == "win32":
        bin_dir = "Scripts"
        lib_dir = "Lib"
        include_dir = "Include"
    else:
        bin_dir = "bin"
        lib_dir = "lib"
        include_dir = "include"
    
    # Show key directories
    print("\nKey Directories:")
    print(f"  Executables: {venv_path}/{bin_dir}")
    print(f"  Libraries: {venv_path}/{lib_dir}")
    print(f"  Headers: {venv_path}/{include_dir}")
    
    # List executables/scripts
    bin_path = os.path.join(venv_path, bin_dir)
    if os.path.exists(bin_path):
        print(f"\nExecutables in {bin_dir}/:")
        # List first 10 files (to keep output manageable)
        files = os.listdir(bin_path)[:10]
        for file in files:
            print(f"  - {file}")
        if len(os.listdir(bin_path)) > 10:
            print(f"  ... and {len(os.listdir(bin_path)) - 10} more")
    
    # Check pyvenv.cfg
    cfg_path = os.path.join(venv_path, "pyvenv.cfg")
    if os.path.exists(cfg_path):
        print("\nConfiguration (pyvenv.cfg):")
        with open(cfg_path, 'r') as f:
            for line in f:
                print(f"  {line.rstrip()}")
    
    print("\n" + "=" * 60)


# Example usage (uncomment to run if you have a venv):
# examine_venv_structure("venv")


# ============================================================================
# SECTION 2: ACTIVATING A VIRTUAL ENVIRONMENT
# ============================================================================

"""
Creating a venv is just the first step.
To USE it, you must ACTIVATE it.

Activation changes your shell's environment so that:
1. The venv's Python is used instead of system Python
2. The venv's pip is used instead of system pip
3. Packages are installed to the venv, not system-wide

CRITICAL: You must activate the venv in EVERY new terminal session!
"""

# ----------------------------------------------------------------------------
# Activation Commands by Platform and Shell
# ----------------------------------------------------------------------------

"""
UNIX-LIKE SYSTEMS (Linux, macOS):
----------------------------------

Bash/Zsh (most common):
    source venv/bin/activate

Fish:
    source venv/bin/activate.fish

Csh/Tcsh:
    source venv/bin/activate.csh


WINDOWS:
--------

Command Prompt (cmd.exe):
    venv\\Scripts\\activate.bat

PowerShell:
    venv\\Scripts\\Activate.ps1
    
    NOTE: PowerShell may require execution policy change:
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser


WHAT ACTIVATION DOES:
---------------------
1. Modifies PATH environment variable
   - Adds venv/bin (or Scripts) to the FRONT of PATH
   - Now 'python' and 'pip' commands find venv versions first

2. Sets VIRTUAL_ENV environment variable
   - Points to the venv directory
   - Some tools use this to detect the active environment

3. Changes command prompt
   - Usually adds (venv) prefix to show environment is active
   - Example: (venv) user@computer:~/project$

4. Provides 'deactivate' command
   - Function to restore original environment
"""

# ----------------------------------------------------------------------------
# Example 3: Detecting if You're in a Virtual Environment
# ----------------------------------------------------------------------------

def check_virtual_environment():
    """
    Check if code is running inside a virtual environment.
    
    Educational Note:
    ----------------
    This function demonstrates multiple methods to detect virtual environments.
    Understanding these checks helps debug environment issues.
    
    Returns:
    --------
    dict : Information about the current environment
    """
    # Method 1: Check for VIRTUAL_ENV environment variable
    # This is set when a venv is activated
    venv_path = os.environ.get('VIRTUAL_ENV')
    
    # Method 2: Check if base_prefix differs from prefix
    # In a venv, sys.prefix points to venv, sys.base_prefix points to system Python
    # Outside venv, both point to the same location
    in_venv = sys.prefix != sys.base_prefix
    
    # Method 3: Check for existence of pyvenv.cfg
    # Real virtual environments have this file
    pyvenv_cfg = os.path.join(sys.prefix, 'pyvenv.cfg')
    has_pyvenv_cfg = os.path.exists(pyvenv_cfg)
    
    # Gather information
    info = {
        'in_virtual_environment': in_venv,
        'VIRTUAL_ENV_variable': venv_path,
        'sys.prefix': sys.prefix,
        'sys.base_prefix': sys.base_prefix,
        'python_executable': sys.executable,
        'has_pyvenv_cfg': has_pyvenv_cfg
    }
    
    return info


def print_environment_info():
    """
    Print detailed information about the current Python environment.
    
    Use this function to verify you're in the correct environment.
    """
    info = check_virtual_environment()
    
    print("Python Environment Information")
    print("=" * 60)
    
    if info['in_virtual_environment']:
        print("✓ Running in a VIRTUAL ENVIRONMENT")
        print(f"  Environment path: {info['VIRTUAL_ENV_variable'] or info['sys.prefix']}")
    else:
        print("✗ Running in SYSTEM PYTHON")
        print("  WARNING: Not in a virtual environment!")
    
    print(f"\nPython executable: {info['python_executable']}")
    print(f"sys.prefix: {info['sys.prefix']}")
    print(f"sys.base_prefix: {info['sys.base_prefix']}")
    print(f"Has pyvenv.cfg: {info['has_pyvenv_cfg']}")
    
    print("\n" + "=" * 60)


# Run this to check your current environment
# Uncomment the line below:
# print_environment_info()


# ============================================================================
# SECTION 3: WORKING WITH AN ACTIVATED ENVIRONMENT
# ============================================================================

"""
Once activated, you work normally with Python and pip.
The key difference: everything stays isolated in your venv.
"""

# ----------------------------------------------------------------------------
# Example 4: Verifying Active Environment
# ----------------------------------------------------------------------------

"""
COMMAND LINE VERIFICATION (run these in your terminal after activation):

1. Check which Python is being used:
   
   Unix-like:
   $ which python
   /path/to/your/project/venv/bin/python
   
   Windows:
   > where python
   C:\\path\\to\\your\\project\\venv\\Scripts\\python.exe

2. Check Python version:
   $ python --version
   Python 3.11.4  (example)

3. Check which pip is being used:
   
   Unix-like:
   $ which pip
   /path/to/your/project/venv/bin/pip
   
   Windows:
   > where pip
   C:\\path\\to\\your\\project\\venv\\Scripts\\pip.exe

4. List installed packages (should be minimal):
   $ pip list
   Package    Version
   ---------- -------
   pip        23.2.1
   setuptools 68.0.0

IMPORTANT: If these commands show system paths instead of venv paths,
           your environment is NOT activated correctly!
"""

def verify_environment_activation():
    """
    Programmatic verification that you're using the virtual environment.
    
    This function checks that Python and pip executables are coming from
    the expected virtual environment location.
    
    Educational Note:
    ----------------
    This is useful in scripts to ensure they're running in the correct environment.
    Production scripts often include similar checks.
    """
    info = check_virtual_environment()
    
    if not info['in_virtual_environment']:
        print("❌ WARNING: Not running in a virtual environment!")
        print("   Please activate your virtual environment first.")
        return False
    
    print("✓ Virtual environment is active")
    
    # Verify Python executable location
    expected_prefix = info['sys.prefix']
    actual_executable = sys.executable
    
    # Check if executable is within the venv
    if expected_prefix in actual_executable:
        print("✓ Python executable is from the virtual environment")
        print(f"  Location: {actual_executable}")
    else:
        print("❌ WARNING: Python executable may not be from the venv")
        print(f"  Expected prefix: {expected_prefix}")
        print(f"  Actual location: {actual_executable}")
        return False
    
    # Try to locate pip
    try:
        if sys.platform == "win32":
            pip_location = os.path.join(expected_prefix, "Scripts", "pip.exe")
        else:
            pip_location = os.path.join(expected_prefix, "bin", "pip")
        
        if os.path.exists(pip_location):
            print("✓ Pip is available in the virtual environment")
            print(f"  Location: {pip_location}")
        else:
            print("❌ WARNING: Could not locate pip in the venv")
            return False
    except Exception as e:
        print(f"❌ Error checking pip location: {e}")
        return False
    
    print("\n✅ Environment verification passed!")
    return True


# Uncomment to run verification:
# verify_environment_activation()


# ============================================================================
# SECTION 4: DEACTIVATING A VIRTUAL ENVIRONMENT
# ============================================================================

"""
When you're done working in a virtual environment, deactivate it.
This restores your shell to use the system Python.

DEACTIVATION COMMAND (same for all platforms and shells):
    deactivate

WHAT DEACTIVATION DOES:
-----------------------
1. Removes venv/bin (or Scripts) from PATH
2. Unsets VIRTUAL_ENV environment variable
3. Removes (venv) prefix from command prompt
4. Restores original Python and pip commands

IMPORTANT NOTES:
----------------
- 'deactivate' is a shell function added by the activation script
- It's not a Python command or external program
- You must be in the same shell session where you activated
- Closing the terminal also effectively "deactivates" (new terminal = clean slate)
"""

# ----------------------------------------------------------------------------
# Example 5: Complete Workflow
# ----------------------------------------------------------------------------

"""
TYPICAL DEVELOPMENT WORKFLOW:

1. Create project directory:
   $ mkdir my_project
   $ cd my_project

2. Create virtual environment:
   $ python -m venv venv

3. Activate the environment:
   # Unix-like:
   $ source venv/bin/activate
   # Windows:
   > venv\\Scripts\\activate.bat

4. Verify activation:
   (venv) $ python --version
   (venv) $ which python  (or 'where python' on Windows)

5. Work on your project:
   (venv) $ pip install requests
   (venv) $ python my_script.py
   (venv) $ pip install flask
   (venv) $ python app.py

6. When finished:
   (venv) $ deactivate
   $  # Prompt returns to normal

7. Next day, come back:
   $ cd my_project
   $ source venv/bin/activate  # Must reactivate!
   (venv) $  # Continue working
"""


# ============================================================================
# SECTION 5: COMMON MISTAKES AND TROUBLESHOOTING
# ============================================================================

"""
MISTAKE 1: Forgetting to Activate
----------------------------------
Symptom: Packages installed but Python can't find them
Cause: Installing with system pip while running code with venv Python
Solution: ALWAYS activate before installing or running code

Example:
    # WRONG - Not activated
    $ pip install requests        # Installs to system
    $ venv/bin/python script.py   # Runs with venv Python - can't find requests!
    
    # RIGHT - Activated first
    $ source venv/bin/activate
    (venv) $ pip install requests  # Installs to venv
    (venv) $ python script.py      # Runs with venv Python - finds requests!
"""

"""
MISTAKE 2: Running Python with Full Path
-----------------------------------------
Symptom: Imports fail even though packages are installed in venv
Cause: Running venv's Python directly without activating
Solution: Activate the venv, then run python normally

Example:
    # WRONG - Running without activation
    $ venv/bin/python script.py   # Python from venv, but PATH not set correctly
    
    # RIGHT - Activate first
    $ source venv/bin/activate
    (venv) $ python script.py     # Everything configured correctly
"""

"""
MISTAKE 3: Creating Venv Inside Another Venv
---------------------------------------------
Symptom: Nested environments, confusion about which is active
Cause: Activating one venv, then creating another
Solution: Deactivate before creating new venv

Example:
    # WRONG
    (venv1) $ python -m venv venv2  # venv2 created using venv1's Python
    
    # RIGHT
    (venv1) $ deactivate
    $ python -m venv venv2          # venv2 created using system Python
"""

"""
MISTAKE 4: Activating Wrong Environment
----------------------------------------
Symptom: Packages not found, unexpected versions
Cause: Multiple venvs, activated the wrong one
Solution: Check VIRTUAL_ENV variable, deactivate and reactivate correct one

Example:
    (old_venv) $ echo $VIRTUAL_ENV
    /path/to/old_venv
    (old_venv) $ deactivate
    $ source new_venv/bin/activate
    (new_venv) $ echo $VIRTUAL_ENV
    /path/to/new_venv
"""

"""
MISTAKE 5: Committing Venv to Version Control
----------------------------------------------
Symptom: Git repo becomes huge, conflicts on different machines
Cause: Adding venv directory to git
Solution: Add venv/ to .gitignore

Example .gitignore:
    # Virtual environments
    venv/
    env/
    ENV/
    .venv/
    
    # Python
    __pycache__/
    *.py[cod]
    *.so
"""


# ============================================================================
# SECTION 6: PLATFORM-SPECIFIC CONSIDERATIONS
# ============================================================================

# ----------------------------------------------------------------------------
# Windows-Specific Issues and Solutions
# ----------------------------------------------------------------------------

"""
ISSUE 1: PowerShell Execution Policy
-------------------------------------
Error: "cannot be loaded because running scripts is disabled"

Solution:
    # Run PowerShell as Administrator
    Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

Or use Command Prompt instead:
    venv\\Scripts\\activate.bat
"""

"""
ISSUE 2: Path Length Limitations
---------------------------------
Error: "The filename or extension is too long"

Solution:
    - Keep project paths short
    - Place projects close to drive root (e.g., C:\\projects\\)
    - Use shorter venv names
    
Example:
    # AVOID
    C:\\Users\\YourName\\Documents\\My Projects\\Python\\Web Development\\my_amazing_project_with_long_name\\venv\\
    
    # PREFER
    C:\\projects\\web_app\\venv\\
"""

"""
ISSUE 3: Antivirus Interference
--------------------------------
Symptom: Slow venv creation, files locked

Solution:
    - Add project directory to antivirus exclusions
    - Use developer-friendly antivirus settings
"""

# ----------------------------------------------------------------------------
# Unix-Like Specific Issues
# ----------------------------------------------------------------------------

"""
ISSUE 1: Permission Denied
---------------------------
Error: Permission denied when creating venv

Solution:
    - Don't use sudo with venv creation
    - Check directory permissions
    - Ensure you own the project directory
    
Example:
    # WRONG
    $ sudo python -m venv venv  # Creates files owned by root
    
    # RIGHT
    $ python -m venv venv       # Creates files owned by you
"""

"""
ISSUE 2: Multiple Python Versions
----------------------------------
Symptom: Venv created with wrong Python version

Solution:
    - Use explicit Python version command
    - Use pyenv to manage Python versions
    
Example:
    $ python3.11 -m venv venv   # Use specific Python version
    $ which python3.11           # Verify it's available
"""


# ============================================================================
# SECTION 7: ADVANCED ACTIVATION TECHNIQUES
# ============================================================================

# ----------------------------------------------------------------------------
# Shell Aliases and Functions
# ----------------------------------------------------------------------------

"""
Pro tip: Create shell aliases for common venv operations

For Bash/Zsh (add to ~/.bashrc or ~/.zshrc):

# Quick activation
alias activate='source venv/bin/activate'

# Quick deactivation (though just typing 'deactivate' works)
alias deact='deactivate'

# Create and activate in one command
mkenv() {
    python -m venv venv
    source venv/bin/activate
    pip install --upgrade pip
}

# Activate and show environment info
act() {
    source venv/bin/activate
    echo "Virtual environment activated:"
    echo "  Python: $(which python)"
    echo "  Pip: $(which pip)"
}


For Windows PowerShell (add to $PROFILE):

function Activate-Venv {
    .\\venv\\Scripts\\Activate.ps1
    Write-Host "Virtual environment activated"
}
Set-Alias -Name activate -Value Activate-Venv

function New-Venv {
    python -m venv venv
    .\\venv\\Scripts\\Activate.ps1
    pip install --upgrade pip
}
"""


# ============================================================================
# SECTION 8: BEST PRACTICES
# ============================================================================

"""
BEST PRACTICE 1: One Venv Per Project
--------------------------------------
Don't share venvs between projects
Each project gets its own isolated environment
Prevents unexpected interactions

Project structure:
    project_a/
        venv/        ← Dedicated to project_a
        src/
        tests/
    
    project_b/
        venv/        ← Dedicated to project_b
        src/
        tests/
"""

"""
BEST PRACTICE 2: Standard Venv Names
-------------------------------------
Use consistent names across projects
Common choices: venv, env, .venv
Team should agree on one convention

Benefits:
    - Easy to add to .gitignore: venv/
    - Easy to remember activation command
    - IDEs often auto-detect 'venv' or '.venv'
"""

"""
BEST PRACTICE 3: Keep Venv in Project Root
-------------------------------------------
Place venv directory at project root
Makes activation commands consistent
Easy for teammates to find

Example:
    my_project/
        venv/            ← Here
        src/
        tests/
        README.md
        requirements.txt
"""

"""
BEST PRACTICE 4: Activate in Every Session
-------------------------------------------
ALWAYS activate venv before working
Add activation to your workflow checklist
Consider using IDE features to auto-activate

IDE Integration:
    - VS Code: Select interpreter (Command Palette → Python: Select Interpreter)
    - PyCharm: Configure Python interpreter in settings
    - Both: Automatically activate venv in integrated terminal
"""

"""
BEST PRACTICE 5: Document Venv Setup
-------------------------------------
Include setup instructions in README
Help teammates and future you

Example README section:

## Setup

1. Create virtual environment:
   ```bash
   python -m venv venv
   ```

2. Activate virtual environment:
   - Unix/macOS: `source venv/bin/activate`
   - Windows: `venv\\Scripts\\activate.bat`

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
"""


# ============================================================================
# SECTION 9: QUICK REFERENCE
# ============================================================================

"""
QUICK COMMAND REFERENCE:

Create venv:
    python -m venv venv

Activate (Unix/macOS):
    source venv/bin/activate

Activate (Windows CMD):
    venv\\Scripts\\activate.bat

Activate (Windows PowerShell):
    venv\\Scripts\\Activate.ps1

Deactivate (all platforms):
    deactivate

Check if in venv (Python):
    import sys
    print(sys.prefix != sys.base_prefix)

Check Python location (shell):
    which python     (Unix/macOS)
    where python     (Windows)

Check pip location (shell):
    which pip        (Unix/macOS)
    where pip        (Windows)

Remove venv:
    rm -rf venv      (Unix/macOS)
    rmdir /s venv    (Windows)
"""


# ============================================================================
# SECTION 10: HANDS-ON EXERCISES
# ============================================================================

"""
EXERCISE 1: Create and Explore
-------------------------------
1. Create a new directory called 'test_project'
2. Create a virtual environment named 'venv'
3. List the contents of the venv directory
4. Find the Python executable in the venv
5. Read the pyvenv.cfg file

EXERCISE 2: Activation Practice
--------------------------------
1. Open a terminal
2. Navigate to your test_project
3. Activate the virtual environment
4. Run: which python (or where python on Windows)
5. Verify it points to your venv
6. Deactivate
7. Run which python again - verify it's back to system Python

EXERCISE 3: Environment Detection
----------------------------------
1. Create a Python script with check_virtual_environment() function
2. Run it outside a venv - observe output
3. Activate a venv
4. Run the same script inside venv - compare output

EXERCISE 4: Multiple Environments
----------------------------------
1. Create three directories: proj_a, proj_b, proj_c
2. Create a venv in each
3. Practice activating different venvs
4. Check $VIRTUAL_ENV to confirm correct activation

EXERCISE 5: Troubleshooting
----------------------------
1. Activate a venv
2. Try to create another venv while activated
3. Deactivate
4. Create the second venv
5. Practice switching between venvs
"""


# ============================================================================
# SELF-CHECK QUESTIONS
# ============================================================================

"""
1. What command creates a virtual environment named 'myenv'?
   (Answer: python -m venv myenv)

2. How do you activate a venv on macOS?
   (Answer: source venv/bin/activate)

3. What changes in your terminal after activation?
   (Answer: Prompt shows (venv) prefix; PATH is modified)

4. How do you check if you're in a virtual environment?
   (Answer: Check $VIRTUAL_ENV or compare sys.prefix with sys.base_prefix)

5. What's the command to deactivate any virtual environment?
   (Answer: deactivate)

6. What's the difference between 'bin' and 'Scripts' directories?
   (Answer: Unix-like systems use 'bin', Windows uses 'Scripts')

7. Should you commit your venv to git?
   (Answer: No! Add it to .gitignore)

8. Do you need to reactivate the venv in a new terminal session?
   (Answer: Yes, activation is per terminal session)
"""


# ============================================================================
# CONCLUSION
# ============================================================================

"""
You now know how to:
✓ Create virtual environments using venv
✓ Understand venv directory structure
✓ Activate and deactivate environments
✓ Verify which environment is active
✓ Troubleshoot common issues
✓ Follow best practices

Next, you'll learn how to install packages using pip and manage
your project's dependencies.

Move on to: 03_pip_basics.py
"""

# ============================================================================
# END OF FILE
# ============================================================================
