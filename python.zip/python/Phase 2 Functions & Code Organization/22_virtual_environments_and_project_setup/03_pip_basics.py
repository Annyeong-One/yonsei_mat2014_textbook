"""
VIRTUAL ENVIRONMENTS & PACKAGE MANAGEMENT - LESSON 3
====================================================
Topic: Package Installation with pip
Level: Beginner
Prerequisites: Lessons 1-2 (Virtual environments basics)

LEARNING OBJECTIVES:
- Understand what pip is and its role in Python
- Install, upgrade, and uninstall packages using pip
- Search for packages on PyPI (Python Package Index)
- View installed packages and their details
- Understand package naming and versioning
- Handle common pip errors and issues

This file teaches practical pip usage within virtual environments.
All examples assume you're working in an activated virtual environment.
"""

import subprocess
import sys
import json

# ============================================================================
# SECTION 1: UNDERSTANDING PIP
# ============================================================================

"""
PIP: PYTHON'S PACKAGE INSTALLER
===============================

What is pip?
------------
pip is the standard package installer for Python. It downloads and installs
packages from the Python Package Index (PyPI) and other indexes.

Think of pip as:
- App Store for Python packages
- apt/yum for Python (if you know Linux)
- npm for Python (if you know JavaScript)
- gem for Python (if you know Ruby)

PyPI (Python Package Index):
-----------------------------
- https://pypi.org
- Central repository of Python packages
- Over 400,000 packages available
- Free and open source
- Anyone can publish packages (after registration)

pip comes pre-installed with Python 3.4+ and in all virtual environments.
"""

# ----------------------------------------------------------------------------
# What pip Does
# ----------------------------------------------------------------------------

"""
When you run 'pip install package_name', pip:

1. RESOLVES DEPENDENCIES
   - Reads the package's required dependencies
   - Determines compatible versions
   - Creates an installation plan

2. DOWNLOADS PACKAGES
   - Fetches packages from PyPI (or specified index)
   - Downloads appropriate wheel or source distribution
   - Verifies package integrity (checksums)

3. INSTALLS PACKAGES
   - Extracts package contents
   - Copies files to site-packages directory
   - Creates entry points (console scripts)
   - Compiles C extensions if needed

4. UPDATES METADATA
   - Records installed version
   - Maintains dependency information
   - Creates .dist-info directory with metadata
"""


# ============================================================================
# SECTION 2: BASIC PIP COMMANDS
# ============================================================================

"""
COMMAND LINE SYNTAX:
-------------------
pip [command] [options] [package_specifier]

CRITICAL: Always activate your virtual environment before using pip!
         (venv) $ pip install package_name

If you run pip outside a venv, you'll install to system Python (bad!)
"""

# ----------------------------------------------------------------------------
# Installing Packages
# ----------------------------------------------------------------------------

"""
1. INSTALL LATEST VERSION
--------------------------
Command: pip install package_name

Example:
    (venv) $ pip install requests

What happens:
    - pip contacts PyPI
    - Finds the latest version of 'requests'
    - Downloads the package and dependencies
    - Installs to venv/lib/pythonX.Y/site-packages/

Output example:
    Collecting requests
      Downloading requests-2.31.0-py3-none-any.whl (62 kB)
    Collecting charset-normalizer<4,>=2
      Downloading charset_normalizer-3.3.2-cp311-cp311-macosx_11_0_arm64.whl
    Collecting idna<4,>=2.5
      Downloading idna-3.6-py3-none-any.whl (61 kB)
    Collecting urllib3<3,>=1.21.1
      Downloading urllib3-2.1.0-py3-none-any.whl (104 kB)
    Collecting certifi>=2017.4.17
      Downloading certifi-2023.11.17-py3-none-any.whl (162 kB)
    Installing collected packages: urllib3, idna, charset-normalizer, certifi, requests
    Successfully installed certifi-2023.11.17 charset-normalizer-3.3.2 idna-3.6 requests-2.31.0 urllib3-2.1.0

Note: requests has 4 dependencies, all installed automatically!
"""

"""
2. INSTALL SPECIFIC VERSION
----------------------------
Command: pip install package_name==version

Example:
    (venv) $ pip install requests==2.28.0

Why specify versions?
    - Reproducibility: Same code works the same everywhere
    - Stability: Avoid breaking changes in newer versions
    - Compatibility: Some packages require specific versions of dependencies
    - Debugging: Test if issue is version-specific
"""

"""
3. INSTALL VERSION CONSTRAINTS
-------------------------------
You can specify version ranges using comparison operators:

Operators:
    ==  Exactly this version
    !=  Any version except this
    >=  This version or newer
    <=  This version or older
    >   Newer than this version
    <   Older than this version
    ~=  Compatible release (see below)

Examples:
    pip install "requests>=2.28.0"           # 2.28.0 or newer
    pip install "requests>=2.28.0,<3.0.0"    # 2.28.x series, not 3.x
    pip install "requests~=2.28.0"           # 2.28.x series (compatible release)
    pip install "requests!=2.29.0"           # Any version except 2.29.0

Note: Use quotes if command includes <, >, or other shell special characters!
"""

"""
4. INSTALL FROM REQUIREMENTS FILE
----------------------------------
Command: pip install -r requirements.txt

Most common way to install project dependencies.
We'll cover this in detail in Lesson 4.

Example:
    (venv) $ pip install -r requirements.txt
"""

"""
5. INSTALL IN EDITABLE MODE
----------------------------
Command: pip install -e .

For package development. Changes to source code immediately available.
We'll cover this in Lesson 10.

Example:
    (venv) $ cd my_package/
    (venv) $ pip install -e .
"""

# ----------------------------------------------------------------------------
# Upgrading Packages
# ----------------------------------------------------------------------------

"""
UPGRADE TO LATEST VERSION
--------------------------
Command: pip install --upgrade package_name
Shorthand: pip install -U package_name

Example:
    (venv) $ pip install --upgrade requests

What happens:
    - pip checks current installed version
    - Checks PyPI for newer version
    - If newer version exists, downloads and installs it
    - May also upgrade dependencies if needed

Important: Always test after upgrading!
          New versions may introduce breaking changes.
"""

"""
UPGRADE PIP ITSELF
-------------------
pip can upgrade itself!

Command: pip install --upgrade pip

Example:
    (venv) $ pip install --upgrade pip
    
    Collecting pip
      Downloading pip-23.3.1-py3-none-any.whl (2.1 MB)
    Installing collected packages: pip
      Attempting uninstall: pip
        Found existing installation: pip 23.2.1
        Uninstalling pip-23.2.1:
          Successfully uninstalled pip-23.2.1
    Successfully installed pip-23.3.1

Best practice: Upgrade pip in new venvs for latest features and bug fixes.
"""

# ----------------------------------------------------------------------------
# Uninstalling Packages
# ----------------------------------------------------------------------------

"""
UNINSTALL A PACKAGE
--------------------
Command: pip uninstall package_name

Example:
    (venv) $ pip uninstall requests
    
    Found existing installation: requests 2.31.0
    Uninstalling requests-2.31.0:
      Would remove:
        /path/to/venv/lib/python3.11/site-packages/requests/
        /path/to/venv/lib/python3.11/site-packages/requests-2.31.0.dist-info/
    Proceed (Y/n)? Y
      Successfully uninstalled requests-2.31.0

Note: pip asks for confirmation before removing files.
      Use -y flag to skip confirmation: pip uninstall -y requests

WARNING: pip uninstall does NOT remove dependencies!
         If you installed 'requests', its dependencies remain installed.
         This is intentional - other packages might use them.
"""

"""
UNINSTALL MULTIPLE PACKAGES
----------------------------
Command: pip uninstall package1 package2 package3

Example:
    (venv) $ pip uninstall requests beautifulsoup4 lxml
"""

"""
UNINSTALL ALL PACKAGES
-----------------------
Useful when cleaning up an environment.

Unix-like systems:
    (venv) $ pip freeze | xargs pip uninstall -y

Windows PowerShell:
    (venv) > pip freeze | ForEach-Object {pip uninstall $_ -y}

This removes everything except pip and setuptools.
"""


# ============================================================================
# SECTION 3: VIEWING INSTALLED PACKAGES
# ============================================================================

"""
LIST ALL INSTALLED PACKAGES
----------------------------
Command: pip list

Example output:
    (venv) $ pip list
    
    Package              Version
    -------------------- ---------
    beautifulsoup4       4.12.2
    certifi              2023.11.17
    charset-normalizer   3.3.2
    idna                 3.6
    pip                  23.3.1
    requests             2.31.0
    setuptools           68.2.0
    soupsieve            2.5
    urllib3              2.1.0

Shows:
    - Package names (left column)
    - Installed versions (right column)
    - All packages, including dependencies
"""

"""
LIST OUTDATED PACKAGES
-----------------------
Command: pip list --outdated

Example output:
    (venv) $ pip list --outdated
    
    Package     Version  Latest   Type
    ----------- -------- -------- -----
    requests    2.28.0   2.31.0   wheel
    setuptools  68.0.0   68.2.0   wheel

Shows:
    - Packages with newer versions available
    - Current version vs latest version
    - Package type (wheel or sdist)

Use this to identify packages that need upgrading.
"""

"""
LIST IN REQUIREMENTS FORMAT
----------------------------
Command: pip freeze

Example output:
    (venv) $ pip freeze
    
    beautifulsoup4==4.12.2
    certifi==2023.11.17
    charset-normalizer==3.3.2
    idna==3.6
    requests==2.31.0
    soupsieve==2.5
    urllib3==2.1.0

Difference from 'pip list':
    - Format: package==version (requirements.txt format)
    - Excludes pip and setuptools
    - Can be redirected to file: pip freeze > requirements.txt
    - Includes all dependencies with exact versions

This is THE standard way to share project dependencies.
"""

"""
SHOW PACKAGE DETAILS
---------------------
Command: pip show package_name

Example:
    (venv) $ pip show requests
    
    Name: requests
    Version: 2.31.0
    Summary: Python HTTP for Humans.
    Home-page: https://requests.readthedocs.io
    Author: Kenneth Reitz
    Author-email: me@kennethreitz.org
    License: Apache 2.0
    Location: /path/to/venv/lib/python3.11/site-packages
    Requires: certifi, charset-normalizer, idna, urllib3
    Required-by: 

Shows:
    - Package metadata
    - Installation location
    - Dependencies (Requires)
    - Reverse dependencies (Required-by)

Very useful for understanding package relationships!
"""

# Programmatic example: Get installed packages
def get_installed_packages():
    """
    Get list of installed packages programmatically.
    
    This demonstrates how to work with pip from within Python code.
    Useful for automated scripts and tools.
    
    Returns:
    --------
    list of dict : Package information
    """
    try:
        # Run pip list with JSON output format
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'list', '--format=json'],
            capture_output=True,
            text=True,
            check=True
        )
        
        # Parse JSON output
        packages = json.loads(result.stdout)
        
        return packages
    
    except subprocess.CalledProcessError as e:
        print(f"Error running pip: {e}")
        return []
    except json.JSONDecodeError as e:
        print(f"Error parsing pip output: {e}")
        return []


def print_installed_packages():
    """
    Print formatted list of installed packages.
    """
    packages = get_installed_packages()
    
    if not packages:
        print("No packages found or error occurred.")
        return
    
    print(f"{'Package':<30} {'Version':<15}")
    print("=" * 45)
    
    for pkg in sorted(packages, key=lambda x: x['name']):
        print(f"{pkg['name']:<30} {pkg['version']:<15}")
    
    print(f"\nTotal packages: {len(packages)}")


# Uncomment to run:
# print_installed_packages()


# ============================================================================
# SECTION 4: SEARCHING FOR PACKAGES
# ============================================================================

"""
Note: As of 2021, 'pip search' was disabled due to PyPI infrastructure issues.

ALTERNATIVES FOR FINDING PACKAGES:
-----------------------------------

1. PyPI Website: https://pypi.org
   - Web interface
   - Search by keyword
   - View package details, documentation, statistics
   - Most reliable method

2. pypi-simple library:
   (venv) $ pip install pypi-simple
   Then use it programmatically to search

3. Google/Search Engines:
   - "python package for [task]"
   - Often leads to PyPI, GitHub, or blog posts

4. Awesome Python Lists:
   - https://github.com/vinta/awesome-python
   - Curated list of popular packages by category

5. Python Standard Library:
   - Check if functionality is built-in first!
   - Many tasks don't need external packages
"""

"""
EVALUATING PACKAGES BEFORE INSTALLATION:
-----------------------------------------

Before pip installing a package, consider:

1. POPULARITY AND MAINTENANCE
   - Download statistics (PyPI shows this)
   - Recent updates (active maintenance?)
   - GitHub stars and forks
   - Issue response times

2. DOCUMENTATION QUALITY
   - Comprehensive docs?
   - Code examples?
   - API reference?

3. PYTHON VERSION SUPPORT
   - Supports your Python version?
   - Wheel available for your platform?

4. DEPENDENCIES
   - How many dependencies?
   - Are dependencies well-maintained?
   - Any security concerns?

5. LICENSE
   - Compatible with your project?
   - Commercial use allowed?
   - Copyleft vs permissive?

6. SECURITY
   - Known vulnerabilities?
   - Check: pip install safety; safety check
   - Review: https://github.com/advisories

Example: Evaluating 'requests' package
    ✓ 2+ billion downloads
    ✓ Active maintenance
    ✓ Excellent documentation
    ✓ Supports Python 3.7+
    ✓ Minimal, well-maintained dependencies
    ✓ Apache 2.0 license (permissive)
    ✓ Used by major companies
    → Safe to use!
"""


# ============================================================================
# SECTION 5: PACKAGE VERSIONS AND NAMING
# ============================================================================

"""
SEMANTIC VERSIONING (SemVer)
-----------------------------
Most Python packages follow semantic versioning: MAJOR.MINOR.PATCH

Example: requests 2.31.0
         ^        ^    ^
         |        |    |
         MAJOR    MINOR PATCH

Rules:
    MAJOR: Breaking changes (incompatible API changes)
    MINOR: New features (backwards-compatible)
    PATCH: Bug fixes (backwards-compatible)

Examples:
    2.31.0 → 2.31.1  (patch)   ✓ Safe to upgrade
    2.31.1 → 2.32.0  (minor)   ✓ Should be safe
    2.32.0 → 3.0.0   (major)   ⚠️ May have breaking changes!

Pre-release versions:
    2.31.0a1     (alpha)
    2.31.0b1     (beta)
    2.31.0rc1    (release candidate)
    2.31.0       (stable release)
"""

"""
PACKAGE NAMING CONVENTIONS
---------------------------

Official package names (on PyPI):
    - Usually lowercase
    - May use hyphens or underscores
    - Examples: scikit-learn, beautifulsoup4, Pillow

Import names (in Python code):
    - May differ from package name!
    - Examples:
        Package: scikit-learn → Import: sklearn
        Package: Pillow → Import: PIL
        Package: beautifulsoup4 → Import: bs4

Finding import name:
    1. Check package documentation
    2. pip show package_name  (look at "Location")
    3. List site-packages directory
    4. Try the obvious name first

Common patterns:
    Package name        Import name
    ------------        -----------
    opencv-python       cv2
    python-dateutil     dateutil
    PyYAML              yaml
    typing-extensions   typing_extensions
"""


# ============================================================================
# SECTION 6: PIP CONFIGURATION AND OPTIONS
# ============================================================================

"""
USEFUL PIP OPTIONS
------------------

--verbose (-v):
    Show detailed output
    Example: pip install -v requests

--quiet (-q):
    Minimal output
    Example: pip install -q requests

--no-cache-dir:
    Don't use cached packages
    Useful for debugging or when cache is corrupted
    Example: pip install --no-cache-dir requests

--user:
    Install to user site-packages (avoid this in venvs!)
    Only use when not in a virtual environment
    Example: pip install --user requests

--upgrade-strategy:
    Control dependency upgrade behavior
    Options: eager (upgrade all), only-if-needed (default)
    Example: pip install --upgrade --upgrade-strategy eager requests

--dry-run:
    Show what would be installed without installing
    Example: pip install --dry-run requests

--index-url:
    Use alternate package index
    Example: pip install --index-url https://custom-pypi.example.com/ package

--trusted-host:
    Mark host as trusted (for HTTP indexes)
    Example: pip install --trusted-host pypi.example.com package
"""

"""
PIP CONFIGURATION FILE
-----------------------

Location (Unix-like):
    ~/.config/pip/pip.conf

Location (Windows):
    %APPDATA%\\pip\\pip.ini

Example configuration:

[global]
timeout = 60
index-url = https://pypi.org/simple

[install]
no-cache-dir = false
upgrade = false

[list]
format = columns

Usage: Settings apply automatically to all pip commands
"""


# ============================================================================
# SECTION 7: COMMON PIP ERRORS AND SOLUTIONS
# ============================================================================

"""
ERROR 1: "Could not find a version that satisfies the requirement"
-------------------------------------------------------------------
Causes:
    - Package name misspelled
    - Package doesn't exist on PyPI
    - No version compatible with your Python version
    - Network/connectivity issues

Solutions:
    1. Check spelling: pip search was disabled, use PyPI website
    2. Verify package exists on https://pypi.org
    3. Check Python version compatibility
    4. Update pip: pip install --upgrade pip
    5. Check network connection

Example:
    (venv) $ pip install reqeusts  # Typo!
    ERROR: Could not find a version that satisfies the requirement reqeusts
    
    Fix: pip install requests
"""

"""
ERROR 2: "Permission denied" or "Access is denied"
---------------------------------------------------
Causes:
    - Trying to install to system Python
    - Installing to protected directory
    - File system permissions issue

Solutions:
    1. Use virtual environment (best solution!)
    2. Check if venv is activated
    3. Don't use sudo/admin privileges
    4. Check directory permissions

Example:
    $ pip install requests  # Not in venv!
    ERROR: Could not install packages due to an OSError: [Errno 13] Permission denied
    
    Fix: Activate venv first: source venv/bin/activate
"""

"""
ERROR 3: "No module named 'package'"
-------------------------------------
After installation, import fails.

Causes:
    - Package installed to different Python
    - Wrong environment activated
    - Package name ≠ import name
    - Installation failed but showed success

Solutions:
    1. Verify environment: python -c "import sys; print(sys.executable)"
    2. Check package installed: pip show package_name
    3. Check import name (may differ from package name)
    4. Reinstall: pip uninstall package && pip install package

Example:
    (venv) $ pip install opencv-python
    (venv) $ python -c "import opencv"  # Wrong import name!
    ModuleNotFoundError: No module named 'opencv'
    
    Fix: import cv2  # Correct import name
"""

"""
ERROR 4: "Failed building wheel" or "error: command 'gcc' failed"
------------------------------------------------------------------
Causes:
    - Package has C extensions
    - Missing build tools (compiler, headers)
    - Platform incompatibility

Solutions:
    1. Install pre-compiled wheel if available
    2. Install build tools:
       - Ubuntu/Debian: sudo apt-get install build-essential python3-dev
       - macOS: xcode-select --install
       - Windows: Install Visual Studio Build Tools
    3. Use conda instead (provides pre-compiled packages)
    4. Find alternative package

Example:
    (venv) $ pip install lxml
    error: command 'gcc' failed with exit status 1
    
    Fix (Ubuntu): sudo apt-get install libxml2-dev libxslt1-dev python3-dev
"""

"""
ERROR 5: "WARNING: Retrying (...) after connection broken"
-----------------------------------------------------------
Causes:
    - Network issues
    - Firewall blocking PyPI
    - PyPI temporarily down
    - Proxy configuration needed

Solutions:
    1. Check internet connection
    2. Try again (might be temporary)
    3. Configure proxy if behind corporate firewall
    4. Use --trusted-host if necessary (HTTP)
    5. Check firewall/antivirus settings

Example:
    (venv) $ pip install requests
    WARNING: Retrying (Retry(total=4, connect=None, read=None, redirect=None, status=None))
    
    Fix: Check network, wait, try again
"""

"""
ERROR 6: "Conflicting dependencies"
------------------------------------
Newer pip versions detect dependency conflicts.

Causes:
    - Package A requires package C version 1.x
    - Package B requires package C version 2.x
    - Can't satisfy both requirements

Solutions:
    1. Check if newer versions resolve conflict
    2. Use different package versions
    3. Separate environments for conflicting packages
    4. Find alternative packages

Example:
    (venv) $ pip install package_a package_b
    ERROR: Cannot install package_a and package_b because these package versions have conflicting dependencies.
    
    Fix: Create separate venvs for each package
"""


# ============================================================================
# SECTION 8: BEST PRACTICES
# ============================================================================

"""
BEST PRACTICE 1: Always Use Virtual Environments
-------------------------------------------------
Never pip install to system Python.
Always work in activated virtual environments.

Benefits:
    - No permission issues
    - No version conflicts
    - Easy to recreate
    - Safe experimentation
"""

"""
BEST PRACTICE 2: Pin Versions in Production
--------------------------------------------
Development: pip install requests (latest)
Production: pip install requests==2.31.0 (pinned)

Why pin versions?
    - Reproducibility
    - Stability
    - Predictable deployments
    - Easier rollbacks

Use: pip freeze > requirements.txt
"""

"""
BEST PRACTICE 3: Upgrade Regularly (But Carefully)
---------------------------------------------------
Don't let packages get too outdated.
But always test after upgrading!

Process:
    1. Check outdated: pip list --outdated
    2. Review changelogs
    3. Upgrade in dev environment first
    4. Test thoroughly
    5. Update requirements.txt
    6. Deploy to production
"""

"""
BEST PRACTICE 4: Use Requirements Files
----------------------------------------
Don't ask teammates to "pip install X, Y, and Z"
Provide requirements.txt instead.

Benefits:
    - One command to install everything
    - Documents all dependencies
    - Ensures version consistency
    - Easy CI/CD integration

Create: pip freeze > requirements.txt
Install: pip install -r requirements.txt
"""

"""
BEST PRACTICE 5: Keep pip Updated
----------------------------------
Update pip regularly for bug fixes and new features.

Command: pip install --upgrade pip

In new venvs:
    python -m venv venv
    source venv/bin/activate
    pip install --upgrade pip  # First thing!
"""

"""
BEST PRACTICE 6: Check Package Security
----------------------------------------
Regularly scan for known vulnerabilities.

Tools:
    - safety: pip install safety; safety check
    - pip-audit: pip install pip-audit; pip-audit

Example:
    (venv) $ pip install safety
    (venv) $ safety check
    
    +==============================================================================+
    |                                                                              |
    |                               /$$$$$$            /$$                         |
    |                              /$$__  $$          | $$                         |
    |           /$$$$$$$  /$$$$$$ | $$  \\__//$$$$$$  /$$$$$$   /$$   /$$          |
    |          /$$_____/ |____  $$| $$$$   /$$__  $$|_  $$_/  | $$  | $$          |
    |         |  $$$$$$   /$$$$$$| $$_/  | $$$$$$$$  | $$    | $$  | $$          |
    |          \\____  $$ /$$__  $$| $$    | $$_____/  | $$ /$$| $$  | $$          |
    |          /$$$$$$$/|  $$$$$$$| $$    |  $$$$$$$  |  $$$$/|  $$$$$$$          |
    |         |_______/  \\_______/|__/     \\_______/   \\___/   \\____  $$          |
    |                                                          /$$  | $$          |
    |                                                         |  $$$$$$/          |
    |  by pyup.io                                              \\______/           |
    |                                                                              |
    +==============================================================================+
    
     REPORT 
      
      All good! No vulnerabilities found.
"""


# ============================================================================
# SECTION 9: QUICK REFERENCE
# ============================================================================

"""
ESSENTIAL PIP COMMANDS:

Install:
    pip install package_name
    pip install package_name==1.2.3
    pip install "package_name>=1.2.3"
    pip install -r requirements.txt

Upgrade:
    pip install --upgrade package_name
    pip install --upgrade pip

Uninstall:
    pip uninstall package_name
    pip uninstall -y package_name  (no confirmation)

List:
    pip list                    (all packages)
    pip list --outdated         (packages with updates)
    pip freeze                  (requirements format)
    pip freeze > requirements.txt

Show:
    pip show package_name       (detailed info)

Help:
    pip help
    pip help install
    pip help command_name
"""


# ============================================================================
# SECTION 10: HANDS-ON EXERCISES
# ============================================================================

"""
EXERCISE 1: Basic Installation
-------------------------------
1. Create and activate a new venv
2. Install the 'requests' package
3. Verify installation: python -c "import requests; print(requests.__version__)"
4. List all installed packages
5. Show details of requests package

EXERCISE 2: Version Management
-------------------------------
1. Install specific version: pip install requests==2.28.0
2. Check version: pip show requests
3. Upgrade to latest: pip install --upgrade requests
4. Check new version
5. Downgrade back: pip install requests==2.28.0

EXERCISE 3: Requirements File
------------------------------
1. Install several packages: requests, beautifulsoup4, lxml
2. Create requirements.txt: pip freeze > requirements.txt
3. View the file: cat requirements.txt
4. Create new venv
5. Install from requirements: pip install -r requirements.txt
6. Compare package lists between venvs

EXERCISE 4: Package Information
--------------------------------
1. Install numpy
2. Run: pip show numpy
3. Note the "Requires" field (dependencies)
4. Install pandas
5. Run: pip show pandas
6. Note pandas requires numpy (among others)
7. Try: pip show requests
8. Note its dependencies

EXERCISE 5: Cleanup
--------------------
1. List all installed packages
2. Uninstall requests: pip uninstall requests
3. Try to uninstall its dependencies
4. Observe that pip doesn't auto-remove them
5. Manually uninstall dependencies
"""


# ============================================================================
# SELF-CHECK QUESTIONS
# ============================================================================

"""
1. What command installs the latest version of a package?
   (Answer: pip install package_name)

2. How do you install a specific version?
   (Answer: pip install package_name==version)

3. What's the difference between 'pip list' and 'pip freeze'?
   (Answer: pip list is human-readable; pip freeze is requirements.txt format)

4. How do you upgrade pip itself?
   (Answer: pip install --upgrade pip)

5. What file is standard for sharing project dependencies?
   (Answer: requirements.txt)

6. How do you create a requirements.txt file?
   (Answer: pip freeze > requirements.txt)

7. Does pip uninstall remove dependencies?
   (Answer: No, you must uninstall them separately)

8. Where does pip install packages in a venv?
   (Answer: venv/lib/pythonX.Y/site-packages/)

9. What does 'pip show package_name' display?
   (Answer: Detailed package metadata and dependencies)

10. Should you ever use sudo with pip?
    (Answer: No! Use virtual environments instead)
"""


# ============================================================================
# CONCLUSION
# ============================================================================

"""
You now know how to:
✓ Install packages with pip
✓ Specify version constraints
✓ Upgrade and uninstall packages
✓ View installed packages and details
✓ Create and use requirements.txt files
✓ Troubleshoot common pip errors
✓ Follow pip best practices

Next, you'll learn about requirements.txt files in depth, including
different formats and advanced dependency management.

Move on to: 04_requirements_files.py
"""

# ============================================================================
# END OF FILE
# ============================================================================
