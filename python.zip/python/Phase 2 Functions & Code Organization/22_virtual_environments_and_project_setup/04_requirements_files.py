"""
VIRTUAL ENVIRONMENTS & PACKAGE MANAGEMENT - LESSON 4
====================================================
Topic: Requirements Files and Dependency Management
Level: Intermediate
Prerequisites: Lessons 1-3

LEARNING OBJECTIVES:
- Create and maintain requirements.txt files
- Understand different requirements file formats
- Pin dependencies vs flexible constraints
- Handle development vs production dependencies
- Use requirements files for reproducible environments
- Manage transitive dependencies

Requirements files are the cornerstone of Python dependency management.
"""

import os
import subprocess
import sys

# ============================================================================
# SECTION 1: INTRODUCTION TO REQUIREMENTS FILES
# ============================================================================

"""
WHAT IS A REQUIREMENTS FILE?
=============================

A requirements file lists all packages your project needs.
Think of it as a "shopping list" for pip.

Standard name: requirements.txt
Standard location: Project root directory

Purpose:
--------
1. Document project dependencies
2. Enable reproducible installations
3. Share environment setup with team
4. Facilitate deployment
5. Version control dependency versions

Basic format:
-------------
package_name==version
another_package==version
third_package==version

Example requirements.txt:
-------------------------
requests==2.31.0
beautifulsoup4==4.12.2
lxml==4.9.3
pandas==2.1.4
numpy==1.26.2
"""

# ============================================================================
# SECTION 2: CREATING REQUIREMENTS FILES
# ============================================================================

"""
METHOD 1: AUTOMATIC GENERATION (MOST COMMON)
---------------------------------------------
Command: pip freeze > requirements.txt

What it does:
- Lists all installed packages
- Includes exact versions (pinned)
- Includes ALL packages (even dependencies)
- Outputs in package==version format

Example workflow:
    (venv) $ pip install requests pandas
    (venv) $ pip freeze > requirements.txt
    (venv) $ cat requirements.txt
    
    certifi==2023.11.17
    charset-normalizer==3.3.2
    idna==3.6
    numpy==1.26.2
    pandas==2.1.4
    python-dateutil==2.8.2
    pytz==2023.3.post1
    requests==2.31.0
    six==1.16.0
    tzdata==2023.3
    urllib3==2.1.0

Note: requests and pandas plus ALL their dependencies are listed!
"""

"""
METHOD 2: MANUAL CREATION
--------------------------
Create requirements.txt manually with a text editor.

When to use:
- Starting a new project
- Only listing direct dependencies
- More control over versions

Example (minimal requirements.txt):
    requests>=2.31.0
    pandas>=2.1.0
    beautifulsoup4>=4.12.0

Advantages:
- Only lists what YOU explicitly need
- Can use version ranges
- More readable and maintainable
- Separates direct from transitive dependencies

Disadvantages:
- Less reproducible (versions can change)
- Requires manual updates
- Dependency resolution happens at install time
"""

# Programmatic example: Generate requirements file
def generate_requirements_file(output_path="requirements.txt"):
    """
    Generate requirements.txt file using pip freeze.
    
    Parameters:
    -----------
    output_path : str
        Path where requirements.txt will be saved
    
    Educational Note:
    ----------------
    This demonstrates how to automate requirements file creation.
    Useful for CI/CD pipelines and deployment scripts.
    """
    try:
        # Run pip freeze
        result = subprocess.run(
            [sys.executable, '-m', 'pip', 'freeze'],
            capture_output=True,
            text=True,
            check=True
        )
        
        # Write to file
        with open(output_path, 'w') as f:
            f.write(result.stdout)
        
        print(f"✓ Requirements file created: {output_path}")
        print(f"  Total packages: {len(result.stdout.strip().split('\n'))}")
        
        return True
    
    except subprocess.CalledProcessError as e:
        print(f"Error running pip freeze: {e}")
        return False
    except IOError as e:
        print(f"Error writing file: {e}")
        return False


# ============================================================================
# SECTION 3: VERSION SPECIFIERS
# ============================================================================

"""
PINNED VERSIONS (EXACT)
------------------------
Format: package==version

Example:
    requests==2.31.0

Use when:
- Production deployments
- Reproducibility is critical
- After testing specific versions

Advantages:
- Guarantees exact versions
- Completely reproducible
- No surprises

Disadvantages:
- No automatic security updates
- May miss bug fixes
- Requires manual version bumps
"""

"""
MINIMUM VERSIONS
----------------
Format: package>=version

Example:
    requests>=2.31.0

Use when:
- Development
- Want latest features and bug fixes
- Trust package maintainers

Allows: 2.31.0, 2.31.1, 2.32.0, 3.0.0, etc.

Advantages:
- Gets security updates
- Gets bug fixes
- Less maintenance

Disadvantages:
- May introduce breaking changes
- Less reproducible
- Requires testing
"""

"""
VERSION RANGES
--------------
Format: package>=min_version,<max_version

Examples:
    requests>=2.31.0,<3.0.0    # Any 2.x version
    pandas>=2.0.0,<2.2.0       # 2.0.x and 2.1.x only
    numpy>=1.20,<2.0           # Any 1.x version from 1.20+

Use when:
- Known compatible range
- Want updates within range
- Avoid major version changes

Advantages:
- Gets minor updates
- Avoids breaking changes
- Balanced approach

Disadvantages:
- Needs version knowledge
- Still some uncertainty
"""

"""
COMPATIBLE RELEASES (~=)
-------------------------
Format: package~=version

Example:
    requests~=2.31.0    # Equivalent to >=2.31.0,<2.32.0
    pandas~=2.1         # Equivalent to >=2.1,<3.0

"Tilde equals" means:
- Updates to rightmost version component OK
- Next significant version NOT OK

Examples:
    ~=2.31.0  allows: 2.31.0, 2.31.1, 2.31.2, ...
              blocks: 2.32.0, 3.0.0, ...
    
    ~=2.31    allows: 2.31, 2.32, 2.33, ...
              blocks: 3.0, ...

Use when:
- Want patch updates only
- Following SemVer packages
- Conservative updates
"""

"""
WILDCARD VERSION
----------------
Format: package==version.*

Example:
    requests==2.31.*    # Any 2.31.x version

Allows: 2.31.0, 2.31.1, 2.31.2, ...
Blocks: 2.32.0, 3.0.0, ...

Similar to ~= but more explicit.
"""

"""
COMPLEX CONSTRAINTS
--------------------
Combine multiple specifiers with commas.

Examples:
    # Want 2.x but not 2.29.0 (had a bug)
    requests>=2.31.0,<3.0.0,!=2.29.0
    
    # Want recent but not cutting edge
    pandas>=2.0.0,<2.2.0
    
    # Want fixes but avoid major version
    numpy>=1.20,<2.0,!=1.24.0

Rules:
- Comma-separated = AND logic
- All constraints must be satisfied
- Most specific wins
"""

# Example: Parse version specifiers
def parse_requirement(requirement_line):
    """
    Parse a requirement line and explain its version constraints.
    
    Parameters:
    -----------
    requirement_line : str
        A line from requirements.txt
    
    Returns:
    --------
    dict : Parsed information about the requirement
    
    Educational Note:
    ----------------
    Understanding how to parse requirements helps debug dependency issues.
    """
    line = requirement_line.strip()
    
    if not line or line.startswith('#'):
        return None
    
    # Simple parsing (real pip uses more complex parsing)
    import re
    
    # Pattern: package_name[operators]version
    pattern = r'^([a-zA-Z0-9_-]+)(.*)$'
    match = re.match(pattern, line)
    
    if not match:
        return {'error': 'Could not parse requirement'}
    
    package_name = match.group(1)
    specifiers = match.group(2).strip()
    
    result = {
        'package': package_name,
        'specifiers': specifiers,
        'is_pinned': '==' in specifiers and ',' not in specifiers,
        'is_flexible': '>=' in specifiers or '~=' in specifiers,
        'has_upper_bound': '<' in specifiers,
    }
    
    return result


def analyze_requirements_file(filepath):
    """
    Analyze a requirements file and provide insights.
    """
    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        return
    
    print(f"Analyzing: {filepath}")
    print("=" * 60)
    
    with open(filepath, 'r') as f:
        lines = f.readlines()
    
    pinned = []
    flexible = []
    ranged = []
    
    for line in lines:
        req = parse_requirement(line)
        if req and 'package' in req:
            if req['is_pinned']:
                pinned.append(req['package'])
            elif req['has_upper_bound']:
                ranged.append(req['package'])
            elif req['is_flexible']:
                flexible.append(req['package'])
    
    print(f"\nTotal requirements: {len(pinned) + len(flexible) + len(ranged)}")
    print(f"  Pinned versions (==): {len(pinned)}")
    print(f"  Flexible versions (>=): {len(flexible)}")
    print(f"  Ranged versions: {len(ranged)}")
    
    if pinned:
        print(f"\nPinned packages: {', '.join(pinned[:5])}")
        if len(pinned) > 5:
            print(f"  ... and {len(pinned) - 5} more")


# ============================================================================
# SECTION 4: ORGANIZING DEPENDENCIES
# ============================================================================

"""
SPLITTING REQUIREMENTS BY PURPOSE
----------------------------------

Many projects use multiple requirements files:

requirements/
├── base.txt          ← Core dependencies (always needed)
├── development.txt   ← Dev tools (testing, linting)
├── production.txt    ← Production-only (monitoring, etc.)
└── testing.txt       ← Testing-only (pytest, etc.)

Or simpler:
    requirements.txt      ← Production
    requirements-dev.txt  ← Development extras
"""

"""
EXAMPLE: base.txt (Core Dependencies)
--------------------------------------
# Core application dependencies
django==4.2.7
djangorestframework==3.14.0
psycopg2-binary==2.9.9
celery==5.3.4
redis==5.0.1

# These are needed for the application to run in ANY environment
"""

"""
EXAMPLE: development.txt (Dev Tools)
-------------------------------------
# Include base requirements
-r base.txt

# Development and debugging tools
django-debug-toolbar==4.2.0
ipython==8.18.1
django-extensions==3.2.3

# Code quality
black==23.12.0
flake8==6.1.0
mypy==1.7.1
isort==5.13.2

# Testing
pytest==7.4.3
pytest-django==4.7.0
pytest-cov==4.1.0
factory-boy==3.3.0

# Documentation
sphinx==7.2.6
"""

"""
EXAMPLE: production.txt (Production Extras)
--------------------------------------------
# Include base requirements
-r base.txt

# Production-specific
gunicorn==21.2.0
sentry-sdk==1.39.1
whitenoise==6.6.0

# No development tools in production!
# Smaller attack surface, faster deployment
"""

"""
INCLUDING OTHER REQUIREMENTS FILES
-----------------------------------
Syntax: -r filename.txt

Example development.txt:
    -r base.txt              # Include base dependencies
    pytest==7.4.3
    black==23.12.0
    
Installation:
    (venv) $ pip install -r requirements/development.txt
    
    This installs:
    1. Everything from base.txt
    2. pytest and black
"""

# ============================================================================
# SECTION 5: CONSTRAINTS FILES
# ============================================================================

"""
WHAT ARE CONSTRAINTS FILES?
----------------------------

Constraints files specify version constraints without requiring installation.
They limit what versions can be installed but don't trigger installation.

File: constraints.txt
Format: Same as requirements.txt

Example constraints.txt:
    numpy<2.0
    pandas>=2.0,<2.2
    requests==2.31.0

Usage:
    pip install -c constraints.txt package_name

Difference from requirements.txt:
- requirements.txt: "Install these packages"
- constraints.txt: "When installing, obey these constraints"
"""

"""
USE CASE: MONOREPO WITH MULTIPLE SERVICES
------------------------------------------

constraints.txt (shared across all services):
    # Company-wide package version constraints
    django>=4.2,<5.0
    requests==2.31.0
    numpy<2.0
    
service_a/requirements.txt:
    django
    requests
    # Versions come from constraints.txt

service_b/requirements.txt:
    django
    numpy
    pandas
    # Versions come from constraints.txt

Installation:
    (venv) $ pip install -r service_a/requirements.txt -c constraints.txt

Benefits:
- Ensures version consistency across services
- Central version management
- Each service only lists what it needs
- Constraints apply to transitive dependencies too
"""

# ============================================================================
# SECTION 6: MANAGING TRANSITIVE DEPENDENCIES
# ============================================================================

"""
TRANSITIVE DEPENDENCIES
------------------------

Direct dependency: Package YOU explicitly install
Transitive dependency: Package installed automatically because another package needs it

Example:
    You install: requests
    pip also installs: certifi, charset-normalizer, idna, urllib3
    
    requests = direct dependency
    certifi, etc. = transitive dependencies

PROBLEM:
--------
pip freeze includes ALL packages (direct + transitive)
This makes requirements.txt harder to maintain.

Example pip freeze output:
    certifi==2023.11.17          ← Transitive
    charset-normalizer==3.3.2    ← Transitive
    idna==3.6                    ← Transitive
    requests==2.31.0             ← Direct
    urllib3==2.1.0               ← Transitive

Problem: If you update requests, you might not need to change certifi version,
         but with pinned versions you must manually manage it.
"""

"""
SOLUTION 1: TWO-FILE APPROACH
------------------------------

requirements.in (direct dependencies only):
    requests>=2.31.0
    beautifulsoup4>=4.12.0
    pandas>=2.1.0

requirements.txt (generated, all dependencies):
    beautifulsoup4==4.12.2
    certifi==2023.11.17
    charset-normalizer==3.3.2
    idna==3.6
    lxml==4.9.3
    numpy==1.26.2
    pandas==2.1.4
    python-dateutil==2.8.2
    pytz==2023.3.post1
    requests==2.31.0
    six==1.16.0
    soupsieve==2.5
    tzdata==2023.3
    urllib3==2.1.0

Workflow:
1. Edit requirements.in (human-maintained)
2. Generate requirements.txt (tool-generated)
3. Commit both files

Benefits:
- Clear separation of direct vs transitive
- Easy to see what YOU depend on
- Full reproducibility from .txt
- Update management easier
"""

"""
SOLUTION 2: USE PIP-TOOLS
--------------------------
pip-tools is a package that helps manage requirements files.

Installation:
    (venv) $ pip install pip-tools

Usage:
    # Create requirements.in with your direct dependencies
    # Then compile it:
    (venv) $ pip-compile requirements.in
    
    # This generates requirements.txt with all dependencies pinned
    
    # To install:
    (venv) $ pip-sync requirements.txt
    
    # To upgrade:
    (venv) $ pip-compile --upgrade requirements.in

Benefits:
- Automatic transitive dependency resolution
- Reproducible builds
- Easy updates
- Clear dependency tree

We'll explore pip-tools more in advanced lessons.
"""

# ============================================================================
# SECTION 7: COMMENTS AND DOCUMENTATION
# ============================================================================

"""
ADDING COMMENTS
---------------
Use # for comments in requirements files.

Example:
    # Web framework and API
    django==4.2.7
    djangorestframework==3.14.0
    
    # Database
    psycopg2-binary==2.9.9
    
    # Async task queue
    celery==5.3.4
    redis==5.0.1  # Celery broker
    
    # Data processing
    pandas>=2.1.0  # Need 2.1+ for new features
    numpy<2.0      # Version 2.0 breaks our code

Comments help:
- Explain why specific versions
- Group related packages
- Document known issues
- Provide context for teammates
"""

"""
INLINE ANNOTATIONS
------------------
pip supports environment markers and extras.

Examples:
    pytest>=7.4.0 ; python_version >= '3.8'
    pywin32>=305 ; platform_system == 'Windows'
    black[jupyter]>=23.0.0

Environment markers:
    python_version
    python_full_version
    platform_system
    platform_machine
    platform_python_implementation

Extras:
    package[extra_name]
    
    Example: requests[security,socks]
"""

# ============================================================================
# SECTION 8: UPDATING DEPENDENCIES
# ============================================================================

"""
WORKFLOW FOR UPDATING PACKAGES
-------------------------------

1. CHECK FOR OUTDATED PACKAGES
   (venv) $ pip list --outdated

2. REVIEW CHANGELOGS
   - Visit package GitHub/website
   - Read release notes
   - Check for breaking changes

3. UPDATE IN DEVELOPMENT
   (venv) $ pip install --upgrade package_name

4. TEST THOROUGHLY
   - Run test suite
   - Manual testing
   - Check for deprecation warnings

5. UPDATE REQUIREMENTS FILE
   (venv) $ pip freeze > requirements.txt
   
   Or manually update if using .in file:
   Edit requirements.in with new version
   (venv) $ pip-compile requirements.in

6. COMMIT CHANGES
   git add requirements.txt
   git commit -m "Update package_name to version X.Y.Z"

7. DEPLOY AND MONITOR
   - Deploy to staging
   - Test in staging
   - Deploy to production
   - Monitor for issues
"""

"""
AUTOMATED DEPENDENCY UPDATES
-----------------------------

Tools that can help automate updates:

1. DEPENDABOT (GitHub)
   - Automatic pull requests for updates
   - Configurable update frequency
   - Supports requirements.txt

2. PYUP.IO
   - Monitors requirements files
   - Creates PRs for updates
   - Security vulnerability alerts

3. RENOVATE BOT
   - Similar to Dependabot
   - More configuration options
   - Supports monorepos

Configuration example (.github/dependabot.yml):
    version: 2
    updates:
      - package-ecosystem: "pip"
        directory: "/"
        schedule:
          interval: "weekly"
        open-pull-requests-limit: 10

Benefits:
- Never miss security updates
- Automated PR creation
- CI/CD tests changes automatically
- Easy to review and merge
"""

# ============================================================================
# SECTION 9: BEST PRACTICES
# ============================================================================

"""
BEST PRACTICE 1: SEPARATE DIRECT FROM TRANSITIVE
-------------------------------------------------
Use requirements.in for direct dependencies.
Generate requirements.txt for full environment.

Why:
- Clarity: Easy to see what you depend on
- Maintenance: Easier to update versions
- Documentation: Clear project dependencies
"""

"""
BEST PRACTICE 2: PIN VERSIONS IN PRODUCTION
--------------------------------------------
Production requirements.txt should have exact versions (==).

Why:
- Reproducibility: Same result every time
- Stability: No surprise updates
- Reliability: Tested versions only

Development can be more flexible (>=).
"""

"""
BEST PRACTICE 3: DOCUMENT WHY NOT JUST WHAT
--------------------------------------------
Add comments explaining version constraints.

Good:
    numpy==1.24.0  # Version 1.25+ breaks our linear algebra code
    
Bad:
    numpy==1.24.0  # No explanation

Why:
- Future you will thank you
- Teammates understand decisions
- Easier to decide when to upgrade
"""

"""
BEST PRACTICE 4: REGULAR UPDATES
---------------------------------
Update dependencies regularly, don't let them rot.

Schedule:
- Check monthly for updates
- Update non-critical packages quarterly
- Security updates immediately
- Major version updates: plan carefully

Why:
- Security patches
- Bug fixes
- Avoid massive update debt
- Easier small updates than giant leaps
"""

"""
BEST PRACTICE 5: TEST AFTER UPDATES
------------------------------------
Always run tests after updating dependencies.

Checklist:
✓ Unit tests pass
✓ Integration tests pass
✓ Manual testing of key features
✓ Check for deprecation warnings
✓ Performance hasn't degraded

Don't assume backwards compatibility!
"""

"""
BEST PRACTICE 6: VERSION CONTROL
---------------------------------
Always commit requirements files to version control.

What to commit:
- requirements.txt (or base.txt, etc.)
- requirements.in (if using)
- constraints.txt (if using)

What NOT to commit:
- venv/ directory
- __pycache__/ directories
- .pyc files

Use .gitignore:
    venv/
    env/
    *.pyc
    __pycache__/
"""

# ============================================================================
# SECTION 10: TROUBLESHOOTING
# ============================================================================

"""
ISSUE 1: "Could not find a version that satisfies the requirement"
-------------------------------------------------------------------
Cause: Conflicting version constraints

Example:
    package_a requires numpy>=1.20,<2.0
    package_b requires numpy>=2.0

Solution:
    1. Check if newer versions resolve conflict
    2. Use different package versions
    3. Contact package maintainers
    4. Consider alternative packages
"""

"""
ISSUE 2: Requirements file install fails midway
------------------------------------------------
Cause: Package installation fails, leaves partial state

Solution:
    (venv) $ pip install --no-cache-dir -r requirements.txt
    
    If still fails:
    1. Install problematic package separately
    2. Check system dependencies (compilers, headers)
    3. Try installing packages one by one
"""

"""
ISSUE 3: Different results on different machines
-------------------------------------------------
Cause: Unpinned versions, different Python versions, platform differences

Solution:
    1. Use exact version pins (==)
    2. Document Python version requirement
    3. Use constraints file
    4. Test on multiple platforms
"""

"""
ISSUE 4: Requirements file is huge and hard to maintain
--------------------------------------------------------
Cause: Using pip freeze with many installed packages

Solution:
    1. Use requirements.in for direct dependencies
    2. Use pip-tools to manage transitive deps
    3. Split into multiple files by purpose
    4. Regular cleanup of unused packages
"""

# ============================================================================
# QUICK REFERENCE
# ============================================================================

"""
CREATING REQUIREMENTS FILES:
    pip freeze > requirements.txt

INSTALLING FROM REQUIREMENTS:
    pip install -r requirements.txt

VERSION SPECIFIERS:
    package==1.2.3      # Exact version
    package>=1.2.3      # Minimum version
    package>=1.2,<2.0   # Version range
    package~=1.2.3      # Compatible release
    package==1.2.*      # Wildcard

INCLUDING OTHER FILES:
    -r base.txt         # Include another requirements file

USING CONSTRAINTS:
    pip install -c constraints.txt package

CHECKING OUTDATED:
    pip list --outdated

UPDATING:
    pip install --upgrade -r requirements.txt
"""

# ============================================================================
# CONCLUSION
# ============================================================================

"""
You now know how to:
✓ Create and maintain requirements files
✓ Use version specifiers effectively
✓ Organize dependencies by purpose
✓ Handle transitive dependencies
✓ Update dependencies safely
✓ Follow best practices for reproducible environments

Next, you'll learn about managing multiple virtual environments
and conda basics.

Move on to: 05_environment_management.py
"""
