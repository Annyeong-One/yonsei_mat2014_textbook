"""
VIRTUAL ENVIRONMENTS & PACKAGE MANAGEMENT - LESSON 5
====================================================
Topic: Managing Multiple Virtual Environments
Level: Intermediate
Prerequisites: Lessons 1-4

LEARNING OBJECTIVES:
- Manage multiple virtual environments efficiently
- Understand when to create new environments vs reuse existing
- Switch between environments effectively
- Handle environment naming and organization
- Clean up and maintain environments
- Use environment management tools and helpers

Multiple projects require multiple environments.
This lesson teaches effective multi-environment management.
"""

import os
import sys
import shutil
import subprocess
from pathlib import Path

# ============================================================================
# SECTION 1: WHY MULTIPLE ENVIRONMENTS?
# ============================================================================

"""
REASONS FOR MULTIPLE ENVIRONMENTS
==================================

1. DIFFERENT PROJECTS
   Project A: Django 4.2, PostgreSQL
   Project B: Flask 3.0, MySQL
   → Need separate environments

2. PYTHON VERSION TESTING
   Test library with:
   - Python 3.8
   - Python 3.9
   - Python 3.10
   - Python 3.11
   → Need environment for each Python version

3. DIFFERENT DEPENDENCY SETS
   Production: Minimal dependencies
   Development: Includes testing, linting tools
   Documentation: Includes Sphinx, themes
   → Need environment for each purpose

4. EXPERIMENTAL/LEARNING
   Stable environment: Known working configuration
   Experiment environment: Testing new packages
   → Keep experiments isolated

5. CLIENT/PROJECT SEPARATION
   Client A project: Specific versions
   Client B project: Different versions
   → Prevent version conflicts
"""

# ============================================================================
# SECTION 2: ENVIRONMENT ORGANIZATION STRATEGIES
# ============================================================================

"""
STRATEGY 1: ONE ENVIRONMENT PER PROJECT (MOST COMMON)
------------------------------------------------------
Each project directory contains its own venv.

Structure:
    ~/projects/
    ├── web_app/
    │   ├── venv/          ← Dedicated environment
    │   ├── src/
    │   └── requirements.txt
    ├── data_analysis/
    │   ├── venv/          ← Different environment
    │   ├── notebooks/
    │   └── requirements.txt
    └── api_client/
        ├── venv/          ← Yet another environment
        ├── client/
        └── requirements.txt

Pros:
- Clear separation
- Easy to delete project + environment
- Standard practice
- Works with most IDEs

Cons:
- Some disk space duplication
- Each project needs separate activation
"""

"""
STRATEGY 2: CENTRALIZED ENVIRONMENT DIRECTORY
----------------------------------------------
All environments in one location, separate from projects.

Structure:
    ~/envs/                   ← All environments here
    ├── web_app_env/
    ├── data_analysis_env/
    └── api_client_env/
    
    ~/projects/               ← Project code here
    ├── web_app/
    ├── data_analysis/
    └── api_client/

Pros:
- Clean project directories
- Easy to list all environments
- Can share environments between projects

Cons:
- Must remember environment names
- Less obvious which env belongs to which project
- Need to document env-project mapping
"""

"""
STRATEGY 3: NAMED ENVIRONMENTS WITH VIRTUALENVWRAPPER
------------------------------------------------------
Use virtualenvwrapper to manage named environments.

Installation:
    pip install virtualenvwrapper
    
    # Add to ~/.bashrc or ~/.zshrc:
    export WORKON_HOME=$HOME/.virtualenvs
    export PROJECT_HOME=$HOME/projects
    source /usr/local/bin/virtualenvwrapper.sh

Usage:
    mkvirtualenv web_app      # Create environment
    workon web_app            # Activate environment
    deactivate                # Deactivate
    rmvirtualenv web_app      # Remove environment
    lsvirtualenv              # List all environments

Pros:
- Easy environment switching
- Consistent environment location
- Convenient commands
- Project-environment linking

Cons:
- Extra dependency
- Learning curve
- Platform-specific setup
"""

"""
STRATEGY 4: DOCKER CONTAINERS
------------------------------
Ultimate isolation: Each project in its own container.

Dockerfile example:
    FROM python:3.11
    WORKDIR /app
    COPY requirements.txt .
    RUN pip install -r requirements.txt
    COPY . .
    CMD ["python", "app.py"]

Pros:
- Complete environment isolation
- Includes system dependencies
- Easy deployment
- Reproducible across machines

Cons:
- Overhead (disk space, memory)
- Complexity
- Requires Docker knowledge
- Slower iteration during development
"""

# ============================================================================
# SECTION 3: ENVIRONMENT NAMING CONVENTIONS
# ============================================================================

"""
GOOD NAMING CONVENTIONS
========================

DESCRIPTIVE NAMES:
    project_name_env
    project_name_venv
    .venv (hidden)

EXAMPLES:
    django_blog_venv
    ml_research_env
    api_client_venv

PYTHON VERSION INDICATORS:
    project_py38
    project_py311
    web_app_py39

PURPOSE INDICATORS:
    project_dev
    project_prod
    project_test

BAD NAMING:
    venv1, venv2, venv3 (meaningless)
    test (too generic)
    env (too generic)
    python (confusing)
"""

"""
RECOMMENDED: STANDARDIZE WITHIN TEAM
-------------------------------------

Team convention examples:

Option 1: Always use 'venv'
    Every project has venv/ directory
    
    Pros: Consistent, easy to .gitignore
    Cons: Can't have multiple envs per project

Option 2: Project-based naming
    {project_name}_env or {project_name}_venv
    
    Pros: Clear ownership
    Cons: Longer names

Option 3: Hidden directory
    .venv (starts with dot)
    
    Pros: Hidden from ls, clean appearance
    Cons: Must use ls -a to see

Choose one and stick with it across all projects!
"""

# ============================================================================
# SECTION 4: MANAGING MULTIPLE ENVIRONMENTS
# ============================================================================

# Utility function: List virtual environments
def find_virtual_environments(search_path="."):
    """
    Find all virtual environments in a directory tree.
    
    Parameters:
    -----------
    search_path : str
        Directory to search (defaults to current directory)
    
    Returns:
    --------
    list : Paths to virtual environment directories
    
    Educational Note:
    ----------------
    This demonstrates how to programmatically locate venvs.
    Useful for cleanup scripts and environment management tools.
    """
    venv_paths = []
    search_path = Path(search_path)
    
    # Common venv directory names
    venv_names = {'venv', 'env', '.venv', 'virtualenv'}
    
    # Indicators that a directory is a venv
    venv_indicators = {'pyvenv.cfg', 'bin/activate', 'Scripts/activate.bat'}
    
    # Walk directory tree
    for dirpath in search_path.rglob('*/'):
        # Check if directory name suggests it's a venv
        if dirpath.name in venv_names:
            # Verify it's actually a venv by checking for indicators
            is_venv = any(
                (dirpath / indicator).exists() 
                for indicator in venv_indicators
            )
            if is_venv:
                venv_paths.append(str(dirpath))
    
    return venv_paths


def display_environments(search_path="."):
    """
    Display information about virtual environments.
    """
    envs = find_virtual_environments(search_path)
    
    if not envs:
        print(f"No virtual environments found in {search_path}")
        return
    
    print(f"Virtual Environments Found: {len(envs)}")
    print("=" * 60)
    
    for env_path in envs:
        path = Path(env_path)
        
        # Get parent directory (project directory)
        project_dir = path.parent
        
        # Try to read pyvenv.cfg
        cfg_path = path / 'pyvenv.cfg'
        python_version = "Unknown"
        if cfg_path.exists():
            with open(cfg_path, 'r') as f:
                for line in f:
                    if 'version' in line.lower():
                        python_version = line.split('=')[1].strip()
                        break
        
        # Calculate size
        try:
            size = sum(
                f.stat().st_size 
                for f in path.rglob('*') 
                if f.is_file()
            )
            size_mb = size / (1024 * 1024)
        except:
            size_mb = 0
        
        print(f"\nProject: {project_dir.name}")
        print(f"  Environment: {env_path}")
        print(f"  Python version: {python_version}")
        print(f"  Size: {size_mb:.1f} MB")


"""
SWITCHING BETWEEN ENVIRONMENTS
-------------------------------

MANUAL METHOD:
    # Deactivate current environment (if any)
    (old_env) $ deactivate
    
    # Navigate to new project
    $ cd ~/projects/new_project
    
    # Activate new environment
    $ source venv/bin/activate
    (venv) $

VIRTUALENVWRAPPER METHOD:
    # Switch in one command (from anywhere)
    (old_env) $ workon new_project_env
    (new_project_env) $

IDE METHOD (VS Code, PyCharm):
    - IDE tracks per-project interpreters
    - Automatically activates correct environment
    - No manual switching needed
"""

# ============================================================================
# SECTION 5: CLEANING UP ENVIRONMENTS
# ============================================================================

"""
WHY CLEAN UP?
-------------
- Virtual environments can be large (100-500 MB each)
- Old projects accumulate unused environments
- Disk space management
- Reduce clutter

WHAT TO DELETE:
- Environments for abandoned projects
- Experimental/test environments
- Duplicate environments
- Corrupted environments

WHAT TO KEEP:
- Active project environments
- Environments with unique configurations
- Production environment backups
"""

"""
SAFE DELETION WORKFLOW:
-----------------------

1. VERIFY IT'S SAFE TO DELETE
   - Check if project is still active
   - Ensure you have requirements.txt
   - Confirm no unique configurations

2. DEACTIVATE IF ACTIVE
   (venv) $ deactivate

3. DELETE THE DIRECTORY
   Unix-like:
   $ rm -rf venv/
   
   Windows:
   > rmdir /s venv

4. RECREATE IF NEEDED LATER
   $ python -m venv venv
   $ source venv/bin/activate
   (venv) $ pip install -r requirements.txt

CANNOT BE UNDONE!
- Deleted venv is gone forever
- But can be recreated from requirements.txt
- This is why requirements.txt is crucial
"""

def clean_environment(env_path, dry_run=True):
    """
    Clean up a virtual environment directory.
    
    Parameters:
    -----------
    env_path : str
        Path to virtual environment
    dry_run : bool
        If True, only show what would be deleted
    
    Educational Note:
    ----------------
    Always verify before deletion!
    This function demonstrates safe cleanup practices.
    """
    path = Path(env_path)
    
    if not path.exists():
        print(f"Environment not found: {env_path}")
        return False
    
    # Verify it's actually a venv
    pyvenv_cfg = path / 'pyvenv.cfg'
    if not pyvenv_cfg.exists():
        print(f"Not a valid virtual environment: {env_path}")
        return False
    
    # Calculate size
    try:
        size = sum(
            f.stat().st_size 
            for f in path.rglob('*') 
            if f.is_file()
        )
        size_mb = size / (1024 * 1024)
    except Exception as e:
        print(f"Error calculating size: {e}")
        size_mb = 0
    
    print(f"Environment: {env_path}")
    print(f"Size: {size_mb:.1f} MB")
    
    if dry_run:
        print("DRY RUN: Would delete this environment")
        print("Call with dry_run=False to actually delete")
        return False
    else:
        try:
            shutil.rmtree(path)
            print(f"✓ Deleted successfully")
            return True
        except Exception as e:
            print(f"Error deleting: {e}")
            return False


def bulk_cleanup_environments(search_path=".", size_threshold_mb=100, dry_run=True):
    """
    Find and optionally delete large/old virtual environments.
    
    Parameters:
    -----------
    search_path : str
        Directory to search
    size_threshold_mb : float
        Only consider environments larger than this
    dry_run : bool
        If True, only show what would be deleted
    """
    envs = find_virtual_environments(search_path)
    
    print(f"Scanning for environments larger than {size_threshold_mb} MB...")
    print("=" * 60)
    
    candidates = []
    
    for env_path in envs:
        path = Path(env_path)
        
        # Calculate size
        try:
            size = sum(
                f.stat().st_size 
                for f in path.rglob('*') 
                if f.is_file()
            )
            size_mb = size / (1024 * 1024)
        except:
            continue
        
        if size_mb >= size_threshold_mb:
            candidates.append((env_path, size_mb))
    
    if not candidates:
        print(f"No environments larger than {size_threshold_mb} MB found")
        return
    
    print(f"Found {len(candidates)} environment(s) to clean:")
    for env_path, size_mb in candidates:
        print(f"  {env_path}: {size_mb:.1f} MB")
    
    if dry_run:
        print("\nDRY RUN: No changes made")
        print("Call with dry_run=False to actually delete")
    else:
        print("\nDeleting...")
        for env_path, size_mb in candidates:
            clean_environment(env_path, dry_run=False)


# ============================================================================
# SECTION 6: ENVIRONMENT DUPLICATION AND CLONING
# ============================================================================

"""
CLONING AN ENVIRONMENT
-----------------------

You cannot simply copy a venv directory!
Virtual environments contain absolute paths that break when moved.

CORRECT METHOD - Recreate from requirements.txt:

1. Export from source environment:
   (source_venv) $ pip freeze > requirements.txt

2. Create new environment:
   $ python -m venv new_venv

3. Activate and install:
   $ source new_venv/bin/activate
   (new_venv) $ pip install -r requirements.txt

RESULT: New environment with same packages
"""

"""
COPYING ENVIRONMENT TO ANOTHER MACHINE
---------------------------------------

WRONG WAY:
    $ scp -r venv/ user@remote:/path/  # DON'T DO THIS!

RIGHT WAY:
    # On source machine
    (venv) $ pip freeze > requirements.txt
    $ scp requirements.txt user@remote:/path/
    
    # On remote machine
    $ python -m venv venv
    $ source venv/bin/activate
    (venv) $ pip install -r requirements.txt

WHY:
- Virtual environments are not portable
- Contain absolute paths
- May have platform-specific binaries
- requirements.txt is portable and reproducible
"""

# ============================================================================
# SECTION 7: ENVIRONMENT INSPECTION AND DEBUGGING
# ============================================================================

def inspect_environment(env_path):
    """
    Inspect a virtual environment and show detailed information.
    
    This is useful for debugging environment issues.
    """
    path = Path(env_path)
    
    if not path.exists():
        print(f"Environment not found: {env_path}")
        return
    
    print(f"Inspecting Environment: {env_path}")
    print("=" * 60)
    
    # Read pyvenv.cfg
    cfg_path = path / 'pyvenv.cfg'
    if cfg_path.exists():
        print("\nConfiguration (pyvenv.cfg):")
        with open(cfg_path, 'r') as f:
            for line in f:
                print(f"  {line.rstrip()}")
    
    # Find Python executable
    if sys.platform == 'win32':
        python_exe = path / 'Scripts' / 'python.exe'
    else:
        python_exe = path / 'bin' / 'python'
    
    if python_exe.exists():
        print(f"\nPython executable: {python_exe}")
        
        # Get Python version
        try:
            result = subprocess.run(
                [str(python_exe), '--version'],
                capture_output=True,
                text=True
            )
            print(f"  Version: {result.stdout.strip()}")
        except:
            pass
    
    # Count installed packages
    if sys.platform == 'win32':
        site_packages = path / 'Lib' / 'site-packages'
    else:
        # Find site-packages (version-specific)
        lib_dir = path / 'lib'
        if lib_dir.exists():
            python_dirs = list(lib_dir.glob('python*'))
            if python_dirs:
                site_packages = python_dirs[0] / 'site-packages'
            else:
                site_packages = None
        else:
            site_packages = None
    
    if site_packages and site_packages.exists():
        # Count .dist-info directories (one per package)
        dist_info_dirs = list(site_packages.glob('*.dist-info'))
        print(f"\nInstalled packages: {len(dist_info_dirs)}")
        
        # Show some examples
        if dist_info_dirs:
            print("  Sample packages:")
            for dist_info in sorted(dist_info_dirs)[:5]:
                package_name = dist_info.name.replace('.dist-info', '')
                print(f"    - {package_name}")
            if len(dist_info_dirs) > 5:
                print(f"    ... and {len(dist_info_dirs) - 5} more")
    
    # Calculate total size
    try:
        size = sum(
            f.stat().st_size 
            for f in path.rglob('*') 
            if f.is_file()
        )
        size_mb = size / (1024 * 1024)
        print(f"\nTotal size: {size_mb:.1f} MB")
    except:
        pass


# ============================================================================
# SECTION 8: BEST PRACTICES
# ============================================================================

"""
BEST PRACTICE 1: ONE ENVIRONMENT PER PROJECT
---------------------------------------------
Don't reuse environments across projects.
Each project gets its own dedicated environment.

Why:
- Prevents dependency conflicts
- Makes cleanup easy (delete project = delete env)
- Clear ownership
- Matches industry standard

Exception: Very similar projects with identical dependencies
           (rare in practice)
"""

"""
BEST PRACTICE 2: ALWAYS HAVE REQUIREMENTS.TXT
----------------------------------------------
Before deleting any environment, ensure requirements.txt exists.

Workflow:
    (venv) $ pip freeze > requirements.txt
    (venv) $ git add requirements.txt
    (venv) $ git commit -m "Update requirements"
    (venv) $ deactivate
    $ rm -rf venv/

Now you can recreate anytime:
    $ python -m venv venv
    $ source venv/bin/activate
    (venv) $ pip install -r requirements.txt
"""

"""
BEST PRACTICE 3: DOCUMENT PYTHON VERSION
-----------------------------------------
Include Python version in documentation.

Example README.md:
    ## Requirements
    
    - Python 3.11+
    - Virtual environment
    
    ## Setup
    
    python3.11 -m venv venv
    source venv/bin/activate
    pip install -r requirements.txt

Why:
- Some packages require specific Python versions
- Prevents compatibility issues
- Helps with debugging
"""

"""
BEST PRACTICE 4: REGULAR CLEANUP
---------------------------------
Schedule environment cleanup.

Monthly checklist:
☐ Review all environments
☐ Delete abandoned project environments
☐ Update active environment dependencies
☐ Check for security vulnerabilities
☐ Archive requirements.txt for closed projects

Use tools to help:
- Scripts to find all venvs
- Size reports
- Last modified dates
"""

"""
BEST PRACTICE 5: USE DESCRIPTIVE NAMES
---------------------------------------
Choose names that indicate purpose.

Good:
    project_name_dev
    project_name_prod
    project_name_py311

Bad:
    venv1
    test
    temp
    old

Future you will thank you!
"""

# ============================================================================
# QUICK REFERENCE
# ============================================================================

"""
CREATE ENVIRONMENT:
    python -m venv project_venv

ACTIVATE:
    source project_venv/bin/activate  (Unix-like)
    project_venv\Scripts\activate     (Windows)

DEACTIVATE:
    deactivate

DELETE ENVIRONMENT:
    rm -rf project_venv/  (Unix-like)
    rmdir /s project_venv (Windows)

CLONE ENVIRONMENT:
    pip freeze > requirements.txt
    python -m venv new_venv
    source new_venv/bin/activate
    pip install -r requirements.txt

LIST ENVIRONMENTS:
    # Custom script or manual search
    find ~ -name "pyvenv.cfg" 2>/dev/null

SWITCH ENVIRONMENTS:
    deactivate
    cd other_project/
    source venv/bin/activate
"""

# ============================================================================
# CONCLUSION
# ============================================================================

"""
You now know how to:
✓ Manage multiple virtual environments
✓ Organize environments effectively
✓ Switch between environments
✓ Clean up old environments
✓ Clone and recreate environments
✓ Inspect and debug environments
✓ Follow best practices for environment management

Next, you'll learn about Conda, an alternative to venv
that's popular in data science and scientific computing.

Move on to: 06_conda_basics.py
"""
