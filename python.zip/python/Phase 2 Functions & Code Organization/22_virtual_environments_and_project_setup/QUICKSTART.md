# Quick Start Guide

## For Students

1. Start with `README.md` for full course overview
2. Read tutorial files in order (01, 02, 03...)
3. Complete corresponding exercises
4. Check solutions only after attempting
5. Experiment with variations

## For Instructors

This package is designed for classroom use:
- Each file is self-contained
- Progressive difficulty
- Real-world examples
- Extensive comments
- Exercise files with solutions

### Suggested Schedule

- Week 1: Lessons 1-3 (Beginner)
- Week 2: Lessons 4-5 (Intermediate pt 1)
- Week 3: Lessons 6-7 (Intermediate pt 2)  
- Week 4: Lessons 8-10 (Advanced)
- Week 5: Final project

## Setup Requirements

```bash
# Python 3.8+
python --version

# Optional but recommended
pip install --upgrade pip
```

## First Lesson

Start here: `01_why_virtual_environments.py`
