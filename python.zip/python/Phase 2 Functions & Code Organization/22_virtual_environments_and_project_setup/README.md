# Virtual Environments & Package Management
## Comprehensive Python Tutorial Package for Undergraduate Education

### 📚 Course Overview
This educational package provides a complete guide to Python virtual environments and package management, essential skills for professional Python development. Students will learn how to isolate project dependencies, manage packages effectively, and follow industry best practices.

### 🎯 Learning Objectives
By the end of this module, students will be able to:
- Understand the importance of virtual environments in Python development
- Create, activate, and manage virtual environments using venv and conda
- Install, update, and remove packages using pip
- Work with requirements.txt files for reproducible environments
- Use modern package management tools (Poetry, pipenv)
- Implement best practices for project dependency management
- Troubleshoot common environment and package issues

### 📖 Course Structure

#### **Beginner Level (1-3)**
1. **01_why_virtual_environments.py** - Understanding the problem and solution
2. **02_basic_venv_usage.py** - Creating and using virtual environments
3. **03_pip_basics.py** - Installing and managing packages

#### **Intermediate Level (4-7)**
4. **04_requirements_files.py** - Working with requirements.txt
5. **05_environment_management.py** - Managing multiple environments
6. **06_conda_basics.py** - Introduction to Conda
7. **07_package_versions.py** - Version management and compatibility

#### **Advanced Level (8-10)**
8. **08_poetry_modern_tools.py** - Modern dependency management
9. **09_environment_variables.py** - Configuration and secrets management
10. **10_package_distribution.py** - Creating and distributing packages

#### **Exercise Files**
- **exercises_beginner.py** - Practice problems for concepts 1-3
- **exercises_intermediate.py** - Practice problems for concepts 4-7
- **exercises_advanced.py** - Practice problems for concepts 8-10
- **solutions_beginner.py** - Detailed solutions with explanations
- **solutions_intermediate.py** - Detailed solutions with explanations
- **solutions_advanced.py** - Detailed solutions with explanations

### 🚀 Getting Started

#### Prerequisites
- Python 3.8 or higher installed
- Basic understanding of Python syntax
- Command line/terminal familiarity
- Text editor or IDE (VS Code, PyCharm recommended)

#### Recommended Study Path
1. Read through each numbered file sequentially
2. Run the examples in your own terminal
3. Complete the corresponding exercises
4. Check solutions only after attempting exercises
5. Experiment with variations of the examples

### 💡 Teaching Tips

#### For Instructors:
- Each file is self-contained with extensive comments
- Code examples are designed to be copy-pasted and executed
- Common pitfalls are highlighted with warning comments
- Platform-specific differences (Windows/Mac/Linux) are noted
- Real-world scenarios demonstrate practical applications

#### For Students:
- Don't just read - type and execute each example
- Experiment by modifying the code
- Pay attention to error messages and learn from them
- Use the exercises to test your understanding
- Refer back to earlier files when needed

### 📋 Key Concepts Covered

#### Virtual Environments
- Why isolation matters
- System Python vs. virtual environment Python
- Environment activation/deactivation
- Environment location and structure

#### Package Management
- pip installation and usage
- requirements.txt format
- Package versions and constraints
- Dependency resolution
- Package conflicts

#### Modern Tools
- Poetry for dependency management
- Conda for scientific computing
- pipenv for combined environments and packages
- pyenv for Python version management

#### Best Practices
- One environment per project
- Always use virtual environments
- Pin dependencies in production
- Document environment setup
- Version control considerations

### 🔧 System Requirements

#### Minimum Requirements:
- Python 3.8+
- 100 MB free disk space per environment
- Internet connection for package downloads

#### Recommended Setup:
- Python 3.10 or higher
- pip 21.0 or higher
- Virtual environment tools (venv, conda)
- Git for version control

### 📚 Additional Resources

#### Official Documentation:
- Python venv: https://docs.python.org/3/library/venv.html
- pip: https://pip.pypa.io/en/stable/
- Conda: https://docs.conda.io/
- Poetry: https://python-poetry.org/docs/

#### Recommended Reading:
- Python Packaging User Guide: https://packaging.python.org/
- The Hitchhiker's Guide to Python (Packaging section)
- Real Python's Virtual Environments Tutorial

### ❓ Common Issues and Solutions

#### Issue: "pip not found" after activation
**Solution:** Ensure virtual environment is activated; check PATH

#### Issue: "Permission denied" when installing packages
**Solution:** Use virtual environment; never use sudo with pip

#### Issue: Different behavior between development and production
**Solution:** Use requirements.txt with pinned versions

#### Issue: Package conflicts
**Solution:** Create separate environments for conflicting requirements

### 🎓 Assessment Ideas

#### Knowledge Checks:
- Explain why virtual environments are necessary
- Describe the difference between pip and conda
- List steps to reproduce an environment

#### Practical Exercises:
- Set up a project with dependencies
- Migrate a project to use Poetry
- Debug a package conflict
- Create a requirements.txt from existing environment

#### Project Ideas:
- Build a web scraper with managed dependencies
- Create a data analysis project with conda
- Package a small library for PyPI
- Set up a multi-environment project structure

### 📞 Support and Feedback
This educational package is designed for classroom use. Instructors should feel free to modify examples and exercises to match their curriculum needs.

### 📄 License and Usage
This educational material is designed for academic use. Feel free to adapt and modify for your teaching needs.

---

**Version:** 1.0  
**Last Updated:** 2025  
**Target Audience:** Undergraduate Computer Science Students  
**Estimated Completion Time:** 8-10 hours of study and practice
