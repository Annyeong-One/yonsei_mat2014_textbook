"""
BEGINNER LEVEL EXERCISES
========================
Virtual Environments & Package Management

These exercises cover Lessons 1-3:
- Why virtual environments
- Basic venv usage
- pip basics

Instructions:
-------------
1. Read each exercise carefully
2. Try to solve without looking at solutions
3. Test your solution
4. Compare with solutions file
5. Understand WHY your solution works or doesn't

Each exercise has:
- Clear problem statement
- Expected outcome
- Hints (use if stuck)
- Difficulty rating (1-5 stars)
"""

# ============================================================================
# EXERCISE 1: Create Your First Virtual Environment
# Difficulty: ★☆☆☆☆
# ============================================================================

"""
TASK:
Create a virtual environment named 'my_first_venv' in your home directory.
Verify it was created correctly by checking for the pyvenv.cfg file.

STEPS:
1. Navigate to your home directory
2. Create a virtual environment
3. List the contents of the venv directory
4. Find and read the pyvenv.cfg file

EXPECTED OUTCOME:
- Directory my_first_venv/ exists
- Contains bin/ (or Scripts/ on Windows)
- Contains pyvenv.cfg file
- pyvenv.cfg shows Python version

HINT:
Use 'python -m venv my_first_venv'
"""

# Your solution here:


# ============================================================================
# EXERCISE 2: Activation Practice
# Difficulty: ★★☆☆☆
# ============================================================================

"""
TASK:
Create a Python script that checks if it's running inside a virtual environment.
The script should print "Inside venv" or "Not in venv".

REQUIREMENTS:
- Create check_venv.py
- Script uses sys.prefix and sys.base_prefix
- Test both inside and outside a venv
- Add explanatory comments

EXPECTED OUTCOME:
- Running outside venv: prints "Not in venv"
- Running inside venv: prints "Inside venv"

HINT:
Compare sys.prefix with sys.base_prefix
They're different when in a venv
"""

# Your solution here:


# ============================================================================
# EXERCISE 3: Package Installation
# Difficulty: ★★☆☆☆
# ============================================================================

"""
TASK:
1. Create a new virtual environment called 'exercise3_env'
2. Activate it
3. Install the 'requests' package
4. Write a Python script that imports requests and prints its version
5. Verify requests is installed to the venv, not system-wide

VERIFICATION CHECKLIST:
☐ venv created
☐ venv activated (check prompt or $VIRTUAL_ENV)
☐ requests installed
☐ Script runs and prints version
☐ 'which pip' or 'where pip' shows venv pip

EXPECTED OUTPUT:
requests version: 2.31.0 (or similar)
"""

# Your solution here:


# ============================================================================
# EXERCISE 4: Requirements File Creation
# Difficulty: ★★★☆☆
# ============================================================================

"""
TASK:
Create a virtual environment and install these packages:
- requests
- beautifulsoup4
- pandas

Then create a requirements.txt file that someone else could use
to recreate your exact environment.

REQUIREMENTS:
1. All packages installed successfully
2. requirements.txt contains exact versions
3. File includes all dependencies (not just top-level packages)
4. Test by creating a NEW venv and installing from the file

VERIFICATION:
Create second venv, run 'pip install -r requirements.txt',
both environments should have identical packages (pip list).

CHALLENGE:
What's the total number of packages installed (including dependencies)?
"""

# Your solution here:


# ============================================================================
# EXERCISE 5: Environment Cleanup
# Difficulty: ★★★☆☆
# ============================================================================

"""
TASK:
You've created several test environments. Clean them up properly.

REQUIREMENTS:
1. List all virtual environments in your home directory
2. For each one, save its requirements.txt first
3. Deactivate if any are active
4. Delete the environment directories
5. Verify they're gone

SAFETY CHECKLIST:
☐ Requirements saved before deletion
☐ Currently not in any of these venvs
☐ Double-checked the paths
☐ Have backup if anything goes wrong

BONUS:
Write a Python script that finds all venvs in a directory
(Look for pyvenv.cfg files)
"""

# Your solution here:


# ============================================================================
# EXERCISE 6: Debugging Environment Issues
# Difficulty: ★★★★☆
# ============================================================================

"""
SCENARIO:
You install a package but Python can't import it.

DEBUGGING STEPS:
1. Create venv called 'debug_env'
2. Do NOT activate it
3. Install requests to system (or other venv)
4. Try to run this from debug_env's Python:
   ./debug_env/bin/python -c "import requests; print(requests.__version__)"
5. Explain why it fails
6. Fix it properly

LEARNING OBJECTIVES:
- Understand activation importance
- Know where packages are installed
- Verify environment configuration
- Troubleshoot import errors

QUESTIONS TO ANSWER:
1. Why did the import fail?
2. Where was requests actually installed?
3. Where does debug_env's Python look for packages?
4. How do you fix it?
"""

# Your solution here:


# ============================================================================
# EXERCISE 7: Cross-Project Requirements
# Difficulty: ★★★★☆
# ============================================================================

"""
SCENARIO:
You have two projects that need different versions of the same package.

PROJECT A:
- Needs requests 2.28.0
- Legacy code depends on old API

PROJECT B:
- Needs requests 2.31.0
- Uses new features

TASK:
1. Set up both projects with separate venvs
2. Install correct versions in each
3. Create script that verifies each version
4. Document the setup process
5. Explain why this would be impossible without venvs

DELIVERABLES:
- Two directories with two venvs
- requirements.txt for each
- README explaining setup
- Test script confirming correct versions
"""

# Your solution here:


# ============================================================================
# EXERCISE 8: Package Installation Methods
# Difficulty: ★★★☆☆
# ============================================================================

"""
TASK:
Demonstrate understanding of different pip install methods.

REQUIREMENTS:
Create commands and explain when to use each:

1. pip install package_name
2. pip install package_name==1.2.3
3. pip install "package_name>=1.2.0,<2.0.0"
4. pip install package_name --upgrade
5. pip install -r requirements.txt

For each, provide:
- Example command
- Use case
- Advantages
- Disadvantages

WRITE YOUR EXPLANATION:
Include real-world scenarios for each method.
"""

# Your explanations here:


# ============================================================================
# CHALLENGE EXERCISE: Environment Detective
# Difficulty: ★★★★★
# ============================================================================

"""
ADVANCED CHALLENGE:
Write a Python script that analyzes a system and generates a report on:
1. All virtual environments found
2. Python version in each
3. Number of packages installed
4. Disk space used
5. Which environments might be old/unused
6. Recommendations for cleanup

BONUS FEATURES:
- Detect duplicate packages across venvs
- Find largest packages
- Check for security vulnerabilities (if you can)
- Generate environment dependency graphs

This is a real-world tool that professional developers use!
"""

# Your solution here:


# ============================================================================
# SELF-ASSESSMENT CHECKLIST
# ============================================================================

"""
Before moving to intermediate exercises, ensure you can:

☐ Create virtual environments reliably
☐ Activate and deactivate environments
☐ Understand when you are/aren't in a venv
☐ Install packages with pip
☐ Create and use requirements.txt
☐ Understand why venvs are necessary
☐ Troubleshoot common activation issues
☐ Know where packages are installed
☐ Clean up old environments safely
☐ Help a teammate set up their environment

If you can't check all boxes, review the relevant lessons!
"""

print("Beginner exercises loaded. Good luck!")
