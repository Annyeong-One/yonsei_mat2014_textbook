"""
01_introduction_to_testing.py

INTRODUCTION TO SOFTWARE TESTING
==================================

This module introduces fundamental concepts of software testing in Python.
Students will learn why testing is essential and how to write basic tests.

Learning Objectives:
- Understand the importance of software testing
- Learn what makes a good test
- Write basic assertion-based tests
- Understand the testing pyramid concept

Target: Beginner Level - Week 1
Prerequisites: Basic Python functions and conditionals
"""


# ============================================================================
# PART 1: WHY TESTING MATTERS
# ============================================================================

"""
Testing is the practice of verifying that your code works as expected.
Without tests, you're essentially hoping your code works.

BENEFITS OF TESTING:
1. Catch bugs early (before users find them)
2. Document how code should behave
3. Enable safe refactoring
4. Improve code design
5. Save time in the long run
6. Build confidence in your code
"""


# Example: Code without testing
def calculate_discount(price, discount_percent):
    """
    Calculate the final price after applying a discount.
    
    Args:
        price: Original price
        discount_percent: Discount percentage (0-100)
    
    Returns:
        Final price after discount
    """
    # BUG: This will fail if discount_percent > 100 or < 0
    # Without tests, this bug might reach production!
    discount_amount = price * (discount_percent / 100)
    return price - discount_amount


# Let's manually test this function
print("=== Manual Testing (Not Ideal) ===")
print(f"$100 with 10% discount: ${calculate_discount(100, 10)}")
print(f"$50 with 20% discount: ${calculate_discount(50, 20)}")
# What about edge cases? We might forget to test them!


# ============================================================================
# PART 2: WHAT MAKES A GOOD TEST
# ============================================================================

"""
GOOD TESTS ARE:
- Fast: Run quickly so you can run them often
- Independent: Don't depend on other tests or external state
- Repeatable: Always produce the same result with same input
- Self-validating: Clearly pass or fail (no manual inspection)
- Timely: Written at the right time (ideally before or with code)

ACRONYM: F.I.R.S.T.
"""


# ============================================================================
# PART 3: BASIC TESTING WITH ASSERTIONS
# ============================================================================

"""
The assert statement is Python's most basic testing tool.
Syntax: assert condition, "optional error message"

If condition is True: nothing happens (test passes)
If condition is False: raises AssertionError (test fails)
"""


def add(a, b):
    """
    Add two numbers together.
    
    Args:
        a: First number
        b: Second number
    
    Returns:
        Sum of a and b
    """
    return a + b


# Simple assertion test
def test_add():
    """Test that add function correctly adds two numbers."""
    # Test with positive numbers
    result = add(2, 3)
    assert result == 5, f"Expected 5, but got {result}"
    
    # Test with negative numbers
    result = add(-1, -1)
    assert result == -2, f"Expected -2, but got {result}"
    
    # Test with zero
    result = add(5, 0)
    assert result == 5, f"Expected 5, but got {result}"
    
    print("✓ All add tests passed!")


# Run the test
test_add()


# ============================================================================
# PART 4: TESTING DIFFERENT TYPES OF BEHAVIOR
# ============================================================================

def is_even(number):
    """
    Check if a number is even.
    
    Args:
        number: Integer to check
    
    Returns:
        True if number is even, False otherwise
    """
    return number % 2 == 0


def test_is_even():
    """Test that is_even correctly identifies even and odd numbers."""
    # Test even numbers (should return True)
    assert is_even(2) == True, "2 should be even"
    assert is_even(0) == True, "0 should be even"
    assert is_even(100) == True, "100 should be even"
    assert is_even(-4) == True, "-4 should be even"
    
    # Test odd numbers (should return False)
    assert is_even(1) == False, "1 should be odd"
    assert is_even(3) == False, "3 should be odd"
    assert is_even(-7) == False, "-7 should be odd"
    
    print("✓ All is_even tests passed!")


# Run the test
test_is_even()


# ============================================================================
# PART 5: TESTING EDGE CASES
# ============================================================================

"""
EDGE CASES are inputs at the extremes of acceptable values:
- Empty inputs (empty string, empty list, zero)
- Boundary values (min/max values)
- Special values (None, negative numbers)
- Invalid inputs

Testing edge cases helps find bugs that normal inputs might miss.
"""


def get_first_element(items):
    """
    Get the first element from a list.
    
    Args:
        items: List of items
    
    Returns:
        First element of the list
    
    Raises:
        ValueError: If list is empty
    """
    if not items:  # Edge case: empty list
        raise ValueError("Cannot get first element of empty list")
    return items[0]


def test_get_first_element():
    """Test get_first_element with normal and edge cases."""
    # Normal case: list with multiple elements
    assert get_first_element([1, 2, 3]) == 1
    
    # Edge case: list with single element
    assert get_first_element([42]) == 42
    
    # Edge case: list with different types
    assert get_first_element(["apple", "banana"]) == "apple"
    
    # Edge case: empty list should raise ValueError
    try:
        get_first_element([])
        assert False, "Should have raised ValueError for empty list"
    except ValueError as e:
        # This is expected behavior
        assert str(e) == "Cannot get first element of empty list"
    
    print("✓ All get_first_element tests passed!")


# Run the test
test_get_first_element()


# ============================================================================
# PART 6: THE TESTING PYRAMID
# ============================================================================

"""
THE TESTING PYRAMID shows the ideal distribution of different test types:

                    /\
                   /  \      ← Few: End-to-End Tests (Slow, Brittle)
                  /____\
                 /      \    ← Some: Integration Tests (Medium Speed)
                /________\
               /          \  ← Many: Unit Tests (Fast, Focused)
              /__________\

UNIT TESTS (Bottom/Most):
- Test individual functions or methods in isolation
- Fast to run (milliseconds)
- Easy to write and maintain
- Most of your tests should be unit tests

INTEGRATION TESTS (Middle):
- Test how multiple components work together
- Slower than unit tests
- Test interactions between modules

END-TO-END TESTS (Top/Fewest):
- Test the entire application from user's perspective
- Slowest to run
- Most brittle (break easily)
- Hardest to maintain

This module focuses on UNIT TESTING.
"""


# ============================================================================
# PART 7: ARRANGE-ACT-ASSERT PATTERN
# ============================================================================

"""
A common pattern for organizing test code:

1. ARRANGE: Set up test data and preconditions
2. ACT: Execute the code being tested
3. ASSERT: Verify the result is correct

This pattern makes tests easy to read and understand.
"""


def calculate_area(length, width):
    """
    Calculate the area of a rectangle.
    
    Args:
        length: Length of rectangle
        width: Width of rectangle
    
    Returns:
        Area of rectangle
    """
    return length * width


def test_calculate_area():
    """Test calculate_area using Arrange-Act-Assert pattern."""
    # ARRANGE: Set up test data
    length = 5
    width = 3
    expected_area = 15
    
    # ACT: Execute the function being tested
    actual_area = calculate_area(length, width)
    
    # ASSERT: Verify the result
    assert actual_area == expected_area, \
        f"Expected area {expected_area}, but got {actual_area}"
    
    print("✓ calculate_area test passed!")


# Run the test
test_calculate_area()


# ============================================================================
# PART 8: NAMING CONVENTIONS
# ============================================================================

"""
GOOD TEST NAMING:
- Use descriptive names that explain what is being tested
- Common patterns:
  * test_<function_name>()
  * test_<function_name>_<scenario>()
  * test_<function_name>_<scenario>_<expected_result>()

EXAMPLES:
- test_add()                              # Basic
- test_add_positive_numbers()             # Better
- test_add_positive_numbers_returns_sum() # Most descriptive
"""


def divide(a, b):
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


# Good test names describe the scenario and expected behavior
def test_divide_positive_numbers_returns_quotient():
    """Test that dividing positive numbers returns correct quotient."""
    assert divide(10, 2) == 5


def test_divide_by_zero_raises_value_error():
    """Test that dividing by zero raises ValueError."""
    try:
        divide(5, 0)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass  # Expected behavior


# Run tests
test_divide_positive_numbers_returns_quotient()
test_divide_by_zero_raises_value_error()
print("✓ All divide tests passed!")


# ============================================================================
# PART 9: PRACTICAL EXAMPLE - TEMPERATURE CONVERTER
# ============================================================================

def celsius_to_fahrenheit(celsius):
    """
    Convert Celsius to Fahrenheit.
    
    Formula: F = (C × 9/5) + 32
    
    Args:
        celsius: Temperature in Celsius
    
    Returns:
        Temperature in Fahrenheit
    """
    return (celsius * 9/5) + 32


def fahrenheit_to_celsius(fahrenheit):
    """
    Convert Fahrenheit to Celsius.
    
    Formula: C = (F - 32) × 5/9
    
    Args:
        fahrenheit: Temperature in Fahrenheit
    
    Returns:
        Temperature in Celsius
    """
    return (fahrenheit - 32) * 5/9


def test_temperature_conversions():
    """
    Test temperature conversion functions.
    
    This demonstrates testing with known values and edge cases.
    """
    # Test Celsius to Fahrenheit with known values
    assert celsius_to_fahrenheit(0) == 32, "Freezing point of water"
    assert celsius_to_fahrenheit(100) == 212, "Boiling point of water"
    assert celsius_to_fahrenheit(-40) == -40, "C and F intersect at -40"
    
    # Test Fahrenheit to Celsius with known values
    assert fahrenheit_to_celsius(32) == 0, "Freezing point of water"
    assert fahrenheit_to_celsius(212) == 100, "Boiling point of water"
    assert fahrenheit_to_celsius(-40) == -40, "C and F intersect at -40"
    
    # Test round-trip conversion (C → F → C should equal C)
    original_celsius = 25
    converted = celsius_to_fahrenheit(original_celsius)
    back_to_celsius = fahrenheit_to_celsius(converted)
    # Use approximate equality for floating-point comparisons
    assert abs(back_to_celsius - original_celsius) < 0.0001, \
        "Round-trip conversion should preserve value"
    
    print("✓ All temperature conversion tests passed!")


# Run the test
test_temperature_conversions()


# ============================================================================
# PART 10: SUMMARY AND BEST PRACTICES
# ============================================================================

"""
KEY TAKEAWAYS:
1. Testing verifies code correctness and catches bugs early
2. Good tests are Fast, Independent, Repeatable, Self-validating, Timely
3. Use assertions to check expected behavior
4. Test both normal cases and edge cases
5. Follow the Arrange-Act-Assert pattern
6. Use descriptive test names
7. Most tests should be fast unit tests (testing pyramid)

BEST PRACTICES:
- Write tests for all public functions
- Test edge cases and error conditions
- Keep tests simple and focused
- Run tests frequently during development
- Fix failing tests immediately
- Use tests as documentation

COMMON MISTAKES TO AVOID:
- Not testing edge cases
- Writing tests that depend on other tests
- Testing implementation instead of behavior
- Not running tests regularly
- Skipping tests for "simple" code

NEXT STEPS:
- Learn about assert statement in depth (02_assert_statements.py)
- Practice writing your own tests
- Explore testing frameworks (unittest, pytest)
"""


# ============================================================================
# PRACTICE EXERCISES
# ============================================================================

"""
Try writing tests for these functions:

1. Write tests for this function:
   def max_of_three(a, b, c):
       return max(a, max(b, c))

2. Write tests for this function:
   def is_palindrome(text):
       return text == text[::-1]

3. Write tests for this function:
   def count_vowels(text):
       vowels = 'aeiouAEIOU'
       return sum(1 for char in text if char in vowels)

Solutions are in: exercises/01_basic_testing_exercises.py
"""


if __name__ == "__main__":
    print("\n" + "="*60)
    print("INTRODUCTION TO SOFTWARE TESTING - ALL TESTS PASSED!")
    print("="*60)
    print("\nYou've learned:")
    print("✓ Why testing matters")
    print("✓ What makes a good test")
    print("✓ How to write assertion-based tests")
    print("✓ The Arrange-Act-Assert pattern")
    print("✓ Testing edge cases")
    print("✓ The testing pyramid")
    print("\nNext: 02_assert_statements.py")
