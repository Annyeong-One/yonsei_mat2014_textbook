"""
02_assert_statements.py

DEEP DIVE INTO ASSERT STATEMENTS
=================================

This module explores Python's assert statement in depth, covering
all aspects of assertion-based testing and common patterns.

Learning Objectives:
- Master the assert statement syntax
- Understand assertion errors and messages
- Learn assertion best practices
- Handle floating-point comparisons
- Test multiple conditions effectively

Target: Beginner Level - Week 1-2
Prerequisites: 01_introduction_to_testing.py
"""


# ============================================================================
# PART 1: ASSERT STATEMENT BASICS
# ============================================================================

"""
ASSERT SYNTAX:
    assert condition, optional_message

HOW IT WORKS:
1. Python evaluates the condition
2. If True: continues execution (test passes)
3. If False: raises AssertionError with optional message

EXAMPLE:
    assert 2 + 2 == 4, "Math is broken!"
    # Passes, does nothing

    assert 2 + 2 == 5, "Math is broken!"
    # Fails, raises: AssertionError: Math is broken!
"""

# Simple assertions
assert True, "This will never fail"
assert 1 == 1, "One equals one"
assert "hello" == "hello", "Strings match"

print("✓ Basic assertions passed")


# ============================================================================
# PART 2: ASSERTION ERROR MESSAGES
# ============================================================================

"""
Good error messages help debug failing tests quickly.
They should explain:
- What was expected
- What was actually received
- Context about the test
"""


def test_with_good_error_messages():
    """Demonstrate effective error messages in assertions."""
    
    # BAD: No error message
    # assert result == expected
    
    # BETTER: Simple message
    # assert result == expected, "Test failed"
    
    # BEST: Descriptive message with values
    expected = 10
    actual = 10
    assert actual == expected, \
        f"Expected {expected}, but got {actual}"
    
    # EVEN BETTER: Include context
    test_input = [1, 2, 3, 4]
    expected_sum = 10
    actual_sum = sum(test_input)
    assert actual_sum == expected_sum, \
        f"Sum of {test_input} should be {expected_sum}, but got {actual_sum}"
    
    print("✓ Error message tests passed")


test_with_good_error_messages()


# ============================================================================
# PART 3: COMPARISON ASSERTIONS
# ============================================================================

"""
Python supports multiple comparison operators in assertions:
==  Equal to
!=  Not equal to
<   Less than
<=  Less than or equal to
>   Greater than
>=  Greater than or equal to
is  Identity (same object)
is not  Not same object
in  Membership
not in  Not member
"""


def test_comparison_assertions():
    """Test various comparison assertions."""
    
    # Equality
    assert 5 == 5, "Equal values"
    assert "test" == "test", "Equal strings"
    
    # Inequality
    assert 5 != 3, "Not equal"
    assert "hello" != "world", "Different strings"
    
    # Less than / Greater than
    assert 3 < 5, "3 is less than 5"
    assert 10 > 7, "10 is greater than 7"
    assert 5 <= 5, "5 is less than or equal to 5"
    assert 8 >= 8, "8 is greater than or equal to 8"
    
    # Identity (same object in memory)
    a = [1, 2, 3]
    b = a  # b points to same object as a
    c = [1, 2, 3]  # c is a new object with same values
    
    assert a is b, "a and b are the same object"
    assert a is not c, "a and c are different objects"
    assert a == c, "but a and c have equal values"
    
    # Membership
    assert 3 in [1, 2, 3, 4], "3 is in the list"
    assert 5 not in [1, 2, 3, 4], "5 is not in the list"
    assert "apple" in ["apple", "banana"], "apple in list"
    
    print("✓ Comparison assertion tests passed")


test_comparison_assertions()


# ============================================================================
# PART 4: BOOLEAN ASSERTIONS
# ============================================================================

"""
Testing boolean conditions and truthiness:
- assert condition (tests if truthy)
- assert not condition (tests if falsy)

TRUTHY values: True, non-zero numbers, non-empty containers, objects
FALSY values: False, None, 0, empty containers ("", [], {}, ())
"""


def test_boolean_assertions():
    """Test boolean and truthiness assertions."""
    
    # Direct boolean tests
    assert True, "True is truthy"
    assert not False, "False is falsy"
    
    # Truthiness tests
    assert "hello", "Non-empty string is truthy"
    assert not "", "Empty string is falsy"
    
    assert [1, 2, 3], "Non-empty list is truthy"
    assert not [], "Empty list is falsy"
    
    assert {'key': 'value'}, "Non-empty dict is truthy"
    assert not {}, "Empty dict is falsy"
    
    assert 42, "Non-zero number is truthy"
    assert not 0, "Zero is falsy"
    
    # None is falsy
    value = None
    assert not value, "None is falsy"
    assert value is None, "Check for None with 'is'"
    
    # Testing conditions
    x = 10
    assert x > 5, "x is greater than 5"
    assert x % 2 == 0, "x is even"
    
    print("✓ Boolean assertion tests passed")


test_boolean_assertions()


# ============================================================================
# PART 5: MULTIPLE ASSERTIONS IN ONE TEST
# ============================================================================

"""
APPROACHES TO MULTIPLE ASSERTIONS:

1. Multiple separate assert statements (PREFERRED)
   - Clear which assertion failed
   - Easy to understand
   
2. Combined with 'and' (USE SPARINGLY)
   - Less clear which condition failed
   - Stops at first failure

3. Separate test functions (BEST for unrelated checks)
   - Each test has single responsibility
   - Better test organization
"""


def test_multiple_assertions_good():
    """Good approach: Multiple separate assertions."""
    result = [1, 2, 3, 4, 5]
    
    # Each assertion tests one thing clearly
    assert len(result) == 5, "List should have 5 elements"
    assert result[0] == 1, "First element should be 1"
    assert result[-1] == 5, "Last element should be 5"
    assert sum(result) == 15, "Sum should be 15"
    assert 3 in result, "3 should be in list"
    
    print("✓ Multiple assertions test passed")


def test_combined_assertions_caution():
    """Combined assertions - use carefully."""
    x = 10
    
    # This is okay for closely related conditions
    assert x > 0 and x < 100, "x should be between 0 and 100"
    
    # But this is harder to debug when it fails:
    # Which condition failed? Less clear.
    assert x % 2 == 0 and x > 5 and x < 20, \
        "x should be even, greater than 5, and less than 20"
    
    print("✓ Combined assertions test passed")


# Run tests
test_multiple_assertions_good()
test_combined_assertions_caution()


# ============================================================================
# PART 6: FLOATING-POINT COMPARISONS
# ============================================================================

"""
PROBLEM: Floating-point arithmetic is inexact!

Example:
    0.1 + 0.2 == 0.3  # False! (due to binary representation)
    # Actual: 0.30000000000000004

SOLUTION: Use approximate equality with tolerance (epsilon)
"""


def test_floating_point_comparisons():
    """Demonstrate floating-point comparison issues and solutions."""
    
    # WRONG: Direct equality
    # result = 0.1 + 0.2
    # assert result == 0.3  # This fails!
    
    # RIGHT: Approximate equality with tolerance
    result = 0.1 + 0.2
    expected = 0.3
    tolerance = 1e-10  # 0.0000000001
    
    assert abs(result - expected) < tolerance, \
        f"Expected {expected}, got {result}, difference: {abs(result - expected)}"
    
    # Alternative: round to reasonable precision
    assert round(0.1 + 0.2, 10) == round(0.3, 10), \
        "Values equal when rounded to 10 decimal places"
    
    # Testing mathematical operations
    import math
    
    result = math.sqrt(2) ** 2
    expected = 2.0
    assert abs(result - expected) < 1e-10, \
        "sqrt(2)^2 approximately equals 2"
    
    print("✓ Floating-point comparison tests passed")


test_floating_point_comparisons()


# ============================================================================
# PART 7: TESTING CONTAINERS (LISTS, DICTS, SETS)
# ============================================================================

"""
Testing collections requires careful consideration:
- Order matters for lists, not for sets
- Dictionary key-value pairs
- Nested structures
- Empty vs non-empty
"""


def test_list_assertions():
    """Test assertions with lists."""
    my_list = [1, 2, 3, 4, 5]
    
    # Length
    assert len(my_list) == 5, "List should have 5 elements"
    
    # Membership
    assert 3 in my_list, "3 should be in list"
    assert 6 not in my_list, "6 should not be in list"
    
    # Indexing
    assert my_list[0] == 1, "First element should be 1"
    assert my_list[-1] == 5, "Last element should be 5"
    
    # Slicing
    assert my_list[:3] == [1, 2, 3], "First 3 elements"
    assert my_list[2:] == [3, 4, 5], "Elements from index 2 onwards"
    
    # List equality (order matters!)
    assert my_list == [1, 2, 3, 4, 5], "Lists are equal"
    assert my_list != [5, 4, 3, 2, 1], "Order matters for lists"
    
    print("✓ List assertion tests passed")


def test_dict_assertions():
    """Test assertions with dictionaries."""
    my_dict = {'name': 'Alice', 'age': 30, 'city': 'NYC'}
    
    # Length (number of keys)
    assert len(my_dict) == 3, "Dict should have 3 key-value pairs"
    
    # Key membership
    assert 'name' in my_dict, "Dict should have 'name' key"
    assert 'country' not in my_dict, "Dict should not have 'country' key"
    
    # Value access
    assert my_dict['name'] == 'Alice', "Name should be Alice"
    assert my_dict.get('age') == 30, "Age should be 30"
    
    # Dictionary equality (order doesn't matter for keys)
    assert my_dict == {'age': 30, 'name': 'Alice', 'city': 'NYC'}, \
        "Dicts equal regardless of key order"
    
    # Keys and values
    assert set(my_dict.keys()) == {'name', 'age', 'city'}, \
        "Check all keys present"
    assert 'Alice' in my_dict.values(), "Alice in values"
    
    print("✓ Dict assertion tests passed")


def test_set_assertions():
    """Test assertions with sets."""
    my_set = {1, 2, 3, 4, 5}
    
    # Length
    assert len(my_set) == 5, "Set should have 5 elements"
    
    # Membership
    assert 3 in my_set, "3 should be in set"
    assert 6 not in my_set, "6 should not be in set"
    
    # Set equality (order doesn't matter)
    assert my_set == {5, 4, 3, 2, 1}, "Sets equal regardless of order"
    
    # Subset/Superset
    assert {1, 2, 3}.issubset(my_set), "{1,2,3} is subset"
    assert my_set.issuperset({1, 2}), "my_set is superset of {1,2}"
    
    # Set operations
    other_set = {4, 5, 6, 7}
    assert my_set.intersection(other_set) == {4, 5}, "Intersection correct"
    assert my_set.union(other_set) == {1, 2, 3, 4, 5, 6, 7}, "Union correct"
    
    print("✓ Set assertion tests passed")


# Run container tests
test_list_assertions()
test_dict_assertions()
test_set_assertions()


# ============================================================================
# PART 8: TESTING STRINGS
# ============================================================================

"""
String testing often involves:
- Exact equality
- Substring matching
- Case sensitivity
- Whitespace handling
- Regular expressions (advanced)
"""


def test_string_assertions():
    """Test assertions with strings."""
    text = "Hello, World!"
    
    # Exact equality
    assert text == "Hello, World!", "Exact match"
    
    # Case sensitivity
    assert text != "hello, world!", "Strings are case-sensitive"
    assert text.lower() == "hello, world!", "Case-insensitive comparison"
    
    # Substring checks
    assert "Hello" in text, "Substring 'Hello' present"
    assert "Goodbye" not in text, "Substring 'Goodbye' not present"
    
    # String methods
    assert text.startswith("Hello"), "Starts with 'Hello'"
    assert text.endswith("!"), "Ends with '!'"
    
    # Length
    assert len(text) == 13, "String has 13 characters"
    
    # Whitespace
    text_with_spaces = "  hello  "
    assert text_with_spaces.strip() == "hello", "Strip whitespace"
    assert text_with_spaces != "hello", "Original has spaces"
    
    # Empty string
    empty = ""
    assert len(empty) == 0, "Empty string has length 0"
    assert not empty, "Empty string is falsy"
    
    print("✓ String assertion tests passed")


test_string_assertions()


# ============================================================================
# PART 9: TESTING WITH TYPE CHECKS
# ============================================================================

"""
Sometimes you need to verify the type of a value:
- isinstance() for type checking
- type() for exact type matching
"""


def test_type_assertions():
    """Test type-related assertions."""
    
    # Integer
    value = 42
    assert isinstance(value, int), "Value should be an integer"
    assert type(value) == int, "Exact type is int"
    
    # Float
    value = 3.14
    assert isinstance(value, float), "Value should be a float"
    
    # String
    value = "hello"
    assert isinstance(value, str), "Value should be a string"
    
    # List
    value = [1, 2, 3]
    assert isinstance(value, list), "Value should be a list"
    
    # Multiple types (isinstance with tuple)
    value = 42
    assert isinstance(value, (int, float)), \
        "Value should be either int or float"
    
    # Not a certain type
    value = "42"
    assert not isinstance(value, int), "String is not an int"
    
    # Check for None specifically
    value = None
    assert value is None, "Value should be None"
    assert type(value) == type(None), "Type is NoneType"
    
    print("✓ Type assertion tests passed")


test_type_assertions()


# ============================================================================
# PART 10: PRACTICAL EXAMPLE - VALIDATION FUNCTION
# ============================================================================

def validate_email(email):
    """
    Validate email address format (simplified).
    
    Args:
        email: String to validate
    
    Returns:
        True if valid, False otherwise
    
    Note: This is a simplified validator for teaching purposes.
    Production code should use proper email validation libraries.
    """
    if not email:
        return False
    
    if '@' not in email:
        return False
    
    parts = email.split('@')
    if len(parts) != 2:
        return False
    
    local, domain = parts
    if not local or not domain:
        return False
    
    if '.' not in domain:
        return False
    
    return True


def test_validate_email():
    """Comprehensive test for email validation."""
    
    # Valid emails
    assert validate_email("user@example.com") == True, \
        "Valid email should pass"
    assert validate_email("test.user@domain.co.uk") == True, \
        "Email with dots should pass"
    
    # Invalid emails - missing @
    assert validate_email("userexample.com") == False, \
        "Email without @ should fail"
    
    # Invalid emails - empty
    assert validate_email("") == False, \
        "Empty string should fail"
    
    # Invalid emails - no local part
    assert validate_email("@example.com") == False, \
        "Email without local part should fail"
    
    # Invalid emails - no domain
    assert validate_email("user@") == False, \
        "Email without domain should fail"
    
    # Invalid emails - no TLD
    assert validate_email("user@domain") == False, \
        "Email without TLD should fail"
    
    # Invalid emails - multiple @
    assert validate_email("user@@example.com") == False, \
        "Multiple @ symbols should fail"
    
    print("✓ All email validation tests passed")


test_validate_email()


# ============================================================================
# PART 11: COMMON MISTAKES AND HOW TO AVOID THEM
# ============================================================================

"""
COMMON MISTAKES:

1. USING ASSIGNMENT (=) INSTEAD OF COMPARISON (==)
   Wrong: assert x = 5  # SyntaxError!
   Right: assert x == 5

2. FORGETTING PARENTHESES IN COMPLEX CONDITIONS
   Wrong: assert x > 0 and < 10  # SyntaxError!
   Right: assert x > 0 and x < 10

3. NOT USING ABSOLUTE VALUE FOR FLOATING-POINT
   Wrong: assert 0.1 + 0.2 == 0.3  # Fails!
   Right: assert abs((0.1 + 0.2) - 0.3) < 1e-10

4. ASSERTING WRONG VALUE
   Wrong: assert calculate() == expected  # Did you mean !=?
   Right: Think carefully about what you're testing

5. TOO COMPLEX ASSERTION CONDITIONS
   Wrong: assert x and y or z and not w  # Hard to understand
   Right: Break into multiple clear assertions
"""


# ============================================================================
# PART 12: ASSERTION BEST PRACTICES
# ============================================================================

"""
BEST PRACTICES:

1. ONE LOGICAL ASSERTION PER TEST
   - Each test should verify one specific behavior
   - Makes failures easier to diagnose

2. ALWAYS INCLUDE ERROR MESSAGES
   - Helps debug when tests fail
   - Include expected and actual values

3. TEST BOTH POSITIVE AND NEGATIVE CASES
   - Test what should work (positive)
   - Test what should fail (negative)

4. USE DESCRIPTIVE VARIABLE NAMES
   expected = 10  # Better than e = 10
   actual = calculate()  # Better than r = calculate()

5. KEEP ASSERTIONS SIMPLE
   - Complex logic belongs in functions, not assertions
   - If assertion is hard to read, simplify it

6. TEST EDGE CASES
   - Empty inputs
   - Null/None values
   - Boundary values (min/max)
   - Special characters

7. AVOID TESTING IMPLEMENTATION DETAILS
   - Test behavior, not internal workings
   - Tests should survive refactoring
"""


# ============================================================================
# SUMMARY
# ============================================================================

"""
KEY TAKEAWAYS:

1. assert is Python's basic testing tool
2. Always include descriptive error messages
3. Use appropriate comparison operators
4. Handle floating-point comparisons carefully
5. Test containers considering their properties
6. Check types when necessary
7. Follow assertion best practices

WHEN TO USE ASSERT:
✓ Unit tests
✓ Quick validation during development
✓ Sanity checks in code

WHEN NOT TO USE ASSERT:
✗ Production error handling (use exceptions)
✗ Can be disabled with -O flag (python -O)
✗ User input validation

NEXT STEPS:
- Practice with exercises in exercises/01_basic_testing_exercises.py
- Learn about test organization (03_test_organization.py)
- Explore testing frameworks (unittest, pytest)
"""


if __name__ == "__main__":
    print("\n" + "="*60)
    print("ASSERT STATEMENTS - ALL TESTS PASSED!")
    print("="*60)
    print("\nYou've mastered:")
    print("✓ Assert statement syntax and usage")
    print("✓ Effective error messages")
    print("✓ Comparison assertions")
    print("✓ Boolean and truthiness testing")
    print("✓ Floating-point comparisons")
    print("✓ Container and string testing")
    print("✓ Type checking in tests")
    print("✓ Assertion best practices")
    print("\nNext: 03_test_organization.py")
