"""
03_test_organization.py

TEST ORGANIZATION AND CONVENTIONS
==================================

This module teaches how to organize test code effectively,
including file structure, naming conventions, and test discovery.

Learning Objectives:
- Understand test file organization
- Learn naming conventions for tests
- Organize tests into modules and packages
- Understand test discovery mechanisms
- Follow industry best practices

Target: Beginner Level - Week 2
Prerequisites: 01_introduction_to_testing.py, 02_assert_statements.py
"""


# ============================================================================
# PART 1: FILE AND DIRECTORY STRUCTURE
# ============================================================================

"""
COMMON TEST ORGANIZATION PATTERNS:

1. TESTS IN SEPARATE DIRECTORY (RECOMMENDED)
   project/
   ├── src/
   │   ├── __init__.py
   │   ├── calculator.py
   │   └── utils.py
   └── tests/
       ├── __init__.py
       ├── test_calculator.py
       └── test_utils.py

2. TESTS ALONGSIDE CODE
   project/
   ├── __init__.py
   ├── calculator.py
   ├── test_calculator.py
   ├── utils.py
   └── test_utils.py

3. MIRROR STRUCTURE (BEST FOR LARGE PROJECTS)
   project/
   ├── src/
   │   ├── package1/
   │   │   ├── __init__.py
   │   │   └── module1.py
   │   └── package2/
   │       ├── __init__.py
   │       └── module2.py
   └── tests/
       ├── package1/
       │   ├── __init__.py
       │   └── test_module1.py
       └── package2/
           ├── __init__.py
           └── test_module2.py

ADVANTAGES OF SEPARATE TESTS DIRECTORY:
- Clear separation of concerns
- Easier to exclude tests from distribution
- Better organization for large projects
- Industry standard
"""


# ============================================================================
# PART 2: NAMING CONVENTIONS
# ============================================================================

"""
NAMING CONVENTIONS FOR TESTS:

TEST FILES:
- Prefix with 'test_': test_calculator.py
- OR suffix with '_test': calculator_test.py
- Must be discoverable by test runners

TEST CLASSES (when using OOP):
- Prefix with 'Test': class TestCalculator
- Descriptive of what's being tested

TEST FUNCTIONS:
- Prefix with 'test_': def test_addition()
- Descriptive and specific
- Use snake_case

NAMING PATTERNS:
test_<function>_<scenario>_<expected_result>

Examples:
- test_add_positive_numbers_returns_sum()
- test_divide_by_zero_raises_exception()
- test_empty_list_returns_none()
- test_valid_email_passes_validation()

WHY GOOD NAMES MATTER:
1. Self-documenting - explains what's being tested
2. Easy to find failing tests
3. Helps with test discovery
4. Makes code reviews easier
"""


# Example functions to test
def add(a, b):
    """Add two numbers."""
    return a + b


def divide(a, b):
    """Divide a by b."""
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b


# GOOD TEST NAMES - Clear and specific
def test_add_positive_numbers():
    """Test adding two positive numbers returns correct sum."""
    assert add(2, 3) == 5


def test_add_negative_numbers():
    """Test adding two negative numbers returns correct sum."""
    assert add(-2, -3) == -5


def test_add_zero_returns_same_number():
    """Test adding zero returns the original number."""
    assert add(5, 0) == 5


def test_divide_positive_numbers():
    """Test dividing positive numbers returns correct quotient."""
    assert divide(10, 2) == 5


def test_divide_by_zero_raises_value_error():
    """Test that dividing by zero raises ValueError."""
    try:
        divide(10, 0)
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert str(e) == "Cannot divide by zero"


# Run good tests
test_add_positive_numbers()
test_add_negative_numbers()
test_add_zero_returns_same_number()
test_divide_positive_numbers()
test_divide_by_zero_raises_value_error()
print("✓ Well-named tests passed")


# ============================================================================
# PART 3: GROUPING RELATED TESTS
# ============================================================================

"""
GROUPING STRATEGIES:

1. BY FUNCTION/METHOD (most common)
   - All tests for add() in test_add_*()
   - All tests for divide() in test_divide_*()

2. BY FEATURE
   - All calculator tests in test_calculator.py
   - All validation tests in test_validation.py

3. BY TEST TYPE
   - Unit tests in test_unit/
   - Integration tests in test_integration/
   - End-to-end tests in test_e2e/

4. BY BEHAVIOR
   - All edge case tests together
   - All error handling tests together
"""


# Example: Grouping tests by scenario
class Calculator:
    """Simple calculator for demonstration."""
    
    def add(self, a, b):
        """Add two numbers."""
        return a + b
    
    def subtract(self, a, b):
        """Subtract b from a."""
        return a - b
    
    def multiply(self, a, b):
        """Multiply two numbers."""
        return a * b
    
    def divide(self, a, b):
        """Divide a by b."""
        if b == 0:
            raise ValueError("Cannot divide by zero")
        return a / b


# Group 1: Basic arithmetic operations tests
def test_calculator_addition():
    """Test calculator addition."""
    calc = Calculator()
    assert calc.add(2, 3) == 5
    assert calc.add(-1, 1) == 0
    assert calc.add(0, 0) == 0


def test_calculator_subtraction():
    """Test calculator subtraction."""
    calc = Calculator()
    assert calc.subtract(5, 3) == 2
    assert calc.subtract(0, 5) == -5


def test_calculator_multiplication():
    """Test calculator multiplication."""
    calc = Calculator()
    assert calc.multiply(3, 4) == 12
    assert calc.multiply(-2, 5) == -10
    assert calc.multiply(0, 100) == 0


# Group 2: Edge cases and error handling
def test_calculator_divide_normal_case():
    """Test calculator division with normal inputs."""
    calc = Calculator()
    assert calc.divide(10, 2) == 5
    assert calc.divide(7, 2) == 3.5


def test_calculator_divide_by_zero_error():
    """Test calculator division by zero raises error."""
    calc = Calculator()
    try:
        calc.divide(10, 0)
        assert False, "Should have raised ValueError"
    except ValueError:
        pass  # Expected


# Run calculator tests
test_calculator_addition()
test_calculator_subtraction()
test_calculator_multiplication()
test_calculator_divide_normal_case()
test_calculator_divide_by_zero_error()
print("✓ Grouped calculator tests passed")


# ============================================================================
# PART 4: TEST DISCOVERY
# ============================================================================

"""
TEST DISCOVERY is how test runners find your tests automatically.

UNITTEST DISCOVERY RULES:
- Files named test_*.py or *_test.py
- Classes named Test*
- Methods named test_*
- In directories with __init__.py files

PYTEST DISCOVERY RULES (more flexible):
- Files named test_*.py or *_test.py
- Classes named Test* (no __init__ required)
- Functions named test_*
- No __init__.py required

RUNNING DISCOVERY:
# unittest
python -m unittest discover

# pytest
pytest

# Specific directory
pytest tests/
python -m unittest discover -s tests/

# Specific pattern
pytest tests/test_calc*.py
"""


# ============================================================================
# PART 5: DOCSTRINGS IN TESTS
# ============================================================================

"""
TEST DOCSTRINGS are important for:
1. Explaining what is being tested
2. Documenting expected behavior
3. Helping future maintainers
4. Test reports and documentation

GOOD TEST DOCSTRING:
- Explains what behavior is tested
- States expected result
- Mentions any important context
- Uses clear, concise language
"""


def test_with_good_docstring():
    """
    Test that empty list returns correct length.
    
    The len() function should return 0 for an empty list.
    This is a fundamental property of empty containers.
    """
    my_list = []
    assert len(my_list) == 0


def test_with_basic_docstring():
    """Test empty list has length zero."""
    my_list = []
    assert len(my_list) == 0


# Both are acceptable; second is more concise
test_with_good_docstring()
test_with_basic_docstring()
print("✓ Docstring tests passed")


# ============================================================================
# PART 6: TEST SETUP AND TEARDOWN PATTERNS
# ============================================================================

"""
SETUP AND TEARDOWN are common patterns for:
- Creating test data
- Initializing objects
- Opening files/connections
- Cleaning up after tests

BASIC PATTERN (without frameworks):
"""


class UserDatabase:
    """Simple in-memory user database for demonstration."""
    
    def __init__(self):
        self.users = {}
    
    def add_user(self, username, email):
        """Add a user to the database."""
        if username in self.users:
            raise ValueError(f"User {username} already exists")
        self.users[username] = email
    
    def get_user(self, username):
        """Get a user's email."""
        return self.users.get(username)
    
    def clear(self):
        """Clear all users."""
        self.users.clear()


# Manual setup and teardown pattern
def setup_database():
    """Create and return a fresh database."""
    return UserDatabase()


def test_add_user_stores_correctly():
    """Test that adding a user stores it in the database."""
    # Setup
    db = setup_database()
    
    # Test
    db.add_user("alice", "alice@example.com")
    
    # Verify
    assert db.get_user("alice") == "alice@example.com"
    
    # Teardown (if needed)
    db.clear()


def test_add_duplicate_user_raises_error():
    """Test that adding duplicate user raises ValueError."""
    # Setup
    db = setup_database()
    db.add_user("alice", "alice@example.com")
    
    # Test
    try:
        db.add_user("alice", "alice2@example.com")
        assert False, "Should have raised ValueError"
    except ValueError as e:
        assert "already exists" in str(e)
    
    # Teardown
    db.clear()


# Run database tests
test_add_user_stores_correctly()
test_add_duplicate_user_raises_error()
print("✓ Database tests with setup/teardown passed")


# ============================================================================
# PART 7: ORGANIZING TESTS BY DIFFICULTY/COMPLEXITY
# ============================================================================

"""
ORGANIZING BY COMPLEXITY helps students learn progressively:

BASIC TESTS:
- Simple inputs
- Expected behavior
- Happy path

INTERMEDIATE TESTS:
- Multiple scenarios
- Boundary conditions
- Type variations

ADVANCED TESTS:
- Edge cases
- Error conditions
- Complex interactions
- Performance considerations
"""


def fibonacci(n):
    """
    Calculate the nth Fibonacci number.
    
    Args:
        n: Position in Fibonacci sequence (0-indexed)
    
    Returns:
        The nth Fibonacci number
    
    Raises:
        ValueError: If n is negative
    """
    if n < 0:
        raise ValueError("n must be non-negative")
    if n <= 1:
        return n
    
    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b


# BASIC TEST
def test_fibonacci_basic():
    """Test Fibonacci with simple cases."""
    assert fibonacci(0) == 0
    assert fibonacci(1) == 1
    assert fibonacci(2) == 1


# INTERMEDIATE TEST
def test_fibonacci_intermediate():
    """Test Fibonacci with various positions."""
    assert fibonacci(3) == 2
    assert fibonacci(4) == 3
    assert fibonacci(5) == 5
    assert fibonacci(10) == 55


# ADVANCED TEST
def test_fibonacci_advanced_edge_cases():
    """Test Fibonacci with edge cases and errors."""
    # Large number
    assert fibonacci(20) == 6765
    
    # Error case: negative input
    try:
        fibonacci(-1)
        assert False, "Should raise ValueError for negative input"
    except ValueError as e:
        assert "non-negative" in str(e)


# Run Fibonacci tests
test_fibonacci_basic()
test_fibonacci_intermediate()
test_fibonacci_advanced_edge_cases()
print("✓ Fibonacci tests (all levels) passed")


# ============================================================================
# PART 8: COMMENT CONVENTIONS IN TESTS
# ============================================================================

"""
COMMENTING IN TESTS:

GOOD COMMENTS:
- Explain WHY something is tested
- Document tricky edge cases
- Clarify non-obvious assertions
- Reference bug tickets/requirements

BAD COMMENTS:
- Restate what the code obviously does
- Redundant with test name
- Too verbose

EXAMPLE OF GOOD COMMENTING:
"""


def test_parse_date_handles_february_edge_cases():
    """
    Test date parsing for February edge cases.
    
    February has different lengths in leap vs non-leap years.
    This test ensures we handle both correctly.
    See bug #1234 for context.
    """
    # Non-leap year: Feb 28 is last day
    # result = parse_date("2023-02-28")
    # assert result.is_valid()
    
    # Leap year: Feb 29 is valid
    # result = parse_date("2024-02-29")
    # assert result.is_valid()
    
    # Non-leap year: Feb 29 is invalid
    # result = parse_date("2023-02-29")
    # assert not result.is_valid()
    
    pass  # Placeholder for demonstration


# ============================================================================
# PART 9: BEST PRACTICES SUMMARY
# ============================================================================

"""
TEST ORGANIZATION BEST PRACTICES:

1. FILE STRUCTURE
   ✓ Keep tests in separate directory
   ✓ Mirror source code structure
   ✓ Use __init__.py for packages

2. NAMING
   ✓ Prefix test files with test_
   ✓ Use descriptive function names
   ✓ Follow team conventions consistently

3. GROUPING
   ✓ Group related tests together
   ✓ One test file per module/class
   ✓ Organize by feature or function

4. DOCUMENTATION
   ✓ Write clear docstrings
   ✓ Comment tricky test logic
   ✓ Explain edge cases

5. SETUP/TEARDOWN
   ✓ Extract common setup code
   ✓ Ensure tests are independent
   ✓ Clean up resources

6. DISCOVERABILITY
   ✓ Follow naming conventions
   ✓ Make tests easy to find
   ✓ Use test frameworks properly

7. MAINTAINABILITY
   ✓ Keep tests simple
   ✓ One test, one concept
   ✓ Avoid duplication
"""


# ============================================================================
# PRACTICAL EXAMPLE: WELL-ORGANIZED TEST MODULE
# ============================================================================

class StringProcessor:
    """Process and manipulate strings."""
    
    def reverse(self, text):
        """Reverse a string."""
        return text[::-1]
    
    def to_uppercase(self, text):
        """Convert string to uppercase."""
        return text.upper()
    
    def count_words(self, text):
        """Count words in text."""
        if not text:
            return 0
        return len(text.split())


# Well-organized test suite for StringProcessor
# Group 1: Basic functionality tests
def test_reverse_simple_string():
    """Test reversing a simple string."""
    processor = StringProcessor()
    assert processor.reverse("hello") == "olleh"


def test_to_uppercase_simple_string():
    """Test converting simple string to uppercase."""
    processor = StringProcessor()
    assert processor.to_uppercase("hello") == "HELLO"


def test_count_words_simple_sentence():
    """Test counting words in a simple sentence."""
    processor = StringProcessor()
    assert processor.count_words("hello world") == 2


# Group 2: Edge cases
def test_reverse_empty_string():
    """Test reversing empty string returns empty string."""
    processor = StringProcessor()
    assert processor.reverse("") == ""


def test_count_words_empty_string():
    """Test counting words in empty string returns zero."""
    processor = StringProcessor()
    assert processor.count_words("") == 0


# Group 3: Special cases
def test_reverse_palindrome():
    """Test reversing a palindrome returns same string."""
    processor = StringProcessor()
    assert processor.reverse("racecar") == "racecar"


def test_to_uppercase_already_uppercase():
    """Test uppercasing already uppercase string."""
    processor = StringProcessor()
    assert processor.to_uppercase("HELLO") == "HELLO"


# Run string processor tests
test_reverse_simple_string()
test_to_uppercase_simple_string()
test_count_words_simple_sentence()
test_reverse_empty_string()
test_count_words_empty_string()
test_reverse_palindrome()
test_to_uppercase_already_uppercase()
print("✓ String processor tests (well-organized) passed")


# ============================================================================
# SUMMARY
# ============================================================================

"""
KEY TAKEAWAYS:

1. Organize tests in separate directory structure
2. Follow consistent naming conventions (test_*)
3. Group related tests logically
4. Write clear, descriptive test names
5. Use docstrings to document test purpose
6. Extract common setup/teardown code
7. Make tests discoverable by frameworks
8. Keep tests simple and maintainable

NAMING CHECKLIST:
□ Test files start with test_ or end with _test
□ Test functions start with test_
□ Names are descriptive and specific
□ Names follow pattern: test_function_scenario_result

ORGANIZATION CHECKLIST:
□ Tests in separate directory
□ Structure mirrors source code
□ Related tests grouped together
□ Setup/teardown extracted
□ Tests are independent

NEXT STEPS:
- Practice organizing your own tests
- Learn unittest framework (04_unittest_basics.py)
- Explore pytest framework (08_pytest_basics.py)
"""


if __name__ == "__main__":
    print("\n" + "="*60)
    print("TEST ORGANIZATION - ALL TESTS PASSED!")
    print("="*60)
    print("\nYou've learned:")
    print("✓ Test file and directory structure")
    print("✓ Naming conventions for tests")
    print("✓ Grouping and organizing tests")
    print("✓ Test discovery mechanisms")
    print("✓ Setup and teardown patterns")
    print("✓ Documentation best practices")
    print("✓ Industry standard organization")
    print("\nNext: 04_unittest_basics.py or exercises/01_basic_testing_exercises.py")
