"""
05_unittest_assertions.py - Comprehensive unittest Assertion Methods
=====================================================================
All assertion methods with examples and best practices.
"""
import unittest

class TestAssertionMethods(unittest.TestCase):
    """Complete reference of unittest assertion methods."""
    
    def test_assertEqual_variants(self):
        """Test equality assertions."""
        self.assertEqual(42, 42)
        self.assertNotEqual(1, 2)
        self.assertAlmostEqual(1.0, 1.0001, places=3)  # Floating-point comparison
        
    def test_comparison_assertions(self):
        """Test comparison assertions."""
        self.assertGreater(5, 3)
        self.assertGreaterEqual(5, 5)
        self.assertLess(3, 5)
        self.assertLessEqual(3, 3)
        
    def test_boolean_assertions(self):
        """Test boolean assertions."""
        self.assertTrue(1 == 1)
        self.assertFalse(1 == 2)
        
    def test_none_assertions(self):
        """Test None assertions."""
        self.assertIsNone(None)
        self.assertIsNotNone("something")
        
    def test_identity_assertions(self):
        """Test object identity."""
        a = [1, 2]
        b = a
        self.assertIs(a, b)
        c = [1, 2]
        self.assertIsNot(a, c)
        
    def test_membership_assertions(self):
        """Test membership."""
        self.assertIn(3, [1, 2, 3])
        self.assertNotIn(5, [1, 2, 3])
        
    def test_type_assertions(self):
        """Test type checking."""
        self.assertIsInstance(42, int)
        self.assertNotIsInstance("hello", int)
        
    def test_regex_assertions(self):
        """Test regex matching."""
        self.assertRegex("hello world", r"hello.*")
        self.assertNotRegex("hello", r"^world")
        
    def test_sequence_assertions(self):
        """Test sequence comparisons."""
        self.assertSequenceEqual([1, 2, 3], [1, 2, 3])
        self.assertListEqual([1, 2], [1, 2])
        self.assertTupleEqual((1, 2), (1, 2))
        
    def test_set_assertions(self):
        """Test set comparisons."""
        self.assertSetEqual({1, 2, 3}, {3, 2, 1})
        
    def test_dict_assertions(self):
        """Test dictionary comparisons."""
        self.assertDictEqual({'a': 1}, {'a': 1})
        
    def test_raises_context_manager(self):
        """Test exception raising using context manager."""
        with self.assertRaises(ValueError):
            int("not a number")
        
        with self.assertRaisesRegex(ValueError, "invalid literal"):
            int("not a number")
        
    def test_warning_assertions(self):
        """Test warning assertions."""
        import warnings
        with self.assertWarns(UserWarning):
            warnings.warn("test warning", UserWarning)

if __name__ == "__main__":
    unittest.main(verbosity=2)
