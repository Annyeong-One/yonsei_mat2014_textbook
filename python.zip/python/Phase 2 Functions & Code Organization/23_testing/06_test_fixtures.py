"""
06_test_fixtures.py - setUp, tearDown, and Test Fixtures
========================================================
Learn to use test fixtures for setup and cleanup.
"""
import unittest
import tempfile
import os

class TestFixturesBasics(unittest.TestCase):
    """Basic fixture usage with setUp and tearDown."""
    
    def setUp(self):
        """Run before each test method."""
        self.temp_list = [1, 2, 3]
        print(f"\nsetUp: Created list {self.temp_list}")
    
    def tearDown(self):
        """Run after each test method."""
        self.temp_list = None
        print("tearDown: Cleaned up list")
    
    def test_list_append(self):
        """Test appending to list."""
        self.temp_list.append(4)
        self.assertEqual(len(self.temp_list), 4)
    
    def test_list_remove(self):
        """Test removing from list."""
        self.temp_list.remove(2)
        self.assertEqual(len(self.temp_list), 2)


class TestClassFixtures(unittest.TestCase):
    """Class-level fixtures - run once per test class."""
    
    @classmethod
    def setUpClass(cls):
        """Run once before all tests in the class."""
        cls.shared_resource = "Expensive setup"
        print(f"\nsetUpClass: Created shared resource")
    
    @classmethod
    def tearDownClass(cls):
        """Run once after all tests in the class."""
        cls.shared_resource = None
        print("\ntearDownClass: Cleaned up shared resource")
    
    def test_resource_exists(self):
        """Test shared resource is available."""
        self.assertIsNotNone(self.shared_resource)
    
    def test_resource_value(self):
        """Test shared resource has correct value."""
        self.assertEqual(self.shared_resource, "Expensive setup")


class DatabaseMock:
    """Mock database for testing."""
    def __init__(self):
        self.connected = False
        self.data = {}
    
    def connect(self):
        self.connected = True
    
    def disconnect(self):
        self.connected = False
        self.data.clear()
    
    def insert(self, key, value):
        if not self.connected:
            raise RuntimeError("Not connected")
        self.data[key] = value
    
    def get(self, key):
        return self.data.get(key)


class TestDatabaseFixtures(unittest.TestCase):
    """Test database operations with fixtures."""
    
    def setUp(self):
        """Create and connect to database before each test."""
        self.db = DatabaseMock()
        self.db.connect()
    
    def tearDown(self):
        """Disconnect from database after each test."""
        self.db.disconnect()
        self.db = None
    
    def test_insert_data(self):
        """Test inserting data into database."""
        self.db.insert("user1", "Alice")
        self.assertEqual(self.db.get("user1"), "Alice")
    
    def test_multiple_inserts(self):
        """Test multiple inserts."""
        self.db.insert("user1", "Alice")
        self.db.insert("user2", "Bob")
        self.assertEqual(len(self.db.data), 2)


class TestFileFixtures(unittest.TestCase):
    """Test file operations with temporary files."""
    
    def setUp(self):
        """Create temporary file for testing."""
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', delete=False)
        self.temp_filename = self.temp_file.name
        self.temp_file.write("Test content\n")
        self.temp_file.close()
    
    def tearDown(self):
        """Clean up temporary file."""
        if os.path.exists(self.temp_filename):
            os.unlink(self.temp_filename)
    
    def test_file_exists(self):
        """Test that temporary file was created."""
        self.assertTrue(os.path.exists(self.temp_filename))
    
    def test_file_content(self):
        """Test reading file content."""
        with open(self.temp_filename, 'r') as f:
            content = f.read()
        self.assertEqual(content, "Test content\n")


if __name__ == "__main__":
    unittest.main(verbosity=2)
