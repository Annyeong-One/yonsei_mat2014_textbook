"""
07_test_suites.py - Test Suites and Test Runners
================================================
Organizing and running multiple test cases together.
"""
import unittest

# Example functions and classes to test
def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

class TestAddition(unittest.TestCase):
    """Tests for addition function."""
    
    def test_add_positive(self):
        self.assertEqual(add(2, 3), 5)
    
    def test_add_negative(self):
        self.assertEqual(add(-1, -1), -2)


class TestMultiplication(unittest.TestCase):
    """Tests for multiplication function."""
    
    def test_multiply_positive(self):
        self.assertEqual(multiply(3, 4), 12)
    
    def test_multiply_by_zero(self):
        self.assertEqual(multiply(5, 0), 0)


def create_test_suite():
    """Create a custom test suite."""
    suite = unittest.TestSuite()
    
    # Add specific tests
    suite.addTest(TestAddition('test_add_positive'))
    suite.addTest(TestMultiplication('test_multiply_positive'))
    
    # Or add all tests from a class
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestAddition))
    
    return suite


def run_custom_suite():
    """Run a custom test suite."""
    suite = create_test_suite()
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)


if __name__ == "__main__":
    # Option 1: Run all tests
    # unittest.main(verbosity=2)
    
    # Option 2: Run custom suite
    run_custom_suite()
