# Python Testing Curriculum - Comprehensive Tutorial Package

## Overview
This comprehensive curriculum teaches software testing in Python from fundamental concepts through advanced testing strategies. Designed for undergraduate computer science students in a year-long Python course.

## Course Structure

### Level 1: Foundations (Weeks 1-2)
- **01_introduction_to_testing.py** - Why testing matters, basic assertions
- **02_assert_statements.py** - Deep dive into Python assertions
- **03_test_organization.py** - Organizing test code and conventions
- **exercises/01_basic_testing_exercises.py** - Practice with assertions and basic testing

### Level 2: unittest Framework (Weeks 3-5)
- **04_unittest_basics.py** - Introduction to unittest framework
- **05_unittest_assertions.py** - unittest assertion methods
- **06_test_fixtures.py** - setUp, tearDown, and test fixtures
- **07_test_suites.py** - Organizing tests into suites
- **exercises/02_unittest_exercises.py** - unittest practice problems

### Level 3: pytest Framework (Weeks 6-8)
- **08_pytest_basics.py** - Introduction to pytest
- **09_pytest_fixtures.py** - pytest fixtures and conftest
- **10_pytest_parametrize.py** - Parametrized testing
- **11_pytest_markers.py** - Test markers and custom markers
- **exercises/03_pytest_exercises.py** - pytest practice problems

### Level 4: Test-Driven Development (Weeks 9-11)
- **12_tdd_introduction.py** - TDD philosophy and red-green-refactor
- **13_tdd_example_calculator.py** - TDD example: Building a calculator
- **14_tdd_example_string_processor.py** - TDD example: String processing
- **exercises/04_tdd_exercises.py** - TDD practice projects

### Level 5: Mocking and Isolation (Weeks 12-14)
- **15_mocking_basics.py** - Introduction to mocking with unittest.mock
- **16_mock_objects.py** - Mock, MagicMock, and patch
- **17_mocking_external_services.py** - Mocking APIs, databases, files
- **exercises/05_mocking_exercises.py** - Mocking practice problems

### Level 6: Advanced Testing (Weeks 15-18)
- **18_property_based_testing.py** - Hypothesis library for property testing
- **19_coverage_analysis.py** - Code coverage and coverage.py
- **20_integration_testing.py** - Integration vs unit testing
- **21_testing_exceptions.py** - Testing error conditions
- **22_testing_async_code.py** - Testing asyncio and concurrent code
- **exercises/06_advanced_exercises.py** - Advanced testing challenges

### Level 7: Real-World Applications (Weeks 19-22)
- **23_testing_web_applications.py** - Testing Flask/FastAPI applications
- **24_testing_data_science_code.py** - Testing NumPy/Pandas code
- **25_continuous_integration.py** - CI/CD and automated testing
- **26_testing_best_practices.py** - Industry best practices and patterns
- **exercises/07_realworld_exercises.py** - Real-world testing scenarios

## Exercise Solutions
All exercises include detailed solutions in the `solutions/` directory:
- `solutions/01_basic_testing_solutions.py`
- `solutions/02_unittest_solutions.py`
- `solutions/03_pytest_solutions.py`
- `solutions/04_tdd_solutions.py`
- `solutions/05_mocking_solutions.py`
- `solutions/06_advanced_solutions.py`
- `solutions/07_realworld_solutions.py`

## Installation Requirements

```bash
# Create virtual environment
python -m venv testing_env
source testing_env/bin/activate  # On Windows: testing_env\Scripts\activate

# Install required packages
pip install pytest pytest-cov hypothesis requests flask pandas numpy
```

## Running Tests

### Using unittest
```bash
# Run single test file
python -m unittest 04_unittest_basics.py

# Run all tests
python -m unittest discover

# Verbose output
python -m unittest -v 04_unittest_basics.py
```

### Using pytest
```bash
# Run all tests
pytest

# Run specific file
pytest 08_pytest_basics.py

# Verbose output
pytest -v

# With coverage
pytest --cov=. --cov-report=html
```

## Learning Path

1. **Complete Beginner**: Start with 01-03, then exercises
2. **Some Python Experience**: Begin at 04 (unittest)
3. **Intermediate Programmer**: Jump to 08 (pytest)
4. **Advanced Students**: Focus on 15-26

## Key Concepts Covered

- **Testing Fundamentals**: Assertions, test organization, naming conventions
- **unittest Framework**: TestCase, assertions, fixtures, suites
- **pytest Framework**: Fixtures, parametrization, markers, plugins
- **TDD Methodology**: Red-green-refactor cycle, test-first development
- **Mocking**: Isolating code, mocking external dependencies
- **Advanced Techniques**: Property-based testing, coverage analysis, async testing
- **Real-World Skills**: Testing web apps, data science code, CI/CD integration

## Assessment Suggestions

### Homework Assignments
1. Week 3: Write unittest test suite for provided calculator module
2. Week 7: Convert unittest tests to pytest with fixtures
3. Week 10: Implement feature using strict TDD (submit git history)
4. Week 14: Write tests using mocks for API client
5. Week 18: Achieve >90% coverage on provided codebase
6. Week 22: Set up CI/CD pipeline with automated testing

### Midterm Project
Students implement a complete module with comprehensive test suite covering:
- Unit tests for all functions/methods
- Integration tests for workflows
- >85% code coverage
- Proper test organization

### Final Project
Students design and implement a small application using TDD:
- Evidence of test-first development
- Comprehensive test suite (unit + integration)
- Mocking of external dependencies
- >90% code coverage
- CI/CD integration

## Additional Resources

- **pytest documentation**: https://docs.pytest.org/
- **unittest documentation**: https://docs.python.org/3/library/unittest.html
- **Real Python Testing Guide**: https://realpython.com/python-testing/
- **Test-Driven Development**: "Test Driven Development: By Example" by Kent Beck
- **Python Testing Cookbook**: "Python Testing Cookbook" by Greg L. Turnquist

## Teaching Notes

### Common Student Mistakes
1. Writing tests that test the framework, not the code
2. Over-mocking leading to brittle tests
3. Testing implementation details instead of behavior
4. Not isolating tests (shared state problems)
5. Writing tests after code (missing TDD benefits)

### Emphasis Points
- Test behavior, not implementation
- Tests should be fast, isolated, repeatable
- Good test names describe what they test
- One assertion per test (when practical)
- Arrange-Act-Assert pattern

### Lab Activities
- Pair programming with TDD
- Test legacy code workshops
- Code review focusing on testability
- Coverage improvement challenges
- Bug hunt with test writing

## License
Educational use only. Created for undergraduate computer science instruction.

## Version
Version 1.0 - Comprehensive Testing Curriculum
Last Updated: November 2025
