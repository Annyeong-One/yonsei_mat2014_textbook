# Python Type Hints Complete Course
## For Undergraduate Computer Science Education

Welcome to the comprehensive Python Type Hints course! This educational package is designed for undergraduate students learning Python in a one-year computer science course.

---

## 📚 Course Overview

This course systematically covers Python type hints from basic concepts to advanced features, with progressive difficulty levels and extensive hands-on exercises.

### Prerequisites
- Python 3.5 or higher (Python 3.9+ recommended)
- Basic Python programming knowledge
- Familiarity with functions, classes, and standard data structures

### Course Structure
- **10 Tutorial Modules**: Progressively complex lessons with heavily commented code
- **Practice Exercises**: Hands-on problems to reinforce learning
- **Complete Solutions**: Detailed solutions for self-assessment
- **Real-world Examples**: Practical applications in each module

---

## 📖 Tutorial Modules

### **Tutorial 01: Basic Type Hints**
**Level:** Beginner  
**Topics:**
- Introduction to type hints and why they matter
- Basic built-in types (int, str, float, bool)
- Simple function annotations
- Understanding runtime behavior vs static checking
- Benefits of type hints for code quality

**Key Concepts:**
- Type hints are optional metadata
- Don't affect runtime behavior
- Improve IDE support and catch bugs early
- Make code self-documenting

---

### **Tutorial 02: Function Annotations in Depth**
**Level:** Beginner to Intermediate  
**Topics:**
- Multiple parameters with type hints
- Functions returning None
- Default parameters and type hints
- Keyword-only parameters
- Variable arguments (*args, **kwargs)
- Functions that never return (NoReturn)

**Key Concepts:**
- Comprehensive function signature typing
- Combining different parameter types
- Using NoReturn for exceptions/infinite loops
- Proper annotation of variadic functions

---

### **Tutorial 03: Collection Type Hints**
**Level:** Intermediate  
**Topics:**
- List type hints (List[T])
- Dictionary type hints (Dict[K, V])
- Set and FrozenSet type hints
- Tuple type hints (fixed and variable length)
- Nested collection types
- Working with homogeneous and heterogeneous collections

**Key Concepts:**
- Specifying element types in collections
- Fixed-length vs variable-length tuples
- Nested data structures
- Immutable collection types

---

### **Tutorial 04: Optional and Union Types**
**Level:** Intermediate  
**Topics:**
- Optional type for nullable values
- Union types for multiple possibilities
- Type narrowing with isinstance
- Handling None values safely
- Complex Optional/Union patterns

**Key Concepts:**
- Optional[X] is shorthand for Union[X, None]
- Type narrowing after None checks
- When to use Union vs Optional
- Best practices for nullable types

---

### **Tutorial 05: Advanced Collection Types**
**Level:** Intermediate to Advanced  
**Topics:**
- Sequence and MutableSequence
- Mapping and MutableMapping
- Iterable and Iterator
- Collection and Container
- When to use abstract vs concrete types
- Covariance basics

**Key Concepts:**
- Abstract collection protocols
- Duck typing with type safety
- Choosing the right abstraction level
- Read-only vs mutable interfaces

---

### **Tutorial 06: Type Aliases and NewType**
**Level:** Intermediate  
**Topics:**
- Creating type aliases for readability
- Complex nested type aliases
- NewType for distinct types
- Type aliases vs NewType
- Generic type aliases
- Documentation best practices

**Key Concepts:**
- Type aliases are synonyms
- NewType creates distinct types
- Improving code readability
- Type safety with NewType
- Recursive type definitions

---

### **Tutorial 07: Generic Types and TypeVar**
**Level:** Advanced  
**Topics:**
- TypeVar for generic programming
- Creating generic functions
- Building generic classes
- Constrained and bounded TypeVars
- Multiple TypeVars
- Variance in generic types

**Key Concepts:**
- Type preservation in generic code
- Reusable type-safe code
- Generic collections and containers
- Type variable constraints
- Covariance and contravariance

---

### **Tutorial 08: Protocols and Structural Subtyping**
**Level:** Advanced  
**Topics:**
- Protocol for structural subtyping
- Creating custom protocols
- Runtime-checkable protocols
- Protocol vs ABC
- Common built-in protocols
- Protocol inheritance

**Key Concepts:**
- Structural vs nominal subtyping
- Duck typing with type safety
- Interface-like behavior
- Runtime protocol checking
- Protocol composition

---

### **Tutorial 09: TypedDict, Literal, and Final**
**Level:** Advanced  
**Topics:**
- TypedDict for structured dictionaries
- Required vs optional fields (total=False)
- Literal types for exact values
- Final for constants and immutable attributes
- Combining these advanced features

**Key Concepts:**
- Type-safe dictionary structures
- Exact value types
- Immutability enforcement
- Structured configuration
- API contract specification

---

### **Tutorial 10: Advanced Type Hints Features**
**Level:** Advanced  
**Topics:**
- Callable types for functions
- ParamSpec and Concatenate
- TypeGuard for type narrowing
- Annotated for metadata
- Overload for multiple signatures
- Advanced decorator typing

**Key Concepts:**
- Higher-order function typing
- Decorator type preservation
- Custom type guards
- Multiple function signatures
- Metadata annotations

---

## 🎯 Learning Path

### Beginner Track (Tutorials 1-3)
Start here if you're new to type hints. These tutorials cover the fundamentals and common patterns you'll use daily.

**Estimated Time:** 6-8 hours
1. Complete Tutorial 01
2. Try exercises 01
3. Complete Tutorial 02
4. Try exercises 02
5. Complete Tutorial 03
6. Try exercises 03

### Intermediate Track (Tutorials 4-6)
Build on your foundation with more complex types and patterns.

**Estimated Time:** 8-10 hours
1. Complete Tutorial 04 (Optional/Union)
2. Try exercises 04
3. Complete Tutorial 05 (Advanced Collections)
4. Try exercises 05
5. Complete Tutorial 06 (Type Aliases)

### Advanced Track (Tutorials 7-10)
Master the most powerful type hinting features for professional development.

**Estimated Time:** 10-12 hours
1. Complete Tutorial 07 (Generics)
2. Complete Tutorial 08 (Protocols)
3. Complete Tutorial 09 (TypedDict/Literal/Final)
4. Complete Tutorial 10 (Advanced Features)

---

## 🚀 Getting Started

### Installation

1. **Ensure Python 3.9+ is installed:**
   ```bash
   python3 --version
   ```

2. **Install mypy (type checker):**
   ```bash
   pip install mypy
   ```

3. **Extract the course materials:**
   ```bash
   unzip type_hints_course.zip
   cd type_hints_course
   ```

### Running Tutorials

Each tutorial is a standalone Python file with extensive comments:

```bash
# Run a tutorial to see examples
python3 tutorials/01_basic_type_hints.py

# Check types with mypy
mypy tutorials/01_basic_type_hints.py
```

### Working with Exercises

1. Open an exercise file in your editor
2. Complete the TODO sections
3. Check your work with mypy:
   ```bash
   mypy exercises/01_exercises.py
   ```
4. Compare with solutions when ready

---

## 📁 Repository Structure

```
type_hints_course/
├── README.md                          # This file
├── tutorials/                         # Tutorial lessons
│   ├── 01_basic_type_hints.py        # Beginner: Basic concepts
│   ├── 02_function_annotations.py    # Beginner: Function typing
│   ├── 03_collections.py             # Intermediate: Collections
│   ├── 04_optional_union.py          # Intermediate: Optional/Union
│   ├── 05_advanced_collections.py    # Advanced: Abstract types
│   ├── 06_type_aliases.py            # Intermediate: Aliases
│   ├── 07_generics.py                # Advanced: Generic programming
│   ├── 08_protocols.py               # Advanced: Structural typing
│   ├── 09_typed_dict_literal.py      # Advanced: TypedDict/Literal
│   └── 10_advanced_features.py       # Advanced: Expert features
├── exercises/                         # Practice problems
│   ├── 01_exercises.py               # Basic exercises
│   ├── 02_exercises.py               # Function exercises
│   ├── 03_exercises.py               # Collection exercises
│   ├── 04_exercises.py               # Optional/Union exercises
│   └── 05_exercises.py               # Advanced exercises
└── solutions/                         # Exercise solutions
    ├── 01_solutions.py
    └── 02_solutions.py
```

---

## 🛠️ Tools and Resources

### Recommended Tools

1. **mypy** - Static type checker
   ```bash
   pip install mypy
   mypy your_file.py
   ```

2. **pyright** - Alternative type checker (faster)
   ```bash
   pip install pyright
   pyright your_file.py
   ```

3. **VS Code** with Python extension
   - Real-time type checking
   - Autocomplete with type hints
   - Type error highlighting

4. **PyCharm** (Community or Professional)
   - Built-in type checking
   - Excellent type hint support

### Configuration

Create a `mypy.ini` file in your project:

```ini
[mypy]
python_version = 3.9
warn_return_any = True
warn_unused_configs = True
disallow_untyped_defs = True
```

---

## 📝 Teaching Notes

### For Instructors

This course is designed for undergraduate computer science education with these pedagogical principles:

1. **Progressive Complexity:** Each tutorial builds on previous concepts
2. **Heavy Commenting:** Every code example is extensively documented
3. **Real-world Context:** Examples reflect practical programming scenarios
4. **Active Learning:** Exercises reinforce each concept
5. **Self-contained Modules:** Each tutorial can be studied independently

### Classroom Integration

**Week 1-2:** Tutorials 1-2 (Basics and Functions)
**Week 3-4:** Tutorials 3-4 (Collections and Optional)
**Week 5-6:** Tutorials 5-6 (Advanced Collections and Aliases)
**Week 7-8:** Tutorials 7-8 (Generics and Protocols)
**Week 9-10:** Tutorials 9-10 (TypedDict and Advanced Features)

### Assessment Ideas

1. **Type Hint Audit:** Students add type hints to existing code
2. **Code Review:** Students identify type errors in sample code
3. **Design Project:** Students create typed API or library
4. **Refactoring Exercise:** Improve code with better type hints

---

## 🎓 Learning Outcomes

After completing this course, students will be able to:

1. ✅ Add appropriate type hints to Python functions and classes
2. ✅ Use type checkers to find bugs before runtime
3. ✅ Read and understand typed Python code in real projects
4. ✅ Design type-safe APIs and interfaces
5. ✅ Apply advanced typing features for generic programming
6. ✅ Use protocols for flexible, typed interfaces
7. ✅ Make informed decisions about when and how to use type hints
8. ✅ Contribute to typed open-source Python projects

---

## 🔍 Additional Resources

### Official Documentation
- [PEP 484 - Type Hints](https://www.python.org/dev/peps/pep-0484/)
- [PEP 526 - Variable Annotations](https://www.python.org/dev/peps/pep-0526/)
- [PEP 544 - Protocols](https://www.python.org/dev/peps/pep-0544/)
- [Python typing module documentation](https://docs.python.org/3/library/typing.html)
- [mypy documentation](https://mypy.readthedocs.io/)

### Books
- "Fluent Python" by Luciano Ramalho (2nd edition covers type hints)
- "Effective Python" by Brett Slatkin
- "Python Type Checking Guide" by Real Python

### Online Courses
- Real Python's Type Checking series
- Python's official typing tutorial
- Type checking in popular frameworks (FastAPI, Django, etc.)

---

## 💡 Tips for Success

1. **Practice Regularly:** Type hints become intuitive with practice
2. **Use a Type Checker:** Run mypy frequently to catch errors
3. **Read Others' Code:** Study typed code in popular libraries
4. **Start Simple:** Begin with basic function annotations
5. **Iterate:** Add types gradually to existing code
6. **Ask Questions:** Type hints can be confusing at first
7. **Don't Overdo It:** Not all code needs type hints
8. **Keep Learning:** New typing features are added regularly

---

## 🐛 Common Pitfalls

1. **Thinking types are enforced at runtime** - They're not!
2. **Over-typing internal code** - Focus on public APIs first
3. **Ignoring mypy errors** - They're usually right
4. **Using Any too much** - Defeats the purpose of type hints
5. **Not updating types** - Keep them in sync with code changes
6. **Forgetting about None** - Use Optional liberally
7. **Premature complexity** - Start simple, add complexity as needed

---

## 📧 Support and Feedback

This educational package was created for undergraduate computer science education. For questions or feedback:

- Review the tutorial comments carefully
- Check the solutions for guidance
- Consult the official Python typing documentation
- Use mypy error messages as learning opportunities

---

## 📄 License

This educational material is provided for academic use. Feel free to use, modify, and distribute for educational purposes.

---

## 🎉 Happy Learning!

Type hints make Python code more maintainable, catch bugs earlier, and improve collaboration. Take your time with each tutorial, practice with the exercises, and soon type hints will become second nature!

**Remember:** The goal isn't to memorize every typing feature, but to understand when and how to apply type hints to write better Python code.

Good luck with your studies! 🐍✨
