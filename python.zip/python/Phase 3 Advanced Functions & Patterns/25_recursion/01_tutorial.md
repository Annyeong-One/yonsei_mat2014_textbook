# Python Recursion - Complete Guide

## Table of Contents
1. [Introduction](#introduction)
2. [What is Recursion?](#what-is-recursion)
3. [How Recursion Works](#how-recursion-works)
4. [Base Case and Recursive Case](#base-case-and-recursive-case)
5. [The Call Stack](#the-call-stack)
6. [Classic Recursion Examples](#classic-recursion-examples)
7. [Recursion vs Iteration](#recursion-vs-iteration)
8. [Common Recursion Patterns](#common-recursion-patterns)
9. [Tail Recursion](#tail-recursion)
10. [Common Pitfalls](#common-pitfalls)
11. [Best Practices](#best-practices)

---

## Introduction

**Recursion** is a programming technique where a function calls itself to solve a problem by breaking it down into smaller, similar subproblems.

### Why Learn Recursion?

- **Problem-solving tool**: Some problems are naturally recursive
- **Tree and graph algorithms**: Essential for hierarchical data
- **Divide and conquer**: Break complex problems into simpler ones
- **Elegant solutions**: Often more concise than iterative approaches
- **Interview favorite**: Common in technical interviews

---

## What is Recursion?

Recursion occurs when a function calls itself, either directly or indirectly.

### Simple Example

```python
def countdown(n):
    if n <= 0:
        print("Blastoff!")
    else:
        print(n)
        countdown(n - 1)  # Function calls itself!

countdown(3)
# Output:
# 3
# 2
# 1
# Blastoff!
```

### The Recursive Idea

Instead of solving the entire problem at once:
1. Solve a small part
2. Call the function again with a simpler version
3. Repeat until the problem is trivial

---

## How Recursion Works

Every recursive function needs **two parts**:

### 1. Base Case (Stopping Condition)
The simplest case that can be solved directly without recursion.

### 2. Recursive Case
The part where the function calls itself with a simpler input.

```python
def factorial(n):
    # Base case: simplest problem we can solve
    if n == 0 or n == 1:
        return 1
    
    # Recursive case: break problem into smaller problem
    else:
        return n * factorial(n - 1)
```

### Visualization: factorial(3)

```
factorial(3)
  = 3 * factorial(2)
  = 3 * (2 * factorial(1))
  = 3 * (2 * 1)
  = 3 * 2
  = 6
```

---

## Base Case and Recursive Case

### Why Base Case is Critical

Without a base case, recursion never stops → **infinite recursion** → stack overflow!

```python
# ❌ WRONG - No base case (infinite recursion)
def bad_countdown(n):
    print(n)
    bad_countdown(n - 1)  # Never stops!

# ✅ CORRECT - Has base case
def good_countdown(n):
    if n <= 0:  # Base case
        print("Done!")
        return
    print(n)
    good_countdown(n - 1)  # Recursive case
```

### Multiple Base Cases

Some problems need multiple base cases:

```python
def fibonacci(n):
    # Base case 1
    if n == 0:
        return 0
    # Base case 2
    if n == 1:
        return 1
    # Recursive case
    return fibonacci(n - 1) + fibonacci(n - 2)
```

---

## The Call Stack

Understanding the call stack helps understand recursion.

### What is the Call Stack?

A stack data structure that stores information about active function calls.

### Example: factorial(3)

```
Step 1: Call factorial(3)
Stack: [factorial(3)]

Step 2: factorial(3) calls factorial(2)
Stack: [factorial(3), factorial(2)]

Step 3: factorial(2) calls factorial(1)
Stack: [factorial(3), factorial(2), factorial(1)]

Step 4: factorial(1) returns 1 (base case)
Stack: [factorial(3), factorial(2)]
        factorial(2) = 2 * 1 = 2

Step 5: factorial(2) returns 2
Stack: [factorial(3)]
        factorial(3) = 3 * 2 = 6

Step 6: factorial(3) returns 6
Stack: []
```

### Stack Overflow

If recursion goes too deep, you run out of stack space:

```python
# This will cause stack overflow for large n
def infinite_like(n):
    if n == 0:
        return 0
    return infinite_like(n - 1)

# infinite_like(10000)  # RecursionError!
```

Python's default recursion limit: ~1000 calls

---

## Classic Recursion Examples

### 1. Factorial

Calculate n! = n × (n-1) × ... × 2 × 1

```python
def factorial(n):
    """Calculate factorial recursively"""
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)

print(factorial(5))  # 120
```

### 2. Fibonacci Sequence

Each number is sum of previous two: 0, 1, 1, 2, 3, 5, 8, 13...

```python
def fibonacci(n):
    """Return nth Fibonacci number"""
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fibonacci(n - 1) + fibonacci(n - 2)

print(fibonacci(6))  # 8
```

### 3. Sum of List

```python
def sum_list(numbers):
    """Sum all numbers in list recursively"""
    # Base case: empty list
    if len(numbers) == 0:
        return 0
    # Recursive case: first + sum of rest
    return numbers[0] + sum_list(numbers[1:])

print(sum_list([1, 2, 3, 4, 5]))  # 15
```

### 4. Power Function

Calculate base^exponent

```python
def power(base, exp):
    """Calculate base^exp recursively"""
    # Base case
    if exp == 0:
        return 1
    # Recursive case
    return base * power(base, exp - 1)

print(power(2, 5))  # 32
```

### 5. Reverse a String

```python
def reverse_string(s):
    """Reverse string recursively"""
    # Base case: empty or single char
    if len(s) <= 1:
        return s
    # Recursive case: last char + reverse of rest
    return s[-1] + reverse_string(s[:-1])

print(reverse_string("hello"))  # "olleh"
```

### 6. Count Digits

```python
def count_digits(n):
    """Count digits in a number"""
    # Base case
    if n < 10:
        return 1
    # Recursive case
    return 1 + count_digits(n // 10)

print(count_digits(12345))  # 5
```

---

## Recursion vs Iteration

Any recursive function can be written iteratively, and vice versa.

### Factorial: Recursive vs Iterative

```python
# Recursive
def factorial_recursive(n):
    if n <= 1:
        return 1
    return n * factorial_recursive(n - 1)

# Iterative
def factorial_iterative(n):
    result = 1
    for i in range(2, n + 1):
        result *= i
    return result
```

### When to Use Recursion

**✅ Use recursion when:**
- Problem is naturally recursive (trees, graphs)
- Code is clearer and more intuitive
- Performance isn't critical
- Problem involves divide-and-conquer

**❌ Avoid recursion when:**
- Simple iteration is clearer
- Deep recursion might cause stack overflow
- Performance is critical (iterative is often faster)
- Memory is limited

### Comparison Table

| Aspect | Recursion | Iteration |
|--------|-----------|-----------|
| Code clarity | Often clearer for recursive problems | Better for simple loops |
| Memory | Uses stack space | Uses less memory |
| Speed | Generally slower | Generally faster |
| Stack overflow | Possible with deep recursion | No risk |
| Debugging | Can be harder | Usually easier |

---

## Common Recursion Patterns

### Pattern 1: Linear Recursion

Process one element, recurse on rest.

```python
def print_list(items):
    if len(items) == 0:
        return
    print(items[0])
    print_list(items[1:])
```

### Pattern 2: Binary Recursion

Two recursive calls (like Fibonacci).

```python
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
```

### Pattern 3: Tail Recursion

Recursive call is the last operation.

```python
def factorial_tail(n, accumulator=1):
    if n <= 1:
        return accumulator
    return factorial_tail(n - 1, n * accumulator)
```

### Pattern 4: Multiple Recursion

More than two recursive calls.

```python
def tribonacci(n):
    if n == 0:
        return 0
    if n <= 2:
        return 1
    return tribonacci(n-1) + tribonacci(n-2) + tribonacci(n-3)
```

### Pattern 5: Indirect Recursion

Function A calls B, B calls A.

```python
def is_even(n):
    if n == 0:
        return True
    return is_odd(n - 1)

def is_odd(n):
    if n == 0:
        return False
    return is_even(n - 1)
```

---

## Tail Recursion

**Tail recursion** occurs when the recursive call is the last operation in the function.

### Regular Recursion (Not Tail)

```python
def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)  # Multiplication after recursive call
```

### Tail Recursion

```python
def factorial_tail(n, accumulator=1):
    if n <= 1:
        return accumulator
    return factorial_tail(n - 1, n * accumulator)  # Nothing after call
```

### Why Tail Recursion Matters

- Can be optimized by compiler/interpreter
- Uses constant stack space (in languages that support it)
- Python **doesn't** optimize tail recursion (but good to know)

---

## Common Pitfalls

### Pitfall 1: Missing Base Case

```python
# ❌ WRONG - Infinite recursion
def countdown(n):
    print(n)
    countdown(n - 1)  # Never stops!

# ✅ CORRECT
def countdown(n):
    if n <= 0:
        return
    print(n)
    countdown(n - 1)
```

### Pitfall 2: Wrong Base Case

```python
# ❌ WRONG - Base case never reached
def sum_list(numbers):
    if len(numbers) == 1:  # What about empty list?
        return numbers[0]
    return numbers[0] + sum_list(numbers[1:])

# ✅ CORRECT
def sum_list(numbers):
    if len(numbers) == 0:  # Handle empty list
        return 0
    return numbers[0] + sum_list(numbers[1:])
```

### Pitfall 3: Not Moving Toward Base Case

```python
# ❌ WRONG - Never gets closer to base case
def bad_function(n):
    if n == 0:
        return
    bad_function(n)  # Same value!

# ✅ CORRECT
def good_function(n):
    if n == 0:
        return
    good_function(n - 1)  # Gets closer to 0
```

### Pitfall 4: Inefficient Recursion

```python
# ❌ INEFFICIENT - Recalculates same values
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

# ✅ BETTER - Memoization
def fibonacci_memo(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fibonacci_memo(n-1, memo) + fibonacci_memo(n-2, memo)
    return memo[n]
```

### Pitfall 5: Modifying Shared State

```python
# ❌ WRONG - Modifying global variable
count = 0
def bad_counter(n):
    global count
    if n == 0:
        return
    count += 1
    bad_counter(n - 1)

# ✅ CORRECT - Pass as parameter
def good_counter(n, count=0):
    if n == 0:
        return count
    return good_counter(n - 1, count + 1)
```

---

## Best Practices

### 1. Always Have a Base Case

```python
def recursive_function(n):
    # ALWAYS check base case first
    if base_condition:
        return base_value
    # Then recursive case
    return recursive_function(modified_n)
```

### 2. Make Progress Toward Base Case

```python
# Each recursive call should be "simpler"
def countdown(n):
    if n <= 0:
        return
    print(n)
    countdown(n - 1)  # n gets smaller each time
```

### 3. Consider Iterative Alternative

```python
# Recursion is elegant but not always best
# For simple cases, iteration might be clearer

# Recursive
def sum_recursive(n):
    if n == 0:
        return 0
    return n + sum_recursive(n - 1)

# Iterative (simpler!)
def sum_iterative(n):
    return sum(range(n + 1))
```

### 4. Use Memoization for Expensive Recursion

```python
def fibonacci_optimized(n, memo=None):
    if memo is None:
        memo = {}
    
    if n in memo:
        return memo[n]
    
    if n <= 1:
        return n
    
    memo[n] = fibonacci_optimized(n-1, memo) + fibonacci_optimized(n-2, memo)
    return memo[n]
```

### 5. Document Your Recursive Function

```python
def factorial(n):
    """
    Calculate factorial of n recursively.
    
    Args:
        n: Non-negative integer
    
    Returns:
        n! = n × (n-1) × ... × 2 × 1
    
    Base case: n = 0 or n = 1 returns 1
    Recursive case: n! = n × (n-1)!
    """
    if n <= 1:
        return 1
    return n * factorial(n - 1)
```

### 6. Think About Edge Cases

```python
def safe_factorial(n):
    # Handle negative numbers
    if n < 0:
        raise ValueError("Factorial not defined for negative numbers")
    
    # Handle very large numbers (might overflow stack)
    if n > 1000:
        raise ValueError("Number too large for recursive factorial")
    
    # Base case
    if n <= 1:
        return 1
    
    # Recursive case
    return n * safe_factorial(n - 1)
```

---

## Recursion Decision Tree

```
Should I use recursion?
  ↓
Is the problem naturally recursive?
  (Trees, graphs, divide-and-conquer)
  ├─ Yes → Consider recursion
  └─ No → Is code much clearer with recursion?
      ├─ Yes → Consider recursion
      └─ No → Use iteration
          ↓
      Will recursion be too deep?
        ├─ Yes → Use iteration or tail recursion
        └─ No → Recursion is okay
            ↓
        Is performance critical?
          ├─ Yes → Consider iteration or memoization
          └─ No → Recursion is fine!
```

---

## Summary

### Key Takeaways

1. **Recursion** = function calling itself
2. **Base case** = stopping condition (critical!)
3. **Recursive case** = self-call with simpler input
4. **Call stack** = tracks recursive calls
5. **Every recursion can be iteration** (and vice versa)
6. **Use when natural**: trees, graphs, divide-and-conquer
7. **Watch out for**: infinite recursion, stack overflow
8. **Optimize with**: memoization, tail recursion

### Recursion Template

```python
def recursive_function(problem):
    # 1. Base case(s) - ALWAYS FIRST
    if is_base_case(problem):
        return base_solution
    
    # 2. Divide problem into smaller piece(s)
    smaller_problem = make_simpler(problem)
    
    # 3. Recursive call(s)
    smaller_solution = recursive_function(smaller_problem)
    
    # 4. Combine to solve original problem
    return combine(problem, smaller_solution)
```

### When to Use Recursion

✅ **Good for:**
- Tree and graph traversal
- Divide and conquer algorithms
- Problems with recursive structure
- When code clarity is priority

❌ **Avoid for:**
- Simple sequential processing
- Performance-critical code
- Deep recursion (>1000 calls)
- When iteration is equally clear

---

## Next Steps

Now that you understand recursion:
- Practice with tree data structures
- Learn dynamic programming
- Explore backtracking algorithms
- Study recursive sorting (merge sort, quick sort)

**Remember**: Recursion is a tool. Use it when it makes code clearer and more elegant!
