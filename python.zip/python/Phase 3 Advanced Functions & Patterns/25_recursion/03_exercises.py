"""
Python Recursion - Practice Exercises
Test your understanding of recursive functions!
"""

print("Exercise 1: Count Down")
print("-"*60)
print("Task: Create countdown(n) that prints n down to 1, then 'Liftoff!'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 2: Sum of Numbers")
print("-"*60)
print("Task: Create sum_to_n(n) that returns sum of 1 to n")
print("Example: sum_to_n(5) should return 15 (1+2+3+4+5)")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 3: Factorial")
print("-"*60)
print("Task: Create factorial(n) that returns n!")
print("Example: factorial(5) should return 120")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 4: Power Function")
print("-"*60)
print("Task: Create power(base, exp) that returns base^exp")
print("Example: power(2, 3) should return 8")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 5: Count Digits")
print("-"*60)
print("Task: Create count_digits(n) that counts digits in number")
print("Example: count_digits(12345) should return 5")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 6: Reverse String")
print("-"*60)
print("Task: Create reverse(s) that reverses a string")
print("Example: reverse('hello') should return 'olleh'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 7: Sum of List")
print("-"*60)
print("Task: Create sum_list(lst) that sums all numbers in list")
print("Example: sum_list([1, 2, 3, 4]) should return 10")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 8: Fibonacci")
print("-"*60)
print("Task: Create fibonacci(n) that returns nth Fibonacci number")
print("Sequence: 0, 1, 1, 2, 3, 5, 8, 13...")
print("Example: fibonacci(6) should return 8")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 9: Greatest Common Divisor")
print("-"*60)
print("Task: Create gcd(a, b) using Euclidean algorithm")
print("Example: gcd(48, 18) should return 6")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 10: Is Palindrome")
print("-"*60)
print("Task: Create is_palindrome(s) checking if string reads same forwards/backwards")
print("Example: is_palindrome('racecar') should return True")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 11: Count Character")
print("-"*60)
print("Task: Create count_char(s, char) counting occurrences of char in string")
print("Example: count_char('hello', 'l') should return 2")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 12: List Maximum")
print("-"*60)
print("Task: Create find_max(lst) finding maximum value in list")
print("Example: find_max([3, 7, 2, 9, 1]) should return 9")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 13: Binary String")
print("-"*60)
print("Task: Create decimal_to_binary(n) converting decimal to binary string")
print("Example: decimal_to_binary(10) should return '1010'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 14: Flatten List")
print("-"*60)
print("Task: Create flatten(lst) flattening nested list")
print("Example: flatten([1, [2, 3], [4, [5]]]) should return [1, 2, 3, 4, 5]")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 15: Product of Digits")
print("-"*60)
print("Task: Create product_of_digits(n) multiplying all digits")
print("Example: product_of_digits(234) should return 24 (2*3*4)")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 16: Range Sum")
print("-"*60)
print("Task: Create range_sum(start, end) summing numbers from start to end")
print("Example: range_sum(1, 5) should return 15 (1+2+3+4+5)")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 17: Remove Character")
print("-"*60)
print("Task: Create remove_char(s, char) removing all occurrences of char")
print("Example: remove_char('hello', 'l') should return 'heo'")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 18: Count Vowels")
print("-"*60)
print("Task: Create count_vowels(s) counting vowels in string")
print("Example: count_vowels('hello') should return 2")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 19: List Contains")
print("-"*60)
print("Task: Create contains(lst, target) checking if target is in list")
print("Example: contains([1, 2, 3], 2) should return True")
print()
# Write your code below:


print("\n"+"="*60+"\n")

print("Exercise 20: Tower of Hanoi")
print("-"*60)
print("Task: Create hanoi(n, source, dest, aux) solving Tower of Hanoi")
print("Print moves to transfer n disks from source to dest using aux")
print()
# Write your code below:


print("\n"+"="*60+"\n")
print("Exercises completed! Check solutions.py for answers.")
