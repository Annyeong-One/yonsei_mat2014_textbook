"""
Python Recursion - Exercise Solutions
"""

print("="*60)
print("Exercise 1 Solution: Count Down")
print("="*60)

def countdown(n):
    if n <= 0:
        print("Liftoff!")
    else:
        print(n)
        countdown(n - 1)

countdown(5)
print()

print("="*60)
print("Exercise 2 Solution: Sum of Numbers")
print("="*60)

def sum_to_n(n):
    if n == 0:
        return 0
    return n + sum_to_n(n - 1)

print(f"sum_to_n(5) = {sum_to_n(5)}")
print(f"sum_to_n(10) = {sum_to_n(10)}")
print()

print("="*60)
print("Exercise 3 Solution: Factorial")
print("="*60)

def factorial(n):
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print(f"factorial(5) = {factorial(5)}")
print(f"factorial(7) = {factorial(7)}")
print()

print("="*60)
print("Exercise 4 Solution: Power Function")
print("="*60)

def power(base, exp):
    if exp == 0:
        return 1
    return base * power(base, exp - 1)

print(f"power(2, 3) = {power(2, 3)}")
print(f"power(5, 2) = {power(5, 2)}")
print()

print("="*60)
print("Exercise 5 Solution: Count Digits")
print("="*60)

def count_digits(n):
    if n < 10:
        return 1
    return 1 + count_digits(n // 10)

print(f"count_digits(12345) = {count_digits(12345)}")
print(f"count_digits(987654) = {count_digits(987654)}")
print()

print("="*60)
print("Exercise 6 Solution: Reverse String")
print("="*60)

def reverse(s):
    if len(s) <= 1:
        return s
    return s[-1] + reverse(s[:-1])

print(f"reverse('hello') = {reverse('hello')}")
print(f"reverse('Python') = {reverse('Python')}")
print()

print("="*60)
print("Exercise 7 Solution: Sum of List")
print("="*60)

def sum_list(lst):
    if len(lst) == 0:
        return 0
    return lst[0] + sum_list(lst[1:])

print(f"sum_list([1, 2, 3, 4]) = {sum_list([1, 2, 3, 4])}")
print(f"sum_list([10, 20, 30]) = {sum_list([10, 20, 30])}")
print()

print("="*60)
print("Exercise 8 Solution: Fibonacci")
print("="*60)

def fibonacci(n):
    if n == 0:
        return 0
    if n == 1:
        return 1
    return fibonacci(n - 1) + fibonacci(n - 2)

print(f"fibonacci(6) = {fibonacci(6)}")
print(f"fibonacci(10) = {fibonacci(10)}")
print()

print("="*60)
print("Exercise 9 Solution: Greatest Common Divisor")
print("="*60)

def gcd(a, b):
    if b == 0:
        return a
    return gcd(b, a % b)

print(f"gcd(48, 18) = {gcd(48, 18)}")
print(f"gcd(100, 35) = {gcd(100, 35)}")
print()

print("="*60)
print("Exercise 10 Solution: Is Palindrome")
print("="*60)

def is_palindrome(s):
    s = s.lower().replace(" ", "")
    if len(s) <= 1:
        return True
    if s[0] != s[-1]:
        return False
    return is_palindrome(s[1:-1])

print(f"is_palindrome('racecar') = {is_palindrome('racecar')}")
print(f"is_palindrome('hello') = {is_palindrome('hello')}")
print()

print("="*60)
print("Exercise 11 Solution: Count Character")
print("="*60)

def count_char(s, char):
    if len(s) == 0:
        return 0
    count = 1 if s[0] == char else 0
    return count + count_char(s[1:], char)

print(f"count_char('hello', 'l') = {count_char('hello', 'l')}")
print(f"count_char('mississippi', 's') = {count_char('mississippi', 's')}")
print()

print("="*60)
print("Exercise 12 Solution: List Maximum")
print("="*60)

def find_max(lst):
    if len(lst) == 1:
        return lst[0]
    max_rest = find_max(lst[1:])
    return lst[0] if lst[0] > max_rest else max_rest

print(f"find_max([3, 7, 2, 9, 1]) = {find_max([3, 7, 2, 9, 1])}")
print(f"find_max([15, 8, 23, 4]) = {find_max([15, 8, 23, 4])}")
print()

print("="*60)
print("Exercise 13 Solution: Binary String")
print("="*60)

def decimal_to_binary(n):
    if n == 0:
        return '0'
    if n == 1:
        return '1'
    return decimal_to_binary(n // 2) + str(n % 2)

print(f"decimal_to_binary(10) = {decimal_to_binary(10)}")
print(f"decimal_to_binary(15) = {decimal_to_binary(15)}")
print()

print("="*60)
print("Exercise 14 Solution: Flatten List")
print("="*60)

def flatten(lst):
    result = []
    for item in lst:
        if isinstance(item, list):
            result.extend(flatten(item))
        else:
            result.append(item)
    return result

nested = [1, [2, 3], [4, [5]]]
print(f"flatten({nested}) = {flatten(nested)}")
print()

print("="*60)
print("Exercise 15 Solution: Product of Digits")
print("="*60)

def product_of_digits(n):
    if n < 10:
        return n
    return (n % 10) * product_of_digits(n // 10)

print(f"product_of_digits(234) = {product_of_digits(234)}")
print(f"product_of_digits(123) = {product_of_digits(123)}")
print()

print("="*60)
print("Exercise 16 Solution: Range Sum")
print("="*60)

def range_sum(start, end):
    if start > end:
        return 0
    return start + range_sum(start + 1, end)

print(f"range_sum(1, 5) = {range_sum(1, 5)}")
print(f"range_sum(10, 15) = {range_sum(10, 15)}")
print()

print("="*60)
print("Exercise 17 Solution: Remove Character")
print("="*60)

def remove_char(s, char):
    if len(s) == 0:
        return ""
    if s[0] == char:
        return remove_char(s[1:], char)
    return s[0] + remove_char(s[1:], char)

print(f"remove_char('hello', 'l') = {remove_char('hello', 'l')}")
print(f"remove_char('banana', 'a') = {remove_char('banana', 'a')}")
print()

print("="*60)
print("Exercise 18 Solution: Count Vowels")
print("="*60)

def count_vowels(s):
    if len(s) == 0:
        return 0
    vowels = "aeiouAEIOU"
    count = 1 if s[0] in vowels else 0
    return count + count_vowels(s[1:])

print(f"count_vowels('hello') = {count_vowels('hello')}")
print(f"count_vowels('Python') = {count_vowels('Python')}")
print()

print("="*60)
print("Exercise 19 Solution: List Contains")
print("="*60)

def contains(lst, target):
    if len(lst) == 0:
        return False
    if lst[0] == target:
        return True
    return contains(lst[1:], target)

print(f"contains([1, 2, 3], 2) = {contains([1, 2, 3], 2)}")
print(f"contains([1, 2, 3], 5) = {contains([1, 2, 3], 5)}")
print()

print("="*60)
print("Exercise 20 Solution: Tower of Hanoi")
print("="*60)

def hanoi(n, source, dest, aux):
    if n == 1:
        print(f"Move disk 1 from {source} to {dest}")
        return
    hanoi(n-1, source, aux, dest)
    print(f"Move disk {n} from {source} to {dest}")
    hanoi(n-1, aux, dest, source)

print("Tower of Hanoi with 3 disks:")
hanoi(3, 'A', 'C', 'B')
print()

print("="*60)
print("All solutions completed!")
print("="*60)
print("\nKey Takeaways:")
print("✓ Every recursive function needs a base case")
print("✓ Recursive case must move toward base case")
print("✓ Break problem into smaller, similar subproblems")
print("✓ Stack overflow risk with deep recursion")
print("✓ Memoization can optimize repeated calculations")
print("✓ Some problems are naturally recursive (trees, graphs)")
print("✓ Consider iterative alternative for simple cases")
print("✓ Recursion is a powerful problem-solving tool")
