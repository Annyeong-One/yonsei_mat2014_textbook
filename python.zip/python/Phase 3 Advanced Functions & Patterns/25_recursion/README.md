# Python Recursion - Learning Module

## 📚 Contents

1. **01_tutorial.md** - Complete guide to recursion
2. **02_examples.py** - 20 practical demonstrations
3. **03_exercises.py** - 20 hands-on exercises
4. **04_solutions.py** - Detailed solutions with explanations

## 🎯 Learning Objectives

After completing this module, you will be able to:

- ✅ Understand what recursion is and how it works
- ✅ Identify base cases and recursive cases
- ✅ Write recursive functions confidently
- ✅ Understand the call stack
- ✅ Choose between recursion and iteration
- ✅ Optimize recursive functions with memoization
- ✅ Avoid common recursion pitfalls
- ✅ Apply recursion to real problems

## 🚀 How to Use This Module

### Step 1: Read the Tutorial
Start with `01_tutorial.md` - comprehensive coverage of:
- What recursion is
- How recursion works (call stack)
- Base case and recursive case
- Classic recursion examples
- Recursion vs iteration
- Common patterns and pitfalls
- Best practices

### Step 2: Run the Examples
Execute `02_examples.py` to see 20 recursive functions:
```bash
python 02_examples.py
```

### Step 3: Practice
Solve all 20 exercises in `03_exercises.py`

### Step 4: Review
Compare with `04_solutions.py`

## 💡 What is Recursion?

**Recursion** = A function that calls itself

### Simple Example
```python
def countdown(n):
    if n <= 0:          # Base case
        print("Done!")
    else:
        print(n)
        countdown(n-1)   # Recursive call
```

## 📖 Key Concepts Covered

### The Two Essential Parts
1. **Base Case** - Where recursion stops
2. **Recursive Case** - Where function calls itself

### Classic Problems
- Factorial
- Fibonacci
- Binary search
- Tower of Hanoi
- Tree traversal
- String reversal
- List operations

### Advanced Topics
- Memoization
- Tail recursion
- Multiple recursion
- Indirect recursion
- Stack overflow prevention

## ⏱️ Estimated Time

- Tutorial reading: 45-60 minutes
- Examples: 20 minutes
- Exercises: 90-120 minutes
- **Total: ~2.5-3 hours**

## 📋 Prerequisites

Before starting, you should understand:
- ✅ Functions (defining, calling, parameters, return)
- ✅ Control flow (if/else)
- ✅ Loops (for, while)
- ✅ Basic data structures (lists, strings)

## 🎓 Why Recursion Matters

### When Recursion Shines
- **Tree structures** - Navigate file systems, DOM trees
- **Graph algorithms** - Search, pathfinding
- **Divide & conquer** - Merge sort, quick sort
- **Backtracking** - Puzzles, games, constraint problems
- **Mathematical sequences** - Fibonacci, factorial

### Real-World Applications
- File system traversal
- JSON/XML parsing
- Fractal generation
- Game AI (minimax algorithm)
- Parser design (compilers)

## 🎯 Quick Reference

### Recursion Template
```python
def recursive_function(problem):
    # 1. Base case (ALWAYS FIRST!)
    if is_simple_enough(problem):
        return direct_solution
    
    # 2. Make problem simpler
    simpler_problem = reduce(problem)
    
    # 3. Recursive call
    simpler_solution = recursive_function(simpler_problem)
    
    # 4. Build solution
    return combine(problem, simpler_solution)
```

### Common Patterns

**Pattern 1: Linear Recursion**
```python
def sum_list(lst):
    if len(lst) == 0:
        return 0
    return lst[0] + sum_list(lst[1:])
```

**Pattern 2: Binary Recursion**
```python
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)
```

**Pattern 3: Tail Recursion**
```python
def factorial_tail(n, acc=1):
    if n <= 1:
        return acc
    return factorial_tail(n-1, n*acc)
```

## ⚠️ Common Pitfalls

1. **Missing base case** → Infinite recursion
2. **Wrong base case** → Never reached
3. **Not moving toward base** → Infinite loop
4. **Too deep recursion** → Stack overflow
5. **Inefficient recursion** → Use memoization

## 💪 Practice Projects

After completing exercises, try:

1. **File Search** - Find files in nested directories
2. **Expression Evaluator** - Parse and evaluate math expressions
3. **Maze Solver** - Find path through maze recursively
4. **JSON Validator** - Validate nested JSON structure
5. **N-Queens Problem** - Place queens on chessboard

## 🔗 Learning Path Context

```
Variables → Data Types → Operators → 
Control Flow → Loops → Functions → Recursion
                                    ↑ YOU ARE HERE
```

### Where Recursion Fits
- **After Functions** - Need to understand functions first
- **Before Data Structures** - Useful for trees and graphs
- **Foundation for Algorithms** - Many algorithms use recursion

## 📊 Recursion vs Iteration

| Aspect | Recursion | Iteration |
|--------|-----------|-----------|
| **Clarity** | Often clearer for recursive problems | Better for simple loops |
| **Memory** | Uses stack space | Minimal memory |
| **Speed** | Usually slower | Usually faster |
| **Risk** | Stack overflow possible | No such risk |
| **Best for** | Trees, graphs, divide-and-conquer | Sequential processing |

## 🎁 Bonus: Optimization Tips

### Memoization Example
```python
def fib_memo(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    memo[n] = fib_memo(n-1, memo) + fib_memo(n-2, memo)
    return memo[n]
```

### When to Use Iteration Instead
```python
# Recursion (elegant but slower)
def sum_recursive(n):
    if n == 0:
        return 0
    return n + sum_recursive(n-1)

# Iteration (faster for simple cases)
def sum_iterative(n):
    return sum(range(n+1))
```

## 💬 Did You Know?

- **Recursion limit** in Python: ~1000 calls (can be changed)
- **Tail recursion** not optimized in Python
- **Every loop** can be written as recursion
- **Some languages** optimize tail recursion automatically
- **Recursion** is fundamental to functional programming

## 🏆 Challenge Yourself

Master these classic recursion problems:

1. ⭐ **Factorial** - Basic recursion
2. ⭐ **Fibonacci** - Multiple base cases
3. ⭐⭐ **Binary Search** - Divide and conquer
4. ⭐⭐ **Tower of Hanoi** - Classic puzzle
5. ⭐⭐⭐ **N-Queens** - Backtracking
6. ⭐⭐⭐ **Sudoku Solver** - Advanced backtracking

## 📈 Your Progress

After this module, you'll have mastered:
- ✅ Basic programming concepts
- ✅ Control flow and loops
- ✅ Functions
- ✅ **Recursion** ← Current
- 🎯 Next: Data structures (lists, trees, graphs)

## 🎓 Tips for Success

1. **Draw the recursion tree** - Visualize the calls
2. **Start with base case** - Always check stopping condition first
3. **Trust the recursion** - Assume simpler problem is solved
4. **Use small examples** - Test with n=0, n=1, n=2
5. **Practice regularly** - Recursion becomes intuitive with practice

## 🔗 What's Next?

After mastering recursion, you're ready for:
- **Data Structures** - Trees, graphs, linked lists
- **Algorithms** - Sorting, searching, pathfinding
- **Dynamic Programming** - Optimization with memoization
- **Backtracking** - Constraint satisfaction problems

---

**Ready to think recursively?**

Recursion is one of the most powerful concepts in programming. It may feel strange at first, but with practice, you'll recognize recursive patterns everywhere!

Happy Coding! 🐍🔄
