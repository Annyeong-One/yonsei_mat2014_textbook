# Python Closures Tutorial

## What are Closures?

A closure is a function object that has access to variables in its enclosing lexical scope, even when the function is called outside that scope. In simpler terms, a closure is a function that "remembers" the environment in which it was created.

### Real-World Analogy
Think of a closure like a backpack. When you go on a trip (call a function), you pack some items (variables) in your backpack. Even when you're far from home (outside the original scope), you still have access to those items because they're in your backpack. The backpack is your closure!

## Why Use Closures?

- **Data Encapsulation**: Hide implementation details and create private variables
- **Factory Functions**: Generate customized functions
- **Callbacks**: Maintain state in event handlers
- **Decorators**: Closures are the foundation of decorators
- **Functional Programming**: Create higher-order functions

## Basic Concepts

### Nested Functions

Functions defined inside other functions can access the outer function's variables:

```python
def outer():
    message = "Hello"
    
    def inner():
        print(message)  # Can access outer's variable
    
    inner()

outer()  # Output: Hello
```

### Returning Inner Functions

The magic happens when you return the inner function:

```python
def outer():
    message = "Hello"
    
    def inner():
        print(message)
    
    return inner  # Return the function itself, not calling it

my_func = outer()  # my_func is now the inner function
my_func()  # Output: Hello
```

**Key Point**: Even though `outer()` has finished executing, `inner()` still remembers `message`!

## Your First Closure

```python
def make_multiplier(factor):
    def multiply(number):
        return number * factor  # 'factor' is from outer scope
    return multiply

times_2 = make_multiplier(2)
times_3 = make_multiplier(3)

print(times_2(5))  # Output: 10 (5 * 2)
print(times_3(5))  # Output: 15 (5 * 3)
```

Here's what happened:
1. `make_multiplier(2)` creates a closure where `factor = 2`
2. `times_2` is that closure - it remembers `factor = 2`
3. Similarly, `times_3` remembers `factor = 3`
4. Each closure maintains its own separate environment

## How Closures Work

### The LEGB Rule

Python searches for variables in this order:
1. **L**ocal: Inside the current function
2. **E**nclosing: In any enclosing functions
3. **G**lobal: At the module level
4. **B**uilt-in: Python's built-in names

```python
x = "global"

def outer():
    x = "enclosing"
    
    def inner():
        x = "local"
        print(x)  # Prints "local"
    
    inner()

outer()
```

### Free Variables

Variables from the enclosing scope that are used in a closure are called "free variables":

```python
def outer(x):
    # x is a free variable for inner()
    def inner(y):
        return x + y
    return inner

add_5 = outer(5)
print(add_5(3))  # Output: 8
```

### Examining Closures

You can inspect what a closure "remembers":

```python
def make_counter(start):
    count = start
    
    def counter():
        nonlocal count
        count += 1
        return count
    
    return counter

c = make_counter(10)

print(c.__closure__)  # Shows the closure's cells
print(c.__code__.co_freevars)  # Shows free variable names: ('count',)
```

## The `nonlocal` Keyword

To modify variables from the enclosing scope, use `nonlocal`:

```python
def make_counter():
    count = 0
    
    def counter():
        nonlocal count  # Without this, count would be local
        count += 1
        return count
    
    return counter

c = make_counter()
print(c())  # 1
print(c())  # 2
print(c())  # 3
```

**Without `nonlocal`:**
```python
def make_counter():
    count = 0
    
    def counter():
        count += 1  # Error! Can't modify count without nonlocal
        return count
    
    return counter
```

## Common Closure Patterns

### 1. Factory Functions

Create specialized functions:

```python
def make_power(exponent):
    def power(base):
        return base ** exponent
    return power

square = make_power(2)
cube = make_power(3)

print(square(4))  # 16
print(cube(4))   # 64
```

### 2. Data Encapsulation

Create private variables:

```python
def make_account(initial_balance):
    balance = initial_balance  # Private variable
    
    def get_balance():
        return balance
    
    def deposit(amount):
        nonlocal balance
        balance += amount
        return balance
    
    def withdraw(amount):
        nonlocal balance
        if amount > balance:
            return "Insufficient funds"
        balance -= amount
        return balance
    
    return {
        'get_balance': get_balance,
        'deposit': deposit,
        'withdraw': withdraw
    }

account = make_account(100)
print(account['get_balance']())  # 100
print(account['deposit'](50))    # 150
print(account['withdraw'](30))   # 120
```

### 3. Function Configuration

Store configuration in closures:

```python
def make_formatter(prefix, suffix):
    def format_string(text):
        return f"{prefix}{text}{suffix}"
    return format_string

html_bold = make_formatter("<b>", "</b>")
html_italic = make_formatter("<i>", "</i>")

print(html_bold("Hello"))    # <b>Hello</b>
print(html_italic("World"))  # <i>World</i>
```

### 4. Callbacks with State

Maintain state in event handlers:

```python
def make_click_handler(element_id):
    click_count = 0
    
    def handle_click():
        nonlocal click_count
        click_count += 1
        print(f"Element {element_id} clicked {click_count} times")
    
    return handle_click

button1_handler = make_click_handler("button1")
button2_handler = make_click_handler("button2")

button1_handler()  # Element button1 clicked 1 times
button1_handler()  # Element button1 clicked 2 times
button2_handler()  # Element button2 clicked 1 times
```

### 5. Memoization/Caching

Cache expensive computations:

```python
def make_memoized_function(func):
    cache = {}
    
    def memoized(*args):
        if args not in cache:
            cache[args] = func(*args)
        return cache[args]
    
    return memoized

@make_memoized_function
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))  # Computed once and cached
```

## Closures vs Classes

Closures and classes can sometimes be used interchangeably:

### Using a Class
```python
class Multiplier:
    def __init__(self, factor):
        self.factor = factor
    
    def multiply(self, number):
        return number * self.factor

times_2 = Multiplier(2)
print(times_2.multiply(5))  # 10
```

### Using a Closure
```python
def make_multiplier(factor):
    def multiply(number):
        return number * factor
    return multiply

times_2 = make_multiplier(2)
print(times_2(5))  # 10
```

**When to use which:**
- **Closure**: Simple, single-method behavior
- **Class**: Multiple methods, complex state, inheritance needed

## Multiple Closures Sharing State

Multiple closures can share the same variables:

```python
def make_counter():
    count = 0
    
    def increment():
        nonlocal count
        count += 1
        return count
    
    def decrement():
        nonlocal count
        count -= 1
        return count
    
    def get_count():
        return count
    
    return increment, decrement, get_count

inc, dec, get = make_counter()
print(inc())  # 1
print(inc())  # 2
print(dec())  # 1
print(get())  # 1
```

## Closures in Loops (Common Pitfall)

### The Problem
```python
def create_multipliers():
    multipliers = []
    for i in range(5):
        multipliers.append(lambda x: x * i)
    return multipliers

funcs = create_multipliers()
print(funcs[0](2))  # Expected: 0, Actual: 8
print(funcs[1](2))  # Expected: 2, Actual: 8
print(funcs[2](2))  # Expected: 4, Actual: 8
```

**Why?** All closures reference the same `i`, which is 4 after the loop!

### Solution 1: Default Arguments
```python
def create_multipliers():
    multipliers = []
    for i in range(5):
        multipliers.append(lambda x, i=i: x * i)  # Capture i's current value
    return multipliers

funcs = create_multipliers()
print(funcs[0](2))  # 0
print(funcs[1](2))  # 2
print(funcs[2](2))  # 4
```

### Solution 2: Factory Function
```python
def make_multiplier(i):
    return lambda x: x * i

def create_multipliers():
    return [make_multiplier(i) for i in range(5)]

funcs = create_multipliers()
print(funcs[0](2))  # 0
print(funcs[1](2))  # 2
print(funcs[2](2))  # 4
```

## Closures and Decorators

Decorators are built on closures:

```python
def make_logger(func):
    def wrapper(*args, **kwargs):
        # wrapper is a closure that remembers func
        print(f"Calling {func.__name__}")
        result = func(*args, **kwargs)
        print(f"Finished {func.__name__}")
        return result
    return wrapper

@make_logger
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")
# Output:
# Calling greet
# Hello, Alice!
# Finished greet
```

## Advanced Patterns

### 1. Partial Application

Create specialized versions of functions:

```python
def partial(func, *fixed_args):
    def wrapper(*args):
        return func(*fixed_args, *args)
    return wrapper

def power(base, exponent):
    return base ** exponent

square = partial(power, exponent=2)
cube = partial(power, exponent=3)

print(square(4))  # 16
print(cube(4))    # 64
```

### 2. Function Composition

Combine functions:

```python
def compose(f, g):
    def composed(x):
        return f(g(x))
    return composed

def double(x):
    return x * 2

def add_10(x):
    return x + 10

double_then_add_10 = compose(add_10, double)
print(double_then_add_10(5))  # 20 (5*2 + 10)
```

### 3. Lazy Evaluation

Delay computation until needed:

```python
def lazy_property(func):
    name = '_lazy_' + func.__name__
    
    def wrapper(self):
        if not hasattr(self, name):
            setattr(self, name, func(self))
        return getattr(self, name)
    
    return property(wrapper)

class Circle:
    def __init__(self, radius):
        self.radius = radius
    
    @lazy_property
    def area(self):
        print("Computing area...")
        return 3.14159 * self.radius ** 2

c = Circle(5)
print(c.area)  # Computing area... 78.53975
print(c.area)  # 78.53975 (cached, no computation)
```

## Best Practices

1. **Keep it Simple**: Closures should be easy to understand
2. **Use `nonlocal` Carefully**: Only when you need to modify outer variables
3. **Document Free Variables**: Make it clear what the closure captures
4. **Avoid Deep Nesting**: More than 2-3 levels gets confusing
5. **Consider Classes**: For complex state, classes might be clearer
6. **Watch Loop Variables**: Use default arguments or factory functions

## Common Use Cases

### 1. Configuration
```python
def make_api_client(api_key, base_url):
    def request(endpoint):
        return f"Request to {base_url}{endpoint} with key {api_key}"
    return request
```

### 2. Event Handlers
```python
def make_button_handler(button_id):
    clicks = 0
    def on_click():
        nonlocal clicks
        clicks += 1
        print(f"{button_id} clicked {clicks} times")
    return on_click
```

### 3. Rate Limiting
```python
def make_rate_limiter(max_calls, time_window):
    calls = []
    def limited_function(func):
        # Implementation using closure
        pass
    return limited_function
```

## Summary

**Closures are:**
- Functions that remember their enclosing scope
- Created when a nested function references outer variables
- Useful for data encapsulation and factory functions
- The foundation of decorators

**Key concepts:**
- Free variables: Variables from enclosing scope
- `nonlocal`: Keyword to modify enclosing variables
- LEGB rule: Variable lookup order
- Function objects carry their environment

**When to use:**
- ✅ Simple state management
- ✅ Factory functions
- ✅ Callbacks with memory
- ✅ Decorators
- ✅ Functional programming patterns

**When NOT to use:**
- ❌ Complex state (use classes)
- ❌ Many methods (use classes)
- ❌ Need inheritance (use classes)
- ❌ When it hurts readability
