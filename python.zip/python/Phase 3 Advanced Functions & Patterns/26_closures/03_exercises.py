"""
Python Closures - Practice Exercises

Complete these exercises to practice creating and using closures.
Try to solve them on your own before checking the solutions file!
"""

print("=" * 70)
print("PYTHON CLOSURES - PRACTICE EXERCISES")
print("=" * 70)

# ========================================================================
# EXERCISE 1: Basic Closure
# ========================================================================
print("\nEXERCISE 1: Basic Closure")
print("-" * 70)
print("Create a function 'make_greeting' that takes a greeting word")
print("and returns a function that greets people with that greeting.")

# Your code here:
# def make_greeting(greeting):
#     # Your implementation
#     pass

# Test your function:
# say_hello = make_greeting("Hello")
# say_hi = make_greeting("Hi")
# print(say_hello("Alice"))  # Expected: Hello, Alice!
# print(say_hi("Bob"))       # Expected: Hi, Bob!

# ========================================================================
# EXERCISE 2: Simple Counter
# ========================================================================
print("\n\nEXERCISE 2: Simple Counter")
print("-" * 70)
print("Create a function 'make_counter' that returns a function that")
print("increments and returns a count each time it's called.")

# Your code here:
# def make_counter():
#     # Your implementation
#     pass

# Test your function:
# counter = make_counter()
# print(counter())  # Expected: 1
# print(counter())  # Expected: 2
# print(counter())  # Expected: 3

# ========================================================================
# EXERCISE 3: Adder Function
# ========================================================================
print("\n\nEXERCISE 3: Adder Function")
print("-" * 70)
print("Create a function 'make_adder' that takes a number and returns")
print("a function that adds that number to its argument.")

# Your code here:
# def make_adder(n):
#     # Your implementation
#     pass

# Test your function:
# add_5 = make_adder(5)
# add_10 = make_adder(10)
# print(add_5(3))   # Expected: 8
# print(add_10(3))  # Expected: 13

# ========================================================================
# EXERCISE 4: Math Operations
# ========================================================================
print("\n\nEXERCISE 4: Math Operations")
print("-" * 70)
print("Create a function 'make_operation' that takes an operator string")
print("('+', '-', '*', '/') and returns a function that performs that operation.")

# Your code here:
# def make_operation(operator):
#     # Your implementation
#     pass

# Test your function:
# add = make_operation('+')
# subtract = make_operation('-')
# multiply = make_operation('*')
# print(add(5, 3))       # Expected: 8
# print(subtract(10, 4)) # Expected: 6
# print(multiply(3, 7))  # Expected: 21

# ========================================================================
# EXERCISE 5: Range Checker
# ========================================================================
print("\n\nEXERCISE 5: Range Checker")
print("-" * 70)
print("Create a function 'make_range_checker' that takes min and max values")
print("and returns a function that checks if a number is in that range.")

# Your code here:
# def make_range_checker(min_val, max_val):
#     # Your implementation
#     pass

# Test your function:
# is_teen = make_range_checker(13, 19)
# is_adult = make_range_checker(18, 65)
# print(is_teen(15))   # Expected: True
# print(is_teen(25))   # Expected: False
# print(is_adult(30))  # Expected: True

# ========================================================================
# EXERCISE 6: Bank Account
# ========================================================================
print("\n\nEXERCISE 6: Bank Account")
print("-" * 70)
print("Create a function 'make_bank_account' that takes an initial balance")
print("and returns a dictionary with 'deposit', 'withdraw', and 'balance' functions.")

# Your code here:
# def make_bank_account(initial_balance):
#     # Your implementation
#     pass

# Test your function:
# account = make_bank_account(100)
# print(account['balance']())     # Expected: 100
# account['deposit'](50)
# print(account['balance']())     # Expected: 150
# account['withdraw'](30)
# print(account['balance']())     # Expected: 120

# ========================================================================
# EXERCISE 7: String Formatter
# ========================================================================
print("\n\nEXERCISE 7: String Formatter")
print("-" * 70)
print("Create a function 'make_formatter' that takes prefix and suffix")
print("and returns a function that formats text with those.")

# Your code here:
# def make_formatter(prefix, suffix):
#     # Your implementation
#     pass

# Test your function:
# bold = make_formatter("<b>", "</b>")
# italic = make_formatter("<i>", "</i>")
# print(bold("Hello"))    # Expected: <b>Hello</b>
# print(italic("World"))  # Expected: <i>World</i>

# ========================================================================
# EXERCISE 8: Average Calculator
# ========================================================================
print("\n\nEXERCISE 8: Average Calculator")
print("-" * 70)
print("Create a function 'make_averager' that returns a function")
print("that calculates the running average of numbers passed to it.")
print("Hint: Keep a list of all numbers in the closure.")

# Your code here:
# def make_averager():
#     # Your implementation
#     pass

# Test your function:
# avg = make_averager()
# print(avg(10))      # Expected: 10.0
# print(avg(20))      # Expected: 15.0
# print(avg(30))      # Expected: 20.0

# ========================================================================
# EXERCISE 9: Timer
# ========================================================================
print("\n\nEXERCISE 9: Timer")
print("-" * 70)
print("Create a function 'make_timer' that returns two functions:")
print("'start' to start timing and 'stop' to return elapsed time in seconds.")
print("Hint: Use the time module and nonlocal.")

# Your code here:
# import time
# def make_timer():
#     # Your implementation
#     pass

# Test your function:
# start, stop = make_timer()
# start()
# time.sleep(1)
# print(f"Elapsed: {stop():.2f} seconds")  # Expected: ~1.00 seconds

# ========================================================================
# EXERCISE 10: History Tracker
# ========================================================================
print("\n\nEXERCISE 10: History Tracker")
print("-" * 70)
print("Create a function 'make_history_tracker' that returns a function")
print("that tracks all values passed to it and returns them as a list.")

# Your code here:
# def make_history_tracker():
#     # Your implementation
#     pass

# Test your function:
# tracker = make_history_tracker()
# tracker(10)
# tracker(20)
# tracker(30)
# print(tracker())  # Expected: [10, 20, 30]

# ========================================================================
# EXERCISE 11: Multiplier List (Loop Pitfall)
# ========================================================================
print("\n\nEXERCISE 11: Multiplier List (Loop Pitfall)")
print("-" * 70)
print("Create a function 'make_multipliers' that returns a list of functions.")
print("Each function should multiply its argument by its index (0, 1, 2, ...).")
print("Fix the common closure-in-loop pitfall!")

# Your code here:
# def make_multipliers(n):
#     # Your implementation
#     pass

# Test your function:
# multipliers = make_multipliers(5)
# print(multipliers[0](10))  # Expected: 0
# print(multipliers[1](10))  # Expected: 10
# print(multipliers[2](10))  # Expected: 20

# ========================================================================
# EXERCISE 12: Function Cache
# ========================================================================
print("\n\nEXERCISE 12: Function Cache")
print("-" * 70)
print("Create a function 'make_cached' that takes a function and returns")
print("a cached version that stores results for seen arguments.")

# Your code here:
# def make_cached(func):
#     # Your implementation
#     pass

# Test your function:
# @make_cached
# def slow_square(x):
#     print(f"Computing {x}^2...")
#     return x ** 2

# print(slow_square(5))  # Should print "Computing 5^2..." and return 25
# print(slow_square(5))  # Should return 25 without printing (cached)
# print(slow_square(3))  # Should print "Computing 3^2..." and return 9

# ========================================================================
# EXERCISE 13: Click Counter with Reset
# ========================================================================
print("\n\nEXERCISE 13: Click Counter with Reset")
print("-" * 70)
print("Create a function 'make_click_counter' that returns three functions:")
print("'click' (increments count), 'count' (returns count), 'reset' (resets to 0).")

# Your code here:
# def make_click_counter():
#     # Your implementation
#     pass

# Test your function:
# click, get_count, reset = make_click_counter()
# click()
# click()
# print(get_count())  # Expected: 2
# click()
# print(get_count())  # Expected: 3
# reset()
# print(get_count())  # Expected: 0

# ========================================================================
# EXERCISE 14: Partial Application
# ========================================================================
print("\n\nEXERCISE 14: Partial Application")
print("-" * 70)
print("Create a function 'partial' that takes a function and some arguments,")
print("and returns a new function with those arguments pre-filled.")

# Your code here:
# def partial(func, *fixed_args):
#     # Your implementation
#     pass

# Test your function:
# def power(base, exponent):
#     return base ** exponent

# square = partial(power, exponent=2)
# cube = partial(power, exponent=3)
# print(square(4))  # Expected: 16
# print(cube(4))    # Expected: 64

# ========================================================================
# EXERCISE 15: Challenge - Rate Limiter
# ========================================================================
print("\n\nEXERCISE 15: Challenge - Rate Limiter")
print("-" * 70)
print("Create a function 'make_rate_limiter' that takes max_calls and time_period,")
print("and returns a function that only allows max_calls in that time period.")
print("Extra calls should return None.")

# Your code here:
# import time
# def make_rate_limiter(max_calls, time_period):
#     # Your implementation
#     pass

# Test your function:
# limited_print = make_rate_limiter(2, 1)  # 2 calls per second
# for i in range(4):
#     result = limited_print(lambda: f"Call {i}")
#     if result:
#         print(result)
#     time.sleep(0.3)

# Expected: First 2 calls succeed, 3rd is blocked, 4th succeeds

# ========================================================================
# EXERCISE 16: Challenge - Lazy Evaluation
# ========================================================================
print("\n\nEXERCISE 16: Challenge - Lazy Evaluation")
print("-" * 70)
print("Create a function 'make_lazy' that takes a function and returns")
print("a function that only computes the result on first call, then caches it.")

# Your code here:
# def make_lazy(func):
#     # Your implementation
#     pass

# Test your function:
# @make_lazy
# def expensive_calculation():
#     print("Computing...")
#     return sum(range(1000000))

# print(expensive_calculation())  # Prints "Computing..." and result
# print(expensive_calculation())  # Just returns cached result

print("\n" + "=" * 70)
print("END OF EXERCISES - Check solutions.py when you're done!")
print("=" * 70)
