"""
Python Closures - Practice Exercise Solutions

Here are the solutions to the practice exercises.
Try to solve them yourself first before looking at these!
"""

import time

print("=" * 70)
print("PYTHON CLOSURES - SOLUTIONS")
print("=" * 70)

# ========================================================================
# EXERCISE 1: Basic Closure
# ========================================================================
print("\nEXERCISE 1: Basic Closure")
print("-" * 70)

def make_greeting(greeting):
    def greet(name):
        return f"{greeting}, {name}!"
    return greet

say_hello = make_greeting("Hello")
say_hi = make_greeting("Hi")
print(say_hello("Alice"))
print(say_hi("Bob"))

# ========================================================================
# EXERCISE 2: Simple Counter
# ========================================================================
print("\n\nEXERCISE 2: Simple Counter")
print("-" * 70)

def make_counter():
    count = 0
    
    def counter():
        nonlocal count
        count += 1
        return count
    
    return counter

counter = make_counter()
print(counter())  # 1
print(counter())  # 2
print(counter())  # 3

# ========================================================================
# EXERCISE 3: Adder Function
# ========================================================================
print("\n\nEXERCISE 3: Adder Function")
print("-" * 70)

def make_adder(n):
    def add(x):
        return x + n
    return add

add_5 = make_adder(5)
add_10 = make_adder(10)
print(add_5(3))   # 8
print(add_10(3))  # 13

# ========================================================================
# EXERCISE 4: Math Operations
# ========================================================================
print("\n\nEXERCISE 4: Math Operations")
print("-" * 70)

def make_operation(operator):
    def operation(a, b):
        if operator == '+':
            return a + b
        elif operator == '-':
            return a - b
        elif operator == '*':
            return a * b
        elif operator == '/':
            return a / b if b != 0 else "Division by zero"
    return operation

add = make_operation('+')
subtract = make_operation('-')
multiply = make_operation('*')
print(add(5, 3))       # 8
print(subtract(10, 4)) # 6
print(multiply(3, 7))  # 21

# ========================================================================
# EXERCISE 5: Range Checker
# ========================================================================
print("\n\nEXERCISE 5: Range Checker")
print("-" * 70)

def make_range_checker(min_val, max_val):
    def in_range(value):
        return min_val <= value <= max_val
    return in_range

is_teen = make_range_checker(13, 19)
is_adult = make_range_checker(18, 65)
print(is_teen(15))   # True
print(is_teen(25))   # False
print(is_adult(30))  # True

# ========================================================================
# EXERCISE 6: Bank Account
# ========================================================================
print("\n\nEXERCISE 6: Bank Account")
print("-" * 70)

def make_bank_account(initial_balance):
    balance = initial_balance
    
    def deposit(amount):
        nonlocal balance
        balance += amount
    
    def withdraw(amount):
        nonlocal balance
        if amount <= balance:
            balance -= amount
        else:
            print("Insufficient funds")
    
    def get_balance():
        return balance
    
    return {
        'deposit': deposit,
        'withdraw': withdraw,
        'balance': get_balance
    }

account = make_bank_account(100)
print(account['balance']())     # 100
account['deposit'](50)
print(account['balance']())     # 150
account['withdraw'](30)
print(account['balance']())     # 120

# ========================================================================
# EXERCISE 7: String Formatter
# ========================================================================
print("\n\nEXERCISE 7: String Formatter")
print("-" * 70)

def make_formatter(prefix, suffix):
    def format_text(text):
        return f"{prefix}{text}{suffix}"
    return format_text

bold = make_formatter("<b>", "</b>")
italic = make_formatter("<i>", "</i>")
print(bold("Hello"))    # <b>Hello</b>
print(italic("World"))  # <i>World</i>

# ========================================================================
# EXERCISE 8: Average Calculator
# ========================================================================
print("\n\nEXERCISE 8: Average Calculator")
print("-" * 70)

def make_averager():
    numbers = []
    
    def averager(number):
        numbers.append(number)
        return sum(numbers) / len(numbers)
    
    return averager

avg = make_averager()
print(avg(10))      # 10.0
print(avg(20))      # 15.0
print(avg(30))      # 20.0

# ========================================================================
# EXERCISE 9: Timer
# ========================================================================
print("\n\nEXERCISE 9: Timer")
print("-" * 70)

def make_timer():
    start_time = None
    
    def start():
        nonlocal start_time
        start_time = time.time()
    
    def stop():
        if start_time is None:
            return "Timer not started"
        return time.time() - start_time
    
    return start, stop

start_timer, stop_timer = make_timer()
start_timer()
time.sleep(0.5)
elapsed = stop_timer()
print(f"Elapsed: {elapsed:.2f} seconds")

# ========================================================================
# EXERCISE 10: History Tracker
# ========================================================================
print("\n\nEXERCISE 10: History Tracker")
print("-" * 70)

def make_history_tracker():
    history = []
    
    def tracker(value=None):
        if value is None:
            return history.copy()
        history.append(value)
    
    return tracker

tracker = make_history_tracker()
tracker(10)
tracker(20)
tracker(30)
print(tracker())  # [10, 20, 30]

# ========================================================================
# EXERCISE 11: Multiplier List (Loop Pitfall)
# ========================================================================
print("\n\nEXERCISE 11: Multiplier List (Loop Pitfall)")
print("-" * 70)

# Solution 1: Using default argument
def make_multipliers_v1(n):
    return [lambda x, i=i: x * i for i in range(n)]

# Solution 2: Using factory function
def make_multiplier(i):
    return lambda x: x * i

def make_multipliers_v2(n):
    return [make_multiplier(i) for i in range(n)]

multipliers = make_multipliers_v1(5)
print(multipliers[0](10))  # 0
print(multipliers[1](10))  # 10
print(multipliers[2](10))  # 20

# ========================================================================
# EXERCISE 12: Function Cache
# ========================================================================
print("\n\nEXERCISE 12: Function Cache")
print("-" * 70)

def make_cached(func):
    cache = {}
    
    def cached_func(*args):
        if args in cache:
            return cache[args]
        result = func(*args)
        cache[args] = result
        return result
    
    return cached_func

@make_cached
def slow_square(x):
    print(f"Computing {x}^2...")
    return x ** 2

print(slow_square(5))  # Prints "Computing 5^2..." and returns 25
print(slow_square(5))  # Returns 25 without printing (cached)
print(slow_square(3))  # Prints "Computing 3^2..." and returns 9

# ========================================================================
# EXERCISE 13: Click Counter with Reset
# ========================================================================
print("\n\nEXERCISE 13: Click Counter with Reset")
print("-" * 70)

def make_click_counter():
    count = 0
    
    def click():
        nonlocal count
        count += 1
    
    def get_count():
        return count
    
    def reset():
        nonlocal count
        count = 0
    
    return click, get_count, reset

click, get_count, reset = make_click_counter()
click()
click()
print(get_count())  # 2
click()
print(get_count())  # 3
reset()
print(get_count())  # 0

# ========================================================================
# EXERCISE 14: Partial Application
# ========================================================================
print("\n\nEXERCISE 14: Partial Application")
print("-" * 70)

def partial(func, *fixed_args, **fixed_kwargs):
    def wrapper(*args, **kwargs):
        return func(*fixed_args, *args, **fixed_kwargs, **kwargs)
    return wrapper

def power(base, exponent):
    return base ** exponent

square = partial(power, exponent=2)
cube = partial(power, exponent=3)
print(square(4))  # 16
print(cube(4))    # 64

# ========================================================================
# EXERCISE 15: Challenge - Rate Limiter
# ========================================================================
print("\n\nEXERCISE 15: Challenge - Rate Limiter")
print("-" * 70)

def make_rate_limiter(max_calls, time_period):
    call_times = []
    
    def rate_limited(func):
        nonlocal call_times
        now = time.time()
        
        # Remove old calls outside the time window
        call_times = [t for t in call_times if now - t < time_period]
        
        if len(call_times) >= max_calls:
            return None
        
        call_times.append(now)
        return func()
    
    return rate_limited

print("Making 4 calls (limit is 2 per second):")
limited_print = make_rate_limiter(2, 1)
for i in range(4):
    result = limited_print(lambda i=i: f"Call {i}")
    if result:
        print(f"  {result}")
    else:
        print(f"  Call {i} blocked (rate limit)")
    time.sleep(0.3)

# ========================================================================
# EXERCISE 16: Challenge - Lazy Evaluation
# ========================================================================
print("\n\nEXERCISE 16: Challenge - Lazy Evaluation")
print("-" * 70)

def make_lazy(func):
    cached_result = None
    computed = False
    
    def lazy_func(*args, **kwargs):
        nonlocal cached_result, computed
        if not computed:
            cached_result = func(*args, **kwargs)
            computed = True
        return cached_result
    
    return lazy_func

@make_lazy
def expensive_calculation():
    print("Computing...")
    return sum(range(100000))

print(f"Result: {expensive_calculation()}")  # Prints "Computing..." and result
print(f"Result: {expensive_calculation()}")  # Just returns cached result

print("\n" + "=" * 70)
print("END OF SOLUTIONS")
print("=" * 70)

# ========================================================================
# BONUS: Additional Insights
# ========================================================================
print("\n\nBONUS INSIGHTS:")
print("-" * 70)
print("""
Key Takeaways About Closures:

1. **Definition**: A closure is a function that remembers its enclosing scope
   - The inner function captures variables from the outer function
   - These variables persist even after the outer function returns

2. **Creating Closures**:
   - Define a function inside another function
   - Have the inner function reference outer variables
   - Return the inner function

3. **The nonlocal Keyword**:
   - Use it to modify variables from the enclosing scope
   - Without it, assignment creates a new local variable
   - Only needed for reassignment, not for reading

4. **Common Pitfall - Loops**:
   - Variables in loops are shared by all closures
   - Use default arguments: lambda x, i=i: x * i
   - Or use factory functions to create separate scopes

5. **When to Use Closures**:
   ✓ Data encapsulation (private variables)
   ✓ Factory functions (creating specialized functions)
   ✓ Callbacks with state
   ✓ Simple stateful behavior
   ✓ Decorators

6. **When NOT to Use Closures**:
   ✗ Complex state management (use classes)
   ✗ Multiple methods (use classes)
   ✗ Need for inheritance
   ✗ When it hurts readability

7. **Closure vs Class**:
   - Closures: Simpler, for single-method behavior
   - Classes: Better for multiple methods, complex state

8. **Memory Considerations**:
   - Closures keep references to outer variables
   - This can prevent garbage collection
   - Be mindful with large data structures

9. **Debugging Tips**:
   - Use func.__closure__ to inspect captured variables
   - Use func.__code__.co_freevars to see variable names
   - Print statements in inner functions help trace execution

10. **Best Practices**:
    - Keep closures simple and focused
    - Use descriptive names for enclosed variables
    - Document what variables are captured
    - Avoid deep nesting (2-3 levels max)
    - Consider classes for complex scenarios

Real-World Applications:
- Decorators (timing, logging, caching)
- Event handlers with state
- API clients with configuration
- Factory functions for specialized behavior
- Functional programming patterns
- Plugin systems
- Configuration management

Practice Tip:
Try refactoring some of your class-based code to use closures,
or vice versa. This will help you understand when each approach
is more appropriate!
""")
