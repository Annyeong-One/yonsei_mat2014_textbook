# Python Closures - Learning Materials

Welcome to the Python Closures learning module! This comprehensive package will teach you everything you need to know about closures - one of Python's most powerful features that enables decorators, callbacks, and elegant functional programming.

## 📦 Package Contents

### 1. **01_closures_tutorial.md**
A comprehensive tutorial covering:
- What closures are and why they're useful
- How closures work (LEGB rule, free variables)
- Creating your first closure
- The `nonlocal` keyword
- Common closure patterns (factories, encapsulation, callbacks)
- Closures vs classes
- Multiple closures sharing state
- Loop pitfalls and solutions
- Closures and decorators
- Advanced patterns (partial application, composition)
- Best practices

### 2. **02_examples.py**
15 practical, runnable examples demonstrating:
- Basic closures
- Multiple closures with different environments
- Using `nonlocal` to modify variables
- Factory functions
- Data encapsulation (private variables)
- Function decorators
- Configuration functions
- Closures with multiple free variables
- Callbacks with state
- Closure vs class comparison
- Loop pitfalls and solutions
- Memoization
- Partial application
- Function composition
- Stateful generators

**To run:** `python 02_examples.py`

### 3. **03_exercises.py**
16 practice exercises organized by difficulty:
- Basic closures (greeting, counter, adder)
- Math operations and range checkers
- Bank account with private variables
- String formatters
- Average calculator
- Timer implementation
- History tracker
- Loop pitfall exercise
- Function cache
- Click counter with reset
- Partial application
- Challenge: Rate limiter
- Challenge: Lazy evaluation

**To use:** Try to complete each exercise before checking the solutions!

### 4. **04_solutions.py**
Complete solutions to all exercises with:
- Working code for each problem
- Multiple solution approaches where applicable
- Detailed explanations
- Bonus insights and tips
- Best practices demonstrated
- Real-world applications

**To run:** `python 04_solutions.py`

### 5. **05_cheat_sheet.md**
Quick reference guide with:
- Closure definition and basic template
- The `nonlocal` keyword
- Common patterns (6 key patterns)
- LEGB rule explained
- Loop pitfall solutions
- Closures vs classes comparison
- Inspecting closures
- Best practices table
- Quick reference for common use cases

## 🎯 Learning Path

### For Beginners:
1. **Start here:** Read `01_closures_tutorial.md` thoroughly
2. Understand nested functions and how they capture variables
3. Run `02_examples.py` and study the output carefully
4. Try exercises 1-7 in `03_exercises.py`
5. Check your work against `04_solutions.py`
6. Keep `05_cheat_sheet.md` handy for quick reference

### For Intermediate Learners:
1. Review `01_closures_tutorial.md` (focus on advanced patterns)
2. Study the examples in `02_examples.py`
3. Complete exercises 8-14 in `03_exercises.py`
4. Try the challenge problems (15-16)
5. Experiment with creating your own closures

### For Quick Review:
1. Start with `05_cheat_sheet.md`
2. Run `02_examples.py` to refresh your memory
3. Review specific patterns you need in the tutorial

## 💡 Key Concepts Covered

### Fundamentals
- **Nested functions**: Functions inside functions
- **Free variables**: Variables from enclosing scope
- **Closure creation**: When inner functions capture outer variables
- **LEGB rule**: Variable lookup order (Local, Enclosing, Global, Built-in)
- **nonlocal keyword**: Modifying enclosing variables

### Core Patterns
- **Factory functions**: Create specialized functions
- **Data encapsulation**: Private variables without classes
- **Callbacks with state**: Event handlers that remember
- **Configuration**: Store settings in closures
- **Memoization**: Cache expensive computations
- **Counters and accumulators**: Maintain state between calls

### Advanced Topics
- **Partial application**: Pre-fill function arguments
- **Function composition**: Combine functions
- **Lazy evaluation**: Delay computation
- **Closures vs classes**: When to use which
- **Loop variables**: Common pitfall and solutions
- **Decorators**: Built on closures

## 🔧 Requirements

- Python 3.x
- No external packages required (uses only standard library)
- time module (built-in)

## 📝 Tips for Success

1. **Understand Scope First**: Make sure you're comfortable with variable scope before diving into closures
2. **Visualize the "Backpack"**: Think of closures as functions carrying a backpack of variables
3. **Practice with Simple Examples**: Start with basic counters and adders before moving to complex patterns
4. **Use print() Liberally**: Print variables to understand what's being captured
5. **Compare with Classes**: Try implementing the same functionality with both closures and classes
6. **Watch for Loop Variables**: This is the #1 pitfall - practice the solutions
7. **Experiment**: Modify examples to see what happens

## 🎓 Learning Objectives

After completing this module, you should be able to:
- ✅ Explain what closures are and how they work
- ✅ Create closures that capture variables from enclosing scope
- ✅ Use the `nonlocal` keyword appropriately
- ✅ Implement common closure patterns (factories, encapsulation, callbacks)
- ✅ Understand and avoid the loop variable pitfall
- ✅ Know when to use closures vs classes
- ✅ Inspect closures to see captured variables
- ✅ Use closures to create decorators
- ✅ Apply closures in real-world scenarios
- ✅ Debug closure-related issues

## 🚀 Next Steps

After mastering closures, you'll have a solid foundation for:
- **Decorators**: Now you'll understand how they really work!
- **Functional programming**: Map, filter, reduce with closures
- **Callback patterns**: Event-driven programming
- **Generator expressions**: Similar closure-like behavior
- **Context managers**: Another use of closures
- **Plugin architectures**: Dynamic behavior with closures

## 📚 Additional Resources

- Python Official Documentation: https://docs.python.org/3/faq/programming.html#what-are-closures
- PEP 227 - Statically Nested Scopes: https://www.python.org/dev/peps/pep-0227/
- Real Python Closures Tutorial: https://realpython.com/inner-functions-what-are-they-good-for/
- Python Scope & LEGB Rule: https://realpython.com/python-scope-legb-rule/

## ❓ Common Questions

**Q: What's the difference between a closure and a nested function?**
A: All closures are nested functions, but not all nested functions are closures. A closure specifically captures and remembers variables from the enclosing scope.

**Q: When should I use closures instead of classes?**
A: Use closures for simple, single-method behavior. Use classes for complex state, multiple methods, or when you need inheritance.

**Q: Why do I need the `nonlocal` keyword?**
A: Python needs to know you want to modify a variable from the enclosing scope, not create a new local variable with the same name.

**Q: What's the difference between `global` and `nonlocal`?**
A: `global` refers to module-level variables, `nonlocal` refers to variables in enclosing function scopes.

**Q: Can closures access variables from multiple levels up?**
A: Yes! A closure can access variables from all enclosing scopes, not just the immediate parent.

**Q: Do closures cause memory leaks?**
A: They can if you're not careful. Closures keep references to captured variables, preventing garbage collection. Be mindful with large objects.

**Q: How do I see what variables a closure has captured?**
A: Use `func.__closure__` and `func.__code__.co_freevars` to inspect captured variables.

**Q: Why does my closure in a loop behave strangely?**
A: This is the classic loop variable pitfall! All closures share the same loop variable. Use default arguments or factory functions to fix it.

## 🌟 Real-World Examples

Closures are used extensively in Python:

### Event Handlers
```python
def make_button_handler(button_id):
    clicks = 0
    def on_click():
        nonlocal clicks
        clicks += 1
        print(f"{button_id}: {clicks} clicks")
    return on_click
```

### API Clients
```python
def make_api_client(api_key, base_url):
    def request(endpoint):
        # api_key and base_url are captured
        return f"{base_url}{endpoint}?key={api_key}"
    return request
```

### Decorators
```python
def timer(func):
    def wrapper(*args, **kwargs):
        # func is captured by the closure
        start = time.time()
        result = func(*args, **kwargs)
        print(f"Took {time.time() - start:.2f}s")
        return result
    return wrapper
```

### Partial Application
```python
def partial(func, *fixed_args):
    def wrapper(*args):
        return func(*fixed_args, *args)
    return wrapper

square = partial(pow, 2)  # Always square
```

## 🎯 Practice Projects

Try implementing these using closures:

1. **Password validator factory**: Create validators with different strength rules
2. **Retry mechanism**: Function that retries on failure with configurable attempts
3. **Debounce function**: Delay function execution until calls stop
4. **State machine**: Simple state machine using closures
5. **Logger factory**: Create loggers with different prefixes/levels
6. **Unit converter**: Temperature, distance, weight converters
7. **ID generator**: Sequential ID generator with prefixes
8. **Shopping cart**: Add, remove, total with private items list
9. **Rate limiter**: Limit function calls per time period
10. **Command pattern**: Store and execute commands with closures

## 🔍 Debugging Tips

1. **Print captured variables**: Add print statements in the inner function
2. **Inspect closures**: Use `__closure__` and `__code__.co_freevars`
3. **Check for `nonlocal`**: Missing `nonlocal` is a common bug
4. **Trace execution**: Add logging to see when closures are created vs called
5. **Use descriptive names**: Makes debugging much easier
6. **Test incrementally**: Build up complexity gradually

## 🤝 Happy Learning!

Closures are a powerful concept that, once mastered, will significantly improve your Python programming. They're the foundation of decorators, enable elegant functional programming, and provide a clean way to maintain state without classes.

Remember: A closure is just a function that remembers where it came from. It carries its environment (the "backpack") wherever it goes!

---

**Month 4: Modular Programming - Closures**
Part of the comprehensive Python programming curriculum.

**Prerequisites**: Understanding of functions, scope, and nested functions
**Next Steps**: Decorators (which are built on closures!)
