# Python Decorators Tutorial

## What are Decorators?

Decorators are a powerful Python feature that allows you to modify or enhance functions and classes without permanently changing their source code. Think of them as "wrappers" that add functionality to existing code.

### Real-World Analogy
Imagine you have a gift (your function). A decorator is like gift wrapping - it adds something extra around the gift without changing what's inside. You can add multiple layers of wrapping (multiple decorators) and still access the gift inside.

## Why Use Decorators?

- **Code Reusability**: Write functionality once, apply it to many functions
- **Separation of Concerns**: Keep core logic separate from cross-cutting concerns (logging, timing, etc.)
- **Clean Code**: Modify behavior without cluttering the original function
- **Common Use Cases**: Logging, timing, authentication, caching, input validation

## Basic Concepts

### Functions are First-Class Objects

In Python, functions are objects that can be:
- Assigned to variables
- Passed as arguments
- Returned from other functions

```python
def greet():
    return "Hello!"

# Assign function to variable
say_hello = greet
print(say_hello())  # Output: Hello!

# Pass function as argument
def call_function(func):
    return func()

print(call_function(greet))  # Output: Hello!
```

### Nested Functions

Functions can be defined inside other functions:

```python
def outer():
    def inner():
        return "I'm inside!"
    return inner()

print(outer())  # Output: I'm inside!
```

### Returning Functions

Functions can return other functions:

```python
def outer():
    def inner():
        return "Hello from inner!"
    return inner  # Return the function itself, not calling it

my_func = outer()  # my_func is now the inner function
print(my_func())   # Output: Hello from inner!
```

## Creating Your First Decorator

### Step 1: The Wrapper Pattern

```python
def my_decorator(func):
    def wrapper():
        print("Before function call")
        result = func()
        print("After function call")
        return result
    return wrapper

def say_hello():
    print("Hello!")

# Manual decoration
decorated_hello = my_decorator(say_hello)
decorated_hello()
```

Output:
```
Before function call
Hello!
After function call
```

### Step 2: Using @ Syntax

The `@` syntax is syntactic sugar for applying decorators:

```python
def my_decorator(func):
    def wrapper():
        print("Before function call")
        result = func()
        print("After function call")
        return result
    return wrapper

@my_decorator
def say_hello():
    print("Hello!")

say_hello()  # Automatically wrapped!
```

This is equivalent to: `say_hello = my_decorator(say_hello)`

## Decorators with Arguments

### Functions with Arguments

```python
def my_decorator(func):
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
        result = func(*args, **kwargs)
        print(f"Result: {result}")
        return result
    return wrapper

@my_decorator
def add(a, b):
    return a + b

@my_decorator
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}!"

add(3, 5)
greet("Alice")
greet("Bob", greeting="Hi")
```

### Decorators with Parameters

To create decorators that accept their own arguments:

```python
def repeat(times):
    def decorator(func):
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result
        return wrapper
    return decorator

@repeat(times=3)
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")
# Output:
# Hello, Alice!
# Hello, Alice!
# Hello, Alice!
```

## Common Decorator Patterns

### 1. Timing Decorator

```python
import time

def timer(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.4f} seconds")
        return result
    return wrapper

@timer
def slow_function():
    time.sleep(1)
    return "Done!"

slow_function()
```

### 2. Logging Decorator

```python
def log_function_call(func):
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__}...")
        result = func(*args, **kwargs)
        print(f"{func.__name__} returned {result}")
        return result
    return wrapper

@log_function_call
def multiply(a, b):
    return a * b

multiply(3, 4)
```

### 3. Debug Decorator

```python
def debug(func):
    def wrapper(*args, **kwargs):
        args_repr = [repr(a) for a in args]
        kwargs_repr = [f"{k}={v!r}" for k, v in kwargs.items()]
        signature = ", ".join(args_repr + kwargs_repr)
        print(f"Calling {func.__name__}({signature})")
        result = func(*args, **kwargs)
        print(f"{func.__name__!r} returned {result!r}")
        return result
    return wrapper

@debug
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}"

greet("Alice", greeting="Hi")
```

### 4. Cache/Memoization Decorator

```python
def memoize(func):
    cache = {}
    def wrapper(*args):
        if args not in cache:
            cache[args] = func(*args)
        return cache[args]
    return wrapper

@memoize
def fibonacci(n):
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(fibonacci(10))  # Much faster with caching!
```

## Preserving Function Metadata

When you wrap a function, you lose its metadata (name, docstring, etc.):

```python
def my_decorator(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@my_decorator
def greet():
    """Say hello"""
    return "Hello"

print(greet.__name__)  # Output: wrapper (not greet!)
print(greet.__doc__)   # Output: None (lost docstring!)
```

### Solution: functools.wraps

```python
from functools import wraps

def my_decorator(func):
    @wraps(func)  # Preserves metadata
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

@my_decorator
def greet():
    """Say hello"""
    return "Hello"

print(greet.__name__)  # Output: greet
print(greet.__doc__)   # Output: Say hello
```

## Stacking Multiple Decorators

You can apply multiple decorators to a single function:

```python
def uppercase(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result.upper()
    return wrapper

def exclaim(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result + "!"
    return wrapper

@uppercase
@exclaim
def greet(name):
    return f"hello, {name}"

print(greet("Alice"))  # Output: HELLO, ALICE!
```

Order matters! Decorators are applied bottom-to-top:
```python
# This is equivalent to:
greet = uppercase(exclaim(greet))
```

## Class-Based Decorators

Decorators can also be implemented as classes:

```python
class CountCalls:
    def __init__(self, func):
        self.func = func
        self.count = 0
    
    def __call__(self, *args, **kwargs):
        self.count += 1
        print(f"Call {self.count} to {self.func.__name__}")
        return self.func(*args, **kwargs)

@CountCalls
def say_hello():
    print("Hello!")

say_hello()
say_hello()
say_hello()
```

## Built-in Decorators

Python provides several built-in decorators:

### @property

```python
class Circle:
    def __init__(self, radius):
        self._radius = radius
    
    @property
    def radius(self):
        return self._radius
    
    @radius.setter
    def radius(self, value):
        if value < 0:
            raise ValueError("Radius cannot be negative")
        self._radius = value
    
    @property
    def area(self):
        return 3.14159 * self._radius ** 2

c = Circle(5)
print(c.radius)  # Access like an attribute
print(c.area)    # Computed property
c.radius = 10    # Use setter
```

### @staticmethod and @classmethod

```python
class MyClass:
    class_variable = "I'm a class variable"
    
    @staticmethod
    def static_method():
        return "I don't need an instance or class"
    
    @classmethod
    def class_method(cls):
        return f"I have access to the class: {cls.class_variable}"
    
    def instance_method(self):
        return "I need an instance"

# Can call without instance
print(MyClass.static_method())
print(MyClass.class_method())
```

## Best Practices

1. **Use functools.wraps**: Always preserve function metadata
2. **Use *args and **kwargs**: Make decorators flexible
3. **Keep it Simple**: Decorators should be easy to understand
4. **Document Well**: Explain what the decorator does
5. **Consider Reusability**: Write decorators that work with many functions
6. **Be Mindful of Order**: When stacking decorators, order matters

## Common Pitfalls

1. **Forgetting to return**: Always return the wrapper function
2. **Not using *args, **kwargs**: Limits which functions can use the decorator
3. **Losing metadata**: Forgetting @wraps
4. **Complex decorators**: If it's too complex, reconsider the design

## Summary

Decorators are a powerful Python feature that allows you to:
- Modify function behavior without changing the function itself
- Write reusable code for cross-cutting concerns
- Keep your code clean and maintainable
- Implement common patterns (logging, timing, caching, etc.)

The key concepts are:
1. Functions are first-class objects
2. Functions can be nested and returned
3. The @ syntax is shorthand for function wrapping
4. Use functools.wraps to preserve metadata
5. *args and **kwargs make decorators flexible
