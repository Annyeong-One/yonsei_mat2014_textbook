"""
Python Decorators - Practice Exercises

Complete these exercises to practice creating and using decorators.
Try to solve them on your own before checking the solutions file!
"""

import time
import functools

print("=" * 70)
print("PYTHON DECORATORS - PRACTICE EXERCISES")
print("=" * 70)

# ========================================================================
# EXERCISE 1: Basic Decorator
# ========================================================================
print("\nEXERCISE 1: Basic Decorator")
print("-" * 70)
print("Create a decorator called 'announce' that prints:")
print("  'Starting...' before the function executes")
print("  'Finished!' after the function executes")

# Your code here:
# def announce(func):
#     # Your implementation
#     pass

# Test your decorator:
# @announce
# def greet(name):
#     print(f"Hello, {name}!")

# greet("Alice")

# Expected output:
# Starting...
# Hello, Alice!
# Finished!

# ========================================================================
# EXERCISE 2: Decorator with Arguments
# ========================================================================
print("\n\nEXERCISE 2: Decorator with Arguments")
print("-" * 70)
print("Create a decorator called 'print_args' that prints the function name")
print("and all arguments passed to it.")

# Your code here:
# def print_args(func):
#     # Your implementation
#     pass

# Test your decorator:
# @print_args
# def multiply(a, b):
#     return a * b

# @print_args
# def greet(name, greeting="Hello"):
#     return f"{greeting}, {name}!"

# multiply(3, 4)
# greet("Bob", greeting="Hi")

# Expected output:
# Calling multiply with args=(3, 4), kwargs={}
# Calling greet with args=('Bob',), kwargs={'greeting': 'Hi'}

# ========================================================================
# EXERCISE 3: Timing Decorator
# ========================================================================
print("\n\nEXERCISE 3: Timing Decorator")
print("-" * 70)
print("Create a decorator called 'measure_time' that measures and prints")
print("how long a function takes to execute.")

# Your code here:
# def measure_time(func):
#     # Your implementation
#     pass

# Test your decorator:
# @measure_time
# def slow_function():
#     time.sleep(0.5)
#     return "Done"

# result = slow_function()

# Expected output:
# slow_function took 0.5XXX seconds

# ========================================================================
# EXERCISE 4: Decorator with Parameters - Repeat
# ========================================================================
print("\n\nEXERCISE 4: Decorator with Parameters - Repeat")
print("-" * 70)
print("Create a decorator called 'repeat' that takes a 'times' parameter")
print("and executes the function that many times.")

# Your code here:
# def repeat(times):
#     # Your implementation
#     pass

# Test your decorator:
# @repeat(times=3)
# def say_hello():
#     print("Hello!")

# say_hello()

# Expected output:
# Hello!
# Hello!
# Hello!

# ========================================================================
# EXERCISE 5: Uppercase Decorator
# ========================================================================
print("\n\nEXERCISE 5: Uppercase Decorator")
print("-" * 70)
print("Create a decorator called 'uppercase' that converts the function's")
print("return value to uppercase.")

# Your code here:
# def uppercase(func):
#     # Your implementation
#     pass

# Test your decorator:
# @uppercase
# def greet(name):
#     return f"hello, {name}"

# print(greet("Alice"))

# Expected output:
# HELLO, ALICE

# ========================================================================
# EXERCISE 6: Exception Handler Decorator
# ========================================================================
print("\n\nEXERCISE 6: Exception Handler Decorator")
print("-" * 70)
print("Create a decorator called 'handle_errors' that catches exceptions")
print("and prints an error message instead of crashing.")

# Your code here:
# def handle_errors(func):
#     # Your implementation
#     pass

# Test your decorator:
# @handle_errors
# def divide(a, b):
#     return a / b

# print(divide(10, 2))   # Should work normally
# print(divide(10, 0))   # Should catch error

# Expected output:
# 5.0
# Error in divide: division by zero

# ========================================================================
# EXERCISE 7: Count Calls Decorator
# ========================================================================
print("\n\nEXERCISE 7: Count Calls Decorator")
print("-" * 70)
print("Create a class-based decorator called 'CountCalls' that counts")
print("how many times a function has been called.")

# Your code here:
# class CountCalls:
#     # Your implementation
#     pass

# Test your decorator:
# @CountCalls
# def say_hello():
#     return "Hello!"

# say_hello()
# say_hello()
# say_hello()
# print(f"Function called {say_hello.count} times")

# Expected output:
# Function called 3 times

# ========================================================================
# EXERCISE 8: Prefix Decorator
# ========================================================================
print("\n\nEXERCISE 8: Prefix Decorator")
print("-" * 70)
print("Create a decorator called 'prefix' that takes a string parameter")
print("and adds it as a prefix to the function's return value.")

# Your code here:
# def prefix(text):
#     # Your implementation
#     pass

# Test your decorator:
# @prefix(">>> ")
# def get_message():
#     return "This is a message"

# print(get_message())

# Expected output:
# >>> This is a message

# ========================================================================
# EXERCISE 9: Validate Type Decorator
# ========================================================================
print("\n\nEXERCISE 9: Validate Type Decorator")
print("-" * 70)
print("Create a decorator called 'validate_type' that checks if the first")
print("argument is of a specific type. If not, raise a TypeError.")

# Your code here:
# def validate_type(expected_type):
#     # Your implementation
#     pass

# Test your decorator:
# @validate_type(int)
# def double(x):
#     return x * 2

# print(double(5))      # Should work
# try:
#     double("5")       # Should raise TypeError
# except TypeError as e:
#     print(f"Error: {e}")

# Expected output:
# 10
# Error: Expected int, got str

# ========================================================================
# EXERCISE 10: Memoization Decorator
# ========================================================================
print("\n\nEXERCISE 10: Memoization Decorator")
print("-" * 70)
print("Create a decorator called 'memoize' that caches function results.")
print("If the same arguments are used again, return the cached result.")

# Your code here:
# def memoize(func):
#     # Your implementation
#     pass

# Test your decorator:
# @memoize
# def fibonacci(n):
#     print(f"Computing fib({n})")
#     if n < 2:
#         return n
#     return fibonacci(n-1) + fibonacci(n-2)

# print(fibonacci(5))
# print("Second call:")
# print(fibonacci(5))  # Should use cached result

# Expected output:
# Computing fib(5)
# Computing fib(4)
# ... (other computations)
# 5
# Second call:
# 5  (no "Computing" messages)

# ========================================================================
# EXERCISE 11: Challenge - Rate Limiter
# ========================================================================
print("\n\nEXERCISE 11: Challenge - Rate Limiter")
print("-" * 70)
print("Create a decorator called 'rate_limit' that limits function calls")
print("to max_calls per time_period seconds.")
print("Hint: Keep track of call timestamps!")

# Your code here:
# def rate_limit(max_calls, time_period):
#     # Your implementation
#     pass

# Test your decorator:
# @rate_limit(max_calls=2, time_period=1)
# def api_call(n):
#     return f"Call {n}"

# for i in range(4):
#     result = api_call(i)
#     if result:
#         print(result)
#     time.sleep(0.3)

# Expected behavior:
# First 2 calls work, 3rd is blocked, 4th works after time passes

# ========================================================================
# EXERCISE 12: Challenge - Retry Decorator
# ========================================================================
print("\n\nEXERCISE 12: Challenge - Retry Decorator")
print("-" * 70)
print("Create a decorator called 'retry' that retries a function up to")
print("max_attempts times if it raises an exception.")

# Your code here:
# def retry(max_attempts=3):
#     # Your implementation
#     pass

# # Test with a flaky function
# attempt = 0
# @retry(max_attempts=3)
# def flaky_function():
#     global attempt
#     attempt += 1
#     if attempt < 3:
#         raise ValueError(f"Attempt {attempt} failed")
#     return "Success!"

# result = flaky_function()
# print(result)

# Expected output:
# Attempt 1 failed
# Attempt 2 failed
# Success!

# ========================================================================
# EXERCISE 13: Challenge - Stacking Decorators
# ========================================================================
print("\n\nEXERCISE 13: Challenge - Stacking Decorators")
print("-" * 70)
print("Create three decorators (bold, italic, underline) that wrap text")
print("with HTML tags. Stack them on a function.")

# Your code here:
# def bold(func):
#     # Wrap result in <b></b>
#     pass

# def italic(func):
#     # Wrap result in <i></i>
#     pass

# def underline(func):
#     # Wrap result in <u></u>
#     pass

# @bold
# @italic
# @underline
# def get_text():
#     return "Hello, World!"

# print(get_text())

# Expected output:
# <b><i><u>Hello, World!</u></i></b>

print("\n" + "=" * 70)
print("END OF EXERCISES - Check solutions.py when you're done!")
print("=" * 70)
