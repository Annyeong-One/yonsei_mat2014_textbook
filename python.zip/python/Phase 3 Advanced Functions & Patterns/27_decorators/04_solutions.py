"""
Python Decorators - Practice Exercise Solutions

Here are the solutions to the practice exercises.
Try to solve them yourself first before looking at these!
"""

import time
import functools

print("=" * 70)
print("PYTHON DECORATORS - SOLUTIONS")
print("=" * 70)

# ========================================================================
# EXERCISE 1: Basic Decorator
# ========================================================================
print("\nEXERCISE 1: Basic Decorator")
print("-" * 70)

def announce(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print("Starting...")
        result = func(*args, **kwargs)
        print("Finished!")
        return result
    return wrapper

@announce
def greet(name):
    print(f"Hello, {name}!")

greet("Alice")

# ========================================================================
# EXERCISE 2: Decorator with Arguments
# ========================================================================
print("\n\nEXERCISE 2: Decorator with Arguments")
print("-" * 70)

def print_args(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
        return func(*args, **kwargs)
    return wrapper

@print_args
def multiply(a, b):
    return a * b

@print_args
def greet(name, greeting="Hello"):
    return f"{greeting}, {name}!"

result1 = multiply(3, 4)
print(f"Result: {result1}")

result2 = greet("Bob", greeting="Hi")
print(f"Result: {result2}")

# ========================================================================
# EXERCISE 3: Timing Decorator
# ========================================================================
print("\n\nEXERCISE 3: Timing Decorator")
print("-" * 70)

def measure_time(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        end = time.time()
        print(f"{func.__name__} took {end - start:.4f} seconds")
        return result
    return wrapper

@measure_time
def slow_function():
    time.sleep(0.5)
    return "Done"

result = slow_function()
print(f"Result: {result}")

# ========================================================================
# EXERCISE 4: Decorator with Parameters - Repeat
# ========================================================================
print("\n\nEXERCISE 4: Decorator with Parameters - Repeat")
print("-" * 70)

def repeat(times):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for _ in range(times):
                result = func(*args, **kwargs)
            return result  # Return last result
        return wrapper
    return decorator

@repeat(times=3)
def say_hello():
    print("Hello!")

say_hello()

# ========================================================================
# EXERCISE 5: Uppercase Decorator
# ========================================================================
print("\n\nEXERCISE 5: Uppercase Decorator")
print("-" * 70)

def uppercase(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result.upper()
    return wrapper

@uppercase
def greet(name):
    return f"hello, {name}"

print(greet("Alice"))

# ========================================================================
# EXERCISE 6: Exception Handler Decorator
# ========================================================================
print("\n\nEXERCISE 6: Exception Handler Decorator")
print("-" * 70)

def handle_errors(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"Error in {func.__name__}: {e}")
            return None
    return wrapper

@handle_errors
def divide(a, b):
    return a / b

print(divide(10, 2))   # Should work normally
print(divide(10, 0))   # Should catch error

# ========================================================================
# EXERCISE 7: Count Calls Decorator
# ========================================================================
print("\n\nEXERCISE 7: Count Calls Decorator")
print("-" * 70)

class CountCalls:
    def __init__(self, func):
        functools.update_wrapper(self, func)
        self.func = func
        self.count = 0
    
    def __call__(self, *args, **kwargs):
        self.count += 1
        return self.func(*args, **kwargs)

@CountCalls
def say_hello():
    return "Hello!"

say_hello()
say_hello()
say_hello()
print(f"Function called {say_hello.count} times")

# ========================================================================
# EXERCISE 8: Prefix Decorator
# ========================================================================
print("\n\nEXERCISE 8: Prefix Decorator")
print("-" * 70)

def prefix(text):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            return text + result
        return wrapper
    return decorator

@prefix(">>> ")
def get_message():
    return "This is a message"

print(get_message())

# ========================================================================
# EXERCISE 9: Validate Type Decorator
# ========================================================================
print("\n\nEXERCISE 9: Validate Type Decorator")
print("-" * 70)

def validate_type(expected_type):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if args and not isinstance(args[0], expected_type):
                raise TypeError(f"Expected {expected_type.__name__}, got {type(args[0]).__name__}")
            return func(*args, **kwargs)
        return wrapper
    return decorator

@validate_type(int)
def double(x):
    return x * 2

print(double(5))      # Should work
try:
    double("5")       # Should raise TypeError
except TypeError as e:
    print(f"Error: {e}")

# ========================================================================
# EXERCISE 10: Memoization Decorator
# ========================================================================
print("\n\nEXERCISE 10: Memoization Decorator")
print("-" * 70)

def memoize(func):
    cache = {}
    @functools.wraps(func)
    def wrapper(*args):
        if args not in cache:
            cache[args] = func(*args)
        return cache[args]
    return wrapper

@memoize
def fibonacci(n):
    print(f"Computing fib({n})")
    if n < 2:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

print(f"Result: {fibonacci(5)}")
print("\nSecond call:")
print(f"Result: {fibonacci(5)}")  # Should use cached result

# ========================================================================
# EXERCISE 11: Challenge - Rate Limiter
# ========================================================================
print("\n\nEXERCISE 11: Challenge - Rate Limiter")
print("-" * 70)

def rate_limit(max_calls, time_period):
    def decorator(func):
        calls = []
        
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            now = time.time()
            # Remove old calls outside the time window
            calls[:] = [call_time for call_time in calls if now - call_time < time_period]
            
            if len(calls) >= max_calls:
                wait_time = time_period - (now - calls[0])
                print(f"  Rate limit reached. Please wait {wait_time:.2f}s")
                return None
            
            calls.append(now)
            return func(*args, **kwargs)
        return wrapper
    return decorator

@rate_limit(max_calls=2, time_period=1)
def api_call(n):
    return f"Call {n}"

print("Making 4 calls (max 2 per second):")
for i in range(4):
    result = api_call(i)
    if result:
        print(f"  {result}")
    time.sleep(0.3)

# ========================================================================
# EXERCISE 12: Challenge - Retry Decorator
# ========================================================================
print("\n\nEXERCISE 12: Challenge - Retry Decorator")
print("-" * 70)

def retry(max_attempts=3):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    if attempt == max_attempts:
                        print(f"Failed after {max_attempts} attempts")
                        raise
                    print(f"Attempt {attempt} failed: {e}")
        return wrapper
    return decorator

# Test with a flaky function
attempt = 0

@retry(max_attempts=3)
def flaky_function():
    global attempt
    attempt += 1
    if attempt < 3:
        raise ValueError(f"Error on attempt {attempt}")
    return "Success!"

result = flaky_function()
print(f"Result: {result}")

# ========================================================================
# EXERCISE 13: Challenge - Stacking Decorators
# ========================================================================
print("\n\nEXERCISE 13: Challenge - Stacking Decorators")
print("-" * 70)

def bold(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return f"<b>{result}</b>"
    return wrapper

def italic(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return f"<i>{result}</i>"
    return wrapper

def underline(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return f"<u>{result}</u>"
    return wrapper

@bold
@italic
@underline
def get_text():
    return "Hello, World!"

print(get_text())
print("\nNote: Decorators are applied bottom-to-top:")
print("  1. underline wraps the original function")
print("  2. italic wraps the underline decorator")
print("  3. bold wraps the italic decorator")

print("\n" + "=" * 70)
print("END OF SOLUTIONS")
print("=" * 70)

# ========================================================================
# BONUS: Additional Insights
# ========================================================================
print("\n\nBONUS INSIGHTS:")
print("-" * 70)
print("""
Key Takeaways:

1. Always use @functools.wraps to preserve function metadata
2. Use *args and **kwargs to make decorators flexible
3. Decorators with parameters require an extra level of nesting
4. Class-based decorators use __call__ to be callable
5. Multiple decorators are applied bottom-to-top

Common Decorator Patterns:
- Timing: Measure execution time
- Logging: Track function calls
- Validation: Check inputs before execution
- Caching: Store results for reuse
- Authentication: Control access
- Error handling: Gracefully handle exceptions
- Retry logic: Attempt multiple times on failure
- Rate limiting: Control call frequency

When to Use Decorators:
✓ Cross-cutting concerns (logging, timing, auth)
✓ Behavior that applies to multiple functions
✓ When you want to modify behavior without changing code
✓ For framework/library features (like Flask routes)

When NOT to Use Decorators:
✗ Core business logic (put that in the function itself)
✗ When it makes code harder to understand
✗ When a simple function call would be clearer
✗ Overly complex transformations

Pro Tips:
1. Keep decorators simple and focused
2. Document what your decorators do
3. Test decorated functions thoroughly
4. Consider using built-in decorators (functools.lru_cache)
5. Be aware of performance overhead
6. Think about decorator order when stacking

Practice makes perfect! Try creating decorators for your own projects.
""")
