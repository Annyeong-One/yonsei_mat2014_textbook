# Python Decorators - Learning Materials

Welcome to the Python Decorators learning module! This comprehensive package will teach you everything you need to know about decorators in Python, from basics to advanced patterns.

## 📦 Package Contents

### 1. **01_decorators_tutorial.md**
A comprehensive tutorial covering:
- What decorators are and why they're useful
- Functions as first-class objects
- Creating your first decorator
- Decorator syntax with @
- Decorators with arguments and parameters
- Common decorator patterns (timing, logging, caching, etc.)
- Preserving function metadata with functools.wraps
- Stacking multiple decorators
- Class-based decorators
- Built-in decorators (@property, @staticmethod, @classmethod)
- Best practices and common pitfalls

### 2. **02_examples.py**
Practical, runnable examples demonstrating:
- Basic decorators
- Decorators with function arguments
- Timing and logging decorators
- Decorators with parameters
- Stacking multiple decorators
- Caching/memoization
- Authentication and authorization
- Validation decorators
- Retry logic
- Class-based decorators
- Debug decorators
- Rate limiting

**To run:** `python 02_examples.py`

### 3. **03_exercises.py**
Practice exercises organized by difficulty:
- Basic decorators (announce, print_args)
- Timing and repeating decorators
- Text transformation decorators
- Exception handling
- Class-based decorators
- Parameterized decorators
- Type validation
- Memoization
- Challenge problems (rate limiting, retry logic, stacking)

**To use:** Try to complete each exercise before checking the solutions!

### 4. **04_solutions.py**
Complete solutions to all exercises with:
- Working code for each problem
- Detailed explanations
- Bonus insights and tips
- Best practices demonstrated

**To run:** `python 04_solutions.py`

### 5. **05_cheat_sheet.md**
Quick reference guide with:
- Basic syntax templates
- Common decorator patterns
- Built-in decorators
- Stacking rules
- Best practices
- Common mistakes
- Real-world examples

## 🎯 Learning Path

### For Beginners:
1. Read **01_decorators_tutorial.md** thoroughly (start here!)
2. Understand the concept of functions as first-class objects
3. Run **02_examples.py** to see decorators in action
4. Try exercises in **03_exercises.py** (start with Exercise 1-5)
5. Check your work against **04_solutions.py**
6. Keep **05_cheat_sheet.md** handy for quick reference

### For Intermediate Learners:
1. Review **01_decorators_tutorial.md** (focus on advanced topics)
2. Study the examples in **02_examples.py**
3. Complete exercises 6-10 in **03_exercises.py**
4. Try the challenge problems (exercises 11-13)
5. Experiment with creating your own decorators

### For Quick Review:
1. Start with **05_cheat_sheet.md**
2. Run **02_examples.py** to refresh your memory
3. Review specific patterns you need in the tutorial

## 💡 Key Concepts Covered

### Fundamentals
- **Functions as objects**: Assigning, passing, returning functions
- **Nested functions**: Functions inside functions
- **Closures**: Inner functions accessing outer scope
- **Decorator syntax**: The @ symbol

### Core Patterns
- **Wrapper pattern**: Basic decorator structure
- **Decorators with arguments**: Using *args and **kwargs
- **Parameterized decorators**: Decorators that take parameters
- **Stacking decorators**: Applying multiple decorators
- **Class-based decorators**: Using classes instead of functions
- **functools.wraps**: Preserving function metadata

### Common Use Cases
- **Timing**: Measure execution time
- **Logging**: Track function calls
- **Caching**: Memoization for performance
- **Validation**: Input/output checking
- **Authentication**: Access control
- **Error handling**: Graceful failure
- **Retry logic**: Handle transient failures
- **Rate limiting**: Control call frequency
- **Debugging**: Development helpers

## 🔧 Requirements

- Python 3.x
- No external packages required (uses only standard library)
- functools module (built-in)
- time module (built-in)

## 📝 Tips for Success

1. **Understand Functions First**: Make sure you're comfortable with functions before tackling decorators
2. **Start Simple**: Master basic decorators before moving to parameterized ones
3. **Run the Code**: Execute examples and modify them to see what happens
4. **Practice Regularly**: Try creating decorators for your own projects
5. **Read Error Messages**: They'll help you understand what went wrong
6. **Use functools.wraps**: ALWAYS use this to preserve function metadata
7. **Debug Step-by-Step**: If confused, break down the decorator into steps

## 🎓 Learning Objectives

After completing this module, you should be able to:
- ✅ Explain what decorators are and why they're useful
- ✅ Create basic decorators to wrap functions
- ✅ Use *args and **kwargs in decorators
- ✅ Create decorators that accept parameters
- ✅ Stack multiple decorators on a single function
- ✅ Use functools.wraps to preserve metadata
- ✅ Implement class-based decorators
- ✅ Apply common decorator patterns (timing, logging, caching)
- ✅ Debug decorated functions
- ✅ Decide when to use decorators vs. other approaches

## 🚀 Next Steps

After mastering decorators, consider exploring:
- **Context managers**: Similar wrapper pattern with `with` statement
- **Metaclasses**: Advanced class customization
- **Descriptors**: Low-level attribute access control
- **Generators**: Function state preservation
- **Async decorators**: Decorators for async/await functions
- **Popular frameworks**: Study how Flask, Django, Click use decorators

## 📚 Additional Resources

- Python Official Documentation: https://docs.python.org/3/glossary.html#term-decorator
- PEP 318 - Decorators for Functions and Methods: https://www.python.org/dev/peps/pep-0318/
- Real Python Decorators Tutorial: https://realpython.com/primer-on-python-decorators/
- functools documentation: https://docs.python.org/3/library/functools.html

## ❓ Common Questions

**Q: When should I use decorators?**
A: Use decorators for cross-cutting concerns (logging, timing, auth) that apply to multiple functions. Don't use them for core business logic.

**Q: Can decorators modify the original function?**
A: Decorators wrap functions but shouldn't modify the original. They return a new wrapper function.

**Q: Why use @wraps?**
A: It preserves the original function's name, docstring, and other metadata, which is important for debugging and documentation.

**Q: Can I remove a decorator after applying it?**
A: Not easily. Decorators permanently wrap the function. Design your code carefully!

**Q: Are decorators slower than regular functions?**
A: Yes, there's a small performance overhead from the wrapper function call. Usually negligible, but avoid in performance-critical loops.

**Q: Can I decorate class methods?**
A: Yes! Decorators work on any callable, including methods.

**Q: What's the difference between @staticmethod and @classmethod?**
A: @staticmethod has no access to instance or class. @classmethod receives the class as first argument.

## 🌟 Real-World Examples

Decorators are used extensively in popular Python frameworks:

### Flask (Web Framework)
```python
@app.route('/users/<id>')
@login_required
def get_user(id):
    return render_template('user.html')
```

### Django (Web Framework)
```python
@login_required
@permission_required('polls.can_vote')
def vote(request, question_id):
    pass
```

### pytest (Testing Framework)
```python
@pytest.fixture
def database():
    return create_db()

@pytest.mark.parametrize("input,expected", [(1,2), (2,3)])
def test_increment(input, expected):
    assert increment(input) == expected
```

### Click (CLI Framework)
```python
@click.command()
@click.option('--name', default='World')
def hello(name):
    click.echo(f'Hello, {name}!')
```

## 🎯 Practice Projects

Try implementing these decorators as practice:

1. **@benchmark**: Compare execution time of multiple runs
2. **@deprecated**: Warn when using deprecated functions
3. **@singleton**: Ensure only one instance of a class
4. **@async_timer**: Time async functions
5. **@throttle**: Limit function calls per time period
6. **@cache_to_file**: Save results to disk
7. **@notify**: Send notification when function completes
8. **@profile**: Track memory usage
9. **@chain**: Pipe function outputs to next function
10. **@fallback**: Return default value on error

## 🤝 Happy Learning!

Remember: Decorators are a powerful tool, but they should make your code clearer, not more complex. Start simple, practice often, and gradually tackle more advanced patterns. The key is understanding that decorators are just functions that take functions and return functions - once you grasp that, everything else falls into place!

---

**Month 4: Modular Programming - Decorators**
Part of the comprehensive Python programming curriculum.
