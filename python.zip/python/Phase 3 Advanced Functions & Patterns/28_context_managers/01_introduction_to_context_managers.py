"""
01_introduction_to_context_managers.py

BEGINNER LEVEL - Introduction to Context Managers

This module introduces the fundamental concept of context managers in Python,
explaining what they are, why they're useful, and how to use the 'with' statement.

Learning Objectives:
- Understand the problem context managers solve
- Learn the basic syntax of the 'with' statement
- Explore built-in context managers in Python
- Recognize when to use context managers
"""

# =============================================================================
# SECTION 1: The Problem - Manual Resource Management
# =============================================================================

print("=" * 70)
print("SECTION 1: The Problem - Manual Resource Management")
print("=" * 70)

# Traditional approach to file handling WITHOUT context managers
# This approach has several problems:

def traditional_file_handling():
    """
    This function demonstrates the traditional way of handling files.
    Notice the explicit open() and close() calls.
    
    Problems with this approach:
    1. You must remember to close the file
    2. If an exception occurs, close() might not be called
    3. More verbose and error-prone
    """
    # Open a file for writing
    file = open('/tmp/example.txt', 'w')
    
    # Write some data
    file.write('Hello, World!')
    
    # Must explicitly close - easy to forget!
    file.close()
    
    print("Traditional method: File written and closed manually")

# Call the function
traditional_file_handling()


# Even worse - what if an exception occurs?
def traditional_with_exception_risk():
    """
    This demonstrates a critical flaw: if an exception occurs before close(),
    the file remains open, causing a resource leak.
    """
    file = open('/tmp/risky.txt', 'w')
    
    try:
        file.write('Some data')
        # Imagine an error occurs here...
        # result = 10 / 0  # This would cause an exception!
        
    finally:
        # We MUST use a finally block to ensure closing
        # This is tedious and error-prone
        file.close()
    
    print("Traditional method with proper exception handling")

traditional_with_exception_risk()


# =============================================================================
# SECTION 2: The Solution - Context Managers and 'with' Statement
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: The Solution - Context Managers and 'with' Statement")
print("=" * 70)

def using_context_manager():
    """
    The 'with' statement provides automatic resource management.
    
    Syntax: with expression as variable:
    
    Benefits:
    1. Automatic cleanup (file is always closed)
    2. Works even if exceptions occur
    3. Cleaner, more readable code
    4. Follows Python's philosophy: "Explicit is better than implicit"
    """
    # The file is automatically closed when the with block exits
    with open('/tmp/example_with.txt', 'w') as file:
        file.write('Hello from context manager!')
        # File automatically closes here, even if an exception occurs
    
    print("Context manager: File automatically closed!")
    
    # Verify the file is closed
    # Note: After the with block, the file object still exists but is closed
    print(f"File closed? {file.closed}")  # Output: True

using_context_manager()


# =============================================================================
# SECTION 3: Built-in Context Managers in Python
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: Built-in Context Managers in Python")
print("=" * 70)

# Example 1: File operations (most common use case)
print("\n1. File Operations:")
with open('/tmp/demo.txt', 'w') as f:
    f.write('Line 1\n')
    f.write('Line 2\n')
    f.write('Line 3\n')
print("   File written successfully")

# Reading the file back
with open('/tmp/demo.txt', 'r') as f:
    content = f.read()
    print(f"   File contents:\n{content}")


# Example 2: Multiple files at once
print("\n2. Multiple Context Managers:")
# You can use multiple context managers in one 'with' statement
with open('/tmp/source.txt', 'w') as source, \
     open('/tmp/destination.txt', 'w') as dest:
    source.write('Source data')
    dest.write('Destination data')
print("   Multiple files handled simultaneously")


# Example 3: Working with locks (threading)
print("\n3. Threading Locks:")
import threading

# Create a lock object
lock = threading.Lock()

# Traditional way
lock.acquire()
try:
    print("   Traditional: Critical section with manual lock management")
finally:
    lock.release()

# With context manager (much cleaner!)
with lock:
    print("   Context manager: Critical section with automatic lock management")


# Example 4: Decimal context for precision arithmetic
print("\n4. Decimal Context:")
from decimal import Decimal, localcontext

# Set specific precision for decimal calculations
with localcontext() as ctx:
    ctx.prec = 50  # 50 decimal places of precision
    result = Decimal(1) / Decimal(7)
    print(f"   High precision (50 places): {result}")

# Outside the context, default precision is restored
result = Decimal(1) / Decimal(7)
print(f"   Default precision: {result}")


# Example 5: Suppressing specific exceptions
print("\n5. Suppressing Exceptions:")
from contextlib import suppress

# Suppress FileNotFoundError when trying to remove a file that may not exist
with suppress(FileNotFoundError):
    import os
    os.remove('/tmp/nonexistent_file.txt')
    print("   This won't print if file doesn't exist")

print("   Code continues despite missing file")


# =============================================================================
# SECTION 4: When to Use Context Managers
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: When to Use Context Managers")
print("=" * 70)

"""
Context managers are ideal for operations that require:

1. SETUP and CLEANUP phases:
   - Opening and closing files
   - Acquiring and releasing locks
   - Connecting and disconnecting from databases
   
2. TEMPORARY STATE changes:
   - Changing directory temporarily
   - Modifying global settings temporarily
   - Timing code execution
   
3. RESOURCE MANAGEMENT:
   - Memory allocation/deallocation
   - Network connections
   - Database transactions

4. EXCEPTION SAFETY:
   - Ensuring cleanup happens even if errors occur
   - Logging entry and exit of critical sections
"""

# Practical example: Timing code execution
print("\nPractical Example - Timing Code Execution:")

import time

class Timer:
    """
    A simple timer context manager to measure execution time.
    This demonstrates a common pattern: setup (start timer),
    execute code, cleanup (stop timer and report).
    """
    def __enter__(self):
        """Called when entering the 'with' block"""
        self.start = time.time()
        print("   Timer started...")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Called when exiting the 'with' block"""
        self.end = time.time()
        self.elapsed = self.end - self.start
        print(f"   Timer stopped. Elapsed time: {self.elapsed:.4f} seconds")
        return False  # Don't suppress any exceptions

# Using our custom timer
with Timer():
    # Simulate some work
    time.sleep(0.5)
    print("   Doing some work...")


# =============================================================================
# SECTION 5: The Context Manager Protocol (Preview)
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: The Context Manager Protocol (Preview)")
print("=" * 70)

"""
Any object that implements two special methods is a context manager:

1. __enter__(self):
   - Called when entering the 'with' block
   - Can return a value (which becomes the 'as' variable)
   - Performs setup operations
   
2. __exit__(self, exc_type, exc_value, traceback):
   - Called when exiting the 'with' block
   - Performs cleanup operations
   - Can suppress exceptions by returning True
   - Always called, even if an exception occurs

Basic structure:

class MyContextManager:
    def __enter__(self):
        # Setup code
        return self  # Or return any object
    
    def __exit__(self, exc_type, exc_value, traceback):
        # Cleanup code
        return False  # Or True to suppress exceptions

We'll explore this in detail in the next lesson!
"""

print("\nSimple demonstration of the protocol:")

class GreetingContext:
    """A simple context manager that prints greetings."""
    
    def __enter__(self):
        print("   >>> Entering the context - Hello!")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print("   >>> Exiting the context - Goodbye!")
        return False

# Using our custom context manager
with GreetingContext():
    print("   >>> Inside the context - Doing work")


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
1. Context managers provide automatic resource management
2. Use the 'with' statement to invoke a context manager
3. Resources are automatically cleaned up, even if exceptions occur
4. Many Python built-in objects support the context manager protocol
5. Context managers make code cleaner, safer, and more Pythonic
6. The pattern: SETUP → USE → CLEANUP (automatic)

Next lesson: We'll learn how to create our own context managers!
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Write code that opens a file, writes your name, and reads it back.
   Do it twice: once without 'with', once with 'with'.

2. Create a file that contains numbers 1-10, one per line, using a context manager.

3. Read two files simultaneously using a single 'with' statement and
   print their contents.

4. Research and use the 'suppress' context manager from contextlib to
   ignore a ZeroDivisionError.

5. Think of three real-world scenarios where context managers would be useful.
   Write them down and explain why.

See exercises_beginner.py for structured practice problems!
""")
