"""
02_context_manager_protocol.py

BEGINNER LEVEL - The Context Manager Protocol

This module provides a deep dive into the context manager protocol,
explaining __enter__ and __exit__ methods in detail.

Learning Objectives:
- Understand the __enter__ method and its return value
- Master the __exit__ method and its parameters
- Learn exception handling within context managers
- Create simple custom context managers
"""

# =============================================================================
# SECTION 1: The __enter__ Method
# =============================================================================

print("=" * 70)
print("SECTION 1: The __enter__ Method")
print("=" * 70)

class SimpleContextManager:
    """
    The __enter__ method is called when the with block is entered.
    
    Key points about __enter__:
    1. Called automatically when 'with' statement begins
    2. Can perform setup operations
    3. Its return value is assigned to the variable after 'as'
    4. If no 'as' clause, return value is ignored
    5. Typically returns self, but can return any object
    """
    
    def __init__(self, name):
        """Constructor - initialize the object"""
        self.name = name
        print(f"__init__: Created context manager '{self.name}'")
    
    def __enter__(self):
        """
        This method is called when entering the with block.
        Whatever it returns is assigned to the 'as' variable.
        """
        print(f"__enter__: Entering context for '{self.name}'")
        # Common practice: return self to give access to the instance
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """This method is called when exiting the with block"""
        print(f"__exit__: Exiting context for '{self.name}'")
        return False  # Don't suppress exceptions
    
    def do_something(self):
        """A method we can call on the context manager"""
        print(f"do_something: Working with '{self.name}'")


# Example 1: Using __enter__'s return value
print("\nExample 1: Basic usage with 'as'")
with SimpleContextManager("Demo1") as cm:
    # 'cm' is the return value of __enter__ (self in this case)
    print(f"Inside with block, cm = {cm}")
    cm.do_something()


# Example 2: Without 'as' clause
print("\nExample 2: Without capturing return value")
with SimpleContextManager("Demo2"):
    # __enter__ is still called, but we don't capture its return value
    print("Inside with block, no variable captured")


# Example 3: Returning different objects from __enter__
print("\nExample 3: Returning custom objects from __enter__")

class FileProcessor:
    """
    Demonstrates returning different objects from __enter__.
    Instead of returning self, we return a list for collecting data.
    """
    
    def __init__(self, filename):
        self.filename = filename
        self.file = None
        self.data = []  # We'll return this instead of self
    
    def __enter__(self):
        print(f"Opening file: {self.filename}")
        self.file = open(self.filename, 'w')
        # Return the data list instead of self!
        # This gives users direct access to the data structure
        return self.data
    
    def __exit__(self, exc_type, exc_value, traceback):
        print(f"Closing file: {self.filename}")
        if self.file:
            # Write all collected data to file
            for item in self.data:
                self.file.write(f"{item}\n")
            self.file.close()
        return False

# Using it - notice 'data' is the list, not the FileProcessor instance
with FileProcessor('/tmp/output.txt') as data:
    print(f"Type of 'data': {type(data)}")  # <class 'list'>
    data.append("First line")
    data.append("Second line")
    data.append("Third line")

print("Data written to file!")


# =============================================================================
# SECTION 2: The __exit__ Method
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: The __exit__ Method")
print("=" * 70)

"""
The __exit__ method has a special signature:

__exit__(self, exc_type, exc_value, traceback)

Parameters:
- exc_type: The exception class (if an exception occurred, else None)
- exc_value: The exception instance (if an exception occurred, else None)
- traceback: The traceback object (if an exception occurred, else None)

Return value:
- False or None: Exception is re-raised (if any occurred)
- True: Exception is suppressed (swallowed)
"""

class DetailedExitDemo:
    """
    Demonstrates the parameters passed to __exit__ and their meanings.
    """
    
    def __init__(self, name):
        self.name = name
    
    def __enter__(self):
        print(f"\n__enter__: Starting '{self.name}'")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """
        Detailed examination of __exit__ parameters.
        """
        print(f"\n__exit__: Cleaning up '{self.name}'")
        print(f"  exc_type  = {exc_type}")      # Exception class or None
        print(f"  exc_value = {exc_value}")      # Exception instance or None
        print(f"  traceback = {traceback}")      # Traceback object or None
        
        # Return False to propagate any exception
        # Return True to suppress any exception
        return False


# Example 1: Normal exit (no exception)
print("\nExample 1: Normal exit")
try:
    with DetailedExitDemo("Normal") as dm:
        print("Everything is fine here")
        result = 10 + 5
        print(f"Result: {result}")
except Exception as e:
    print(f"Exception caught: {e}")


# Example 2: Exit with exception
print("\nExample 2: Exit with exception")
try:
    with DetailedExitDemo("Exception") as dm:
        print("About to cause an error...")
        result = 10 / 0  # ZeroDivisionError!
        print("This won't print")
except Exception as e:
    print(f"Exception caught outside: {e}")


# =============================================================================
# SECTION 3: Exception Handling in __exit__
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: Exception Handling in __exit__")
print("=" * 70)

class ExceptionHandler:
    """
    Demonstrates different ways to handle exceptions in __exit__.
    """
    
    def __init__(self, suppress=False):
        """
        Args:
            suppress: If True, suppress exceptions; if False, propagate them
        """
        self.suppress = suppress
    
    def __enter__(self):
        print(f"__enter__: suppress={self.suppress}")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        print(f"__exit__: Exception occurred? {exc_type is not None}")
        
        if exc_type is not None:
            # An exception occurred
            print(f"  Exception type: {exc_type.__name__}")
            print(f"  Exception message: {exc_value}")
            
            # We can log, handle, or transform the exception here
            if self.suppress:
                print("  → Suppressing exception")
                return True  # Suppress the exception
            else:
                print("  → Propagating exception")
                return False  # Propagate the exception
        
        return False  # Normal exit


# Example 1: Propagating exceptions (default behavior)
print("\nExample 1: Propagating exceptions")
try:
    with ExceptionHandler(suppress=False):
        print("Causing an error...")
        x = 1 / 0
except ZeroDivisionError as e:
    print(f"Caught in outer try: {e}")


# Example 2: Suppressing exceptions
print("\nExample 2: Suppressing exceptions")
try:
    with ExceptionHandler(suppress=True):
        print("Causing an error...")
        x = 1 / 0
        print("This won't execute")
    print("Execution continues normally after with block!")
except ZeroDivisionError as e:
    print(f"This won't execute: {e}")


# Example 3: Selective exception handling
print("\nExample 3: Selective exception handling")

class SelectiveHandler:
    """
    Only suppress specific exception types.
    """
    
    def __init__(self, suppress_types):
        """
        Args:
            suppress_types: Tuple of exception types to suppress
        """
        self.suppress_types = suppress_types
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is not None:
            print(f"Exception: {exc_type.__name__}: {exc_value}")
            
            # Check if this exception type should be suppressed
            if issubclass(exc_type, self.suppress_types):
                print(f"→ Suppressing {exc_type.__name__}")
                return True
            else:
                print(f"→ Propagating {exc_type.__name__}")
                return False
        
        return False

# Suppress ValueError but not TypeError
print("\nSuppressing ValueError:")
try:
    with SelectiveHandler((ValueError,)):
        int("not a number")  # Raises ValueError
    print("Continued after ValueError")
except ValueError:
    print("This won't print - exception was suppressed")

print("\nNot suppressing TypeError:")
try:
    with SelectiveHandler((ValueError,)):
        x = 10 + "20"  # Raises TypeError
    print("This won't execute")
except TypeError as e:
    print(f"Caught TypeError: {e}")


# =============================================================================
# SECTION 4: Practical Example - Database Transaction
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: Practical Example - Database Transaction")
print("=" * 70)

class DatabaseTransaction:
    """
    Simulates a database transaction context manager.
    
    Pattern:
    - __enter__: Begin transaction
    - Normal exit: Commit transaction
    - Exception exit: Rollback transaction
    """
    
    def __init__(self, db_name):
        self.db_name = db_name
        self.transaction_active = False
    
    def __enter__(self):
        """Begin a new transaction"""
        print(f"BEGIN TRANSACTION on {self.db_name}")
        self.transaction_active = True
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Commit or rollback depending on whether an exception occurred"""
        
        if exc_type is None:
            # No exception - commit the transaction
            print(f"COMMIT TRANSACTION on {self.db_name}")
            self.transaction_active = False
        else:
            # Exception occurred - rollback the transaction
            print(f"ROLLBACK TRANSACTION on {self.db_name}")
            print(f"  Reason: {exc_type.__name__}: {exc_value}")
            self.transaction_active = False
        
        # Don't suppress the exception - let it propagate
        return False
    
    def execute(self, query):
        """Simulate executing a database query"""
        if not self.transaction_active:
            raise RuntimeError("No active transaction")
        print(f"  EXECUTE: {query}")


# Example 1: Successful transaction
print("\nExample 1: Successful transaction (commit)")
try:
    with DatabaseTransaction("users.db") as db:
        db.execute("INSERT INTO users VALUES ('Alice', 25)")
        db.execute("INSERT INTO users VALUES ('Bob', 30)")
        # Transaction commits automatically
except Exception as e:
    print(f"Error: {e}")


# Example 2: Failed transaction
print("\nExample 2: Failed transaction (rollback)")
try:
    with DatabaseTransaction("users.db") as db:
        db.execute("INSERT INTO users VALUES ('Charlie', 35)")
        # Simulate an error
        raise ValueError("Invalid data!")
        db.execute("INSERT INTO users VALUES ('David', 40)")  # Won't execute
except ValueError as e:
    print(f"Handled error: {e}")


# =============================================================================
# SECTION 5: Best Practices for __enter__ and __exit__
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: Best Practices")
print("=" * 70)

class BestPracticesDemo:
    """
    Demonstrates best practices for implementing context managers.
    """
    
    def __init__(self, resource_name):
        self.resource_name = resource_name
        self.resource = None
    
    def __enter__(self):
        """
        Best practices for __enter__:
        1. Keep it simple and focused on setup
        2. Return self or a relevant object
        3. Don't catch exceptions here (let them propagate)
        4. Acquire resources here
        """
        print(f"Acquiring resource: {self.resource_name}")
        # Simulate resource acquisition
        self.resource = f"Handle to {self.resource_name}"
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """
        Best practices for __exit__:
        1. ALWAYS clean up resources, even if an exception occurred
        2. Log the exception if needed, but usually don't suppress it
        3. Return False (or None) by default to propagate exceptions
        4. Only return True if you have a good reason to suppress exceptions
        5. Be defensive - handle cleanup errors gracefully
        """
        try:
            if self.resource:
                print(f"Releasing resource: {self.resource_name}")
                # Simulate resource release
                self.resource = None
        except Exception as cleanup_error:
            # Log cleanup errors but don't let them mask the original exception
            print(f"Error during cleanup: {cleanup_error}")
        
        # Don't suppress exceptions unless you have a specific reason
        return False


print("\nBest practices demonstration:")
with BestPracticesDemo("NetworkConnection") as resource:
    print(f"Using resource: {resource.resource}")


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
__enter__ method:
- Called when entering the with block
- Return value is assigned to the 'as' variable
- Performs setup/initialization
- Usually returns self, but can return any object

__exit__ method:
- Called when exiting the with block (always!)
- Receives exception information (if any occurred)
- Performs cleanup/finalization
- Return False to propagate exceptions, True to suppress them
- Should be defensive and handle cleanup errors

Exception handling:
- __exit__ receives three parameters about any exception
- All parameters are None if no exception occurred
- Return True to suppress exceptions (use cautiously!)
- Return False (or None) to propagate exceptions (default)

Best practices:
- Keep __enter__ and __exit__ simple and focused
- Always clean up in __exit__, regardless of exceptions
- Usually propagate exceptions (return False)
- Be defensive in cleanup code
- Document expected behavior
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Create a context manager that prints "START" when entering and "END" when exiting.

2. Create a context manager that measures and prints the time taken in the with block.

3. Create a context manager that changes the current working directory temporarily
   and restores it when done.

4. Create a context manager that suppresses only KeyboardInterrupt exceptions.

5. Create a context manager for a simple logging system that logs entry, exit,
   and any exceptions that occur.

See exercises_beginner.py for more structured problems!
""")
