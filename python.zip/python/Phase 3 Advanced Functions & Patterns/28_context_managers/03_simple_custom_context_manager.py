"""
03_simple_custom_context_manager.py

BEGINNER LEVEL - Creating Simple Custom Context Managers

This module teaches how to create your own context managers from scratch,
starting with simple examples and building up to more practical implementations.

Learning Objectives:
- Create custom context managers for various use cases
- Understand common patterns in context manager design
- Learn to make reusable context managers
- Practice implementing both __enter__ and __exit__ properly
"""

import time
import os
import sys
from datetime import datetime

# =============================================================================
# SECTION 1: Your First Custom Context Manager
# =============================================================================

print("=" * 70)
print("SECTION 1: Your First Custom Context Manager")
print("=" * 70)

class HelloWorld:
    """
    The simplest possible context manager.
    This demonstrates the bare minimum required structure.
    """
    
    def __enter__(self):
        """Called when entering the with block"""
        print("Hello, entering the context!")
        return self  # Convention: return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Called when exiting the with block"""
        print("Goodbye, exiting the context!")
        return False  # Don't suppress exceptions

print("\nUsing HelloWorld context manager:")
with HelloWorld():
    print("  Inside the with block")


# =============================================================================
# SECTION 2: Timer Context Manager
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: Timer Context Manager")
print("=" * 70)

class Timer:
    """
    A practical context manager that times code execution.
    
    This is one of the most common uses for custom context managers:
    measuring performance of code blocks.
    """
    
    def __init__(self, description="Code block"):
        """
        Args:
            description: A description of what's being timed
        """
        self.description = description
        self.start_time = None
        self.end_time = None
        self.elapsed = None
    
    def __enter__(self):
        """Start the timer"""
        self.start_time = time.time()
        print(f"⏱️  Timer started for: {self.description}")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Stop the timer and print elapsed time"""
        self.end_time = time.time()
        self.elapsed = self.end_time - self.start_time
        print(f"⏱️  Timer stopped for: {self.description}")
        print(f"⏱️  Elapsed time: {self.elapsed:.4f} seconds")
        return False


# Example 1: Timing a simple operation
print("\nExample 1: Timing a simple calculation")
with Timer("Simple calculation"):
    result = sum(range(1000000))
    print(f"  Result: {result}")


# Example 2: Timing with access to elapsed time
print("\nExample 2: Accessing the timer object")
with Timer("Sleep operation") as t:
    time.sleep(0.5)
    print(f"  Doing work...")

# We can access the timer's elapsed time after the with block
print(f"Final elapsed time: {t.elapsed:.4f} seconds")


# =============================================================================
# SECTION 3: File Writer with Automatic Header/Footer
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: File Writer with Automatic Header/Footer")
print("=" * 70)

class DocumentWriter:
    """
    A context manager that automatically adds headers and footers to files.
    
    This demonstrates wrapping existing resources (files) with additional behavior.
    """
    
    def __init__(self, filename, title):
        """
        Args:
            filename: Name of file to write
            title: Title for the document
        """
        self.filename = filename
        self.title = title
        self.file = None
    
    def __enter__(self):
        """Open file and write header"""
        self.file = open(self.filename, 'w')
        
        # Write header
        self.file.write("=" * 50 + "\n")
        self.file.write(f"{self.title.center(50)}\n")
        self.file.write("=" * 50 + "\n")
        self.file.write(f"Generated: {datetime.now()}\n")
        self.file.write("=" * 50 + "\n\n")
        
        print(f"Document opened: {self.filename}")
        return self.file  # Return the file object for writing
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Write footer and close file"""
        if self.file:
            # Write footer
            self.file.write("\n" + "=" * 50 + "\n")
            self.file.write("End of document\n")
            self.file.write("=" * 50 + "\n")
            
            self.file.close()
            print(f"Document closed: {self.filename}")
        
        return False


# Using the DocumentWriter
print("\nCreating a document:")
with DocumentWriter('/tmp/report.txt', 'Monthly Sales Report') as doc:
    doc.write("Sales for January: $10,000\n")
    doc.write("Sales for February: $12,000\n")
    doc.write("Sales for March: $15,000\n")
    print("  Content written")

# Read and display the file
print("\nDocument contents:")
with open('/tmp/report.txt', 'r') as f:
    print(f.read())


# =============================================================================
# SECTION 4: Directory Changer
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: Directory Changer")
print("=" * 70)

class ChangeDirectory:
    """
    A context manager that temporarily changes the current working directory.
    
    This demonstrates temporarily modifying global state and restoring it.
    Very useful pattern for file operations in specific directories.
    """
    
    def __init__(self, new_dir):
        """
        Args:
            new_dir: Directory to change to
        """
        self.new_dir = new_dir
        self.old_dir = None
    
    def __enter__(self):
        """Save current directory and change to new one"""
        self.old_dir = os.getcwd()
        os.chdir(self.new_dir)
        print(f"Changed directory:")
        print(f"  From: {self.old_dir}")
        print(f"  To:   {self.new_dir}")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Restore original directory"""
        os.chdir(self.old_dir)
        print(f"Restored directory to: {self.old_dir}")
        return False


# Example usage
print("\nUsing directory changer:")
print(f"Current directory: {os.getcwd()}")

with ChangeDirectory('/tmp'):
    print(f"Inside with block: {os.getcwd()}")
    # Do work in /tmp directory
    with open('temp_file.txt', 'w') as f:
        f.write('Temporary file in /tmp')

print(f"After with block: {os.getcwd()}")


# =============================================================================
# SECTION 5: State Saver
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: State Saver")
print("=" * 70)

class StateSaver:
    """
    A context manager that saves and restores the state of an object's attribute.
    
    This is useful when you need to temporarily modify an object and ensure
    it's restored to its original state.
    """
    
    def __init__(self, obj, attribute_name):
        """
        Args:
            obj: The object whose attribute we'll save/restore
            attribute_name: Name of the attribute to save/restore
        """
        self.obj = obj
        self.attribute_name = attribute_name
        self.original_value = None
    
    def __enter__(self):
        """Save the current value of the attribute"""
        self.original_value = getattr(self.obj, self.attribute_name)
        print(f"Saved {self.attribute_name} = {self.original_value}")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Restore the original value"""
        setattr(self.obj, self.attribute_name, self.original_value)
        print(f"Restored {self.attribute_name} = {self.original_value}")
        return False


# Example: Temporarily modify sys.stdout
print("\nExample: Temporarily redirecting stdout")

class Config:
    """Sample class with configurable settings"""
    def __init__(self):
        self.debug_mode = False
        self.log_level = "INFO"

config = Config()
print(f"Initial debug_mode: {config.debug_mode}")

# Temporarily enable debug mode
with StateSaver(config, 'debug_mode'):
    config.debug_mode = True
    print(f"  Inside with block, debug_mode: {config.debug_mode}")

print(f"After with block, debug_mode: {config.debug_mode}")


# =============================================================================
# SECTION 6: List Transaction
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 6: List Transaction")
print("=" * 70)

class ListTransaction:
    """
    A context manager that allows you to make changes to a list,
    but rolls back if an exception occurs.
    
    This demonstrates the "transaction" pattern: commit on success,
    rollback on failure.
    """
    
    def __init__(self, target_list):
        """
        Args:
            target_list: The list to manage transactionally
        """
        self.target_list = target_list
        self.backup = None
    
    def __enter__(self):
        """Create a backup of the list"""
        # Create a copy of the list
        self.backup = self.target_list.copy()
        print(f"Transaction started. Backed up list: {self.backup}")
        return self.target_list
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Commit or rollback based on whether an exception occurred"""
        if exc_type is None:
            # No exception - commit (do nothing, changes remain)
            print("Transaction committed. Changes saved.")
        else:
            # Exception occurred - rollback
            print(f"Exception occurred: {exc_type.__name__}")
            print("Transaction rolled back. Restoring original list.")
            # Restore the original list contents
            self.target_list.clear()
            self.target_list.extend(self.backup)
        
        return False  # Don't suppress exceptions


# Example 1: Successful transaction
print("\nExample 1: Successful transaction")
my_list = [1, 2, 3]
print(f"Before: {my_list}")

with ListTransaction(my_list) as lst:
    lst.append(4)
    lst.append(5)
    print(f"  During transaction: {lst}")

print(f"After (committed): {my_list}")


# Example 2: Failed transaction
print("\nExample 2: Failed transaction")
my_list = [1, 2, 3]
print(f"Before: {my_list}")

try:
    with ListTransaction(my_list) as lst:
        lst.append(4)
        lst.append(5)
        print(f"  During transaction: {lst}")
        # Simulate an error
        raise ValueError("Something went wrong!")
        lst.append(6)  # This won't execute
except ValueError as e:
    print(f"  Caught exception: {e}")

print(f"After (rolled back): {my_list}")


# =============================================================================
# SECTION 7: Indented Printer
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 7: Indented Printer")
print("=" * 70)

class IndentedPrinter:
    """
    A context manager that indents printed output.
    
    This demonstrates how context managers can be nested for hierarchical output.
    Each nested level adds more indentation.
    """
    
    # Class variable to track current indentation level
    indent_level = 0
    indent_string = "  "
    
    def __init__(self, title=None):
        """
        Args:
            title: Optional title to print when entering context
        """
        self.title = title
    
    def __enter__(self):
        """Increase indentation level"""
        if self.title:
            self.print(f"▼ {self.title}")
        IndentedPrinter.indent_level += 1
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Decrease indentation level"""
        IndentedPrinter.indent_level -= 1
        if self.title:
            self.print(f"▲ End of {self.title}")
        return False
    
    @classmethod
    def print(cls, message):
        """Print with current indentation"""
        indent = cls.indent_string * cls.indent_level
        print(f"{indent}{message}")


# Example: Nested indentation for hierarchical output
print("\nExample: Nested indentation")

IndentedPrinter.print("Top level")

with IndentedPrinter("Section 1"):
    IndentedPrinter.print("Content of section 1")
    
    with IndentedPrinter("Subsection 1.1"):
        IndentedPrinter.print("Content of subsection 1.1")
        
        with IndentedPrinter("Sub-subsection 1.1.1"):
            IndentedPrinter.print("Deep content")
    
    with IndentedPrinter("Subsection 1.2"):
        IndentedPrinter.print("Content of subsection 1.2")

with IndentedPrinter("Section 2"):
    IndentedPrinter.print("Content of section 2")

IndentedPrinter.print("Back to top level")


# =============================================================================
# SECTION 8: Reusable Context Managers
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 8: Reusable Context Managers")
print("=" * 70)

class Counter:
    """
    A reusable context manager that can be used multiple times.
    
    Important: Make sure your context manager can be used multiple times
    by properly resetting state in __enter__ or __init__.
    """
    
    def __init__(self, name):
        self.name = name
        self.count = 0
        self.current_count = 0
    
    def __enter__(self):
        """Increment and track entry count"""
        self.count += 1
        self.current_count = self.count
        print(f"[{self.name}] Entered (entry #{self.current_count})")
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Clean exit"""
        print(f"[{self.name}] Exited (entry #{self.current_count})")
        return False


# Using the same context manager multiple times
print("\nUsing reusable context manager:")
counter = Counter("MyCounter")

with counter:
    print("  First use")

with counter:
    print("  Second use")

with counter:
    print("  Third use")

print(f"Total entries: {counter.count}")


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
Creating custom context managers:
1. Implement __enter__ and __exit__ methods
2. __enter__ performs setup and returns an object (usually self)
3. __exit__ performs cleanup and handles exceptions
4. Return False from __exit__ to propagate exceptions

Common patterns:
- Timer: Measure execution time
- State saver: Save and restore state
- Resource wrapper: Add behavior to existing resources
- Transaction: Commit on success, rollback on failure
- Indentation: Hierarchical output formatting

Design principles:
- Keep __enter__ and __exit__ focused and simple
- Make context managers reusable when possible
- Clean up resources in __exit__ regardless of exceptions
- Document expected behavior and usage
- Consider what __enter__ should return

Best practices:
- Always clean up in __exit__, even if exceptions occur
- Usually return False from __exit__ (propagate exceptions)
- Initialize state properly for reusable context managers
- Make the interface intuitive for users
- Test with both normal and exceptional flows
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Create a context manager that redirects print statements to a file.

2. Create a context manager that temporarily changes an environment variable
   and restores it when done.

3. Create a context manager that prints a progress indicator (spinner)
   while code is running.

4. Create a context manager that suppresses print statements entirely.

5. Create a "Profiler" context manager that tracks:
   - Start time
   - End time
   - Peak memory usage
   - Number of function calls (hint: use sys.settrace)

6. Create a context manager for a simple "shopping cart" that allows adding
   items, but only "purchases" them (commits) if no exception occurs.

See exercises_beginner.py for more structured problems!
""")
