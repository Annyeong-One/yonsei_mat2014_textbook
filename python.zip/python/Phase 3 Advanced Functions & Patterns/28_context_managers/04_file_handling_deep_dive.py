"""
04_file_handling_deep_dive.py

BEGINNER LEVEL - File Handling with Context Managers (Deep Dive)

This module provides comprehensive coverage of file handling using context managers,
including various modes, binary files, and best practices.

Learning Objectives:
- Master all file opening modes
- Handle text and binary files correctly
- Understand encoding and newline handling
- Work with multiple files simultaneously
- Implement custom file-like context managers
"""

import os
import csv
import json

# =============================================================================
# SECTION 1: File Opening Modes Review
# =============================================================================

print("=" * 70)
print("SECTION 1: File Opening Modes Review")
print("=" * 70)

"""
File opening modes:

Text modes:
'r'  - Read only (default). File must exist.
'w'  - Write only. Creates file or truncates existing file.
'a'  - Append only. Creates file if doesn't exist.
'r+' - Read and write. File must exist.
'w+' - Read and write. Creates file or truncates existing file.
'a+' - Read and append. Creates file if doesn't exist.

Binary modes (add 'b' to any mode):
'rb'  - Read binary
'wb'  - Write binary
'ab'  - Append binary
'rb+' - Read and write binary
'wb+' - Write and read binary
'ab+' - Append and read binary

Exclusive creation:
'x'   - Create new file, fail if exists
'xb'  - Create new binary file, fail if exists
"""

# Example 1: Writing text file
print("\nExample 1: Writing to a file ('w' mode)")
with open('/tmp/write_demo.txt', 'w') as f:
    f.write("First line\n")
    f.write("Second line\n")
    f.write("Third line\n")
print("File written successfully")


# Example 2: Reading text file
print("\nExample 2: Reading from a file ('r' mode)")
with open('/tmp/write_demo.txt', 'r') as f:
    content = f.read()
    print("File contents:")
    print(content)


# Example 3: Appending to file
print("\nExample 3: Appending to a file ('a' mode)")
with open('/tmp/write_demo.txt', 'a') as f:
    f.write("Fourth line (appended)\n")
    f.write("Fifth line (appended)\n")

# Read to verify
with open('/tmp/write_demo.txt', 'r') as f:
    print("Updated contents:")
    print(f.read())


# Example 4: Read and write mode
print("\nExample 4: Read and write mode ('r+' mode)")
with open('/tmp/write_demo.txt', 'r+') as f:
    # Read first
    content = f.read()
    print(f"Read {len(content)} characters")
    
    # Seek to end and write
    f.seek(0, 2)  # 2 means end of file
    f.write("Sixth line (via r+)\n")


# Example 5: Exclusive creation
print("\nExample 5: Exclusive creation ('x' mode)")
try:
    with open('/tmp/new_file.txt', 'x') as f:
        f.write("This file didn't exist before\n")
    print("New file created successfully")
except FileExistsError:
    print("File already exists, cannot create with 'x' mode")


# =============================================================================
# SECTION 2: Reading Files Line by Line
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: Reading Files Line by Line")
print("=" * 70)

# Create a sample file
with open('/tmp/lines.txt', 'w') as f:
    for i in range(1, 6):
        f.write(f"Line {i}\n")

# Method 1: read() - reads entire file as string
print("\nMethod 1: read() - entire file as string")
with open('/tmp/lines.txt', 'r') as f:
    content = f.read()
    print(f"Type: {type(content)}")
    print(f"Content:\n{content}")


# Method 2: readline() - reads one line at a time
print("\nMethod 2: readline() - one line at a time")
with open('/tmp/lines.txt', 'r') as f:
    line1 = f.readline()
    line2 = f.readline()
    print(f"First line: {line1.strip()}")
    print(f"Second line: {line2.strip()}")


# Method 3: readlines() - returns list of all lines
print("\nMethod 3: readlines() - list of all lines")
with open('/tmp/lines.txt', 'r') as f:
    lines = f.readlines()
    print(f"Type: {type(lines)}")
    print(f"Number of lines: {len(lines)}")
    for i, line in enumerate(lines, 1):
        print(f"  Line {i}: {line.strip()}")


# Method 4: Iterating over file object (BEST for large files!)
print("\nMethod 4: Iterating over file object (BEST METHOD!)")
with open('/tmp/lines.txt', 'r') as f:
    for line_num, line in enumerate(f, 1):
        print(f"  Line {line_num}: {line.strip()}")


# Method 5: Reading specific number of characters
print("\nMethod 5: Reading specific number of characters")
with open('/tmp/lines.txt', 'r') as f:
    chunk1 = f.read(10)  # Read first 10 characters
    chunk2 = f.read(10)  # Read next 10 characters
    print(f"Chunk 1: '{chunk1}'")
    print(f"Chunk 2: '{chunk2}'")


# =============================================================================
# SECTION 3: Binary Files
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: Binary Files")
print("=" * 70)

# Example 1: Writing binary data
print("\nExample 1: Writing binary data")
binary_data = bytes([0x48, 0x65, 0x6C, 0x6C, 0x6F])  # "Hello" in hex
with open('/tmp/binary_demo.bin', 'wb') as f:
    f.write(binary_data)
    print(f"Wrote {len(binary_data)} bytes")


# Example 2: Reading binary data
print("\nExample 2: Reading binary data")
with open('/tmp/binary_demo.bin', 'rb') as f:
    data = f.read()
    print(f"Read bytes: {data}")
    print(f"As string: {data.decode('utf-8')}")


# Example 3: Working with binary integers
print("\nExample 3: Writing binary integers")
import struct

# Write integers in binary format
with open('/tmp/integers.bin', 'wb') as f:
    # Pack integers as binary data (4 bytes each, little-endian)
    for num in [100, 200, 300, 400, 500]:
        binary = struct.pack('<i', num)  # '<i' = little-endian signed int
        f.write(binary)

# Read integers back
print("Reading binary integers:")
with open('/tmp/integers.bin', 'rb') as f:
    while True:
        binary = f.read(4)  # Read 4 bytes
        if not binary:
            break
        num = struct.unpack('<i', binary)[0]
        print(f"  Read integer: {num}")


# =============================================================================
# SECTION 4: File Encoding
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: File Encoding")
print("=" * 70)

# Example 1: UTF-8 encoding (default and recommended)
print("\nExample 1: UTF-8 encoding (handles all Unicode)")
text_with_emoji = "Hello! 你好! こんにちは! 🎉🎊"
with open('/tmp/utf8_demo.txt', 'w', encoding='utf-8') as f:
    f.write(text_with_emoji)

with open('/tmp/utf8_demo.txt', 'r', encoding='utf-8') as f:
    content = f.read()
    print(f"Content: {content}")


# Example 2: Different encodings
print("\nExample 2: Latin-1 encoding (Western European)")
latin_text = "Café résumé"
with open('/tmp/latin1_demo.txt', 'w', encoding='latin-1') as f:
    f.write(latin_text)

with open('/tmp/latin1_demo.txt', 'r', encoding='latin-1') as f:
    content = f.read()
    print(f"Content: {content}")


# Example 3: Handling encoding errors
print("\nExample 3: Handling encoding errors")
# Write with UTF-8
with open('/tmp/encoding_test.txt', 'w', encoding='utf-8') as f:
    f.write("Hello 世界")

# Try to read with ASCII (will fail by default)
try:
    with open('/tmp/encoding_test.txt', 'r', encoding='ascii') as f:
        content = f.read()
except UnicodeDecodeError as e:
    print(f"Error: {e}")

# Read with error handling
with open('/tmp/encoding_test.txt', 'r', encoding='ascii', errors='ignore') as f:
    content = f.read()
    print(f"With errors='ignore': '{content}'")

with open('/tmp/encoding_test.txt', 'r', encoding='ascii', errors='replace') as f:
    content = f.read()
    print(f"With errors='replace': '{content}'")


# =============================================================================
# SECTION 5: Working with Multiple Files
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: Working with Multiple Files")
print("=" * 70)

# Example 1: Reading from one file, writing to another
print("\nExample 1: File copying")
# Create source file
with open('/tmp/source.txt', 'w') as f:
    f.write("Line 1\nLine 2\nLine 3\n")

# Copy to destination
with open('/tmp/source.txt', 'r') as source, \
     open('/tmp/destination.txt', 'w') as dest:
    content = source.read()
    dest.write(content)
    print("File copied successfully")


# Example 2: Processing multiple files
print("\nExample 2: Merging multiple files")
# Create multiple source files
for i in range(1, 4):
    with open(f'/tmp/part{i}.txt', 'w') as f:
        f.write(f"Content of part {i}\n")

# Merge them
with open('/tmp/merged.txt', 'w') as output:
    for i in range(1, 4):
        with open(f'/tmp/part{i}.txt', 'r') as input_file:
            content = input_file.read()
            output.write(content)

print("Files merged. Result:")
with open('/tmp/merged.txt', 'r') as f:
    print(f.read())


# =============================================================================
# SECTION 6: CSV Files with Context Managers
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 6: CSV Files with Context Managers")
print("=" * 70)

# Writing CSV
print("\nWriting CSV file:")
data = [
    ['Name', 'Age', 'City'],
    ['Alice', '25', 'New York'],
    ['Bob', '30', 'San Francisco'],
    ['Charlie', '35', 'Chicago']
]

with open('/tmp/people.csv', 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerows(data)
print("CSV file written")

# Reading CSV
print("\nReading CSV file:")
with open('/tmp/people.csv', 'r', newline='') as f:
    reader = csv.reader(f)
    for row in reader:
        print(f"  {row}")


# =============================================================================
# SECTION 7: JSON Files with Context Managers
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 7: JSON Files with Context Managers")
print("=" * 70)

# Writing JSON
print("\nWriting JSON file:")
data = {
    'name': 'Alice',
    'age': 25,
    'city': 'New York',
    'hobbies': ['reading', 'coding', 'hiking']
}

with open('/tmp/data.json', 'w') as f:
    json.dump(data, f, indent=2)
print("JSON file written")

# Reading JSON
print("\nReading JSON file:")
with open('/tmp/data.json', 'r') as f:
    loaded_data = json.load(f)
    print(f"  Name: {loaded_data['name']}")
    print(f"  Age: {loaded_data['age']}")
    print(f"  Hobbies: {', '.join(loaded_data['hobbies'])}")


# =============================================================================
# SECTION 8: Custom File-like Context Manager
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 8: Custom File-like Context Manager")
print("=" * 70)

class SafeFileWriter:
    """
    A context manager that writes to a temporary file first,
    then renames it to the target filename only if successful.
    
    This prevents corruption of the target file if writing fails.
    """
    
    def __init__(self, filename):
        self.filename = filename
        self.temp_filename = filename + '.tmp'
        self.file = None
    
    def __enter__(self):
        """Open temporary file for writing"""
        self.file = open(self.temp_filename, 'w')
        print(f"Writing to temporary file: {self.temp_filename}")
        return self.file
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Close file and rename if successful"""
        if self.file:
            self.file.close()
        
        if exc_type is None:
            # No exception - rename temp file to target
            os.rename(self.temp_filename, self.filename)
            print(f"Success! Renamed to: {self.filename}")
        else:
            # Exception occurred - remove temp file
            if os.path.exists(self.temp_filename):
                os.remove(self.temp_filename)
            print(f"Error occurred, temporary file removed")
        
        return False


# Example 1: Successful write
print("\nExample 1: Successful write")
with SafeFileWriter('/tmp/safe_output.txt') as f:
    f.write("Line 1\n")
    f.write("Line 2\n")
    f.write("Line 3\n")


# Example 2: Failed write
print("\nExample 2: Failed write")
try:
    with SafeFileWriter('/tmp/safe_output2.txt') as f:
        f.write("Line 1\n")
        raise ValueError("Simulated error!")
        f.write("Line 2\n")  # Won't execute
except ValueError:
    print("Exception handled")

print("Checking if safe_output2.txt exists:", 
      os.path.exists('/tmp/safe_output2.txt'))


# =============================================================================
# SECTION 9: File Buffering
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 9: File Buffering")
print("=" * 70)

"""
File buffering modes:
- buffering=0: Unbuffered (binary mode only)
- buffering=1: Line buffered (text mode only)
- buffering>1: Fixed size buffer
- buffering=-1: System default (usually 4096 or 8192 bytes)
"""

# Example: Line buffering (useful for log files)
print("\nLine-buffered file (immediately flushes each line):")
with open('/tmp/line_buffered.txt', 'w', buffering=1) as f:
    f.write("Line 1\n")  # Flushed immediately
    f.write("Line 2\n")  # Flushed immediately
    f.write("Line 3")    # Not flushed (no newline)
    f.flush()            # Manual flush
print("File written with line buffering")


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
File opening modes:
- 'r': read, 'w': write (truncate), 'a': append
- Add '+' for read/write
- Add 'b' for binary mode
- Use 'x' for exclusive creation

Reading methods:
- read(): entire file as string (small files)
- readline(): one line at a time
- readlines(): list of all lines
- Iteration: for line in file (BEST for large files)

Binary files:
- Use 'b' mode: 'rb', 'wb', 'ab'
- Data as bytes objects
- Use struct module for binary data structures

Encoding:
- Always specify encoding for text files
- UTF-8 is recommended default
- Handle encoding errors with errors parameter

Multiple files:
- Use multiple with clauses or comma-separated
- Close automatically even if exceptions occur

Best practices:
- Always use context managers for file operations
- Specify encoding explicitly
- Use iteration for large files
- Handle exceptions appropriately
- Close files implicitly with 'with'
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Write a function that counts the number of lines, words, and characters
   in a text file using a context manager.

2. Create a file copier that handles both text and binary files correctly.

3. Write a CSV reader that converts a CSV file into a list of dictionaries.

4. Create a context manager that writes to multiple log files simultaneously
   (e.g., info.log, error.log, debug.log).

5. Implement a context manager that compresses data before writing to a file
   and decompresses when reading (hint: use gzip module).

6. Create a context manager for a configuration file that supports both
   reading and writing, with automatic backup before modifications.

See exercises_beginner.py for more structured problems!
""")
