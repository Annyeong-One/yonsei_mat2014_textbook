"""
05_contextlib_module.py

INTERMEDIATE LEVEL - The contextlib Module

This module explores the contextlib module, which provides utilities for
working with context managers, including the @contextmanager decorator
which simplifies context manager creation.

Learning Objectives:
- Master the @contextmanager decorator
- Understand generator-based context managers
- Use contextlib utilities (suppress, redirect_stdout, etc.)
- Compare class-based vs decorator-based approaches
- Create reusable context manager factories
"""

from contextlib import (
    contextmanager, suppress, redirect_stdout, redirect_stderr,
    closing, ExitStack, nullcontext
)
import io
import sys
import time

# =============================================================================
# SECTION 1: The @contextmanager Decorator
# =============================================================================

print("=" * 70)
print("SECTION 1: The @contextmanager Decorator")
print("=" * 70)

"""
The @contextmanager decorator allows you to write a context manager as a
generator function instead of a class with __enter__ and __exit__ methods.

Structure:
@contextmanager
def my_context():
    # Code before yield = __enter__ code
    yield value  # Value given to 'as' variable
    # Code after yield = __exit__ code
"""

@contextmanager
def simple_context():
    """
    A simple context manager using @contextmanager decorator.
    
    The yield statement divides the function into two parts:
    - Before yield: runs when entering (like __enter__)
    - After yield: runs when exiting (like __exit__)
    """
    print("Entering context")
    yield  # Execution of with block happens here
    print("Exiting context")

print("\nExample 1: Basic @contextmanager")
with simple_context():
    print("  Inside with block")


@contextmanager
def greeting_context(name):
    """Context manager with parameters and return value"""
    print(f"Hello, {name}!")
    yield f"Welcome message for {name}"  # This is returned to 'as' variable
    print(f"Goodbye, {name}!")

print("\nExample 2: With parameters and return value")
with greeting_context("Alice") as message:
    print(f"  Message: {message}")


# =============================================================================
# SECTION 2: Exception Handling in @contextmanager
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: Exception Handling in @contextmanager")
print("=" * 70)

@contextmanager
def error_handler():
    """
    To handle exceptions in @contextmanager, wrap the yield in try/finally.
    
    Important:
    - Code in 'finally' always runs (like __exit__)
    - To catch and suppress exceptions, use try/except around yield
    """
    print("Setup")
    try:
        yield
    except Exception as e:
        print(f"Caught exception: {e}")
        # Not re-raising = suppressing the exception
    finally:
        print("Cleanup (always runs)")

print("\nExample: Exception handling")
with error_handler():
    print("  About to raise an error")
    raise ValueError("Test error")
    print("  This won't print")

print("Continued after with block (exception was suppressed)")


@contextmanager
def transaction():
    """
    Demonstrates commit/rollback pattern with exceptions.
    """
    print("BEGIN TRANSACTION")
    try:
        yield
        print("COMMIT")  # Only runs if no exception
    except Exception as e:
        print(f"ROLLBACK (due to {e})")
        raise  # Re-raise the exception
    finally:
        print("Transaction ended")

print("\nExample: Transaction pattern - success")
try:
    with transaction():
        print("  Executing queries...")
        print("  All queries successful")
except Exception:
    pass

print("\nExample: Transaction pattern - failure")
try:
    with transaction():
        print("  Executing queries...")
        raise ValueError("Query failed!")
except ValueError as e:
    print(f"Handled: {e}")


# =============================================================================
# SECTION 3: Practical @contextmanager Examples
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: Practical @contextmanager Examples")
print("=" * 70)

# Example 1: Timer
@contextmanager
def timer(name):
    """Simple timer context manager"""
    start = time.time()
    print(f"[{name}] Starting...")
    yield
    elapsed = time.time() - start
    print(f"[{name}] Finished in {elapsed:.4f} seconds")

print("\nExample 1: Timer")
with timer("My operation"):
    time.sleep(0.5)
    print("  Doing work...")


# Example 2: Temporary attribute change
@contextmanager
def temporary_attr(obj, attr_name, temp_value):
    """
    Temporarily change an object's attribute, then restore it.
    """
    # Save original value
    original_value = getattr(obj, attr_name)
    print(f"Saving {attr_name}: {original_value}")
    
    # Set temporary value
    setattr(obj, attr_name, temp_value)
    print(f"Setting {attr_name}: {temp_value}")
    
    try:
        yield obj
    finally:
        # Restore original value
        setattr(obj, attr_name, original_value)
        print(f"Restored {attr_name}: {original_value}")

print("\nExample 2: Temporary attribute change")
class Config:
    debug = False

config = Config()
print(f"Initial debug: {config.debug}")

with temporary_attr(config, 'debug', True):
    print(f"  Inside with: {config.debug}")

print(f"After with: {config.debug}")


# Example 3: Working directory
import os

@contextmanager
def working_directory(path):
    """
    Temporarily change working directory.
    """
    old_dir = os.getcwd()
    os.chdir(path)
    print(f"Changed to: {path}")
    try:
        yield path
    finally:
        os.chdir(old_dir)
        print(f"Restored to: {old_dir}")

print("\nExample 3: Working directory")
print(f"Current: {os.getcwd()}")
with working_directory('/tmp'):
    print(f"  Inside with: {os.getcwd()}")
print(f"After: {os.getcwd()}")


# =============================================================================
# SECTION 4: contextlib.suppress
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: contextlib.suppress")
print("=" * 70)

"""
suppress(*exceptions) - Suppresses specified exceptions.
Cleaner than try/except when you just want to ignore exceptions.
"""

print("\nWithout suppress:")
try:
    os.remove('/tmp/nonexistent.txt')
    print("File removed")
except FileNotFoundError:
    print("File doesn't exist (expected)")

print("\nWith suppress:")
with suppress(FileNotFoundError):
    os.remove('/tmp/nonexistent.txt')
    print("File removed")
print("No exception raised")


# Suppressing multiple exception types
print("\nSuppressing multiple exceptions:")
with suppress(ValueError, TypeError, KeyError):
    data = {'a': 1}
    value = data['b']  # KeyError - suppressed
print("KeyError was suppressed")


# =============================================================================
# SECTION 5: contextlib.redirect_stdout and redirect_stderr
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: redirect_stdout and redirect_stderr")
print("=" * 70)

"""
redirect_stdout(new_target) - Redirects sys.stdout to new_target
redirect_stderr(new_target) - Redirects sys.stderr to new_target

Useful for capturing output or redirecting to files.
"""

print("\nExample 1: Capturing stdout")
output = io.StringIO()
with redirect_stdout(output):
    print("This goes to output, not console")
    print("So does this")

captured = output.getvalue()
print(f"Captured: '{captured}'")


print("\nExample 2: Redirecting to file")
with open('/tmp/output.log', 'w') as f:
    with redirect_stdout(f):
        print("This line goes to the file")
        print("So does this one")

with open('/tmp/output.log', 'r') as f:
    print(f"File contents: {f.read()}")


print("\nExample 3: Silencing output")
with redirect_stdout(io.StringIO()):
    print("You won't see this")
    print("Or this")
print("Back to normal output")


# =============================================================================
# SECTION 6: contextlib.closing
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 6: contextlib.closing")
print("=" * 70)

"""
closing(obj) - Ensures obj.close() is called when exiting the context.
Useful for objects that have a close() method but don't support
the context manager protocol.
"""

class Connection:
    """Simulates a connection that doesn't support context managers"""
    def __init__(self, name):
        self.name = name
        self.is_open = True
        print(f"Connection '{name}' opened")
    
    def close(self):
        """Has close method but not __enter__/__exit__"""
        self.is_open = False
        print(f"Connection '{name}' closed")
    
    def send_data(self, data):
        if self.is_open:
            print(f"  Sending: {data}")
        else:
            print("  Connection is closed!")

print("\nUsing closing():")
with closing(Connection("DB1")) as conn:
    conn.send_data("Hello")
    conn.send_data("World")
# close() is called automatically


# =============================================================================
# SECTION 7: contextlib.ExitStack
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 7: contextlib.ExitStack")
print("=" * 70)

"""
ExitStack - Manages a variable number of context managers.
Useful when you don't know how many context managers you'll need at runtime.
"""

print("\nExample 1: Managing multiple files")
file_names = ['/tmp/file1.txt', '/tmp/file2.txt', '/tmp/file3.txt']

with ExitStack() as stack:
    # Open multiple files and add them to the stack
    files = [stack.enter_context(open(fname, 'w')) for fname in file_names]
    
    # Write to all files
    for i, f in enumerate(files, 1):
        f.write(f"Content of file {i}\n")
        print(f"Wrote to {f.name}")
    
    # All files are automatically closed when exiting

print("\nVerifying files are closed:")
for f in files:
    print(f"{f.name}: closed = {f.closed}")


print("\nExample 2: Conditional context managers")
def open_files(count):
    """Open a variable number of files"""
    with ExitStack() as stack:
        files = []
        for i in range(count):
            f = stack.enter_context(open(f'/tmp/dynamic_{i}.txt', 'w'))
            files.append(f)
        
        print(f"Opened {len(files)} files")
        for f in files:
            f.write("Data\n")
        
        return files  # Files are still open here
    # All files closed automatically after exiting ExitStack

files = open_files(5)
print(f"All files closed: {all(f.closed for f in files)}")


# =============================================================================
# SECTION 8: contextlib.nullcontext
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 8: contextlib.nullcontext")
print("=" * 70)

"""
nullcontext(enter_result=None) - A context manager that does nothing.
Useful as a placeholder when context manager usage is conditional.
"""

def process_data(use_timer=True):
    """Example of conditional context manager"""
    # Use timer or nullcontext based on flag
    timer_context = timer("Processing") if use_timer else nullcontext()
    
    with timer_context:
        time.sleep(0.2)
        print("  Processing data...")

print("\nWith timer:")
process_data(use_timer=True)

print("\nWithout timer:")
process_data(use_timer=False)


# =============================================================================
# SECTION 9: Class-based vs Decorator-based Comparison
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 9: Class-based vs Decorator-based Comparison")
print("=" * 70)

# Class-based approach
class ClassTimer:
    """Timer implemented as a class"""
    def __init__(self, name):
        self.name = name
        self.start = None
        self.elapsed = None
    
    def __enter__(self):
        self.start = time.time()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.elapsed = time.time() - self.start
        print(f"[Class] {self.name}: {self.elapsed:.4f}s")
        return False

# Decorator-based approach
@contextmanager
def decorator_timer(name):
    """Timer implemented with decorator"""
    start = time.time()
    yield
    elapsed = time.time() - start
    print(f"[Decorator] {name}: {elapsed:.4f}s")

print("\nClass-based:")
with ClassTimer("Test1"):
    time.sleep(0.1)

print("\nDecorator-based:")
with decorator_timer("Test2"):
    time.sleep(0.1)


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
@contextmanager decorator:
- Converts generator functions into context managers
- Code before yield = __enter__
- Code after yield = __exit__
- Use try/finally for cleanup
- Simpler than class-based approach for simple cases

contextlib utilities:
- suppress(): Suppress specific exceptions
- redirect_stdout/stderr(): Redirect output streams
- closing(): Auto-close objects with close() method
- ExitStack: Manage variable number of context managers
- nullcontext(): No-op context manager for conditional use

When to use decorator vs class:
- Decorator: Simpler cases, one-time use
- Class: Complex state, reusability, multiple methods

Best practices:
- Use @contextmanager for simple, linear setup/teardown
- Use classes when you need stateful context managers
- Use suppress() instead of empty try/except
- Use ExitStack for dynamic number of resources
- Always clean up in finally block or after yield
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Create a @contextmanager that measures peak memory usage during execution.

2. Implement a context manager using @contextmanager that creates a temporary
   directory, yields it, and removes it when done.

3. Create a context manager that changes environment variables temporarily
   using @contextmanager.

4. Use ExitStack to open and process a list of files where the list length
   is determined at runtime.

5. Create a context manager that suppresses output (both stdout and stderr)
   using contextlib utilities.

6. Implement the same timer context manager both ways (class and decorator)
   and compare them.

See exercises_intermediate.py for more structured problems!
""")
