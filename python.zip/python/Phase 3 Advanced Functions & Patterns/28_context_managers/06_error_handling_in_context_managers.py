"""
06_error_handling_in_context_managers.py

INTERMEDIATE LEVEL - Error Handling in Context Managers

This module provides comprehensive coverage of exception handling within
context managers, including best practices and common patterns.

Learning Objectives:
- Master exception handling in __exit__ method
- Understand exception suppression patterns
- Implement proper error logging
- Handle cleanup errors safely
- Create robust context managers
"""

import sys
import traceback
import logging
from contextlib import contextmanager

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')

# =============================================================================
# SECTION 1: Understanding __exit__ Exception Parameters
# =============================================================================

print("=" * 70)
print("SECTION 1: Understanding __exit__ Exception Parameters")
print("=" * 70)

class ExceptionInspector:
    """
    Demonstrates detailed inspection of exception information in __exit__.
    
    __exit__(self, exc_type, exc_value, traceback):
    - exc_type: Exception class (e.g., ValueError)
    - exc_value: Exception instance (the actual error object)
    - traceback: Traceback object (call stack information)
    """
    
    def __enter__(self):
        print("Entering context")
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        print("\n__exit__ called:")
        print(f"  exc_type:  {exc_type}")
        print(f"  exc_value: {exc_value}")
        print(f"  exc_tb:    {exc_tb}")
        
        if exc_type is not None:
            print(f"\nException details:")
            print(f"  Exception class name: {exc_type.__name__}")
            print(f"  Exception message: {str(exc_value)}")
            print(f"  Exception args: {exc_value.args}")
            
            # Traceback information
            if exc_tb is not None:
                print(f"\nTraceback information:")
                print(f"  File: {exc_tb.tb_frame.f_code.co_filename}")
                print(f"  Line: {exc_tb.tb_lineno}")
                print(f"  Function: {exc_tb.tb_frame.f_code.co_name}")
        
        return False  # Propagate exception

print("\nExample with exception:")
try:
    with ExceptionInspector():
        x = 10 / 0
except ZeroDivisionError:
    print("\nException propagated and caught outside")


# =============================================================================
# SECTION 2: Exception Suppression Patterns
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: Exception Suppression Patterns")
print("=" * 70)

class SelectiveExceptionSuppressor:
    """
    Suppresses only specific exception types.
    This is more controlled than suppressing all exceptions.
    """
    
    def __init__(self, *suppress_types):
        """
        Args:
            suppress_types: Exception types to suppress
        """
        self.suppress_types = suppress_types
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            return False
        
        # Check if exception type should be suppressed
        for suppress_type in self.suppress_types:
            if issubclass(exc_type, suppress_type):
                print(f"Suppressing {exc_type.__name__}: {exc_value}")
                return True  # Suppress exception
        
        # Not suppressing this type
        print(f"Not suppressing {exc_type.__name__}: {exc_value}")
        return False

print("\nExample 1: Suppressing ValueError")
with SelectiveExceptionSuppressor(ValueError):
    print("About to raise ValueError...")
    raise ValueError("This will be suppressed")
print("Execution continues\n")

print("Example 2: Not suppressing TypeError")
try:
    with SelectiveExceptionSuppressor(ValueError):
        print("About to raise TypeError...")
        raise TypeError("This will NOT be suppressed")
except TypeError as e:
    print(f"Caught: {e}")


# =============================================================================
# SECTION 3: Logging Exceptions
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: Logging Exceptions")
print("=" * 70)

class LoggingContext:
    """
    Logs all exceptions that occur, but propagates them.
    Useful for debugging and monitoring.
    """
    
    def __init__(self, name):
        self.name = name
        self.logger = logging.getLogger(name)
    
    def __enter__(self):
        self.logger.info(f"Entering context: {self.name}")
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            self.logger.info(f"Exiting context normally: {self.name}")
        else:
            self.logger.error(
                f"Exception in context '{self.name}': {exc_type.__name__}: {exc_value}"
            )
            # Log full traceback
            self.logger.debug("Full traceback:", exc_info=(exc_type, exc_value, exc_tb))
        
        return False  # Propagate exception

print("\nExample with logging:")
try:
    with LoggingContext("database_operation"):
        print("  Doing some work...")
        result = 10 / 0
except ZeroDivisionError:
    print("Exception handled")


# =============================================================================
# SECTION 4: Safe Cleanup
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: Safe Cleanup")
print("=" * 70)

class SafeCleanup:
    """
    Demonstrates safe cleanup that handles errors during cleanup itself.
    
    Important: Cleanup errors should not mask the original exception!
    """
    
    def __init__(self):
        self.resource1 = None
        self.resource2 = None
        self.resource3 = None
    
    def __enter__(self):
        print("Acquiring resources...")
        self.resource1 = "Resource 1"
        self.resource2 = "Resource 2"
        self.resource3 = "Resource 3"
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        print("\nCleaning up resources...")
        cleanup_errors = []
        
        # Clean up each resource, catching errors
        try:
            if self.resource1:
                print("  Releasing resource 1")
                # Simulate cleanup of resource1
                self.resource1 = None
        except Exception as e:
            cleanup_errors.append(f"Error cleaning resource1: {e}")
        
        try:
            if self.resource2:
                print("  Releasing resource 2")
                # Simulate cleanup error
                # raise RuntimeError("Cleanup failed for resource2!")
                self.resource2 = None
        except Exception as e:
            cleanup_errors.append(f"Error cleaning resource2: {e}")
        
        try:
            if self.resource3:
                print("  Releasing resource 3")
                self.resource3 = None
        except Exception as e:
            cleanup_errors.append(f"Error cleaning resource3: {e}")
        
        # Log cleanup errors
        if cleanup_errors:
            for error in cleanup_errors:
                logging.error(error)
        
        # Return False to propagate the original exception
        # (don't let cleanup errors mask it)
        return False

print("\nExample:")
try:
    with SafeCleanup():
        print("Using resources...")
        # raise ValueError("Operation failed!")
except ValueError as e:
    print(f"Caught: {e}")


# =============================================================================
# SECTION 5: Exception Transformation
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: Exception Transformation")
print("=" * 70)

class ExceptionTransformer:
    """
    Catches specific exceptions and transforms them into more meaningful ones.
    """
    
    def __init__(self, transform_map):
        """
        Args:
            transform_map: Dict mapping exception types to new exception types
        """
        self.transform_map = transform_map
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            return False
        
        # Check if we should transform this exception
        for from_exc, to_exc in self.transform_map.items():
            if issubclass(exc_type, from_exc):
                print(f"Transforming {exc_type.__name__} to {to_exc.__name__}")
                # Raise new exception with original as cause
                raise to_exc(f"Transformed from {exc_value}") from exc_value
        
        # Don't suppress if not transforming
        return False

print("\nExample:")
class DatabaseError(Exception):
    pass

try:
    with ExceptionTransformer({KeyError: DatabaseError}):
        data = {}
        value = data['missing_key']
except DatabaseError as e:
    print(f"Caught DatabaseError: {e}")
    print(f"Original cause: {e.__cause__}")


# =============================================================================
# SECTION 6: Retry Logic with Context Managers
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 6: Retry Logic")
print("=" * 70)

class Retry:
    """
    Context manager that retries the block if specific exceptions occur.
    """
    
    def __init__(self, max_attempts=3, retry_on=(Exception,)):
        self.max_attempts = max_attempts
        self.retry_on = retry_on
        self.attempt = 0
    
    def __enter__(self):
        self.attempt += 1
        print(f"Attempt {self.attempt} of {self.max_attempts}")
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            return False
        
        # Check if we should retry
        should_retry = any(issubclass(exc_type, exc) for exc in self.retry_on)
        
        if should_retry and self.attempt < self.max_attempts:
            print(f"  Failed with {exc_type.__name__}, retrying...")
            # This is a simplified example - actual retry would need recursion
            return True  # Suppress to attempt retry
        
        print(f"  Max attempts reached or non-retriable exception")
        return False  # Propagate exception

# Note: This example shows the concept, but actual retry logic is better
# implemented differently (not with context managers)
print("\nExample (simplified retry concept):")
try:
    with Retry(max_attempts=3, retry_on=(ValueError,)):
        print("  Attempting operation...")
        raise ValueError("Temporary failure")
except ValueError as e:
    print(f"Final exception: {e}")


# =============================================================================
# SECTION 7: Multiple Exception Types
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 7: Handling Multiple Exception Types")
print("=" * 70)

class MultiExceptionHandler:
    """
    Handles different exception types differently.
    """
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            return False
        
        if issubclass(exc_type, ValueError):
            print(f"Handling ValueError: {exc_value}")
            # Log it but let it propagate
            logging.warning(f"ValueError occurred: {exc_value}")
            return False
        
        elif issubclass(exc_type, KeyError):
            print(f"Suppressing KeyError: {exc_value}")
            return True  # Suppress
        
        elif issubclass(exc_type, TypeError):
            print(f"Transforming TypeError")
            raise RuntimeError(f"Invalid type: {exc_value}") from exc_value
        
        else:
            # Unknown exception type
            print(f"Unknown exception type: {exc_type.__name__}")
            return False

print("\nExample 1: ValueError (logged, propagated)")
try:
    with MultiExceptionHandler():
        raise ValueError("Bad value")
except ValueError:
    print("  Caught ValueError\n")

print("Example 2: KeyError (suppressed)")
with MultiExceptionHandler():
    raise KeyError("Missing key")
print("  Continued after KeyError\n")

print("Example 3: TypeError (transformed)")
try:
    with MultiExceptionHandler():
        raise TypeError("Wrong type")
except RuntimeError as e:
    print(f"  Caught RuntimeError: {e}")


# =============================================================================
# SECTION 8: Best Practices for Error Handling
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 8: Best Practices")
print("=" * 70)

class BestPracticeContext:
    """
    Demonstrates best practices for error handling in context managers.
    """
    
    def __init__(self, resource_name):
        self.resource_name = resource_name
        self.resource = None
    
    def __enter__(self):
        """
        Best practice: Let exceptions in __enter__ propagate naturally.
        Don't catch them unless you have a specific reason.
        """
        try:
            print(f"Acquiring {self.resource_name}")
            self.resource = f"Handle to {self.resource_name}"
            return self
        except Exception:
            # Only catch if you need to do something specific
            # Usually just let it propagate
            print(f"Failed to acquire {self.resource_name}")
            raise
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        """
        Best practices:
        1. Always attempt cleanup, even if exception occurred
        2. Handle cleanup errors separately
        3. Don't mask original exceptions
        4. Log important information
        5. Usually return False (propagate exceptions)
        """
        
        # 1. Always attempt cleanup
        try:
            if self.resource:
                print(f"Releasing {self.resource_name}")
                self.resource = None
        except Exception as cleanup_error:
            # 2. Handle cleanup errors
            logging.error(f"Cleanup error: {cleanup_error}")
            # Don't raise here - would mask original exception
        
        # 3. Log original exception if present
        if exc_type is not None:
            logging.error(
                f"Exception in {self.resource_name}: "
                f"{exc_type.__name__}: {exc_value}"
            )
        
        # 5. Propagate exceptions by default
        return False

print("\nExample:")
try:
    with BestPracticeContext("NetworkConnection"):
        print("  Using resource...")
        raise ValueError("Operation failed")
except ValueError:
    print("Exception handled")


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
Exception handling in __exit__:
- Receives (exc_type, exc_value, traceback) - all None if no exception
- Return True to suppress exception, False to propagate
- Always called, even when exceptions occur

Best practices:
1. Usually return False (propagate exceptions)
2. Only suppress exceptions you specifically intend to handle
3. Always clean up resources, even when exceptions occur
4. Handle cleanup errors separately (don't mask original exception)
5. Log exceptions for debugging
6. Be specific about which exceptions to suppress/handle

Common patterns:
- Selective suppression: Only suppress specific exception types
- Logging: Log all exceptions but propagate them
- Transformation: Convert low-level to high-level exceptions
- Safe cleanup: Handle cleanup errors without masking original
- Multiple handlers: Handle different exception types differently

What NOT to do:
- Don't suppress all exceptions blindly
- Don't let cleanup errors mask original exceptions
- Don't forget to log important exception information
- Don't catch exceptions in __enter__ unless necessary
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Create a context manager that logs exceptions to a file before propagating.

2. Implement a context manager that retries operations on specific exceptions.

3. Create a "graceful fallback" context manager that catches exceptions,
   logs them, and returns a default value.

4. Build a context manager that tracks the frequency of different exception
   types across multiple uses.

5. Implement a context manager that sends exception notifications
   (e.g., email or Slack) for critical errors.

6. Create a decorator that converts any function into a context manager
   with automatic exception logging.

See exercises_intermediate.py for more structured problems!
""")
