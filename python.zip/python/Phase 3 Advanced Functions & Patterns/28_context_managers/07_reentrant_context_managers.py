"""
07_reentrant_context_managers.py

INTERMEDIATE LEVEL - Reentrant Context Managers

This module explores reentrant context managers - context managers that can be
entered multiple times, either nested or in sequence.

Learning Objectives:
- Understand reentrancy in context managers
- Implement reentrant context managers using RLock
- Create context managers that track entry/exit levels
- Handle nested resource acquisition safely
- Understand when reentrancy is needed
"""

import threading
from contextlib import contextmanager

# =============================================================================
# SECTION 1: Understanding Reentrancy
# =============================================================================

print("=" * 70)
print("SECTION 1: Understanding Reentrancy")
print("=" * 70)

"""
A reentrant context manager can be entered multiple times from the same thread,
even while already inside its context.

Example use cases:
- Recursive functions that need the same lock
- Nested calls that share a resource
- Tracking depth/levels of operation
"""

class SimpleNonReentrant:
    """Non-reentrant context manager - can only be entered once at a time"""
    
    def __init__(self):
        self.is_entered = False
    
    def __enter__(self):
        if self.is_entered:
            raise RuntimeError("Already entered! Not reentrant.")
        self.is_entered = True
        print("Entered (non-reentrant)")
        return self
    
    def __exit__(self, *args):
        self.is_entered = False
        print("Exited")
        return False

print("\nExample 1: Non-reentrant (will fail on nested use)")
cm = SimpleNonReentrant()
with cm:
    print("  First level")
    try:
        with cm:  # Try to enter again
            print("  Second level")
    except RuntimeError as e:
        print(f"  Error: {e}")


# =============================================================================
# SECTION 2: Simple Reentrant Context Manager
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 2: Simple Reentrant Context Manager")
print("=" * 70)

class ReentrantContext:
    """Reentrant context manager that tracks entry depth"""
    
    def __init__(self):
        self.depth = 0
    
    def __enter__(self):
        self.depth += 1
        print(f"Entered (depth={self.depth})")
        return self
    
    def __exit__(self, *args):
        print(f"Exiting (depth={self.depth})")
        self.depth -= 1
        return False

print("\nExample: Reentrant usage")
cm = ReentrantContext()
with cm:
    print("  Outer level")
    with cm:
        print("    Middle level")
        with cm:
            print("      Inner level")
        print("    Back to middle")
    print("  Back to outer")


# =============================================================================
# SECTION 3: Reentrant Locks
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 3: Reentrant Locks")
print("=" * 70)

"""
Python's threading.RLock is a reentrant lock that can be acquired
multiple times by the same thread.
"""

# Regular Lock (non-reentrant)
print("\nRegular Lock (non-reentrant):")
regular_lock = threading.Lock()
print("First acquire:", regular_lock.acquire(blocking=False))
print("Second acquire (would block):", regular_lock.acquire(blocking=False))
regular_lock.release()

# Reentrant Lock
print("\nReentrant Lock (RLock):")
rlock = threading.RLock()
print("First acquire:", rlock.acquire(blocking=False))
print("Second acquire:", rlock.acquire(blocking=False))
print("Third acquire:", rlock.acquire(blocking=False))
rlock.release()
rlock.release()
rlock.release()
print("All releases done")


# =============================================================================
# SECTION 4: Practical Example - Database Transaction
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 4: Practical Example - Database Transaction")
print("=" * 70)

class DatabaseTransaction:
    """
    Reentrant database transaction context manager.
    Only the outermost transaction commits/rolls back.
    """
    
    def __init__(self, db_name):
        self.db_name = db_name
        self.depth = 0
    
    def __enter__(self):
        self.depth += 1
        if self.depth == 1:
            # Outermost transaction
            print(f"BEGIN TRANSACTION (depth={self.depth})")
        else:
            # Nested transaction (savepoint)
            print(f"CREATE SAVEPOINT sp_{self.depth} (depth={self.depth})")
        return self
    
    def __exit__(self, exc_type, exc_value, exc_tb):
        if exc_type is None:
            # No exception
            if self.depth == 1:
                print(f"COMMIT (depth={self.depth})")
            else:
                print(f"RELEASE SAVEPOINT sp_{self.depth} (depth={self.depth})")
        else:
            # Exception occurred
            if self.depth == 1:
                print(f"ROLLBACK (depth={self.depth})")
            else:
                print(f"ROLLBACK TO SAVEPOINT sp_{self.depth} (depth={self.depth})")
        
        self.depth -= 1
        return False
    
    def execute(self, sql):
        """Execute a SQL statement"""
        print(f"  EXECUTE (depth={self.depth}): {sql}")

print("\nExample 1: Successful nested transactions")
db = DatabaseTransaction("mydb")
with db:
    db.execute("INSERT INTO users VALUES (1, 'Alice')")
    
    with db:
        db.execute("INSERT INTO orders VALUES (1, 100)")
        
        with db:
            db.execute("UPDATE inventory SET qty = qty - 1")
    
    db.execute("INSERT INTO logs VALUES ('Order placed')")

print("\nExample 2: Nested transaction with failure")
db = DatabaseTransaction("mydb")
try:
    with db:
        db.execute("INSERT INTO users VALUES (2, 'Bob')")
        
        try:
            with db:
                db.execute("INSERT INTO orders VALUES (2, 200)")
                raise ValueError("Payment failed!")
                db.execute("UPDATE inventory")  # Won't execute
        except ValueError:
            print("  Inner transaction rolled back")
        
        db.execute("INSERT INTO logs VALUES ('Order failed')")
except Exception:
    pass


# =============================================================================
# SECTION 5: Reference Counting Context Manager
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 5: Reference Counting Context Manager")
print("=" * 70)

class ResourceManager:
    """
    Uses reference counting to manage a resource.
    Resource is only acquired once and released when ref count reaches zero.
    """
    
    def __init__(self, resource_name):
        self.resource_name = resource_name
        self.ref_count = 0
        self.resource = None
    
    def __enter__(self):
        self.ref_count += 1
        print(f"Entering (ref_count={self.ref_count})")
        
        if self.ref_count == 1:
            # First entry - actually acquire resource
            self.resource = f"Handle to {self.resource_name}"
            print(f"  → Actually acquiring resource: {self.resource_name}")
        else:
            print(f"  → Resource already acquired, incrementing ref count")
        
        return self
    
    def __exit__(self, *args):
        print(f"Exiting (ref_count={self.ref_count})")
        self.ref_count -= 1
        
        if self.ref_count == 0:
            # Last exit - actually release resource
            print(f"  → Actually releasing resource: {self.resource_name}")
            self.resource = None
        else:
            print(f"  → Keeping resource, decrementing ref count")
        
        return False
    
    def use_resource(self):
        """Use the managed resource"""
        if self.resource:
            print(f"  Using resource: {self.resource}")
        else:
            print(f"  Resource not available!")

print("\nExample: Reference counting")
rm = ResourceManager("Database Connection")

with rm:
    rm.use_resource()
    
    with rm:
        rm.use_resource()
        
        with rm:
            rm.use_resource()


# =============================================================================
# SECTION 6: Thread-Safe Reentrant Context Manager
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 6: Thread-Safe Reentrant Context Manager")
print("=" * 70)

class ThreadSafeReentrant:
    """
    Thread-safe reentrant context manager using RLock.
    Allows multiple entries from the same thread, but blocks other threads.
    """
    
    def __init__(self, name):
        self.name = name
        self.rlock = threading.RLock()
        self.depth = 0
    
    def __enter__(self):
        self.rlock.acquire()
        self.depth += 1
        thread_id = threading.current_thread().name
        print(f"[{thread_id}] Acquired {self.name} (depth={self.depth})")
        return self
    
    def __exit__(self, *args):
        thread_id = threading.current_thread().name
        print(f"[{thread_id}] Releasing {self.name} (depth={self.depth})")
        self.depth -= 1
        self.rlock.release()
        return False

print("\nExample: Thread-safe reentrant usage")
ts = ThreadSafeReentrant("SharedResource")

with ts:
    print("  Outer context")
    with ts:
        print("    Inner context (reentrant in same thread)")


# =============================================================================
# SECTION 7: Decorator for Making Context Managers Reentrant
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 7: Making Context Managers Reentrant")
print("=" * 70)

class ReentrantWrapper:
    """
    Wraps a non-reentrant context manager to make it reentrant.
    """
    
    def __init__(self, context_manager):
        self.context_manager = context_manager
        self.depth = 0
        self.stored_value = None
    
    def __enter__(self):
        self.depth += 1
        if self.depth == 1:
            # First entry - actually enter the wrapped context
            self.stored_value = self.context_manager.__enter__()
        return self.stored_value
    
    def __exit__(self, *args):
        self.depth -= 1
        if self.depth == 0:
            # Last exit - actually exit the wrapped context
            return self.context_manager.__exit__(*args)
        return False

# Example usage
print("\nExample: Making a non-reentrant context reentrant")

class MyResource:
    def __enter__(self):
        print("  Resource entered")
        return "Resource handle"
    
    def __exit__(self, *args):
        print("  Resource exited")
        return False

resource = MyResource()
reentrant_resource = ReentrantWrapper(resource)

with reentrant_resource as r1:
    print(f"Outer: {r1}")
    with reentrant_resource as r2:
        print(f"  Inner: {r2}")


# =============================================================================
# SECTION 8: When to Use Reentrant Context Managers
# =============================================================================

print("\n" + "=" * 70)
print("SECTION 8: When to Use Reentrant Context Managers")
print("=" * 70)

"""
Use reentrant context managers when:

1. Recursive functions need the same resource:
   - Recursive algorithms that need a lock
   - Tree/graph traversal with shared state

2. Nested function calls share a resource:
   - Helper functions that may or may not be called in a context
   - Library code that doesn't know if it's nested

3. Transaction management:
   - Nested transactions with savepoints
   - Hierarchical operations with rollback

4. Reference counting:
   - Expensive resources that should only be acquired once
   - Shared resources with multiple users

Avoid when:
- Resource semantics don't support reentrancy
- Confusion about cleanup timing
- Simple cases where reentrancy adds unnecessary complexity
"""

def recursive_with_lock(n, lock):
    """Example: Recursive function using reentrant lock"""
    with lock:
        print(f"  Processing level {n}")
        if n > 0:
            recursive_with_lock(n - 1, lock)

print("\nExample: Recursive function with reentrant lock")
lock = ThreadSafeReentrant("RecursiveLock")
recursive_with_lock(3, lock)


# =============================================================================
# KEY TAKEAWAYS
# =============================================================================

print("\n" + "=" * 70)
print("KEY TAKEAWAYS")
print("=" * 70)

print("""
Reentrancy:
- Ability to enter a context multiple times
- Useful for recursive functions and nested calls
- Requires tracking entry depth or reference count

Implementation patterns:
- Depth counter: Track how many times entered
- Reference counting: Acquire once, release when count reaches zero
- RLock: Thread-safe reentrant locking
- Wrapper: Convert non-reentrant to reentrant

Best practices:
- Only outermost entry/exit should acquire/release resources
- Track entry depth for proper cleanup
- Use RLock for thread-safe reentrancy
- Document reentrant behavior clearly
- Test nested and recursive scenarios

Common use cases:
- Database transactions with savepoints
- Recursive algorithms with shared resources
- Library code that may be nested
- Reference-counted resources
- Thread-safe recursive operations

When NOT to use:
- Resource doesn't support reentrancy semantically
- Adds unnecessary complexity
- Cleanup timing becomes confusing
""")

# =============================================================================
# EXERCISES
# =============================================================================

print("=" * 70)
print("EXERCISES")
print("=" * 70)

print("""
1. Create a reentrant context manager for indented logging
   (each nested level adds more indentation).

2. Implement a reentrant "profiler" that tracks time spent at each depth level.

3. Create a reentrant context manager for matplotlib figure management
   that allows nested subplots.

4. Build a reentrant context manager for temporary sys.path modifications.

5. Implement a thread-safe reentrant counter that tracks concurrent users.

6. Create a reentrant "mock" context manager that patches objects
   at different nesting levels.

See exercises_intermediate.py for more structured problems!
""")
