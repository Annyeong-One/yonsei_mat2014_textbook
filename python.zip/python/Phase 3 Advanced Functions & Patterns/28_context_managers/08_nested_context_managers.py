"""
08_nested_context_managers.py

INTERMEDIATE LEVEL - Nested Context Managers

Working with multiple context managers simultaneously.

Learning Objectives:
- Use multiple context managers in one statement
- Understand execution order and cleanup
- Handle errors in nested contexts
- Use ExitStack for dynamic nesting
"""

import time
from contextlib import contextmanager, ExitStack

print("=" * 70)
print("NESTED CONTEXT MANAGERS")
print("=" * 70)

@contextmanager
def timer(name):
    start = time.time()
    print(f"[{name}] Start")
    yield
    print(f"[{name}] End: {time.time()-start:.3f}s")

@contextmanager
def logger(name):
    print(f">> {name} starting")
    yield
    print(f"<< {name} ending")

# Example 1: Multiple with statements
print("\nExample 1: Comma-separated")
with timer("Operation"), logger("Process"):
    print("  Working...")
    time.sleep(0.1)

# Example 2: ExitStack for dynamic nesting
print("\nExample 2: ExitStack")
with ExitStack() as stack:
    stack.enter_context(timer("Task1"))
    stack.enter_context(logger("Task1"))
    print("  Processing...")

print("""
\nKEY POINTS:
- Multiple contexts: comma-separated or nested
- ExitStack: Dynamic number of contexts
- Cleanup order: reverse of entry order
- Exception in one affects all

EXERCISES:
1. Create nested file processors
2. Build transaction system with multiple resources
3. Implement cascading error handlers
4. Use ExitStack for config file hierarchy
""")
