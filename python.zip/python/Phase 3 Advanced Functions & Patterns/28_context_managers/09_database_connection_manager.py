"""
09_database_connection_manager.py

ADVANCED LEVEL - Database Connection Manager

Practical implementation of connection pooling and transaction management.

Learning Objectives:
- Implement connection pooling
- Manage transactions properly
- Handle connection errors
- Create reusable database contexts
"""

from contextlib import contextmanager
import time
import threading

print("=" * 70)
print("DATABASE CONNECTION MANAGER")
print("=" * 70)

class ConnectionPool:
    """Simple connection pool implementation"""
    
    def __init__(self, max_connections=5):
        self.max_connections = max_connections
        self.available = []
        self.in_use = set()
        self.lock = threading.Lock()
    
    def acquire(self):
        with self.lock:
            if self.available:
                conn = self.available.pop()
                print(f"Reusing connection {conn}")
            elif len(self.in_use) < self.max_connections:
                conn = f"Connection-{len(self.in_use)}"
                print(f"Creating new connection {conn}")
            else:
                raise RuntimeError("No connections available")
            
            self.in_use.add(conn)
            return conn
    
    def release(self, conn):
        with self.lock:
            if conn in self.in_use:
                self.in_use.remove(conn)
                self.available.append(conn)
                print(f"Released connection {conn}")
    
    @contextmanager
    def connection(self):
        """Context manager for database connection"""
        conn = self.acquire()
        try:
            yield conn
        finally:
            self.release(conn)
    
    @contextmanager
    def transaction(self):
        """Context manager for database transaction"""
        conn = self.acquire()
        try:
            print(f"BEGIN TRANSACTION on {conn}")
            yield conn
            print(f"COMMIT on {conn}")
        except Exception as e:
            print(f"ROLLBACK on {conn} (error: {e})")
            raise
        finally:
            self.release(conn)

# Example usage
print("\nExample: Connection pooling")
pool = ConnectionPool(max_connections=3)

with pool.connection() as conn:
    print(f"  Using {conn} for query")

with pool.transaction() as conn:
    print(f"  Executing transaction on {conn}")

print("""
\nKEY FEATURES:
- Connection pooling for efficiency
- Automatic transaction management
- Thread-safe connection handling
- Proper error handling and rollback

EXERCISES:
1. Add connection timeout
2. Implement retry logic
3. Add query logging
4. Create read/write connection pools
5. Implement connection health checks
""")
