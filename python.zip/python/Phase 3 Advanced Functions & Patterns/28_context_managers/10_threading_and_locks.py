"""
10_threading_and_locks.py

ADVANCED LEVEL - Threading and Locks with Context Managers

Using context managers for thread synchronization.

Learning Objectives:
- Use locks as context managers
- Implement thread-safe operations
- Handle deadlock prevention
- Create custom synchronization primitives
"""

import threading
import time
from contextlib import contextmanager

print("=" * 70)
print("THREADING AND LOCKS")
print("=" * 70)

# Example 1: Basic lock usage
print("\nExample 1: Thread-safe counter")
counter = 0
lock = threading.Lock()

def increment():
    global counter
    for _ in range(100000):
        with lock:  # Automatic acquire/release
            counter += 1

threads = [threading.Thread(target=increment) for _ in range(5)]
for t in threads:
    t.start()
for t in threads:
    t.join()

print(f"Final counter: {counter}")

# Example 2: Custom lock manager
class LockManager:
    """Manages multiple named locks"""
    
    def __init__(self):
        self.locks = {}
        self._lock = threading.Lock()
    
    @contextmanager
    def lock(self, name):
        with self._lock:
            if name not in self.locks:
                self.locks[name] = threading.Lock()
            lock = self.locks[name]
        
        lock.acquire()
        try:
            yield
        finally:
            lock.release()

print("\nExample 2: Named locks")
manager = LockManager()

with manager.lock("resource_a"):
    print("  Holding lock on resource_a")

print("""
\nKEY CONCEPTS:
- Lock: Basic mutual exclusion
- RLock: Reentrant lock (same thread can acquire multiple times)
- Semaphore: Limited number of concurrent accesses
- Condition: Wait/notify mechanisms
- Context managers ensure proper lock release

BEST PRACTICES:
- Always use locks with context managers
- Keep critical sections small
- Avoid nested locks (deadlock risk)
- Use timeout when possible
- Document lock ordering

EXERCISES:
1. Implement reader-writer lock
2. Create deadlock detection
3. Build priority-based lock manager
4. Implement distributed lock system
5. Create thread-safe queue with locks
""")
