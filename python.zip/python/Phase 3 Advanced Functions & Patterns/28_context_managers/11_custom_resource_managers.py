"""
11_custom_resource_managers.py

ADVANCED LEVEL - Custom Resource Managers

Creating generic, reusable resource management patterns.

Learning Objectives:
- Design generic resource managers
- Implement resource lifecycle management
- Create composable resource patterns
- Build resource pools and caches
"""

from contextlib import contextmanager
import time

print("=" * 70)
print("CUSTOM RESOURCE MANAGERS")
print("=" * 70)

class ResourceManager:
    """
    Generic resource manager pattern.
    Handles acquisition, usage, and release of any resource.
    """
    
    def __init__(self, resource_type, acquire_fn, release_fn):
        """
        Args:
            resource_type: Description of resource type
            acquire_fn: Function to acquire resource
            release_fn: Function to release resource
        """
        self.resource_type = resource_type
        self.acquire_fn = acquire_fn
        self.release_fn = release_fn
    
    def __enter__(self):
        print(f"Acquiring {self.resource_type}...")
        self.resource = self.acquire_fn()
        print(f"Acquired: {self.resource}")
        return self.resource
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        print(f"Releasing {self.resource_type}...")
        self.release_fn(self.resource)
        print(f"Released: {self.resource}")
        return False

# Example: File handle manager
print("\nExample 1: File handle manager")
def acquire_file():
    return open('/tmp/test.txt', 'w')

def release_file(f):
    f.close()

with ResourceManager("file handle", acquire_file, release_file) as f:
    f.write("Hello, World!\n")

# Example 2: Generic timer
print("\nExample 2: Timing context manager")
@contextmanager
def measure_time(operation_name):
    """Measures execution time of a code block"""
    start = time.time()
    print(f"Starting: {operation_name}")
    try:
        yield
    finally:
        elapsed = time.time() - start
        print(f"Finished: {operation_name} ({elapsed:.4f}s)")

with measure_time("Data processing"):
    time.sleep(0.2)
    print("  Processing...")

# Example 3: Resource with setup and teardown
class ManagedResource:
    """
    Complete resource lifecycle management with
    initialization, validation, and cleanup.
    """
    
    def __init__(self, name):
        self.name = name
        self.state = "uninitialized"
    
    def setup(self):
        """Setup phase"""
        print(f"Setting up {self.name}")
        self.state = "active"
    
    def teardown(self):
        """Teardown phase"""
        print(f"Tearing down {self.name}")
        self.state = "inactive"
    
    def __enter__(self):
        self.setup()
        return self
    
    def __exit__(self, *args):
        self.teardown()
        return False
    
    def use(self):
        """Use the resource"""
        if self.state == "active":
            print(f"  Using {self.name}")
        else:
            raise RuntimeError(f"Resource {self.name} not active")

print("\nExample 3: Managed resource lifecycle")
with ManagedResource("API Client") as client:
    client.use()

print("""
\nDESIGN PATTERNS:
- Generic ResourceManager: Parameterize acquire/release
- Template Method: Define lifecycle steps
- Factory: Create resource managers dynamically
- Decorator: Add behavior to existing managers
- Strategy: Different resource strategies

BEST PRACTICES:
- Separate concern: acquisition vs usage
- Make resources composable
- Handle partial acquisition failures
- Document resource requirements
- Provide clear error messages

EXERCISES:
1. Create NetworkManager for sockets
2. Build MemoryManager with allocation tracking
3. Implement APIClient with rate limiting
4. Create CacheManager with TTL
5. Build TemporaryEnvironment manager
6. Implement ResourcePool with health checks
""")
