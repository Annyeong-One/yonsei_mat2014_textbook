"""
12_async_context_managers.py

ADVANCED LEVEL - Asynchronous Context Managers

Using async/await with context managers for async operations.

Learning Objectives:
- Understand async context manager protocol
- Implement __aenter__ and __aexit__
- Use async with statement
- Create async resource managers
"""

import asyncio
import time
from contextlib import asynccontextmanager

print("=" * 70)
print("ASYNC CONTEXT MANAGERS")
print("=" * 70)

# Example 1: Class-based async context manager
class AsyncTimer:
    """Async context manager for timing operations"""
    
    def __init__(self, name):
        self.name = name
        self.start = None
    
    async def __aenter__(self):
        """Async enter method"""
        self.start = time.time()
        print(f"[{self.name}] Starting...")
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async exit method"""
        elapsed = time.time() - self.start
        print(f"[{self.name}] Completed in {elapsed:.4f}s")
        return False

# Example 2: Decorator-based async context manager
@asynccontextmanager
async def async_file(filename, mode='r'):
    """Async file context manager"""
    print(f"Opening {filename}")
    f = open(filename, mode)
    try:
        yield f
    finally:
        print(f"Closing {filename}")
        f.close()

# Example 3: Async connection pool
class AsyncConnectionPool:
    """Async database connection pool"""
    
    def __init__(self, max_connections=5):
        self.max_connections = max_connections
        self.available = []
        self.semaphore = asyncio.Semaphore(max_connections)
    
    async def __aenter__(self):
        await self.semaphore.acquire()
        if self.available:
            conn = self.available.pop()
        else:
            # Simulate async connection creation
            await asyncio.sleep(0.1)
            conn = f"AsyncConn-{id(self)}"
        print(f"Acquired connection: {conn}")
        self.current_conn = conn
        return conn
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        print(f"Releasing connection: {self.current_conn}")
        self.available.append(self.current_conn)
        self.semaphore.release()
        return False

# Test async context managers
async def test_async_contexts():
    """Test all async context manager examples"""
    
    print("\nTest 1: Async timer")
    async with AsyncTimer("Database query"):
        await asyncio.sleep(0.5)
        print("  Executing query...")
    
    print("\nTest 2: Async file")
    async with async_file('/tmp/async_test.txt', 'w') as f:
        f.write("Async content\n")
    
    print("\nTest 3: Async connection pool")
    pool = AsyncConnectionPool(max_connections=2)
    
    async def use_connection(task_id):
        async with pool as conn:
            print(f"  Task {task_id} using {conn}")
            await asyncio.sleep(0.2)
    
    # Run multiple tasks concurrently
    tasks = [use_connection(i) for i in range(3)]
    await asyncio.gather(*tasks)

# Run the async tests
print("\nRunning async examples:")
asyncio.run(test_async_contexts())

print("""
\nKEY CONCEPTS:
- __aenter__: Async setup (use 'await' if needed)
- __aexit__: Async cleanup (use 'await' if needed)
- async with: Enter async context
- @asynccontextmanager: Decorator for async generators

WHEN TO USE:
- Async I/O operations (files, network, database)
- Resource acquisition that might block
- Operations requiring async cleanup
- Working with asyncio libraries

BEST PRACTICES:
- Use async context managers for async resources
- Don't block the event loop in __aenter__/__aexit__
- Handle exceptions properly in async code
- Clean up async resources in __aexit__
- Use asyncio.gather for concurrent operations

EXERCISES:
1. Create async web scraper with connection manager
2. Build async file processor with batching
3. Implement async rate limiter
4. Create async transaction manager
5. Build async cache with expiration
6. Implement async retry mechanism
""")
