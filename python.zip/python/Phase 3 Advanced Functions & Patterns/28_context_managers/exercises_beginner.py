"""
exercises_beginner.py

BEGINNER LEVEL EXERCISES

Complete these exercises to practice basic context manager concepts.
Solutions are provided in solutions_beginner.py.

Instructions:
- Implement each function/class according to specifications
- Test your solutions by running this file
- Compare with solutions only after attempting yourself
"""

# =============================================================================
# EXERCISE 1: Simple Greeting Context Manager
# =============================================================================

"""
Create a context manager class called GreetingContext that:
- Takes a name parameter in __init__
- Prints "Hello, {name}!" when entering
- Prints "Goodbye, {name}!" when exiting
- Returns the name in __enter__
"""

# YOUR CODE HERE
class GreetingContext:
    pass


# Test Exercise 1
def test_exercise_1():
    print("Testing Exercise 1:")
    with GreetingContext("Alice") as name:
        print(f"  Inside context with {name}")
    print()


# =============================================================================
# EXERCISE 2: File Line Counter
# =============================================================================

"""
Create a function called count_lines(filename) that:
- Opens a file using a context manager
- Counts the number of lines
- Returns the count
- Properly closes the file even if an error occurs
"""

# YOUR CODE HERE
def count_lines(filename):
    pass


# Test Exercise 2
def test_exercise_2():
    print("Testing Exercise 2:")
    # Create a test file
    with open('/tmp/test_lines.txt', 'w') as f:
        f.write("Line 1\n")
        f.write("Line 2\n")
        f.write("Line 3\n")
    
    count = count_lines('/tmp/test_lines.txt')
    print(f"  Line count: {count}")
    print()


# =============================================================================
# EXERCISE 3: Timer Context Manager
# =============================================================================

"""
Create a Timer context manager class that:
- Records start time when entering
- Records end time when exiting
- Prints elapsed time in seconds
- Stores elapsed time in self.elapsed attribute
"""

# YOUR CODE HERE
class Timer:
    pass


# Test Exercise 3
def test_exercise_3():
    print("Testing Exercise 3:")
    import time
    with Timer() as t:
        time.sleep(0.5)
        print("  Working...")
    print(f"  Elapsed: {t.elapsed:.2f}s")
    print()


# =============================================================================
# EXERCISE 4: Suppressing Exceptions
# =============================================================================

"""
Create a context manager class called SuppressException that:
- Takes exception type(s) to suppress as parameters
- Suppresses only those exception types
- Propagates other exceptions
"""

# YOUR CODE HERE
class SuppressException:
    pass


# Test Exercise 4
def test_exercise_4():
    print("Testing Exercise 4:")
    
    # Should suppress ValueError
    with SuppressException(ValueError):
        print("  Raising ValueError...")
        raise ValueError("This should be suppressed")
    print("  Continued after ValueError")
    
    # Should NOT suppress TypeError
    try:
        with SuppressException(ValueError):
            print("  Raising TypeError...")
            raise TypeError("This should propagate")
    except TypeError:
        print("  TypeError was propagated")
    print()


# =============================================================================
# EXERCISE 5: Directory Content Saver
# =============================================================================

"""
Create a context manager that:
- Accepts a directory path in __init__
- Lists all files in the directory when entering
- Compares and reports any changes when exiting
- Returns the list of files from __enter__
"""

# YOUR CODE HERE
class DirectoryWatcher:
    pass


# Test Exercise 5
def test_exercise_5():
    print("Testing Exercise 5:")
    import os
    test_dir = '/tmp/test_dir'
    os.makedirs(test_dir, exist_ok=True)
    
    with DirectoryWatcher(test_dir) as files:
        print(f"  Initial files: {files}")
        # Create a new file
        with open(f'{test_dir}/new_file.txt', 'w') as f:
            f.write("test")
    print()


# =============================================================================
# EXERCISE 6: Multiple File Processor
# =============================================================================

"""
Create a function process_files(input_file, output_file) that:
- Opens both files using a single with statement
- Reads from input_file
- Writes uppercase version to output_file
- Properly closes both files
"""

# YOUR CODE HERE
def process_files(input_file, output_file):
    pass


# Test Exercise 6
def test_exercise_6():
    print("Testing Exercise 6:")
    # Create input file
    with open('/tmp/input.txt', 'w') as f:
        f.write("hello world\n")
    
    process_files('/tmp/input.txt', '/tmp/output.txt')
    
    # Read output
    with open('/tmp/output.txt', 'r') as f:
        content = f.read()
        print(f"  Output: {content.strip()}")
    print()


# =============================================================================
# RUN ALL TESTS
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("BEGINNER EXERCISES")
    print("=" * 70)
    print()
    
    try:
        test_exercise_1()
    except Exception as e:
        print(f"Exercise 1 error: {e}\n")
    
    try:
        test_exercise_2()
    except Exception as e:
        print(f"Exercise 2 error: {e}\n")
    
    try:
        test_exercise_3()
    except Exception as e:
        print(f"Exercise 3 error: {e}\n")
    
    try:
        test_exercise_4()
    except Exception as e:
        print(f"Exercise 4 error: {e}\n")
    
    try:
        test_exercise_5()
    except Exception as e:
        print(f"Exercise 5 error: {e}\n")
    
    try:
        test_exercise_6()
    except Exception as e:
        print(f"Exercise 6 error: {e}\n")
    
    print("=" * 70)
    print("Complete exercises_beginner.py!")
    print("Then check solutions_beginner.py")
    print("=" * 70)
