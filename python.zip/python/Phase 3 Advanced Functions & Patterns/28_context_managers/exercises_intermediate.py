"""
exercises_intermediate.py

INTERMEDIATE LEVEL EXERCISES

Practice @contextmanager decorator, error handling, and advanced patterns.
"""

from contextlib import contextmanager

# EXERCISE 1: Create a @contextmanager that temporarily changes sys.path
# EXERCISE 2: Build a transaction manager with commit/rollback
# EXERCISE 3: Implement a reentrant indented logger
# EXERCISE 4: Create ExitStack-based configuration loader
# EXERCISE 5: Build selective exception transformer
# EXERCISE 6: Implement retry mechanism with exponential backoff

print("""
INTERMEDIATE EXERCISES
======================

1. Create temp_syspath(path) context manager using @contextmanager
   - Add path to sys.path on enter
   - Remove it on exit
   - Handle errors properly

2. Build TransactionManager class
   - Track operations in a list
   - Commit on normal exit
   - Rollback on exception
   - Support nested transactions

3. Implement IndentedLogger
   - Each nested level adds indentation
   - Thread-safe if possible
   - Support custom indent string

4. Create config_hierarchy(filenames) using ExitStack
   - Load multiple config files
   - Merge configurations
   - Clean up properly

5. Build ExceptionTransformer(@contextmanager)
   - Transform specific exceptions
   - Preserve original exception info
   - Log transformations

6. Implement retry_context(max_attempts, exceptions)
   - Retry on specific exceptions
   - Exponential backoff
   - Log retry attempts

See solutions_intermediate.py after attempting!
""")
