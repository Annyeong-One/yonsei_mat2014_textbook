"""
solutions_advanced.py

SOLUTIONS TO ADVANCED EXERCISES
"""

import asyncio
import time
import threading
from contextlib import contextmanager, asynccontextmanager
from collections import deque
from datetime import datetime, timedelta

# SOLUTION 1: ConnectionPool with health checks
class ConnectionPool:
    """Production-grade connection pool"""
    
    def __init__(self, max_connections=10, health_check_interval=30):
        self.max_connections = max_connections
        self.available = deque()
        self.in_use = set()
        self.lock = threading.Lock()
        self.health_check_interval = health_check_interval
    
    def acquire(self, timeout=5):
        """Acquire a connection with timeout"""
        start = time.time()
        while True:
            with self.lock:
                # Try to get healthy connection
                while self.available:
                    conn = self.available.pop()
                    if self._is_healthy(conn):
                        self.in_use.add(conn)
                        return conn
                
                # Create new if under limit
                if len(self.in_use) < self.max_connections:
                    conn = self._create_connection()
                    self.in_use.add(conn)
                    return conn
            
            # Check timeout
            if time.time() - start > timeout:
                raise TimeoutError("No connections available")
            
            time.sleep(0.1)
    
    def release(self, conn):
        """Release connection back to pool"""
        with self.lock:
            self.in_use.discard(conn)
            if self._is_healthy(conn):
                self.available.append(conn)
            else:
                # Close unhealthy connection
                self._close_connection(conn)
    
    @contextmanager
    def connection(self, timeout=5):
        """Context manager for connection"""
        conn = self.acquire(timeout)
        try:
            yield conn
        finally:
            self.release(conn)
    
    def _create_connection(self):
        """Create new connection"""
        return {
            'id': id(self),
            'created': time.time(),
            'healthy': True
        }
    
    def _is_healthy(self, conn):
        """Check connection health"""
        age = time.time() - conn['created']
        return conn['healthy'] and age < self.health_check_interval
    
    def _close_connection(self, conn):
        """Close connection"""
        conn['healthy'] = False

# SOLUTION 2: Rate Limiter
class RateLimiter:
    """Token bucket rate limiter"""
    
    def __init__(self, rate, capacity=None):
        self.rate = rate  # tokens per second
        self.capacity = capacity or rate
        self.tokens = self.capacity
        self.last_update = time.time()
        self.lock = threading.Lock()
    
    def __enter__(self):
        """Acquire token, block if necessary"""
        while True:
            with self.lock:
                self._refill()
                if self.tokens >= 1:
                    self.tokens -= 1
                    return self
            
            # Wait before retry
            time.sleep(0.01)
    
    def __exit__(self, *args):
        return False
    
    def _refill(self):
        """Refill tokens based on elapsed time"""
        now = time.time()
        elapsed = now - self.last_update
        self.tokens = min(
            self.capacity,
            self.tokens + elapsed * self.rate
        )
        self.last_update = now

# SOLUTION 3: AsyncBatchProcessor
class AsyncBatchProcessor:
    """Process items in batches asynchronously"""
    
    def __init__(self, batch_size=10, process_fn=None):
        self.batch_size = batch_size
        self.process_fn = process_fn or self._default_process
        self.batch = []
    
    async def __aenter__(self):
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Process remaining batch on exit"""
        if self.batch:
            await self._process_batch()
        return False
    
    async def add(self, item):
        """Add item, process batch if full"""
        self.batch.append(item)
        if len(self.batch) >= self.batch_size:
            await self._process_batch()
    
    async def _process_batch(self):
        """Process current batch"""
        if not self.batch:
            return
        
        print(f"Processing batch of {len(self.batch)} items")
        try:
            await self.process_fn(self.batch.copy())
        finally:
            self.batch.clear()
    
    async def _default_process(self, batch):
        """Default processing function"""
        await asyncio.sleep(0.1)
        print(f"  Processed: {batch}")

# SOLUTION 4: MonitoringContext
class MonitoringContext:
    """Monitor execution metrics"""
    
    def __init__(self, name):
        self.name = name
        self.start_time = None
        self.metrics = {}
    
    def __enter__(self):
        self.start_time = time.time()
        print(f"[{self.name}] Monitoring started")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed = time.time() - self.start_time
        
        self.metrics = {
            'name': self.name,
            'duration': elapsed,
            'success': exc_type is None,
            'exception': exc_type.__name__ if exc_type else None,
            'timestamp': datetime.now().isoformat()
        }
        
        print(f"[{self.name}] Metrics: {self.metrics}")
        return False
    
    def record(self, key, value):
        """Record custom metric"""
        self.metrics[key] = value

# SOLUTION 5: Resource Pool with TTL
class ResourcePool:
    """Pool with resource expiration"""
    
    def __init__(self, create_fn, max_size=10, ttl=60):
        self.create_fn = create_fn
        self.max_size = max_size
        self.ttl = timedelta(seconds=ttl)
        self.pool = deque()
        self.lock = threading.Lock()
    
    @contextmanager
    def resource(self):
        """Acquire resource with TTL check"""
        resource = self._acquire()
        try:
            yield resource['value']
        finally:
            self._release(resource)
    
    def _acquire(self):
        """Get resource from pool or create new"""
        with self.lock:
            # Try to reuse from pool
            while self.pool:
                resource = self.pool.pop()
                if self._is_valid(resource):
                    return resource
            
            # Create new
            return {
                'value': self.create_fn(),
                'created': datetime.now()
            }
    
    def _release(self, resource):
        """Return resource to pool"""
        with self.lock:
            if (self._is_valid(resource) and 
                len(self.pool) < self.max_size):
                self.pool.append(resource)
    
    def _is_valid(self, resource):
        """Check if resource is still valid"""
        age = datetime.now() - resource['created']
        return age < self.ttl

print("All advanced solutions implemented!")

# Example usage
if __name__ == "__main__":
    print("\nTesting solutions...")
    
    # Test ConnectionPool
    print("\n1. Connection Pool:")
    pool = ConnectionPool(max_connections=2)
    with pool.connection() as conn:
        print(f"  Using connection: {conn['id']}")
    
    # Test RateLimiter
    print("\n2. Rate Limiter:")
    limiter = RateLimiter(rate=2)
    for i in range(3):
        with limiter:
            print(f"  Request {i+1}")
    
    # Test MonitoringContext
    print("\n3. Monitoring:")
    with MonitoringContext("test_operation") as monitor:
        time.sleep(0.1)
        monitor.record("custom_metric", 42)
    
    print("\nAll tests completed!")
