"""
solutions_beginner.py

SOLUTIONS TO BEGINNER LEVEL EXERCISES

These are detailed solutions with explanations.
Try solving exercises yourself before looking at these!
"""

import time
import os

# =============================================================================
# SOLUTION 1: Simple Greeting Context Manager
# =============================================================================

class GreetingContext:
    """
    Simple context manager that greets on entry and exit.
    
    This demonstrates the basic structure of a context manager:
    - __init__ for initialization
    - __enter__ for setup and returning a value
    - __exit__ for cleanup
    """
    
    def __init__(self, name):
        """Store the name to use in greetings"""
        self.name = name
    
    def __enter__(self):
        """Print greeting and return the name"""
        print(f"Hello, {self.name}!")
        return self.name  # This becomes the 'as' variable
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Print goodbye"""
        print(f"Goodbye, {self.name}!")
        return False  # Don't suppress exceptions


# =============================================================================
# SOLUTION 2: File Line Counter
# =============================================================================

def count_lines(filename):
    """
    Count lines in a file using a context manager.
    
    The 'with' statement ensures the file is properly closed
    even if an exception occurs during reading.
    """
    with open(filename, 'r') as f:
        # Using sum() with generator expression for efficiency
        count = sum(1 for line in f)
    return count

# Alternative solution using readlines()
def count_lines_alt(filename):
    """Alternative implementation using readlines()"""
    with open(filename, 'r') as f:
        lines = f.readlines()
        return len(lines)


# =============================================================================
# SOLUTION 3: Timer Context Manager
# =============================================================================

class Timer:
    """
    Context manager that measures execution time.
    
    Key points:
    - Store start time in __enter__
    - Calculate elapsed time in __exit__
    - Make elapsed time accessible as an attribute
    """
    
    def __init__(self):
        self.start_time = None
        self.end_time = None
        self.elapsed = None
    
    def __enter__(self):
        """Record start time"""
        self.start_time = time.time()
        return self  # Return self to allow access to elapsed
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Calculate and print elapsed time"""
        self.end_time = time.time()
        self.elapsed = self.end_time - self.start_time
        print(f"Elapsed time: {self.elapsed:.4f} seconds")
        return False


# =============================================================================
# SOLUTION 4: Suppressing Exceptions
# =============================================================================

class SuppressException:
    """
    Context manager that selectively suppresses exceptions.
    
    Important:
    - Store exception types to suppress
    - Check if raised exception matches types
    - Return True to suppress, False to propagate
    """
    
    def __init__(self, *exception_types):
        """
        Args:
            exception_types: Exception classes to suppress
        """
        self.exception_types = exception_types
    
    def __enter__(self):
        """Nothing special needed on entry"""
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """
        Suppress only specified exception types.
        
        Returns:
            True if exception should be suppressed
            False if exception should propagate
        """
        if exc_type is None:
            # No exception occurred
            return False
        
        # Check if exception type matches any we should suppress
        for exception_type in self.exception_types:
            if issubclass(exc_type, exception_type):
                print(f"Suppressing {exc_type.__name__}")
                return True  # Suppress this exception
        
        # Don't suppress other exceptions
        return False


# =============================================================================
# SOLUTION 5: Directory Content Saver
# =============================================================================

class DirectoryWatcher:
    """
    Context manager that monitors directory changes.
    
    Pattern: Save state on entry, compare on exit.
    This is useful for detecting changes, rollbacks, etc.
    """
    
    def __init__(self, directory):
        self.directory = directory
        self.initial_files = None
    
    def __enter__(self):
        """List and store initial directory contents"""
        self.initial_files = set(os.listdir(self.directory))
        print(f"Monitoring directory: {self.directory}")
        return list(self.initial_files)
    
    def __exit__(self, exc_type, exc_value, traceback):
        """Compare final state with initial state"""
        final_files = set(os.listdir(self.directory))
        
        # Find changes
        added = final_files - self.initial_files
        removed = self.initial_files - final_files
        
        # Report changes
        if added:
            print(f"Added files: {added}")
        if removed:
            print(f"Removed files: {removed}")
        if not added and not removed:
            print("No changes detected")
        
        return False


# =============================================================================
# SOLUTION 6: Multiple File Processor
# =============================================================================

def process_files(input_file, output_file):
    """
    Process files using multiple context managers.
    
    Method 1: Comma-separated with statement
    Both files are opened simultaneously and both are
    guaranteed to close properly.
    """
    with open(input_file, 'r') as infile, \
         open(output_file, 'w') as outfile:
        # Read all content
        content = infile.read()
        # Write uppercase version
        outfile.write(content.upper())

# Alternative: Nested with statements
def process_files_alt(input_file, output_file):
    """Alternative using nested with statements"""
    with open(input_file, 'r') as infile:
        with open(output_file, 'w') as outfile:
            content = infile.read()
            outfile.write(content.upper())


# =============================================================================
# TEST ALL SOLUTIONS
# =============================================================================

if __name__ == "__main__":
    print("=" * 70)
    print("TESTING BEGINNER SOLUTIONS")
    print("=" * 70)
    print()
    
    # Test 1
    print("Test 1: Greeting Context")
    with GreetingContext("Bob") as name:
        print(f"  Inside with: {name}")
    print()
    
    # Test 2
    print("Test 2: Count Lines")
    with open('/tmp/test.txt', 'w') as f:
        f.write("Line 1\nLine 2\nLine 3\n")
    count = count_lines('/tmp/test.txt')
    print(f"  Lines: {count}")
    print()
    
    # Test 3
    print("Test 3: Timer")
    with Timer() as t:
        time.sleep(0.2)
    print()
    
    # Test 4
    print("Test 4: Suppress Exception")
    with SuppressException(ValueError):
        raise ValueError("Test")
    print("  Continued")
    print()
    
    # Test 5
    print("Test 5: Directory Watcher")
    os.makedirs('/tmp/watch_test', exist_ok=True)
    with DirectoryWatcher('/tmp/watch_test'):
        with open('/tmp/watch_test/new.txt', 'w') as f:
            f.write("test")
    print()
    
    # Test 6
    print("Test 6: Process Files")
    with open('/tmp/in.txt', 'w') as f:
        f.write("hello")
    process_files('/tmp/in.txt', '/tmp/out.txt')
    with open('/tmp/out.txt', 'r') as f:
        print(f"  Result: {f.read()}")
    
    print("=" * 70)
    print("ALL SOLUTIONS TESTED")
    print("=" * 70)
