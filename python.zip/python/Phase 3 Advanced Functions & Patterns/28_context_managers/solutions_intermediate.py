"""
solutions_intermediate.py

SOLUTIONS TO INTERMEDIATE EXERCISES
"""

from contextlib import contextmanager, ExitStack
import sys
import time

# SOLUTION 1: temp_syspath
@contextmanager
def temp_syspath(path):
    """Temporarily add path to sys.path"""
    sys.path.insert(0, path)
    try:
        yield
    finally:
        sys.path.remove(path)

# SOLUTION 2: TransactionManager
class TransactionManager:
    def __init__(self):
        self.operations = []
        self.depth = 0
    
    def __enter__(self):
        self.depth += 1
        if self.depth == 1:
            print("BEGIN TRANSACTION")
        else:
            print(f"SAVEPOINT level_{self.depth}")
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is None:
            if self.depth == 1:
                print(f"COMMIT: {self.operations}")
                self.operations.clear()
            else:
                print(f"RELEASE SAVEPOINT level_{self.depth}")
        else:
            if self.depth == 1:
                print(f"ROLLBACK: {self.operations}")
                self.operations.clear()
            else:
                print(f"ROLLBACK TO SAVEPOINT level_{self.depth}")
        self.depth -= 1
        return False
    
    def add(self, operation):
        self.operations.append(operation)

# SOLUTION 3: IndentedLogger
class IndentedLogger:
    depth = 0
    indent_str = "  "
    
    def __enter__(self):
        IndentedLogger.depth += 1
        return self
    
    def __exit__(self, *args):
        IndentedLogger.depth -= 1
        return False
    
    @classmethod
    def log(cls, message):
        print(f"{cls.indent_str * cls.depth}{message}")

# SOLUTION 4: config_hierarchy
def config_hierarchy(filenames):
    """Load configuration hierarchy using ExitStack"""
    config = {}
    with ExitStack() as stack:
        for filename in filenames:
            try:
                f = stack.enter_context(open(filename, 'r'))
                # Simple config loading (key=value format)
                for line in f:
                    if '=' in line:
                        key, value = line.strip().split('=', 1)
                        config[key] = value
            except FileNotFoundError:
                print(f"Config file not found: {filename}")
    return config

# SOLUTION 5: ExceptionTransformer
@contextmanager
def exception_transformer(mapping):
    """Transform exceptions based on mapping"""
    try:
        yield
    except Exception as e:
        for from_exc, to_exc in mapping.items():
            if isinstance(e, from_exc):
                print(f"Transforming {type(e).__name__} to {to_exc.__name__}")
                raise to_exc(str(e)) from e
        raise

# SOLUTION 6: retry_context
@contextmanager
def retry_context(max_attempts=3, retry_on=(Exception,), backoff=1.0):
    """Retry with exponential backoff"""
    for attempt in range(1, max_attempts + 1):
        try:
            print(f"Attempt {attempt}/{max_attempts}")
            yield
            break
        except retry_on as e:
            if attempt < max_attempts:
                wait = backoff * (2 ** (attempt - 1))
                print(f"  Failed: {e}, retrying in {wait}s...")
                time.sleep(wait)
            else:
                print(f"  Failed: {e}, no more attempts")
                raise

print("All intermediate solutions implemented!")
