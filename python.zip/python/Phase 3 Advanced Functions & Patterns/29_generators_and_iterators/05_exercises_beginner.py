"""
PYTHON GENERATORS & ITERATORS - BEGINNER EXERCISES
==================================================

Instructions:
------------
1. Read each exercise carefully
2. Implement your solution in the designated area
3. Test your implementation with the provided test cases
4. Check your work against the solution file when done

Topics Covered:
--------------
- Creating custom iterators
- Understanding __iter__() and __next__()
- Handling StopIteration
- Basic generator functions
- Simple generator expressions
"""

# ============================================================================
# EXERCISE 1: Simple Counter Iterator
# ============================================================================

"""
EXERCISE 1: Create a Range Iterator

Implement a custom iterator class called 'MyRange' that mimics Python's
built-in range() function for positive integers.

Requirements:
- Takes start and stop parameters (stop is exclusive)
- Implements __iter__() and __next__() methods
- Raises StopIteration when range is exhausted

Example:
    for num in MyRange(1, 5):
        print(num)  # Prints: 1, 2, 3, 4
"""


class MyRange:
    """Custom range iterator class."""
    
    def __init__(self, start, stop):
        # YOUR CODE HERE
        pass
    
    def __iter__(self):
        # YOUR CODE HERE
        pass
    
    def __next__(self):
        # YOUR CODE HERE
        pass


# Test Exercise 1
print("=" * 70)
print("EXERCISE 1: Testing MyRange")
print("=" * 70)

try:
    print("Test 1: MyRange(1, 5)")
    result = list(MyRange(1, 5))
    expected = [1, 2, 3, 4]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: MyRange(0, 3)")
    result = list(MyRange(0, 3))
    expected = [0, 1, 2]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 2: Reusable Iterable
# ============================================================================

"""
EXERCISE 2: Create a Reusable Countdown

Implement both a CountdownIterable and CountdownIterator class.
The iterable should create a new iterator each time, allowing
multiple iterations.

Requirements:
- CountdownIterable stores the starting number
- CountdownIterable.__iter__() returns a new CountdownIterator
- CountdownIterator counts down from n to 1
- Should be able to iterate multiple times

Example:
    countdown = CountdownIterable(3)
    list(countdown)  # [3, 2, 1]
    list(countdown)  # [3, 2, 1] (works again!)
"""


class CountdownIterable:
    """Iterable for countdown."""
    
    def __init__(self, n):
        # YOUR CODE HERE
        pass
    
    def __iter__(self):
        # YOUR CODE HERE
        pass


class CountdownIterator:
    """Iterator for countdown."""
    
    def __init__(self, n):
        # YOUR CODE HERE
        pass
    
    def __iter__(self):
        # YOUR CODE HERE
        pass
    
    def __next__(self):
        # YOUR CODE HERE
        pass


# Test Exercise 2
print("=" * 70)
print("EXERCISE 2: Testing Countdown")
print("=" * 70)

try:
    countdown = CountdownIterable(5)
    
    print("Test 1: First iteration")
    result1 = list(countdown)
    expected = [5, 4, 3, 2, 1]
    print(f"Result: {result1}")
    print(f"Expected: {expected}")
    print(f"Pass: {result1 == expected}\n")
    
    print("Test 2: Second iteration (testing reusability)")
    result2 = list(countdown)
    print(f"Result: {result2}")
    print(f"Expected: {expected}")
    print(f"Pass: {result2 == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 3: Fibonacci Iterator
# ============================================================================

"""
EXERCISE 3: Create a Fibonacci Iterator

Implement an iterator that generates Fibonacci numbers up to a maximum value.

Requirements:
- Takes a max_value parameter
- Generates: 0, 1, 1, 2, 3, 5, 8, 13, ...
- Stops when next number would exceed max_value

Example:
    fib = FibonacciIterator(20)
    list(fib)  # [0, 1, 1, 2, 3, 5, 8, 13]
"""


class FibonacciIterator:
    """Iterator for Fibonacci sequence."""
    
    def __init__(self, max_value):
        # YOUR CODE HERE
        pass
    
    def __iter__(self):
        # YOUR CODE HERE
        pass
    
    def __next__(self):
        # YOUR CODE HERE
        pass


# Test Exercise 3
print("=" * 70)
print("EXERCISE 3: Testing Fibonacci")
print("=" * 70)

try:
    print("Test 1: FibonacciIterator(50)")
    result = list(FibonacciIterator(50))
    expected = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: FibonacciIterator(10)")
    result = list(FibonacciIterator(10))
    expected = [0, 1, 1, 2, 3, 5, 8]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 4: Simple Generator Function
# ============================================================================

"""
EXERCISE 4: Create a Square Generator

Implement a generator function that yields the square of numbers
from 1 to n.

Requirements:
- Takes a single parameter n
- Yields squares: 1, 4, 9, 16, ..., n^2
- Must use yield (generator function)

Example:
    gen = squares(4)
    list(gen)  # [1, 4, 9, 16]
"""


def squares(n):
    """Generator for squares of numbers 1 to n."""
    # YOUR CODE HERE
    pass


# Test Exercise 4
print("=" * 70)
print("EXERCISE 4: Testing Squares Generator")
print("=" * 70)

try:
    print("Test 1: squares(5)")
    result = list(squares(5))
    expected = [1, 4, 9, 16, 25]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: Check it's a generator")
    gen = squares(3)
    print(f"Type: {type(gen)}")
    print(f"Is generator: {hasattr(gen, '__next__')}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 5: Even Numbers Generator
# ============================================================================

"""
EXERCISE 5: Create an Even Numbers Generator

Implement a generator function that yields even numbers from a range.

Requirements:
- Takes start and end parameters (end is exclusive)
- Yields only even numbers in the range
- Use generator function with yield

Example:
    gen = even_numbers(1, 10)
    list(gen)  # [2, 4, 6, 8]
"""


def even_numbers(start, end):
    """Generator for even numbers in range."""
    # YOUR CODE HERE
    pass


# Test Exercise 5
print("=" * 70)
print("EXERCISE 5: Testing Even Numbers")
print("=" * 70)

try:
    print("Test 1: even_numbers(1, 10)")
    result = list(even_numbers(1, 10))
    expected = [2, 4, 6, 8]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: even_numbers(0, 7)")
    result = list(even_numbers(0, 7))
    expected = [0, 2, 4, 6]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 6: Generator Expressions
# ============================================================================

"""
EXERCISE 6: Use Generator Expressions

For each task below, write a generator expression (not a list comprehension).

Requirements:
- All must be generator expressions (use parentheses)
- Should not create lists
"""


def exercise_6():
    """Complete the generator expressions."""
    
    # Task A: Generator for squares of numbers 1-10
    # squares_gen = YOUR CODE HERE
    squares_gen = None  # Replace this line
    
    # Task B: Generator for odd numbers from 1-20
    # odds_gen = YOUR CODE HERE
    odds_gen = None  # Replace this line
    
    # Task C: Generator for lengths of strings in a list
    words = ['hello', 'world', 'python', 'generator']
    # lengths_gen = YOUR CODE HERE
    lengths_gen = None  # Replace this line
    
    return squares_gen, odds_gen, lengths_gen


# Test Exercise 6
print("=" * 70)
print("EXERCISE 6: Testing Generator Expressions")
print("=" * 70)

try:
    squares_gen, odds_gen, lengths_gen = exercise_6()
    
    print("Test 1: Squares")
    if squares_gen:
        result = list(squares_gen)
        expected = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
        print(f"Result: {result}")
        print(f"Expected: {expected}")
        print(f"Pass: {result == expected}\n")
    else:
        print("Not implemented yet\n")
    
    print("Test 2: Odd numbers")
    if odds_gen:
        result = list(odds_gen)
        expected = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
        print(f"Result: {result}")
        print(f"Expected: {expected}")
        print(f"Pass: {result == expected}\n")
    else:
        print("Not implemented yet\n")
    
    print("Test 3: String lengths")
    if lengths_gen:
        result = list(lengths_gen)
        expected = [5, 5, 6, 9]
        print(f"Result: {result}")
        print(f"Expected: {expected}")
        print(f"Pass: {result == expected}\n")
    else:
        print("Not implemented yet\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 7: Character Iterator
# ============================================================================

"""
EXERCISE 7: Create a Character Iterator

Implement an iterator that yields characters from a string one at a time,
but in reverse order.

Requirements:
- Takes a string parameter
- Iterates from last character to first
- Implements iterator protocol

Example:
    rev = ReverseStringIterator("hello")
    list(rev)  # ['o', 'l', 'l', 'e', 'h']
"""


class ReverseStringIterator:
    """Iterator for string in reverse."""
    
    def __init__(self, text):
        # YOUR CODE HERE
        pass
    
    def __iter__(self):
        # YOUR CODE HERE
        pass
    
    def __next__(self):
        # YOUR CODE HERE
        pass


# Test Exercise 7
print("=" * 70)
print("EXERCISE 7: Testing Reverse String Iterator")
print("=" * 70)

try:
    print("Test 1: 'Python'")
    result = ''.join(ReverseStringIterator("Python"))
    expected = "nohtyP"
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: 'abc'")
    result = list(ReverseStringIterator("abc"))
    expected = ['c', 'b', 'a']
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 8: Prime Numbers Generator
# ============================================================================

"""
EXERCISE 8: Create a Prime Numbers Generator

Implement a generator function that yields prime numbers up to a maximum value.

Requirements:
- Takes a max_value parameter
- Yields only prime numbers
- A prime is divisible only by 1 and itself

Example:
    gen = primes(20)
    list(gen)  # [2, 3, 5, 7, 11, 13, 17, 19]
"""


def is_prime(n):
    """Helper function to check if n is prime."""
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def primes(max_value):
    """Generator for prime numbers up to max_value."""
    # YOUR CODE HERE
    pass


# Test Exercise 8
print("=" * 70)
print("EXERCISE 8: Testing Primes Generator")
print("=" * 70)

try:
    print("Test 1: primes(30)")
    result = list(primes(30))
    expected = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: primes(10)")
    result = list(primes(10))
    expected = [2, 3, 5, 7]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 9: Custom List Iterator
# ============================================================================

"""
EXERCISE 9: Create a Skip Iterator

Implement an iterator that skips every nth element from a list.

Requirements:
- Takes a list and skip_every parameter
- Yields elements, skipping every nth one
- Example: [1,2,3,4,5,6] skip_every=2 -> [1,3,5]

Example:
    skipper = SkipIterator([1,2,3,4,5,6,7,8], 3)
    list(skipper)  # [1, 2, 4, 5, 7, 8]  (skips 3, 6)
"""


class SkipIterator:
    """Iterator that skips every nth element."""
    
    def __init__(self, data, skip_every):
        # YOUR CODE HERE
        pass
    
    def __iter__(self):
        # YOUR CODE HERE
        pass
    
    def __next__(self):
        # YOUR CODE HERE
        pass


# Test Exercise 9
print("=" * 70)
print("EXERCISE 9: Testing Skip Iterator")
print("=" * 70)

try:
    print("Test 1: Skip every 2nd element")
    result = list(SkipIterator([1,2,3,4,5,6], 2))
    expected = [1,3,5]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: Skip every 3rd element")
    result = list(SkipIterator([1,2,3,4,5,6,7,8,9], 3))
    expected = [1,2,4,5,7,8]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# EXERCISE 10: Cycle Generator
# ============================================================================

"""
EXERCISE 10: Create an Infinite Cycle Generator

Implement a generator that cycles through a list infinitely.

Requirements:
- Takes a list parameter
- Yields items in order, then starts over
- Continues forever (infinite generator)
- User must break the loop manually

Example:
    gen = cycle([1, 2, 3])
    # Yields: 1, 2, 3, 1, 2, 3, 1, 2, 3, ...
"""


def cycle(items):
    """Generator that cycles through items infinitely."""
    # YOUR CODE HERE
    pass


# Test Exercise 10
print("=" * 70)
print("EXERCISE 10: Testing Cycle Generator")
print("=" * 70)

try:
    print("Test 1: First 10 items from cycle([1, 2, 3])")
    gen = cycle([1, 2, 3])
    result = []
    for i, item in enumerate(gen):
        if i >= 10:
            break
        result.append(item)
    expected = [1, 2, 3, 1, 2, 3, 1, 2, 3, 1]
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
    
    print("Test 2: First 7 items from cycle(['a', 'b'])")
    gen = cycle(['a', 'b'])
    result = []
    for i, item in enumerate(gen):
        if i >= 7:
            break
        result.append(item)
    expected = ['a', 'b', 'a', 'b', 'a', 'b', 'a']
    print(f"Result: {result}")
    print(f"Expected: {expected}")
    print(f"Pass: {result == expected}\n")
except Exception as e:
    print(f"Error: {e}\n")


# ============================================================================
# COMPLETION MESSAGE
# ============================================================================

print("=" * 70)
print("END OF BEGINNER EXERCISES")
print("=" * 70)
print("\nGreat job working through these exercises!")
print("Check the solution file 08_solutions_beginner.py to compare.")
print("\nKey concepts practiced:")
print("- Creating iterator classes")
print("- Implementing __iter__() and __next__()")
print("- Writing generator functions")
print("- Using generator expressions")
print("- Understanding lazy evaluation")
print("\nReady for intermediate exercises!")
print("=" * 70)
