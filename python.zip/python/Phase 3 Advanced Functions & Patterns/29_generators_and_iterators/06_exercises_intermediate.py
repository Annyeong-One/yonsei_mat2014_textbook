"""
PYTHON GENERATORS & ITERATORS - INTERMEDIATE EXERCISES
======================================================

Instructions:
------------
1. Read each exercise carefully
2. Implement your solution in the designated area
3. Test your implementation with the provided test cases
4. Check your work against the solution file when done

Topics Covered:
--------------
- Generator functions with state
- Generator expressions for filtering
- Chaining generators
- Lazy evaluation patterns
- Data processing pipelines
"""

# Exercise 1: Running Total Generator
def running_total(numbers):
    """
    Create a generator that yields running totals.
    
    Example:
        gen = running_total([1, 2, 3, 4, 5])
        list(gen)  # [1, 3, 6, 10, 15]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 1
print("Exercise 1: Running Total")
result = list(running_total([1, 2, 3, 4, 5]))
expected = [1, 3, 6, 10, 15]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 2: Batch Generator
def batch_generator(iterable, batch_size):
    """
    Create batches of specified size from an iterable.
    
    Example:
        gen = batch_generator(range(10), 3)
        list(gen)  # [[0,1,2], [3,4,5], [6,7,8], [9]]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 2
print("Exercise 2: Batch Generator")
result = list(batch_generator(range(10), 3))
expected = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 3: Flatten Nested Lists
def flatten(nested_list):
    """
    Flatten a nested list structure using recursion and yield from.
    
    Example:
        gen = flatten([1, [2, [3, 4]], 5])
        list(gen)  # [1, 2, 3, 4, 5]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 3
print("Exercise 3: Flatten")
result = list(flatten([1, [2, [3, 4]], 5, [6, 7]]))
expected = [1, 2, 3, 4, 5, 6, 7]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 4: Window Generator
def window(iterable, size):
    """
    Generate sliding windows of specified size.
    
    Example:
        gen = window([1,2,3,4,5], 3)
        list(gen)  # [(1,2,3), (2,3,4), (3,4,5)]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 4
print("Exercise 4: Window Generator")
result = list(window([1, 2, 3, 4, 5], 3))
expected = [(1, 2, 3), (2, 3, 4), (3, 4, 5)]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 5: Filter Map Generator
def filter_map(iterable, filter_func, map_func):
    """
    Filter and map in one generator.
    
    Example:
        gen = filter_map(range(10), lambda x: x%2==0, lambda x: x**2)
        list(gen)  # [0, 4, 16, 36, 64]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 5
print("Exercise 5: Filter Map")
result = list(filter_map(range(10), lambda x: x % 2 == 0, lambda x: x ** 2))
expected = [0, 4, 16, 36, 64]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 6: Unique Generator
def unique(iterable):
    """
    Yield only unique items (first occurrence).
    
    Example:
        gen = unique([1,2,2,3,1,4])
        list(gen)  # [1, 2, 3, 4]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 6
print("Exercise 6: Unique")
result = list(unique([1, 2, 2, 3, 1, 4, 3, 5]))
expected = [1, 2, 3, 4, 5]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 7: Chained Generators
def chain_generators(*iterables):
    """
    Chain multiple iterables into one generator.
    
    Example:
        gen = chain_generators([1,2], [3,4], [5,6])
        list(gen)  # [1, 2, 3, 4, 5, 6]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 7
print("Exercise 7: Chain Generators")
result = list(chain_generators([1, 2], [3, 4], [5, 6]))
expected = [1, 2, 3, 4, 5, 6]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 8: Take While Generator
def take_while(iterable, predicate):
    """
    Yield items while predicate is True.
    
    Example:
        gen = take_while([1,2,3,4,5,6], lambda x: x < 4)
        list(gen)  # [1, 2, 3]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 8
print("Exercise 8: Take While")
result = list(take_while([1, 2, 3, 4, 5, 6], lambda x: x < 4))
expected = [1, 2, 3]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 9: Pairwise Generator
def pairwise(iterable):
    """
    Generate consecutive pairs.
    
    Example:
        gen = pairwise([1,2,3,4])
        list(gen)  # [(1,2), (2,3), (3,4)]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 9
print("Exercise 9: Pairwise")
result = list(pairwise([1, 2, 3, 4]))
expected = [(1, 2), (2, 3), (3, 4)]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 10: Moving Average Generator
def moving_average(numbers, window_size):
    """
    Calculate moving average with given window size.
    
    Example:
        gen = moving_average([1,2,3,4,5], 3)
        list(gen)  # [2.0, 3.0, 4.0]
    """
    # YOUR CODE HERE
    pass

# Test Exercise 10
print("Exercise 10: Moving Average")
result = list(moving_average([1, 2, 3, 4, 5], 3))
expected = [2.0, 3.0, 4.0]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")

print("\n" + "=" * 70)
print("END OF INTERMEDIATE EXERCISES")
print("Check solutions file when ready!")
print("=" * 70)
