"""
PYTHON GENERATORS & ITERATORS - ADVANCED EXERCISES
==================================================

Instructions:
------------
1. Read each exercise carefully
2. Implement your solution in the designated area
3. Test your implementation with the provided test cases
4. Check your work against the solution file when done

Topics Covered:
--------------
- Generator methods: send(), throw(), close()
- Bidirectional communication
- yield from delegation
- Coroutines
- Complex generator pipelines
"""

# Exercise 1: Calculator Coroutine
def calculator():
    """
    Create a calculator coroutine that accepts operations.
    
    The coroutine should:
    - Accept dicts: {'op': '+', 'value': 10}
    - Maintain running total
    - Yield result after each operation
    - Support ops: +, -, *, /
    """
    # YOUR CODE HERE
    pass

# Test Exercise 1
print("Exercise 1: Calculator Coroutine")
try:
    calc = calculator()
    next(calc)
    r1 = calc.send({'op': '+', 'value': 10})
    r2 = calc.send({'op': '*', 'value': 2})
    r3 = calc.send({'op': '-', 'value': 5})
    print(f"Results: {r1}, {r2}, {r3}")
    print(f"Pass: {r1 == 10 and r2 == 20 and r3 == 15}\n")
except Exception as e:
    print(f"Error: {e}\n")


# Exercise 2: Pipeline with send()
def data_collector():
    """
    Create a coroutine that collects sent data and yields summary.
    
    Should accept: numbers via send()
    Should yield: {'count': n, 'sum': s, 'avg': a} after each send
    Stop on send(None)
    """
    # YOUR CODE HERE
    pass

# Test Exercise 2
print("Exercise 2: Data Collector")
try:
    collector = data_collector()
    next(collector)
    r1 = collector.send(10)
    r2 = collector.send(20)
    r3 = collector.send(30)
    print(f"Final result: {r3}")
    print(f"Pass: {r3['avg'] == 20.0}\n")
except Exception as e:
    print(f"Error: {e}\n")


# Exercise 3: Generator with throw()
def resilient_processor():
    """
    Create a generator that handles exceptions via throw().
    
    Should:
    - Process items normally
    - Catch ValueError, log it, and continue
    - Stop on any other exception
    """
    # YOUR CODE HERE
    pass

# Test Exercise 3
print("Exercise 3: Resilient Processor")
try:
    processor = resilient_processor()
    next(processor)
    processor.send("process this")
    processor.throw(ValueError, "test error")
    processor.send("continue")
    print("Pass: Handled ValueError and continued\n")
except Exception as e:
    print(f"Error: {e}\n")


# Exercise 4: yield from Tree Traversal
class TreeNode:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def preorder_traversal(node):
    """
    Implement preorder traversal using yield from.
    
    Preorder: root, left, right
    """
    # YOUR CODE HERE
    pass

# Test Exercise 4
print("Exercise 4: Tree Traversal")
root = TreeNode(1, TreeNode(2, TreeNode(4), TreeNode(5)), TreeNode(3))
result = list(preorder_traversal(root))
expected = [1, 2, 4, 5, 3]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")


# Exercise 5: Coroutine Decorator
def coroutine(func):
    """
    Create a decorator that auto-primes coroutines.
    """
    # YOUR CODE HERE
    pass

@coroutine
def test_coroutine():
    while True:
        value = yield
        print(f"Received: {value}")

# Test Exercise 5
print("Exercise 5: Coroutine Decorator")
try:
    coro = test_coroutine()
    coro.send("test")  # Should work without next()
    print("Pass: Coroutine auto-primed\n")
except Exception as e:
    print(f"Error: {e}\n")


# Exercise 6: Pipeline Coroutines
def printer():
    """Final stage: print received values."""
    # YOUR CODE HERE
    pass

def doubler(target):
    """Middle stage: double and send to target."""
    # YOUR CODE HERE
    pass

def filter_positive(target):
    """First stage: filter positive numbers."""
    # YOUR CODE HERE
    pass

# Test Exercise 6
print("Exercise 6: Coroutine Pipeline")
try:
    p = printer()
    d = doubler(p)
    f = filter_positive(d)
    
    f.send(5)   # Should print 10
    f.send(-3)  # Should not print
    f.send(2)   # Should print 4
    print("Pass: Pipeline working\n")
except Exception as e:
    print(f"Error: {e}\n")


# Exercise 7: Generator State Machine
def traffic_light():
    """
    Create a traffic light state machine.
    
    States: 'red', 'yellow', 'green'
    Commands: 'next' (advance), 'reset' (to red)
    Yields current state
    """
    # YOUR CODE HERE
    pass

# Test Exercise 7
print("Exercise 7: State Machine")
try:
    light = traffic_light()
    s1 = next(light)
    s2 = light.send('next')
    s3 = light.send('next')
    s4 = light.send('reset')
    print(f"States: {s1}, {s2}, {s3}, {s4}")
    print(f"Pass: {s1 == 'red' and s2 == 'yellow' and s4 == 'red'}\n")
except Exception as e:
    print(f"Error: {e}\n")


# Exercise 8: Complex yield from
def delegate_to_subgen(n):
    """
    Delegate to multiple sub-generators using yield from.
    
    Should yield:
    - Numbers 1 to n
    - Then squares of 1 to n
    - Then cubes of 1 to n
    """
    # YOUR CODE HERE
    pass

# Test Exercise 8
print("Exercise 8: Complex Delegation")
result = list(delegate_to_subgen(3))
expected = [1, 2, 3, 1, 4, 9, 1, 8, 27]
print(f"Result: {result}")
print(f"Pass: {result == expected}\n")

print("\n" + "=" * 70)
print("END OF ADVANCED EXERCISES")
print("Excellent work! Check solutions file when ready!")
print("=" * 70)
