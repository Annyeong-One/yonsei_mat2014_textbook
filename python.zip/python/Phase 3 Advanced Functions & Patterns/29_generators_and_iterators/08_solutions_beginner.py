"""
PYTHON GENERATORS & ITERATORS - BEGINNER SOLUTIONS
==================================================

This file contains complete solutions with detailed explanations
for all beginner-level exercises.

Each solution includes:
- Complete working code
- Explanation of the approach
- Key concepts demonstrated
"""

# SOLUTION 1: Simple Counter Iterator
class MyRange:
    """
    Custom range iterator.
    
    Approach:
    - Store start and stop in __init__
    - Track current position
    - In __next__, return current and increment
    - Raise StopIteration when done
    """
    
    def __init__(self, start, stop):
        self.start = start
        self.stop = stop
        self.current = start
    
    def __iter__(self):
        # Return self - this is an iterator
        return self
    
    def __next__(self):
        # Check if we've reached the end
        if self.current >= self.stop:
            raise StopIteration
        
        # Get current value, increment, return
        value = self.current
        self.current += 1
        return value

print("Solution 1: MyRange")
print(list(MyRange(1, 5)))
print()


# SOLUTION 2: Reusable Iterable
class CountdownIterable:
    """
    Reusable countdown iterable.
    
    Key: Separate iterable from iterator!
    - Iterable stores configuration
    - Iterator tracks state
    - Each __iter__ call creates NEW iterator
    """
    
    def __init__(self, n):
        self.n = n
    
    def __iter__(self):
        # Return NEW iterator each time
        return CountdownIterator(self.n)


class CountdownIterator:
    """Iterator for countdown."""
    
    def __init__(self, n):
        self.current = n
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.current < 1:
            raise StopIteration
        value = self.current
        self.current -= 1
        return value

print("Solution 2: Countdown")
cd = CountdownIterable(3)
print(list(cd))
print(list(cd))  # Works again!
print()


# SOLUTION 3: Fibonacci Iterator
class FibonacciIterator:
    """
    Fibonacci iterator.
    
    Approach:
    - Track two previous numbers (a, b)
    - Each iteration: save a, calculate next (a,b = b, a+b)
    - Stop when a exceeds max_value
    """
    
    def __init__(self, max_value):
        self.max_value = max_value
        self.a = 0
        self.b = 1
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.a > self.max_value:
            raise StopIteration
        
        value = self.a
        self.a, self.b = self.b, self.a + self.b
        return value

print("Solution 3: Fibonacci")
print(list(FibonacciIterator(20)))
print()


# SOLUTION 4: Squares Generator
def squares(n):
    """
    Generator for squares.
    
    Key: Use yield instead of return
    - Much simpler than iterator class
    - State preserved automatically
    """
    for i in range(1, n + 1):
        yield i ** 2

print("Solution 4: Squares")
print(list(squares(5)))
print()


# SOLUTION 5: Even Numbers Generator
def even_numbers(start, end):
    """
    Generator for even numbers.
    
    Approach:
    - Loop through range
    - Check if even (n % 2 == 0)
    - Yield only evens
    """
    for num in range(start, end):
        if num % 2 == 0:
            yield num

print("Solution 5: Even Numbers")
print(list(even_numbers(1, 10)))
print()


# SOLUTION 6: Generator Expressions
def exercise_6():
    """
    Generator expressions.
    
    Key: Use () instead of []
    - Creates generator, not list
    - Lazy evaluation
    """
    
    squares_gen = (x ** 2 for x in range(1, 11))
    odds_gen = (x for x in range(1, 20) if x % 2 != 0)
    
    words = ['hello', 'world', 'python', 'generator']
    lengths_gen = (len(word) for word in words)
    
    return squares_gen, odds_gen, lengths_gen

print("Solution 6: Generator Expressions")
s, o, l = exercise_6()
print("Squares:", list(s))
print("Odds:", list(o))
print("Lengths:", list(l))
print()


# SOLUTION 7: Reverse String Iterator
class ReverseStringIterator:
    """
    Reverse string iterator.
    
    Approach:
    - Start from end (len - 1)
    - Decrement index each time
    - Stop when index < 0
    """
    
    def __init__(self, text):
        self.text = text
        self.index = len(text) - 1
    
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.index < 0:
            raise StopIteration
        
        char = self.text[self.index]
        self.index -= 1
        return char

print("Solution 7: Reverse String")
print(''.join(ReverseStringIterator("Python")))
print()


# SOLUTION 8: Primes Generator
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True

def primes(max_value):
    """
    Primes generator.
    
    Approach:
    - Check each number from 2 to max_value
    - Use helper function to test primality
    - Yield if prime
    """
    for n in range(2, max_value + 1):
        if is_prime(n):
            yield n

print("Solution 8: Primes")
print(list(primes(20)))
print()


# SOLUTION 9: Skip Iterator
class SkipIterator:
    """
    Skip iterator.
    
    Approach:
    - Track position (1-indexed)
    - Skip when position % skip_every == 0
    - Otherwise yield
    """
    
    def __init__(self, data, skip_every):
        self.data = data
        self.skip_every = skip_every
        self.index = 0
        self.position = 0
    
    def __iter__(self):
        return self
    
    def __next__(self):
        while self.index < len(self.data):
            self.position += 1
            value = self.data[self.index]
            self.index += 1
            
            # Skip if position is multiple of skip_every
            if self.position % self.skip_every == 0:
                continue
            
            return value
        
        raise StopIteration

print("Solution 9: Skip Iterator")
print(list(SkipIterator([1,2,3,4,5,6], 2)))
print()


# SOLUTION 10: Cycle Generator
def cycle(items):
    """
    Infinite cycle generator.
    
    Approach:
    - Use infinite while loop
    - Iterate through items
    - Start over when done
    """
    while True:
        for item in items:
            yield item

print("Solution 10: Cycle")
gen = cycle([1, 2, 3])
result = [next(gen) for _ in range(10)]
print(result)
print()

print("All beginner solutions demonstrated!")
