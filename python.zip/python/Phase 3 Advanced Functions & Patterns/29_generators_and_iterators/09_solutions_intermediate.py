"""
PYTHON GENERATORS & ITERATORS - INTERMEDIATE SOLUTIONS
======================================================
"""

from collections import deque

# SOLUTION 1: Running Total
def running_total(numbers):
    total = 0
    for num in numbers:
        total += num
        yield total

print('Solution 1:', list(running_total([1,2,3,4,5])))

# SOLUTION 2: Batch Generator
def batch_generator(iterable, batch_size):
    batch = []
    for item in iterable:
        batch.append(item)
        if len(batch) >= batch_size:
            yield batch
            batch = []
    if batch:
        yield batch

print('Solution 2:', list(batch_generator(range(10), 3)))

# SOLUTION 3: Flatten
def flatten(nested_list):
    for item in nested_list:
        if isinstance(item, list):
            yield from flatten(item)
        else:
            yield item

print('Solution 3:', list(flatten([1, [2, [3, 4]], 5])))

# SOLUTION 4: Window
def window(iterable, size):
    iterator = iter(iterable)
    win = deque(maxlen=size)
    for _ in range(size):
        try:
            win.append(next(iterator))
        except StopIteration:
            return
    yield tuple(win)
    for item in iterator:
        win.append(item)
        yield tuple(win)

print('Solution 4:', list(window([1,2,3,4,5], 3)))

# SOLUTION 5: Filter Map
def filter_map(iterable, filter_func, map_func):
    for item in iterable:
        if filter_func(item):
            yield map_func(item)

print('Solution 5:', list(filter_map(range(10), lambda x: x%2==0, lambda x: x**2)))

# SOLUTION 6: Unique
def unique(iterable):
    seen = set()
    for item in iterable:
        if item not in seen:
            seen.add(item)
            yield item

print('Solution 6:', list(unique([1,2,2,3,1,4])))

# SOLUTION 7: Chain
def chain_generators(*iterables):
    for iterable in iterables:
        for item in iterable:
            yield item

print('Solution 7:', list(chain_generators([1,2], [3,4], [5,6])))

# SOLUTION 8: Take While
def take_while(iterable, predicate):
    for item in iterable:
        if predicate(item):
            yield item
        else:
            break

print('Solution 8:', list(take_while([1,2,3,4,5,6], lambda x: x < 4)))

# SOLUTION 9: Pairwise
def pairwise(iterable):
    iterator = iter(iterable)
    try:
        prev = next(iterator)
    except StopIteration:
        return
    for item in iterator:
        yield (prev, item)
        prev = item

print('Solution 9:', list(pairwise([1,2,3,4])))

# SOLUTION 10: Moving Average
def moving_average(numbers, window_size):
    nums = list(numbers)
    for i in range(len(nums) - window_size + 1):
        window = nums[i:i + window_size]
        yield sum(window) / len(window)

print('Solution 10:', list(moving_average([1,2,3,4,5], 3)))
