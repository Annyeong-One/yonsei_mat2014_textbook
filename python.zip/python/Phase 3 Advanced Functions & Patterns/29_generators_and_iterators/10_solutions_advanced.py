"""
PYTHON GENERATORS & ITERATORS - ADVANCED SOLUTIONS
==================================================
"""

# SOLUTION 1: Calculator Coroutine
def calculator():
    total = 0
    while True:
        cmd = yield total
        if cmd is None:
            break
        op = cmd.get('op')
        val = cmd.get('value', 0)
        
        if op == '+':
            total += val
        elif op == '-':
            total -= val
        elif op == '*':
            total *= val
        elif op == '/' and val != 0:
            total /= val

print('Solution 1: Calculator')
calc = calculator()
next(calc)
print(calc.send({'op': '+', 'value': 10}))
print(calc.send({'op': '*', 'value': 2}))
print()

# SOLUTION 2: Data Collector
def data_collector():
    total = 0
    count = 0
    while True:
        value = yield {'count': count, 'sum': total, 'avg': total/count if count > 0 else 0}
        if value is None:
            break
        total += value
        count += 1

print('Solution 2: Data Collector')
coll = data_collector()
next(coll)
print(coll.send(10))
print(coll.send(20))
print()

# SOLUTION 3: Resilient Processor
def resilient_processor():
    try:
        while True:
            data = yield
            try:
                print(f'Processing: {data}')
            except ValueError as e:
                print(f'Caught ValueError: {e}')
                continue
    except GeneratorExit:
        print('Closing')

# SOLUTION 4: Tree Traversal
class TreeNode:
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right

def preorder_traversal(node):
    if node:
        yield node.value
        yield from preorder_traversal(node.left)
        yield from preorder_traversal(node.right)

print('Solution 4: Tree Traversal')
root = TreeNode(1, TreeNode(2, TreeNode(4), TreeNode(5)), TreeNode(3))
print(list(preorder_traversal(root)))
print()

# SOLUTION 5: Coroutine Decorator
def coroutine(func):
    def wrapper(*args, **kwargs):
        gen = func(*args, **kwargs)
        next(gen)
        return gen
    return wrapper

# SOLUTION 6: Pipeline Coroutines
@coroutine
def printer():
    while True:
        value = yield
        print(f'Output: {value}')

@coroutine
def doubler(target):
    while True:
        value = yield
        target.send(value * 2)

@coroutine
def filter_positive(target):
    while True:
        value = yield
        if value > 0:
            target.send(value)

# SOLUTION 7: State Machine
def traffic_light():
    states = ['red', 'yellow', 'green']
    current = 0
    state = states[current]
    
    while True:
        cmd = yield state
        if cmd == 'next':
            current = (current + 1) % len(states)
            state = states[current]
        elif cmd == 'reset':
            current = 0
            state = states[current]

print('Solution 7: State Machine')
light = traffic_light()
print(next(light))
print(light.send('next'))
print(light.send('next'))
print()

# SOLUTION 8: Complex Delegation
def delegate_to_subgen(n):
    yield from range(1, n + 1)
    yield from (x**2 for x in range(1, n + 1))
    yield from (x**3 for x in range(1, n + 1))

print('Solution 8: Delegation')
print(list(delegate_to_subgen(3)))
