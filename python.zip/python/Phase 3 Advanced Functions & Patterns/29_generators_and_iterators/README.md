# Python Generators & Iterators - Comprehensive Educational Package

## Course Overview
This package provides a complete curriculum for teaching Python Generators & Iterators in an undergraduate computer science course. The materials progress from fundamental concepts to advanced applications, with heavily commented code and practical exercises.

## Package Contents

### Tutorial Files (Progressive Difficulty)

1. **01_beginner_iteration_basics.py**
   - Understanding iterables vs iterators
   - The iteration protocol
   - Built-in iterators
   - Creating custom iterators with classes
   - The `__iter__()` and `__next__()` methods

2. **02_intermediate_generators.py**
   - Introduction to generator functions
   - The `yield` keyword
   - Generator expressions
   - Lazy evaluation and memory efficiency
   - Generator state and execution flow
   - Practical use cases

3. **03_advanced_generators.py**
   - Advanced generator methods: `send()`, `throw()`, `close()`
   - Generator delegation with `yield from`
   - Coroutines and bidirectional communication
   - Generator pipelines
   - Performance optimization techniques

4. **04_practical_applications.py**
   - Real-world generator patterns
   - Working with large datasets
   - Infinite sequences
   - Generator-based parsers
   - Custom iteration protocols
   - Integration with standard library

### Exercise Files

5. **05_exercises_beginner.py**
   - Basic iterator and generator exercises
   - Difficulty: Beginner
   - 10 hands-on problems

6. **06_exercises_intermediate.py**
   - Intermediate generator challenges
   - Difficulty: Intermediate
   - 10 practical problems

7. **07_exercises_advanced.py**
   - Advanced generator applications
   - Difficulty: Advanced
   - 8 complex problems

8. **08_solutions_beginner.py**
   - Complete solutions with explanations
   - For beginner exercises

9. **09_solutions_intermediate.py**
   - Complete solutions with explanations
   - For intermediate exercises

10. **10_solutions_advanced.py**
    - Complete solutions with explanations
    - For advanced exercises

## Learning Objectives

By the end of this module, students will be able to:

1. **Understand Core Concepts**
   - Distinguish between iterables, iterators, and generators
   - Explain the iteration protocol in Python
   - Understand lazy evaluation and its benefits

2. **Implement Iterators**
   - Create custom iterator classes
   - Implement `__iter__()` and `__next__()` methods
   - Handle StopIteration exceptions properly

3. **Work with Generators**
   - Write generator functions using `yield`
   - Create generator expressions
   - Understand generator state management

4. **Apply Advanced Techniques**
   - Use `send()`, `throw()`, and `close()` methods
   - Implement generator pipelines
   - Create coroutines for bidirectional communication
   - Use `yield from` for generator delegation

5. **Solve Real Problems**
   - Process large datasets efficiently
   - Create infinite sequences
   - Build data processing pipelines
   - Optimize memory usage in applications

## Suggested Teaching Schedule

### Week 1: Iteration Fundamentals
- Day 1-2: Iteration protocol and iterables
- Day 3-4: Custom iterators with classes
- Day 5: Exercises and review

### Week 2: Generator Basics
- Day 1-2: Generator functions and yield
- Day 3-4: Generator expressions and lazy evaluation
- Day 5: Exercises and review

### Week 3: Advanced Generators
- Day 1-2: send(), throw(), close() methods
- Day 3-4: yield from and generator pipelines
- Day 5: Exercises and review

### Week 4: Practical Applications
- Day 1-3: Real-world applications and patterns
- Day 4-5: Final project and comprehensive review

## Key Concepts Covered

### Iteration Protocol
- Iterable: Object with `__iter__()` method
- Iterator: Object with `__iter__()` and `__next__()` methods
- StopIteration exception handling

### Generator Features
- Lazy evaluation (compute on demand)
- Memory efficiency (no intermediate lists)
- State preservation between yields
- One-time iteration

### Advanced Patterns
- Generator pipelines (chaining generators)
- Coroutines (bidirectional communication)
- Context management with generators
- Infinite sequences

## Prerequisites

- Basic Python programming (variables, functions, loops)
- Understanding of Python functions and scope
- Basic knowledge of exceptions
- Familiarity with Python lists and loops

## Usage Instructions

1. Start with `01_beginner_iteration_basics.py`
2. Read through the heavily commented code
3. Run the examples interactively
4. Complete corresponding exercises
5. Check solutions after attempting problems
6. Progress to next difficulty level

## Running the Code

All files are standalone and can be run directly:
```bash
python 01_beginner_iteration_basics.py
```

For exercises, students should:
1. Open exercise file
2. Implement solutions in designated areas
3. Test their implementations
4. Compare with solution files

## Additional Resources

- Python official documentation: https://docs.python.org/3/library/stdtypes.html#iterator-types
- PEP 255 (Simple Generators): https://www.python.org/dev/peps/pep-0255/
- PEP 342 (Coroutines): https://www.python.org/dev/peps/pep-0342/
- PEP 380 (yield from): https://www.python.org/dev/peps/pep-0380/

## Assessment Suggestions

1. **Quiz Questions** (Conceptual Understanding)
   - What is the difference between an iterable and an iterator?
   - Explain lazy evaluation in generators
   - When should you use a generator vs. a list?

2. **Coding Assignments**
   - Implement a custom iterator for a data structure
   - Create a generator pipeline for data processing
   - Build a parser using generators

3. **Project Ideas**
   - Log file analyzer using generators
   - Data streaming application
   - Custom iteration for complex data structures

## Notes for Instructors

- All code is heavily commented for self-paced learning
- Examples progress from simple to complex within each file
- Exercises are designed to reinforce concepts from tutorials
- Solutions include detailed explanations of approach
- Code follows PEP 8 style guidelines
- All examples are tested and working

## License

This educational package is designed for academic use in undergraduate computer science courses.

## Author

Created for undergraduate Python education

## Version

Version 1.0 - Comprehensive Generators & Iterators Curriculum
