# Classes & Objects: Fundamentals

## What are Classes and Objects?

### Class
A **class** is a blueprint or template for creating objects. It defines:
- **Attributes** (data/properties)
- **Methods** (functions/behaviors)

Think of a class as a cookie cutter and objects as the cookies made from it.

### Object
An **object** is an instance of a class. It's a concrete entity created from the class blueprint with specific values.

## Basic Syntax

```python
class ClassName:
    # Class attribute (shared by all instances)
    class_attribute = "shared value"
    
    # Constructor method
    def __init__(self, param1, param2):
        # Instance attributes (unique to each object)
        self.attribute1 = param1
        self.attribute2 = param2
    
    # Instance method
    def method_name(self):
        return f"Accessing {self.attribute1}"
```

## The `self` Parameter

- `self` represents the instance of the class
- It's used to access attributes and methods of the current object
- Always the first parameter in instance methods
- Python automatically passes it when you call a method

## Example: Creating a Simple Class

```python
class Dog:
    # Class attribute
    species = "Canis familiaris"
    
    def __init__(self, name, age):
        # Instance attributes
        self.name = name
        self.age = age
    
    # Instance method
    def bark(self):
        return f"{self.name} says Woof!"
    
    def get_info(self):
        return f"{self.name} is {self.age} years old"

# Creating objects (instances)
dog1 = Dog("Buddy", 3)
dog2 = Dog("Max", 5)

# Accessing attributes
print(dog1.name)  # Output: Buddy
print(dog2.age)   # Output: 5

# Calling methods
print(dog1.bark())      # Output: Buddy says Woof!
print(dog2.get_info())  # Output: Max is 5 years old

# Accessing class attribute
print(dog1.species)     # Output: Canis familiaris
```

## Key Concepts

### 1. Constructor (`__init__`)
- Special method called when creating a new object
- Initializes instance attributes
- Sets up the initial state of the object

### 2. Instance vs Class Attributes
- **Instance attributes**: Unique to each object (defined in `__init__`)
- **Class attributes**: Shared across all instances (defined at class level)

### 3. Instance Methods
- Functions defined inside a class
- Operate on instance data
- Have access to `self`

## Practice Exercise

Create a `Book` class with:
- Attributes: title, author, pages, current_page
- Methods: read(pages_read), get_progress(), is_finished()

Try implementing this before checking the solution!
