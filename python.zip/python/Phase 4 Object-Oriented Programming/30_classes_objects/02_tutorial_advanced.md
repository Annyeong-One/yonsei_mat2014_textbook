# Advanced Classes & Objects Concepts

## 1. Encapsulation

Encapsulation is about bundling data and methods together and controlling access to them.

### Public, Protected, and Private Attributes

```python
class BankAccount:
    def __init__(self, owner, balance):
        self.owner = owner              # Public
        self._account_id = "12345"      # Protected (convention)
        self.__balance = balance        # Private (name mangling)
    
    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            return True
        return False
    
    def get_balance(self):
        return self.__balance

account = BankAccount("Alice", 1000)
print(account.owner)           # OK: Public
print(account._account_id)     # Works but discouraged
# print(account.__balance)     # Error: Private attribute
print(account.get_balance())   # OK: Access via method
```

## 2. Class Methods and Static Methods

### Class Methods
- Use `@classmethod` decorator
- Receive class (cls) as first parameter
- Can access/modify class state

```python
class Employee:
    company = "TechCorp"
    employee_count = 0
    
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary
        Employee.employee_count += 1
    
    @classmethod
    def set_company(cls, new_company):
        cls.company = new_company
    
    @classmethod
    def from_string(cls, emp_string):
        # Alternative constructor
        name, salary = emp_string.split('-')
        return cls(name, int(salary))

emp1 = Employee.from_string("John-50000")
Employee.set_company("NewCorp")
```

### Static Methods
- Use `@staticmethod` decorator
- Don't receive self or cls
- Like regular functions but belong to class namespace

```python
class MathUtils:
    @staticmethod
    def is_even(num):
        return num % 2 == 0
    
    @staticmethod
    def factorial(n):
        if n <= 1:
            return 1
        return n * MathUtils.factorial(n - 1)

print(MathUtils.is_even(4))    # True
print(MathUtils.factorial(5))  # 120
```

## 3. Property Decorators

Properties allow you to add logic to attribute access while maintaining simple syntax.

```python
class Temperature:
    def __init__(self, celsius):
        self._celsius = celsius
    
    @property
    def celsius(self):
        """Getter for celsius"""
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        """Setter for celsius with validation"""
        if value < -273.15:
            raise ValueError("Temperature below absolute zero!")
        self._celsius = value
    
    @property
    def fahrenheit(self):
        """Computed property"""
        return (self._celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        self._celsius = (value - 32) * 5/9

temp = Temperature(25)
print(temp.celsius)        # 25
print(temp.fahrenheit)     # 77.0
temp.fahrenheit = 86       # Sets celsius to 30
print(temp.celsius)        # 30.0
```

## 4. Special Methods (Magic Methods/Dunder Methods)

### String Representation
```python
class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __str__(self):
        # User-friendly string (for print)
        return f"Point({self.x}, {self.y})"
    
    def __repr__(self):
        # Developer-friendly representation
        return f"Point(x={self.x}, y={self.y})"

p = Point(3, 4)
print(p)          # Uses __str__
print(repr(p))    # Uses __repr__
```

### Comparison Methods
```python
class Student:
    def __init__(self, name, grade):
        self.name = name
        self.grade = grade
    
    def __eq__(self, other):
        return self.grade == other.grade
    
    def __lt__(self, other):
        return self.grade < other.grade
    
    def __le__(self, other):
        return self.grade <= other.grade

s1 = Student("Alice", 85)
s2 = Student("Bob", 90)
print(s1 < s2)    # True
print(s1 == s2)   # False
```

### Arithmetic Operations
```python
class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    
    def __mul__(self, scalar):
        return Vector(self.x * scalar, self.y * scalar)
    
    def __str__(self):
        return f"Vector({self.x}, {self.y})"

v1 = Vector(1, 2)
v2 = Vector(3, 4)
v3 = v1 + v2
print(v3)  # Vector(4, 6)
print(v1 * 3)  # Vector(3, 6)
```

## 5. Composition vs Inheritance

### Composition (Has-A Relationship)
```python
class Engine:
    def __init__(self, horsepower):
        self.horsepower = horsepower
    
    def start(self):
        return "Engine started"

class Car:
    def __init__(self, model, horsepower):
        self.model = model
        self.engine = Engine(horsepower)  # Car HAS-A Engine
    
    def start(self):
        return f"{self.model}: {self.engine.start()}"

car = Car("Tesla Model 3", 283)
print(car.start())
```

## 6. Abstract Base Classes

```python
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass
    
    @abstractmethod
    def perimeter(self):
        pass

class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height
    
    def perimeter(self):
        return 2 * (self.width + self.height)

# shape = Shape()  # Error: Can't instantiate abstract class
rect = Rectangle(5, 3)
print(rect.area())  # 15
```

## Best Practices

1. **Single Responsibility Principle**: Each class should have one clear purpose
2. **Encapsulation**: Hide internal details, expose clean interfaces
3. **Meaningful Names**: Use descriptive class and method names
4. **Don't Repeat Yourself (DRY)**: Reuse code through methods and inheritance
5. **Favor Composition**: Use composition over inheritance when possible
6. **Keep Methods Small**: Each method should do one thing well

## Challenge Exercise

Design a library system with:
- `Book` class with title, author, ISBN, availability
- `Member` class with name, member_id, borrowed_books
- `Library` class that manages books and members
- Implement borrowing and returning functionality
- Add proper encapsulation and validation
