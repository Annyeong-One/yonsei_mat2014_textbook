# Classes & Objects Quick Reference

## Class Definition Syntax

```python
class ClassName:
    # Class attribute (shared by all instances)
    class_variable = "shared"
    
    def __init__(self, param1, param2):
        # Instance attributes (unique to each instance)
        self.attribute1 = param1
        self.attribute2 = param2
    
    def method(self):
        # Instance method
        return self.attribute1
```

## Creating and Using Objects

```python
# Create instance
obj = ClassName("value1", "value2")

# Access attributes
obj.attribute1

# Call methods
obj.method()

# Access class attribute
ClassName.class_variable
obj.class_variable
```

## Access Modifiers

```python
class Example:
    def __init__(self):
        self.public = "accessible everywhere"
        self._protected = "convention: internal use"
        self.__private = "name mangled"
```

## Properties

```python
class Circle:
    def __init__(self, radius):
        self._radius = radius
    
    @property
    def radius(self):
        """Getter"""
        return self._radius
    
    @radius.setter
    def radius(self, value):
        """Setter with validation"""
        if value < 0:
            raise ValueError("Radius must be positive")
        self._radius = value
    
    @property
    def area(self):
        """Computed property (read-only)"""
        return 3.14159 * self._radius ** 2
```

## Class Methods and Static Methods

```python
class MyClass:
    count = 0
    
    def __init__(self):
        MyClass.count += 1
    
    @classmethod
    def get_count(cls):
        """Access/modify class state"""
        return cls.count
    
    @staticmethod
    def utility_function(x):
        """Utility that doesn't need instance or class"""
        return x * 2
```

## Special Methods (Magic Methods)

### String Representation
```python
def __str__(self):
    """User-friendly string (print, str())"""
    return f"MyClass({self.value})"

def __repr__(self):
    """Developer-friendly representation"""
    return f"MyClass(value={self.value})"
```

### Comparison Operators
```python
def __eq__(self, other):    # ==
    return self.value == other.value

def __lt__(self, other):    # <
    return self.value < other.value

def __le__(self, other):    # <=
    return self.value <= other.value

def __gt__(self, other):    # >
    return self.value > other.value

def __ge__(self, other):    # >=
    return self.value >= other.value

def __ne__(self, other):    # !=
    return self.value != other.value
```

### Arithmetic Operators
```python
def __add__(self, other):      # +
    return MyClass(self.value + other.value)

def __sub__(self, other):      # -
    return MyClass(self.value - other.value)

def __mul__(self, other):      # *
    return MyClass(self.value * other.value)

def __truediv__(self, other):  # /
    return MyClass(self.value / other.value)

def __floordiv__(self, other): # //
    return MyClass(self.value // other.value)

def __mod__(self, other):      # %
    return MyClass(self.value % other.value)

def __pow__(self, other):      # **
    return MyClass(self.value ** other.value)
```

### Container Methods
```python
def __len__(self):
    """len(obj)"""
    return len(self.items)

def __getitem__(self, key):
    """obj[key]"""
    return self.items[key]

def __setitem__(self, key, value):
    """obj[key] = value"""
    self.items[key] = value

def __delitem__(self, key):
    """del obj[key]"""
    del self.items[key]

def __contains__(self, item):
    """item in obj"""
    return item in self.items

def __iter__(self):
    """for item in obj"""
    return iter(self.items)
```

### Other Useful Methods
```python
def __call__(self, *args):
    """Make instance callable: obj()"""
    return self.process(*args)

def __bool__(self):
    """bool(obj)"""
    return self.value != 0

def __abs__(self):
    """abs(obj)"""
    return abs(self.value)

def __hash__(self):
    """hash(obj) - for use in sets/dicts"""
    return hash(self.value)
```

## Context Managers

```python
class ResourceManager:
    def __enter__(self):
        """Setup - called when entering 'with' block"""
        self.resource = acquire_resource()
        return self.resource
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Cleanup - called when exiting 'with' block"""
        release_resource(self.resource)
        return False  # Don't suppress exceptions

# Usage
with ResourceManager() as resource:
    use(resource)
# Automatically cleaned up
```

## Inheritance

```python
class Parent:
    def __init__(self, value):
        self.value = value
    
    def method(self):
        return "Parent method"

class Child(Parent):
    def __init__(self, value, extra):
        super().__init__(value)  # Call parent constructor
        self.extra = extra
    
    def method(self):
        # Override parent method
        return "Child method"
    
    def parent_method(self):
        # Call parent's method
        return super().method()
```

## Composition

```python
class Engine:
    def start(self):
        return "Engine started"

class Car:
    def __init__(self):
        self.engine = Engine()  # Car HAS-A Engine
    
    def start(self):
        return self.engine.start()
```

## Abstract Base Classes

```python
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        """Must be implemented by subclasses"""
        pass
    
    @abstractmethod
    def perimeter(self):
        """Must be implemented by subclasses"""
        pass

class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius
    
    def area(self):
        return 3.14159 * self.radius ** 2
    
    def perimeter(self):
        return 2 * 3.14159 * self.radius
```

## Common Patterns

### Singleton Pattern
```python
class Singleton:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
```

### Factory Method
```python
class Animal:
    @classmethod
    def create(cls, animal_type):
        if animal_type == "dog":
            return Dog()
        elif animal_type == "cat":
            return Cat()
        raise ValueError(f"Unknown animal type: {animal_type}")
```

### Builder Pattern
```python
class Pizza:
    def __init__(self):
        self.size = None
        self.toppings = []
    
    def set_size(self, size):
        self.size = size
        return self  # Return self for chaining
    
    def add_topping(self, topping):
        self.toppings.append(topping)
        return self
    
    def build(self):
        return self

# Usage
pizza = Pizza().set_size("large").add_topping("cheese").add_topping("pepperoni").build()
```

## Best Practices Checklist

✅ **Class Design**
- [ ] Single Responsibility Principle (one purpose per class)
- [ ] Meaningful, descriptive class names (PascalCase)
- [ ] Keep classes focused and cohesive

✅ **Methods**
- [ ] Methods should do one thing well
- [ ] Use meaningful method names (snake_case)
- [ ] Keep methods short (<20 lines when possible)

✅ **Attributes**
- [ ] Use properties for validated access
- [ ] Make attributes private when appropriate
- [ ] Initialize all attributes in `__init__`

✅ **Documentation**
- [ ] Write docstrings for classes and methods
- [ ] Document parameters and return values
- [ ] Explain complex logic with comments

✅ **Code Quality**
- [ ] Follow PEP 8 style guide
- [ ] Don't Repeat Yourself (DRY)
- [ ] Test your classes thoroughly

## Common Mistakes to Avoid

❌ **Don't**: Forget `self` parameter
```python
def method():  # Wrong!
    return value
```
✅ **Do**: Always include `self`
```python
def method(self):  # Correct
    return self.value
```

❌ **Don't**: Modify mutable default arguments
```python
def __init__(self, items=[]):  # Wrong!
    self.items = items
```
✅ **Do**: Use None and create new instance
```python
def __init__(self, items=None):  # Correct
    self.items = items if items is not None else []
```

❌ **Don't**: Use class attributes for mutable data
```python
class MyClass:
    items = []  # Shared across all instances!
```
✅ **Do**: Use instance attributes
```python
class MyClass:
    def __init__(self):
        self.items = []  # Unique to each instance
```

## Quick Tips

💡 **Choosing Between Class and Instance Methods**
- Instance method: Needs access to instance data
- Class method: Needs access to class data or alternative constructors
- Static method: Utility function related to class

💡 **Composition vs Inheritance**
- Inheritance: "is-a" relationship (Dog is-a Animal)
- Composition: "has-a" relationship (Car has-a Engine)
- Prefer composition when possible

💡 **When to Use Properties**
- Need validation when setting values
- Want computed/derived values
- Need to maintain compatibility while refactoring

💡 **Testing Classes**
```python
# Create instances with different values
# Test methods with various inputs
# Verify attributes are set correctly
# Check edge cases and error conditions
```

## Keyboard Shortcuts for Common Tasks

**Creating a new class:**
```python
class ClassName:
    def __init__(self):
        pass
```

**Adding a property:**
```python
@property
def attribute(self):
    return self._attribute

@attribute.setter
def attribute(self, value):
    self._attribute = value
```

**Implementing comparison:**
```python
def __eq__(self, other):
    return self.key_attribute == other.key_attribute

def __lt__(self, other):
    return self.key_attribute < other.key_attribute
```

---

**Remember:** Practice is key! Refer to this guide when writing classes, and soon these patterns will become second nature.
