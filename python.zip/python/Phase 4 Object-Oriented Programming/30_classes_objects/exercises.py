"""
Classes & Objects - Practice Exercises

Complete these exercises to practice your OOP skills.
Solutions are provided in the 'solutions' folder.
"""

# Exercise 1: Basic Class Creation
print("Exercise 1: Book Class")
print("-" * 40)
"""
Create a Book class with the following:

Attributes:
- title (string)
- author (string)
- pages (integer)
- current_page (integer, starts at 0)

Methods:
- read(num_pages): Advances current_page by num_pages (don't exceed total pages)
- get_progress(): Returns percentage of book completed
- is_finished(): Returns True if current_page >= pages
- __str__(): Returns "Title by Author (X% complete)"

Test your class with at least 2 book objects.
"""

# YOUR CODE HERE


# Exercise 2: Rectangle Class with Validation
print("\nExercise 2: Rectangle with Validation")
print("-" * 40)
"""
Create a Rectangle class with the following:

Attributes (use properties with validation):
- width (must be positive)
- height (must be positive)

Methods:
- area(): Returns width * height
- perimeter(): Returns 2 * (width + height)
- scale(factor): Multiplies both dimensions by factor
- is_square(): Returns True if width == height
- __str__(): Returns "Rectangle(WxH)"

Raise ValueError if trying to set negative dimensions.
"""

# YOUR CODE HERE


# Exercise 3: Bank Account System
print("\nExercise 3: Bank Account System")
print("-" * 40)
"""
Create a BankAccount class with the following:

Attributes:
- account_number (string)
- owner (string)
- balance (float, private, starts at 0)
- transaction_history (list, private)

Methods:
- deposit(amount): Adds to balance, records transaction
- withdraw(amount): Subtracts from balance if sufficient funds, records transaction
- get_balance(): Returns current balance
- get_transactions(): Returns list of all transactions
- transfer(amount, other_account): Transfers money to another account
- __str__(): Returns "Account XXXX: $YYY.YY"

Add validation (no negative amounts, sufficient funds for withdrawals).
"""

# YOUR CODE HERE


# Exercise 4: Student Grade Tracker
print("\nExercise 4: Student Grade Tracker")
print("-" * 40)
"""
Create a Student class with the following:

Class attribute:
- passing_grade = 60

Instance attributes:
- name (string)
- student_id (string)
- grades (dictionary: subject -> list of grades)

Methods:
- add_grade(subject, grade): Adds grade to subject (create subject if needed)
- get_average(subject): Returns average for a subject
- get_overall_average(): Returns average across all subjects
- is_passing(subject): Returns True if average >= passing_grade
- get_report_card(): Returns formatted string with all subjects and averages
- __str__(): Returns "Student: Name (ID: XXX)"

Class method:
- set_passing_grade(grade): Sets the class-wide passing grade
"""

# YOUR CODE HERE


# Exercise 5: Temperature Converter
print("\nExercise 5: Temperature Converter")
print("-" * 40)
"""
Create a Temperature class with the following:

Attributes:
- celsius (property with setter that validates >= -273.15)

Computed properties:
- fahrenheit: Converts celsius to fahrenheit (read and write)
- kelvin: Converts celsius to kelvin (read and write)

Methods:
- __str__(): Returns "XX.X°C / YY.Y°F / ZZ.Z K"
- __eq__(other): Compares temperatures (same if celsius values equal)
- __lt__(other): Returns True if this temperature < other

Formulas:
- F = (C * 9/5) + 32
- K = C + 273.15
"""

# YOUR CODE HERE


# Exercise 6: Shopping Cart System
print("\nExercise 6: Shopping Cart System")
print("-" * 40)
"""
Create two classes:

Product class:
- name (string)
- price (float)
- category (string)
- __str__(): Returns "Name ($X.XX)"

ShoppingCart class:
- items (list of dicts: {'product': Product, 'quantity': int})

Methods:
- add_item(product, quantity=1): Adds product to cart
- remove_item(product_name): Removes product from cart
- update_quantity(product_name, new_quantity): Updates item quantity
- get_total(): Returns total price
- get_item_count(): Returns total number of items
- get_items_by_category(category): Returns list of products in category
- apply_discount(percentage): Reduces all prices by percentage
- clear(): Empties the cart
- __str__(): Returns formatted cart summary
"""

# YOUR CODE HERE


# Exercise 7: Time Class
print("\nExercise 7: Time Class with Operators")
print("-" * 40)
"""
Create a Time class with the following:

Attributes:
- hours (0-23)
- minutes (0-59)
- seconds (0-59)

Methods:
- __str__(): Returns "HH:MM:SS" format
- __add__(other): Adds two times together
- __sub__(other): Returns difference in seconds
- add_seconds(seconds): Adds seconds to time
- to_seconds(): Returns total seconds since midnight
- is_am(): Returns True if before noon
- is_pm(): Returns True if after noon

Handle overflow (e.g., 23:59:59 + 2 seconds = 00:00:01)
"""

# YOUR CODE HERE


# Exercise 8: Library Management System
print("\nExercise 8: Library Management System")
print("-" * 40)
"""
Create a library system with three classes:

Book class:
- title, author, isbn
- is_available (boolean)

Member class:
- name, member_id
- borrowed_books (list of Book objects)
- max_books = 3 (class attribute)

Library class:
- name
- books (list of Book objects)
- members (list of Member objects)

Methods for Library:
- add_book(book): Adds book to library
- add_member(member): Adds member to library
- find_book(title): Returns Book object or None
- borrow_book(member_id, isbn): Handles book borrowing
- return_book(member_id, isbn): Handles book returning
- get_available_books(): Returns list of available books
- get_member_books(member_id): Returns books borrowed by member

Add proper validation and error handling.
"""

# YOUR CODE HERE


# Exercise 9: Vector Math
print("\nExercise 9: 3D Vector Class")
print("-" * 40)
"""
Create a Vector3D class with the following:

Attributes:
- x, y, z (float)

Methods:
- __str__(): Returns "(x, y, z)"
- __add__(other): Vector addition
- __sub__(other): Vector subtraction
- __mul__(scalar): Scalar multiplication
- dot(other): Dot product
- cross(other): Cross product
- magnitude(): Returns length of vector
- normalize(): Returns unit vector
- __eq__(other): Checks if vectors are equal
- __getitem__(index): Access by index (0=x, 1=y, 2=z)

Formulas:
- dot product: x1*x2 + y1*y2 + z1*z2
- cross product: (y1*z2-z1*y2, z1*x2-x1*z2, x1*y2-y1*x2)
- magnitude: sqrt(x² + y² + z²)
"""

# YOUR CODE HERE


# Exercise 10: Custom Container
print("\nExercise 10: Playlist Manager")
print("-" * 40)
"""
Create a playlist system with two classes:

Song class:
- title, artist, duration (in seconds)
- __str__(): Returns "Title by Artist (M:SS)"

Playlist class:
- name
- songs (list of Song objects)

Methods:
- add_song(song): Adds song to playlist
- remove_song(title): Removes song by title
- get_total_duration(): Returns total playlist duration
- get_song_count(): Returns number of songs
- shuffle(): Randomly reorders songs
- __len__(): Returns number of songs
- __getitem__(index): Access song by index
- __iter__(): Makes playlist iterable
- __str__(): Returns formatted playlist info

Make the Playlist iterable so you can use:
for song in playlist:
    print(song)
"""

# YOUR CODE HERE


print("\n" + "=" * 60)
print("Complete all exercises and check your solutions!")
print("Run the solution file to see one possible implementation.")
print("=" * 60)
