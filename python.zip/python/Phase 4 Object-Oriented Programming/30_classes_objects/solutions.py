"""
Classes & Objects - Exercise Solutions

These are example solutions. Your solutions may differ but should
meet the same requirements.
"""

# Exercise 1: Book Class
print("Exercise 1: Book Class - Solution")
print("-" * 40)

class Book:
    def __init__(self, title, author, pages):
        self.title = title
        self.author = author
        self.pages = pages
        self.current_page = 0
    
    def read(self, num_pages):
        self.current_page = min(self.current_page + num_pages, self.pages)
        return f"Read {num_pages} pages. Now on page {self.current_page}"
    
    def get_progress(self):
        if self.pages == 0:
            return 0
        return (self.current_page / self.pages) * 100
    
    def is_finished(self):
        return self.current_page >= self.pages
    
    def __str__(self):
        return f"{self.title} by {self.author} ({self.get_progress():.1f}% complete)"

# Test
book1 = Book("1984", "George Orwell", 328)
book2 = Book("The Hobbit", "J.R.R. Tolkien", 310)

print(book1)
print(book1.read(100))
print(book1)
print(f"Finished? {book1.is_finished()}")
book1.read(300)
print(book1)
print(f"Finished? {book1.is_finished()}")
print()


# Exercise 2: Rectangle Class
print("\nExercise 2: Rectangle with Validation - Solution")
print("-" * 40)

class Rectangle:
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    @property
    def width(self):
        return self._width
    
    @width.setter
    def width(self, value):
        if value <= 0:
            raise ValueError("Width must be positive")
        self._width = value
    
    @property
    def height(self):
        return self._height
    
    @height.setter
    def height(self, value):
        if value <= 0:
            raise ValueError("Height must be positive")
        self._height = value
    
    def area(self):
        return self._width * self._height
    
    def perimeter(self):
        return 2 * (self._width + self._height)
    
    def scale(self, factor):
        self._width *= factor
        self._height *= factor
    
    def is_square(self):
        return self._width == self._height
    
    def __str__(self):
        return f"Rectangle({self._width}x{self._height})"

# Test
rect = Rectangle(5, 3)
print(rect)
print(f"Area: {rect.area()}")
print(f"Perimeter: {rect.perimeter()}")
print(f"Is square? {rect.is_square()}")
rect.scale(2)
print(f"After scaling: {rect}")

try:
    rect.width = -5
except ValueError as e:
    print(f"Error: {e}")
print()


# Exercise 3: Bank Account System
print("\nExercise 3: Bank Account System - Solution")
print("-" * 40)

class BankAccount:
    def __init__(self, account_number, owner):
        self.account_number = account_number
        self.owner = owner
        self.__balance = 0.0
        self.__transaction_history = []
    
    def deposit(self, amount):
        if amount <= 0:
            return "Amount must be positive"
        self.__balance += amount
        self.__transaction_history.append(f"Deposit: +${amount:.2f}")
        return f"Deposited ${amount:.2f}. Balance: ${self.__balance:.2f}"
    
    def withdraw(self, amount):
        if amount <= 0:
            return "Amount must be positive"
        if amount > self.__balance:
            return "Insufficient funds"
        self.__balance -= amount
        self.__transaction_history.append(f"Withdrawal: -${amount:.2f}")
        return f"Withdrew ${amount:.2f}. Balance: ${self.__balance:.2f}"
    
    def get_balance(self):
        return self.__balance
    
    def get_transactions(self):
        return self.__transaction_history.copy()
    
    def transfer(self, amount, other_account):
        if amount <= 0:
            return "Amount must be positive"
        if amount > self.__balance:
            return "Insufficient funds for transfer"
        
        self.__balance -= amount
        other_account.deposit(amount)
        self.__transaction_history.append(f"Transfer to {other_account.account_number}: -${amount:.2f}")
        return f"Transferred ${amount:.2f} to account {other_account.account_number}"
    
    def __str__(self):
        return f"Account {self.account_number}: ${self.__balance:.2f}"

# Test
acc1 = BankAccount("001", "Alice")
acc2 = BankAccount("002", "Bob")

print(acc1.deposit(1000))
print(acc1.withdraw(200))
print(acc1.transfer(300, acc2))
print(acc1)
print(acc2)
print(f"Transactions: {acc1.get_transactions()}")
print()


# Exercise 4: Student Grade Tracker
print("\nExercise 4: Student Grade Tracker - Solution")
print("-" * 40)

class Student:
    passing_grade = 60
    
    def __init__(self, name, student_id):
        self.name = name
        self.student_id = student_id
        self.grades = {}
    
    def add_grade(self, subject, grade):
        if subject not in self.grades:
            self.grades[subject] = []
        self.grades[subject].append(grade)
        return f"Added grade {grade} for {subject}"
    
    def get_average(self, subject):
        if subject not in self.grades or not self.grades[subject]:
            return 0
        return sum(self.grades[subject]) / len(self.grades[subject])
    
    def get_overall_average(self):
        if not self.grades:
            return 0
        all_grades = []
        for subject_grades in self.grades.values():
            all_grades.extend(subject_grades)
        return sum(all_grades) / len(all_grades) if all_grades else 0
    
    def is_passing(self, subject):
        return self.get_average(subject) >= Student.passing_grade
    
    def get_report_card(self):
        report = f"\n--- Report Card for {self.name} ---\n"
        for subject in sorted(self.grades.keys()):
            avg = self.get_average(subject)
            status = "PASS" if self.is_passing(subject) else "FAIL"
            report += f"{subject}: {avg:.2f} ({status})\n"
        report += f"Overall Average: {self.get_overall_average():.2f}\n"
        return report
    
    @classmethod
    def set_passing_grade(cls, grade):
        cls.passing_grade = grade
    
    def __str__(self):
        return f"Student: {self.name} (ID: {self.student_id})"

# Test
student = Student("Alice", "S001")
print(student)
print(student.add_grade("Math", 85))
print(student.add_grade("Math", 90))
print(student.add_grade("Science", 75))
print(student.add_grade("History", 55))
print(student.get_report_card())
Student.set_passing_grade(70)
print("After changing passing grade to 70:")
print(student.get_report_card())
print()


# Exercise 5: Temperature Converter
print("\nExercise 5: Temperature Converter - Solution")
print("-" * 40)

class Temperature:
    def __init__(self, celsius):
        self.celsius = celsius
    
    @property
    def celsius(self):
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        if value < -273.15:
            raise ValueError("Temperature cannot be below absolute zero (-273.15°C)")
        self._celsius = value
    
    @property
    def fahrenheit(self):
        return (self._celsius * 9/5) + 32
    
    @fahrenheit.setter
    def fahrenheit(self, value):
        self.celsius = (value - 32) * 5/9
    
    @property
    def kelvin(self):
        return self._celsius + 273.15
    
    @kelvin.setter
    def kelvin(self, value):
        self.celsius = value - 273.15
    
    def __str__(self):
        return f"{self._celsius:.1f}°C / {self.fahrenheit:.1f}°F / {self.kelvin:.1f} K"
    
    def __eq__(self, other):
        return abs(self._celsius - other._celsius) < 0.01
    
    def __lt__(self, other):
        return self._celsius < other._celsius

# Test
temp1 = Temperature(25)
print(temp1)
temp1.fahrenheit = 86
print(f"After setting F to 86: {temp1}")
temp2 = Temperature(30)
print(f"temp1 < temp2: {temp1 < temp2}")
print()


# Exercise 6: Shopping Cart System
print("\nExercise 6: Shopping Cart System - Solution")
print("-" * 40)

class Product:
    def __init__(self, name, price, category):
        self.name = name
        self.price = price
        self.category = category
    
    def __str__(self):
        return f"{self.name} (${self.price:.2f})"

class ShoppingCart:
    def __init__(self):
        self.items = []
    
    def add_item(self, product, quantity=1):
        # Check if product already in cart
        for item in self.items:
            if item['product'].name == product.name:
                item['quantity'] += quantity
                return f"Added {quantity} more {product.name}(s)"
        
        self.items.append({'product': product, 'quantity': quantity})
        return f"Added {quantity} {product.name}(s) to cart"
    
    def remove_item(self, product_name):
        for i, item in enumerate(self.items):
            if item['product'].name == product_name:
                self.items.pop(i)
                return f"Removed {product_name} from cart"
        return "Product not found in cart"
    
    def update_quantity(self, product_name, new_quantity):
        if new_quantity <= 0:
            return self.remove_item(product_name)
        
        for item in self.items:
            if item['product'].name == product_name:
                item['quantity'] = new_quantity
                return f"Updated {product_name} quantity to {new_quantity}"
        return "Product not found in cart"
    
    def get_total(self):
        return sum(item['product'].price * item['quantity'] for item in self.items)
    
    def get_item_count(self):
        return sum(item['quantity'] for item in self.items)
    
    def get_items_by_category(self, category):
        return [item['product'] for item in self.items 
                if item['product'].category == category]
    
    def apply_discount(self, percentage):
        for item in self.items:
            item['product'].price *= (1 - percentage / 100)
        return f"Applied {percentage}% discount"
    
    def clear(self):
        self.items = []
        return "Cart cleared"
    
    def __str__(self):
        if not self.items:
            return "Shopping Cart: Empty"
        
        result = "\n--- Shopping Cart ---\n"
        for item in self.items:
            product = item['product']
            quantity = item['quantity']
            subtotal = product.price * quantity
            result += f"{quantity}x {product} = ${subtotal:.2f}\n"
        result += f"\nTotal Items: {self.get_item_count()}"
        result += f"\nTotal Cost: ${self.get_total():.2f}\n"
        return result

# Test
cart = ShoppingCart()
laptop = Product("Laptop", 999.99, "Electronics")
mouse = Product("Mouse", 29.99, "Electronics")
book = Product("Python Book", 39.99, "Books")

print(cart.add_item(laptop, 1))
print(cart.add_item(mouse, 2))
print(cart.add_item(book, 1))
print(cart)
print(cart.apply_discount(10))
print(cart)
print()


# Exercise 7: Time Class
print("\nExercise 7: Time Class with Operators - Solution")
print("-" * 40)

class Time:
    def __init__(self, hours=0, minutes=0, seconds=0):
        # Normalize time
        total_seconds = hours * 3600 + minutes * 60 + seconds
        total_seconds = total_seconds % 86400  # 86400 seconds in a day
        
        self.hours = total_seconds // 3600
        self.minutes = (total_seconds % 3600) // 60
        self.seconds = total_seconds % 60
    
    def __str__(self):
        return f"{self.hours:02d}:{self.minutes:02d}:{self.seconds:02d}"
    
    def __add__(self, other):
        total_secs = self.to_seconds() + other.to_seconds()
        return Time(seconds=total_secs)
    
    def __sub__(self, other):
        diff = self.to_seconds() - other.to_seconds()
        return diff  # Return difference in seconds
    
    def add_seconds(self, seconds):
        total = self.to_seconds() + seconds
        return Time(seconds=total)
    
    def to_seconds(self):
        return self.hours * 3600 + self.minutes * 60 + self.seconds
    
    def is_am(self):
        return self.hours < 12
    
    def is_pm(self):
        return self.hours >= 12

# Test
time1 = Time(10, 30, 45)
time2 = Time(2, 15, 30)
print(f"Time 1: {time1}")
print(f"Time 2: {time2}")
print(f"Time 1 + Time 2: {time1 + time2}")
print(f"Difference in seconds: {time1 - time2}")
print(f"Time 1 is AM: {time1.is_am()}")
time3 = time1.add_seconds(7200)
print(f"Time 1 + 2 hours: {time3}")
print()


# Exercise 8: Library Management System
print("\nExercise 8: Library Management System - Solution")
print("-" * 40)

class Book:
    def __init__(self, title, author, isbn):
        self.title = title
        self.author = author
        self.isbn = isbn
        self.is_available = True
    
    def __str__(self):
        status = "Available" if self.is_available else "Borrowed"
        return f"{self.title} by {self.author} ({status})"

class Member:
    max_books = 3
    
    def __init__(self, name, member_id):
        self.name = name
        self.member_id = member_id
        self.borrowed_books = []
    
    def can_borrow(self):
        return len(self.borrowed_books) < Member.max_books
    
    def __str__(self):
        return f"Member: {self.name} (ID: {self.member_id})"

class Library:
    def __init__(self, name):
        self.name = name
        self.books = []
        self.members = []
    
    def add_book(self, book):
        self.books.append(book)
        return f"Added '{book.title}' to library"
    
    def add_member(self, member):
        self.members.append(member)
        return f"Added member {member.name}"
    
    def find_book(self, title):
        for book in self.books:
            if book.title.lower() == title.lower():
                return book
        return None
    
    def find_member(self, member_id):
        for member in self.members:
            if member.member_id == member_id:
                return member
        return None
    
    def borrow_book(self, member_id, isbn):
        member = self.find_member(member_id)
        if not member:
            return "Member not found"
        
        if not member.can_borrow():
            return f"{member.name} has reached borrowing limit"
        
        for book in self.books:
            if book.isbn == isbn:
                if not book.is_available:
                    return f"'{book.title}' is not available"
                
                book.is_available = False
                member.borrowed_books.append(book)
                return f"{member.name} borrowed '{book.title}'"
        
        return "Book not found"
    
    def return_book(self, member_id, isbn):
        member = self.find_member(member_id)
        if not member:
            return "Member not found"
        
        for book in member.borrowed_books:
            if book.isbn == isbn:
                book.is_available = True
                member.borrowed_books.remove(book)
                return f"{member.name} returned '{book.title}'"
        
        return "Book not found in member's borrowed books"
    
    def get_available_books(self):
        return [book for book in self.books if book.is_available]
    
    def get_member_books(self, member_id):
        member = self.find_member(member_id)
        if not member:
            return []
        return member.borrowed_books

# Test
library = Library("City Library")
book1 = Book("1984", "George Orwell", "ISBN001")
book2 = Book("The Hobbit", "J.R.R. Tolkien", "ISBN002")
member1 = Member("Alice", "M001")

print(library.add_book(book1))
print(library.add_book(book2))
print(library.add_member(member1))
print(library.borrow_book("M001", "ISBN001"))
print(f"Available books: {len(library.get_available_books())}")
print(library.return_book("M001", "ISBN001"))
print(f"Available books: {len(library.get_available_books())}")
print()


# Exercise 9: 3D Vector Class
print("\nExercise 9: 3D Vector Class - Solution")
print("-" * 40)

import math

class Vector3D:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    
    def __str__(self):
        return f"({self.x}, {self.y}, {self.z})"
    
    def __add__(self, other):
        return Vector3D(self.x + other.x, self.y + other.y, self.z + other.z)
    
    def __sub__(self, other):
        return Vector3D(self.x - other.x, self.y - other.y, self.z - other.z)
    
    def __mul__(self, scalar):
        return Vector3D(self.x * scalar, self.y * scalar, self.z * scalar)
    
    def dot(self, other):
        return self.x * other.x + self.y * other.y + self.z * other.z
    
    def cross(self, other):
        return Vector3D(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x
        )
    
    def magnitude(self):
        return math.sqrt(self.x**2 + self.y**2 + self.z**2)
    
    def normalize(self):
        mag = self.magnitude()
        if mag == 0:
            return Vector3D(0, 0, 0)
        return Vector3D(self.x / mag, self.y / mag, self.z / mag)
    
    def __eq__(self, other):
        return (abs(self.x - other.x) < 0.001 and
                abs(self.y - other.y) < 0.001 and
                abs(self.z - other.z) < 0.001)
    
    def __getitem__(self, index):
        if index == 0:
            return self.x
        elif index == 1:
            return self.y
        elif index == 2:
            return self.z
        raise IndexError("Vector3D index out of range")

# Test
v1 = Vector3D(1, 2, 3)
v2 = Vector3D(4, 5, 6)
print(f"v1: {v1}")
print(f"v2: {v2}")
print(f"v1 + v2: {v1 + v2}")
print(f"v1 - v2: {v1 - v2}")
print(f"v1 * 2: {v1 * 2}")
print(f"v1 · v2: {v1.dot(v2)}")
print(f"v1 × v2: {v1.cross(v2)}")
print(f"|v1|: {v1.magnitude():.3f}")
print(f"v1 normalized: {v1.normalize()}")
print()


# Exercise 10: Playlist Manager
print("\nExercise 10: Playlist Manager - Solution")
print("-" * 40)

import random

class Song:
    def __init__(self, title, artist, duration):
        self.title = title
        self.artist = artist
        self.duration = duration
    
    def __str__(self):
        minutes = self.duration // 60
        seconds = self.duration % 60
        return f"{self.title} by {self.artist} ({minutes}:{seconds:02d})"

class Playlist:
    def __init__(self, name):
        self.name = name
        self.songs = []
    
    def add_song(self, song):
        self.songs.append(song)
        return f"Added '{song.title}' to playlist"
    
    def remove_song(self, title):
        for i, song in enumerate(self.songs):
            if song.title.lower() == title.lower():
                removed = self.songs.pop(i)
                return f"Removed '{removed.title}' from playlist"
        return "Song not found"
    
    def get_total_duration(self):
        return sum(song.duration for song in self.songs)
    
    def get_song_count(self):
        return len(self.songs)
    
    def shuffle(self):
        random.shuffle(self.songs)
        return "Playlist shuffled"
    
    def __len__(self):
        return len(self.songs)
    
    def __getitem__(self, index):
        return self.songs[index]
    
    def __iter__(self):
        return iter(self.songs)
    
    def __str__(self):
        total_duration = self.get_total_duration()
        minutes = total_duration // 60
        seconds = total_duration % 60
        
        result = f"\n--- Playlist: {self.name} ---\n"
        result += f"Songs: {len(self.songs)}\n"
        result += f"Total Duration: {minutes}:{seconds:02d}\n\n"
        
        for i, song in enumerate(self.songs, 1):
            result += f"{i}. {song}\n"
        
        return result

# Test
playlist = Playlist("My Favorites")
song1 = Song("Bohemian Rhapsody", "Queen", 354)
song2 = Song("Stairway to Heaven", "Led Zeppelin", 482)
song3 = Song("Hotel California", "Eagles", 391)

print(playlist.add_song(song1))
print(playlist.add_song(song2))
print(playlist.add_song(song3))
print(playlist)

print("Iterating through playlist:")
for song in playlist:
    print(f"  - {song}")

print(f"\nAccessing by index: {playlist[1]}")
print(f"Playlist length: {len(playlist)}")
print()

print("\n" + "=" * 60)
print("All exercises completed!")
print("=" * 60)
