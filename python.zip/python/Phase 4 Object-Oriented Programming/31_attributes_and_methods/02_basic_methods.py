"""
02: Basic Methods in Python

Methods are functions defined inside a class.
They define the behavior of objects.
"""

# Example 1: Basic instance methods
class Dog:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    # Instance method - operates on instance data
    def bark(self):
        return f"{self.name} says: Woof! Woof!"
    
    def get_info(self):
        return f"{self.name} is {self.age} years old"
    
    def have_birthday(self):
        self.age += 1
        return f"Happy birthday {self.name}! Now {self.age} years old!"

dog = Dog("Buddy", 3)
print(dog.bark())
print(dog.get_info())
print(dog.have_birthday())
print(dog.get_info())


# Example 2: Methods with parameters
class Calculator:
    def __init__(self, name):
        self.name = name
        self.history = []
    
    def add(self, a, b):
        result = a + b
        self.history.append(f"{a} + {b} = {result}")
        return result
    
    def subtract(self, a, b):
        result = a - b
        self.history.append(f"{a} - {b} = {result}")
        return result
    
    def multiply(self, a, b):
        result = a * b
        self.history.append(f"{a} × {b} = {result}")
        return result
    
    def show_history(self):
        print(f"\n{self.name} Calculation History:")
        for calculation in self.history:
            print(f"  - {calculation}")

calc = Calculator("My Calculator")
print(f"\n10 + 5 = {calc.add(10, 5)}")
print(f"10 - 5 = {calc.subtract(10, 5)}")
print(f"10 × 5 = {calc.multiply(10, 5)}")
calc.show_history()


# Example 3: Methods that modify object state
class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance
        self.transactions = []
    
    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            self.transactions.append(f"Deposit: +${amount}")
            return f"Deposited ${amount}. New balance: ${self.balance}"
        return "Invalid deposit amount"
    
    def withdraw(self, amount):
        if amount > self.balance:
            return "Insufficient funds"
        if amount > 0:
            self.balance -= amount
            self.transactions.append(f"Withdrawal: -${amount}")
            return f"Withdrew ${amount}. New balance: ${self.balance}"
        return "Invalid withdrawal amount"
    
    def get_balance(self):
        return f"{self.owner}'s balance: ${self.balance}"
    
    def print_statement(self):
        print(f"\n--- Account Statement for {self.owner} ---")
        print(f"Current Balance: ${self.balance}")
        print("Recent Transactions:")
        for transaction in self.transactions:
            print(f"  {transaction}")

account = BankAccount("Alice Johnson", 1000)
print(account.get_balance())
print(account.deposit(500))
print(account.withdraw(200))
print(account.deposit(100))
account.print_statement()


# Example 4: Methods calling other methods
class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width
    
    def area(self):
        return self.length * self.width
    
    def perimeter(self):
        return 2 * (self.length + self.width)
    
    def is_square(self):
        return self.length == self.width
    
    def describe(self):
        # This method calls other methods
        shape_type = "square" if self.is_square() else "rectangle"
        return f"This {shape_type} has:\n  Area: {self.area()}\n  Perimeter: {self.perimeter()}"

rect = Rectangle(5, 3)
print(f"\n{rect.describe()}")

square = Rectangle(4, 4)
print(f"\n{square.describe()}")


# Example 5: The importance of 'self'
class Counter:
    def __init__(self):
        self.count = 0
    
    def increment(self):
        # 'self' refers to the specific instance
        self.count += 1
    
    def decrement(self):
        self.count -= 1
    
    def get_count(self):
        return self.count

# Each counter has its own count
counter1 = Counter()
counter2 = Counter()

counter1.increment()
counter1.increment()
counter1.increment()

counter2.increment()

print(f"\nCounter 1: {counter1.get_count()}")
print(f"Counter 2: {counter2.get_count()}")


# Key Takeaways:
# 1. Methods are functions defined inside a class
# 2. First parameter is always 'self' (refers to the instance)
# 3. Methods can access and modify instance attributes
# 4. Methods can accept parameters just like regular functions
# 5. Methods can call other methods using self.method_name()
# 6. Methods define the behavior/actions of objects
