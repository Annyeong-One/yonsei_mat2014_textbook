"""
04: Access Modifiers (Public, Private, Protected)

Python doesn't have strict access control like Java/C++, but uses naming conventions:
- public: regular name (e.g., name)
- protected: single underscore (e.g., _name)
- private: double underscore (e.g., __name)
"""

# Example 1: Public attributes and methods
class PublicExample:
    def __init__(self):
        # Public attribute - accessible from anywhere
        self.public_data = "I am public"
    
    # Public method - accessible from anywhere
    def public_method(self):
        return "This is a public method"

obj = PublicExample()
print("PUBLIC ACCESS:")
print(f"Attribute: {obj.public_data}")
print(f"Method: {obj.public_method()}")


# Example 2: Protected members (single underscore)
class BankAccount:
    def __init__(self, owner, balance):
        self.owner = owner          # Public
        self._balance = balance     # Protected (convention: internal use)
        self._transaction_fee = 2   # Protected
    
    def deposit(self, amount):
        if amount > 0:
            self._balance += amount
            return f"Deposited ${amount}"
        return "Invalid amount"
    
    def withdraw(self, amount):
        total_cost = amount + self._transaction_fee
        if total_cost <= self._balance:
            self._balance -= total_cost
            return f"Withdrew ${amount} (Fee: ${self._transaction_fee})"
        return "Insufficient funds"
    
    def get_balance(self):
        # Public method to access protected attribute
        return f"Balance: ${self._balance}"
    
    def _apply_interest(self, rate):
        # Protected method (internal use)
        self._balance *= (1 + rate)

account = BankAccount("Alice", 1000)
print("\n" + "="*50)
print("PROTECTED ACCESS:")
print(account.get_balance())
print(account.deposit(500))

# You CAN still access protected members (Python doesn't prevent it)
# But by convention, you shouldn't
print(f"Direct access (not recommended): {account._balance}")
account._apply_interest(0.05)  # Accessing protected method
print(f"After interest: {account.get_balance()}")


# Example 3: Private members (double underscore)
class SecureVault:
    def __init__(self, pin):
        self.__pin = pin  # Private attribute (name mangling)
        self.__balance = 0
        self.owner = "Vault Owner"  # Public
    
    def verify_pin(self, pin):
        return pin == self.__pin
    
    def __encrypt_data(self, data):
        # Private method
        return f"encrypted_{data}_secure"
    
    def store_data(self, data, pin):
        if self.verify_pin(pin):
            encrypted = self.__encrypt_data(data)
            return f"Data stored: {encrypted}"
        return "Invalid PIN"
    
    def change_pin(self, old_pin, new_pin):
        if self.verify_pin(old_pin):
            self.__pin = new_pin
            return "PIN changed successfully"
        return "Invalid PIN"

vault = SecureVault("1234")
print("\n" + "="*50)
print("PRIVATE ACCESS:")
print(vault.store_data("secret info", "1234"))

# Trying to access private attribute directly won't work
try:
    print(vault.__pin)
except AttributeError as e:
    print(f"Cannot access private attribute: {e}")

# Python uses name mangling for private attributes
# They're actually renamed to _ClassName__attribute
print(f"Name mangling allows this (not recommended): {vault._SecureVault__pin}")


# Example 4: Real-world example combining all three
class Employee:
    # Class attribute (public)
    company = "TechCorp"
    
    def __init__(self, name, salary, ssn):
        # Public attribute
        self.name = name
        
        # Protected attribute (internal use, but accessible)
        self._department = "General"
        self._salary = salary
        
        # Private attribute (sensitive data)
        self.__ssn = ssn
    
    # Public method
    def get_info(self):
        return f"{self.name} works at {self.company}"
    
    # Protected method
    def _calculate_bonus(self):
        return self._salary * 0.10
    
    # Private method
    def __validate_ssn(self):
        return len(str(self.__ssn)) == 9
    
    # Public method that uses private method
    def is_valid_employee(self):
        return self.__validate_ssn()
    
    # Public method providing controlled access to protected data
    def get_salary_info(self):
        bonus = self._calculate_bonus()
        return f"Salary: ${self._salary}, Bonus: ${bonus}"
    
    # Setter method with validation
    def set_department(self, dept):
        allowed_depts = ["Engineering", "Sales", "HR", "General"]
        if dept in allowed_depts:
            self._department = dept
            return True
        return False

emp = Employee("John Doe", 75000, 123456789)

print("\n" + "="*50)
print("COMBINED EXAMPLE:")
print(emp.get_info())  # Public method
print(emp.get_salary_info())  # Accessing protected data through public method
print(f"Valid employee: {emp.is_valid_employee()}")  # Uses private method internally

# Public attribute - direct access
print(f"Name (public): {emp.name}")

# Protected attribute - accessible but not recommended
print(f"Department (protected): {emp._department}")

# Private attribute - not directly accessible
try:
    print(emp.__ssn)
except AttributeError:
    print("Cannot access private SSN directly (good!)")


# Example 5: Property-based access (better approach)
class BetterBankAccount:
    def __init__(self, owner, balance):
        self.owner = owner
        self.__balance = balance  # Private
    
    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount
            return True
        return False
    
    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount
            return True
        return False
    
    def get_balance(self):
        """Read-only access to balance"""
        return self.__balance

account = BetterBankAccount("Bob", 1000)
print("\n" + "="*50)
print("BETTER ENCAPSULATION:")
print(f"Balance: ${account.get_balance()}")
account.deposit(500)
print(f"After deposit: ${account.get_balance()}")
account.withdraw(200)
print(f"After withdrawal: ${account.get_balance()}")


# Summary visualization
print("\n" + "="*70)
print("ACCESS LEVEL SUMMARY")
print("="*70)
print("PUBLIC (name):        Accessible everywhere")
print("PROTECTED (_name):    Convention - internal use, but accessible")
print("PRIVATE (__name):     Name mangling - hard to access (but still possible)")
print("="*70)


# Key Takeaways:
# 1. PUBLIC: No underscore - accessible from anywhere
# 2. PROTECTED: Single underscore (_) - convention for internal use
# 3. PRIVATE: Double underscore (__) - name mangling applied
# 4. Python doesn't enforce access control strictly
# 5. These are conventions to signal intent to other developers
# 6. Use getters/setters or properties for controlled access
# 7. Private members help prevent accidental modification
# 8. Protected members are for subclass use
