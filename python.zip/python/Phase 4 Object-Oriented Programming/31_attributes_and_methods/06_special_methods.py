"""
06: Special Methods (Magic Methods / Dunder Methods)

Special methods in Python start and end with double underscores (__).
They allow your objects to use Python's built-in operations and functions.
"""

# Example 1: Basic special methods
class Book:
    def __init__(self, title, author, pages):
        """Constructor - called when creating an object"""
        self.title = title
        self.author = author
        self.pages = pages
    
    def __str__(self):
        """String representation for end users (print)"""
        return f"'{self.title}' by {self.author}"
    
    def __repr__(self):
        """String representation for developers (debugging)"""
        return f"Book('{self.title}', '{self.author}', {self.pages})"
    
    def __len__(self):
        """Makes len() work on the object"""
        return self.pages

book = Book("1984", "George Orwell", 328)

print("BASIC SPECIAL METHODS:")
print(f"str: {str(book)}")  # Calls __str__
print(f"repr: {repr(book)}")  # Calls __repr__
print(f"len: {len(book)} pages")  # Calls __len__


# Example 2: Comparison operators
class Student:
    def __init__(self, name, grade):
        self.name = name
        self.grade = grade
    
    def __eq__(self, other):
        """Equal to: =="""
        return self.grade == other.grade
    
    def __lt__(self, other):
        """Less than: <"""
        return self.grade < other.grade
    
    def __le__(self, other):
        """Less than or equal: <="""
        return self.grade <= other.grade
    
    def __gt__(self, other):
        """Greater than: >"""
        return self.grade > other.grade
    
    def __ge__(self, other):
        """Greater than or equal: >="""
        return self.grade >= other.grade
    
    def __ne__(self, other):
        """Not equal: !="""
        return self.grade != other.grade
    
    def __str__(self):
        return f"{self.name} (Grade: {self.grade})"

print("\n" + "="*50)
print("COMPARISON OPERATORS:")
alice = Student("Alice", 95)
bob = Student("Bob", 87)
charlie = Student("Charlie", 95)

print(f"{alice}")
print(f"{bob}")
print(f"Alice == Bob: {alice == bob}")
print(f"Alice == Charlie: {alice == charlie}")
print(f"Alice > Bob: {alice > bob}")
print(f"Bob < Alice: {bob < alice}")


# Example 3: Arithmetic operators
class Money:
    def __init__(self, amount):
        self.amount = amount
    
    def __add__(self, other):
        """Addition: +"""
        if isinstance(other, Money):
            return Money(self.amount + other.amount)
        return Money(self.amount + other)
    
    def __sub__(self, other):
        """Subtraction: -"""
        if isinstance(other, Money):
            return Money(self.amount - other.amount)
        return Money(self.amount - other)
    
    def __mul__(self, factor):
        """Multiplication: *"""
        return Money(self.amount * factor)
    
    def __truediv__(self, divisor):
        """Division: /"""
        return Money(self.amount / divisor)
    
    def __str__(self):
        return f"${self.amount:.2f}"
    
    def __repr__(self):
        return f"Money({self.amount})"

print("\n" + "="*50)
print("ARITHMETIC OPERATORS:")
wallet1 = Money(100)
wallet2 = Money(50)

print(f"Wallet 1: {wallet1}")
print(f"Wallet 2: {wallet2}")
print(f"Total: {wallet1 + wallet2}")
print(f"Difference: {wallet1 - wallet2}")
print(f"Double wallet 1: {wallet1 * 2}")
print(f"Split wallet 1: {wallet1 / 2}")


# Example 4: Container methods (making objects iterable/indexable)
class Playlist:
    def __init__(self, name):
        self.name = name
        self.songs = []
    
    def add_song(self, song):
        self.songs.append(song)
    
    def __len__(self):
        """Number of songs"""
        return len(self.songs)
    
    def __getitem__(self, index):
        """Access by index: playlist[0]"""
        return self.songs[index]
    
    def __setitem__(self, index, value):
        """Set by index: playlist[0] = 'new song'"""
        self.songs[index] = value
    
    def __delitem__(self, index):
        """Delete by index: del playlist[0]"""
        del self.songs[index]
    
    def __contains__(self, song):
        """Check membership: 'song' in playlist"""
        return song in self.songs
    
    def __iter__(self):
        """Make object iterable"""
        return iter(self.songs)
    
    def __str__(self):
        return f"{self.name} ({len(self)} songs)"

print("\n" + "="*50)
print("CONTAINER METHODS:")
my_playlist = Playlist("Favorites")
my_playlist.add_song("Bohemian Rhapsody")
my_playlist.add_song("Stairway to Heaven")
my_playlist.add_song("Hotel California")

print(f"Playlist: {my_playlist}")
print(f"First song: {my_playlist[0]}")
print(f"All songs:")
for song in my_playlist:  # Uses __iter__
    print(f"  - {song}")

print(f"'Hey Jude' in playlist: {'Hey Jude' in my_playlist}")
print(f"'Hotel California' in playlist: {'Hotel California' in my_playlist}")


# Example 5: Context managers (__enter__ and __exit__)
class FileHandler:
    def __init__(self, filename, mode):
        self.filename = filename
        self.mode = mode
        self.file = None
    
    def __enter__(self):
        """Called when entering 'with' block"""
        print(f"Opening {self.filename}...")
        self.file = open(self.filename, self.mode)
        return self.file
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Called when exiting 'with' block"""
        print(f"Closing {self.filename}...")
        if self.file:
            self.file.close()
        return False

print("\n" + "="*50)
print("CONTEXT MANAGERS:")
# Create a test file first
with open('/home/claude/test.txt', 'w') as f:
    f.write("Hello, World!")

# Use our custom context manager
with FileHandler('/home/claude/test.txt', 'r') as file:
    content = file.read()
    print(f"Content: {content}")


# Example 6: Callable objects (__call__)
class Multiplier:
    def __init__(self, factor):
        self.factor = factor
    
    def __call__(self, x):
        """Makes object callable like a function"""
        return x * self.factor

print("\n" + "="*50)
print("CALLABLE OBJECTS:")
double = Multiplier(2)
triple = Multiplier(3)

print(f"double(5) = {double(5)}")  # Object used as a function!
print(f"triple(5) = {triple(5)}")


# Example 7: Attribute access methods
class SmartDict:
    def __init__(self):
        self._data = {}
    
    def __getattr__(self, name):
        """Called when attribute doesn't exist"""
        return self._data.get(name, "Attribute not found")
    
    def __setattr__(self, name, value):
        """Called when setting any attribute"""
        if name == '_data':
            super().__setattr__(name, value)
        else:
            self._data[name] = value
    
    def __delattr__(self, name):
        """Called when deleting attribute"""
        if name in self._data:
            del self._data[name]

print("\n" + "="*50)
print("ATTRIBUTE ACCESS:")
sd = SmartDict()
sd.name = "Alice"
sd.age = 30
print(f"Name: {sd.name}")
print(f"Age: {sd.age}")
print(f"City: {sd.city}")  # Doesn't exist, returns default message


# Example 8: Complete example with multiple special methods
class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __str__(self):
        return f"Vector({self.x}, {self.y})"
    
    def __repr__(self):
        return f"Vector({self.x}, {self.y})"
    
    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)
    
    def __sub__(self, other):
        return Vector(self.x - other.x, self.y - other.y)
    
    def __mul__(self, scalar):
        return Vector(self.x * scalar, self.y * scalar)
    
    def __eq__(self, other):
        return self.x == other.x and self.y == other.y
    
    def __abs__(self):
        return (self.x ** 2 + self.y ** 2) ** 0.5
    
    def __bool__(self):
        return bool(abs(self))

print("\n" + "="*50)
print("COMPLETE VECTOR EXAMPLE:")
v1 = Vector(3, 4)
v2 = Vector(1, 2)

print(f"v1 = {v1}")
print(f"v2 = {v2}")
print(f"v1 + v2 = {v1 + v2}")
print(f"v1 - v2 = {v1 - v2}")
print(f"v1 * 2 = {v1 * 2}")
print(f"Magnitude of v1: {abs(v1):.2f}")
print(f"v1 == v2: {v1 == v2}")


# Summary of commonly used special methods
print("\n" + "="*70)
print("COMMON SPECIAL METHODS REFERENCE")
print("="*70)
print("__init__(self, ...)      : Constructor")
print("__str__(self)            : String representation (for users)")
print("__repr__(self)           : String representation (for developers)")
print("__len__(self)            : len() function")
print("__getitem__(self, key)   : obj[key] access")
print("__setitem__(self, k, v)  : obj[key] = value")
print("__eq__(self, other)      : == operator")
print("__lt__(self, other)      : < operator")
print("__add__(self, other)     : + operator")
print("__sub__(self, other)     : - operator")
print("__mul__(self, other)     : * operator")
print("__contains__(self, item) : in operator")
print("__iter__(self)           : for loops")
print("__call__(self, ...)      : obj() callable")
print("__enter__(self)          : with statement (entry)")
print("__exit__(self, ...)      : with statement (exit)")
print("="*70)


# Key Takeaways:
# 1. Special methods start and end with double underscores (__)
# 2. They integrate your objects with Python's syntax and built-ins
# 3. __str__ for user-friendly output, __repr__ for debugging
# 4. Comparison operators: __eq__, __lt__, __gt__, etc.
# 5. Arithmetic operators: __add__, __sub__, __mul__, etc.
# 6. Container methods: __len__, __getitem__, __setitem__
# 7. __call__ makes objects callable like functions
# 8. __enter__ and __exit__ for context managers (with statement)
# 9. Don't call special methods directly - use built-in functions/operators
