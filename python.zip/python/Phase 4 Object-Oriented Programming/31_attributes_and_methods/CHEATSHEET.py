"""
QUICK REFERENCE: Attributes & Methods Cheat Sheet
"""

print("="*70)
print("ATTRIBUTES & METHODS - QUICK REFERENCE")
print("="*70)

# ATTRIBUTES
print("\n1. INSTANCE ATTRIBUTES")
print("-" * 70)
print("""
class Dog:
    def __init__(self, name, age):
        self.name = name      # Instance attribute
        self.age = age        # Instance attribute

dog1 = Dog("Buddy", 3)
dog2 = Dog("Max", 5)
print(dog1.name)  # Buddy
print(dog2.name)  # Max
""")

print("\n2. CLASS ATTRIBUTES")
print("-" * 70)
print("""
class Dog:
    species = "Canis familiaris"  # Class attribute (shared by all)
    
    def __init__(self, name):
        self.name = name              # Instance attribute (unique)

dog1 = Dog("Buddy")
dog2 = Dog("Max")
print(dog1.species)  # Canis familiaris (same for all)
print(Dog.species)   # Canis familiaris
""")

# METHODS
print("\n3. INSTANCE METHODS")
print("-" * 70)
print("""
class Dog:
    def __init__(self, name):
        self.name = name
    
    def bark(self):           # Instance method
        return f"{self.name} says Woof!"

dog = Dog("Buddy")
print(dog.bark())  # Buddy says Woof!
""")

print("\n4. CLASS METHODS")
print("-" * 70)
print("""
class Employee:
    company = "TechCorp"
    
    @classmethod
    def get_company(cls):     # Class method
        return cls.company
    
    @classmethod
    def from_string(cls, emp_string):  # Alternative constructor
        name, salary = emp_string.split('-')
        return cls(name, int(salary))

print(Employee.get_company())  # TechCorp
emp = Employee.from_string("Alice-50000")
""")

print("\n5. STATIC METHODS")
print("-" * 70)
print("""
class Math:
    @staticmethod
    def add(x, y):            # Static method
        return x + y

print(Math.add(5, 3))  # 8
""")

# ACCESS MODIFIERS
print("\n6. ACCESS MODIFIERS")
print("-" * 70)
print("""
class Example:
    def __init__(self):
        self.public = "public"         # Public
        self._protected = "protected"   # Protected (convention)
        self.__private = "private"      # Private (name mangling)

obj = Example()
print(obj.public)      # OK
print(obj._protected)  # OK (but not recommended)
print(obj.__private)   # AttributeError
""")

# PROPERTIES
print("\n7. PROPERTIES (@property)")
print("-" * 70)
print("""
class Temperature:
    def __init__(self, celsius):
        self._celsius = celsius
    
    @property
    def celsius(self):          # Getter
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):   # Setter with validation
        if value < -273.15:
            raise ValueError("Too cold!")
        self._celsius = value
    
    @property
    def fahrenheit(self):       # Computed property
        return (self._celsius * 9/5) + 32

temp = Temperature(25)
print(temp.celsius)     # 25
temp.celsius = 30       # Uses setter
print(temp.fahrenheit)  # 86.0 (computed)
""")

# SPECIAL METHODS
print("\n8. SPECIAL METHODS (Magic Methods)")
print("-" * 70)
print("""
class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def __str__(self):              # For print()
        return f"Vector({self.x}, {self.y})"
    
    def __repr__(self):             # For repr()
        return f"Vector({self.x}, {self.y})"
    
    def __add__(self, other):       # For +
        return Vector(self.x + other.x, self.y + other.y)
    
    def __eq__(self, other):        # For ==
        return self.x == other.x and self.y == other.y
    
    def __len__(self):              # For len()
        return 2
    
    def __getitem__(self, index):   # For indexing []
        return [self.x, self.y][index]

v1 = Vector(1, 2)
v2 = Vector(3, 4)
print(v1)           # Vector(1, 2)
print(v1 + v2)      # Vector(4, 6)
print(v1 == v2)     # False
print(len(v1))      # 2
print(v1[0])        # 1
""")

# COMMON SPECIAL METHODS
print("\n9. COMMON SPECIAL METHODS")
print("-" * 70)
print("""
__init__(self, ...)       : Constructor
__str__(self)            : String for print() - user-friendly
__repr__(self)           : String for repr() - developer-friendly
__len__(self)            : len(obj)
__getitem__(self, key)   : obj[key]
__setitem__(self, k, v)  : obj[key] = value
__delitem__(self, key)   : del obj[key]
__contains__(self, item) : item in obj
__iter__(self)           : for x in obj
__call__(self, ...)      : obj()

# Comparison
__eq__(self, other)      : ==
__ne__(self, other)      : !=
__lt__(self, other)      : <
__le__(self, other)      : <=
__gt__(self, other)      : >
__ge__(self, other)      : >=

# Arithmetic
__add__(self, other)     : +
__sub__(self, other)     : -
__mul__(self, other)     : *
__truediv__(self, other) : /
__floordiv__(self, other): //
__mod__(self, other)     : %
__pow__(self, other)     : **

# Unary
__neg__(self)            : -obj
__pos__(self)            : +obj
__abs__(self)            : abs(obj)

# Context Manager
__enter__(self)          : with statement entry
__exit__(self, ...)      : with statement exit
""")

# BEST PRACTICES
print("\n10. BEST PRACTICES")
print("-" * 70)
print("""
✓ Use instance attributes for data unique to each object
✓ Use class attributes for data shared by all objects
✓ Use instance methods when you need to access/modify instance data
✓ Use class methods for alternative constructors or class-level operations
✓ Use static methods for utility functions related to the class
✓ Use _ prefix for protected members (internal use)
✓ Use __ prefix for private members (strong encapsulation)
✓ Use @property for getters/setters and computed values
✓ Implement __str__ for user-friendly output
✓ Implement __repr__ for debugging output
✓ Add validation in property setters
✓ Keep methods focused on one task
✓ Use descriptive names for attributes and methods
""")

print("\n" + "="*70)
print("END OF CHEAT SHEET")
print("="*70)
