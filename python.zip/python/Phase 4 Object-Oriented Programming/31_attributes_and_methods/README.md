# Attributes & Methods in Object-Oriented Programming

## Overview
This module covers the fundamental building blocks of Object-Oriented Programming: attributes (data) and methods (behavior).

## What You'll Learn
- Instance attributes vs class attributes
- Instance methods, class methods, and static methods
- Access modifiers (public, private, protected)
- Properties and getters/setters
- Method overloading concepts
- The `self` parameter in Python

## File Structure
- `01_basic_attributes.py` - Introduction to attributes
- `02_basic_methods.py` - Introduction to methods
- `03_instance_vs_class.py` - Instance vs class attributes/methods
- `04_access_modifiers.py` - Public, private, and protected members
- `05_properties.py` - Using @property decorators
- `06_special_methods.py` - Magic/dunder methods
- `exercises/` - Practice problems
- `solutions/` - Solutions to exercises

## Key Concepts

### Attributes
**Attributes** are variables that belong to a class or object. They represent the state or data of an object.

- **Instance Attributes**: Unique to each object instance
- **Class Attributes**: Shared across all instances of a class

### Methods
**Methods** are functions defined inside a class that describe the behaviors of objects.

- **Instance Methods**: Operate on instance data (use `self`)
- **Class Methods**: Operate on class data (use `@classmethod` decorator)
- **Static Methods**: Don't access instance or class data (use `@staticmethod` decorator)

## Getting Started
1. Start with `01_basic_attributes.py` to understand how attributes work
2. Move through the numbered files sequentially
3. Try the exercises after completing the examples
4. Check solutions only after attempting the exercises

## Additional Resources
- Python Official Documentation: https://docs.python.org/3/tutorial/classes.html
- Real Python OOP Tutorial: https://realpython.com/python3-object-oriented-programming/

Happy Learning! 🚀
