# Encapsulation

## Learning Objectives
By the end of this module, you will be able to:
- Understand and implement encapsulation in Python
- Use public, protected, and private attributes
- Create getters and setters using @property decorator
- Implement data validation and access control
- Understand the benefits of data hiding
- Apply encapsulation in real-world scenarios

## Module Structure

### 📁 examples/
Demonstration code showing key concepts:
- `01_basic_encapsulation.py` - Introduction to encapsulation
- `02_access_modifiers.py` - Public, protected, and private attributes
- `03_property_decorator.py` - Using @property for getters/setters
- `04_data_validation.py` - Validating data with properties
- `05_computed_properties.py` - Properties that calculate values
- `06_encapsulation_benefits.py` - Why encapsulation matters

### 📁 exercises/
Practice problems to reinforce learning:
- `exercise_01_person.py` - Create a Person class with encapsulation
- `exercise_02_bank_account.py` - Secure bank account implementation
- `exercise_03_temperature.py` - Temperature converter with validation
- `exercise_04_product.py` - Product inventory with price control

### 📁 projects/
Real-world applications:
- `user_authentication/` - Login system with secure password storage
- `shopping_cart/` - E-commerce cart with price calculations

### 📁 solutions/
Complete solutions to all exercises

## Key Concepts

### What is Encapsulation?
Encapsulation is the bundling of data (attributes) and methods that operate on that data within a single unit (class), while restricting direct access to some of the object's components.

### Access Levels in Python

```python
class Example:
    def __init__(self):
        self.public = "I'm public"           # Anyone can access
        self._protected = "I'm protected"    # Hint: internal use
        self.__private = "I'm private"       # Name mangling applied
```

### Property Decorator

```python
class Person:
    def __init__(self, name):
        self._name = name
    
    @property
    def name(self):
        """Getter"""
        return self._name
    
    @name.setter
    def name(self, value):
        """Setter with validation"""
        if not value:
            raise ValueError("Name cannot be empty")
        self._name = value
```

## Benefits of Encapsulation
1. **Data Protection** - Control how data is accessed and modified
2. **Flexibility** - Change internal implementation without breaking code
3. **Validation** - Ensure data meets requirements before storing
4. **Abstraction** - Hide complexity from users
5. **Maintainability** - Easier to update and debug

## Tips for Success
- Use private attributes for internal state
- Provide public methods/properties for controlled access
- Validate data in setters
- Document your public interface
- Follow naming conventions

Happy coding! 🔒
