# Inheritance

## Learning Objectives
By the end of this module, you will be able to:
- Understand and implement class inheritance in Python
- Create parent and child class relationships
- Override methods in derived classes
- Implement multiple inheritance
- Use super() to access parent class methods
- Design class hierarchies for real-world scenarios

## Module Structure

### 📁 examples/
Demonstration code showing key concepts:
- `01_basic_inheritance.py` - Introduction to inheritance
- `02_method_overriding.py` - How to override parent methods
- `03_super_function.py` - Using super() effectively
- `04_multiple_inheritance.py` - Working with multiple parent classes

### 📁 exercises/
Practice problems to reinforce learning:
- `exercise_01_animals.py` - Create an animal hierarchy
- `exercise_02_vehicles.py` - Build a vehicle system
- `exercise_03_employees.py` - Employee management system

### 📁 projects/
Real-world application:
- `game_characters/` - RPG character system with inheritance

### 📁 solutions/
Complete solutions to all exercises

## Key Concepts

### What is Inheritance?
Inheritance allows a class (child/subclass) to inherit attributes and methods from another class (parent/superclass).

```python
class Parent:
    def method(self):
        print("Parent method")

class Child(Parent):
    pass  # Inherits everything from Parent
```

### Method Overriding
Child classes can override parent methods to provide specific behavior:

```python
class Animal:
    def make_sound(self):
        return "Some sound"

class Dog(Animal):
    def make_sound(self):  # Override
        return "Woof!"
```

### Using super()
Access parent class methods from child class:

```python
class Child(Parent):
    def __init__(self, name):
        super().__init__()  # Call parent constructor
        self.name = name
```

### Multiple Inheritance
A class can inherit from multiple parents:

```python
class Child(Parent1, Parent2):
    pass
```

## Benefits of Inheritance
1. **Code Reusability** - Inherit existing functionality
2. **Logical Hierarchy** - Model real-world relationships
3. **Extensibility** - Easy to add new features
4. **Maintainability** - Changes in parent affect all children
5. **Polymorphism** - Different classes, same interface

## Tips for Success
- Start with simple parent-child relationships
- Use super() to call parent methods
- Override methods when you need different behavior
- Keep inheritance hierarchies shallow (prefer composition for deep trees)
- Document your class relationships

Happy coding! 🌳
