# Polymorphism

## Learning Objectives
By the end of this module, you will be able to:
- Understand and apply polymorphism in Python
- Implement polymorphic behavior through method overriding
- Use abstract base classes to enforce interfaces
- Apply duck typing principles
- Design flexible, extensible systems

## Module Structure

### 📁 examples/
Demonstration code showing key concepts:
- `05_polymorphism_demo.py` - Understanding polymorphism
- `06_abstract_classes.py` - Abstract base classes and interfaces

### 📁 exercises/
Practice problem to reinforce learning:
- `exercise_04_shapes.py` - Geometric shapes with polymorphism

### 📁 projects/
Real-world application:
- `banking_system/` - Banking application with polymorphic account types

### 📁 solutions/
Complete solution to the exercise

## Key Concepts

### What is Polymorphism?
Polymorphism means "many forms". It allows objects of different classes to be treated as objects of a common parent class, with each object responding differently to the same method call.

```python
class Animal:
    def speak(self):
        pass

class Dog(Animal):
    def speak(self):
        return "Woof!"

class Cat(Animal):
    def speak(self):
        return "Meow!"

# Polymorphism in action
animals = [Dog(), Cat()]
for animal in animals:
    print(animal.speak())  # Different behavior, same method!
```

### Abstract Base Classes
Enforce that subclasses implement specific methods:

```python
from abc import ABC, abstractmethod

class Shape(ABC):
    @abstractmethod
    def area(self):
        pass  # Subclasses MUST implement this

class Circle(Shape):
    def area(self):
        return 3.14 * self.radius ** 2
```

### Duck Typing
"If it walks like a duck and quacks like a duck, it's a duck."

```python
def make_it_speak(obj):
    print(obj.speak())  # Works with any object that has speak()

# No inheritance required!
make_it_speak(Dog())
make_it_speak(Cat())
```

## Benefits of Polymorphism
1. **Flexibility** - Easy to add new types without changing existing code
2. **Maintainability** - Changes to one class don't affect others
3. **Extensibility** - New classes work with existing functions
4. **Code Reusability** - Same code works with multiple types
5. **Abstraction** - Hide implementation details behind common interface

## Real-World Examples
- **Payment Processing** - Multiple payment methods (credit card, PayPal, crypto)
- **File Handling** - Different file types (CSV, JSON, XML)
- **Database Connections** - Different databases (MySQL, PostgreSQL, MongoDB)
- **Notifications** - Different channels (email, SMS, push)

## Tips for Success
- Design your interfaces (abstract classes) first
- Think about what behaviors are common across classes
- Use abstract methods for required functionality
- Test with different object types to verify polymorphism
- Remember: same interface, different implementations

Happy coding! 🎭
