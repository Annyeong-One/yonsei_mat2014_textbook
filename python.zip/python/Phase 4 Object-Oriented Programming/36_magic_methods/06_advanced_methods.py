"""
Example 6: Advanced Magic Methods
Demonstrates: __getattr__, __setattr__, __delattr__, __hash__, __bool__
"""


class DynamicAttributes:
    """A class that dynamically creates attributes."""
    
    def __init__(self):
        # Use object.__setattr__ to avoid recursion
        object.__setattr__(self, '_data', {})
    
    def __getattr__(self, name):
        """Called when attribute is not found normally."""
        print(f"Getting dynamic attribute: {name}")
        if name in self._data:
            return self._data[name]
        raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
    
    def __setattr__(self, name, value):
        """Called for every attribute assignment."""
        print(f"Setting attribute: {name} = {value}")
        self._data[name] = value
    
    def __delattr__(self, name):
        """Called when deleting an attribute."""
        print(f"Deleting attribute: {name}")
        if name in self._data:
            del self._data[name]
        else:
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")


class ValidatedAttribute:
    """A class that validates attributes before setting."""
    
    def __init__(self, name, age):
        self.name = name  # Will call __setattr__
        self.age = age
    
    def __setattr__(self, name, value):
        """Validate attributes before setting."""
        if name == 'age':
            if not isinstance(value, int):
                raise TypeError("Age must be an integer")
            if value < 0 or value > 150:
                raise ValueError("Age must be between 0 and 150")
        elif name == 'name':
            if not isinstance(value, str):
                raise TypeError("Name must be a string")
            if len(value) == 0:
                raise ValueError("Name cannot be empty")
        
        # Actually set the attribute
        object.__setattr__(self, name, value)


class Point3D:
    """A 3D point with hash support for use in sets and as dict keys."""
    
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z
    
    def __repr__(self):
        return f"Point3D({self.x}, {self.y}, {self.z})"
    
    def __eq__(self, other):
        """Points are equal if all coordinates are equal."""
        if not isinstance(other, Point3D):
            return NotImplemented
        return (self.x, self.y, self.z) == (other.x, other.y, other.z)
    
    def __hash__(self):
        """Make the point hashable so it can be used in sets and as dict keys."""
        return hash((self.x, self.y, self.z))


class SmartList:
    """A list wrapper with custom boolean behavior."""
    
    def __init__(self, items=None):
        self.items = items or []
    
    def __repr__(self):
        return f"SmartList({self.items})"
    
    def __bool__(self):
        """Custom truthiness: True if sum of items is positive."""
        return sum(self.items) > 0 if self.items else False
    
    def __len__(self):
        return len(self.items)
    
    def add(self, item):
        self.items.append(item)


class CaseInsensitiveDict:
    """A dictionary that treats keys as case-insensitive."""
    
    def __init__(self):
        self._data = {}
    
    def __getitem__(self, key):
        return self._data[key.lower()]
    
    def __setitem__(self, key, value):
        self._data[key.lower()] = value
    
    def __delitem__(self, key):
        del self._data[key.lower()]
    
    def __contains__(self, key):
        return key.lower() in self._data
    
    def __repr__(self):
        return f"CaseInsensitiveDict({dict(self._data)})"


# Examples
if __name__ == "__main__":
    print("=== DynamicAttributes Examples ===")
    obj = DynamicAttributes()
    
    # Set attributes dynamically
    obj.name = "Alice"
    obj.age = 30
    obj.city = "New York"
    
    # Get attributes
    print(f"\nName: {obj.name}")
    print(f"Age: {obj.age}")
    
    # Delete attribute
    del obj.city
    
    try:
        print(obj.city)
    except AttributeError as e:
        print(f"Error: {e}")
    
    print("\n\n=== ValidatedAttribute Examples ===")
    person = ValidatedAttribute("Bob", 25)
    print(f"Created: {person.name}, age {person.age}")
    
    # Valid update
    person.age = 26
    print(f"Updated age: {person.age}")
    
    # Invalid updates
    try:
        person.age = -5
    except ValueError as e:
        print(f"Error: {e}")
    
    try:
        person.age = "thirty"
    except TypeError as e:
        print(f"Error: {e}")
    
    try:
        person.name = ""
    except ValueError as e:
        print(f"Error: {e}")
    
    print("\n\n=== Point3D with Hash Examples ===")
    p1 = Point3D(1, 2, 3)
    p2 = Point3D(1, 2, 3)
    p3 = Point3D(4, 5, 6)
    
    print(f"p1: {p1}")
    print(f"p2: {p2}")
    print(f"p3: {p3}")
    
    print(f"\np1 == p2: {p1 == p2}")
    print(f"p1 == p3: {p1 == p3}")
    print(f"hash(p1) == hash(p2): {hash(p1) == hash(p2)}")
    
    # Use in set
    points = {p1, p2, p3}  # p1 and p2 are the same, so only 2 unique points
    print(f"\nSet of points: {points}")
    print(f"Length of set: {len(points)}")
    
    # Use as dict keys
    point_names = {
        p1: "Origin area",
        p3: "Far corner"
    }
    print(f"\nPoint dictionary: {point_names}")
    print(f"p1 in dict: {p1 in point_names}")
    print(f"p2 in dict: {p2 in point_names}")  # True because p2 == p1
    
    print("\n\n=== SmartList Boolean Examples ===")
    list1 = SmartList([1, 2, 3])
    list2 = SmartList([-5, -10])
    list3 = SmartList([5, -5])
    list4 = SmartList([])
    
    print(f"list1 {list1}: bool = {bool(list1)} (sum = {sum(list1.items)})")
    print(f"list2 {list2}: bool = {bool(list2)} (sum = {sum(list2.items)})")
    print(f"list3 {list3}: bool = {bool(list3)} (sum = {sum(list3.items)})")
    print(f"list4 {list4}: bool = {bool(list4)}")
    
    # Use in if statement
    if list1:
        print("\nlist1 is truthy (sum is positive)")
    
    if not list2:
        print("list2 is falsy (sum is not positive)")
    
    print("\n\n=== CaseInsensitiveDict Examples ===")
    d = CaseInsensitiveDict()
    
    # Set with different cases
    d["Name"] = "Alice"
    d["AGE"] = 30
    d["city"] = "New York"
    
    print(f"Dictionary: {d}")
    
    # Get with different cases
    print(f"\nd['name'] = {d['name']}")
    print(f"d['Name'] = {d['Name']}")
    print(f"d['NAME'] = {d['NAME']}")
    
    # Check membership with different cases
    print(f"\n'name' in d: {'name' in d}")
    print(f"'NAME' in d: {'NAME' in d}")
    print(f"'Name' in d: {'Name' in d}")
    print(f"'Country' in d: {'Country' in d}")
