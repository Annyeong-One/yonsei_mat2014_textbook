# Python Magic Methods (Dunder Methods) - Complete Guide

## What Are Magic Methods?

Magic methods (also called dunder methods, short for "double underscore") are special methods in Python that start and end with double underscores (`__`). They allow you to define how objects of your class behave with built-in Python operations.

## Categories of Magic Methods

### 1. Object Initialization and Representation

- `__init__(self, ...)` - Constructor, called when object is created
- `__new__(cls, ...)` - Creates the instance (called before `__init__`)
- `__del__(self)` - Destructor, called when object is deleted
- `__repr__(self)` - Official string representation (for developers)
- `__str__(self)` - Informal string representation (for users)
- `__format__(self, format_spec)` - Custom string formatting
- `__bytes__(self)` - Byte representation
- `__hash__(self)` - Returns hash value of object

### 2. Comparison Operators

- `__eq__(self, other)` - Equal to (`==`)
- `__ne__(self, other)` - Not equal to (`!=`)
- `__lt__(self, other)` - Less than (`<`)
- `__le__(self, other)` - Less than or equal to (`<=`)
- `__gt__(self, other)` - Greater than (`>`)
- `__ge__(self, other)` - Greater than or equal to (`>=`)

### 3. Arithmetic Operators

- `__add__(self, other)` - Addition (`+`)
- `__sub__(self, other)` - Subtraction (`-`)
- `__mul__(self, other)` - Multiplication (`*`)
- `__truediv__(self, other)` - Division (`/`)
- `__floordiv__(self, other)` - Floor division (`//`)
- `__mod__(self, other)` - Modulo (`%`)
- `__pow__(self, other)` - Power (`**`)
- `__matmul__(self, other)` - Matrix multiplication (`@`)

### 4. Reverse Arithmetic Operators

- `__radd__(self, other)` - Right-side addition
- `__rsub__(self, other)` - Right-side subtraction
- `__rmul__(self, other)` - Right-side multiplication
- And so on for other operators...

### 5. Augmented Assignment

- `__iadd__(self, other)` - In-place addition (`+=`)
- `__isub__(self, other)` - In-place subtraction (`-=`)
- `__imul__(self, other)` - In-place multiplication (`*=`)
- And so on for other operators...

### 6. Unary Operators

- `__neg__(self)` - Negation (`-obj`)
- `__pos__(self)` - Positive (`+obj`)
- `__abs__(self)` - Absolute value (`abs(obj)`)
- `__invert__(self)` - Bitwise inversion (`~obj`)

### 7. Type Conversion

- `__int__(self)` - Convert to int
- `__float__(self)` - Convert to float
- `__complex__(self)` - Convert to complex
- `__bool__(self)` - Convert to boolean
- `__index__(self)` - Convert to integer for indexing

### 8. Container Methods

- `__len__(self)` - Length (`len(obj)`)
- `__getitem__(self, key)` - Get item (`obj[key]`)
- `__setitem__(self, key, value)` - Set item (`obj[key] = value`)
- `__delitem__(self, key)` - Delete item (`del obj[key]`)
- `__contains__(self, item)` - Membership test (`item in obj`)
- `__iter__(self)` - Return iterator
- `__next__(self)` - Get next item in iteration
- `__reversed__(self)` - Reverse iteration

### 9. Attribute Access

- `__getattr__(self, name)` - Get attribute that doesn't exist
- `__setattr__(self, name, value)` - Set any attribute
- `__delattr__(self, name)` - Delete attribute
- `__getattribute__(self, name)` - Get any attribute (even existing ones)
- `__dir__(self)` - Return list of attributes

### 10. Callable Objects

- `__call__(self, ...)` - Make object callable like a function

### 11. Context Managers

- `__enter__(self)` - Enter context (`with` statement)
- `__exit__(self, exc_type, exc_val, exc_tb)` - Exit context

### 12. Descriptor Protocol

- `__get__(self, instance, owner)` - Get attribute value
- `__set__(self, instance, value)` - Set attribute value
- `__delete__(self, instance)` - Delete attribute

## When to Use Magic Methods

1. **Custom Containers**: Implement `__len__`, `__getitem__`, etc.
2. **Numeric Types**: Implement arithmetic operators
3. **Context Managers**: Implement `__enter__` and `__exit__`
4. **Better Printing**: Implement `__repr__` and `__str__`
5. **Comparisons**: Implement comparison operators
6. **Making Objects Callable**: Implement `__call__`

## Best Practices

1. Always implement `__repr__` for debugging
2. Implement `__str__` for user-friendly output
3. If you implement `__eq__`, also implement `__hash__` (or set it to None)
4. Return `NotImplemented` in comparison/arithmetic methods when appropriate
5. Document your magic methods clearly
6. Follow the principle of least surprise - make behavior intuitive
