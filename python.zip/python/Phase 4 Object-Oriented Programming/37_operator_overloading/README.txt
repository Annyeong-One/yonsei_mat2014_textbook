"""
Python Operator Overloading Tutorial Package
============================================

A comprehensive educational package for teaching operator overloading in Python
using dunder (magic) methods. This package progresses from beginner concepts
through advanced patterns with heavily commented code examples.

Author: Created for undergraduate computer science education
Target Audience: Students learning Python operator overloading
Python Version: 3.8+


Package Structure
=================

operator_overloading_tutorial/
├── README.txt                          (This file)
├── beginner/                           (Beginner level tutorials)
│   ├── 01_basic_arithmetic_operators.py
│   ├── 02_comparison_operators.py
│   └── 03_string_and_unary_operators.py
├── intermediate/                       (Intermediate level tutorials)
│   ├── 01_container_operators.py
│   ├── 02_callable_and_descriptors.py
│   └── 03_context_managers_augmented.py
├── advanced/                           (Advanced level tutorials)
│   ├── 01_reflected_operators.py
│   └── 02_advanced_iteration.py
├── exercises/                          (Practice exercises)
│   ├── beginner_exercises.py
│   └── intermediate_exercises.py
└── solutions/                          (Exercise solutions)
    └── beginner_solutions.py


Quick Start Guide
=================

1. Start with Beginner Level:
   ---------------------------
   Run each file in the beginner/ directory:
   
   $ python beginner/01_basic_arithmetic_operators.py
   $ python beginner/02_comparison_operators.py
   $ python beginner/03_string_and_unary_operators.py
   
   Each file demonstrates concepts with working examples and detailed comments.

2. Progress to Intermediate Level:
   --------------------------------
   After mastering beginner concepts, move to intermediate/ directory:
   
   $ python intermediate/01_container_operators.py
   $ python intermediate/02_callable_and_descriptors.py
   $ python intermediate/03_context_managers_augmented.py

3. Practice with Exercises:
   -------------------------
   Test your understanding with exercises:
   
   $ python exercises/beginner_exercises.py
   $ python exercises/intermediate_exercises.py
   
   Implement the missing methods, then check solutions/ directory.

4. Master Advanced Concepts:
   --------------------------
   $ python advanced/01_reflected_operators.py
   $ python advanced/02_advanced_iteration.py


Learning Path
=============

BEGINNER LEVEL (Start Here)
----------------------------
Week 1-2: Basic Arithmetic Operators
  - File: 01_basic_arithmetic_operators.py
  - Topics: __add__, __sub__, __mul__, __truediv__
  - Concepts: Basic operator overloading, creating custom numeric types
  - Exercise: Implement Fraction class

Week 2-3: Comparison Operators
  - File: 02_comparison_operators.py
  - Topics: __eq__, __ne__, __lt__, __le__, __gt__, __ge__
  - Concepts: Making objects sortable, using @total_ordering
  - Exercise: Implement ComplexNumber class

Week 3-4: String and Unary Operators
  - File: 03_string_and_unary_operators.py
  - Topics: __str__, __repr__, __neg__, __abs__, __bool__
  - Concepts: String representation, type conversion
  - Exercise: Implement TimeSpan class

INTERMEDIATE LEVEL
------------------
Week 5-6: Container Operators
  - File: 01_container_operators.py
  - Topics: __len__, __getitem__, __setitem__, __contains__, __iter__
  - Concepts: Making objects behave like lists/dicts
  - Exercise: Implement Stack class

Week 6-7: Callable Objects and Descriptors
  - File: 02_callable_and_descriptors.py
  - Topics: __call__, __get__, __set__, __delete__
  - Concepts: Making objects callable, controlling attribute access
  - Exercise: Implement CachedCalculator

Week 7-8: Context Managers and Augmented Assignment
  - File: 03_context_managers_augmented.py
  - Topics: __enter__, __exit__, __iadd__, __isub__, __imul__
  - Concepts: Resource management, in-place operations
  - Exercise: Implement ManagedResource and Vector2D

ADVANCED LEVEL
--------------
Week 9-10: Reflected Operators
  - File: 01_reflected_operators.py
  - Topics: __radd__, __rmul__, __matmul__, __pow__
  - Concepts: Right-hand operators, matrix operations
  - Advanced: Polynomial and Matrix classes

Week 11-12: Advanced Iteration
  - File: 02_advanced_iteration.py
  - Topics: Custom iterators, generators, __next__
  - Concepts: Lazy evaluation, infinite iterators
  - Advanced: Building sophisticated iterable data structures


Complete Dunder Method Reference
=================================

ARITHMETIC OPERATORS
--------------------
__add__(self, other)          # Addition: a + b
__sub__(self, other)          # Subtraction: a - b
__mul__(self, other)          # Multiplication: a * b
__truediv__(self, other)      # Division: a / b
__floordiv__(self, other)     # Floor division: a // b
__mod__(self, other)          # Modulo: a % b
__pow__(self, other)          # Exponentiation: a ** b
__matmul__(self, other)       # Matrix multiplication: a @ b

REFLECTED OPERATORS (Right-hand)
--------------------------------
__radd__(self, other)         # Right addition: other + self
__rsub__(self, other)         # Right subtraction: other - self
__rmul__(self, other)         # Right multiplication: other * self
__rtruediv__(self, other)     # Right division: other / self
__rmatmul__(self, other)      # Right matrix mult: other @ self

AUGMENTED ASSIGNMENT
--------------------
__iadd__(self, other)         # In-place addition: a += b
__isub__(self, other)         # In-place subtraction: a -= b
__imul__(self, other)         # In-place multiplication: a *= b
__itruediv__(self, other)     # In-place division: a /= b

COMPARISON OPERATORS
--------------------
__eq__(self, other)           # Equal: a == b
__ne__(self, other)           # Not equal: a != b
__lt__(self, other)           # Less than: a < b
__le__(self, other)           # Less than or equal: a <= b
__gt__(self, other)           # Greater than: a > b
__ge__(self, other)           # Greater than or equal: a >= b

UNARY OPERATORS
---------------
__neg__(self)                 # Negation: -a
__pos__(self)                 # Positive: +a
__abs__(self)                 # Absolute value: abs(a)
__invert__(self)              # Bitwise NOT: ~a

CONTAINER OPERATORS
-------------------
__len__(self)                 # Length: len(obj)
__getitem__(self, key)        # Get item: obj[key]
__setitem__(self, key, value) # Set item: obj[key] = value
__delitem__(self, key)        # Delete item: del obj[key]
__contains__(self, item)      # Membership: item in obj
__iter__(self)                # Iteration: for x in obj
__reversed__(self)            # Reverse: reversed(obj)

STRING REPRESENTATION
---------------------
__str__(self)                 # String: str(obj), print(obj)
__repr__(self)                # Representation: repr(obj)
__format__(self, spec)        # Format: f"{obj:spec}"

TYPE CONVERSION
---------------
__int__(self)                 # Convert to int: int(obj)
__float__(self)               # Convert to float: float(obj)
__bool__(self)                # Convert to bool: bool(obj)
__complex__(self)             # Convert to complex: complex(obj)

CALLABLE AND DESCRIPTOR
-----------------------
__call__(self, *args)         # Call: obj(*args)
__get__(self, inst, owner)    # Descriptor get
__set__(self, inst, value)    # Descriptor set
__delete__(self, inst)        # Descriptor delete

CONTEXT MANAGERS
----------------
__enter__(self)               # Enter context: with obj:
__exit__(self, exc_type, exc_value, traceback)  # Exit context

ITERATOR PROTOCOL
-----------------
__iter__(self)                # Get iterator
__next__(self)                # Get next item


Best Practices and Common Patterns
===================================

1. Return NotImplemented for Unsupported Types
   -------------------------------------------
   def __add__(self, other):
       if isinstance(other, MyClass):
           return MyClass(...)
       return NotImplemented  # Not TypeError!

2. String Representations
   ----------------------
   __str__:  For humans, readable
   __repr__: For developers, unambiguous
   
   def __repr__(self):
       return f"MyClass({self.x}, {self.y})"

3. Comparison Operators
   --------------------
   Use @total_ordering to generate missing methods:
   
   from functools import total_ordering
   
   @total_ordering
   class MyClass:
       def __eq__(self, other):
           ...
       def __lt__(self, other):
           ...
       # __le__, __gt__, __ge__ generated automatically!

4. Augmented Assignment
   --------------------
   Must return self:
   
   def __iadd__(self, other):
       self.x += other.x
       return self  # Required!

5. Context Managers
   ----------------
   Always clean up in __exit__:
   
   def __exit__(self, exc_type, exc_value, traceback):
       self.cleanup()
       return False  # Propagate exceptions

6. Iterators vs Iterables
   ----------------------
   Iterable: Has __iter__, can iterate multiple times
   Iterator: Has __next__ and __iter__ (returning self)


Common Pitfalls and Solutions
==============================

Pitfall 1: Forgetting to Return NotImplemented
   Problem: Raising TypeError prevents Python from trying reflected ops
   Solution: Return NotImplemented to let Python try other.__rop__

Pitfall 2: __iadd__ Not Returning self
   Problem: Augmented assignment won't work correctly
   Solution: Always return self from augmented operators

Pitfall 3: Mutating Objects in Regular Operators
   Problem: a + b shouldn't modify a
   Solution: Regular operators create and return new objects

Pitfall 4: __exit__ Not Cleaning Up
   Problem: Resources leak when exceptions occur
   Solution: Always clean up, regardless of exc_type

Pitfall 5: Iterator Not Raising StopIteration
   Problem: Infinite loops in for loops
   Solution: Raise StopIteration when exhausted


Testing Your Implementation
============================

Each tutorial file includes demonstration functions. Run them to see examples:

$ python beginner/01_basic_arithmetic_operators.py

For exercises:

1. Edit the exercise file to implement missing methods
2. Run the file to test your implementation
3. Compare with solutions in solutions/ directory

Example workflow:
$ python exercises/beginner_exercises.py
(Fix any errors in your implementation)
$ python solutions/beginner_solutions.py
(Compare your solution)


Additional Resources
====================

Python Documentation:
- Data Model: https://docs.python.org/3/reference/datamodel.html
- Special Method Names: https://docs.python.org/3/reference/datamodel.html#special-method-names

Recommended Reading Order:
1. All beginner tutorials
2. Beginner exercises + solutions
3. All intermediate tutorials
4. Intermediate exercises + solutions
5. Advanced tutorials
6. Create your own projects!


FAQ
===

Q: Do I need to implement all operators?
A: No! Only implement operators that make sense for your class.

Q: What's the difference between __str__ and __repr__?
A: __str__ is for end users (readable), __repr__ is for developers (unambiguous).

Q: When should I use __iadd__ vs __add__?
A: __iadd__ for mutable types (modify in-place), __add__ for immutable types.

Q: Why return NotImplemented instead of raising TypeError?
A: It lets Python try the reflected operator on the other operand.

Q: Should iterators be separate from iterables?
A: Yes, for reusable containers. Use separate iterator classes or generators.

Q: When should I use context managers?
A: For resource management: files, locks, database connections, transactions.


Support and Feedback
====================

This package was created for educational purposes. Each file is heavily
commented and includes working examples. If you find errors or have
suggestions for improvement, please document them for future students.

Remember:
- Start with beginner level
- Work through examples in order
- Practice with exercises
- Compare your solutions
- Build your own projects!

Happy coding! 🐍
"""