"""
01_basic_inheritance_mro.py

BEGINNER LEVEL: Introduction to Method Resolution Order (MRO)

This file introduces the concept of Method Resolution Order (MRO) in Python
using simple single inheritance examples. MRO determines the order in which
Python searches for methods in a class hierarchy.

Learning Objectives:
- Understand what MRO is and why it matters
- Learn how to view a class's MRO
- Understand method lookup in single inheritance
- Learn the basic rules of MRO
"""

# ============================================================================
# SECTION 1: What is MRO?
# ============================================================================

"""
Method Resolution Order (MRO) is the order in which Python looks for a method
or attribute in a hierarchy of classes. When you call a method, Python:
1. Looks in the instance
2. Looks in the class
3. Looks in parent classes according to MRO
4. Raises AttributeError if not found
"""


# ============================================================================
# SECTION 2: Single Inheritance - Simple MRO
# ============================================================================

class Animal:
    """
    Base class representing a generic animal.
    This is the root of our inheritance hierarchy.
    """
    
    def __init__(self, name):
        """Initialize an animal with a name."""
        self.name = name
    
    def speak(self):
        """Generic speak method - to be overridden by subclasses."""
        return f"{self.name} makes a sound"
    
    def info(self):
        """Return basic information about the animal."""
        return f"I am an animal named {self.name}"


class Dog(Animal):
    """
    Dog class inherits from Animal.
    In single inheritance, MRO is straightforward: Dog -> Animal -> object
    """
    
    def speak(self):
        """
        Override the speak method from Animal.
        When we call dog.speak(), Python finds it here first.
        """
        return f"{self.name} says Woof!"
    
    def fetch(self):
        """Dog-specific method not present in parent class."""
        return f"{self.name} fetches the ball"


# Create a Dog instance
my_dog = Dog("Buddy")

# When we call speak(), Python follows MRO:
# 1. Check Dog class - Found! Use Dog.speak()
print(my_dog.speak())  # Output: Buddy says Woof!

# When we call info(), Python follows MRO:
# 1. Check Dog class - Not found
# 2. Check Animal class - Found! Use Animal.info()
print(my_dog.info())  # Output: I am an animal named Buddy

# When we call fetch(), Python follows MRO:
# 1. Check Dog class - Found! Use Dog.fetch()
print(my_dog.fetch())  # Output: Buddy fetches the ball


# ============================================================================
# SECTION 3: Viewing MRO
# ============================================================================

"""
Python provides two ways to view a class's MRO:
1. ClassName.__mro__ - returns a tuple
2. ClassName.mro() - returns a list
"""

print("\n" + "="*70)
print("VIEWING MRO FOR DOG CLASS")
print("="*70)

# Method 1: Using __mro__ attribute (returns tuple)
print("\nUsing Dog.__mro__:")
print(Dog.__mro__)
# Output: (<class '__main__.Dog'>, <class '__main__.Animal'>, <class 'object'>)

# Method 2: Using mro() method (returns list)
print("\nUsing Dog.mro():")
print(Dog.mro())
# Output: [<class '__main__.Dog'>, <class '__main__.Animal'>, <class 'object'>]

# More readable format
print("\nMRO in readable format:")
for i, cls in enumerate(Dog.__mro__, 1):
    print(f"{i}. {cls.__name__}")
# Output:
# 1. Dog
# 2. Animal
# 3. object


# ============================================================================
# SECTION 4: Three-Level Inheritance Chain
# ============================================================================

class LivingBeing:
    """
    Root class for all living beings.
    This demonstrates a deeper inheritance hierarchy.
    """
    
    def __init__(self, name):
        """Initialize a living being with a name."""
        self.name = name
    
    def is_alive(self):
        """All living beings are alive."""
        return True
    
    def basic_info(self):
        """Most basic information."""
        return f"A living being named {self.name}"


class Mammal(LivingBeing):
    """
    Mammal class inherits from LivingBeing.
    Adds mammal-specific characteristics.
    """
    
    def __init__(self, name, fur_color="brown"):
        """
        Initialize a mammal with name and fur color.
        We call the parent __init__ to set the name.
        """
        super().__init__(name)  # Call parent class __init__
        self.fur_color = fur_color
    
    def has_fur(self):
        """Mammals have fur."""
        return True
    
    def basic_info(self):
        """
        Override basic_info to add mammal-specific information.
        """
        return f"A mammal named {self.name} with {self.fur_color} fur"


class Cat(Mammal):
    """
    Cat class inherits from Mammal.
    This creates a three-level hierarchy: Cat -> Mammal -> LivingBeing -> object
    """
    
    def __init__(self, name, fur_color="orange", indoor=True):
        """Initialize a cat with additional indoor/outdoor attribute."""
        super().__init__(name, fur_color)  # Call parent class __init__
        self.indoor = indoor
    
    def meow(self):
        """Cat-specific method."""
        return f"{self.name} says Meow!"
    
    def basic_info(self):
        """
        Override basic_info again to add cat-specific information.
        """
        location = "indoor" if self.indoor else "outdoor"
        return f"A {location} cat named {self.name} with {self.fur_color} fur"


# Create a Cat instance
my_cat = Cat("Whiskers", "gray", True)

print("\n" + "="*70)
print("THREE-LEVEL INHERITANCE EXAMPLE")
print("="*70)

# Method lookup follows MRO
print(f"\nCalling meow(): {my_cat.meow()}")  # Found in Cat
print(f"Calling has_fur(): {my_cat.has_fur()}")  # Found in Mammal
print(f"Calling is_alive(): {my_cat.is_alive()}")  # Found in LivingBeing
print(f"Calling basic_info(): {my_cat.basic_info()}")  # Found in Cat (overridden)

# View Cat's MRO
print("\nMRO for Cat class:")
for i, cls in enumerate(Cat.__mro__, 1):
    print(f"{i}. {cls.__name__}")
# Output:
# 1. Cat
# 2. Mammal
# 3. LivingBeing
# 4. object


# ============================================================================
# SECTION 5: Understanding 'object' in MRO
# ============================================================================

"""
Every class in Python 3 inherits from 'object' by default.
'object' is the base class for all classes and provides fundamental methods
like __init__, __str__, __repr__, etc.
"""

class SimpleClass:
    """
    A simple class with no explicit parent.
    It still inherits from object automatically.
    """
    pass


print("\n" + "="*70)
print("OBJECT CLASS IN MRO")
print("="*70)

print("\nMRO for SimpleClass:")
for i, cls in enumerate(SimpleClass.__mro__, 1):
    print(f"{i}. {cls.__name__}")
# Output:
# 1. SimpleClass
# 2. object

# The object class provides basic methods
simple_instance = SimpleClass()
print(f"\nMethods inherited from object:")
print(f"__str__: {simple_instance.__str__()}")
print(f"__repr__: {simple_instance.__repr__()}")
print(f"__class__: {simple_instance.__class__}")


# ============================================================================
# SECTION 6: Method Overriding and MRO
# ============================================================================

class Vehicle:
    """Base vehicle class."""
    
    def start(self):
        """Generic start method."""
        return "Vehicle starting..."
    
    def stop(self):
        """Generic stop method."""
        return "Vehicle stopping..."
    
    def status(self):
        """Check vehicle status."""
        return "Vehicle status: operational"


class ElectricVehicle(Vehicle):
    """Electric vehicle that overrides some methods."""
    
    def start(self):
        """
        Override start method for electric vehicles.
        This method shadows Vehicle.start() in the MRO.
        """
        return "Electric vehicle starting silently..."
    
    # Note: stop() is NOT overridden, so it uses Vehicle.stop()
    
    def charge(self):
        """Electric vehicle specific method."""
        return "Charging battery..."


# Create an ElectricVehicle instance
ev = ElectricVehicle()

print("\n" + "="*70)
print("METHOD OVERRIDING WITH MRO")
print("="*70)

# start() is found in ElectricVehicle (overridden)
print(f"\nev.start(): {ev.start()}")

# stop() is NOT in ElectricVehicle, so MRO moves to Vehicle
print(f"ev.stop(): {ev.stop()}")

# charge() is found in ElectricVehicle (new method)
print(f"ev.charge(): {ev.charge()}")

# status() is NOT in ElectricVehicle, so MRO moves to Vehicle
print(f"ev.status(): {ev.status()}")


# ============================================================================
# SECTION 7: Key Takeaways
# ============================================================================

"""
KEY POINTS ABOUT MRO IN SINGLE INHERITANCE:

1. MRO determines the order Python searches for methods and attributes

2. In single inheritance, MRO is straightforward:
   Child -> Parent -> Grandparent -> ... -> object

3. Every class ultimately inherits from 'object'

4. When a method is called, Python searches:
   - First in the instance's class
   - Then up the inheritance chain according to MRO
   - Stops at the first match

5. You can view MRO using:
   - ClassName.__mro__ (tuple)
   - ClassName.mro() (list)

6. Method overriding: Child class methods shadow parent class methods
   in the MRO

7. MRO is deterministic and follows a specific order (depth-first,
   left-to-right in Python 3)
"""

print("\n" + "="*70)
print("END OF BASIC MRO TUTORIAL")
print("="*70)
print("\nNext: Learn about multiple inheritance and the diamond problem!")
