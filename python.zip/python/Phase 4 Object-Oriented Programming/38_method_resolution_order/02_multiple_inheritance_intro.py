"""
02_multiple_inheritance_intro.py

BEGINNER LEVEL: Introduction to Multiple Inheritance and MRO

This file introduces multiple inheritance in Python and shows how MRO
handles classes that inherit from multiple parents. Multiple inheritance
allows a class to inherit from more than one parent class.

Learning Objectives:
- Understand multiple inheritance syntax
- Learn how MRO works with multiple parents
- Understand the left-to-right rule
- See practical examples of multiple inheritance
"""

# ============================================================================
# SECTION 1: What is Multiple Inheritance?
# ============================================================================

"""
Multiple inheritance allows a class to inherit from more than one parent class.

Syntax:
    class Child(Parent1, Parent2, Parent3):
        pass

Python will look for methods in this order:
1. Child
2. Parent1 (and its parents)
3. Parent2 (and its parents)
4. Parent3 (and its parents)
5. object

This is a simplified view - the actual order follows C3 linearization algorithm.
"""


# ============================================================================
# SECTION 2: Simple Multiple Inheritance
# ============================================================================

class Father:
    """
    Father class with father-specific attributes and methods.
    """
    
    def __init__(self):
        """Initialize father attributes."""
        self.father_name = "John"
    
    def gardening(self):
        """Father's hobby."""
        return f"{self.father_name} enjoys gardening"
    
    def family_name(self):
        """Father's family name."""
        return "Smith family"


class Mother:
    """
    Mother class with mother-specific attributes and methods.
    """
    
    def __init__(self):
        """Initialize mother attributes."""
        self.mother_name = "Jane"
    
    def cooking(self):
        """Mother's hobby."""
        return f"{self.mother_name} enjoys cooking"
    
    def family_name(self):
        """Mother's family name - same method name as Father!"""
        return "Johnson family"


class Child(Father, Mother):
    """
    Child inherits from both Father and Mother.
    This is multiple inheritance.
    
    MRO: Child -> Father -> Mother -> object
    
    The order matters! Father is listed first, so it comes before Mother in MRO.
    """
    
    def __init__(self):
        """
        Initialize child.
        We need to explicitly call parent __init__ methods.
        """
        # Call both parent __init__ methods
        Father.__init__(self)
        Mother.__init__(self)
        self.child_name = "Tommy"
    
    def play(self):
        """Child's own method."""
        return f"{self.child_name} loves to play"


# Create a Child instance
tommy = Child()

print("="*70)
print("SIMPLE MULTIPLE INHERITANCE")
print("="*70)

# Access methods from both parents
print(f"\n{tommy.gardening()}")  # From Father
print(f"{tommy.cooking()}")      # From Mother
print(f"{tommy.play()}")          # From Child

# What about family_name()? Both parents have this method!
# Python uses MRO: Child -> Father -> Mother -> object
# It finds family_name() in Father first, so that's what gets called
print(f"\nCalling family_name(): {tommy.family_name()}")
# Output: Smith family (from Father, not Johnson from Mother!)

# View the MRO
print("\nMRO for Child class:")
for i, cls in enumerate(Child.__mro__, 1):
    print(f"{i}. {cls.__name__}")
# Output:
# 1. Child
# 2. Father
# 3. Mother
# 4. object


# ============================================================================
# SECTION 3: Left-to-Right Rule
# ============================================================================

"""
When a class inherits from multiple parents, Python searches them
from LEFT to RIGHT as they are listed in the class definition.

class Child(First, Second, Third):  # Searches: First, then Second, then Third
"""


class A:
    """First parent class."""
    
    def method(self):
        return "Method from A"
    
    def method_a(self):
        return "Specific to A"


class B:
    """Second parent class."""
    
    def method(self):
        return "Method from B"
    
    def method_b(self):
        return "Specific to B"


class C1(A, B):
    """
    C1 inherits from A and B in that order.
    MRO: C1 -> A -> B -> object
    """
    pass


class C2(B, A):
    """
    C2 inherits from B and A in that order.
    MRO: C2 -> B -> A -> object
    
    Notice: Same parents, different order!
    """
    pass


print("\n" + "="*70)
print("LEFT-TO-RIGHT RULE DEMONSTRATION")
print("="*70)

# Create instances
c1 = C1()
c2 = C2()

# Both have method() in parent classes A and B
# Which one gets called depends on the order in class definition
print(f"\nc1.method() - A listed first: {c1.method()}")  # Method from A
print(f"c2.method() - B listed first: {c2.method()}")    # Method from B

# View MROs to see the difference
print("\nMRO for C1 (A, B):")
for i, cls in enumerate(C1.__mro__, 1):
    print(f"{i}. {cls.__name__}")

print("\nMRO for C2 (B, A):")
for i, cls in enumerate(C2.__mro__, 1):
    print(f"{i}. {cls.__name__}")


# ============================================================================
# SECTION 4: Practical Example - Multiple Capabilities
# ============================================================================

"""
Multiple inheritance is useful for creating classes that combine
multiple capabilities or "mixins".
"""


class Swimmer:
    """Provides swimming capability."""
    
    def swim(self):
        return "I can swim!"
    
    def swim_speed(self):
        return "Swimming at 5 mph"


class Flyer:
    """Provides flying capability."""
    
    def fly(self):
        return "I can fly!"
    
    def fly_speed(self):
        return "Flying at 30 mph"


class Walker:
    """Provides walking capability."""
    
    def walk(self):
        return "I can walk!"
    
    def walk_speed(self):
        return "Walking at 3 mph"


class Duck(Swimmer, Flyer, Walker):
    """
    A duck can swim, fly, and walk!
    It inherits all three capabilities through multiple inheritance.
    
    MRO: Duck -> Swimmer -> Flyer -> Walker -> object
    """
    
    def __init__(self, name):
        self.name = name
    
    def introduce(self):
        return f"I'm {self.name}, a duck!"


class Penguin(Swimmer, Walker):
    """
    A penguin can swim and walk, but not fly.
    It only inherits swimming and walking capabilities.
    
    MRO: Penguin -> Swimmer -> Walker -> object
    """
    
    def __init__(self, name):
        self.name = name
    
    def introduce(self):
        return f"I'm {self.name}, a penguin!"


class Chicken(Walker, Flyer):
    """
    A chicken can walk and fly (a little).
    
    MRO: Chicken -> Walker -> Flyer -> object
    """
    
    def __init__(self, name):
        self.name = name
    
    def introduce(self):
        return f"I'm {self.name}, a chicken!"
    
    def fly(self):
        """Override fly to be more realistic."""
        return "I can flutter a bit!"


print("\n" + "="*70)
print("PRACTICAL EXAMPLE: MULTIPLE CAPABILITIES")
print("="*70)

# Create instances
donald = Duck("Donald")
happy_feet = Penguin("Happy Feet")
clucky = Chicken("Clucky")

# Duck can do everything
print(f"\n{donald.introduce()}")
print(f"  {donald.swim()}")
print(f"  {donald.fly()}")
print(f"  {donald.walk()}")

# Penguin can swim and walk
print(f"\n{happy_feet.introduce()}")
print(f"  {happy_feet.swim()}")
print(f"  {happy_feet.walk()}")
# happy_feet.fly() would raise AttributeError - penguins don't inherit Flyer!

# Chicken can walk and fly (but overrides fly)
print(f"\n{clucky.introduce()}")
print(f"  {clucky.walk()}")
print(f"  {clucky.fly()}")  # Uses overridden version

# View their MROs
print("\nMRO for Duck:")
for i, cls in enumerate(Duck.__mro__, 1):
    print(f"{i}. {cls.__name__}")

print("\nMRO for Penguin:")
for i, cls in enumerate(Penguin.__mro__, 1):
    print(f"{i}. {cls.__name__}")

print("\nMRO for Chicken:")
for i, cls in enumerate(Chicken.__mro__, 1):
    print(f"{i}. {cls.__name__}")


# ============================================================================
# SECTION 5: Method Name Conflicts
# ============================================================================

"""
When multiple parent classes have methods with the same name,
MRO determines which one gets called.
"""


class Teacher:
    """Teacher class."""
    
    def teach(self):
        return "Teaching students"
    
    def work(self):
        return "Working as a teacher"
    
    def salary(self):
        return "$50,000"


class Engineer:
    """Engineer class."""
    
    def design(self):
        return "Designing systems"
    
    def work(self):
        return "Working as an engineer"
    
    def salary(self):
        return "$80,000"


class TeacherEngineer(Teacher, Engineer):
    """
    Someone who is both a teacher and an engineer.
    
    MRO: TeacherEngineer -> Teacher -> Engineer -> object
    
    When there are conflicts (work, salary), Teacher's version is used
    because it comes first in the MRO.
    """
    
    def introduce(self):
        return "I'm both a teacher and an engineer!"


te = TeacherEngineer()

print("\n" + "="*70)
print("METHOD NAME CONFLICTS")
print("="*70)

print(f"\n{te.introduce()}")
print(f"{te.teach()}")   # From Teacher
print(f"{te.design()}")  # From Engineer

# Conflicting methods - which one is used?
print(f"\nCalling work(): {te.work()}")      # Teacher.work() - Teacher comes first
print(f"Calling salary(): {te.salary()}")    # Teacher.salary() - Teacher comes first

print("\nMRO for TeacherEngineer:")
for i, cls in enumerate(TeacherEngineer.__mro__, 1):
    print(f"{i}. {cls.__name__}")


# ============================================================================
# SECTION 6: Accessing Shadowed Methods
# ============================================================================

"""
If you need to access a method that is shadowed in the MRO,
you can call it directly from the parent class.
"""


class Engineer2(Engineer, Teacher):
    """
    Same parents as TeacherEngineer but in DIFFERENT ORDER.
    
    MRO: Engineer2 -> Engineer -> Teacher -> object
    
    Now Engineer comes before Teacher in MRO!
    """
    
    def introduce(self):
        return "I'm primarily an engineer who also teaches!"
    
    def full_salary_info(self):
        """
        Demonstrate accessing both parent methods directly.
        """
        # Get Engineer's salary (first in MRO)
        engineer_salary = Engineer.salary(self)
        
        # Get Teacher's salary (second in MRO, but shadowed)
        teacher_salary = Teacher.salary(self)
        
        return f"Engineer salary: {engineer_salary}, Teacher salary: {teacher_salary}"


e2 = Engineer2()

print("\n" + "="*70)
print("ACCESSING SHADOWED METHODS")
print("="*70)

print(f"\n{e2.introduce()}")
print(f"Default work(): {e2.work()}")  # Engineer.work() - Engineer comes first

# Access both salary methods directly
print(f"\n{e2.full_salary_info()}")

print("\nMRO for Engineer2:")
for i, cls in enumerate(Engineer2.__mro__, 1):
    print(f"{i}. {cls.__name__}")


# ============================================================================
# SECTION 7: Key Takeaways
# ============================================================================

"""
KEY POINTS ABOUT MULTIPLE INHERITANCE:

1. Multiple inheritance allows a class to inherit from multiple parents:
   class Child(Parent1, Parent2, Parent3): pass

2. MRO searches parents from LEFT to RIGHT as listed in the class definition

3. When multiple parents have methods with the same name, the first parent
   in the list takes precedence

4. You can access shadowed methods by calling them directly on the parent class:
   ParentClass.method(self)

5. Multiple inheritance is useful for combining different capabilities
   (often called "mixins")

6. Order of parent classes matters! Different orders create different MROs

7. Use ClassName.__mro__ or ClassName.mro() to inspect the method resolution order

CAUTION:
- Multiple inheritance can be complex and confusing
- The diamond problem (coming next) is a classic issue
- Use carefully and document your MRO intentions
- Consider composition over inheritance for complex scenarios
"""

print("\n" + "="*70)
print("END OF MULTIPLE INHERITANCE INTRODUCTION")
print("="*70)
print("\nNext: Learn about the diamond problem and how Python solves it!")
