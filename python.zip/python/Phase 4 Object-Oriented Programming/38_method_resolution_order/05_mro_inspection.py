"""
05_mro_inspection.py

INTERMEDIATE LEVEL: MRO Inspection Tools and Techniques

This file covers all the tools and techniques for inspecting and analyzing
Method Resolution Order in Python. Understanding how to inspect MRO is crucial
for debugging complex inheritance hierarchies.

Learning Objectives:
- Master MRO inspection methods
- Learn to analyze inheritance hierarchies
- Debug MRO-related issues
- Use introspection tools effectively
- Visualize class hierarchies
"""

# ============================================================================
# SECTION 1: Basic MRO Inspection Methods
# ============================================================================

"""
Python provides several ways to inspect a class's MRO:

1. ClassName.__mro__     - Returns tuple of classes in MRO
2. ClassName.mro()       - Returns list of classes in MRO
3. instance.__class__    - Get the class of an instance
4. isinstance()          - Check if instance is of a type
5. issubclass()          - Check if class is a subclass
"""


class A:
    """Base class A."""
    pass


class B(A):
    """B inherits from A."""
    pass


class C(A):
    """C inherits from A."""
    pass


class D(B, C):
    """D inherits from B and C (diamond)."""
    pass


print("="*70)
print("BASIC MRO INSPECTION METHODS")
print("="*70)

# Method 1: __mro__ attribute (returns tuple)
print("\n1. Using __mro__ attribute:")
print(f"D.__mro__ = {D.__mro__}")
print(f"Type: {type(D.__mro__)}")  # tuple

# Method 2: mro() method (returns list)
print("\n2. Using mro() method:")
print(f"D.mro() = {D.mro()}")
print(f"Type: {type(D.mro())}")  # list

# Method 3: Get class from instance
print("\n3. Getting class from instance:")
d = D()
print(f"type(d) = {type(d)}")
print(f"d.__class__ = {d.__class__}")
print(f"d.__class__.__mro__ = {d.__class__.__mro__}")

# Method 4: isinstance checks
print("\n4. isinstance() checks:")
print(f"isinstance(d, D) = {isinstance(d, D)}")
print(f"isinstance(d, B) = {isinstance(d, B)}")
print(f"isinstance(d, C) = {isinstance(d, C)}")
print(f"isinstance(d, A) = {isinstance(d, A)}")
print(f"isinstance(d, object) = {isinstance(d, object)}")

# Method 5: issubclass checks
print("\n5. issubclass() checks:")
print(f"issubclass(D, B) = {issubclass(D, B)}")
print(f"issubclass(D, C) = {issubclass(D, C)}")
print(f"issubclass(D, A) = {issubclass(D, A)}")
print(f"issubclass(B, A) = {issubclass(B, A)}")


# ============================================================================
# SECTION 2: Formatting MRO Output
# ============================================================================

"""
Creating readable MRO displays is helpful for understanding and debugging.
"""


def print_mro_simple(cls):
    """Print MRO in simple format."""
    print(f"\nMRO for {cls.__name__}:")
    for i, c in enumerate(cls.__mro__, 1):
        print(f"  {i}. {c.__name__}")


def print_mro_detailed(cls):
    """Print MRO with module information."""
    print(f"\nDetailed MRO for {cls.__name__}:")
    for i, c in enumerate(cls.__mro__, 1):
        module = c.__module__ if hasattr(c, '__module__') else 'unknown'
        print(f"  {i}. {c.__name__:<20} (from {module})")


def print_mro_arrows(cls):
    """Print MRO with arrow notation."""
    mro_names = [c.__name__ for c in cls.__mro__]
    print(f"\nMRO Chain: {' -> '.join(mro_names)}")


def print_mro_tree(cls, indent=0):
    """Print inheritance tree (not true MRO, but helpful)."""
    print("  " * indent + f"{cls.__name__}")
    for base in cls.__bases__:
        if base != object:  # Skip object for cleaner display
            print_mro_tree(base, indent + 1)


print("\n" + "="*70)
print("FORMATTING MRO OUTPUT")
print("="*70)

print_mro_simple(D)
print_mro_detailed(D)
print_mro_arrows(D)
print("\nInheritance Tree:")
print_mro_tree(D)


# ============================================================================
# SECTION 3: Inspecting Method Resolution
# ============================================================================

"""
Finding where a method is defined in the MRO chain.
"""


class Vehicle:
    """Base vehicle class."""
    
    def start(self):
        return "Vehicle starting"
    
    def stop(self):
        return "Vehicle stopping"
    
    def info(self):
        return "Generic vehicle"


class Car(Vehicle):
    """Car class."""
    
    def start(self):
        return "Car engine starting"
    
    def honk(self):
        return "Car honking"


class ElectricCar(Car):
    """Electric car class."""
    
    def start(self):
        return "Electric car starting silently"
    
    def charge(self):
        return "Charging battery"


def find_method_in_mro(cls, method_name):
    """
    Find where a method is defined in the MRO.
    
    Args:
        cls: The class to search
        method_name: Name of the method to find
    
    Returns:
        The class where the method is defined, or None
    """
    for c in cls.__mro__:
        if method_name in c.__dict__:
            return c
    return None


def analyze_method(cls, method_name):
    """
    Provide detailed analysis of a method's resolution.
    """
    print(f"\nAnalyzing method '{method_name}' in {cls.__name__}:")
    
    # Find where it's defined
    defined_in = find_method_in_mro(cls, method_name)
    
    if defined_in:
        print(f"  Defined in: {defined_in.__name__}")
        print(f"  Position in MRO: {cls.__mro__.index(defined_in) + 1}")
        
        # Show if it's overridden
        overridden_in = []
        for c in cls.__mro__[cls.__mro__.index(defined_in) + 1:]:
            if method_name in c.__dict__:
                overridden_in.append(c.__name__)
        
        if overridden_in:
            print(f"  Overrides: {', '.join(overridden_in)}")
        else:
            print(f"  Not overridden")
    else:
        print(f"  Not found in MRO")


def list_all_methods(cls):
    """
    List all methods available to a class through MRO.
    """
    methods = {}
    
    # Walk through MRO backwards to build method dictionary
    for c in reversed(cls.__mro__):
        for name in dir(c):
            if not name.startswith('_'):  # Skip private/magic methods
                attr = getattr(c, name)
                if callable(attr):
                    methods[name] = c.__name__
    
    return methods


print("\n" + "="*70)
print("INSPECTING METHOD RESOLUTION")
print("="*70)

print_mro_simple(ElectricCar)

# Analyze specific methods
analyze_method(ElectricCar, 'start')
analyze_method(ElectricCar, 'stop')
analyze_method(ElectricCar, 'honk')
analyze_method(ElectricCar, 'charge')
analyze_method(ElectricCar, 'nonexistent')

# List all methods
print("\n" + "-"*70)
print("All methods available to ElectricCar:")
all_methods = list_all_methods(ElectricCar)
for method, defined_in in sorted(all_methods.items()):
    print(f"  {method:<20} from {defined_in}")


# ============================================================================
# SECTION 4: Inspecting Class Attributes
# ============================================================================

"""
Understanding __dict__, __bases__, and other class attributes.
"""


class Parent1:
    """First parent class."""
    class_var_1 = "from Parent1"
    
    def __init__(self):
        self.instance_var = "parent1 instance"


class Parent2:
    """Second parent class."""
    class_var_2 = "from Parent2"
    
    def __init__(self):
        self.instance_var = "parent2 instance"


class Child(Parent1, Parent2):
    """Child of both parents."""
    child_class_var = "from Child"
    
    def __init__(self):
        super().__init__()
        self.child_instance_var = "child instance"


def inspect_class_attributes(cls):
    """Inspect various class attributes."""
    print(f"\nInspecting {cls.__name__}:")
    
    # Direct attributes defined in this class
    print(f"\n  1. __dict__ (attributes defined in {cls.__name__}):")
    for key, value in cls.__dict__.items():
        if not key.startswith('_'):
            print(f"     {key}: {value}")
    
    # Direct parent classes
    print(f"\n  2. __bases__ (direct parents):")
    for base in cls.__bases__:
        print(f"     {base.__name__}")
    
    # All parent classes
    print(f"\n  3. __mro__ (all parents in order):")
    for i, c in enumerate(cls.__mro__, 1):
        print(f"     {i}. {c.__name__}")
    
    # Class name and module
    print(f"\n  4. Metadata:")
    print(f"     __name__: {cls.__name__}")
    print(f"     __module__: {cls.__module__}")
    print(f"     __qualname__: {cls.__qualname__}")


print("\n" + "="*70)
print("INSPECTING CLASS ATTRIBUTES")
print("="*70)

inspect_class_attributes(Child)

# Instance vs class attributes
print("\n" + "-"*70)
print("Instance vs Class attributes:")
child = Child()
print(f"\nInstance __dict__: {child.__dict__}")
print(f"Class __dict__ (filtered): {[k for k in Child.__dict__.keys() if not k.startswith('_')]}")


# ============================================================================
# SECTION 5: Advanced Inspection with inspect Module
# ============================================================================

"""
Python's inspect module provides powerful introspection capabilities.
"""

import inspect


class Base5:
    """Base class for inspection."""
    
    def method1(self):
        """Method 1 in Base."""
        pass


class Child5A(Base5):
    """First child."""
    
    def method2(self):
        """Method 2 in Child5A."""
        pass


class Child5B(Base5):
    """Second child."""
    
    def method3(self):
        """Method 3 in Child5B."""
        pass


class GrandChild5(Child5A, Child5B):
    """Grandchild combining both."""
    
    def method4(self):
        """Method 4 in GrandChild."""
        pass


def inspect_with_module(cls):
    """Use inspect module for detailed analysis."""
    print(f"\nDetailed inspection of {cls.__name__} using inspect module:")
    
    # Get MRO
    print(f"\n  1. MRO via inspect:")
    print(f"     {inspect.getmro(cls)}")
    
    # Get all members
    print(f"\n  2. All members:")
    for name, value in inspect.getmembers(cls):
        if not name.startswith('_') and not inspect.isbuiltin(value):
            member_type = "method" if inspect.isfunction(value) or inspect.ismethod(value) else "attribute"
            print(f"     {name}: {member_type}")
    
    # Get methods only
    print(f"\n  3. Methods only:")
    for name, method in inspect.getmembers(cls, predicate=inspect.isfunction):
        if not name.startswith('_'):
            # Find where it's defined
            defined_in = find_method_in_mro(cls, name)
            print(f"     {name}() from {defined_in.__name__}")
    
    # Check if it's a class
    print(f"\n  4. Type checks:")
    print(f"     inspect.isclass(): {inspect.isclass(cls)}")
    
    # Get source (if available)
    try:
        print(f"\n  5. Source location:")
        print(f"     File: {inspect.getfile(cls)}")
        print(f"     Line: {inspect.getsourcelines(cls)[1]}")
    except:
        print(f"     Source not available")


print("\n" + "="*70)
print("ADVANCED INSPECTION WITH INSPECT MODULE")
print("="*70)

inspect_with_module(GrandChild5)


# ============================================================================
# SECTION 6: MRO Comparison Tool
# ============================================================================

"""
Compare MROs of different class hierarchies.
"""


def compare_mros(*classes):
    """
    Compare MROs of multiple classes side by side.
    """
    print("\nMRO Comparison:")
    print("-" * 70)
    
    # Get all MROs
    mros = {cls.__name__: cls.__mro__ for cls in classes}
    
    # Find max length
    max_len = max(len(mro) for mro in mros.values())
    
    # Print header
    header = "Position  "
    for name in mros.keys():
        header += f"{name:<20}"
    print(header)
    print("-" * 70)
    
    # Print each position
    for i in range(max_len):
        row = f"{i+1:<10}"
        for mro in mros.values():
            if i < len(mro):
                row += f"{mro[i].__name__:<20}"
            else:
                row += " " * 20
        print(row)


print("\n" + "="*70)
print("MRO COMPARISON TOOL")
print("="*70)

# Create some classes to compare
class X: pass
class Y: pass
class Z: pass

class AB(X, Y): pass
class BA(Y, X): pass
class ABC(X, Y, Z): pass

compare_mros(AB, BA, ABC)


# ============================================================================
# SECTION 7: MRO Validation Tool
# ============================================================================

"""
Check for common MRO issues and validate inheritance hierarchies.
"""


def validate_mro(cls):
    """
    Validate MRO and check for common issues.
    """
    print(f"\nValidating MRO for {cls.__name__}:")
    issues = []
    warnings = []
    
    # Check 1: MRO length
    mro_len = len(cls.__mro__)
    print(f"  MRO length: {mro_len}")
    if mro_len > 10:
        warnings.append(f"Long MRO ({mro_len} classes) - may be complex")
    
    # Check 2: Diamond inheritance
    seen = set()
    diamonds = []
    for c in cls.__mro__[1:-1]:  # Skip cls and object
        for base in c.__bases__:
            if base in seen and base != object:
                diamonds.append((c.__name__, base.__name__))
            seen.add(base)
    
    if diamonds:
        print(f"  Diamond inheritance detected:")
        for child, parent in diamonds:
            print(f"    {child} and others inherit from {parent}")
    
    # Check 3: Consistent super() usage
    print(f"  Checking super() usage...")
    no_super = []
    for c in cls.__mro__[:-1]:  # Skip object
        if '__init__' in c.__dict__:
            source = None
            try:
                source = inspect.getsource(c.__init__)
                if 'super()' not in source and 'super(' not in source:
                    no_super.append(c.__name__)
            except:
                pass
    
    if no_super:
        warnings.append(f"Classes without super() in __init__: {', '.join(no_super)}")
    
    # Check 4: Method conflicts
    method_sources = {}
    for c in cls.__mro__:
        for name in c.__dict__:
            if not name.startswith('_') and callable(getattr(c, name)):
                if name in method_sources:
                    # Method is overridden
                    pass
                else:
                    method_sources[name] = c.__name__
    
    # Summary
    print(f"\n  Summary:")
    if not issues and not warnings:
        print(f"    ✓ No issues found")
    else:
        if issues:
            print(f"    ✗ Issues:")
            for issue in issues:
                print(f"      - {issue}")
        if warnings:
            print(f"    ⚠ Warnings:")
            for warning in warnings:
                print(f"      - {warning}")


print("\n" + "="*70)
print("MRO VALIDATION TOOL")
print("="*70)

validate_mro(D)
validate_mro(GrandChild5)


# ============================================================================
# SECTION 8: Creating Custom MRO Inspector
# ============================================================================

"""
A comprehensive custom inspector class.
"""


class MROInspector:
    """
    Comprehensive MRO inspection tool.
    """
    
    def __init__(self, cls):
        """Initialize with a class to inspect."""
        self.cls = cls
        self.mro = cls.__mro__
    
    def print_summary(self):
        """Print a summary of the MRO."""
        print(f"\n{'='*70}")
        print(f"MRO INSPECTION SUMMARY FOR: {self.cls.__name__}")
        print(f"{'='*70}")
        
        print(f"\n1. MRO Chain ({len(self.mro)} classes):")
        print(f"   {' -> '.join(c.__name__ for c in self.mro)}")
        
        print(f"\n2. Direct Parents:")
        for base in self.cls.__bases__:
            print(f"   - {base.__name__}")
        
        print(f"\n3. All Ancestors:")
        ancestors = set(self.mro) - {self.cls, object}
        for ancestor in ancestors:
            print(f"   - {ancestor.__name__}")
    
    def find_method(self, method_name):
        """Find where a method is defined."""
        for c in self.mro:
            if method_name in c.__dict__:
                return c
        return None
    
    def list_methods(self):
        """List all methods with their sources."""
        methods = {}
        for c in reversed(self.mro):
            for name in c.__dict__:
                if not name.startswith('_') and callable(getattr(c, name)):
                    methods[name] = c.__name__
        return methods
    
    def check_diamond(self):
        """Check for diamond inheritance patterns."""
        diamonds = []
        for i, c1 in enumerate(self.mro[:-1]):
            for c2 in self.mro[i+1:]:
                # Check if they share a common base
                common = set(c1.__mro__) & set(c2.__mro__)
                common -= {object}
                if common:
                    diamonds.append((c1.__name__, c2.__name__, 
                                   [c.__name__ for c in common]))
        return diamonds
    
    def full_report(self):
        """Generate a full inspection report."""
        self.print_summary()
        
        print(f"\n4. Methods Available:")
        methods = self.list_methods()
        for method, source in sorted(methods.items()):
            print(f"   - {method}() from {source}")
        
        diamonds = self.check_diamond()
        if diamonds:
            print(f"\n5. Diamond Patterns:")
            for c1, c2, common in diamonds:
                print(f"   - {c1} and {c2} share: {', '.join(common)}")
        
        print(f"\n{'='*70}\n")


print("\n" + "="*70)
print("CUSTOM MRO INSPECTOR")
print("="*70)

inspector = MROInspector(ElectricCar)
inspector.full_report()


# ============================================================================
# SECTION 9: Key Takeaways
# ============================================================================

"""
KEY POINTS ABOUT MRO INSPECTION:

1. Basic Tools:
   - __mro__ attribute (tuple)
   - mro() method (list)
   - isinstance() and issubclass()

2. Method Resolution:
   - Use __dict__ to find where methods are defined
   - Walk through MRO to find method sources
   - Check for overridden methods

3. Class Attributes:
   - __dict__: attributes defined in this class
   - __bases__: direct parent classes
   - __mro__: complete method resolution order

4. inspect Module:
   - getmro(): get MRO
   - getmembers(): get all attributes
   - getsource(): get source code
   - isclass(), ismethod(), etc.

5. Validation:
   - Check MRO length and complexity
   - Detect diamond patterns
   - Verify super() usage
   - Find method conflicts

6. Custom Tools:
   - Create inspectors for your needs
   - Build comparison tools
   - Generate reports
   - Visualize hierarchies

7. Best Practices:
   - Inspect early and often
   - Document complex hierarchies
   - Use validation tools
   - Test thoroughly
   - Keep hierarchies simple when possible
"""

print("\n" + "="*70)
print("END OF MRO INSPECTION TUTORIAL")
print("="*70)
print("\nNext: Learn about C3 linearization algorithm!")
