"""
07_complex_hierarchies.py

ADVANCED LEVEL: Complex Inheritance Hierarchies

This file explores complex real-world inheritance patterns, advanced MRO
scenarios, and best practices for managing complicated class hierarchies.

Learning Objectives:
- Handle deep inheritance hierarchies
- Work with mixin classes
- Understand metaclass MRO
- Design scalable class structures
- Avoid common pitfalls
"""

# ============================================================================
# SECTION 1: Deep Inheritance Chains
# ============================================================================

"""
Deep inheritance chains can become complex. Understanding how MRO
handles them is crucial for debugging and design.
"""


class Level0:
    """Root level."""
    
    def method(self):
        return "Level0"


class Level1(Level0):
    """First level down."""
    
    def level1_method(self):
        return "Level1"


class Level2(Level1):
    """Second level down."""
    
    def level2_method(self):
        return "Level2"


class Level3(Level2):
    """Third level down."""
    
    def level3_method(self):
        return "Level3"


class Level4(Level3):
    """Fourth level down."""
    
    def level4_method(self):
        return "Level4"
    
    def method(self):
        """Override method from Level0."""
        return f"Level4 (overrides {super().method()})"


print("="*70)
print("DEEP INHERITANCE CHAINS")
print("="*70)

obj = Level4()
print(f"\nMRO depth: {len(Level4.__mro__)}")
print(f"MRO: {' -> '.join(c.__name__ for c in Level4.__mro__)}")
print(f"\nCalling method(): {obj.method()}")


# ============================================================================
# SECTION 2: Mixin Pattern
# ============================================================================

"""
Mixins are classes designed to add specific functionality when mixed
into other classes. They're a key pattern in complex hierarchies.
"""


class JSONSerializableMixin:
    """Mixin to add JSON serialization capability."""
    
    def to_json(self):
        """Convert object to JSON representation."""
        import json
        return json.dumps(self.__dict__)
    
    def from_json(self, json_str):
        """Load object from JSON."""
        import json
        self.__dict__.update(json.loads(json_str))
        return self


class LoggingMixin:
    """Mixin to add logging capability."""
    
    def log(self, message, level="INFO"):
        """Log a message."""
        return f"[{level}] {self.__class__.__name__}: {message}"


class ValidationMixin:
    """Mixin for data validation."""
    
    def validate(self):
        """Validate object state."""
        required_attrs = getattr(self, '_required_attrs', [])
        for attr in required_attrs:
            if not hasattr(self, attr):
                return False, f"Missing required attribute: {attr}"
        return True, "Valid"


class User(JSONSerializableMixin, LoggingMixin, ValidationMixin):
    """
    User class with mixed-in functionality.
    
    MRO: User -> JSONSerializableMixin -> LoggingMixin -> 
         ValidationMixin -> object
    """
    
    _required_attrs = ['username', 'email']
    
    def __init__(self, username, email):
        self.username = username
        self.email = email
    
    def display(self):
        """Display user info."""
        return f"User: {self.username} ({self.email})"


print("\n" + "="*70)
print("MIXIN PATTERN")
print("="*70)

user = User("alice", "alice@example.com")
print(f"\nUser: {user.display()}")
print(f"JSON: {user.to_json()}")
print(f"Log: {user.log('User created')}")
print(f"Validation: {user.validate()}")

print(f"\nMRO: {' -> '.join(c.__name__ for c in User.__mro__)}")


# ============================================================================
# SECTION 3: Multiple Mixin Combinations
# ============================================================================

"""
Combining multiple mixins with various base classes.
"""


class CacheableMixin:
    """Mixin for caching."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._cache = {}
    
    def get_cached(self, key):
        return self._cache.get(key)
    
    def set_cached(self, key, value):
        self._cache[key] = value


class TimestampMixin:
    """Mixin for timestamps."""
    
    def __init__(self, *args, **kwargs):
        from datetime import datetime
        super().__init__(*args, **kwargs)
        self.created_at = datetime.now()
    
    def age(self):
        from datetime import datetime
        return (datetime.now() - self.created_at).total_seconds()


class BaseModel:
    """Base model class."""
    
    def __init__(self, id=None):
        self.id = id


class CachedModel(CacheableMixin, BaseModel):
    """Model with caching."""
    pass


class TimestampedModel(TimestampMixin, BaseModel):
    """Model with timestamps."""
    pass


class FullFeaturedModel(CacheableMixin, TimestampMixin, BaseModel):
    """
    Model with both caching and timestamps.
    
    Diamond structure:
               BaseModel
              /    |    \
    Cacheable  Timestamp  (direct)
              \    |    /
           FullFeaturedModel
    """
    
    def __init__(self, id=None):
        super().__init__(id=id)


print("\n" + "="*70)
print("MULTIPLE MIXIN COMBINATIONS")
print("="*70)

model = FullFeaturedModel(id=123)
model.set_cached('key1', 'value1')

print(f"\nModel ID: {model.id}")
print(f"Cached value: {model.get_cached('key1')}")
print(f"Age: {model.age():.2f} seconds")

print(f"\nMRO: {' -> '.join(c.__name__ for c in FullFeaturedModel.__mro__)}")


# ============================================================================
# SECTION 4: Abstract Base Classes with MRO
# ============================================================================

"""
Using ABC (Abstract Base Classes) in complex hierarchies.
"""

from abc import ABC, abstractmethod


class Shape(ABC):
    """Abstract base shape."""
    
    @abstractmethod
    def area(self):
        """Calculate area."""
        pass
    
    @abstractmethod
    def perimeter(self):
        """Calculate perimeter."""
        pass


class ColorMixin:
    """Mixin for colored shapes."""
    
    def __init__(self, *args, color="black", **kwargs):
        super().__init__(*args, **kwargs)
        self.color = color
    
    def describe_color(self):
        return f"Color: {self.color}"


class Rectangle(ColorMixin, Shape):
    """Concrete rectangle class."""
    
    def __init__(self, width, height, color="black"):
        super().__init__(color=color)
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height
    
    def perimeter(self):
        return 2 * (self.width + self.height)


print("\n" + "="*70)
print("ABSTRACT BASE CLASSES WITH MRO")
print("="*70)

rect = Rectangle(10, 5, color="red")
print(f"\nRectangle: {rect.width}x{rect.height}")
print(f"Area: {rect.area()}")
print(f"Perimeter: {rect.perimeter()}")
print(f"{rect.describe_color()}")

print(f"\nMRO: {' -> '.join(c.__name__ for c in Rectangle.__mro__)}")


# ============================================================================
# SECTION 5: Plugin Architecture
# ============================================================================

"""
Using MRO for plugin systems.
"""


class PluginBase:
    """Base class for all plugins."""
    
    _plugins = []
    
    def __init_subclass__(cls, **kwargs):
        """Register plugins automatically."""
        super().__init_subclass__(**kwargs)
        PluginBase._plugins.append(cls)
    
    def process(self, data):
        """Process data - to be overridden."""
        return data


class ValidationPlugin(PluginBase):
    """Plugin for validation."""
    
    def process(self, data):
        print(f"  Validating: {data}")
        return super().process(data)


class TransformPlugin(PluginBase):
    """Plugin for transformation."""
    
    def process(self, data):
        print(f"  Transforming: {data}")
        data = data.upper() if isinstance(data, str) else data
        return super().process(data)


class LoggingPlugin(PluginBase):
    """Plugin for logging."""
    
    def process(self, data):
        print(f"  Logging: {data}")
        return super().process(data)


class DataProcessor(ValidationPlugin, TransformPlugin, LoggingPlugin):
    """
    Combined processor using multiple plugins.
    
    MRO determines processing order!
    """
    pass


print("\n" + "="*70)
print("PLUGIN ARCHITECTURE")
print("="*70)

processor = DataProcessor()
print(f"\nMRO: {' -> '.join(c.__name__ for c in DataProcessor.__mro__)}")

print(f"\nProcessing data:")
result = processor.process("hello world")
print(f"Final result: {result}")


# ============================================================================
# SECTION 6: Avoiding Common Pitfalls
# ============================================================================

"""
Common mistakes in complex hierarchies and how to avoid them.
"""

# PITFALL 1: Fragile Base Class Problem
class FragileBase:
    """Base class that might change."""
    
    def __init__(self):
        self.value = 0
        self.setup()  # Calls setup during init
    
    def setup(self):
        """Setup method."""
        self.value = 1


class FragileChild(FragileBase):
    """Child that overrides setup."""
    
    def setup(self):
        """Child's setup - but __init__ not called yet!"""
        # This runs during FragileBase.__init__
        # Before FragileChild.__init__ is called
        # Can cause issues if we try to access child's attributes
        super().setup()


# PITFALL 2: Inconsistent MRO from parent order
# (See previous sections for examples)

# PITFALL 3: Forgetting super() in mixins
class BadMixin:
    """Mixin that breaks the chain."""
    
    def __init__(self):
        # No super().__init__() call!
        # This breaks cooperative inheritance
        self.mixin_value = "bad"


# PITFALL 4: Mixin dependencies
class DependentMixin:
    """Mixin that depends on other classes."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Assumes self.id exists from another class
        # This is fragile!
        if not hasattr(self, 'id'):
            raise AttributeError("DependentMixin requires an 'id' attribute")


print("\n" + "="*70)
print("COMMON PITFALLS")
print("="*70)

print("""
1. Fragile Base Class Problem:
   - Base class calls overridden methods in __init__
   - Child's __init__ not called yet
   - Can access unitialized attributes
   - Solution: Be careful with method calls in __init__

2. Inconsistent MRO:
   - Parent order conflicts
   - Python raises TypeError
   - Solution: Reorder parents or restructure

3. Forgetting super():
   - Breaks cooperative inheritance
   - Classes in MRO chain not initialized
   - Solution: Always call super().__init__()

4. Mixin Dependencies:
   - Mixin assumes attributes from other classes
   - Fragile and error-prone
   - Solution: Document dependencies clearly

5. Deep Hierarchies:
   - Hard to understand and maintain
   - Many levels of indirection
   - Solution: Favor composition over deep inheritance
""")


# ============================================================================
# SECTION 7: Best Practices
# ============================================================================

"""
Best practices for complex hierarchies.
"""

print("\n" + "="*70)
print("BEST PRACTICES FOR COMPLEX HIERARCHIES")
print("="*70)

print("""
1. Design Principles:
   - Keep hierarchies shallow when possible
   - Use composition over inheritance for complex functionality
   - Make mixins independent and reusable
   - Document MRO intentions

2. Mixin Design:
   - Always call super().__init__()
   - Use **kwargs for parameter passing
   - Make mixins self-contained
   - Avoid dependencies on other classes
   - Name mixins with "Mixin" suffix

3. Initialization:
   - Use cooperative inheritance (__init__ with super())
   - Pass all args with **kwargs
   - Initialize in correct order
   - Be careful with method calls in __init__

4. Testing:
   - Test MRO explicitly
   - Verify all methods resolve correctly
   - Check for shadowing issues
   - Test diamond patterns

5. Documentation:
   - Document expected MRO
   - List mixin dependencies
   - Explain complex patterns
   - Provide usage examples

6. Tools:
   - Use MRO inspection tools
   - Validate hierarchies
   - Create visualization
   - Monitor complexity

7. Refactoring:
   - Simplify when hierarchy grows too complex
   - Consider composition alternatives
   - Break apart god classes
   - Use delegation patterns
""")


# ============================================================================
# SECTION 8: Key Takeaways
# ============================================================================

print("\n" + "="*70)
print("KEY TAKEAWAYS")
print("="*70)

print("""
COMPLEX HIERARCHIES:

1. MRO Handles Complexity:
   - C3 linearization works for deep hierarchies
   - Consistent and predictable
   - Detects conflicts automatically

2. Mixins are Powerful:
   - Add functionality without deep inheritance
   - Combine multiple capabilities
   - Keep code modular and reusable

3. Common Patterns:
   - Mixin pattern for cross-cutting concerns
   - Plugin architecture with MRO
   - Abstract base classes with concrete mixins
   - Multiple inheritance for capabilities

4. Avoid Pitfalls:
   - Always use super() in cooperative inheritance
   - Be careful with __init__ and method calls
   - Watch for fragile base class problems
   - Test complex hierarchies thoroughly

5. Best Practices:
   - Keep hierarchies shallow
   - Make mixins independent
   - Document thoroughly
   - Use composition when appropriate
   - Test MRO explicitly

6. When to Use:
   - Framework base classes
   - Plugin systems
   - Cross-cutting concerns
   - Code reuse across unrelated classes

7. When NOT to Use:
   - Simple problems
   - When composition is clearer
   - Deep hierarchies (>5 levels)
   - Tightly coupled components
""")

print("\n" + "="*70)
print("END OF COMPLEX HIERARCHIES TUTORIAL")
print("="*70)
print("\nNext: See practical real-world examples!")
