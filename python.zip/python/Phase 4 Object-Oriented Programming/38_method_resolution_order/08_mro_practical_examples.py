"""
08_mro_practical_examples.py

ADVANCED LEVEL: Practical Real-World MRO Examples

This file presents real-world scenarios where understanding MRO is crucial.
These examples demonstrate practical applications in web frameworks, GUI
libraries, ORMs, and other common Python patterns.

Learning Objectives:
- Apply MRO in real-world scenarios
- Understand framework design patterns
- See MRO in popular Python libraries
- Learn industry best practices
"""

# ============================================================================
# SECTION 1: Django-style ORM Model
# ============================================================================

"""
Django's ORM uses complex hierarchies with metaclasses and mixins.
This simplified example shows the pattern.
"""


class QuerySet:
    """Simplified QuerySet for database queries."""
    
    def __init__(self, model_class):
        self.model_class = model_class
        self._results = []
    
    def filter(self, **kwargs):
        """Filter results."""
        print(f"Filtering {self.model_class.__name__} by {kwargs}")
        return self
    
    def all(self):
        """Get all results."""
        print(f"Getting all {self.model_class.__name__} instances")
        return self


class Manager:
    """Database manager."""
    
    def __init__(self):
        self.model_class = None
    
    def get_queryset(self):
        """Get queryset for this model."""
        return QuerySet(self.model_class)
    
    def all(self):
        """Get all objects."""
        return self.get_queryset().all()
    
    def filter(self, **kwargs):
        """Filter objects."""
        return self.get_queryset().filter(**kwargs)


class ModelBase(type):
    """Metaclass for models."""
    
    def __new__(mcs, name, bases, attrs):
        # Add manager if not present
        if 'objects' not in attrs:
            attrs['objects'] = Manager()
        
        cls = super().__new__(mcs, name, bases, attrs)
        
        # Connect manager to model
        if hasattr(cls, 'objects'):
            cls.objects.model_class = cls
        
        return cls


class Model(metaclass=ModelBase):
    """Base model class (like Django's Model)."""
    
    def __init__(self, **kwargs):
        for key, value in kwargs.items():
            setattr(self, key, value)
    
    def save(self):
        """Save to database."""
        print(f"Saving {self.__class__.__name__} instance")
    
    def delete(self):
        """Delete from database."""
        print(f"Deleting {self.__class__.__name__} instance")


class TimestampMixin:
    """Mixin for timestamp fields."""
    
    def __init__(self, **kwargs):
        from datetime import datetime
        super().__init__(**kwargs)
        if not hasattr(self, 'created_at'):
            self.created_at = datetime.now()


class SoftDeleteMixin:
    """Mixin for soft delete."""
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.is_deleted = False
    
    def delete(self):
        """Soft delete - mark as deleted."""
        self.is_deleted = True
        print(f"Soft deleting {self.__class__.__name__} instance")


class User(TimestampMixin, SoftDeleteMixin, Model):
    """
    User model with mixins.
    
    MRO: User -> TimestampMixin -> SoftDeleteMixin -> Model -> 
         object (plus metaclass)
    """
    pass


print("="*70)
print("DJANGO-STYLE ORM MODEL")
print("="*70)

# Use the model
print("\nUsing User model:")
user = User(username="alice", email="alice@example.com")
print(f"Created user: {user.username}")
print(f"Has timestamp: {hasattr(user, 'created_at')}")
print(f"Has soft delete: {hasattr(user, 'is_deleted')}")

# Manager methods
print("\nUsing manager:")
User.objects.all()
User.objects.filter(username="alice")

# Delete (uses SoftDeleteMixin)
user.delete()
print(f"Is deleted: {user.is_deleted}")

print(f"\nMRO: {' -> '.join(c.__name__ for c in User.__mro__)}")


# ============================================================================
# SECTION 2: Flask-style Request/Response
# ============================================================================

"""
Web frameworks like Flask use mixins for request/response handling.
"""


class JSONMixin:
    """Mixin for JSON handling."""
    
    def get_json(self):
        """Get JSON data."""
        import json
        return json.loads(getattr(self, 'data', '{}'))
    
    def json_response(self, data, status=200):
        """Create JSON response."""
        import json
        return {
            'data': json.dumps(data),
            'status': status,
            'content_type': 'application/json'
        }


class AuthenticationMixin:
    """Mixin for authentication."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = None
    
    def is_authenticated(self):
        """Check if request is authenticated."""
        return self.user is not None
    
    def require_auth(self):
        """Require authentication."""
        if not self.is_authenticated():
            raise PermissionError("Authentication required")


class Request(JSONMixin, AuthenticationMixin):
    """
    HTTP Request class with mixins.
    
    MRO: Request -> JSONMixin -> AuthenticationMixin -> object
    """
    
    def __init__(self, data="", user=None):
        super().__init__()
        self.data = data
        self.user = user


class Response:
    """HTTP Response class."""
    
    def __init__(self, data, status=200, content_type='text/html'):
        self.data = data
        self.status = status
        self.content_type = content_type


print("\n" + "="*70)
print("FLASK-STYLE REQUEST/RESPONSE")
print("="*70)

# Authenticated request
auth_request = Request(data='{"name": "test"}', user="alice")
print(f"\nAuthenticated: {auth_request.is_authenticated()}")
print(f"JSON data: {auth_request.get_json()}")
print(f"JSON response: {auth_request.json_response({'result': 'success'})}")

# Unauthenticated request
unauth_request = Request(data='{}')
print(f"\nAuthenticated: {unauth_request.is_authenticated()}")

print(f"\nMRO: {' -> '.join(c.__name__ for c in Request.__mro__)}")


# ============================================================================
# SECTION 3: GUI Framework (Tkinter-style)
# ============================================================================

"""
GUI frameworks use complex hierarchies for widgets.
"""


class Widget:
    """Base widget class."""
    
    def __init__(self, width=100, height=100):
        self.width = width
        self.height = height
        self.visible = True
    
    def show(self):
        """Show widget."""
        self.visible = True
    
    def hide(self):
        """Hide widget."""
        self.visible = False


class Clickable:
    """Mixin for clickable widgets."""
    
    def __init__(self, *args, on_click=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.on_click = on_click
        self.click_count = 0
    
    def click(self):
        """Handle click."""
        self.click_count += 1
        if self.on_click:
            self.on_click()
        return f"Clicked (count: {self.click_count})"


class Draggable:
    """Mixin for draggable widgets."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.x = 0
        self.y = 0
    
    def drag_to(self, x, y):
        """Drag widget to position."""
        self.x = x
        self.y = y
        return f"Dragged to ({x}, {y})"


class Resizable:
    """Mixin for resizable widgets."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def resize(self, width, height):
        """Resize widget."""
        self.width = width
        self.height = height
        return f"Resized to {width}x{height}"


class Button(Clickable, Widget):
    """
    Button widget.
    
    MRO: Button -> Clickable -> Widget -> object
    """
    
    def __init__(self, text="Click me", **kwargs):
        super().__init__(**kwargs)
        self.text = text


class Window(Draggable, Resizable, Widget):
    """
    Window widget.
    
    MRO: Window -> Draggable -> Resizable -> Widget -> object
    """
    
    def __init__(self, title="Window", **kwargs):
        super().__init__(**kwargs)
        self.title = title


class Dialog(Clickable, Draggable, Resizable, Widget):
    """
    Dialog widget (can do everything).
    
    MRO: Dialog -> Clickable -> Draggable -> Resizable -> Widget -> object
    """
    
    def __init__(self, title="Dialog", **kwargs):
        super().__init__(**kwargs)
        self.title = title


print("\n" + "="*70)
print("GUI FRAMEWORK")
print("="*70)

# Create widgets
button = Button(text="Submit", on_click=lambda: print("Button clicked!"))
window = Window(title="Main Window", width=800, height=600)
dialog = Dialog(title="Save File", width=400, height=300)

print("\nButton:")
print(f"  {button.click()}")
print(f"  MRO: {' -> '.join(c.__name__ for c in Button.__mro__)}")

print("\nWindow:")
print(f"  {window.drag_to(100, 100)}")
print(f"  {window.resize(1024, 768)}")
print(f"  MRO: {' -> '.join(c.__name__ for c in Window.__mro__)}")

print("\nDialog (has all capabilities):")
print(f"  {dialog.click()}")
print(f"  {dialog.drag_to(200, 200)}")
print(f"  {dialog.resize(500, 400)}")
print(f"  MRO: {' -> '.join(c.__name__ for c in Dialog.__mro__)}")


# ============================================================================
# SECTION 4: Testing Framework (pytest-style)
# ============================================================================

"""
Testing frameworks use mixins for fixtures and test utilities.
"""


class TestCase:
    """Base test case."""
    
    def setup(self):
        """Setup before each test."""
        pass
    
    def teardown(self):
        """Teardown after each test."""
        pass
    
    def assert_equal(self, a, b):
        """Assert two values are equal."""
        if a != b:
            raise AssertionError(f"{a} != {b}")


class DatabaseFixture:
    """Mixin providing database fixtures."""
    
    def setup(self):
        """Setup database."""
        super().setup()
        print("  Setting up database")
        self.db = "test_database"
    
    def teardown(self):
        """Teardown database."""
        print("  Tearing down database")
        super().teardown()


class HTTPFixture:
    """Mixin providing HTTP fixtures."""
    
    def setup(self):
        """Setup HTTP client."""
        super().setup()
        print("  Setting up HTTP client")
        self.client = "test_client"
    
    def teardown(self):
        """Teardown HTTP client."""
        print("  Tearing down HTTP client")
        super().teardown()


class IntegrationTest(DatabaseFixture, HTTPFixture, TestCase):
    """
    Integration test with multiple fixtures.
    
    MRO: IntegrationTest -> DatabaseFixture -> HTTPFixture -> 
         TestCase -> object
    
    setup() is called once, but all fixtures run due to super()!
    """
    
    def test_example(self):
        """Example test."""
        print("  Running test")
        self.assert_equal(1, 1)


print("\n" + "="*70)
print("TESTING FRAMEWORK")
print("="*70)

test = IntegrationTest()
print("\nRunning IntegrationTest:")
test.setup()
test.test_example()
test.teardown()

print(f"\nMRO: {' -> '.join(c.__name__ for c in IntegrationTest.__mro__)}")


# ============================================================================
# SECTION 5: Logging Framework
# ============================================================================

"""
Logging systems use hierarchies for handlers and formatters.
"""


class Handler:
    """Base handler."""
    
    def emit(self, record):
        """Emit a log record."""
        pass


class Formatter:
    """Base formatter."""
    
    def format(self, record):
        """Format a log record."""
        return str(record)


class ConsoleHandler(Handler):
    """Handler that writes to console."""
    
    def emit(self, record):
        """Write to console."""
        print(f"CONSOLE: {record}")


class FileHandler(Handler):
    """Handler that writes to file."""
    
    def __init__(self, filename):
        self.filename = filename
    
    def emit(self, record):
        """Write to file."""
        print(f"FILE({self.filename}): {record}")


class JSONFormatter(Formatter):
    """Format records as JSON."""
    
    def format(self, record):
        """Format as JSON."""
        import json
        return json.dumps({'message': record, 'format': 'json'})


class Logger:
    """Logger with handlers."""
    
    def __init__(self, name):
        self.name = name
        self.handlers = []
    
    def add_handler(self, handler):
        """Add a handler."""
        self.handlers.append(handler)
    
    def log(self, message):
        """Log a message through all handlers."""
        for handler in self.handlers:
            # Apply formatter if available
            if hasattr(handler, 'formatter'):
                message = handler.formatter.format(message)
            handler.emit(message)


print("\n" + "="*70)
print("LOGGING FRAMEWORK")
print("="*70)

logger = Logger("app")
logger.add_handler(ConsoleHandler())
logger.add_handler(FileHandler("app.log"))

print("\nLogging messages:")
logger.log("Application started")
logger.log("Processing request")


# ============================================================================
# SECTION 6: Game Engine (Unity-style)
# ============================================================================

"""
Game engines use component-based systems with inheritance.
"""


class Component:
    """Base component."""
    
    def __init__(self):
        self.enabled = True
    
    def update(self):
        """Update component."""
        pass


class Transform(Component):
    """Transform component."""
    
    def __init__(self, x=0, y=0, z=0):
        super().__init__()
        self.x = x
        self.y = y
        self.z = z
    
    def translate(self, dx, dy, dz):
        """Move the transform."""
        self.x += dx
        self.y += dy
        self.z += dz


class Renderable(Component):
    """Renderable component."""
    
    def __init__(self):
        super().__init__()
        self.visible = True
    
    def render(self):
        """Render the component."""
        if self.visible:
            return "Rendering..."


class Physics(Component):
    """Physics component."""
    
    def __init__(self):
        super().__init__()
        self.velocity = {'x': 0, 'y': 0, 'z': 0}
    
    def apply_force(self, fx, fy, fz):
        """Apply force."""
        self.velocity['x'] += fx
        self.velocity['y'] += fy
        self.velocity['z'] += fz


class GameObject(Transform, Renderable, Physics):
    """
    Game object with multiple components.
    
    MRO: GameObject -> Transform -> Renderable -> Physics -> 
         Component -> object
    """
    
    def __init__(self, name="Object", x=0, y=0, z=0):
        super().__init__(x, y, z)
        self.name = name
    
    def update(self):
        """Update all components."""
        super().update()
        # Apply physics
        self.translate(
            self.velocity['x'],
            self.velocity['y'],
            self.velocity['z']
        )


print("\n" + "="*70)
print("GAME ENGINE")
print("="*70)

player = GameObject(name="Player", x=0, y=0, z=0)
print(f"\nPlayer position: ({player.x}, {player.y}, {player.z})")

player.apply_force(1, 0, 0)
print(f"Applied force: {player.velocity}")

player.update()
print(f"After update: ({player.x}, {player.y}, {player.z})")

print(f"\nMRO: {' -> '.join(c.__name__ for c in GameObject.__mro__)}")


# ============================================================================
# SECTION 7: Key Takeaways
# ============================================================================

print("\n" + "="*70)
print("KEY TAKEAWAYS - PRACTICAL EXAMPLES")
print("="*70)

print("""
REAL-WORLD MRO APPLICATIONS:

1. ORMs (Django, SQLAlchemy):
   - Metaclasses for model registration
   - Mixins for common fields (timestamps, soft delete)
   - Manager classes for queries
   - Complex hierarchies for model inheritance

2. Web Frameworks (Flask, Django):
   - Request/Response mixins
   - Authentication mixins
   - JSON handling mixins
   - Middleware through inheritance

3. GUI Libraries (Tkinter, Qt):
   - Widget hierarchies
   - Event handling mixins
   - Layout managers
   - Visual properties through inheritance

4. Testing Frameworks (pytest, unittest):
   - Test case base classes
   - Fixture mixins
   - Setup/teardown chains
   - Assertion helpers

5. Logging Systems:
   - Handler hierarchies
   - Formatter chains
   - Filter mixins
   - Output destinations

6. Game Engines (Unity, Pygame):
   - Component-based architecture
   - Entity hierarchies
   - Behavior mixins
   - System integration

COMMON PATTERNS:

1. Mixin Pattern:
   - Add specific functionality
   - Keep concerns separated
   - Reusable across hierarchies
   - Easy to test in isolation

2. Template Method:
   - Base class defines structure
   - Subclasses fill in details
   - super() calls coordinate
   - MRO ensures proper order

3. Cooperative Inheritance:
   - All classes use super()
   - Parameters passed via **kwargs
   - Each class processes what it needs
   - Chain continues to completion

4. Plugin Systems:
   - Base class for plugins
   - __init_subclass__ for registration
   - MRO determines processing order
   - Dynamic behavior composition

INDUSTRY BEST PRACTICES:

1. Documentation:
   - Document expected MRO
   - Explain mixin purposes
   - Show usage examples
   - List dependencies

2. Testing:
   - Test each mixin independently
   - Test mixin combinations
   - Verify MRO explicitly
   - Test edge cases

3. Design:
   - Keep hierarchies shallow
   - Make mixins independent
   - Use composition when appropriate
   - Follow single responsibility

4. Performance:
   - MRO lookup is fast
   - But don't abuse depth
   - Consider caching
   - Profile if necessary

5. Maintenance:
   - Regular hierarchy reviews
   - Refactor when complex
   - Monitor for anti-patterns
   - Keep it simple
""")

print("\n" + "="*70)
print("END OF PRACTICAL EXAMPLES")
print("="*70)
print("\nYou've completed the tutorial section!")
print("Next: Practice with exercises!")
