# Python Method Resolution Order (MRO) Tutorial Package

## Overview
This comprehensive tutorial package teaches Python's Method Resolution Order (MRO), a fundamental concept in object-oriented programming that determines the order in which base classes are searched when executing methods in inheritance hierarchies.

## What is MRO?
Method Resolution Order (MRO) is the order in which Python looks for a method in a hierarchy of classes. It becomes crucial when dealing with multiple inheritance, where a class can inherit from multiple parent classes.

## Package Contents

### 1. Beginner Level
- **01_basic_inheritance_mro.py**: Introduction to MRO with single inheritance
- **02_multiple_inheritance_intro.py**: Basic multiple inheritance concepts

### 2. Intermediate Level
- **03_diamond_problem.py**: Understanding the diamond problem and how MRO solves it
- **04_super_and_mro.py**: How super() works with MRO
- **05_mro_inspection.py**: Tools and methods to inspect MRO

### 3. Advanced Level
- **06_c3_linearization.py**: Understanding the C3 linearization algorithm
- **07_complex_hierarchies.py**: Complex multiple inheritance scenarios
- **08_mro_practical_examples.py**: Real-world design patterns using MRO

### 4. Exercises
- **exercises_01_basic.py**: Basic MRO exercises
- **exercises_02_intermediate.py**: Intermediate MRO challenges
- **exercises_03_advanced.py**: Advanced MRO problems
- **solutions_01_basic.py**: Solutions to basic exercises
- **solutions_02_intermediate.py**: Solutions to intermediate exercises
- **solutions_03_advanced.py**: Solutions to advanced exercises

## Key Concepts Covered

1. **Single Inheritance MRO**: Understanding how MRO works in simple inheritance chains
2. **Multiple Inheritance**: How Python handles multiple parent classes
3. **Diamond Problem**: The classic multiple inheritance problem and Python's solution
4. **C3 Linearization**: The algorithm Python uses to determine MRO
5. **super() Function**: How super() leverages MRO for cooperative inheritance
6. **MRO Inspection**: Using `__mro__` attribute and `mro()` method
7. **Practical Applications**: Real-world use cases and design patterns

## Learning Path

### For Beginners:
Start with files 01-02 to understand basic inheritance and MRO concepts.

### For Intermediate Students:
Progress to files 03-05 to learn about the diamond problem, super(), and MRO inspection.

### For Advanced Students:
Study files 06-08 to understand C3 linearization and complex inheritance patterns.

### For All Levels:
Complete the exercises in order, checking solutions only after attempting the problems.

## How to Use This Package

1. **Read the Code**: Each file is heavily commented with explanations
2. **Run Examples**: Execute each file to see MRO in action
3. **Experiment**: Modify the code to test your understanding
4. **Do Exercises**: Complete exercises before looking at solutions
5. **Build Projects**: Apply MRO concepts to your own class hierarchies

## Key Python Methods for MRO

```python
# View MRO as a tuple
ClassName.__mro__

# View MRO as a list
ClassName.mro()

# Get next class in MRO
super()
```

## Important MRO Rules

1. **Child classes come before parent classes**
2. **If multiple parents, they are kept in the order listed**
3. **Each class appears only once in MRO**
4. **MRO must be consistent (C3 linearization)**
5. **All classes ultimately inherit from object**

## Prerequisites

- Basic understanding of Python classes
- Familiarity with inheritance concepts
- Python 3.x installed

## Additional Resources

- Python Official Documentation on MRO
- PEP 253: Subtyping Built-in Types
- PEP 3119: Introducing Abstract Base Classes

## Testing Your Understanding

After completing this tutorial, you should be able to:
- Predict MRO for any class hierarchy
- Understand why certain inheritance patterns fail
- Use super() correctly in multiple inheritance
- Design effective class hierarchies
- Debug inheritance-related issues

---

**Author**: Created for undergraduate Python education  
**Level**: Beginner to Advanced  
**Estimated Time**: 6-8 hours of study
