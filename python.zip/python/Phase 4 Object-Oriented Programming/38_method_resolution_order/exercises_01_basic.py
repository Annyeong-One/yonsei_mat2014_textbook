"""
exercises_01_basic.py

BASIC EXERCISES: Test Your Understanding of MRO Basics

Complete these exercises to test your understanding of basic MRO concepts.
Try to solve them without looking at the solutions!

Topics Covered:
- Basic inheritance MRO
- Viewing MRO
- Single inheritance chains
- Method resolution
- Understanding __mro__
"""

print("="*70)
print("BASIC MRO EXERCISES")
print("="*70)

# ============================================================================
# EXERCISE 1: Predict the MRO
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 1: Predict the MRO")
print("-"*70)

"""
Given the following class hierarchy:

class Animal:
    pass

class Mammal(Animal):
    pass

class Dog(Mammal):
    pass

TASK: Without running the code, write down what you think Dog's MRO will be.
Then, create the classes and check if you were correct.
"""

# YOUR CODE HERE:
# Create the classes above, then print Dog's MRO








# ============================================================================
# EXERCISE 2: Method Resolution
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 2: Method Resolution")
print("-"*70)

"""
Create a three-level inheritance hierarchy:

1. Create a class Vehicle with:
   - A method move() that returns "Vehicle is moving"
   
2. Create a class Car(Vehicle) with:
   - A method move() that returns "Car is driving"
   - A method honk() that returns "Beep beep!"
   
3. Create a class SportsCar(Car) with:
   - A method accelerate() that returns "Accelerating fast!"

TASK: Create an instance of SportsCar and:
   - Call move() - which class provides this method?
   - Call honk() - which class provides this method?
   - Call accelerate() - which class provides this method?
   - Print the MRO of SportsCar
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 3: Understanding object in MRO
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 3: Understanding object in MRO")
print("-"*70)

"""
TASK:
1. Create a simple class MyClass with no explicit parent
2. Print its MRO
3. Explain why 'object' appears in the MRO
4. List 3 methods that MyClass inherits from object
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 4: Method Overriding
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 4: Method Overriding")
print("-"*70)

"""
Create the following classes:

class Shape:
    def area(self):
        return 0
    
    def description(self):
        return "Generic shape"

class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height

TASK:
1. Create a Rectangle instance with width=5 and height=3
2. Call area() - which method is used?
3. Call description() - which method is used?
4. Explain why these specific methods are called
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 5: Finding Methods in MRO
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 5: Finding Methods in MRO")
print("-"*70)

"""
Given these classes:

class A:
    def method_a(self):
        return "A"

class B(A):
    def method_b(self):
        return "B"

class C(B):
    def method_c(self):
        return "C"
    def method_a(self):  # Override
        return "C overrides A"

TASK:
1. Create an instance of C
2. For each method (method_a, method_b, method_c), write a function
   that finds which class in the MRO defines that method
3. Print results in a nice format
"""

# YOUR CODE HERE:










# ============================================================================
# EXERCISE 6: MRO Length
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 6: MRO Length")
print("-"*70)

"""
TASK:
Create an inheritance chain that has exactly 5 classes in its MRO
(including object). Name them Level1 through Level4.

Verify:
1. The total length of the MRO is 5
2. Print the MRO showing all 5 classes
3. object is the last class in the MRO
"""

# YOUR CODE HERE:









# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================

print("\n" + "-"*70)
print("CHALLENGE: Build an MRO Inspector")
print("-"*70)

"""
Create a function inspect_class(cls) that:
1. Prints the class name
2. Prints the MRO in a numbered list
3. For each class in MRO (except object), lists its direct parents
4. Shows the total depth of the inheritance chain

Example output for Dog (from Exercise 1):
    Inspecting class: Dog
    MRO:
      1. Dog (parents: Mammal)
      2. Mammal (parents: Animal)
      3. Animal (parents: object)
      4. object
    Inheritance depth: 3
"""

# YOUR CODE HERE:











print("\n" + "="*70)
print("END OF BASIC EXERCISES")
print("="*70)
print("\nCheck your answers in solutions_01_basic.py")
