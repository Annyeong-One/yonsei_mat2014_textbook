"""
exercises_02_intermediate.py

INTERMEDIATE EXERCISES: Multiple Inheritance and Diamond Problem

These exercises test your understanding of multiple inheritance, the diamond
problem, super(), and C3 linearization basics.

Topics Covered:
- Multiple inheritance
- Diamond problem
- super() usage
- Method conflicts
- Cooperative inheritance
"""

print("="*70)
print("INTERMEDIATE MRO EXERCISES")
print("="*70)

# ============================================================================
# EXERCISE 1: Multiple Inheritance MRO Prediction
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 1: Predict Multiple Inheritance MRO")
print("-"*70)

"""
Given:
    class A: pass
    class B: pass
    class C(A, B): pass
    class D(B, A): pass

TASKS:
1. Predict the MRO for C
2. Predict the MRO for D
3. Create the classes and verify your predictions
4. Explain why the MROs are different
"""

# YOUR CODE HERE:







# ============================================================================
# EXERCISE 2: Diamond Problem
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 2: Solve the Diamond Problem")
print("-"*70)

"""
Create a diamond inheritance:
    
         Base
        /    \
    Left    Right
        \    /
        Diamond

Requirements:
1. Base has a method value() that returns "base"
2. Left overrides value() to return "left"
3. Right overrides value() to return "right"
4. Diamond inherits from Left, then Right

TASKS:
1. Create the classes
2. Create a Diamond instance and call value() - what is returned?
3. Print the MRO
4. Explain which value() method is used and why
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 3: Using super() Correctly
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 3: Implement Cooperative Inheritance")
print("-"*70)

"""
Create a diamond with proper __init__ methods:

        Animal
        /    \
    Flyer   Swimmer
        \    /
        Duck

Requirements:
1. Animal.__init__(self, name) - stores name
2. Flyer.__init__(self, name, max_altitude) - stores max_altitude
3. Swimmer.__init__(self, name, max_depth) - stores max_depth
4. Duck.__init__(self, name, max_altitude, max_depth)
5. All classes must use super().__init__() properly
6. Each __init__ should print which class is initializing

TASK: Create a Duck instance and verify all __init__ methods are called
exactly once in the correct order.
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 4: Method Conflict Resolution
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 4: Resolve Method Conflicts")
print("-"*70)

"""
Create three classes:

class Teacher:
    def work(self): return "Teaching"
    def salary(self): return 50000

class Programmer:
    def work(self): return "Coding"
    def salary(self): return 80000

class TeachingProgrammer(Teacher, Programmer):
    pass

TASKS:
1. Create a TeachingProgrammer instance
2. What does work() return? Why?
3. What does salary() return? Why?
4. How can you access Programmer's methods from TeachingProgrammer?
5. Implement a method total_salary() that returns both salaries
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 5: MRO with **kwargs
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 5: Cooperative Inheritance with **kwargs")
print("-"*70)

"""
Create a mixin-based system:

class Base:
    def __init__(self, id, **kwargs):
        super().__init__(**kwargs)
        self.id = id

class TimestampMixin:
    def __init__(self, created_at=None, **kwargs):
        super().__init__(**kwargs)
        self.created_at = created_at or "now"

class OwnerMixin:
    def __init__(self, owner=None, **kwargs):
        super().__init__(**kwargs)
        self.owner = owner

class Document(TimestampMixin, OwnerMixin, Base):
    def __init__(self, id, title, created_at=None, owner=None):
        # YOUR TASK: Implement this __init__ correctly
        pass

TASK: 
1. Complete Document.__init__ to properly initialize all attributes
2. Create a Document and verify all attributes are set
3. Explain the order in which __init__ methods are called
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 6: Detecting Diamonds
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 6: Create a Diamond Detector")
print("-"*70)

"""
TASK: Create a function find_diamonds(cls) that:
1. Takes a class as input
2. Analyzes its MRO
3. Detects if there are any diamond patterns
4. Returns a list of common ancestors that create diamonds

Example:
        A
       / \
      B   C
       \ /
        D
    
    find_diamonds(D) should return ['A'] because A is the
    common ancestor of B and C.

Test your function with different hierarchies!
"""

# YOUR CODE HERE:









# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================

print("\n" + "-"*70)
print("CHALLENGE: Build a Mixin System")
print("-"*70)

"""
Design and implement a complete mixin system for a database model:

Create these mixins:
1. TimestampMixin - adds created_at and updated_at
2. SoftDeleteMixin - adds is_deleted flag
3. VersionMixin - adds version number
4. AuditMixin - adds created_by and modified_by

Create a Model base class that:
1. Has __init__ method
2. Has save() and delete() methods
3. Works with all mixins cooperatively

Create a User class that:
1. Inherits from all mixins and Model
2. Has username and email fields
3. Properly initializes everything

Requirements:
- All __init__ methods must use super() and **kwargs
- Test that all mixins work together
- Create a user and verify all attributes exist
- Call save() and delete() and verify they work
"""

# YOUR CODE HERE:












print("\n" + "="*70)
print("END OF INTERMEDIATE EXERCISES")
print("="*70)
print("\nCheck your answers in solutions_02_intermediate.py")
