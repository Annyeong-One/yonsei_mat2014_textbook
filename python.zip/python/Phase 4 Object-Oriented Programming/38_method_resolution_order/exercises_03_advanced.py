"""
exercises_03_advanced.py

ADVANCED EXERCISES: C3 Linearization and Complex Hierarchies

These exercises test your mastery of MRO, C3 linearization algorithm,
complex hierarchies, and advanced patterns.

Topics Covered:
- C3 linearization manual computation
- Complex inheritance patterns
- Metaclass MRO
- Performance considerations
- Real-world design patterns
"""

print("="*70)
print("ADVANCED MRO EXERCISES")
print("="*70)

# ============================================================================
# EXERCISE 1: Manual C3 Computation
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 1: Compute MRO Manually")
print("-"*70)

"""
Given this hierarchy:

    class O: pass
    class A(O): pass
    class B(O): pass
    class C(O): pass
    class D(A, B): pass
    class E(B, C): pass
    class F(D, E): pass

TASKS:
1. Manually compute the MRO for F using C3 linearization
2. Write out each step of the merge process
3. Create the classes and verify your answer
4. Draw the inheritance graph

Hint: L[F] = F + merge(L[D], L[E], [D, E])
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 2: Inconsistent MRO
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 2: Fix Inconsistent MRO")
print("-"*70)

"""
The following hierarchy is inconsistent:

    class X: pass
    class Y: pass
    class A(X, Y): pass
    class B(Y, X): pass
    # class C(A, B): pass  # This would fail!

TASKS:
1. Explain why class C cannot be created
2. Show the C3 merge that would fail
3. Propose TWO different solutions to fix the hierarchy
4. Implement both solutions and verify they work
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 3: Plugin Architecture
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 3: Build a Plugin System")
print("-"*70)

"""
Design a plugin architecture where:

1. Base class PluginBase with:
   - __init_subclass__ to register plugins
   - process(data) method
   - class-level registry of all plugins

2. Three plugins:
   - ValidationPlugin: checks data validity
   - TransformPlugin: modifies data
   - LogPlugin: logs data processing

3. A Processor class that:
   - Inherits from all three plugins
   - Processes data through all plugins using MRO
   - Each plugin's process() calls super().process()

TASKS:
1. Implement the complete system
2. Ensure correct MRO determines processing order
3. Test with sample data
4. Show how changing plugin order changes behavior
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 4: Metaclass MRO
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 4: Understand Metaclass MRO")
print("-"*70)

"""
Create a metaclass system:

1. Meta class that:
   - Counts how many instances of classes are created
   - Validates class attributes
   - Logs class creation

2. Two base classes with different metaclasses
3. A child class that should inherit from both

TASKS:
1. Implement the metaclass system
2. Understand how metaclass MRO works
3. Make classes with different metaclasses work together
4. Document the metaclass MRO

Note: This is tricky! You may need to create a common metaclass.
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 5: Performance Analysis
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 5: MRO Performance Analysis")
print("-"*70)

"""
TASKS:
1. Create hierarchies of different complexities:
   - Shallow: 3 levels deep
   - Medium: 6 levels deep
   - Deep: 10 levels deep
   - Wide: 10 direct parents

2. For each hierarchy:
   - Measure time to compute MRO
   - Measure time for method lookups
   - Count MRO length

3. Create a performance comparison report

4. Explain when MRO complexity impacts performance
"""

# YOUR CODE HERE:









# ============================================================================
# EXERCISE 6: Framework Design
# ============================================================================

print("\n" + "-"*70)
print("EXERCISE 6: Design a Mini Web Framework")
print("-"*70)

"""
Design a mini web framework with these components:

1. Request class with mixins:
   - JSONMixin: JSON handling
   - AuthMixin: Authentication
   - SessionMixin: Session management
   - ValidationMixin: Input validation

2. View base class with:
   - get(), post(), put(), delete() methods
   - dispatch() method that routes to correct method

3. ModelView that combines:
   - View base
   - CRUD operations
   - Validation
   - Authentication

TASKS:
1. Design the complete hierarchy
2. Ensure all mixins work cooperatively
3. Document the MRO
4. Create example endpoints
5. Test that all features work together
"""

# YOUR CODE HERE:












# ============================================================================
# CHALLENGE EXERCISE
# ============================================================================

print("\n" + "-"*70)
print("CHALLENGE: MRO Visualization Tool")
print("-"*70)

"""
Create a comprehensive MRO visualization and analysis tool:

Requirements:
1. ASCII art visualization of inheritance graph
2. Step-by-step C3 linearization computation
3. Detection of:
   - Diamond patterns
   - Inconsistent hierarchies
   - Circular dependencies
   - Deep hierarchies (>5 levels)
   
4. Analysis features:
   - MRO complexity score
   - Method shadowing detection
   - Suggest optimizations
   - Performance predictions

5. Output formats:
   - Terminal pretty-print
   - Graphviz DOT format
   - JSON export

Test your tool on multiple complex hierarchies from this tutorial!
"""

# YOUR CODE HERE:












print("\n" + "="*70)
print("END OF ADVANCED EXERCISES")
print("="*70)
print("\nCheck your answers in solutions_03_advanced.py")
