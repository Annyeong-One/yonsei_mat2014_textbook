"""
solutions_01_basic.py

SOLUTIONS: Basic MRO Exercises

These are the solutions to exercises_01_basic.py. Try to solve the exercises
yourself before looking at these solutions!
"""

print("="*70)
print("SOLUTIONS: BASIC MRO EXERCISES")
print("="*70)

# ============================================================================
# SOLUTION 1: Predict the MRO
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 1: Predict the MRO")
print("-"*70)

class Animal:
    pass

class Mammal(Animal):
    pass

class Dog(Mammal):
    pass

print("Dog's MRO:")
for i, cls in enumerate(Dog.__mro__, 1):
    print(f"  {i}. {cls.__name__}")

print("\nExpected: Dog -> Mammal -> Animal -> object")
print("This is a simple single inheritance chain.")


# ============================================================================
# SOLUTION 2: Method Resolution
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 2: Method Resolution")
print("-"*70)

class Vehicle:
    def move(self):
        return "Vehicle is moving"

class Car(Vehicle):
    def move(self):
        return "Car is driving"
    
    def honk(self):
        return "Beep beep!"

class SportsCar(Car):
    def accelerate(self):
        return "Accelerating fast!"

sports_car = SportsCar()

print(f"move(): {sports_car.move()}")
print("  → Provided by: Car (overrides Vehicle)")

print(f"honk(): {sports_car.honk()}")
print("  → Provided by: Car")

print(f"accelerate(): {sports_car.accelerate()}")
print("  → Provided by: SportsCar")

print("\nMRO:")
for i, cls in enumerate(SportsCar.__mro__, 1):
    print(f"  {i}. {cls.__name__}")


# ============================================================================
# SOLUTION 3: Understanding object in MRO
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 3: Understanding object in MRO")
print("-"*70)

class MyClass:
    pass

print("MyClass MRO:")
for i, cls in enumerate(MyClass.__mro__, 1):
    print(f"  {i}. {cls.__name__}")

print("\nExplanation:")
print("  'object' appears because in Python 3, all classes implicitly")
print("  inherit from 'object'. It's the root of the class hierarchy.")

print("\n3 methods inherited from object:")
my_instance = MyClass()
print(f"  1. __str__: {type(my_instance.__str__)}")
print(f"  2. __repr__: {type(my_instance.__repr__)}")
print(f"  3. __hash__: {type(my_instance.__hash__)}")


# ============================================================================
# SOLUTION 4: Method Overriding
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 4: Method Overriding")
print("-"*70)

class Shape:
    def area(self):
        return 0
    
    def description(self):
        return "Generic shape"

class Rectangle(Shape):
    def __init__(self, width, height):
        self.width = width
        self.height = height
    
    def area(self):
        return self.width * self.height

rect = Rectangle(5, 3)

print(f"area() returns: {rect.area()}")
print("  → Rectangle.area() is used (overrides Shape.area())")
print("  → Python finds area() in Rectangle first in the MRO")

print(f"\ndescription() returns: {rect.description()}")
print("  → Shape.description() is used")
print("  → Rectangle doesn't override it, so MRO moves to Shape")

print("\nMRO for Rectangle:")
for i, cls in enumerate(Rectangle.__mro__, 1):
    print(f"  {i}. {cls.__name__}")


# ============================================================================
# SOLUTION 5: Finding Methods in MRO
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 5: Finding Methods in MRO")
print("-"*70)

class A:
    def method_a(self):
        return "A"

class B(A):
    def method_b(self):
        return "B"

class C(B):
    def method_c(self):
        return "C"
    
    def method_a(self):
        return "C overrides A"

def find_method_source(cls, method_name):
    """Find which class defines a method in the MRO."""
    for c in cls.__mro__:
        if method_name in c.__dict__:
            return c.__name__
    return "Not found"

c_instance = C()

print("Method sources for class C:")
methods = ['method_a', 'method_b', 'method_c']
for method in methods:
    source = find_method_source(C, method)
    result = getattr(c_instance, method)()
    print(f"  {method}() → defined in {source}, returns '{result}'")

print("\nC's MRO:")
for i, cls in enumerate(C.__mro__, 1):
    print(f"  {i}. {cls.__name__}")


# ============================================================================
# SOLUTION 6: MRO Length
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 6: MRO Length")
print("-"*70)

class Level1:
    pass

class Level2(Level1):
    pass

class Level3(Level2):
    pass

class Level4(Level3):
    pass

print(f"MRO length: {len(Level4.__mro__)}")

print("\nComplete MRO:")
for i, cls in enumerate(Level4.__mro__, 1):
    print(f"  {i}. {cls.__name__}")

print(f"\nVerification:")
print(f"  Length is 5: {len(Level4.__mro__) == 5}")
print(f"  Last class is object: {Level4.__mro__[-1].__name__ == 'object'}")


# ============================================================================
# CHALLENGE SOLUTION: MRO Inspector
# ============================================================================

print("\n" + "-"*70)
print("CHALLENGE SOLUTION: Build an MRO Inspector")
print("-"*70)

def inspect_class(cls):
    """Comprehensive class inspection."""
    print(f"\nInspecting class: {cls.__name__}")
    print("MRO:")
    
    depth = 0
    for i, c in enumerate(cls.__mro__, 1):
        if c != object:
            depth += 1
            parents = [p.__name__ for p in c.__bases__]
            parent_str = ", ".join(parents) if parents else "none"
            print(f"  {i}. {c.__name__} (parents: {parent_str})")
        else:
            print(f"  {i}. {c.__name__}")
    
    print(f"Inheritance depth: {depth}")

# Test with Dog from earlier
inspect_class(Dog)

# Test with a more complex example
class Base:
    pass

class Left(Base):
    pass

class Right(Base):
    pass

class Bottom(Left, Right):
    pass

inspect_class(Bottom)


print("\n" + "="*70)
print("END OF BASIC SOLUTIONS")
print("="*70)
