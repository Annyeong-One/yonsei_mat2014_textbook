"""
solutions_02_intermediate.py

SOLUTIONS: Intermediate MRO Exercises

Solutions to exercises_02_intermediate.py covering multiple inheritance,
diamond problem, and super() usage.
"""

print("="*70)
print("SOLUTIONS: INTERMEDIATE MRO EXERCISES")
print("="*70)

# ============================================================================
# SOLUTION 1: Multiple Inheritance MRO Prediction
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 1: Multiple Inheritance MRO")
print("-"*70)

class A:
    pass

class B:
    pass

class C(A, B):
    pass

class D(B, A):
    pass

print("Predicted MRO for C: C -> A -> B -> object")
print("Actual MRO for C:")
for i, cls in enumerate(C.__mro__, 1):
    print(f"  {i}. {cls.__name__}")

print("\nPredicted MRO for D: D -> B -> A -> object")
print("Actual MRO for D:")
for i, cls in enumerate(D.__mro__, 1):
    print(f"  {i}. {cls.__name__}")

print("\nExplanation:")
print("  The order of parents in the class definition determines MRO.")
print("  C(A, B) → A comes before B")
print("  D(B, A) → B comes before A")


# ============================================================================
# SOLUTION 2: Diamond Problem
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 2: Diamond Problem")
print("-"*70)

class Base:
    def value(self):
        return "base"

class Left(Base):
    def value(self):
        return "left"

class Right(Base):
    def value(self):
        return "right"

class Diamond(Left, Right):
    pass

d = Diamond()
print(f"d.value() returns: '{d.value()}'")

print("\nMRO for Diamond:")
for i, cls in enumerate(Diamond.__mro__, 1):
    print(f"  {i}. {cls.__name__}")

print("\nExplanation:")
print("  Diamond.value() resolves to Left.value()")
print("  Because Left comes before Right in Diamond(Left, Right)")
print("  MRO is: Diamond -> Left -> Right -> Base -> object")
print("  Python finds value() in Left first, so that's what's called")


# ============================================================================
# SOLUTION 3: Cooperative Inheritance
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 3: Cooperative Inheritance")
print("-"*70)

class Animal:
    def __init__(self, name):
        print(f"  Animal.__init__({name})")
        self.name = name

class Flyer(Animal):
    def __init__(self, name, max_altitude):
        print(f"  Flyer.__init__({name}, {max_altitude})")
        super().__init__(name)
        self.max_altitude = max_altitude

class Swimmer(Animal):
    def __init__(self, name, max_depth):
        print(f"  Swimmer.__init__({name}, {max_depth})")
        super().__init__(name)
        self.max_depth = max_depth

class Duck(Flyer, Swimmer):
    def __init__(self, name, max_altitude, max_depth):
        print(f"  Duck.__init__({name}, {max_altitude}, {max_depth})")
        super().__init__(name, max_altitude)
        # Note: max_depth is not passed here but Swimmer still gets it!
        # This would require **kwargs pattern for real implementation

print("Creating a Duck:")
# Note: This simplified version won't pass max_depth to Swimmer
# See challenge solution for proper **kwargs implementation

print("\nFor proper implementation with **kwargs:")

class Animal2:
    def __init__(self, name, **kwargs):
        print(f"  Animal2.__init__({name})")
        super().__init__(**kwargs)
        self.name = name

class Flyer2(Animal2):
    def __init__(self, max_altitude=1000, **kwargs):
        print(f"  Flyer2.__init__({max_altitude})")
        super().__init__(**kwargs)
        self.max_altitude = max_altitude

class Swimmer2(Animal2):
    def __init__(self, max_depth=100, **kwargs):
        print(f"  Swimmer2.__init__({max_depth})")
        super().__init__(**kwargs)
        self.max_depth = max_depth

class Duck2(Flyer2, Swimmer2):
    def __init__(self, name, max_altitude=1000, max_depth=100):
        print(f"  Duck2.__init__({name}, {max_altitude}, {max_depth})")
        super().__init__(
            name=name,
            max_altitude=max_altitude,
            max_depth=max_depth
        )

duck = Duck2("Donald", 5000, 50)
print(f"\nDuck attributes:")
print(f"  name: {duck.name}")
print(f"  max_altitude: {duck.max_altitude}")
print(f"  max_depth: {duck.max_depth}")


# ============================================================================
# SOLUTION 4: Method Conflict Resolution
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 4: Method Conflicts")
print("-"*70)

class Teacher:
    def work(self):
        return "Teaching"
    
    def salary(self):
        return 50000

class Programmer:
    def work(self):
        return "Coding"
    
    def salary(self):
        return 80000

class TeachingProgrammer(Teacher, Programmer):
    def total_salary(self):
        """Get both salaries by calling parent classes directly."""
        teacher_sal = Teacher.salary(self)
        programmer_sal = Programmer.salary(self)
        return teacher_sal + programmer_sal

tp = TeachingProgrammer()

print(f"work() returns: {tp.work()}")
print("  → Teacher.work() because Teacher comes first")

print(f"\nsalary() returns: {tp.salary()}")
print("  → Teacher.salary() because Teacher comes first")

print(f"\ntotal_salary() returns: {tp.total_salary()}")
print("  → Calls both parent methods directly")

print("\nMRO:")
for i, cls in enumerate(TeachingProgrammer.__mro__, 1):
    print(f"  {i}. {cls.__name__}")


# ============================================================================
# SOLUTION 5: Cooperative Inheritance with **kwargs
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 5: **kwargs Pattern")
print("-"*70)

class Base:
    def __init__(self, id, **kwargs):
        super().__init__(**kwargs)
        print(f"  Base.__init__(id={id})")
        self.id = id

class TimestampMixin:
    def __init__(self, created_at=None, **kwargs):
        super().__init__(**kwargs)
        print(f"  TimestampMixin.__init__(created_at={created_at})")
        self.created_at = created_at or "now"

class OwnerMixin:
    def __init__(self, owner=None, **kwargs):
        super().__init__(**kwargs)
        print(f"  OwnerMixin.__init__(owner={owner})")
        self.owner = owner

class Document(TimestampMixin, OwnerMixin, Base):
    def __init__(self, id, title, created_at=None, owner=None):
        print(f"  Document.__init__(id={id}, title={title})")
        super().__init__(
            id=id,
            created_at=created_at,
            owner=owner
        )
        self.title = title

print("Creating Document:")
doc = Document(id=1, title="Report", created_at="2025-01-01", owner="Alice")

print(f"\nDocument attributes:")
print(f"  id: {doc.id}")
print(f"  title: {doc.title}")
print(f"  created_at: {doc.created_at}")
print(f"  owner: {doc.owner}")

print(f"\nMRO: {' -> '.join(c.__name__ for c in Document.__mro__)}")


# ============================================================================
# SOLUTION 6: Diamond Detector
# ============================================================================

print("\n" + "-"*70)
print("SOLUTION 6: Diamond Detector")
print("-"*70)

def find_diamonds(cls):
    """Detect diamond patterns in MRO."""
    diamonds = []
    mro = cls.__mro__
    
    # Check each pair of classes
    for i, c1 in enumerate(mro[:-1]):
        for c2 in mro[i+1:]:
            # Find common ancestors
            c1_ancestors = set(c1.__mro__)
            c2_ancestors = set(c2.__mro__)
            common = c1_ancestors & c2_ancestors
            common -= {object}  # Remove object
            
            # If they have common ancestors besides object, it's a diamond
            if common:
                for ancestor in common:
                    if ancestor not in diamonds:
                        diamonds.append(ancestor.__name__)
    
    return diamonds

# Test with diamond
class A:
    pass

class B(A):
    pass

class C(A):
    pass

class D(B, C):
    pass

print(f"Diamonds in D: {find_diamonds(D)}")

# Test with no diamond
class X:
    pass

class Y:
    pass

class Z(X, Y):
    pass

print(f"Diamonds in Z: {find_diamonds(Z)}")


# ============================================================================
# CHALLENGE SOLUTION: Complete Mixin System
# ============================================================================

print("\n" + "-"*70)
print("CHALLENGE SOLUTION: Mixin System")
print("-"*70)

from datetime import datetime

class TimestampMixin:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.created_at = datetime.now()
        self.updated_at = datetime.now()

class SoftDeleteMixin:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.is_deleted = False
    
    def delete(self):
        self.is_deleted = True
        return "Soft deleted"

class VersionMixin:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.version = 1
    
    def increment_version(self):
        self.version += 1

class AuditMixin:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.created_by = None
        self.modified_by = None

class Model:
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
    
    def save(self):
        return "Saved"

class User(TimestampMixin, SoftDeleteMixin, VersionMixin, AuditMixin, Model):
    def __init__(self, username, email):
        super().__init__()
        self.username = username
        self.email = email

print("Creating User with all mixins:")
user = User("alice", "alice@example.com")

print(f"\nUser attributes:")
print(f"  username: {user.username}")
print(f"  email: {user.email}")
print(f"  created_at: {user.created_at}")
print(f"  is_deleted: {user.is_deleted}")
print(f"  version: {user.version}")
print(f"  created_by: {user.created_by}")

print(f"\nUser methods:")
print(f"  save(): {user.save()}")
print(f"  delete(): {user.delete()}")
user.increment_version()
print(f"  version after increment: {user.version}")

print(f"\nMRO: {' -> '.join(c.__name__ for c in User.__mro__)}")


print("\n" + "="*70)
print("END OF INTERMEDIATE SOLUTIONS")
print("="*70)
