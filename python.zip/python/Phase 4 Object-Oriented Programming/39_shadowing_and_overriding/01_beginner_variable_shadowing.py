"""
01_beginner_variable_shadowing.py

BEGINNER LEVEL: Introduction to Variable Shadowing in Python

This module introduces the concept of shadowing, where a variable in an inner scope
has the same name as a variable in an outer scope, effectively "hiding" the outer variable.

Topics covered:
1. Global vs local scope basics
2. Variable shadowing fundamentals
3. The LEGB rule (Local, Enclosing, Global, Built-in)
4. Common pitfalls and debugging
5. Best practices

Learning objectives:
- Understand how Python resolves variable names
- Identify shadowing in code
- Write code that avoids unintentional shadowing
- Use global keyword when necessary
"""

# =============================================================================
# SECTION 1: Basic Scope and Shadowing
# =============================================================================

print("=" * 70)
print("SECTION 1: Basic Scope and Shadowing")
print("=" * 70)

# Example 1.1: Global variable (no shadowing)
# ---------------------------------------------
# A variable defined at module level is a global variable
# It can be accessed from anywhere in the module

counter = 0  # Global variable

def increment():
    """
    This function reads the global variable 'counter'.
    Note: We're only READING it, not modifying it.
    """
    print(f"Inside increment(): counter = {counter}")

increment()  # Output: Inside increment(): counter = 0
print(f"Outside function: counter = {counter}")  # Output: Outside function: counter = 0

print("\n" + "-" * 70 + "\n")

# Example 1.2: Local variable shadowing global variable
# ------------------------------------------------------
# When we create a variable with the same name inside a function,
# it "shadows" (hides) the global variable

message = "Global message"  # Global variable

def show_message():
    """
    This function creates a LOCAL variable named 'message'.
    This local variable shadows the global 'message' variable.
    Inside this function, 'message' refers to the local variable only.
    """
    message = "Local message"  # Local variable shadows global
    print(f"Inside function: {message}")  # Prints: Local message

show_message()
print(f"Outside function: {message}")  # Prints: Global message (unchanged)

print("\n" + "-" * 70 + "\n")

# Example 1.3: Function parameters shadow global variables
# ---------------------------------------------------------
# Function parameters are local variables, so they also cause shadowing

username = "Alice"  # Global variable

def greet(username):  # Parameter 'username' shadows global 'username'
    """
    The parameter 'username' is a local variable that shadows
    the global 'username' variable within this function scope.
    """
    print(f"Hello, {username}!")  # Uses the parameter, not the global

greet("Bob")  # Output: Hello, Bob!
print(f"Global username: {username}")  # Output: Global username: Alice

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 2: The LEGB Rule - Python's Name Resolution Order
# =============================================================================

print("SECTION 2: The LEGB Rule - Python's Name Resolution Order")
print("=" * 70)

"""
When Python encounters a variable name, it searches for it in this order:
L - Local: Variables defined in the current function
E - Enclosing: Variables in enclosing functions (for nested functions)
G - Global: Variables defined at the module level
B - Built-in: Python's built-in names (like print, len, etc.)

Python stops searching as soon as it finds the name.
"""

# Example 2.1: Demonstrating LEGB search order
# ---------------------------------------------

value = "GLOBAL"  # Global scope (G)

def outer():
    """
    Outer function creates an enclosing scope for inner().
    """
    value = "ENCLOSING"  # Enclosing scope (E) for inner()
    
    def inner():
        """
        Inner function has its own local scope.
        The 'value' variable here is in the local scope (L).
        """
        value = "LOCAL"  # Local scope (L)
        print(f"Inside inner(): {value}")  # Finds LOCAL first
    
    inner()
    print(f"Inside outer(): {value}")  # Finds ENCLOSING

outer()
print(f"At module level: {value}")  # Finds GLOBAL

print("\n" + "-" * 70 + "\n")

# Example 2.2: LEGB without shadowing at each level
# --------------------------------------------------
# If a variable isn't defined locally, Python searches outer scopes

color = "GLOBAL_COLOR"  # Global (G)

def outer_func():
    """
    This function doesn't define 'color' locally,
    so it searches in enclosing and then global scopes.
    """
    brightness = "ENCLOSING_BRIGHTNESS"  # Enclosing (E) for inner_func()
    
    def inner_func():
        """
        This function doesn't define 'color' or 'brightness' locally,
        so it finds them in outer scopes.
        """
        saturation = "LOCAL_SATURATION"  # Local (L)
        
        # All three variables found at different LEGB levels:
        print(f"saturation (L): {saturation}")
        print(f"brightness (E): {brightness}")
        print(f"color (G): {color}")
    
    inner_func()

outer_func()

print("\n" + "-" * 70 + "\n")

# Example 2.3: Built-in scope (B) - shadowing built-in names
# -----------------------------------------------------------
# WARNING: You can shadow built-in names, but it's generally a bad idea!

print("Before shadowing, print is:", type(print))  # <class 'builtin_function_or_method'>

def bad_practice():
    """
    DEMONSTRATION ONLY - DO NOT DO THIS IN REAL CODE!
    
    Shadowing built-in names like 'print' or 'len' can cause confusion
    and make debugging difficult.
    """
    print = "I'm not the print function anymore!"  # Shadows built-in 'print'
    # Now we can't use the print function in this scope!
    # This would cause an error: print("Hello")  # TypeError: 'str' object is not callable

# After the function, the built-in 'print' is still available
print("After function, print works fine!")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 3: Common Pitfalls and UnboundLocalError
# =============================================================================

print("SECTION 3: Common Pitfalls and UnboundLocalError")
print("=" * 70)

# Example 3.1: The UnboundLocalError trap
# ----------------------------------------
# This is one of the most common mistakes beginners make!

score = 100  # Global variable

def update_score():
    """
    COMMON ERROR: This function will raise UnboundLocalError!
    
    Why? Because we're trying to modify 'score', Python treats it as a local variable.
    But we're trying to read it before assigning to it in the same function.
    """
    try:
        print(score)  # Trying to read 'score'
        score = score + 10  # Trying to assign to 'score'
    except UnboundLocalError as e:
        print(f"ERROR: {e}")
        print("Explanation: Python sees 'score = ...' and treats 'score' as local.")
        print("But we tried to read 'score' before assigning to it!")

update_score()

print("\n" + "-" * 70 + "\n")

# Example 3.2: Fixing UnboundLocalError with 'global' keyword
# ------------------------------------------------------------
# If you need to modify a global variable, declare it with 'global'

points = 50  # Global variable

def add_points():
    """
    Using 'global' tells Python: "Don't create a local variable,
    use the global variable instead."
    """
    global points  # Declare that we're using the global 'points'
    print(f"Points before: {points}")
    points = points + 25  # Now we can modify the global variable
    print(f"Points after: {points}")

add_points()
print(f"Global points after function: {points}")  # Changed to 75

print("\n" + "-" * 70 + "\n")

# Example 3.3: Better approach - avoid global modification
# ---------------------------------------------------------
# Instead of modifying globals, return new values (functional programming style)

total = 100  # Global variable

def calculate_bonus(current_total):
    """
    BEST PRACTICE: Don't modify globals directly.
    Instead, accept parameters and return new values.
    This makes the function easier to test and understand.
    """
    bonus = 50
    return current_total + bonus

# Update the global by assigning the return value
total = calculate_bonus(total)
print(f"Total after bonus: {total}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 4: Shadowing in Different Contexts
# =============================================================================

print("SECTION 4: Shadowing in Different Contexts")
print("=" * 70)

# Example 4.1: Loop variable shadowing
# -------------------------------------
# Loop variables can shadow variables from outer scopes

index = 999  # Global variable

def process_items():
    """
    The loop variable 'index' shadows the global 'index'.
    After the loop, 'index' remains in the function's scope.
    """
    items = ['apple', 'banana', 'cherry']
    
    for index in range(len(items)):  # 'index' shadows global
        print(f"Processing item {index}: {items[index]}")
    
    # After the loop, 'index' still exists and has the last loop value
    print(f"After loop, local index: {index}")

process_items()
print(f"Global index unchanged: {index}")

print("\n" + "-" * 70 + "\n")

# Example 4.2: List comprehension scope (Python 3.x)
# ---------------------------------------------------
# In Python 3, list comprehensions have their own scope

x = "GLOBAL"  # Global variable

# The 'x' in the comprehension doesn't shadow the global 'x'
squares = [x**2 for x in range(5)]  # 'x' here is local to the comprehension

print(f"Squares: {squares}")
print(f"Global x unchanged: {x}")  # Still "GLOBAL"

print("\n" + "-" * 70 + "\n")

# Example 4.3: Conditional shadowing
# -----------------------------------
# Unlike some languages, Python doesn't have block scope for if/else

def conditional_scope():
    """
    In Python, if/else blocks don't create new scopes.
    Variables created inside if/else are part of the function scope.
    """
    condition = True
    
    if condition:
        result = "if branch"  # Created in function scope
    else:
        result = "else branch"
    
    # 'result' is available here because Python doesn't have block scope
    print(f"Result: {result}")

conditional_scope()

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 5: Best Practices and Guidelines
# =============================================================================

print("SECTION 5: Best Practices and Guidelines")
print("=" * 70)

"""
BEST PRACTICES:

1. Use descriptive, specific names to avoid accidental shadowing
   ❌ Bad:  data = ... (too generic)
   ✅ Good: user_data = ...

2. Avoid shadowing built-in names (print, len, list, dict, etc.)
   ❌ Bad:  list = [1, 2, 3]
   ✅ Good: numbers_list = [1, 2, 3]

3. Minimize use of global variables
   - Prefer passing parameters and returning values
   - Use classes to encapsulate state

4. If you must modify a global, use 'global' keyword explicitly
   - This makes your intent clear to other developers

5. Use tools to catch shadowing issues:
   - pylint: warns about shadowing
   - mypy: helps with type checking
   - IDE warnings: most IDEs highlight shadowing

6. Be cautious with common variable names:
   - Avoid: i, j, x, y, data, result, temp
   - Prefer: user_index, coordinate_x, user_data, calculation_result

7. When reading code, mentally track which scope you're in
   - Look for function boundaries
   - Note where variables are defined
"""

# Example 5.1: Good practice - clear naming
# ------------------------------------------

DATABASE_URL = "postgresql://localhost/mydb"  # Global constant (all caps)

def connect_to_database():
    """
    Use specific names that don't conflict with common variables.
    Return values instead of modifying globals.
    """
    connection_url = DATABASE_URL  # Local copy with clear name
    print(f"Connecting to: {connection_url}")
    # ... connection logic here ...
    return connection_url  # Return instead of modifying global

# Example 5.2: Using classes instead of globals
# ----------------------------------------------
# Classes provide a clean way to manage state without global variables

class ScoreManager:
    """
    Encapsulating state in a class is better than using global variables.
    This avoids shadowing issues and makes code more maintainable.
    """
    
    def __init__(self):
        """Initialize the score manager with default values."""
        self.current_score = 0  # Instance variable
        self.high_score = 0     # Instance variable
    
    def add_points(self, points):
        """Add points to the current score."""
        self.current_score += points
        if self.current_score > self.high_score:
            self.high_score = self.current_score
        return self.current_score
    
    def reset(self):
        """Reset the current score."""
        self.current_score = 0

# Using the class
game = ScoreManager()
game.add_points(100)
game.add_points(50)
print(f"Final score: {game.current_score}")
print(f"High score: {game.high_score}")

print("\n" + "=" * 70)
print("END OF BEGINNER TUTORIAL")
print("=" * 70)

"""
SUMMARY:

1. Shadowing occurs when a variable in an inner scope has the same name
   as a variable in an outer scope.

2. Python uses LEGB rule: Local → Enclosing → Global → Built-in

3. Common pitfall: UnboundLocalError when trying to read then modify a global

4. Solution: Use 'global' keyword or (better) pass parameters and return values

5. Best practices:
   - Use descriptive names
   - Avoid shadowing built-ins
   - Minimize global variables
   - Prefer classes for state management
   - Use linters to catch shadowing issues

NEXT STEPS:
- Practice with exercises_01_basic.py
- Move on to 02_intermediate_function_shadowing.py
"""
