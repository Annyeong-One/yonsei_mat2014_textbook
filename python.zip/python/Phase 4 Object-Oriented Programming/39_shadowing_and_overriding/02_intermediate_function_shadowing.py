"""
02_intermediate_function_shadowing.py

INTERMEDIATE LEVEL: Function Shadowing and Nested Scopes

This module explores function shadowing, including function redefinition,
nested function shadowing, closures, and the 'nonlocal' keyword.

Topics covered:
1. Function redefinition (shadowing functions)
2. Nested function shadowing
3. Closures and variable capture
4. The nonlocal keyword
5. Import shadowing
6. Practical patterns and anti-patterns

Prerequisites:
- Completed 01_beginner_variable_shadowing.py
- Understanding of LEGB rule
- Basic knowledge of functions
"""

# =============================================================================
# SECTION 1: Function Redefinition (Function Shadowing)
# =============================================================================

print("=" * 70)
print("SECTION 1: Function Redefinition (Function Shadowing)")
print("=" * 70)

# Example 1.1: Basic function shadowing
# --------------------------------------
# When you define a function with the same name twice,
# the second definition shadows (replaces) the first

def greet():
    """First version of greet function."""
    return "Hello!"

print(f"First version: {greet()}")  # Output: Hello!

def greet():  # This shadows the previous greet() function
    """Second version of greet function - shadows the first."""
    return "Hi there!"

print(f"Second version: {greet()}")  # Output: Hi there!
# The first version is now completely inaccessible

print("\n" + "-" * 70 + "\n")

# Example 1.2: Function shadowing in different scopes
# ----------------------------------------------------
# Functions can shadow other functions in outer scopes

def calculate():
    """Global calculate function."""
    return "global calculation"

def outer_function():
    """
    This function defines a local calculate() function that
    shadows the global calculate() function within its scope.
    """
    
    def calculate():  # Shadows the global calculate()
        """Local calculate function - shadows global."""
        return "local calculation"
    
    # Inside outer_function, calculate() refers to the local version
    result = calculate()
    print(f"Inside outer_function: {result}")
    
    return result

outer_function()
# Outside outer_function, calculate() refers to the global version
print(f"Outside outer_function: {calculate()}")

print("\n" + "-" * 70 + "\n")

# Example 1.3: Storing function references before shadowing
# ----------------------------------------------------------
# You can keep a reference to the original function before shadowing

def process_data(data):
    """Original function."""
    return data.upper()

# Save a reference to the original function
original_process = process_data

# Now shadow the function
def process_data(data):
    """New function that shadows the original."""
    return data.lower()

# Both versions are accessible through different names
print(f"New version: {process_data('Hello')}")      # hello
print(f"Original version: {original_process('Hello')}")  # HELLO

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 2: Nested Function Shadowing
# =============================================================================

print("SECTION 2: Nested Function Shadowing")
print("=" * 70)

# Example 2.1: Multiple levels of nested functions
# -------------------------------------------------
# Each level of nesting can shadow names from outer levels

def level_1():
    """Outermost function level."""
    
    def helper():
        """Helper function at level 1."""
        return "Level 1 helper"
    
    def level_2():
        """Middle function level."""
        
        def helper():  # Shadows level_1's helper()
            """Helper function at level 2 - shadows level 1."""
            return "Level 2 helper"
        
        def level_3():
            """Innermost function level."""
            
            def helper():  # Shadows level_2's helper()
                """Helper function at level 3 - shadows level 2."""
                return "Level 3 helper"
            
            # This calls the level_3 helper
            print(f"Level 3 calls: {helper()}")
        
        # This calls the level_2 helper
        print(f"Level 2 calls: {helper()}")
        level_3()
    
    # This calls the level_1 helper
    print(f"Level 1 calls: {helper()}")
    level_2()

level_1()

print("\n" + "-" * 70 + "\n")

# Example 2.2: Accessing outer function despite shadowing
# --------------------------------------------------------
# Once shadowed, you can't directly access the outer function,
# but you can use other patterns

def outer():
    """Outer function with utilities."""
    
    def utility_function():
        """Utility in outer scope."""
        return "outer utility"
    
    # Store reference to utility_function in outer scope
    outer_utility = utility_function
    
    def inner():
        """Inner function that shadows utility_function."""
        
        def utility_function():  # Shadows outer's utility_function
            """Utility in inner scope - shadows outer."""
            return "inner utility"
        
        # Can still access outer's version through saved reference
        # (if it was passed or stored in a way accessible here)
        print(f"Inner's utility: {utility_function()}")
        # Note: outer_utility is not accessible here without passing it
    
    inner()
    print(f"Outer's utility: {utility_function()}")

outer()

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 3: Closures and Variable Capture
# =============================================================================

print("SECTION 3: Closures and Variable Capture")
print("=" * 70)

"""
A closure is a function that remembers values from its enclosing scope,
even after the outer function has finished executing.
Shadowing interacts with closures in important ways.
"""

# Example 3.1: Basic closure without shadowing
# ---------------------------------------------
# The inner function "closes over" the outer function's variables

def make_multiplier(factor):
    """
    Returns a function that multiplies its argument by factor.
    The returned function is a closure - it remembers 'factor'.
    """
    
    def multiplier(x):
        """Closure that remembers factor from enclosing scope."""
        return x * factor  # 'factor' is from enclosing scope
    
    return multiplier

# Create different multipliers
times_2 = make_multiplier(2)
times_5 = make_multiplier(5)

print(f"5 * 2 = {times_2(5)}")  # Output: 10
print(f"5 * 5 = {times_5(5)}")  # Output: 25

print("\n" + "-" * 70 + "\n")

# Example 3.2: Closure with shadowing
# ------------------------------------
# When an inner function shadows a variable, it doesn't affect the closure

def create_counter(start):
    """
    Returns a function that counts from 'start'.
    This demonstrates closure with shadowing.
    """
    count = start  # This 'count' is in the enclosing scope
    
    def increment():
        """
        This function wants to modify 'count' from enclosing scope.
        Without 'nonlocal', it would create a local 'count' (shadow).
        """
        # This would cause UnboundLocalError (like with global):
        # count = count + 1
        
        # We'll handle this properly in the next example
        return count  # For now, just read it
    
    return increment

counter = create_counter(10)
print(f"Count: {counter()}")  # Output: 10

print("\n" + "-" * 70 + "\n")

# Example 3.3: The 'nonlocal' keyword
# ------------------------------------
# 'nonlocal' is like 'global', but for enclosing function scopes

def create_working_counter(start):
    """
    Returns a function that properly modifies a variable in enclosing scope.
    Uses 'nonlocal' to avoid shadowing.
    """
    count = start  # Variable in enclosing scope
    
    def increment():
        """
        Using 'nonlocal' tells Python: "Don't create a local 'count',
        use the one from the enclosing function scope."
        """
        nonlocal count  # Declare we're using enclosing scope's count
        count = count + 1  # Now we can modify it
        return count
    
    def get_count():
        """Get current count without modifying it."""
        return count  # No nonlocal needed for just reading
    
    return increment, get_count

# Create a counter
inc, get = create_working_counter(100)

print(f"Initial count: {get()}")  # 100
print(f"After increment: {inc()}")  # 101
print(f"After increment: {inc()}")  # 102
print(f"Current count: {get()}")  # 102

print("\n" + "-" * 70 + "\n")

# Example 3.4: Multiple nested levels with nonlocal
# --------------------------------------------------
# nonlocal searches enclosing scopes from inner to outer

def level_1():
    """Outermost function level."""
    x = "level 1"
    
    def level_2():
        """Middle function level."""
        x = "level 2"  # Shadows level_1's x
        
        def level_3():
            """Innermost function level."""
            nonlocal x  # Refers to level_2's x (closest enclosing)
            x = "modified by level 3"
            print(f"Level 3 modified x to: {x}")
        
        print(f"Before level 3: x = {x}")
        level_3()
        print(f"After level 3: x = {x}")  # Changed by level_3
    
    print(f"Before level 2: x = {x}")
    level_2()
    print(f"After level 2: x = {x}")  # Unchanged by level_2/level_3

level_1()

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 4: Import Shadowing
# =============================================================================

print("SECTION 4: Import Shadowing")
print("=" * 70)

"""
Import statements can shadow built-in names or other imported names.
This is a common source of bugs!
"""

# Example 4.1: Shadowing imported modules
# ----------------------------------------

import math  # Import the math module

print(f"math.pi before shadowing: {math.pi}")

def demonstrate_import_shadowing():
    """
    Local variables can shadow imported module names.
    This is usually unintentional and problematic!
    """
    
    # This shadows the imported 'math' module
    math = "I'm not a module anymore!"  # Bad practice!
    
    try:
        # This will fail because 'math' is now a string
        print(math.pi)
    except AttributeError as e:
        print(f"ERROR: {e}")
        print("Explanation: We shadowed 'math' with a string!")

demonstrate_import_shadowing()

# Outside the function, 'math' is still the module
print(f"math.pi after function: {math.pi}")

print("\n" + "-" * 70 + "\n")

# Example 4.2: Shadowing imported functions
# ------------------------------------------

from math import sqrt  # Import sqrt function directly

print(f"sqrt(16) before shadowing: {sqrt(16)}")

def bad_practice():
    """
    Demonstrates shadowing an imported function.
    This is confusing and should be avoided!
    """
    
    # Shadow the imported sqrt function
    sqrt = 100  # Now sqrt is an int, not a function!
    
    try:
        result = sqrt(25)  # This will fail
    except TypeError as e:
        print(f"ERROR: {e}")
        print("Explanation: We shadowed sqrt function with an integer!")

bad_practice()
print(f"sqrt(16) after function: {sqrt(16)}")  # Still works outside

print("\n" + "-" * 70 + "\n")

# Example 4.3: Import order and shadowing
# ----------------------------------------
# Later imports shadow earlier imports with the same name

def demonstrate_import_order():
    """
    When importing multiple items with the same name,
    the last import wins (shadows previous imports).
    """
    
    # Imagine these imports in a real file:
    # from module_a import process  # First import
    # from module_b import process  # Shadows module_a's process
    
    # The second 'process' shadows the first one
    # This is why explicit imports are often better:
    # import module_a
    # import module_b
    # Then use: module_a.process() and module_b.process()
    
    print("Tip: Use 'import module' instead of 'from module import *'")
    print("This avoids accidental shadowing!")

demonstrate_import_order()

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 5: Practical Patterns and Anti-patterns
# =============================================================================

print("SECTION 5: Practical Patterns and Anti-patterns")
print("=" * 70)

# ANTI-PATTERN 5.1: Redefining functions conditionally
# ----------------------------------------------------
# This creates confusion about which version of a function exists

DEBUG = True

if DEBUG:
    def log(message):
        """Debug version of log function."""
        print(f"[DEBUG] {message}")
else:
    def log(message):
        """Production version of log function."""
        print(f"[INFO] {message}")

# Problem: It's not clear which version is active without checking DEBUG
log("Application started")

print("\n" + "-" * 70 + "\n")

# BETTER PATTERN 5.1: Use parameters instead of shadowing
# --------------------------------------------------------

def create_logger(debug=False):
    """
    Factory function that returns the appropriate logger.
    This is clearer than conditional function definition.
    """
    
    def log(message):
        """Log with appropriate level based on debug flag."""
        prefix = "[DEBUG]" if debug else "[INFO]"
        print(f"{prefix} {message}")
    
    return log

# Create the logger you need
logger = create_logger(debug=True)
logger("Application started")

print("\n" + "-" * 70 + "\n")

# ANTI-PATTERN 5.2: Recursive shadowing confusion
# ------------------------------------------------

def factorial(n):
    """
    Original factorial function.
    """
    if n <= 1:
        return 1
    return n * factorial(n - 1)

print(f"factorial(5) = {factorial(5)}")

def create_wrapped_factorial():
    """
    This pattern is confusing because factorial shadows itself.
    Note: We need to be careful about the order of operations.
    """
    # We can't save a reference after defining the local factorial,
    # so this demonstrates why this pattern is problematic.
    # In real code, you'd use a decorator instead.
    
    # For demonstration purposes, we'll import from global scope
    import builtins
    
    def wrapped_factorial(n):  # Different name to avoid shadowing issue
        """Wrapped version."""
        print(f"Calculating factorial({n})")
        # Use the global factorial function
        return factorial(n)
    
    return wrapped_factorial

# This creates confusion about which factorial is being called
wrapped = create_wrapped_factorial()
print(f"wrapped factorial(3) = {wrapped(3)}")

print("\n" + "-" * 70 + "\n")

# BETTER PATTERN 5.2: Use descriptive names
# ------------------------------------------

def factorial_with_logging(n):
    """
    Use a different name instead of shadowing.
    This is much clearer!
    """
    print(f"Calculating factorial({n})")
    
    if n <= 1:
        return 1
    return n * factorial_with_logging(n - 1)

print(f"factorial_with_logging(3) = {factorial_with_logging(3)}")

print("\n" + "-" * 70 + "\n")

# GOOD PATTERN 5.3: Function decorators (advanced)
# -------------------------------------------------
# Decorators are a clean way to wrap functions without shadowing

def logging_decorator(func):
    """
    Decorator that adds logging to a function.
    This is the proper Python way to wrap functionality.
    """
    
    def wrapper(*args, **kwargs):
        """Wrapper function that adds logging."""
        print(f"Calling {func.__name__} with args={args}")
        result = func(*args, **kwargs)
        print(f"{func.__name__} returned {result}")
        return result
    
    return wrapper

@logging_decorator  # Apply decorator using @ syntax
def multiply(a, b):
    """Simple multiplication function."""
    return a * b

result = multiply(3, 4)
print(f"Final result: {result}")

print("\n" + "=" * 70)
print("END OF INTERMEDIATE TUTORIAL")
print("=" * 70)

"""
SUMMARY:

1. Functions can shadow other functions (redefinition)
   - In the same scope: second definition replaces first
   - In nested scopes: inner shadows outer

2. Nested functions can shadow outer functions
   - Each nesting level has its own scope
   - Inner scopes can't access shadowed outer names directly

3. Closures capture variables from enclosing scopes
   - Inner functions "remember" outer scope variables
   - Use 'nonlocal' to modify enclosing scope variables

4. Import shadowing is common and problematic
   - Local variables can shadow imported names
   - Later imports shadow earlier imports
   - Use explicit imports (import module) to avoid confusion

5. Best practices:
   - Avoid shadowing function names
   - Use descriptive, unique names
   - Prefer decorators over function wrapping
   - Use factory functions instead of conditional definitions
   - Use 'nonlocal' explicitly when modifying enclosing scope

NEXT STEPS:
- Practice with exercises_02_intermediate.py
- Move on to 03_advanced_method_override.py for OOP concepts
"""
