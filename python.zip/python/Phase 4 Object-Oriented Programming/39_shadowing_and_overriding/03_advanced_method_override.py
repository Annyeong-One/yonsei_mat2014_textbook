"""
03_advanced_method_override.py

ADVANCED LEVEL: Method Override in Object-Oriented Programming

This module covers method overriding in inheritance hierarchies, proper use
of super(), Method Resolution Order (MRO), and the distinction between
shadowing and overriding.

Topics covered:
1. Method overriding in inheritance
2. The super() function and its proper use
3. Method Resolution Order (MRO)
4. Multiple inheritance and super()
5. Abstract methods and override enforcement
6. Property overriding
7. Special methods (__init__, __str__, etc.)

Prerequisites:
- Completed 01 and 02 tutorials
- Understanding of classes and inheritance
- Basic OOP concepts
"""

# =============================================================================
# SECTION 1: Method Overriding Basics
# =============================================================================

print("=" * 70)
print("SECTION 1: Method Overriding Basics")
print("=" * 70)

"""
METHOD OVERRIDE vs SHADOWING:

Shadowing: A variable in an inner scope hides a variable in an outer scope.
            This happens with variables in functions.

Overriding: A method in a subclass replaces a method in a superclass.
            This is a fundamental OOP concept that enables polymorphism.

Key difference: Overriding is intentional and part of OOP design.
                Shadowing is often accidental and can cause bugs.
"""

# Example 1.1: Basic method override
# -----------------------------------

class Animal:
    """
    Base class representing a generic animal.
    Defines the interface that subclasses will override.
    """
    
    def __init__(self, name):
        """Initialize animal with a name."""
        self.name = name
    
    def speak(self):
        """
        Generic speak method.
        Subclasses should override this to provide specific behavior.
        """
        return f"{self.name} makes a sound"
    
    def describe(self):
        """
        Generic description method.
        This method is NOT overridden by subclasses (for demonstration).
        """
        return f"This is an animal named {self.name}"

class Dog(Animal):
    """
    Dog class that inherits from Animal.
    Overrides the speak() method to provide dog-specific behavior.
    """
    
    def speak(self):
        """
        Override the speak() method from Animal class.
        This provides dog-specific behavior.
        """
        return f"{self.name} says Woof!"
    
    # Note: describe() is inherited, not overridden

class Cat(Animal):
    """
    Cat class that inherits from Animal.
    Overrides the speak() method to provide cat-specific behavior.
    """
    
    def speak(self):
        """
        Override the speak() method from Animal class.
        This provides cat-specific behavior.
        """
        return f"{self.name} says Meow!"

# Create instances and demonstrate polymorphism
dog = Dog("Buddy")
cat = Cat("Whiskers")

print(dog.speak())      # Calls Dog's overridden method
print(cat.speak())      # Calls Cat's overridden method
print(dog.describe())   # Calls inherited method from Animal
print(cat.describe())   # Calls inherited method from Animal

print("\n" + "-" * 70 + "\n")

# Example 1.2: Checking method override with type()
# --------------------------------------------------

class Parent:
    """Parent class with a method."""
    
    def method(self):
        """Original method in parent class."""
        return "Parent method"

class ChildWithOverride(Parent):
    """Child that overrides the method."""
    
    def method(self):
        """Overridden method in child class."""
        return "Child method"

class ChildWithoutOverride(Parent):
    """Child that inherits the method without overriding."""
    pass  # Inherits method() as-is

# Demonstrate override behavior
parent = Parent()
child_with = ChildWithOverride()
child_without = ChildWithoutOverride()

print(f"Parent: {parent.method()}")
print(f"Child with override: {child_with.method()}")
print(f"Child without override: {child_without.method()}")

# Check where methods are defined
print(f"\nmethod defined in Parent: {type(parent).method}")
print(f"method defined in ChildWithOverride: {type(child_with).method}")
print(f"method inherited by ChildWithoutOverride: {type(child_without).method}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 2: The super() Function
# =============================================================================

print("SECTION 2: The super() Function")
print("=" * 70)

"""
super() returns a proxy object that allows you to call methods from a parent class.
It's essential for:
1. Extending parent behavior (not replacing it completely)
2. Working correctly with multiple inheritance
3. Following the Method Resolution Order (MRO)
"""

# Example 2.1: Using super() to extend parent behavior
# -----------------------------------------------------

class Vehicle:
    """Base vehicle class."""
    
    def __init__(self, brand, model):
        """Initialize vehicle with brand and model."""
        self.brand = brand
        self.model = model
        print(f"Vehicle.__init__ called: {brand} {model}")
    
    def start(self):
        """Start the vehicle."""
        return f"{self.brand} {self.model} is starting"

class ElectricVehicle(Vehicle):
    """
    Electric vehicle class that extends Vehicle.
    Uses super() to call parent's __init__ and extend functionality.
    """
    
    def __init__(self, brand, model, battery_capacity):
        """
        Initialize electric vehicle.
        Calls parent's __init__ using super(), then adds battery_capacity.
        """
        # Call parent's __init__ to handle brand and model
        super().__init__(brand, model)
        
        # Add electric-specific attributes
        self.battery_capacity = battery_capacity
        print(f"ElectricVehicle.__init__ called: battery={battery_capacity}kWh")
    
    def start(self):
        """
        Override start() but extend parent's behavior.
        Calls parent's method using super(), then adds more functionality.
        """
        # Get parent's behavior
        parent_message = super().start()
        
        # Add electric-specific behavior
        return f"{parent_message} (Battery: {self.battery_capacity}kWh)"

# Create an electric vehicle
tesla = ElectricVehicle("Tesla", "Model 3", 75)
print(tesla.start())

print("\n" + "-" * 70 + "\n")

# Example 2.2: super() vs explicit parent class call
# ---------------------------------------------------

class Shape:
    """Base shape class."""
    
    def __init__(self, color):
        """Initialize shape with color."""
        self.color = color

class Rectangle(Shape):
    """Rectangle class - demonstrates TWO ways to call parent init."""
    
    def __init__(self, color, width, height):
        """Initialize rectangle using super()."""
        # RECOMMENDED: Use super()
        super().__init__(color)
        self.width = width
        self.height = height

class ExplicitRectangle(Shape):
    """Rectangle class - demonstrates explicit parent call."""
    
    def __init__(self, color, width, height):
        """Initialize rectangle using explicit parent class call."""
        # WORKS BUT NOT RECOMMENDED: Explicit parent call
        Shape.__init__(self, color)
        self.width = width
        self.height = height

"""
Why prefer super() over explicit parent class call?
1. Works correctly with multiple inheritance
2. Follows MRO automatically
3. Makes code more maintainable (if parent class name changes)
4. Required for cooperative multiple inheritance
"""

rect1 = Rectangle("red", 10, 20)
rect2 = ExplicitRectangle("blue", 15, 25)

print(f"rect1 (super): {rect1.color}, {rect1.width}x{rect1.height}")
print(f"rect2 (explicit): {rect2.color}, {rect2.width}x{rect2.height}")

print("\n" + "-" * 70 + "\n")

# Example 2.3: Common mistake - forgetting to call super()
# ---------------------------------------------------------

class BankAccount:
    """Base bank account class."""
    
    def __init__(self, account_number, balance):
        """Initialize bank account."""
        self.account_number = account_number
        self.balance = balance
        print(f"BankAccount created: {account_number}, balance=${balance}")

class SavingsAccount(BankAccount):
    """Savings account WITHOUT calling super() - WRONG!"""
    
    def __init__(self, account_number, balance, interest_rate):
        """Initialize savings account - MISSING super() call!"""
        # BUG: Not calling super().__init__()!
        self.interest_rate = interest_rate
        # account_number and balance are NOT initialized!

class CheckingAccount(BankAccount):
    """Checking account WITH proper super() call - CORRECT!"""
    
    def __init__(self, account_number, balance, overdraft_limit):
        """Initialize checking account - correctly calls super()."""
        super().__init__(account_number, balance)  # Correct!
        self.overdraft_limit = overdraft_limit

# Demonstrate the bug
try:
    savings = SavingsAccount("SAV001", 1000, 0.05)
    print(f"Savings balance: {savings.balance}")  # Will fail!
except AttributeError as e:
    print(f"ERROR in SavingsAccount: {e}")
    print("Problem: We forgot to call super().__init__()!")

# Correct version works fine
checking = CheckingAccount("CHK001", 500, 200)
print(f"Checking balance: ${checking.balance}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 3: Method Resolution Order (MRO)
# =============================================================================

print("SECTION 3: Method Resolution Order (MRO)")
print("=" * 70)

"""
MRO determines the order in which Python searches for methods in a class hierarchy.
This is crucial for understanding super() and multiple inheritance.

Python uses C3 Linearization algorithm to compute MRO.
You can view a class's MRO using: ClassName.__mro__ or ClassName.mro()
"""

# Example 3.1: Viewing MRO
# -------------------------

class A:
    """Base class A."""
    def method(self):
        return "A.method"

class B(A):
    """Class B inherits from A."""
    def method(self):
        return "B.method"

class C(A):
    """Class C inherits from A."""
    def method(self):
        return "C.method"

class D(B, C):
    """Class D inherits from both B and C."""
    pass  # Doesn't override method

# View the MRO
print("Method Resolution Order for class D:")
for i, cls in enumerate(D.__mro__):
    print(f"  {i+1}. {cls.__name__}")

# When we call method() on D, it follows the MRO
d = D()
print(f"\nd.method() returns: {d.method()}")
print("Python found 'method' in B (second in MRO)")

print("\n" + "-" * 70 + "\n")

# Example 3.2: How super() follows MRO
# -------------------------------------

class Base:
    """Base class."""
    
    def method(self):
        """Base method."""
        print("Base.method")

class Left(Base):
    """Left branch of inheritance."""
    
    def method(self):
        """Override and call super()."""
        print("Left.method (before super)")
        super().method()  # Calls next in MRO
        print("Left.method (after super)")

class Right(Base):
    """Right branch of inheritance."""
    
    def method(self):
        """Override and call super()."""
        print("Right.method (before super)")
        super().method()  # Calls next in MRO
        print("Right.method (after super)")

class Bottom(Left, Right):
    """Bottom of diamond inheritance."""
    
    def method(self):
        """Override and call super()."""
        print("Bottom.method (before super)")
        super().method()  # Calls next in MRO
        print("Bottom.method (after super)")

# MRO for Bottom: Bottom -> Left -> Right -> Base -> object
print("MRO for Bottom:", [cls.__name__ for cls in Bottom.__mro__])

print("\nCalling bottom.method():")
bottom = Bottom()
bottom.method()

print("\nNotice: super() in Left calls Right, not Base!")
print("This is cooperative multiple inheritance.")

print("\n" + "-" * 70 + "\n")

# Example 3.3: Multiple inheritance with different signatures
# ------------------------------------------------------------

class TimestampMixin:
    """Mixin that adds timestamp functionality."""
    
    def __init__(self, *args, **kwargs):
        """
        Initialize with timestamp.
        Note: Must call super() for cooperative inheritance!
        """
        super().__init__(*args, **kwargs)  # Pass along to next in MRO
        import datetime
        self.created_at = datetime.datetime.now()

class User:
    """User class with basic attributes."""
    
    def __init__(self, username, email):
        """Initialize user."""
        super().__init__()  # Important for mixins!
        self.username = username
        self.email = email

class TimestampedUser(TimestampMixin, User):
    """User with automatic timestamp."""
    
    def __init__(self, username, email):
        """
        Initialize timestamped user.
        super().__init__() will call TimestampMixin.__init__,
        which will call User.__init__ following MRO.
        """
        super().__init__(username, email)

# Create a timestamped user
user = TimestampedUser("alice", "alice@example.com")
print(f"User: {user.username}, {user.email}")
print(f"Created: {user.created_at}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 4: Abstract Methods and Override Enforcement
# =============================================================================

print("SECTION 4: Abstract Methods and Override Enforcement")
print("=" * 70)

"""
Abstract Base Classes (ABC) allow you to enforce that subclasses
override certain methods. This is useful for defining interfaces.
"""

from abc import ABC, abstractmethod

# Example 4.1: Abstract base class
# ---------------------------------

class Shape(ABC):
    """
    Abstract base class for shapes.
    Cannot be instantiated directly - must be subclassed.
    """
    
    def __init__(self, color):
        """Initialize shape with color."""
        self.color = color
    
    @abstractmethod
    def area(self):
        """
        Abstract method - must be overridden by subclasses.
        Subclasses cannot be instantiated without overriding this.
        """
        pass  # No implementation in base class
    
    @abstractmethod
    def perimeter(self):
        """Abstract method for perimeter calculation."""
        pass
    
    def describe(self):
        """
        Concrete method - can be inherited as-is or overridden.
        Not marked as abstract, so subclasses can use it directly.
        """
        return f"A {self.color} shape"

class Circle(Shape):
    """
    Circle class that properly implements abstract methods.
    """
    
    def __init__(self, color, radius):
        """Initialize circle."""
        super().__init__(color)
        self.radius = radius
    
    def area(self):
        """Override abstract area() method."""
        import math
        return math.pi * self.radius ** 2
    
    def perimeter(self):
        """Override abstract perimeter() method."""
        import math
        return 2 * math.pi * self.radius

class IncompleteShape(Shape):
    """
    This class doesn't implement all abstract methods.
    It CANNOT be instantiated!
    """
    
    def __init__(self, color):
        super().__init__(color)
    
    def area(self):
        """Implements area, but not perimeter."""
        return 0
    
    # Missing perimeter() implementation!

# Try to create instances
circle = Circle("red", 5)
print(f"Circle area: {circle.area():.2f}")
print(f"Circle perimeter: {circle.perimeter():.2f}")
print(f"Circle description: {circle.describe()}")

print("\nTrying to create abstract Shape directly:")
try:
    shape = Shape("blue")  # Will fail!
except TypeError as e:
    print(f"ERROR: {e}")

print("\nTrying to create IncompleteShape:")
try:
    incomplete = IncompleteShape("green")  # Will fail!
except TypeError as e:
    print(f"ERROR: {e}")
    print("Reason: perimeter() method not implemented!")

print("\n" + "-" * 70 + "\n")

# Example 4.2: Abstract method with default implementation
# ---------------------------------------------------------

class AbstractProcessor(ABC):
    """Abstract processor with some default behavior."""
    
    @abstractmethod
    def process(self, data):
        """
        Abstract method with default implementation.
        Subclasses MUST override, but can call super() to use default.
        """
        print("Default preprocessing")
        return data

class ConcreteProcessor(AbstractProcessor):
    """Concrete processor that extends abstract method."""
    
    def process(self, data):
        """Override process, but use super() for default behavior."""
        super().process(data)  # Call default implementation
        print(f"Custom processing: {data}")
        return data.upper()

processor = ConcreteProcessor()
result = processor.process("hello")
print(f"Result: {result}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 5: Property Overriding
# =============================================================================

print("SECTION 5: Property Overriding")
print("=" * 70)

"""
Properties (@property) can also be overridden in subclasses.
This is useful for changing behavior while maintaining interface.
"""

# Example 5.1: Overriding a property
# -----------------------------------

class Temperature:
    """Base temperature class with Celsius property."""
    
    def __init__(self, celsius):
        """Initialize with Celsius temperature."""
        self._celsius = celsius
    
    @property
    def celsius(self):
        """Get temperature in Celsius."""
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        """Set temperature in Celsius."""
        self._celsius = value
    
    @property
    def fahrenheit(self):
        """Get temperature in Fahrenheit."""
        return self._celsius * 9/5 + 32

class RestrictedTemperature(Temperature):
    """Temperature class with validation."""
    
    @property
    def celsius(self):
        """Override getter to add formatting."""
        return f"{self._celsius:.1f}°C"
    
    @celsius.setter
    def celsius(self, value):
        """Override setter to add validation."""
        if value < -273.15:
            raise ValueError("Temperature below absolute zero!")
        self._celsius = value

# Normal temperature
temp1 = Temperature(25)
print(f"Normal temp: {temp1.celsius}°C = {temp1.fahrenheit:.1f}°F")

# Restricted temperature with overridden property
temp2 = RestrictedTemperature(30)
print(f"Restricted temp: {temp2.celsius}")

try:
    temp2.celsius = -300  # Will fail validation
except ValueError as e:
    print(f"Validation error: {e}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 6: Overriding Special Methods
# =============================================================================

print("SECTION 6: Overriding Special Methods")
print("=" * 70)

"""
Special methods (dunder methods) like __init__, __str__, __repr__
can and should be overridden to customize object behavior.
"""

# Example 6.1: Overriding __str__ and __repr__
# ---------------------------------------------

class Person:
    """Base person class."""
    
    def __init__(self, name, age):
        """Initialize person."""
        self.name = name
        self.age = age
    
    def __str__(self):
        """String representation for end users."""
        return f"Person: {self.name}"
    
    def __repr__(self):
        """String representation for developers."""
        return f"Person(name='{self.name}', age={self.age})"

class Employee(Person):
    """Employee class that overrides special methods."""
    
    def __init__(self, name, age, employee_id):
        """Initialize employee."""
        super().__init__(name, age)
        self.employee_id = employee_id
    
    def __str__(self):
        """Override __str__ to include employee ID."""
        # Option 1: Completely replace parent behavior
        return f"Employee: {self.name} (ID: {self.employee_id})"
        
        # Option 2: Extend parent behavior (commented out)
        # parent_str = super().__str__()
        # return f"{parent_str} (ID: {self.employee_id})"
    
    def __repr__(self):
        """Override __repr__ for detailed representation."""
        return f"Employee(name='{self.name}', age={self.age}, employee_id='{self.employee_id}')"

person = Person("Alice", 30)
employee = Employee("Bob", 35, "E12345")

print(f"str(person): {str(person)}")
print(f"repr(person): {repr(person)}")
print(f"str(employee): {str(employee)}")
print(f"repr(employee): {repr(employee)}")

print("\n" + "-" * 70 + "\n")

# Example 6.2: Overriding comparison operators
# ---------------------------------------------

class Product:
    """Product class with comparison based on price."""
    
    def __init__(self, name, price):
        """Initialize product."""
        self.name = name
        self.price = price
    
    def __lt__(self, other):
        """Less than comparison based on price."""
        return self.price < other.price
    
    def __eq__(self, other):
        """Equality comparison based on price."""
        return self.price == other.price
    
    def __str__(self):
        """String representation."""
        return f"{self.name}: ${self.price}"

class DiscountedProduct(Product):
    """Product with discount that overrides comparison."""
    
    def __init__(self, name, price, discount):
        """Initialize discounted product."""
        super().__init__(name, price)
        self.discount = discount
    
    @property
    def final_price(self):
        """Calculate price after discount."""
        return self.price * (1 - self.discount)
    
    def __lt__(self, other):
        """Override comparison to use final price."""
        if isinstance(other, DiscountedProduct):
            return self.final_price < other.final_price
        return self.final_price < other.price
    
    def __str__(self):
        """Override string representation."""
        return f"{self.name}: ${self.price} ({self.discount*100}% off = ${self.final_price:.2f})"

# Create and compare products
laptop = Product("Laptop", 1000)
phone = DiscountedProduct("Phone", 800, 0.2)  # 20% off, final: $640

print(laptop)
print(phone)
print(f"Phone < Laptop: {phone < laptop}")  # Compares $640 < $1000

print("\n" + "=" * 70)
print("END OF ADVANCED TUTORIAL")
print("=" * 70)

"""
SUMMARY:

1. Method override is different from shadowing:
   - Override: Replacing parent class methods in subclasses (OOP feature)
   - Shadowing: Variable/function hiding in inner scopes (scope issue)

2. Use super() to call parent methods:
   - super().__init__() in __init__ methods
   - super().method() to extend parent behavior
   - Works correctly with multiple inheritance

3. Method Resolution Order (MRO):
   - Determines order of method lookup
   - View with ClassName.__mro__
   - super() follows MRO automatically
   - Critical for multiple inheritance

4. Abstract Base Classes (ABC):
   - Use @abstractmethod to enforce overrides
   - Cannot instantiate abstract classes
   - Ensures subclasses implement required methods

5. Property overriding:
   - Override @property getters and setters
   - Add validation or change behavior
   - Maintain interface compatibility

6. Special method overriding:
   - __init__, __str__, __repr__, __eq__, __lt__, etc.
   - Customize object behavior
   - Remember to call super() when appropriate

BEST PRACTICES:
- Always use super() instead of explicit parent class calls
- Call super().__init__() in __init__ methods
- Override special methods to customize behavior
- Use abstract base classes to define interfaces
- Document overridden methods clearly
- Test with isinstance() and issubclass()

NEXT STEPS:
- Practice with exercises_03_advanced.py
- Move on to 04_expert_complex_shadowing.py for edge cases
"""
