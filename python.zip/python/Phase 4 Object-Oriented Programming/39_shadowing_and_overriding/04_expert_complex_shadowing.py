"""
04_expert_complex_shadowing.py

EXPERT LEVEL: Complex Shadowing Patterns and Edge Cases

This module covers advanced shadowing scenarios including class vs instance
attributes, descriptors, metaclasses, and other sophisticated patterns.

Topics covered:
1. Class attribute vs instance attribute shadowing
2. Method vs attribute shadowing
3. Descriptor protocol and shadowing
4. Name mangling and private attributes
5. __getattribute__ and __getattr__ shadowing
6. Metaclass shadowing
7. Module-level shadowing patterns
8. Dynamic attribute shadowing

Prerequisites:
- Completed tutorials 01-03
- Strong understanding of OOP
- Familiarity with Python's data model
"""

# =============================================================================
# SECTION 1: Class Attribute vs Instance Attribute Shadowing
# =============================================================================

print("=" * 70)
print("SECTION 1: Class Attribute vs Instance Attribute Shadowing")
print("=" * 70)

"""
Class attributes are shared across all instances.
Instance attributes can shadow class attributes.
This is a common source of confusion!
"""

# Example 1.1: Basic class attribute shadowing
# ---------------------------------------------

class Counter:
    """
    Class demonstrating class attribute shadowing.
    """
    
    # Class attribute - shared by all instances
    count = 0
    
    def __init__(self, name):
        """
        Initialize counter with name.
        Note: We're NOT creating an instance attribute 'count' here.
        """
        self.name = name

# Create instances - they share the class attribute
counter1 = Counter("C1")
counter2 = Counter("C2")

print(f"counter1.count (class attribute): {counter1.count}")
print(f"counter2.count (class attribute): {counter2.count}")
print(f"Counter.count (class attribute): {Counter.count}")

# Modifying through the class affects all instances
Counter.count = 5
print(f"\nAfter Counter.count = 5:")
print(f"counter1.count: {counter1.count}")
print(f"counter2.count: {counter2.count}")

# Now create an INSTANCE attribute that shadows the class attribute
counter1.count = 10  # This creates an instance attribute!

print(f"\nAfter counter1.count = 10:")
print(f"counter1.count (instance attribute, shadows class): {counter1.count}")
print(f"counter2.count (still class attribute): {counter2.count}")
print(f"Counter.count (class attribute, unchanged): {Counter.count}")

# Check what's in the instance dictionary
print(f"\ncounter1.__dict__: {counter1.__dict__}")  # Has 'count'
print(f"counter2.__dict__: {counter2.__dict__}")  # Does NOT have 'count'

print("\n" + "-" * 70 + "\n")

# Example 1.2: Attribute lookup order
# ------------------------------------

class Demo:
    """
    Class demonstrating Python's attribute lookup order:
    1. Instance __dict__
    2. Class __dict__
    3. Parent classes (following MRO)
    """
    
    # Class attribute
    value = "CLASS VALUE"
    
    def __init__(self, instance_value=None):
        """
        Optionally create an instance attribute that shadows class attribute.
        """
        if instance_value is not None:
            self.value = instance_value  # Creates instance attribute

# Instance without instance attribute
obj1 = Demo()
print(f"obj1.value (from class): {obj1.value}")

# Instance with instance attribute (shadows class)
obj2 = Demo("INSTANCE VALUE")
print(f"obj2.value (from instance, shadows class): {obj2.value}")

# Access class attribute directly
print(f"Demo.value (class attribute): {Demo.value}")

# Delete instance attribute to reveal class attribute
del obj2.value  # Remove instance attribute
print(f"obj2.value after del (from class): {obj2.value}")

print("\n" + "-" * 70 + "\n")

# Example 1.3: Mutable class attributes - common pitfall!
# --------------------------------------------------------

class Dangerous:
    """
    DANGEROUS PATTERN: Mutable class attribute.
    This is a very common source of bugs!
    """
    
    # Mutable class attribute - SHARED BY ALL INSTANCES!
    items = []  # WARNING: This is dangerous!
    
    def __init__(self, name):
        """Initialize with name."""
        self.name = name
    
    def add_item(self, item):
        """
        BUG: This modifies the SHARED class attribute!
        All instances will see the change!
        """
        self.items.append(item)

class Safe:
    """
    SAFE PATTERN: Initialize instance attribute in __init__.
    """
    
    def __init__(self, name):
        """Initialize with name and create instance attribute."""
        self.name = name
        self.items = []  # Instance attribute - unique to each instance
    
    def add_item(self, item):
        """Add item to this instance's list."""
        self.items.append(item)

# Demonstrate the bug
print("DANGEROUS PATTERN:")
dangerous1 = Dangerous("D1")
dangerous2 = Dangerous("D2")

dangerous1.add_item("Item A")
dangerous2.add_item("Item B")

print(f"dangerous1.items: {dangerous1.items}")  # ['Item A', 'Item B'] - BUG!
print(f"dangerous2.items: {dangerous2.items}")  # ['Item A', 'Item B'] - BUG!

# Demonstrate the safe pattern
print("\nSAFE PATTERN:")
safe1 = Safe("S1")
safe2 = Safe("S2")

safe1.add_item("Item A")
safe2.add_item("Item B")

print(f"safe1.items: {safe1.items}")  # ['Item A'] - Correct!
print(f"safe2.items: {safe2.items}")  # ['Item B'] - Correct!

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 2: Method vs Attribute Shadowing
# =============================================================================

print("SECTION 2: Method vs Attribute Shadowing")
print("=" * 70)

"""
Instance attributes can shadow class methods!
This can lead to very confusing bugs.
"""

# Example 2.1: Attribute shadowing a method
# ------------------------------------------

class Calculator:
    """Class with methods that can be shadowed by attributes."""
    
    def add(self, a, b):
        """Add two numbers."""
        return a + b
    
    def multiply(self, a, b):
        """Multiply two numbers."""
        return a * b

calc = Calculator()

# Initially, add is a method
print(f"calc.add is a method: {type(calc.add)}")
result = calc.add(3, 4)
print(f"calc.add(3, 4) = {result}")

# Now shadow the method with an attribute
calc.add = 100  # Creates instance attribute that shadows method!

print(f"\nAfter calc.add = 100:")
print(f"calc.add is now an int: {type(calc.add)}")
print(f"calc.add = {calc.add}")

try:
    result = calc.add(3, 4)  # Will fail!
except TypeError as e:
    print(f"ERROR: {e}")
    print("Explanation: 'add' is now an int, not a method!")

# The class method is still accessible
print(f"\nCalculator.add still exists: {Calculator.add}")

# Delete instance attribute to reveal method again
del calc.add
print(f"After del calc.add: {calc.add(3, 4)}")

print("\n" + "-" * 70 + "\n")

# Example 2.2: Practical case - caching with attribute shadowing
# ---------------------------------------------------------------

class ExpensiveComputation:
    """
    Class that uses attribute shadowing for caching.
    First call computes and caches, subsequent calls return cached value.
    """
    
    def __init__(self, n):
        """Initialize with value n."""
        self.n = n
    
    def result(self):
        """
        Compute expensive result and cache it by shadowing this method.
        Note: This is a clever but potentially confusing pattern!
        """
        print(f"Computing expensive result for n={self.n}...")
        
        # Simulate expensive computation
        import time
        time.sleep(0.1)  # Pretend this takes time
        value = self.n ** 2
        
        # Shadow this method with the computed value
        self.result = value  # Now result is an attribute, not a method!
        
        return value

comp = ExpensiveComputation(10)

# First call: computes and caches
print(f"First call: {comp.result()}")  # Calls method

# Second call: returns cached value (attribute)
print(f"Second call: {comp.result}")  # Accesses attribute, no ()

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 3: Descriptor Protocol and Shadowing
# =============================================================================

print("SECTION 3: Descriptor Protocol and Shadowing")
print("=" * 70)

"""
Descriptors implement __get__, __set__, and/or __delete__.
They control attribute access and interact with shadowing in complex ways.

Data descriptors: Implement both __get__ and __set__ (or __delete__)
Non-data descriptors: Implement only __get__

Important: Instance attributes shadow non-data descriptors but NOT data descriptors!
"""

# Example 3.1: Non-data descriptor (can be shadowed)
# ---------------------------------------------------

class NonDataDescriptor:
    """
    Non-data descriptor (only __get__).
    Instance attributes can shadow this.
    """
    
    def __init__(self, value):
        """Initialize with value."""
        self.value = value
    
    def __get__(self, obj, objtype=None):
        """
        Called when accessing the attribute.
        obj: instance accessing the attribute
        objtype: type of obj
        """
        if obj is None:
            return self
        print(f"  NonDataDescriptor.__get__ called")
        return self.value

class TestNonData:
    """Class with non-data descriptor."""
    
    x = NonDataDescriptor(10)  # Class attribute with descriptor

obj = TestNonData()

# First access: calls descriptor's __get__
print("Accessing obj.x (through descriptor):")
print(f"obj.x = {obj.x}")

# Create instance attribute that shadows the descriptor
obj.x = 20  # Instance attribute shadows descriptor!

# Second access: returns instance attribute, descriptor NOT called
print("\nAfter obj.x = 20 (instance attribute created):")
print(f"obj.x = {obj.x}")  # Descriptor's __get__ is NOT called

print("\n" + "-" * 70 + "\n")

# Example 3.2: Data descriptor (cannot be shadowed by instance)
# --------------------------------------------------------------

class DataDescriptor:
    """
    Data descriptor (has __set__).
    Instance attributes CANNOT shadow this!
    """
    
    def __init__(self, value):
        """Initialize with value."""
        self.value = value
    
    def __get__(self, obj, objtype=None):
        """Called when accessing the attribute."""
        if obj is None:
            return self
        print(f"  DataDescriptor.__get__ called")
        return self.value
    
    def __set__(self, obj, value):
        """Called when setting the attribute."""
        print(f"  DataDescriptor.__set__ called with value={value}")
        self.value = value

class TestData:
    """Class with data descriptor."""
    
    x = DataDescriptor(10)  # Class attribute with descriptor

obj = TestData()

# Access: calls descriptor's __get__
print("Accessing obj.x (through descriptor):")
print(f"obj.x = {obj.x}")

# Try to set instance attribute
obj.x = 20  # This calls descriptor's __set__, does NOT create instance attribute!

# Access again: still goes through descriptor
print("\nAfter obj.x = 20 (descriptor's __set__ called):")
print(f"obj.x = {obj.x}")

# Verify no instance attribute created
print(f"\nobj.__dict__ = {obj.__dict__}")  # Empty! No instance attribute!

print("\n" + "-" * 70 + "\n")

# Example 3.3: Practical use - property descriptor
# -------------------------------------------------

class Temperature:
    """
    Practical example: @property creates a data descriptor.
    Instance attributes cannot shadow properties!
    """
    
    def __init__(self, celsius):
        """Initialize temperature."""
        self._celsius = celsius  # Stored as private attribute
    
    @property  # Creates a data descriptor
    def celsius(self):
        """Get temperature in Celsius."""
        return self._celsius
    
    @celsius.setter
    def celsius(self, value):
        """Set temperature with validation."""
        if value < -273.15:
            raise ValueError("Below absolute zero!")
        self._celsius = value

temp = Temperature(25)
print(f"temp.celsius = {temp.celsius}")

# Try to shadow with instance attribute
try:
    temp.__dict__['celsius'] = 100  # Force instance attribute creation
    print(f"Forced instance attribute: temp.__dict__ = {temp.__dict__}")
    print(f"But temp.celsius still goes through property: {temp.celsius}")
except Exception as e:
    print(f"ERROR: {e}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 4: Name Mangling and Private Attributes
# =============================================================================

print("SECTION 4: Name Mangling and Private Attributes")
print("=" * 70)

"""
Attributes starting with __ (but not ending with __) are name-mangled.
Python transforms __attr to _ClassName__attr to avoid shadowing in subclasses.
"""

# Example 4.1: Name mangling basics
# ----------------------------------

class Parent:
    """Parent class with private attribute."""
    
    def __init__(self):
        """Initialize with private attribute."""
        self.__private = "Parent's private"  # Name mangled!
        self.public = "Parent's public"
    
    def show_private(self):
        """Access private attribute."""
        return self.__private

class Child(Parent):
    """Child class that tries to shadow parent's private attribute."""
    
    def __init__(self):
        """Initialize child."""
        super().__init__()
        self.__private = "Child's private"  # Different name after mangling!
    
    def show_child_private(self):
        """Access child's private attribute."""
        return self.__private

child = Child()

# Both private attributes exist - they don't shadow each other!
print(f"Parent's private (via method): {child.show_private()}")
print(f"Child's private (via method): {child.show_child_private()}")

# View the mangled names in __dict__
print(f"\nchild.__dict__:")
for key, value in child.__dict__.items():
    print(f"  {key}: {value}")

# Access mangled names directly (not recommended!)
print(f"\nDirect access to mangled names:")
print(f"child._Parent__private: {child._Parent__private}")
print(f"child._Child__private: {child._Child__private}")

print("\n" + "-" * 70 + "\n")

# Example 4.2: When name mangling prevents issues
# ------------------------------------------------

class BankAccount:
    """Bank account with protected balance."""
    
    def __init__(self, balance):
        """Initialize with balance."""
        self.__balance = balance  # Name mangled for protection
    
    def deposit(self, amount):
        """Deposit money."""
        if amount > 0:
            self.__balance += amount
    
    def get_balance(self):
        """Get current balance."""
        return self.__balance

class SavingsAccount(BankAccount):
    """
    Savings account might want its own __balance tracking.
    Thanks to name mangling, it doesn't interfere with parent's __balance.
    """
    
    def __init__(self, balance, interest_rate):
        """Initialize savings account."""
        super().__init__(balance)
        self.__balance = 0  # Child's own __balance (different from parent's!)
        self.interest_rate = interest_rate
    
    def apply_interest(self):
        """Apply interest (uses parent's balance)."""
        parent_balance = self.get_balance()  # Get parent's balance
        interest = parent_balance * self.interest_rate
        self.deposit(interest)

account = SavingsAccount(1000, 0.05)
print(f"Initial balance: ${account.get_balance()}")

account.apply_interest()
print(f"After interest: ${account.get_balance()}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 5: __getattribute__ and __getattr__ Shadowing
# =============================================================================

print("SECTION 5: __getattribute__ and __getattr__ Shadowing")
print("=" * 70)

"""
__getattribute__: Called for EVERY attribute access (even if attribute exists)
__getattr__: Called only when attribute is NOT found by normal lookup

These can intercept and modify attribute access, affecting shadowing behavior.
"""

# Example 5.1: __getattribute__ intercepts all access
# ----------------------------------------------------

class AllAccessInterceptor:
    """
    Class that intercepts ALL attribute access.
    This includes access to methods and special attributes!
    """
    
    def __init__(self):
        """Initialize with some attributes."""
        # Use object.__setattr__ to avoid infinite recursion
        object.__setattr__(self, 'data', {})
    
    def __getattribute__(self, name):
        """
        Intercept ALL attribute access.
        Must be very careful to avoid infinite recursion!
        """
        print(f"  __getattribute__ called for: {name}")
        
        # Must use object.__getattribute__ to avoid recursion
        return object.__getattribute__(self, name)
    
    def regular_method(self):
        """Regular method."""
        return "method called"

obj = AllAccessInterceptor()

print("Accessing obj.data:")
print(f"obj.data = {obj.data}")

print("\nAccessing obj.regular_method:")
print(f"obj.regular_method() = {obj.regular_method()}")

print("\n" + "-" * 70 + "\n")

# Example 5.2: __getattr__ for missing attributes
# ------------------------------------------------

class DynamicAttributes:
    """
    Class that creates attributes dynamically when accessed.
    __getattr__ is only called for missing attributes.
    """
    
    def __init__(self):
        """Initialize with existing attribute."""
        self.existing = "I exist!"
    
    def __getattr__(self, name):
        """
        Called only when attribute is NOT found.
        This allows dynamic attribute creation.
        """
        print(f"  __getattr__ called for missing attribute: {name}")
        
        # Return a dynamic value
        return f"Dynamic value for {name}"

obj = DynamicAttributes()

print("Accessing existing attribute:")
print(f"obj.existing = {obj.existing}")  # __getattr__ NOT called

print("\nAccessing missing attribute:")
print(f"obj.missing = {obj.missing}")  # __getattr__ IS called

print("\n" + "-" * 70 + "\n")

# Example 5.3: Combining __getattr__ with instance attributes
# ------------------------------------------------------------

class SmartDefaults:
    """
    Class that provides smart defaults for missing attributes.
    Instance attributes shadow the dynamic defaults.
    """
    
    def __init__(self):
        """Initialize with some predefined attributes."""
        self.name = "Real Name"
    
    def __getattr__(self, name):
        """Provide defaults for missing attributes."""
        # Return default values based on attribute name
        if name.startswith('default_'):
            return "DEFAULT VALUE"
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

obj = SmartDefaults()

print(f"obj.name (real attribute): {obj.name}")
print(f"obj.default_x (dynamic): {obj.default_x}")

# Create instance attribute that shadows dynamic default
obj.default_x = "CUSTOM VALUE"
print(f"obj.default_x (after assignment): {obj.default_x}")

try:
    print(f"obj.invalid: {obj.invalid}")
except AttributeError as e:
    print(f"ERROR: {e}")

print("\n" + "=" * 70 + "\n")

# =============================================================================
# SECTION 6: Metaclass Shadowing
# =============================================================================

print("SECTION 6: Metaclass Shadowing")
print("=" * 70)

"""
Metaclasses control class creation.
Class attributes from metaclass can be shadowed by instance class attributes.
This is very advanced!
"""

# Example 6.1: Basic metaclass attribute shadowing
# -------------------------------------------------

class Meta(type):
    """
    Metaclass that adds class attributes.
    """
    
    def __new__(mcs, name, bases, attrs):
        """Create new class with additional attributes."""
        # Add metaclass attribute
        attrs['meta_attr'] = "FROM METACLASS"
        return super().__new__(mcs, name, bases, attrs)

class MyClass(metaclass=Meta):
    """Class using custom metaclass."""
    pass

# Access metaclass-provided attribute
print(f"MyClass.meta_attr: {MyClass.meta_attr}")

# Shadow metaclass attribute with class attribute
MyClass.meta_attr = "FROM CLASS"
print(f"After shadowing: {MyClass.meta_attr}")

print("\n" + "-" * 70 + "\n")

# Example 6.2: Metaclass method shadowing
# ----------------------------------------

class MethodMeta(type):
    """Metaclass that provides class methods."""
    
    def class_method(cls):
        """Method provided by metaclass."""
        return "METACLASS METHOD"

class MyClass2(metaclass=MethodMeta):
    """Class using metaclass with method."""
    pass

# Call metaclass-provided method
print(f"MyClass2.class_method(): {MyClass2.class_method()}")

# Shadow with class method
class MyClass3(metaclass=MethodMeta):
    """Class that shadows metaclass method."""
    
    @classmethod
    def class_method(cls):
        """Override metaclass method."""
        return "CLASS METHOD (shadows metaclass)"

print(f"MyClass3.class_method(): {MyClass3.class_method()}")

print("\n" + "=" * 70)
print("END OF EXPERT TUTORIAL")
print("=" * 70)

"""
SUMMARY:

1. Class vs Instance Attribute Shadowing:
   - Instance attributes shadow class attributes
   - Mutable class attributes are shared (common bug!)
   - Check __dict__ to see which attributes are instance vs class

2. Method vs Attribute Shadowing:
   - Instance attributes can shadow class methods
   - This can be used for caching but is confusing
   - Delete instance attribute to reveal method/class attribute

3. Descriptor Protocol:
   - Non-data descriptors: Can be shadowed by instance attributes
   - Data descriptors: CANNOT be shadowed by instance attributes
   - @property creates data descriptors

4. Name Mangling:
   - __private attributes are mangled to _ClassName__private
   - Prevents accidental shadowing in inheritance
   - Still accessible via mangled name (not truly private)

5. __getattribute__ and __getattr__:
   - __getattribute__: Intercepts ALL attribute access
   - __getattr__: Called only for missing attributes
   - Can modify shadowing behavior dynamically

6. Metaclass Shadowing:
   - Metaclass attributes can be shadowed by class attributes
   - Complex but powerful for framework design

BEST PRACTICES:
- Initialize mutable attributes in __init__, not as class attributes
- Be aware of attribute lookup order: instance → class → parent
- Use name mangling (__private) to prevent accidental shadowing
- Avoid shadowing methods with attributes (unless intentional caching)
- Use descriptors (@property) for computed attributes
- Document any intentional shadowing clearly

DEBUGGING TIPS:
- Use __dict__ to inspect instance attributes
- Use dir() to see all accessible attributes
- Use type(obj).attr vs obj.attr to distinguish class vs instance
- Use __mro__ to understand method resolution order

NEXT STEPS:
- Review all tutorials
- Complete all exercise files
- Build projects using these concepts
"""
