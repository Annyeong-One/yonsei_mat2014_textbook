# Python Shadowing and Method Override - Complete Tutorial Package

## Course Overview
This comprehensive package covers shadowing concepts and method overriding in Python, designed for undergraduate computer science students. The materials progress from fundamental concepts to advanced patterns.

## Package Structure

### Tutorial Files (Progressive Difficulty)
1. **01_beginner_variable_shadowing.py** - Introduction to variable shadowing
   - Local vs global scope
   - Basic shadowing concepts
   - Common pitfalls and best practices

2. **02_intermediate_function_shadowing.py** - Function shadowing and nested scopes
   - Function redefinition
   - Nested function shadowing
   - Closure behavior with shadowing

3. **03_advanced_method_override.py** - Object-oriented method overriding
   - Inheritance and method override
   - super() usage
   - Multiple inheritance considerations

4. **04_expert_complex_shadowing.py** - Advanced shadowing patterns
   - Class attribute vs instance attribute shadowing
   - Descriptor protocol and shadowing
   - Metaclass shadowing scenarios

### Exercise Files
- **exercises_01_basic.py** - Fundamental concepts (20 exercises)
- **exercises_02_intermediate.py** - Intermediate applications (15 exercises)
- **exercises_03_advanced.py** - Advanced scenarios (10 exercises)

### Solutions
- **solutions/** - Complete solutions with detailed explanations

## Learning Objectives

By completing this package, students will:
1. Understand Python's scoping rules (LEGB: Local, Enclosing, Global, Built-in)
2. Identify and resolve shadowing issues
3. Implement proper method overriding using inheritance
4. Apply super() correctly in single and multiple inheritance
5. Distinguish between shadowing and overriding
6. Write maintainable code avoiding common shadowing pitfalls

## Key Concepts Covered

### Variable Shadowing
- Local variables shadowing global variables
- Function parameters shadowing outer scope
- Loop variables and comprehension scope

### Function Shadowing
- Function redefinition in same scope
- Nested function shadowing
- Import shadowing

### Method Override
- Inheritance-based override
- super() for parent method access
- Method Resolution Order (MRO)
- Abstract methods and override enforcement

### Class Attribute Shadowing
- Instance attributes shadowing class attributes
- Property and descriptor shadowing
- Name mangling and private attributes

## Usage Instructions

1. **For Self-Study**: Work through tutorial files in order, running each example
2. **For Classroom**: Use tutorials for lecture demonstrations, exercises for homework
3. **For Practice**: Complete exercises before checking solutions
4. **For Reference**: Use as a quick reference for shadowing/override patterns

## Prerequisites
- Python 3.8 or higher
- Basic understanding of functions and classes
- Familiarity with object-oriented programming concepts

## Running the Code
```bash
# Run tutorial files
python 01_beginner_variable_shadowing.py

# Run exercises (attempt before viewing solutions)
python exercises_01_basic.py
```

## Additional Resources
- Python official documentation on scopes: https://docs.python.org/3/tutorial/classes.html#python-scopes-and-namespaces
- PEP 3135: New super(): https://www.python.org/dev/peps/pep-3135/

## Author Notes
These materials are designed for progressive learning. Each file builds upon previous concepts. Students should complete exercises to reinforce understanding before moving to the next difficulty level.

---
Created for undergraduate Python education | All code fully commented for learning
