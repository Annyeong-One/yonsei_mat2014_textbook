"""
exercises_01_basic.py

BASIC EXERCISES: Variable Shadowing

These exercises test understanding of basic shadowing concepts covered in
01_beginner_variable_shadowing.py

Instructions:
1. Read each exercise carefully
2. Write your solution in the designated area
3. Run the file to test your solution
4. Check solutions/solutions_01_basic.py if you get stuck

Topics tested:
- Local vs global scope
- Variable shadowing
- LEGB rule
- UnboundLocalError
- global keyword
"""

print("=" * 70)
print("BASIC EXERCISES: Variable Shadowing")
print("=" * 70)
print()

# =============================================================================
# EXERCISE 1: Identify the output (Easy)
# =============================================================================

print("EXERCISE 1: Identify the output")
print("-" * 70)

"""
What will this code print? Write your prediction, then uncomment to verify.

x = 10

def func():
    x = 20
    print(x)

func()
print(x)
"""

# YOUR PREDICTION:
# Line 1 will print: 
# Line 2 will print: 

# Uncomment to verify:
# x = 10
# def func():
#     x = 20
#     print(x)
# func()
# print(x)

print()

# =============================================================================
# EXERCISE 2: Fix the UnboundLocalError (Easy)
# =============================================================================

print("EXERCISE 2: Fix the UnboundLocalError")
print("-" * 70)

"""
The following code raises UnboundLocalError. Fix it using the 'global' keyword.
"""

counter = 0

def increment():
    """Fix this function to increment the global counter."""
    # TODO: Add global declaration here
    
    counter = counter + 1  # This line causes UnboundLocalError
    return counter

# Uncomment to test after fixing:
# print(f"Before: {counter}")
# increment()
# print(f"After: {counter}")

print()

# =============================================================================
# EXERCISE 3: Avoid global modification (Medium)
# =============================================================================

print("EXERCISE 3: Avoid global modification")
print("-" * 70)

"""
Rewrite the increment() function to avoid modifying the global variable.
Instead, accept a parameter and return the incremented value.
"""

total = 100

def increment_better(value):
    """
    TODO: Implement this function.
    Accept a value, increment it by 1, and return the new value.
    Do NOT use the global keyword.
    """
    pass  # Replace with your implementation

# Uncomment to test:
# print(f"Before: {total}")
# total = increment_better(total)
# print(f"After: {total}")

print()

# =============================================================================
# EXERCISE 4: LEGB Rule Tracing (Medium)
# =============================================================================

print("EXERCISE 4: LEGB Rule Tracing")
print("-" * 70)

"""
Trace through this code and determine what each print statement will output.
"""

x = "GLOBAL"

def outer():
    x = "OUTER"
    
    def inner():
        x = "INNER"
        print(f"1: {x}")
    
    inner()
    print(f"2: {x}")

outer()
print(f"3: {x}")

# YOUR PREDICTIONS:
# Print 1: 
# Print 2: 
# Print 3: 

# Uncomment to verify:
# (code is already above)

print()

# =============================================================================
# EXERCISE 5: Loop variable shadowing (Medium)
# =============================================================================

print("EXERCISE 5: Loop variable shadowing")
print("-" * 70)

"""
What will this code print? Explain why.
"""

i = 999

for i in range(3):
    print(f"In loop: {i}")

print(f"After loop: {i}")

# YOUR PREDICTION:
# In loop will print (3 times): 
# After loop will print: 
# Explanation: 

print()

# =============================================================================
# EXERCISE 6: Function parameter shadowing (Easy)
# =============================================================================

print("EXERCISE 6: Function parameter shadowing")
print("-" * 70)

"""
Complete the function so that it returns True if the parameter
shadows a global variable, False otherwise.
"""

name = "Alice"

def has_shadowing(name):
    """
    TODO: This function should return True because parameter 'name'
    shadows the global 'name' variable.
    
    Hint: You can't directly check for shadowing, but you can return True
    since we know the parameter shadows the global.
    """
    pass  # Replace with your implementation

# Uncomment to test:
# print(has_shadowing("Bob"))  # Should print True

print()

# =============================================================================
# EXERCISE 7: Shadowing built-in names (Easy)
# =============================================================================

print("EXERCISE 7: Shadowing built-in names")
print("-" * 70)

"""
Which of the following variable names would shadow built-in names?
Mark each as True (shadows) or False (doesn't shadow).

Your answers:
"""

# TODO: Replace None with True or False
shadows_builtin = {
    'list': None,      # Does 'list' shadow a built-in?
    'my_list': None,   # Does 'my_list' shadow a built-in?
    'dict': None,      # Does 'dict' shadow a built-in?
    'print': None,     # Does 'print' shadow a built-in?
    'len': None,       # Does 'len' shadow a built-in?
    'length': None,    # Does 'length' shadow a built-in?
}

# print(shadows_builtin)

print()

# =============================================================================
# EXERCISE 8: Fix shadowing bug (Medium)
# =============================================================================

print("EXERCISE 8: Fix shadowing bug")
print("-" * 70)

"""
This code has a bug due to shadowing. Fix it.
"""

def calculate_total(prices):
    """Calculate total of prices."""
    total = 0
    for total in prices:  # BUG: Loop variable shadows total!
        total = total + total  # This doesn't work as intended
    return total

# TODO: Fix the function above

# Uncomment to test:
# result = calculate_total([10, 20, 30])
# print(f"Total: {result}")  # Should print 60

print()

# =============================================================================
# EXERCISE 9: Global vs Local (Easy)
# =============================================================================

print("EXERCISE 9: Global vs Local")
print("-" * 70)

"""
For each variable access, identify if it's accessing a local or global variable.
"""

score = 100  # Global

def game():
    score = 0  # Local
    score = score + 10
    print(score)  # Accessing: local or global?
    
game()
print(score)  # Accessing: local or global?

# YOUR ANSWERS:
# First print accesses: 
# Second print accesses: 

print()

# =============================================================================
# EXERCISE 10: Write shadowing code (Medium)
# =============================================================================

print("EXERCISE 10: Write shadowing code")
print("-" * 70)

"""
Write code that demonstrates shadowing at THREE levels (global, enclosing, local).
"""

# TODO: Write your code here
# Requirements:
# 1. Define a global variable 'value'
# 2. Define an outer function that creates a local 'value' (shadows global)
# 3. Define an inner function that creates a local 'value' (shadows outer)
# 4. Print the value at each level

print()

# =============================================================================
# EXERCISE 11: Identify the bug (Medium)
# =============================================================================

print("EXERCISE 11: Identify the bug")
print("-" * 70)

"""
This code has a shadowing-related bug. Identify and fix it.
"""

class ShoppingCart:
    total = 0  # Class attribute
    
    def add_item(self, price):
        """Add item to cart."""
        total = total + price  # BUG: What's wrong here?
        return total

# TODO: Identify the bug and explain how to fix it

# Your explanation:
# Bug: 
# Fix: 

print()

# =============================================================================
# EXERCISE 12: List comprehension scope (Easy)
# =============================================================================

print("EXERCISE 12: List comprehension scope")
print("-" * 70)

"""
What will this code print?
"""

x = "GLOBAL"
squares = [x**2 for x in range(3)]
print(x)

# YOUR PREDICTION: 
# Explanation: 

print()

# =============================================================================
# EXERCISE 13: Multiple functions (Medium)
# =============================================================================

print("EXERCISE 13: Multiple functions")
print("-" * 70)

"""
Complete the functions to demonstrate proper scope usage.
"""

balance = 1000

def deposit(amount):
    """
    TODO: Add amount to global balance using global keyword.
    """
    pass

def get_balance():
    """
    TODO: Return the global balance (no global keyword needed).
    """
    pass

# Uncomment to test:
# print(f"Initial: {get_balance()}")
# deposit(500)
# print(f"After deposit: {get_balance()}")

print()

# =============================================================================
# EXERCISE 14: Nested function challenge (Hard)
# =============================================================================

print("EXERCISE 14: Nested function challenge")
print("-" * 70)

"""
Predict the output of this complex nested function.
"""

def level1():
    x = "L1"
    
    def level2():
        x = "L2"
        
        def level3():
            print(x)  # Which x?
        
        level3()
        print(x)
    
    level2()
    print(x)

# YOUR PREDICTIONS:
# First print: 
# Second print: 
# Third print: 

# Uncomment to verify:
# level1()

print()

# =============================================================================
# EXERCISE 15: Best practice question (Easy)
# =============================================================================

print("EXERCISE 15: Best practice question")
print("-" * 70)

"""
Which of the following is the BEST practice? (Choose one)

A) Use global variables frequently for convenience
B) Shadow built-in names when you need different functionality  
C) Pass parameters and return values instead of using globals
D) Use single-letter variable names to avoid conflicts
"""

# YOUR ANSWER: 

print()

# =============================================================================
# EXERCISE 16: Conditional shadowing (Medium)
# =============================================================================

print("EXERCISE 16: Conditional shadowing")
print("-" * 70)

"""
What will this code print?
"""

def conditional_test():
    if True:
        message = "Inside if"
    
    print(message)  # Is this accessible?

# YOUR PREDICTION: 
# Will it print successfully? 
# If yes, what? 
# If no, why not? 

# Uncomment to test:
# conditional_test()

print()

# =============================================================================
# EXERCISE 17: Function redefinition (Easy)
# =============================================================================

print("EXERCISE 17: Function redefinition")
print("-" * 70)

"""
What happens when you define a function twice with the same name?
"""

def greet():
    return "Hello"

def greet():
    return "Hi"

# YOUR ANSWER:
# What does greet() return? 
# Why? 

# Uncomment to test:
# print(greet())

print()

# =============================================================================
# EXERCISE 18: Scope debugging (Hard)
# =============================================================================

print("EXERCISE 18: Scope debugging")
print("-" * 70)

"""
This code is meant to count function calls, but it doesn't work.
Debug and fix it.
"""

call_count = 0

def tracked_function():
    """This function should increment call_count each time it's called."""
    call_count = call_count + 1  # BUG here
    print(f"Called {call_count} times")

# TODO: Fix the function above

# Uncomment to test:
# tracked_function()
# tracked_function()
# tracked_function()

print()

# =============================================================================
# EXERCISE 19: Class vs instance (Easy)
# =============================================================================

print("EXERCISE 19: Class vs instance")
print("-" * 70)

"""
Predict what this code will print.
"""

class Demo:
    value = 10

obj = Demo()
obj.value = 20

print(Demo.value)  # What will this print?
print(obj.value)   # What will this print?

# YOUR PREDICTIONS:
# Demo.value: 
# obj.value: 
# Explanation: 

print()

# =============================================================================
# EXERCISE 20: Write clean code (Medium)
# =============================================================================

print("EXERCISE 20: Write clean code")
print("-" * 70)

"""
Rewrite this code to avoid shadowing and follow best practices.
"""

# BAD CODE:
list = [1, 2, 3]  # Shadows built-in
total = 0

def sum():  # Shadows built-in
    total = 0
    for i in list:
        total = total + i
    return total

# TODO: Rewrite the code above following best practices:
# 1. Don't shadow built-ins
# 2. Use descriptive names
# 3. Pass parameters instead of using globals

print()

print("=" * 70)
print("END OF BASIC EXERCISES")
print("=" * 70)
print()
print("Check solutions/solutions_01_basic.py for complete solutions!")
