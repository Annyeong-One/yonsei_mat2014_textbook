"""
exercises_02_intermediate.py

INTERMEDIATE EXERCISES: Function Shadowing and Closures

These exercises test understanding of concepts covered in
02_intermediate_function_shadowing.py

Instructions:
1. Read each exercise carefully
2. Write your solution in the designated area
3. Run the file to test your solution
4. Check solutions/solutions_02_intermediate.py if you get stuck

Topics tested:
- Function redefinition
- Nested function shadowing
- Closures and variable capture
- nonlocal keyword
- Import shadowing
"""

print("=" * 70)
print("INTERMEDIATE EXERCISES: Function Shadowing and Closures")
print("=" * 70)
print()

# =============================================================================
# EXERCISE 1: Function redefinition (Easy)
# =============================================================================

print("EXERCISE 1: Function redefinition")
print("-" * 70)

"""
What will this code output? Predict, then verify.
"""

def compute(x):
    return x * 2

result1 = compute(5)

def compute(x):
    return x * 3

result2 = compute(5)

# YOUR PREDICTIONS:
# result1 = 
# result2 = 
# Explanation: 

# Uncomment to verify:
# print(f"result1: {result1}")
# print(f"result2: {result2}")

print()

# =============================================================================
# EXERCISE 2: Nested function shadowing (Medium)
# =============================================================================

print("EXERCISE 2: Nested function shadowing")
print("-" * 70)

"""
Write nested functions where each level shadows a helper function.
"""

def outer():
    """
    TODO: Create this structure:
    - Define a helper() function that returns "outer helper"
    - Define an inner() function that:
      - Defines its own helper() that returns "inner helper"
      - Calls both helpers (somehow access both)
      - Returns both results
    """
    pass  # Your implementation here

# Uncomment to test:
# outer()

print()

# =============================================================================
# EXERCISE 3: Build a counter with closure (Medium)
# =============================================================================

print("EXERCISE 3: Build a counter with closure")
print("-" * 70)

"""
Create a function that returns a counter. The counter should:
- Start at a given value
- Increment by 1 each time it's called
- Return the new count
"""

def make_counter(start=0):
    """
    TODO: Implement this function.
    It should return a function that increments and returns a counter.
    Use a closure to remember the count.
    Hint: You'll need to use 'nonlocal' keyword.
    """
    pass  # Your implementation here

# Uncomment to test:
# counter = make_counter(10)
# print(counter())  # Should print 11
# print(counter())  # Should print 12
# print(counter())  # Should print 13

print()

# =============================================================================
# EXERCISE 4: nonlocal vs global (Medium)
# =============================================================================

print("EXERCISE 4: nonlocal vs global")
print("-" * 70)

"""
Fix this code. It tries to modify a variable in the enclosing scope
but raises UnboundLocalError.
"""

def outer():
    count = 0
    
    def inner():
        # TODO: Add the correct keyword here
        count = count + 1
        return count
    
    return inner

# Uncomment to test:
# inc = outer()
# print(inc())  # Should print 1
# print(inc())  # Should print 2

print()

# =============================================================================
# EXERCISE 5: Multiple counters (Medium)
# =============================================================================

print("EXERCISE 5: Multiple counters")
print("-" * 70)

"""
Create independent counters that don't interfere with each other.
"""

def make_counter():
    """
    TODO: Implement this so that each returned function
    maintains its own independent count starting from 0.
    """
    pass  # Your implementation here

# Uncomment to test:
# counter1 = make_counter()
# counter2 = make_counter()
# print(counter1())  # 1
# print(counter1())  # 2
# print(counter2())  # 1 (independent!)
# print(counter1())  # 3

print()

# =============================================================================
# EXERCISE 6: Closure with multiple variables (Hard)
# =============================================================================

print("EXERCISE 6: Closure with multiple variables")
print("-" * 70)

"""
Create a bank account using closures.
"""

def create_account(initial_balance):
    """
    TODO: Return three functions:
    - deposit(amount): add to balance
    - withdraw(amount): subtract from balance (if sufficient funds)
    - get_balance(): return current balance
    
    All three functions should share the same balance variable.
    """
    pass  # Your implementation here

# Uncomment to test:
# deposit, withdraw, get_balance = create_account(100)
# print(get_balance())  # 100
# deposit(50)
# print(get_balance())  # 150
# withdraw(30)
# print(get_balance())  # 120

print()

# =============================================================================
# EXERCISE 7: Trace nested closures (Hard)
# =============================================================================

print("EXERCISE 7: Trace nested closures")
print("-" * 70)

"""
Predict the output of this code.
"""

def make_multiplier(x):
    def make_adder(y):
        def compute(z):
            return x * y + z
        return compute
    return make_adder

func = make_multiplier(2)(3)
result = func(4)

# YOUR PREDICTION:
# result = 
# Explanation: 

# Uncomment to verify:
# print(f"result: {result}")

print()

# =============================================================================
# EXERCISE 8: Fix closure bug (Medium)
# =============================================================================

print("EXERCISE 8: Fix closure bug")
print("-" * 70)

"""
This code has a classic closure bug. Fix it.
"""

def create_multipliers():
    """
    BUG: This should return a list of functions where:
    - functions[0](10) returns 0
    - functions[1](10) returns 10
    - functions[2](10) returns 20
    But it doesn't work correctly!
    """
    functions = []
    for i in range(3):
        def multiplier(x):
            return i * x  # BUG: 'i' is not captured correctly
        functions.append(multiplier)
    return functions

# TODO: Fix the function above

# Uncomment to test:
# multipliers = create_multipliers()
# for i, func in enumerate(multipliers):
#     print(f"multipliers[{i}](10) = {func(10)}")

print()

# =============================================================================
# EXERCISE 9: Import shadowing (Easy)
# =============================================================================

print("EXERCISE 9: Import shadowing")
print("-" * 70)

"""
Identify what's wrong with this code.
"""

import math

def calculate():
    math = 42  # What's wrong here?
    return math.pi  # Will this work?

# YOUR ANSWER:
# Problem: 
# Fix: 

print()

# =============================================================================
# EXERCISE 10: Function factory (Hard)
# =============================================================================

print("EXERCISE 10: Function factory")
print("-" * 70)

"""
Create a function that generates custom validators.
"""

def create_validator(min_val, max_val):
    """
    TODO: Return a function that validates if a number
    is between min_val and max_val (inclusive).
    The returned function should return True or False.
    """
    pass  # Your implementation here

# Uncomment to test:
# is_valid_age = create_validator(0, 120)
# print(is_valid_age(25))   # True
# print(is_valid_age(150))  # False
# 
# is_valid_percentage = create_validator(0, 100)
# print(is_valid_percentage(50))   # True
# print(is_valid_percentage(101))  # False

print()

# =============================================================================
# EXERCISE 11: Decorator basics (Hard)
# =============================================================================

print("EXERCISE 11: Decorator basics")
print("-" * 70)

"""
Write a simple decorator that counts function calls.
"""

def call_counter(func):
    """
    TODO: Implement a decorator that counts how many times
    the decorated function is called.
    
    Hint: Use a closure to store the count.
    The wrapper function should print the count before calling func.
    """
    pass  # Your implementation here

# Uncomment to test:
# @call_counter
# def greet(name):
#     return f"Hello, {name}!"
# 
# print(greet("Alice"))  # Should print: "Call #1" then "Hello, Alice!"
# print(greet("Bob"))    # Should print: "Call #2" then "Hello, Bob!"

print()

# =============================================================================
# EXERCISE 12: Nonlocal in nested loops (Medium)
# =============================================================================

print("EXERCISE 12: Nonlocal in nested loops")
print("-" * 70)

"""
Fix this function to correctly count total iterations.
"""

def count_iterations():
    """Count total iterations in nested loops."""
    total = 0
    
    def outer_loop():
        for i in range(3):
            inner_loop()
    
    def inner_loop():
        # TODO: Fix this to increment outer total
        total = total + 1  # UnboundLocalError!
    
    outer_loop()
    return total

# Uncomment to test:
# print(count_iterations())  # Should print 3

print()

# =============================================================================
# EXERCISE 13: Closure scope chain (Hard)
# =============================================================================

print("EXERCISE 13: Closure scope chain")
print("-" * 70)

"""
Create a three-level nested structure with shared state.
"""

def create_nested_counter():
    """
    TODO: Create this structure:
    - level1_count variable
    - level1() function that increments level1_count
    - Inside level1(), create level2_count and level2() function
    - Inside level2(), create level3() function that can access both counts
    - Return level1 function
    
    The returned function should be callable and create the nested structure.
    """
    pass  # Your implementation here

# Uncomment to test when complete

print()

# =============================================================================
# EXERCISE 14: Preventing shadowing (Medium)
# =============================================================================

print("EXERCISE 14: Preventing shadowing")
print("-" * 70)

"""
Rewrite this to avoid shadowing without changing functionality.
"""

def process_data():
    data = [1, 2, 3, 4, 5]
    
    def filter_data():
        data = [x for x in data if x > 2]  # Shadows outer data
        return data
    
    filtered = filter_data()
    return filtered

# TODO: Rewrite to avoid shadowing while maintaining functionality

print()

# =============================================================================
# EXERCISE 15: Function reference vs call (Easy)
# =============================================================================

print("EXERCISE 15: Function reference vs call")
print("-" * 70)

"""
What's the difference between these two?
"""

def original():
    return "original"

saved = original
original = lambda: "modified"

# YOUR ANSWERS:
# saved() returns: 
# original() returns: 
# Explanation: 

# Uncomment to verify:
# print(saved())
# print(original())

print()

print("=" * 70)
print("END OF INTERMEDIATE EXERCISES")
print("=" * 70)
print()
print("Check solutions/solutions_02_intermediate.py for complete solutions!")
