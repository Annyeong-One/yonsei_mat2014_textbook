"""
exercises_03_advanced.py

ADVANCED EXERCISES: Method Override and Complex Shadowing

These exercises test understanding of concepts covered in
03_advanced_method_override.py and 04_expert_complex_shadowing.py

Instructions:
1. Read each exercise carefully
2. Write your solution in the designated area
3. Run the file to test your solution
4. Check solutions/solutions_03_advanced.py if you get stuck

Topics tested:
- Method overriding
- super() usage
- Method Resolution Order (MRO)
- Abstract base classes
- Class vs instance attribute shadowing
- Descriptor protocol
- Special methods
"""

print("=" * 70)
print("ADVANCED EXERCISES: Method Override and Complex Shadowing")
print("=" * 70)
print()

# =============================================================================
# EXERCISE 1: Basic method override (Easy)
# =============================================================================

print("EXERCISE 1: Basic method override")
print("-" * 70)

"""
Create a simple inheritance hierarchy with method override.
"""

class Vehicle:
    """Base vehicle class."""
    
    def __init__(self, brand):
        self.brand = brand
    
    def start(self):
        return f"{self.brand} is starting"

class ElectricCar(Vehicle):
    """
    TODO: Create ElectricCar that:
    - Inherits from Vehicle
    - Overrides start() to return "{brand} electric motor starting"
    """
    pass  # Your implementation here

# Uncomment to test:
# car = ElectricCar("Tesla")
# print(car.start())  # Should include "electric motor"

print()

# =============================================================================
# EXERCISE 2: Using super() (Medium)
# =============================================================================

print("EXERCISE 2: Using super()")
print("-" * 70)

"""
Fix this class to properly use super().
"""

class Animal:
    def __init__(self, name):
        self.name = name
        print(f"Animal.__init__: {name}")

class Dog(Animal):
    def __init__(self, name, breed):
        # TODO: Call parent __init__ using super()
        self.breed = breed
        print(f"Dog.__init__: {breed}")

# Uncomment to test:
# dog = Dog("Buddy", "Golden Retriever")
# print(f"{dog.name} is a {dog.breed}")

print()

# =============================================================================
# EXERCISE 3: Extending parent behavior (Medium)
# =============================================================================

print("EXERCISE 3: Extending parent behavior")
print("-" * 70)

"""
Create a child class that extends (not replaces) parent functionality.
"""

class Logger:
    def log(self, message):
        """Basic logging."""
        print(f"[LOG] {message}")

class TimestampLogger(Logger):
    """
    TODO: Override log() to add timestamp before the message,
    then call the parent's log() method using super().
    """
    pass  # Your implementation here

# Uncomment to test:
# logger = TimestampLogger()
# logger.log("System started")

print()

# =============================================================================
# EXERCISE 4: MRO prediction (Hard)
# =============================================================================

print("EXERCISE 4: MRO prediction")
print("-" * 70)

"""
Predict the Method Resolution Order for class D.
"""

class A:
    pass

class B(A):
    pass

class C(A):
    pass

class D(B, C):
    pass

# YOUR PREDICTION (order of classes):
# D → ? → ? → ? → object

# Uncomment to verify:
# print("Actual MRO:")
# for cls in D.__mro__:
#     print(f"  {cls.__name__}")

print()

# =============================================================================
# EXERCISE 5: Diamond inheritance (Hard)
# =============================================================================

print("EXERCISE 5: Diamond inheritance")
print("-" * 70)

"""
Implement cooperative multiple inheritance using super().
"""

class Base:
    def __init__(self):
        print("Base.__init__")
        super().__init__()

class Left(Base):
    def __init__(self):
        print("Left.__init__")
        super().__init__()

class Right(Base):
    def __init__(self):
        print("Right.__init__")
        super().__init__()

class Bottom(Left, Right):
    """
    TODO: Implement __init__ that properly calls super().
    Predict what will be printed when Bottom() is created.
    """
    pass  # Your implementation here

# YOUR PREDICTION (order of prints):
# 

# Uncomment to test:
# obj = Bottom()

print()

# =============================================================================
# EXERCISE 6: Abstract base class (Medium)
# =============================================================================

print("EXERCISE 6: Abstract base class")
print("-" * 70)

"""
Create an abstract base class for shapes.
"""

from abc import ABC, abstractmethod

class Shape(ABC):
    """
    TODO: Create abstract Shape class with:
    - Abstract method: area()
    - Abstract method: perimeter()
    - Concrete method: describe() that returns "A shape"
    """
    pass  # Your implementation here

class Rectangle(Shape):
    """
    TODO: Implement Rectangle that:
    - Takes width and height in __init__
    - Implements area() and perimeter()
    """
    pass  # Your implementation here

# Uncomment to test:
# rect = Rectangle(5, 10)
# print(f"Area: {rect.area()}")
# print(f"Perimeter: {rect.perimeter()}")

print()

# =============================================================================
# EXERCISE 7: Property override (Medium)
# =============================================================================

print("EXERCISE 7: Property override")
print("-" * 70)

"""
Override a property to add validation.
"""

class Person:
    def __init__(self, name, age):
        self._name = name
        self._age = age
    
    @property
    def age(self):
        return self._age
    
    @age.setter
    def age(self, value):
        self._age = value

class ValidatedPerson(Person):
    """
    TODO: Override the age property setter to validate:
    - Age must be >= 0
    - Age must be <= 150
    Raise ValueError if validation fails.
    """
    pass  # Your implementation here

# Uncomment to test:
# person = ValidatedPerson("Alice", 30)
# print(person.age)
# person.age = 200  # Should raise ValueError

print()

# =============================================================================
# EXERCISE 8: Special method override (Medium)
# =============================================================================

print("EXERCISE 8: Special method override")
print("-" * 70)

"""
Override special methods for custom behavior.
"""

class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author

class AnnotatedBook(Book):
    """
    TODO: 
    - Add 'notes' parameter to __init__
    - Override __str__ to return: "Title by Author (with notes)"
    - Override __repr__ to return: "AnnotatedBook('Title', 'Author', 'Notes')"
    - Override __eq__ to compare books by title and author only
    """
    pass  # Your implementation here

# Uncomment to test:
# book1 = AnnotatedBook("Python Guide", "Author", "Great book!")
# book2 = AnnotatedBook("Python Guide", "Author", "Different notes")
# print(str(book1))
# print(repr(book1))
# print(book1 == book2)  # Should be True (same title and author)

print()

# =============================================================================
# EXERCISE 9: Class attribute shadowing (Medium)
# =============================================================================

print("EXERCISE 9: Class attribute shadowing")
print("-" * 70)

"""
Demonstrate class vs instance attribute shadowing.
"""

class Counter:
    count = 0  # Class attribute
    
    def increment_class(self):
        """Increment the class attribute."""
        # TODO: Implement this
        pass
    
    def increment_instance(self):
        """Create/increment instance attribute (shadows class)."""
        # TODO: Implement this
        pass

# Uncomment to test:
# c1 = Counter()
# c2 = Counter()
# c1.increment_class()
# print(f"c1.count: {c1.count}, c2.count: {c2.count}")  # Both should be 1
# c1.increment_instance()
# print(f"c1.count: {c1.count}, c2.count: {c2.count}")  # c1: 1, c2: 1

print()

# =============================================================================
# EXERCISE 10: Multiple inheritance method resolution (Hard)
# =============================================================================

print("EXERCISE 10: Multiple inheritance method resolution")
print("-" * 70)

"""
Create a class with multiple inheritance and predict method calls.
"""

class Mixin1:
    def method(self):
        return "Mixin1"

class Mixin2:
    def method(self):
        return "Mixin2"

class MyClass(Mixin1, Mixin2):
    """
    TODO: Don't override method().
    Predict which method() will be called.
    """
    pass

# YOUR PREDICTION:
# MyClass().method() will return: 
# Explanation (MRO): 

# Uncomment to verify:
# obj = MyClass()
# print(obj.method())
# print([cls.__name__ for cls in MyClass.__mro__])

print()

# =============================================================================
# EXERCISE 11: Name mangling (Hard)
# =============================================================================

print("EXERCISE 11: Name mangling")
print("-" * 70)

"""
Use name mangling to prevent accidental override.
"""

class SecureBase:
    """
    TODO: Create a class with:
    - A private attribute __secret (use name mangling)
    - A public method get_secret() to access it
    """
    pass  # Your implementation here

class SecureChild(SecureBase):
    """
    TODO: Create a child class with:
    - Its own __secret attribute (won't conflict due to mangling)
    - A method get_child_secret() to access it
    """
    pass  # Your implementation here

# Uncomment to test:
# obj = SecureChild()
# print(obj.get_secret())       # Parent's secret
# print(obj.get_child_secret()) # Child's secret
# print(obj.__dict__)           # See both mangled names

print()

# =============================================================================
# EXERCISE 12: Mixin pattern (Hard)
# =============================================================================

print("EXERCISE 12: Mixin pattern")
print("-" * 70)

"""
Create a mixin that adds functionality to any class.
"""

class TimestampMixin:
    """
    TODO: Create a mixin that:
    - Adds a created_at attribute in __init__
    - Properly calls super().__init__() for cooperative inheritance
    """
    pass  # Your implementation here

class User:
    def __init__(self, username):
        super().__init__()
        self.username = username

class TimestampedUser(TimestampMixin, User):
    """
    TODO: Create a class that combines the mixin and User.
    Should have both username and created_at.
    """
    pass  # Your implementation here

# Uncomment to test:
# user = TimestampedUser("alice")
# print(f"User: {user.username}")
# print(f"Created: {user.created_at}")

print()

# =============================================================================
# EXERCISE 13: Descriptor basics (Hard)
# =============================================================================

print("EXERCISE 13: Descriptor basics")
print("-" * 70)

"""
Create a simple descriptor for validation.
"""

class PositiveNumber:
    """
    TODO: Implement a data descriptor that:
    - Stores a number
    - Validates it's positive in __set__
    - Raises ValueError if negative
    """
    pass  # Your implementation here

class Product:
    price = PositiveNumber()  # Use descriptor
    
    def __init__(self, name, price):
        self.name = name
        self.price = price  # Will use descriptor's __set__

# Uncomment to test:
# p = Product("Widget", 10)
# print(p.price)
# p.price = -5  # Should raise ValueError

print()

# =============================================================================
# EXERCISE 14: __getattr__ shadowing (Hard)
# =============================================================================

print("EXERCISE 14: __getattr__ shadowing")
print("-" * 70)

"""
Create a class that provides default values for missing attributes.
"""

class Config:
    """
    TODO: Implement a class that:
    - Has some normal attributes
    - Implements __getattr__ to return "DEFAULT" for missing attributes
    - Demonstrates that instance attributes shadow __getattr__
    """
    pass  # Your implementation here

# Uncomment to test:
# config = Config()
# config.debug = True
# print(config.debug)      # True (real attribute)
# print(config.timeout)    # "DEFAULT" (via __getattr__)
# config.timeout = 30
# print(config.timeout)    # 30 (now a real attribute)

print()

# =============================================================================
# EXERCISE 15: Complex override challenge (Hard)
# =============================================================================

print("EXERCISE 15: Complex override challenge")
print("-" * 70)

"""
Create a complete class hierarchy demonstrating multiple concepts.
"""

class DatabaseConnection:
    """
    TODO: Create base class with:
    - __init__(host, port)
    - connect() method
    - disconnect() method
    - __enter__ and __exit__ for context manager
    """
    pass  # Your implementation here

class PostgreSQLConnection(DatabaseConnection):
    """
    TODO: Create subclass that:
    - Adds database name to __init__
    - Overrides connect() to add PostgreSQL-specific logic
    - Uses super() appropriately
    - Maintains context manager functionality
    """
    pass  # Your implementation here

# Uncomment to test:
# with PostgreSQLConnection("localhost", 5432, "mydb") as conn:
#     print("Connected!")
# print("Disconnected!")

print()

print("=" * 70)
print("END OF ADVANCED EXERCISES")
print("=" * 70)
print()
print("Check solutions/solutions_03_advanced.py for complete solutions!")
