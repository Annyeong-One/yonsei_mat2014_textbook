"""
02_namespace_basics.py - Python Namespaces
Topic #23: Memory and Namespace
"""

print("=" * 70)
print("NAMESPACE BASICS")
print("=" * 70)

print("""
A NAMESPACE is a mapping from names to objects.
Think of it as a dictionary: {"name": object}

Python has 4 namespace types (LEGB):
1. Local (L): Inside functions
2. Enclosing (E): In outer functions
3. Global (G): Module level
4. Built-in (B): Python's built-ins
""")

# Inspecting namespaces
x = 10
y = 20

print("\nGlobal namespace (partial):")
g = globals()
print(f"  'x' exists: {'x' in g}")
print(f"  Value of x: {g['x']}")

def my_function():
    a = 100
    b = 200
    print("\n  Local namespace:")
    l = locals()
    for name in sorted(l.keys()):
        print(f"    {name}: {l[name]}")

my_function()

# LEGB demonstration
x = "global"

def outer():
    x = "enclosing"
    def inner():
        x = "local"
        print(f"    inner sees: '{x}'")  # Local
    inner()
    print(f"  outer sees: '{x}'")  # Enclosing

outer()
print(f"global sees: '{x}'")  # Global

print("""
NAME LOOKUP ORDER (LEGB):
1. Local → 2. Enclosing → 3. Global → 4. Built-in

Python searches in this order and stops at first match!

NAMESPACE LIFETIME:
- Built-in: Lives for entire program
- Global: Lives for module lifetime
- Enclosing: Lives for outer function call
- Local: Created when function called, destroyed when returns
""")

print("\nSee exercises.py for practice!")
