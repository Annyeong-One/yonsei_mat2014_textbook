# Topic #23: Memory and Namespace (Foundation)

## Overview
Foundational concepts for understanding Python's memory model and namespace system.
Provides the conceptual framework needed before deep diving into memory details.

## Duration: 3-5 hours

## Contents
- 01_stack_vs_heap.py - Stack and heap memory concepts
- 02_namespace_basics.py - Namespaces and LEGB rule
- exercises.py - 30 practice problems
- solutions.py - Complete solutions

## Prerequisites
- Functions (topic #15)
- LEGB rule (topic #20)
- Closures (topic #21)

## Next Steps
After this foundation, proceed to:
- **Topic #24**: Memory Deep Dive (comprehensive treatment)
- **Topic #25**: List Dynamic Memory Allocation (advanced)
