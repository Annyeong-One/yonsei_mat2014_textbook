"""
exercises.py - Memory and Namespace Exercises
Topic #23
"""

print("=" * 70)
print("TOPIC #23 EXERCISES")
print("=" * 70)

print("""
1. Where are variable NAMES stored?
2. Where are Python OBJECTS stored?
3. What happens to stack frame when function returns?
4. Name the 4 types of namespaces (LEGB)
5. In what order does Python search namespaces?

6. What is shadowing?
7. When is local namespace created?
8. When is local namespace destroyed?
9. How to access global variable from inside function?
10. Why can we use print() without importing it?

11. Draw memory model for: x = [1, 2, 3]
12. What causes stack overflow?
13. Why is stack faster than heap?
14. Use globals() to inspect global namespace
15. Use locals() inside a function

16. Create nested functions demonstrating LEGB
17. What error if name not found in any namespace?
18. Explain: variable NAMES vs variable OBJECTS
19. When does heap memory get freed?
20. What is Python's garbage collector for?

See solutions.py for complete answers!
""")
