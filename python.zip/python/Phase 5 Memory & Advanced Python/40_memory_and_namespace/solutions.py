"""
solutions.py - Complete Solutions
Topic #23
"""

print("=" * 70)
print("TOPIC #23 SOLUTIONS")
print("=" * 70)

print("""
1. Variable NAMES: STACK (in namespace/frame)
2. Variable OBJECTS: HEAP (all objects!)
3. Stack frame: DESTROYED/popped off stack
4. Local, Enclosing, Global, Built-in (LEGB)
5. Search order: L → E → G → B

6. Shadowing: Local name hides outer name
7. Local namespace: Created when function called
8. Local namespace: Destroyed when function returns
9. Use 'global' keyword: global x
10. print() is in Built-in namespace

11. Memory model:
    STACK:  x ────→ HEAP: [1,2,3] object
    
12. Stack overflow: Too many nested function calls

13. Stack faster: Organized, predictable access

14-20: See code examples below
""")

# Example: LEGB demonstration
x = "global"

def outer():
    x = "enclosing"
    def inner():
        x = "local"
        print(f"  {x}")  # Finds local first
    inner()

outer()

# Example: Using globals() and locals()
def demo():
    local_var = 100
    print(f"globals() keys: {len(globals())}")
    print(f"locals(): {locals()}")

demo()

print("\nAll solutions complete!")
