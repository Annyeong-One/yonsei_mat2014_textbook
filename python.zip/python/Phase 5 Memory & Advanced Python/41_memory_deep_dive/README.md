# Python Variable Assignment: Stack and Heap Memory Tutorial

## Overview
This comprehensive tutorial package covers variable assignment and memory management in Python, progressing from fundamental concepts to advanced memory internals. Designed for undergraduate computer science courses, it provides heavily commented code examples and practical exercises.

## Course Structure

### Beginner Level (Weeks 1-2)
- **01_beginner_variables_and_memory.py**: Introduction to variables, memory basics, and the object model
- **02_beginner_immutable_types.py**: Immutable types (int, float, str, tuple) and their memory behavior

### Intermediate Level (Weeks 3-4)
- **03_intermediate_mutable_types.py**: Mutable types (list, dict, set) and reference behavior
- **04_intermediate_aliasing_copying.py**: Aliasing, shallow copy vs deep copy, and reference semantics

### Advanced Level (Weeks 5-6)
- **05_advanced_memory_management.py**: Memory management, garbage collection, reference counting
- **06_advanced_object_lifecycle.py**: Object lifecycle, __del__, memory profiling, and internals

### Exercise Files
- **exercises_01_beginner.py**: Practice problems for beginner concepts
- **exercises_02_intermediate.py**: Practice problems for intermediate concepts
- **exercises_03_advanced.py**: Practice problems for advanced concepts
- **solutions_01_beginner.py**: Complete solutions with explanations
- **solutions_02_intermediate.py**: Complete solutions with explanations
- **solutions_03_advanced.py**: Complete solutions with explanations

## Key Concepts Covered

### Memory Model
- Stack vs Heap memory allocation
- Python's object model and PyObject structure
- Memory addresses and identity
- Reference counting mechanism

### Variable Assignment
- Name binding and the namespace
- Immutable vs mutable types
- Pass-by-object-reference semantics
- Aliasing and its implications

### Memory Management
- Automatic garbage collection
- Reference counting
- Cyclic garbage collector
- Memory optimization techniques
- Memory profiling tools

## Prerequisites
- Basic Python syntax knowledge
- Understanding of data types
- Familiarity with functions and scope

## Learning Objectives
By completing this tutorial, students will:
1. Understand how Python manages memory internally
2. Distinguish between stack and heap memory usage
3. Comprehend the difference between immutable and mutable types
4. Master reference semantics and copying mechanisms
5. Apply memory-efficient programming practices
6. Debug memory-related issues in Python programs

## How to Use This Package

### For Self-Study
1. Start with beginner files and progress sequentially
2. Run each example and observe the output
3. Complete exercises before viewing solutions
4. Use `id()`, `sys.getsizeof()`, and memory profilers to explore

### For Classroom Instruction
- Use main tutorial files for lectures (30-45 minutes each)
- Assign exercises as homework or in-class activities
- Use solutions for review sessions
- Encourage students to experiment with memory profiling

## Running the Code
```bash
# Run any tutorial file
python 01_beginner_variables_and_memory.py

# Run exercises (outputs will guide you)
python exercises_01_beginner.py

# View solutions
python solutions_01_beginner.py
```

## Additional Resources
- Python Memory Management Documentation
- `memory_profiler` package for profiling
- `sys.getsizeof()` for object size inspection
- `gc` module for garbage collection control
- `id()` function for memory address inspection

## Assessment Suggestions
1. Weekly quizzes on memory concepts
2. Code review exercises focusing on memory efficiency
3. Debugging assignments with memory leaks
4. Final project: Memory profiler implementation or optimization challenge

## Author Notes
This package is designed for comprehensive understanding of Python's memory model. Each file is heavily commented to support both instructor-led and self-paced learning. Encourage students to experiment beyond the provided examples and use debugging tools to visualize memory behavior.

## Version Information
- Python Version: 3.8+
- Last Updated: November 2025
- Difficulty Progression: Beginner → Intermediate → Advanced
