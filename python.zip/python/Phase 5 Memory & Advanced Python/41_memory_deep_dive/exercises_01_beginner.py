"""
exercises_01_beginner.py

LEVEL: Beginner
TOPICS: Variables, Memory, Immutable Types

INSTRUCTIONS:
- Complete each exercise below
- Run the file to check your understanding
- Solutions are in solutions_01_beginner.py
- Try to solve without looking at solutions first!
"""

import sys

print("=" * 70)
print("BEGINNER EXERCISES: Variables and Memory")
print("=" * 70)

# ============================================================================
# EXERCISE 1: Understanding Variables as References
# ============================================================================

print("\nEXERCISE 1: Variables as References")
print("-" * 70)

# Create a variable x with value 100
# Create a variable y that references the same object as x
# Check if they are the same object using 'is'
# Print their ids and check if they're equal

# YOUR CODE HERE:
x = None  # Replace this
y = None  # Replace this

# Expected output: y should reference the same object as x

# ============================================================================
# EXERCISE 2: Immutable Type Behavior
# ============================================================================

print("\nEXERCISE 2: Immutable Types")
print("-" * 70)

# Create an integer variable num = 50
# Store its id in a variable original_id
# Add 10 to num (num = num + 10)
# Store the new id in new_id
# Check if the id changed and print a message explaining why

# YOUR CODE HERE:

# Expected output: The id should have changed because integers are immutable

# ============================================================================
# EXERCISE 3: String Immutability
# ============================================================================

print("\nEXERCISE 3: String Immutability")
print("-" * 70)

# Create a string s = "Python"
# Try to concatenate " Programming" to it
# Check if the id changed
# Explain why strings are immutable

# YOUR CODE HERE:

# Expected output: Id changes, new string object created

# ============================================================================
# EXERCISE 4: Multiple References
# ============================================================================

print("\nEXERCISE 4: Multiple References")
print("-" * 70)

# Create a list L = [1, 2, 3]
# Create three more variables (a, b, c) that all reference L
# Use sys.getrefcount() to check the reference count
# Delete one variable and check the count again

# YOUR CODE HERE:

# Expected output: Refcount increases with more references, decreases with deletion

# ============================================================================
# EXERCISE 5: Integer Caching Investigation
# ============================================================================

print("\nEXERCISE 5: Integer Caching")
print("-" * 70)

# Write a function that tests whether two variables with the same
# integer value are the same object (using 'is')
# Test with values: -6, -5, 0, 100, 256, 257, 1000
# Find the exact range where integers are cached

# YOUR CODE HERE:
def test_integer_caching(value):
    """Test if Python caches this integer value"""
    # Your implementation
    pass

# Test various values
test_values = [-6, -5, 0, 100, 256, 257, 1000]
# Call your function for each value

# Expected output: Cached range is -5 to 256

# ============================================================================
# EXERCISE 6: String Interning Experiment
# ============================================================================

print("\nEXERCISE 6: String Interning")
print("-" * 70)

# Test string interning with different types of strings:
# 1. Simple identifier-like strings: "hello", "world"
# 2. Strings with spaces: "hello world"
# 3. Strings with special characters: "hello@world"
# Create two variables with the same string value and check if they're the same object

# YOUR CODE HERE:

# Expected output: Some strings are interned, others are not

# ============================================================================
# EXERCISE 7: Equality vs Identity
# ============================================================================

print("\nEXERCISE 7: == vs is")
print("-" * 70)

# Create two lists with the same values
# Create a third list that is an alias of the first
# Use == and 'is' to compare them
# Print results and explain the difference

# YOUR CODE HERE:

# Expected output: Understand when to use == vs is

# ============================================================================
# EXERCISE 8: Tuple Immutability with Mutable Elements
# ============================================================================

print("\nEXERCISE 8: Tuple with Mutable Elements")
print("-" * 70)

# Create a tuple containing a list: t = (1, 2, [3, 4])
# Try to change t[0] - what happens?
# Try to modify t[2] (the list inside) - what happens?
# Check the tuple's id before and after modifying the list
# Explain the behavior

# YOUR CODE HERE:

# Expected output: Can't reassign tuple elements, but can modify mutable elements

# ============================================================================
# EXERCISE 9: Function Parameters
# ============================================================================

print("\nEXERCISE 9: Immutable Function Parameters")
print("-" * 70)

# Write a function that takes an integer parameter and tries to modify it
# Call the function and check if the original variable changed
# Write another function that takes a string and tries to modify it
# Explain why the original values don't change

# YOUR CODE HERE:
def modify_integer(x):
    """Try to modify the integer"""
    pass

def modify_string(s):
    """Try to modify the string"""
    pass

# Test your functions

# Expected output: Original values unchanged because immutable types

# ============================================================================
# EXERCISE 10: Memory Size Investigation
# ============================================================================

print("\nEXERCISE 10: Object Memory Sizes")
print("-" * 70)

# Use sys.getsizeof() to find the memory size of:
# - Integers: 0, 1, 100, 10000
# - Strings: "", "a", "hello", "a" * 100
# - Create a table showing the sizes
# Observe the pattern and explain the overhead

# YOUR CODE HERE:

# Expected output: Understand Python's memory overhead per object

print("\n" + "=" * 70)
print("EXERCISES COMPLETE!")
print("Check solutions_01_beginner.py for answers and explanations")
print("=" * 70)
