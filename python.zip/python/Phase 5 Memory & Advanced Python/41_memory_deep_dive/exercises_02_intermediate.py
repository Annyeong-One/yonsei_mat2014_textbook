"""
exercises_02_intermediate.py

LEVEL: Intermediate
TOPICS: Mutable Types, Aliasing, Copying

INSTRUCTIONS:
- Complete each exercise below
- These are more challenging than beginner exercises
- Test your code thoroughly
- Solutions are in solutions_02_intermediate.py
"""

import copy
import sys

print("=" * 70)
print("INTERMEDIATE EXERCISES: Mutable Types and Copying")
print("=" * 70)

# ============================================================================
# EXERCISE 1: Aliasing Problem
# ============================================================================

print("\nEXERCISE 1: Fix the Aliasing Bug")
print("-" * 70)

# The following code has a bug due to aliasing
# Fix it so that modifying list2 doesn't affect list1

def buggy_function():
    list1 = [1, 2, 3, 4, 5]
    list2 = list1  # BUG: This creates an alias!
    list2.append(6)
    return list1, list2

# YOUR CODE HERE: Fix the function

# Expected output: list1 should be unchanged, list2 should have 6 appended

# ============================================================================
# EXERCISE 2: Mutable Default Argument
# ============================================================================

print("\nEXERCISE 2: Fix Mutable Default Argument")
print("-" * 70)

# This function has the classic mutable default argument bug
# Fix it to work correctly

def add_to_list(item, my_list=[]):  # BUG!
    my_list.append(item)
    return my_list

# YOUR CODE HERE: Fix the function

# Test cases:
# result1 = add_to_list(1)  # Should return [1]
# result2 = add_to_list(2)  # Should return [2], not [1, 2]!

# ============================================================================
# EXERCISE 3: Shallow Copy Problem
# ============================================================================

print("\nEXERCISE 3: Understanding Shallow Copy")
print("-" * 70)

# Create a nested list
# Make a shallow copy
# Modify a nested element
# Demonstrate that both the original and copy are affected
# Then create a deep copy and show the difference

# YOUR CODE HERE:

# Expected output: Demonstrate the problem with shallow copy and solution with deep copy

# ============================================================================
# EXERCISE 4: Matrix Modification
# ============================================================================

print("\nEXERCISE 4: Matrix Aliasing")
print("-" * 70)

# Create a 3x3 matrix (list of lists)
# Create a function that receives the matrix and modifies it
# Show that the original matrix is modified
# Create another function that creates and returns a modified copy

# YOUR CODE HERE:

# Expected output: First function modifies original, second doesn't

# ============================================================================
# EXERCISE 5: Dictionary Mutation
# ============================================================================

print("\nEXERCISE 5: Dictionary Mutation")
print("-" * 70)

# Write a function that takes a dictionary and modifies it
# Write another function that returns a modified copy without changing original
# Test both functions with the same dictionary

# YOUR CODE HERE:

# Expected output: Understand mutation vs copying for dictionaries

# ============================================================================
# EXERCISE 6: Function Side Effects
# ============================================================================

print("\nEXERCISE 6: Avoiding Side Effects")
print("-" * 70)

# Write a function that sorts a list
# Version 1: Should modify the list in-place (mutate)
# Version 2: Should return a sorted copy (no mutation)
# Test both versions

# YOUR CODE HERE:

# Expected output: Two different behaviors - mutation vs copying

# ============================================================================
# EXERCISE 7: Complex Nested Structure
# ============================================================================

print("\nEXERCISE 7: Deep Nested Structure")
print("-" * 70)

# Create a complex nested structure:
# A dictionary containing lists of dictionaries
# Create both shallow and deep copies
# Modify nested elements and observe the differences

# YOUR CODE HERE:

# Expected output: Demonstrate deep copy necessity for complex structures

# ============================================================================
# EXERCISE 8: List Comprehension vs Mutation
# ============================================================================

print("\nEXERCISE 8: Creating New vs Modifying")
print("-" * 70)

# Given a list of numbers, create TWO functions:
# Function 1: Modify the list in-place to square each element
# Function 2: Return a new list with squared elements
# Compare their behavior and performance (for large lists)

# YOUR CODE HERE:

# Expected output: Understand trade-offs between mutation and creation

# ============================================================================
# EXERCISE 9: Debugging Shared State
# ============================================================================

print("\nEXERCISE 9: Debug Shared State")
print("-" * 70)

# The following code has unexpected behavior due to shared state
# Find the problem and fix it

class ShoppingCart:
    def __init__(self, items=[]):  # BUG!
        self.items = items
    
    def add_item(self, item):
        self.items.append(item)

# YOUR CODE HERE: Fix the class

# Test:
# cart1 = ShoppingCart()
# cart1.add_item("Apple")
# cart2 = ShoppingCart()
# cart2.add_item("Banana")
# Both carts should be independent!

# ============================================================================
# EXERCISE 10: Performance Comparison
# ============================================================================

print("\nEXERCISE 10: Shallow vs Deep Copy Performance")
print("-" * 70)

# Create a large nested structure (e.g., 100x100 matrix)
# Measure the time taken for:
# 1. Aliasing (no copy)
# 2. Shallow copy
# 3. Deep copy
# Report the results

# YOUR CODE HERE:

# Expected output: Performance comparison with timings

print("\n" + "=" * 70)
print("EXERCISES COMPLETE!")
print("Check solutions_02_intermediate.py for answers and explanations")
print("=" * 70)
