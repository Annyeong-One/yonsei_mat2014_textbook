"""
exercises_03_advanced.py

LEVEL: Advanced
TOPICS: Memory Management, Garbage Collection, Object Lifecycle

INSTRUCTIONS:
- These exercises require deep understanding of Python internals
- Use gc, sys, tracemalloc modules
- Profile and optimize memory usage
- Solutions are in solutions_03_advanced.py
"""

import sys
import gc
import weakref
import tracemalloc

print("=" * 70)
print("ADVANCED EXERCISES: Memory Management")
print("=" * 70)

# ============================================================================
# EXERCISE 1: Cyclic Reference Detection
# ============================================================================

print("\nEXERCISE 1: Create and Detect Cyclic References")
print("-" * 70)

# Create a circular doubly-linked list with 3 nodes
# Use gc.get_referrers() to show the cycle
# Force garbage collection and verify cleanup
# Use gc.get_objects() before and after to count objects

# YOUR CODE HERE:

# Expected output: Demonstrate cycle creation, detection, and cleanup

# ============================================================================
# EXERCISE 2: Memory Leak Simulation
# ============================================================================

print("\nEXERCISE 2: Create and Fix a Memory Leak")
print("-" * 70)

# Create a class that intentionally leaks memory
# Use tracemalloc to measure the leak
# Fix the leak and verify with tracemalloc

# YOUR CODE HERE:

# Expected output: Show memory leak, then show fix

# ============================================================================
# EXERCISE 3: __slots__ Optimization
# ============================================================================

print("\nEXERCISE 3: Memory Optimization with __slots__")
print("-" * 70)

# Create a class WITHOUT __slots__
# Create a class WITH __slots__ 
# Create 10,000 instances of each
# Measure total memory usage using sys.getsizeof
# Calculate the memory savings

# YOUR CODE HERE:

# Expected output: Significant memory savings with __slots__

# ============================================================================
# EXERCISE 4: Weak Reference Cache
# ============================================================================

print("\nEXERCISE 4: Implement a Cache with Weak References")
print("-" * 70)

# Implement a cache using WeakValueDictionary
# Add objects to the cache
# Delete the objects elsewhere
# Verify that cache automatically removes entries
# Compare to a regular dict cache

# YOUR CODE HERE:

# Expected output: Weak reference cache automatically cleans up

# ============================================================================
# EXERCISE 5: Context Manager for Memory Profiling
# ============================================================================

print("\nEXERCISE 5: Memory Profiling Context Manager")
print("-" * 70)

# Create a context manager that:
# - Starts tracemalloc on entry
# - Tracks memory usage during the block
# - Reports peak memory usage on exit
# - Displays top memory allocations

# YOUR CODE HERE:

# Example usage:
# with MemoryProfiler():
#     # Your code here
#     pass

# Expected output: Memory profiling report

# ============================================================================
# EXERCISE 6: Object Lifecycle Tracking
# ============================================================================

print("\nEXERCISE 6: Track Complete Object Lifecycle")
print("-" * 70)

# Create a class that tracks its complete lifecycle:
# - __new__ (allocation)
# - __init__ (initialization)  
# - Regular usage
# - __del__ (destruction)
# Create instances and use gc.collect() to control destruction
# Print detailed lifecycle events

# YOUR CODE HERE:

# Expected output: Complete lifecycle trace for objects

# ============================================================================
# EXERCISE 7: Memory-Efficient Data Structure
# ============================================================================

print("\nEXERCISE 7: Compare Data Structure Efficiency")
print("-" * 70)

# Store 1 million integers using:
# 1. list
# 2. array.array
# 3. tuple
# Measure memory usage for each
# Calculate memory savings

# YOUR CODE HERE:

# Expected output: Compare memory usage of different structures

# ============================================================================
# EXERCISE 8: Generator vs List Memory
# ============================================================================

print("\nEXERCISE 8: Generator Memory Efficiency")
print("-" * 70)

# Create a function that generates squares of numbers 1 to 1,000,000
# Version 1: Return as list
# Version 2: Return as generator
# Measure memory usage of each
# Demonstrate the memory advantage of generators

# YOUR CODE HERE:

# Expected output: Generators use much less memory

# ============================================================================
# EXERCISE 9: Reference Count Debugging
# ============================================================================

print("\nEXERCISE 9: Debug Reference Counting")
print("-" * 70)

# Create an object with complex references:
# - Stored in multiple containers
# - Referenced by closures
# - Referenced by class attributes
# Use sys.getrefcount() and gc.get_referrers() to track all references
# Delete references one by one and track the count

# YOUR CODE HERE:

# Expected output: Understand all sources of references

# ============================================================================
# EXERCISE 10: Memory Optimization Challenge
# ============================================================================

print("\nEXERCISE 10: Optimize Memory Usage")
print("-" * 70)

# Given: A class that stores student records (name, grades, metadata)
# Task: Optimize memory usage for 100,000 student records
# Requirements:
# - Each student has: name (string), grades (list of floats), year (int)
# - Minimize memory per instance
# - Compare before/after memory usage

# YOUR CODE HERE:

# Unoptimized version:
class Student:
    def __init__(self, name, grades, year):
        self.name = name
        self.grades = grades
        self.year = year

# YOUR OPTIMIZED VERSION:

# Expected output: Significant memory reduction with optimizations

print("\n" + "=" * 70)
print("EXERCISES COMPLETE!")
print("Check solutions_03_advanced.py for answers and explanations")
print("=" * 70)
