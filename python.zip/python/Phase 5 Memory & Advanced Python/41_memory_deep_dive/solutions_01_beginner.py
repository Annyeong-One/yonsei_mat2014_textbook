"""
solutions_01_beginner.py

COMPLETE SOLUTIONS TO BEGINNER EXERCISES
Includes explanations and best practices
"""

import sys

print("=" * 70)
print("BEGINNER EXERCISE SOLUTIONS")
print("=" * 70)

# ============================================================================
# SOLUTION 1: Understanding Variables as References
# ============================================================================

print("\nSOLUTION 1: Variables as References")
print("-" * 70)

x = 100
y = x  # y now references the same object as x

print(f"x = {x}, id(x) = {id(x)}")
print(f"y = {y}, id(y) = {id(y)}")
print(f"x is y: {x is y}")
print(f"id(x) == id(y): {id(x) == id(y)}")

print("\nExplanation:")
print("When we write y = x, Python makes y reference the SAME object as x.")
print("They are aliases - two names for the same object in memory.")
print("This is why id(x) == id(y) returns True.")

# ============================================================================
# SOLUTION 2: Immutable Type Behavior
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 2: Immutable Types")
print("-" * 70)

num = 50
original_id = id(num)
print(f"Original: num = {num}, id = {original_id}")

num = num + 10  # This creates a NEW integer object
new_id = id(num)
print(f"After num + 10: num = {num}, id = {new_id}")
print(f"ID changed? {original_id != new_id}")

print("\nExplanation:")
print("Integers are IMMUTABLE. When we do num = num + 10:")
print("1. Python creates a NEW integer object with value 60")
print("2. Python makes 'num' reference this new object")
print("3. The original object (50) is no longer referenced by 'num'")
print("4. The id changes because num now references a different object")

# ============================================================================
# SOLUTION 3: String Immutability
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 3: String Immutability")
print("-" * 70)

s = "Python"
original_id = id(s)
print(f"Original: s = '{s}', id = {original_id}")

s = s + " Programming"
new_id = id(s)
print(f"After concatenation: s = '{s}', id = {new_id}")
print(f"ID changed? {original_id != new_id}")

print("\nExplanation:")
print("Strings are IMMUTABLE. String concatenation creates a NEW string.")
print("The original string 'Python' still exists (if referenced elsewhere).")
print("The variable 's' now references the new string 'Python Programming'.")

# ============================================================================
# SOLUTION 4: Multiple References
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 4: Multiple References")
print("-" * 70)

L = [1, 2, 3]
a = L
b = L
c = L

print(f"L = {L}")
print(f"Reference count: {sys.getrefcount(L)}")
print("(Note: getrefcount adds 1 temporary reference)")

del a
print(f"After del a: {sys.getrefcount(L)}")

del b
print(f"After del b: {sys.getrefcount(L)}")

print("\nExplanation:")
print("Each variable that references the object increases the reference count.")
print("When we delete a variable, the reference count decreases.")
print("The object is only deallocated when the refcount reaches 0.")

# ============================================================================
# SOLUTION 5: Integer Caching Investigation
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 5: Integer Caching")
print("-" * 70)

def test_integer_caching(value):
    """Test if Python caches this integer value"""
    x = value
    y = value
    is_cached = x is y
    print(f"  {str(value):5} : {'CACHED' if is_cached else 'NOT CACHED'}")
    return is_cached

print("Testing integer caching:")
test_values = [-6, -5, 0, 100, 256, 257, 1000]
for val in test_values:
    test_integer_caching(val)

print("\nExplanation:")
print("Python caches integers from -5 to 256 for performance.")
print("These are pre-created when Python starts.")
print("Any variable with these values references the same object.")
print("This is an optimization - don't rely on it in code!")
print("ALWAYS use == for value comparison, not 'is'.")

# ============================================================================
# SOLUTION 6: String Interning Experiment
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 6: String Interning")
print("-" * 70)

print("Testing string interning:")

# Simple strings
s1 = "hello"
s2 = "hello"
print(f"'hello': {s1 is s2} (interned: {s1 is s2})")

# Strings with spaces
s3 = "hello world"
s4 = "hello world"
print(f"'hello world': {s3 is s4} (interned: {s3 is s4})")

# Explicit interning
s5 = sys.intern("hello world")
s6 = sys.intern("hello world")
print(f"sys.intern('hello world'): {s5 is s6} (interned: {s5 is s6})")

print("\nExplanation:")
print("Python automatically interns:")
print("- Python identifiers (variable names, function names)")
print("- String literals that look like identifiers")
print("- Some compile-time constants")
print("\nYou can explicitly intern strings with sys.intern().")
print("This saves memory when you have many identical strings.")

# ============================================================================
# SOLUTION 7: Equality vs Identity
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 7: == vs is")
print("-" * 70)

list1 = [1, 2, 3]
list2 = [1, 2, 3]
list3 = list1

print("Three lists:")
print(f"list1 = {list1}, id = {id(list1)}")
print(f"list2 = {list2}, id = {id(list2)}")
print(f"list3 = {list3}, id = {id(list3)}")

print("\nEquality (==) - compares VALUES:")
print(f"  list1 == list2: {list1 == list2}")
print(f"  list1 == list3: {list1 == list3}")

print("\nIdentity (is) - compares OBJECTS:")
print(f"  list1 is list2: {list1 is list2}")
print(f"  list1 is list3: {list1 is list3}")

print("\nExplanation:")
print("== operator: Checks if values are equal (calls __eq__)")
print("is operator: Checks if variables reference the SAME object")
print("Use == for value comparison (almost always)")
print("Use 'is' for identity checks (None, True, False)")

# ============================================================================
# SOLUTION 8: Tuple Immutability with Mutable Elements
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 8: Tuple with Mutable Elements")
print("-" * 70)

t = (1, 2, [3, 4])
print(f"Original tuple: {t}, id = {id(t)}")

# Try to change immutable element
print("\nTrying t[0] = 10...")
try:
    t[0] = 10
except TypeError as e:
    print(f"Error: {e}")

# Modify mutable element
original_id = id(t)
print(f"\nModifying t[2] (the list)...")
t[2].append(5)
print(f"After modification: {t}")
print(f"Tuple id changed? {original_id != id(t)}")

print("\nExplanation:")
print("The TUPLE itself is immutable - you can't change WHICH objects it references.")
print("But if the tuple contains mutable objects (like lists),")
print("you CAN modify those mutable objects.")
print("The tuple still references the same list object,")
print("but that list object's contents have changed.")

# ============================================================================
# SOLUTION 9: Function Parameters
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 9: Immutable Function Parameters")
print("-" * 70)

def modify_integer(x):
    """Try to modify the integer"""
    print(f"  Inside: x = {x}, id = {id(x)}")
    x = x + 10  # Creates NEW object, rebinds local x
    print(f"  Modified: x = {x}, id = {id(x)}")
    return x

def modify_string(s):
    """Try to modify the string"""
    print(f"  Inside: s = '{s}', id = {id(s)}")
    s = s + " World"  # Creates NEW object, rebinds local s
    print(f"  Modified: s = '{s}', id = {id(s)}")
    return s

# Test integer
num = 5
print(f"Before: num = {num}, id = {id(num)}")
result = modify_integer(num)
print(f"After: num = {num}, id = {id(num)}")
print(f"Result: {result}")

print()

# Test string
text = "Hello"
print(f"Before: text = '{text}', id = {id(text)}")
result = modify_string(text)
print(f"After: text = '{text}', id = {id(text)}")
print(f"Result: {result}")

print("\nExplanation:")
print("Immutable objects passed to functions CANNOT be modified.")
print("Any 'modification' creates a NEW object and rebinds the local parameter.")
print("The original variable in the calling scope is unaffected.")

# ============================================================================
# SOLUTION 10: Memory Size Investigation
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 10: Object Memory Sizes")
print("-" * 70)

print("INTEGER SIZES:")
integers = [0, 1, 100, 10000]
for i in integers:
    print(f"  {str(i):10} : {sys.getsizeof(i):3} bytes")

print("\nSTRING SIZES:")
strings = ["", "a", "hello", "a" * 100]
for s in strings:
    display = repr(s) if len(s) <= 10 else f"'{s[:10]}...' (len={len(s)})"
    print(f"  {display:20} : {sys.getsizeof(s):3} bytes")

print("\nExplanation:")
print("Every Python object has overhead:")
print("- Reference count (8 bytes on 64-bit)")
print("- Type pointer (8 bytes on 64-bit)")
print("- Object-specific data")
print("\nSmall objects have HIGH overhead ratio.")
print("For memory efficiency with many small objects, consider:")
print("- array.array for numeric data")
print("- __slots__ for custom classes")
print("- Appropriate data structures")

print("\n" + "=" * 70)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 70)
