"""
solutions_02_intermediate.py

COMPLETE SOLUTIONS TO INTERMEDIATE EXERCISES
Includes detailed explanations and best practices
"""

import copy
import sys
import time

print("=" * 70)
print("INTERMEDIATE EXERCISE SOLUTIONS")
print("=" * 70)

# ============================================================================
# SOLUTION 1: Fix the Aliasing Bug
# ============================================================================

print("\nSOLUTION 1: Fix the Aliasing Bug")
print("-" * 70)

def fixed_function():
    list1 = [1, 2, 3, 4, 5]
    list2 = list1[:]  # FIXED: Create a copy instead of alias
    # Alternative: list2 = list1.copy()
    # Alternative: list2 = list(list1)
    list2.append(6)
    return list1, list2

result1, result2 = fixed_function()
print(f"list1: {result1}")
print(f"list2: {result2}")
print(f"Independent? {result1 is not result2}")

print("\nExplanation:")
print("Original bug: list2 = list1 creates an alias")
print("Fix: Use slicing [:] or .copy() to create a new list")
print("Now list1 and list2 are independent objects")

# ============================================================================
# SOLUTION 2: Fix Mutable Default Argument
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 2: Fix Mutable Default Argument")
print("-" * 70)

def add_to_list_fixed(item, my_list=None):
    """FIXED: Use None as default, create new list inside"""
    if my_list is None:
        my_list = []  # Create NEW list each time
    my_list.append(item)
    return my_list

result1 = add_to_list_fixed(1)
result2 = add_to_list_fixed(2)
print(f"First call: {result1}")
print(f"Second call: {result2}")
print(f"Independent? {result1 is not result2}")

print("\nExplanation:")
print("Problem: Mutable default arguments are created ONCE")
print("Solution: Use None as default, create new object inside function")
print("Each call now gets its own independent list")

# ============================================================================
# SOLUTION 3: Shallow Copy Problem
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 3: Understanding Shallow Copy")
print("-" * 70)

# Create nested list
original = [[1, 2], [3, 4], [5, 6]]
print(f"Original: {original}")

# Shallow copy
shallow = original[:]
print(f"Shallow copy: {shallow}")
print(f"Different outer objects? {original is not shallow}")

# Modify nested element
shallow[0].append(99)
print(f"\nAfter shallow[0].append(99):")
print(f"  Original: {original} (CHANGED!)")
print(f"  Shallow:  {shallow}  (changed)")
print(f"Nested lists shared? {original[0] is shallow[0]}")

# Deep copy - the solution
deep = copy.deepcopy(original)
deep[1].append(88)
print(f"\nAfter deep[1].append(88):")
print(f"  Original: {original} (unchanged)")
print(f"  Deep:     {deep}   (changed)")

print("\nExplanation:")
print("Shallow copy: Copies outer structure, shares nested objects")
print("Deep copy: Recursively copies everything")
print("Use deep copy for nested mutable structures")

# ============================================================================
# SOLUTION 4: Matrix Modification
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 4: Matrix Aliasing")
print("-" * 70)

def modify_matrix_inplace(matrix):
    """Modifies the original matrix"""
    for row in matrix:
        row.append(0)
    return matrix

def modify_matrix_copy(matrix):
    """Returns modified copy, original unchanged"""
    matrix_copy = copy.deepcopy(matrix)
    for row in matrix_copy:
        row.append(0)
    return matrix_copy

# Test both
original = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(f"Original matrix:\n{original}")

# Test in-place modification
matrix1 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
result1 = modify_matrix_inplace(matrix1)
print(f"\nAfter modify_matrix_inplace:")
print(f"  Original modified: {matrix1}")

# Test copy modification
matrix2 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
result2 = modify_matrix_copy(matrix2)
print(f"\nAfter modify_matrix_copy:")
print(f"  Original: {matrix2}")
print(f"  Copy: {result2}")

print("\nExplanation:")
print("First function mutates original (side effect)")
print("Second function returns modified copy (no side effect)")
print("Choose based on needs: mutation is faster, copy is safer")

# ============================================================================
# SOLUTION 5: Dictionary Mutation
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 5: Dictionary Mutation")
print("-" * 70)

def update_dict_inplace(d):
    """Modifies dictionary in place"""
    d['modified'] = True
    d['count'] = d.get('count', 0) + 1
    return d

def update_dict_copy(d):
    """Returns modified copy"""
    d_copy = d.copy()  # Shallow copy sufficient for flat dict
    d_copy['modified'] = True
    d_copy['count'] = d_copy.get('count', 0) + 1
    return d_copy

# Test
original = {'name': 'Alice', 'count': 5}
print(f"Original: {original}")

result1 = update_dict_inplace(original)
print(f"\nAfter update_dict_inplace:")
print(f"  Original: {original} (modified)")

original2 = {'name': 'Bob', 'count': 3}
result2 = update_dict_copy(original2)
print(f"\nAfter update_dict_copy:")
print(f"  Original: {original2} (unchanged)")
print(f"  Copy: {result2}")

print("\nExplanation:")
print("Dictionaries are mutable like lists")
print("Use .copy() for shallow copy, deepcopy() for nested dicts")

# ============================================================================
# SOLUTION 6: Function Side Effects
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 6: Avoiding Side Effects")
print("-" * 70)

def sort_inplace(lst):
    """Sorts list in-place (mutation)"""
    lst.sort()
    return lst

def sort_copy(lst):
    """Returns sorted copy (no mutation)"""
    return sorted(lst)  # sorted() returns new list

# Test both
original = [5, 2, 8, 1, 9, 3]
print(f"Original: {original}")

# In-place
list1 = [5, 2, 8, 1, 9, 3]
result1 = sort_inplace(list1)
print(f"\nAfter sort_inplace:")
print(f"  List: {list1} (sorted)")

# Copy
list2 = [5, 2, 8, 1, 9, 3]
result2 = sort_copy(list2)
print(f"\nAfter sort_copy:")
print(f"  Original: {list2} (unchanged)")
print(f"  Result: {result2} (sorted)")

print("\nExplanation:")
print(".sort() - modifies list in-place, returns None")
print("sorted() - returns new sorted list, original unchanged")

# ============================================================================
# SOLUTION 7: Complex Nested Structure
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 7: Deep Nested Structure")
print("-" * 70)

# Complex structure
data = {
    'users': [
        {'name': 'Alice', 'scores': [95, 87, 92]},
        {'name': 'Bob', 'scores': [88, 91, 84]}
    ],
    'settings': {'theme': 'dark', 'notifications': True}
}

shallow = copy.copy(data)
deep = copy.deepcopy(data)

print("Original structure created")

# Modify nested list through shallow copy
shallow['users'][0]['scores'].append(100)
print(f"\nAfter modifying through shallow copy:")
print(f"  Original affected? {100 in data['users'][0]['scores']}")

# Modify nested list through deep copy
deep['users'][1]['scores'].append(200)
print(f"\nAfter modifying through deep copy:")
print(f"  Original affected? {200 in data['users'][1]['scores']}")

print("\nExplanation:")
print("Complex nested structures REQUIRE deep copy")
print("Shallow copy only copies the top level")

# ============================================================================
# SOLUTION 8: List Comprehension vs Mutation
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 8: Creating New vs Modifying")
print("-" * 70)

def square_inplace(lst):
    """Modify list in-place"""
    for i in range(len(lst)):
        lst[i] = lst[i] ** 2

def square_new(lst):
    """Return new list"""
    return [x**2 for x in lst]

# Performance comparison
n = 100000
test_list = list(range(n))

# Test in-place
start = time.time()
square_inplace(test_list)
time_inplace = time.time() - start

# Test new list
test_list = list(range(n))
start = time.time()
result = square_new(test_list)
time_new = time.time() - start

print(f"In-place modification: {time_inplace:.4f} seconds")
print(f"New list creation: {time_new:.4f} seconds")
print(f"\nIn-place is {time_new/time_inplace:.2f}x faster")

print("\nExplanation:")
print("In-place: Faster, but modifies original")
print("New list: Slower, but safer (no side effects)")
print("Choose based on requirements")

# ============================================================================
# SOLUTION 9: Debug Shared State
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 9: Debug Shared State")
print("-" * 70)

class ShoppingCartFixed:
    def __init__(self, items=None):
        """FIXED: Use None as default"""
        self.items = items if items is not None else []
    
    def add_item(self, item):
        self.items.append(item)

cart1 = ShoppingCartFixed()
cart1.add_item("Apple")
cart2 = ShoppingCartFixed()
cart2.add_item("Banana")

print(f"Cart1: {cart1.items}")
print(f"Cart2: {cart2.items}")
print(f"Independent? {cart1.items is not cart2.items}")

print("\nExplanation:")
print("Problem: Mutable default argument shared across instances")
print("Solution: Use None as default, create list in __init__")

# ============================================================================
# SOLUTION 10: Performance Comparison
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 10: Shallow vs Deep Copy Performance")
print("-" * 70)

# Create large nested structure
matrix = [[i for i in range(100)] for j in range(100)]

# Aliasing (no copy)
start = time.time()
for _ in range(100):
    alias = matrix
alias_time = time.time() - start

# Shallow copy
start = time.time()
for _ in range(100):
    shallow = matrix[:]
shallow_time = time.time() - start

# Deep copy
start = time.time()
for _ in range(100):
    deep = copy.deepcopy(matrix)
deep_time = time.time() - start

print(f"Aliasing:     {alias_time:.6f} seconds")
print(f"Shallow copy: {shallow_time:.6f} seconds")
print(f"Deep copy:    {deep_time:.6f} seconds")
print(f"\nDeep is {deep_time/shallow_time:.1f}x slower than shallow")

print("\nExplanation:")
print("Aliasing: Nearly instant (just reference)")
print("Shallow: Fast (copies outer list only)")
print("Deep: Slow (recursively copies everything)")

print("\n" + "=" * 70)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 70)
