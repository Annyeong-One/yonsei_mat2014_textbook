"""
solutions_03_advanced.py

COMPLETE SOLUTIONS TO ADVANCED EXERCISES
Includes detailed explanations of memory internals
"""

import sys
import gc
import weakref
import tracemalloc
import array
import time

print("=" * 70)
print("ADVANCED EXERCISE SOLUTIONS")
print("=" * 70)

# ============================================================================
# SOLUTION 1: Cyclic Reference Detection
# ============================================================================

print("\nSOLUTION 1: Create and Detect Cyclic References")
print("-" * 70)

class Node:
    def __init__(self, value):
        self.value = value
        self.next = None
    def __repr__(self):
        return f"Node({self.value})"

# Count objects before
before_count = len([obj for obj in gc.get_objects() if isinstance(obj, Node)])
print(f"Node objects before: {before_count}")

# Create cycle
node1 = Node(1)
node2 = Node(2)
node3 = Node(3)
node1.next = node2
node2.next = node3
node3.next = node1  # Cycle!

print("Cycle created: node1 -> node2 -> node3 -> node1")

# Check referrers
print(f"\nnode1 referenced by:")
for ref in gc.get_referrers(node1):
    print(f"  {type(ref).__name__}")

# Delete variables
del node1, node2, node3

# Objects are unreachable but not yet collected
after_del = len([obj for obj in gc.get_objects() if isinstance(obj, Node)])
print(f"\nAfter del: {after_del} Node objects (still in memory)")

# Force collection
collected = gc.collect()
print(f"Garbage collected: {collected} objects")

after_gc = len([obj for obj in gc.get_objects() if isinstance(obj, Node)])
print(f"After gc.collect(): {after_gc} Node objects")

print("\nExplanation: Cyclic references are handled by garbage collector")

# ============================================================================
# SOLUTION 2: Memory Leak Simulation
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 2: Create and Fix a Memory Leak")
print("-" * 70)

# Start profiling
tracemalloc.start()

# Take baseline
snapshot1 = tracemalloc.take_snapshot()

# Create memory leak
class LeakyCache:
    def __init__(self):
        self.cache = {}
    def store(self, key, data):
        self.cache[key] = data  # Never released!

cache = LeakyCache()
for i in range(1000):
    cache.store(i, [0] * 1000)

snapshot2 = tracemalloc.take_snapshot()
stats = snapshot2.compare_to(snapshot1, 'lineno')
current, peak = tracemalloc.get_traced_memory()
print(f"Memory leak: {current / 1024:.1f} KB")

# Fix: Use weak references
del cache

class FixedCache:
    def __init__(self):
        self.cache = weakref.WeakValueDictionary()
    def store(self, key, data):
        self.cache[key] = data

cache = FixedCache()
for i in range(1000):
    temp = [0] * 1000
    cache.store(i, temp)
# Objects can be garbage collected when no strong refs exist

tracemalloc.stop()
print("Fixed with WeakValueDictionary")

# ============================================================================
# SOLUTION 3: __slots__ Optimization
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 3: Memory Optimization with __slots__")
print("-" * 70)

class WithoutSlots:
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

class WithSlots:
    __slots__ = ['x', 'y', 'z']
    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

# Create instances
n = 10000
without = [WithoutSlots(i, i*2, i*3) for i in range(n)]
with_slots = [WithSlots(i, i*2, i*3) for i in range(n)]

# Measure memory
size_without = sum(sys.getsizeof(obj) + sys.getsizeof(obj.__dict__) for obj in without[:100])
size_with = sum(sys.getsizeof(obj) for obj in with_slots[:100])

print(f"Without __slots__ (100 objects): {size_without} bytes")
print(f"With __slots__ (100 objects): {size_with} bytes")
print(f"Savings: {(1 - size_with/size_without) * 100:.1f}%")

print("\nExplanation: __slots__ eliminates __dict__, saves ~40% memory")

# ============================================================================
# SOLUTION 4: Weak Reference Cache
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 4: Implement a Cache with Weak References")
print("-" * 70)

class WeakCache:
    def __init__(self):
        self.cache = weakref.WeakValueDictionary()
    def set(self, key, value):
        self.cache[key] = value
    def get(self, key):
        return self.cache.get(key)
    def size(self):
        return len(self.cache)

cache = WeakCache()
obj1 = [1, 2, 3]
obj2 = [4, 5, 6]

cache.set('key1', obj1)
cache.set('key2', obj2)
print(f"Cache size: {cache.size()}")

# Delete object, cache automatically cleans up
del obj1
gc.collect()
print(f"After deleting obj1: {cache.size()}")
print(f"key1 value: {cache.get('key1')}")

print("\nExplanation: Weak references allow automatic cleanup")

# ============================================================================
# SOLUTION 5: Memory Profiling Context Manager
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 5: Memory Profiling Context Manager")
print("-" * 70)

class MemoryProfiler:
    def __enter__(self):
        tracemalloc.start()
        self.snapshot_before = tracemalloc.take_snapshot()
        return self
    
    def __exit__(self, *args):
        snapshot_after = tracemalloc.take_snapshot()
        stats = snapshot_after.compare_to(self.snapshot_before, 'lineno')
        
        print("\nTop memory allocations:")
        for stat in stats[:3]:
            print(f"  {stat}")
        
        current, peak = tracemalloc.get_traced_memory()
        print(f"\nPeak memory: {peak / 1024:.1f} KB")
        tracemalloc.stop()

# Usage
with MemoryProfiler():
    data = [i**2 for i in range(10000)]

print("Explanation: Context manager ensures cleanup")

# ============================================================================
# SOLUTION 6: Object Lifecycle Tracking
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 6: Track Complete Object Lifecycle")
print("-" * 70)

class LifecycleTracker:
    count = 0
    
    def __new__(cls, name):
        print(f"  __new__: Allocating memory for {name}")
        instance = super().__new__(cls)
        return instance
    
    def __init__(self, name):
        print(f"  __init__: Initializing {name}")
        LifecycleTracker.count += 1
        self.name = name
    
    def __del__(self):
        print(f"  __del__: Destroying {self.name}")
        LifecycleTracker.count -= 1

# Create and destroy
obj1 = LifecycleTracker("Object1")
print(f"  Objects alive: {LifecycleTracker.count}")
del obj1
gc.collect()
print(f"  Objects alive: {LifecycleTracker.count}")

print("\nExplanation: Track __new__, __init__, __del__ for complete lifecycle")

# ============================================================================
# SOLUTION 7: Memory-Efficient Data Structure
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 7: Compare Data Structure Efficiency")
print("-" * 70)

n = 1000000

# List
lst = list(range(n))
list_size = sys.getsizeof(lst) + sum(sys.getsizeof(i) for i in lst[:10]) * (n/10)

# Array
arr = array.array('i', range(n))
array_size = sys.getsizeof(arr)

# Tuple
tpl = tuple(range(n))
tuple_size = sys.getsizeof(tpl) + sum(sys.getsizeof(i) for i in tpl[:10]) * (n/10)

print(f"List (estimated): {list_size/1024/1024:.1f} MB")
print(f"Array: {array_size/1024/1024:.1f} MB")
print(f"Tuple (estimated): {tuple_size/1024/1024:.1f} MB")
print(f"\nArray uses {(1 - array_size/list_size) * 100:.1f}% less memory than list")

print("\nExplanation: array.array stores values directly, not PyObjects")

# ============================================================================
# SOLUTION 8: Generator vs List Memory
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 8: Generator Memory Efficiency")
print("-" * 70)

def squares_list(n):
    return [i**2 for i in range(n)]

def squares_generator(n):
    return (i**2 for i in range(n))

n = 1000000

# List
lst = squares_list(n)
list_memory = sys.getsizeof(lst)

# Generator
gen = squares_generator(n)
gen_memory = sys.getsizeof(gen)

print(f"List: {list_memory/1024/1024:.1f} MB")
print(f"Generator: {gen_memory} bytes")
print(f"\nGenerator uses {list_memory / gen_memory:.0f}x less memory")

print("\nExplanation: Generators compute values on-demand, don't store all")

# ============================================================================
# SOLUTION 9: Reference Count Debugging
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 9: Debug Reference Counting")
print("-" * 70)

obj = [1, 2, 3]
print(f"Initial refcount: {sys.getrefcount(obj)}")

# Container reference
container = [obj]
print(f"After adding to list: {sys.getrefcount(obj)}")

# Dictionary reference
d = {'key': obj}
print(f"After adding to dict: {sys.getrefcount(obj)}")

# Function closure
def closure():
    return obj
print(f"After closure: {sys.getrefcount(obj)}")

# Clean up
del container
print(f"After deleting container: {sys.getrefcount(obj)}")
del d
print(f"After deleting dict: {sys.getrefcount(obj)}")

print("\nExplanation: Track all references to debug memory issues")

# ============================================================================
# SOLUTION 10: Memory Optimization Challenge
# ============================================================================

print("\n" + "=" * 70)
print("SOLUTION 10: Optimize Memory Usage")
print("-" * 70)

# Unoptimized
class Student:
    def __init__(self, name, grades, year):
        self.name = name
        self.grades = grades
        self.year = year

# Optimized with __slots__
class StudentOptimized:
    __slots__ = ['name', 'grades', 'year']
    def __init__(self, name, grades, year):
        self.name = sys.intern(name)  # Intern strings
        self.grades = tuple(grades)   # Tuple instead of list
        self.year = year

# Compare
n = 1000
students1 = [Student(f"Student{i}", [90, 85, 88], 2024) for i in range(n)]
students2 = [StudentOptimized(f"Student{i}", [90, 85, 88], 2024) for i in range(n)]

size1 = sum(sys.getsizeof(s) + sys.getsizeof(s.__dict__) for s in students1)
size2 = sum(sys.getsizeof(s) for s in students2)

print(f"Unoptimized: {size1/1024:.1f} KB")
print(f"Optimized: {size2/1024:.1f} KB")
print(f"Savings: {(1 - size2/size1) * 100:.1f}%")

print("\nOptimizations:")
print("1. __slots__ - eliminates __dict__")
print("2. sys.intern() - shares string objects")
print("3. tuple instead of list - immutable, smaller")

print("\n" + "=" * 70)
print("ALL SOLUTIONS COMPLETE!")
print("=" * 70)
