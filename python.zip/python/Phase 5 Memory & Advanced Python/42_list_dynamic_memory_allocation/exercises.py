"""
exercises.py - Advanced List Implementation Exercises
"""

print("=" * 70)
print("LIST DYNAMIC MEMORY ALLOCATION - EXERCISES")
print("=" * 70)

print("""
SECTION 1: Understanding Internals (10 exercises)

1. What is the difference between list length and capacity?
2. Why does Python over-allocate memory for lists?
3. What is the time complexity of append() WITHOUT over-allocation?
4. What is the time complexity of append() WITH over-allocation?
5. Approximately how much extra capacity does Python allocate?

6. What happens when capacity is exceeded?
7. Why is sys.getsizeof() larger than expected?
8. What does ob_item point to in a list structure?
9. Do lists store objects or pointers to objects?
10. What is "amortized" O(1) time complexity?

SECTION 2: Performance Analysis (10 exercises)

1. Why is lst[i] access O(1)?
2. Why is lst.insert(0, x) slow?
3. Why is lst.pop(0) slow?
4. Compare: append() vs insert(0)
5. Why is lst1 + lst2 slower than lst1.extend(lst2)?

6. Measure time to append 100,000 elements
7. Measure time to insert 1,000 elements at beginning
8. Why are list comprehensions faster than repeated append()?
9. When would pre-allocation help?
10. Why is deque better for queue operations?

SECTION 3: Memory Trade-offs (10 exercises)

1. Calculate wasted memory for list of 100 elements
2. When is memory waste acceptable?
3. Compare memory: list vs array.array
4. When should you use tuples instead?
5. How to minimize memory waste?

6. Why doesn't Python reallocate on every append?
7. What's the growth pattern formula?
8. Compare: [None]*1000 vs 1000 appends
9. Memory impact of many small lists
10. When to use numpy instead of lists?

SECTION 4: Best Practices (10 exercises)

1. Write efficient code to build list of 10,000 squares
2. Fix: lst = []; for x in data: lst.insert(0, x)
3. Pre-allocate list if size known
4. Concatenate 100 lists efficiently
5. Choose: list, deque, or array for each scenario

6. Optimize: repeated lst = lst + [x]
7. Profile memory usage of growing list
8. When to use list comprehension vs append loop?
9. Convert insertion-heavy code to use deque
10. Analyze when over-allocation helps vs hurts

See solutions.py for complete answers!
""")
