"""
solutions.py - Complete Solutions
"""

print("=" * 70)
print("LIST DYNAMIC MEMORY ALLOCATION - SOLUTIONS")
print("=" * 70)

print("""
SECTION 1: Understanding Internals

1. Length: number of elements (len())
   Capacity: total allocated slots (includes unused)

2. Over-allocation: avoid O(n²) cost of reallocating on every append

3. WITHOUT over-allocation: O(n²) total for n appends

4. WITH over-allocation: O(1) amortized per append

5. Approximately 12.5% extra (growth ~1.125x + constant)

SECTION 2: Performance Analysis

1. lst[i] is O(1): direct array access by offset

2. lst.insert(0, x) is O(n): must shift all elements right

3. lst.pop(0) is O(n): must shift all elements left

4. append(): O(1) amortized, insert(0): O(n) always

5. extend() modifies in place, + creates new list

SECTION 3: Best Practice Example

# Efficient: pre-allocate if size known
squares = [i**2 for i in range(10000)]  # Best

# Less efficient: repeated append
squares = []
for i in range(10000):
    squares.append(i**2)  # Still fast due to over-allocation

# Bad: concatenation in loop
squares = []
for i in range(10000):
    squares = squares + [i**2]  # Creates new list each time! O(n²)

# Fix insertion problem
# Bad:
result = []
for x in data:
    result.insert(0, x)  # O(n²)

# Good:
from collections import deque
result = deque()
for x in data:
    result.appendleft(x)  # O(1)
result = list(result)  # Convert once if needed
""")

print("\nAll solutions complete!")
