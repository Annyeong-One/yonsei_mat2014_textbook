# Python Packages Quick Reference

## Regular Package (with __init__.py)

### Structure
```
mypackage/
    __init__.py    ← Makes it a regular package
    module1.py
    module2.py
```

### Characteristics
- ✅ Requires __init__.py
- ✅ Runs initialization code
- ✅ Package-level attributes
- ✅ Package-level functions
- ✅ Can control __all__
- ❌ Cannot span multiple directories

### When to Use
- Need package initialization
- Want package-level interface
- Need to control exports
- Want package metadata
- Need backwards compatibility

---

## Namespace Package (without __init__.py)

### Structure
```
mynamespace/
    (NO __init__.py!)  ← Absence makes it namespace package
    module1.py
    module2.py
```

### Characteristics
- ❌ No __init__.py
- ❌ No initialization code
- ❌ No package-level attributes
- ❌ No package-level functions
- ❌ Cannot control __all__
- ✅ Can span multiple directories

### When to Use
- Simple module collection
- Plugin systems
- Distributed packages
- Modern Python 3.3+ projects
- No initialization needed

---

## Import Syntax Comparison

### Absolute Imports (Recommended)
```python
from mypackage import module
from mypackage.module import function
import mypackage.module
```

### Relative Imports (Within Packages)
```python
from . import module          # Current package
from .. import module         # Parent package
from ..sibling import module  # Sibling package
```

---

## Common Patterns

### Regular Package __init__.py Template
```python
"""Package description."""

__version__ = "1.0.0"
__author__ = "Your Name"

# Import key items for convenient access
from .module1 import Class1
from .module2 import function2

# Define public API
__all__ = ['Class1', 'function2']
```

### Accessing Packages
```python
# Regular package
import mypackage
mypackage.function()  # If defined in __init__.py
mypackage.__version__  # Access metadata

# Namespace package
from mynamespace import module
module.function()  # Must go through module
# mynamespace.__version__  # ERROR: No package-level attributes
```

---

## Decision Tree

```
Do you need package initialization?
├─ Yes → Use Regular Package
└─ No
   ├─ Need package-level attributes?
   │  ├─ Yes → Use Regular Package
   │  └─ No
   │     ├─ Want plugin system?
   │     │  ├─ Yes → Use Namespace Package
   │     │  └─ No → Either works (prefer namespace for simplicity)
   └─ Simple module collection?
      └─ Yes → Use Namespace Package
```

---

## Common Pitfalls

### For Regular Packages
- ❌ Forgetting __init__.py in subdirectories
- ❌ Circular imports between modules
- ❌ Heavy initialization slowing imports
- ❌ Too much logic in __init__.py

### For Namespace Packages
- ❌ Trying to access package-level attributes
- ❌ Expecting initialization code to run
- ❌ Not understanding split package behavior
- ❌ Confusing with regular packages

---

## Testing Checklist

### Regular Package
- [ ] __init__.py exists in all package directories
- [ ] Import works: `import mypackage`
- [ ] Can access package attributes: `mypackage.__version__`
- [ ] Submodules accessible: `from mypackage import module`

### Namespace Package
- [ ] No __init__.py files
- [ ] Import works: `import mynamespace`
- [ ] Modules accessible: `from mynamespace import module`
- [ ] Cannot access package attributes (expected)

---

## Performance Considerations

### Regular Packages
- Initialization code runs once on first import
- Can add startup overhead if complex
- Cached in sys.modules after first import

### Namespace Packages
- No initialization overhead
- Faster import for simple cases
- Still cached in sys.modules

---

## Best Practices

1. **Choose the right type**: Regular for control, namespace for simplicity
2. **Use absolute imports**: Clearer and more maintainable
3. **Keep __init__.py simple**: Fast execution, minimal logic
4. **Document your choice**: Help future developers understand
5. **Follow PEP 8**: Import order and style guidelines
6. **Avoid circular imports**: Design better module structure
7. **Use __all__**: Control public API (regular packages only)
8. **Version your packages**: Use semantic versioning

---

## Resources

- PEP 420: Implicit Namespace Packages
- PEP 8: Style Guide for Python Code
- Python Documentation: Modules and Packages
- This tutorial: Complete examples and exercises
