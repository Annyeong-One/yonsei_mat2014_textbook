# Python Packages Tutorial: Regular vs Namespace Packages

## Overview
This comprehensive tutorial covers two fundamental types of Python packages:
1. **Regular Packages** - Traditional packages with `__init__.py` files
2. **Namespace Packages** - Modern packages without `__init__.py` files (PEP 420)

## Course Structure

### 1. Basics (basics/)
- `01_simple_regular_package/` - Basic regular package structure
- `02_simple_namespace_package/` - Basic namespace package structure
- `03_import_mechanisms.py` - How Python imports packages
- `04_package_initialization.py` - Package initialization behaviors

### 2. Intermediate (intermediate/)
- `05_nested_packages/` - Multi-level package hierarchies
- `06_relative_imports/` - Relative vs absolute imports
- `07_package_data/` - Including non-Python files
- `08_namespace_splitting/` - Splitting namespace packages across directories
- `09_mixing_styles.py` - When regular and namespace packages coexist

### 3. Advanced (advanced/)
- `10_dynamic_imports/` - Runtime package discovery
- `11_package_paths/` - Understanding sys.path and package search
- `12_circular_imports.py` - Handling circular dependencies
- `13_lazy_loading/` - Lazy module loading techniques
- `14_package_metadata/` - Version info and package attributes

### 4. Exercises (exercises/)
- Practice problems with solutions
- Real-world scenarios
- Debugging challenges

## Key Differences: Regular vs Namespace Packages

### Regular Packages (with `__init__.py`)
- **Pros:**
  - Explicit initialization code
  - Can define `__all__` for controlled exports
  - Package-level attributes and functions
  - Compatible with older Python versions
  
- **Cons:**
  - Requires `__init__.py` in every package directory
  - Cannot be split across multiple locations easily

### Namespace Packages (without `__init__.py`)
- **Pros:**
  - No `__init__.py` needed
  - Can span multiple directories/installations
  - Automatic package discovery
  - Modern Python 3.3+ feature (PEP 420)
  
- **Cons:**
  - No initialization code
  - No package-level attributes
  - May be confusing for beginners

## Prerequisites
- Python 3.8 or higher
- Basic understanding of Python modules
- Familiarity with Python's import system

## How to Use This Tutorial

1. Start with the `basics/` directory
2. Read the code comments carefully
3. Run each example to see the behavior
4. Complete exercises in the `exercises/` directory
5. Progress through intermediate and advanced topics

## Running Examples

Each example includes a test script or can be run directly:

```bash
# From the tutorial root directory
python -m basics.03_import_mechanisms

# Or navigate to specific examples
cd basics/01_simple_regular_package
python test_regular_package.py
```

## Learning Objectives

By the end of this tutorial, students will be able to:
- Understand the structure and purpose of Python packages
- Create both regular and namespace packages
- Know when to use each package type
- Handle complex import scenarios
- Debug common package-related issues
- Apply best practices in package organization

## Additional Resources
- PEP 420: Implicit Namespace Packages
- Python Documentation: Modules and Packages
- Python Import System Documentation

## Author Notes
This tutorial is designed for undergraduate computer science students learning Python. Each file contains extensive inline comments explaining not just "what" but "why" - helping students develop deep understanding of Python's package system.
