"""
01_basic_exceptions.py
======================
Introduction to Python Exception Handling

Topics Covered:
- What are exceptions?
- Basic try/except syntax
- Why exception handling is important
- Common built-in exceptions

Learning Objectives:
- Understand what exceptions are and when they occur
- Write basic try/except blocks
- Prevent program crashes from errors
- Distinguish between syntax errors and runtime errors
"""

# ============================================================================
# PART 1: Understanding Exceptions
# ============================================================================
# An exception is an error that occurs during program execution.
# Without proper handling, exceptions cause the program to crash.

print("=" * 60)
print("PART 1: What Happens Without Exception Handling")
print("=" * 60)

# Example 1: Division by zero (uncomment to see the crash)
# This would crash the program without exception handling
# result = 10 / 0  # ZeroDivisionError

# Example 2: Type errors
# Converting incompatible types causes exceptions
# number = int("hello")  # ValueError

# Example 3: Index errors
# Accessing an invalid index causes an exception
# my_list = [1, 2, 3]
# print(my_list[10])  # IndexError

print("Program continues without running the commented error code...")
print()

# ============================================================================
# PART 2: Basic Try/Except Structure
# ============================================================================
# The try/except block allows us to handle exceptions gracefully
# Syntax:
#   try:
#       # Code that might raise an exception
#   except ExceptionType:
#       # Code to handle the exception

print("=" * 60)
print("PART 2: Basic Try/Except Usage")
print("=" * 60)

# Example 1: Handling division by zero
print("\nExample 1: Safe Division")
print("-" * 40)

try:
    # This code might raise an exception
    numerator = 10
    denominator = 0
    result = numerator / denominator
    print(f"Result: {result}")  # This line won't execute
except ZeroDivisionError:
    # This code runs if ZeroDivisionError occurs
    print("Error: Cannot divide by zero!")
    print("Program continues safely instead of crashing")

print()

# Example 2: Handling invalid input conversion
print("\nExample 2: Safe Type Conversion")
print("-" * 40)

user_input = "not_a_number"
try:
    # Attempting to convert a string to integer
    number = int(user_input)
    print(f"Successfully converted: {number}")
except ValueError:
    # Handles the case where conversion fails
    print(f"Error: '{user_input}' cannot be converted to an integer")
    print("Using default value instead")
    number = 0  # Assign a default value

print(f"Number value: {number}")
print()

# ============================================================================
# PART 3: Generic Exception Handling
# ============================================================================
# You can catch any exception using the base Exception class
# However, this is generally not recommended for production code
# It's better to catch specific exceptions when possible

print("=" * 60)
print("PART 3: Generic Exception Handling")
print("=" * 60)

# Example: Catching any exception
print("\nExample: Catching All Exceptions")
print("-" * 40)

operations = [
    ("10 / 2", lambda: 10 / 2),
    ("10 / 0", lambda: 10 / 0),
    ("int('abc')", lambda: int('abc')),
    ("[1,2,3][5]", lambda: [1, 2, 3][5])
]

for description, operation in operations:
    try:
        result = operation()
        print(f"✓ {description} = {result}")
    except Exception as e:
        # 'as e' captures the exception object for inspection
        print(f"✗ {description} raised {type(e).__name__}: {e}")

print()

# ============================================================================
# PART 4: Multiple Operations in Try Block
# ============================================================================
# A try block can contain multiple statements
# If any statement raises an exception, remaining statements are skipped

print("=" * 60)
print("PART 4: Multiple Operations in Try Block")
print("=" * 60)

print("\nExample: Sequential Operations")
print("-" * 40)

try:
    print("Step 1: Creating a list")
    my_list = [1, 2, 3, 4, 5]
    
    print("Step 2: Accessing valid index")
    print(f"Element at index 2: {my_list[2]}")
    
    print("Step 3: Attempting to access invalid index")
    print(f"Element at index 10: {my_list[10]}")  # This will raise IndexError
    
    print("Step 4: This line will never execute")
    # Because the exception occurs at step 3
    
except IndexError:
    print("Error: Tried to access an index that doesn't exist")
    print("Steps 1-2 completed, but step 3 failed")

print()

# ============================================================================
# PART 5: Practical Example - User Input Validation
# ============================================================================
# Real-world scenario: Getting and validating user input

print("=" * 60)
print("PART 5: Practical Example - Input Validation")
print("=" * 60)

def get_valid_age(age_string):
    """
    Converts a string to a valid age (integer).
    
    Parameters:
        age_string (str): The age as a string
    
    Returns:
        int: The age as an integer, or None if invalid
    """
    try:
        age = int(age_string)
        
        # Age must be positive
        if age < 0:
            print(f"Invalid: Age cannot be negative ({age})")
            return None
        
        # Age must be reasonable
        if age > 150:
            print(f"Invalid: Age seems unrealistic ({age})")
            return None
        
        return age
    
    except ValueError:
        # Handles non-numeric input
        print(f"Invalid: '{age_string}' is not a valid number")
        return None

# Test the function with various inputs
print("\nTesting age validation:")
print("-" * 40)

test_ages = ["25", "-5", "150", "200", "abc", "30.5"]

for test_input in test_ages:
    result = get_valid_age(test_input)
    if result is not None:
        print(f"✓ '{test_input}' -> Valid age: {result}")
    else:
        print(f"✗ '{test_input}' -> Invalid (returned None)")

print()

# ============================================================================
# PART 6: Common Built-in Exceptions
# ============================================================================
# Python has many built-in exception types for different error situations

print("=" * 60)
print("PART 6: Common Built-in Exceptions")
print("=" * 60)

print("\nDemonstrating common exceptions:")
print("-" * 40)

# Dictionary of exception examples
exception_examples = {
    "ZeroDivisionError": lambda: 1 / 0,
    "ValueError": lambda: int("not_a_number"),
    "TypeError": lambda: "string" + 5,
    "IndexError": lambda: [1, 2, 3][10],
    "KeyError": lambda: {"a": 1}["b"],
    "AttributeError": lambda: "string".nonexistent_method(),
    "NameError": lambda: undefined_variable,
    "FileNotFoundError": lambda: open("nonexistent_file.txt")
}

for exc_name, operation in exception_examples.items():
    try:
        operation()
    except Exception as e:
        print(f"{exc_name:20s}: {str(e)}")

print()

# ============================================================================
# SUMMARY AND KEY TAKEAWAYS
# ============================================================================
print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
1. Exceptions are runtime errors that can crash your program
2. Use try/except blocks to handle exceptions gracefully
3. The try block contains code that might raise exceptions
4. The except block contains code to handle specific exceptions
5. Use 'except Exception as e' to capture the exception object
6. It's better to catch specific exceptions rather than generic ones
7. Only the first exception in a try block is caught
8. Exception handling prevents program crashes and improves user experience

BEST PRACTICES:
- Always handle expected exceptions explicitly
- Provide meaningful error messages to users
- Use exception handling for exceptional cases, not control flow
- Log exceptions for debugging purposes
- Don't suppress exceptions silently without good reason
""")

print("\n" + "=" * 60)
print("End of Module 01: Basic Exceptions")
print("=" * 60)
