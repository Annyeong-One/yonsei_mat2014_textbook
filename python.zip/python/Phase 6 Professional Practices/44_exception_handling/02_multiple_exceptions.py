"""
02_multiple_exceptions.py
==========================
Handling Multiple Exception Types

Topics Covered:
- Catching multiple specific exceptions
- Multiple except blocks
- Tuple of exceptions in a single except
- Order of exception handlers
- Getting exception details

Learning Objectives:
- Handle different exception types appropriately
- Understand exception handler order matters
- Access exception information for debugging
- Write more robust error handling code
"""

# ============================================================================
# PART 1: Multiple Except Blocks
# ============================================================================
# You can have multiple except blocks to handle different exception types
# Each exception type can be handled differently

print("=" * 60)
print("PART 1: Multiple Except Blocks")
print("=" * 60)

def safe_divide(a, b):
    """
    Performs division with comprehensive error handling.
    
    Parameters:
        a: numerator (should be numeric)
        b: denominator (should be numeric)
    
    Returns:
        float: result of division, or None if error occurs
    """
    try:
        # Attempt the division
        result = a / b
        return result
    
    except ZeroDivisionError:
        # Handles division by zero specifically
        print(f"Error: Cannot divide {a} by zero")
        return None
    
    except TypeError:
        # Handles cases where a or b are not numbers
        print(f"Error: Cannot divide {type(a).__name__} by {type(b).__name__}")
        print("Both arguments must be numeric types")
        return None

# Test the function with different inputs
print("\nTesting safe_divide function:")
print("-" * 40)

test_cases = [
    (10, 2),      # Normal case
    (10, 0),      # ZeroDivisionError
    ("10", 2),    # TypeError (string / int)
    (10, "2"),    # TypeError (int / string)
    ([1, 2], 3),  # TypeError (list / int)
]

for a, b in test_cases:
    print(f"\nsafe_divide({repr(a)}, {repr(b)}):")
    result = safe_divide(a, b)
    if result is not None:
        print(f"  → Result: {result}")
    else:
        print(f"  → Returned None due to error")

print()

# ============================================================================
# PART 2: Catching Multiple Exceptions in One Block
# ============================================================================
# You can catch multiple exception types in a single except block
# Use a tuple of exception types: except (Type1, Type2, Type3)

print("=" * 60)
print("PART 2: Catching Multiple Exceptions Together")
print("=" * 60)

def process_user_input(data):
    """
    Processes various types of user input data.
    
    Parameters:
        data: Input data of various types
    
    Returns:
        Processed value or None if error
    """
    try:
        # Try to convert to integer
        number = int(data)
        
        # Try to perform calculation
        result = 100 / number
        
        # Try to access as if it's a list
        # (This is intentionally problematic for demonstration)
        first_char = data[0]
        
        return result
    
    except (ValueError, TypeError):
        # These two exceptions are handled the same way
        print(f"Error: '{data}' is not valid numeric input")
        return None
    
    except ZeroDivisionError:
        # This exception gets special handling
        print(f"Error: Input cannot be zero for this operation")
        return None

print("\nTesting process_user_input function:")
print("-" * 40)

test_inputs = ["50", "0", "abc", None, 25]

for inp in test_inputs:
    print(f"\nProcessing: {repr(inp)}")
    result = process_user_input(inp)
    if result is not None:
        print(f"  → Success: {result}")

print()

# ============================================================================
# PART 3: Order of Exception Handlers Matters
# ============================================================================
# Exception handlers are checked from top to bottom
# More specific exceptions should come before more general ones

print("=" * 60)
print("PART 3: Exception Handler Order")
print("=" * 60)

print("\nExample 1: INCORRECT ORDER (too general first)")
print("-" * 40)

def bad_exception_order(value):
    """
    Demonstrates incorrect exception handling order.
    The general Exception catches everything, making specific handlers unreachable.
    """
    try:
        result = 10 / int(value)
        return result
    except Exception:
        # This is TOO GENERAL - it catches everything!
        print("Some error occurred (but we don't know what!)")
        return None
    except ZeroDivisionError:
        # WARNING: This block will NEVER execute!
        # Because Exception (above) catches ZeroDivisionError too
        print("This message will never appear!")
        return None
    except ValueError:
        # WARNING: This block will also NEVER execute!
        print("This message will also never appear!")
        return None

# Test to show the problem
print("Testing bad_exception_order:")
bad_exception_order("0")     # Should catch ZeroDivisionError, but doesn't
bad_exception_order("abc")   # Should catch ValueError, but doesn't

print("\nExample 2: CORRECT ORDER (specific first)")
print("-" * 40)

def good_exception_order(value):
    """
    Demonstrates correct exception handling order.
    Specific exceptions are caught first, general exception last.
    """
    try:
        result = 10 / int(value)
        return result
    
    except ZeroDivisionError:
        # Specific exception: handles division by zero
        print("Error: Cannot divide by zero")
        return None
    
    except ValueError:
        # Specific exception: handles invalid conversion
        print(f"Error: '{value}' is not a valid number")
        return None
    
    except Exception as e:
        # General exception: catches anything else unexpected
        print(f"Unexpected error: {type(e).__name__}: {e}")
        return None

# Test to show correct behavior
print("Testing good_exception_order:")
result1 = good_exception_order("0")     # Catches ZeroDivisionError
result2 = good_exception_order("abc")   # Catches ValueError
result3 = good_exception_order("5")     # Succeeds

print()

# ============================================================================
# PART 4: Accessing Exception Information
# ============================================================================
# Use "as variable_name" to capture the exception object
# The exception object contains useful information for debugging

print("=" * 60)
print("PART 4: Accessing Exception Details")
print("=" * 60)

def detailed_error_handler(operation_name, operation):
    """
    Executes an operation and provides detailed error information.
    
    Parameters:
        operation_name (str): Description of the operation
        operation (callable): Function to execute
    """
    try:
        result = operation()
        print(f"✓ {operation_name}: Success - Result = {result}")
    
    except ZeroDivisionError as e:
        # Capture the exception object as 'e'
        print(f"✗ {operation_name}: ZeroDivisionError")
        print(f"  Exception type: {type(e).__name__}")
        print(f"  Exception message: {e}")
        print(f"  Exception args: {e.args}")
    
    except ValueError as e:
        print(f"✗ {operation_name}: ValueError")
        print(f"  Exception type: {type(e).__name__}")
        print(f"  Exception message: {e}")
        print(f"  Exception args: {e.args}")
    
    except (TypeError, IndexError, KeyError) as e:
        # Multiple exceptions with same handling
        print(f"✗ {operation_name}: {type(e).__name__}")
        print(f"  Exception message: {e}")

print("\nTesting operations with detailed error reporting:")
print("-" * 40)

# Define test operations
operations = [
    ("Division by zero", lambda: 10 / 0),
    ("Invalid int conversion", lambda: int("not_a_number")),
    ("Type mismatch", lambda: "string" + 5),
    ("Index out of range", lambda: [1, 2, 3][10]),
    ("Missing dictionary key", lambda: {"a": 1}["b"]),
    ("Valid operation", lambda: 10 / 2),
]

for name, op in operations:
    print()
    detailed_error_handler(name, op)

print()

# ============================================================================
# PART 5: Practical Example - Data Processing Pipeline
# ============================================================================
# Real-world scenario: Processing data with multiple potential failure points

print("=" * 60)
print("PART 5: Practical Example - Data Processing")
print("=" * 60)

def process_student_grade(student_data):
    """
    Processes student grade data with comprehensive error handling.
    
    Parameters:
        student_data (dict): Dictionary with 'name' and 'score' keys
    
    Returns:
        dict: Processed result with grade information
    """
    result = {
        "success": False,
        "name": None,
        "score": None,
        "grade": None,
        "error": None
    }
    
    try:
        # Step 1: Extract name (might raise KeyError)
        name = student_data["name"]
        result["name"] = name
        
        # Step 2: Extract score (might raise KeyError)
        score = student_data["score"]
        
        # Step 3: Convert score to number (might raise ValueError, TypeError)
        score = float(score)
        result["score"] = score
        
        # Step 4: Validate score range (might be invalid)
        if score < 0 or score > 100:
            raise ValueError(f"Score {score} is out of valid range (0-100)")
        
        # Step 5: Calculate grade
        if score >= 90:
            grade = "A"
        elif score >= 80:
            grade = "B"
        elif score >= 70:
            grade = "C"
        elif score >= 60:
            grade = "D"
        else:
            grade = "F"
        
        result["grade"] = grade
        result["success"] = True
        return result
    
    except KeyError as e:
        # Missing required field
        result["error"] = f"Missing required field: {e}"
        return result
    
    except ValueError as e:
        # Invalid score value or range
        result["error"] = f"Invalid score value: {e}"
        return result
    
    except TypeError as e:
        # Wrong data type
        result["error"] = f"Type error: {e}"
        return result

# Test with various student data
print("\nProcessing student grades:")
print("-" * 40)

students = [
    {"name": "Alice", "score": "95"},      # Valid
    {"name": "Bob", "score": "78.5"},      # Valid
    {"name": "Charlie", "score": "not_a_number"},  # ValueError
    {"name": "David", "score": 150},       # Out of range
    {"name": "Eve"},                       # Missing score
    {"score": "85"},                       # Missing name
    {"name": "Frank", "score": None},      # None score
]

for student in students:
    print(f"\nInput: {student}")
    result = process_student_grade(student)
    
    if result["success"]:
        print(f"  ✓ {result['name']}: Score={result['score']}, Grade={result['grade']}")
    else:
        print(f"  ✗ Error: {result['error']}")

print()

# ============================================================================
# PART 6: Best Practices Summary
# ============================================================================

print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
1. Use multiple except blocks to handle different exceptions differently
2. Catch multiple similar exceptions together using tuples: except (E1, E2)
3. Order matters: put specific exceptions before general ones
4. Never put "except Exception" before specific exception handlers
5. Use "as variable" to capture exception objects for detailed information
6. Exception objects contain:
   - type: accessible via type(e).__name__
   - message: accessible via str(e)
   - args: accessible via e.args
7. Handle expected exceptions explicitly
8. Provide clear, informative error messages

BEST PRACTICES:
- Catch only the exceptions you can meaningfully handle
- Don't hide errors - handle them appropriately
- Log detailed exception information for debugging
- Provide user-friendly error messages
- Use specific exception types for better code clarity
- Test error handling paths as thoroughly as success paths

COMMON MISTAKES TO AVOID:
- Catching Exception before specific exceptions
- Using bare "except:" without specifying exception type
- Silently ignoring exceptions (empty except blocks)
- Catching exceptions but not handling them properly
""")

print("\n" + "=" * 60)
print("End of Module 02: Multiple Exceptions")
print("=" * 60)
