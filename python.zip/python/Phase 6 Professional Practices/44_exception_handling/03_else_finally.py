"""
03_else_finally.py
==================
The else and finally Clauses in Exception Handling

Topics Covered:
- The else clause: executes when no exception occurs
- The finally clause: always executes for cleanup
- Execution order: try-except-else-finally
- Use cases for else and finally
- Resource cleanup and guaranteed execution

Learning Objectives:
- Understand when to use else vs putting code in try
- Master the finally clause for cleanup operations
- Write more organized exception handling code
- Ensure proper resource management
"""

import time
import sys

# ============================================================================
# PART 1: The else Clause
# ============================================================================
# The else clause executes only if no exception was raised in the try block
# Syntax:
#   try:
#       # risky code
#   except SomeException:
#       # handle exception
#   else:
#       # executes only if try succeeds (no exception)

print("=" * 60)
print("PART 1: Understanding the else Clause")
print("=" * 60)

def divide_with_else(a, b):
    """
    Demonstrates the else clause in exception handling.
    
    Parameters:
        a (float): numerator
        b (float): denominator
    
    Returns:
        float: result of division or None
    """
    try:
        result = a / b
        print(f"  Try block: Division {a}/{b} executed successfully")
    
    except ZeroDivisionError:
        print(f"  Except block: Cannot divide {a} by zero")
        return None
    
    else:
        # This executes only if no exception occurred
        print(f"  Else block: No exception occurred, processing result")
        # Additional processing after successful operation
        result = round(result, 2)
        return result
    
    # Note: If we return in else, code here won't execute
    print(f"  After try-except-else: This won't execute due to return")

print("\nExample 1: Division with else clause")
print("-" * 40)

print("\nCase 1: Successful division")
result1 = divide_with_else(10, 3)
print(f"Final result: {result1}\n")

print("Case 2: Division by zero")
result2 = divide_with_else(10, 0)
print(f"Final result: {result2}\n")

# ============================================================================
# PART 2: Why Use else Instead of Putting Code in try?
# ============================================================================
# Key principle: Only code that might raise exceptions should go in try block
# Code that should run after success goes in else

print("=" * 60)
print("PART 2: try Block vs else Block")
print("=" * 60)

print("\nExample 2a: BAD - Too much code in try block")
print("-" * 40)

def bad_approach(filename):
    """
    Demonstrates problematic approach: too much in try block.
    """
    try:
        # Only this line needs exception handling
        file = open(filename, 'r')
        
        # These operations don't need to be in try!
        # If they fail, we want to know about it separately
        content = file.read()
        lines = content.split('\n')
        word_count = sum(len(line.split()) for line in lines)
        file.close()
        
        return word_count
    except FileNotFoundError:
        print(f"File {filename} not found")
        return 0

print("This approach is problematic because:")
print("- All processing is in try block")
print("- Any error in processing is caught as if it's a file error")
print("- Harder to debug which operation failed")

print("\nExample 2b: GOOD - Minimal try, processing in else")
print("-" * 40)

def good_approach(filename):
    """
    Demonstrates better approach: minimal try, processing in else.
    """
    try:
        # Only the risky operation in try
        file = open(filename, 'r')
    except FileNotFoundError:
        print(f"File {filename} not found")
        return 0
    else:
        # Process after successful file open
        # If these fail, we'll see the real error
        content = file.read()
        lines = content.split('\n')
        word_count = sum(len(line.split()) for line in lines)
        file.close()
        return word_count

print("This approach is better because:")
print("- Only file opening (risky part) is in try")
print("- Processing code in else shows it depends on try success")
print("- Processing errors are not confused with file errors")
print("- Code structure is clearer and more maintainable")

print()

# ============================================================================
# PART 3: The finally Clause
# ============================================================================
# The finally clause ALWAYS executes, whether exception occurred or not
# Perfect for cleanup operations: closing files, releasing resources, etc.

print("=" * 60)
print("PART 3: Understanding the finally Clause")
print("=" * 60)

def demonstrate_finally(should_fail):
    """
    Demonstrates that finally always executes.
    
    Parameters:
        should_fail (bool): Whether to trigger an exception
    """
    print(f"\n  Testing with should_fail={should_fail}")
    
    try:
        print("  → Try block: Starting operation")
        if should_fail:
            raise ValueError("Intentional error for demonstration")
        print("  → Try block: Operation completed successfully")
        return "Success"
    
    except ValueError as e:
        print(f"  → Except block: Caught exception: {e}")
        return "Failed"
    
    else:
        print("  → Else block: No exception occurred")
    
    finally:
        # This ALWAYS executes, no matter what
        print("  → Finally block: Cleanup operations (ALWAYS runs)")

print("\nExample 3: finally executes in all cases")
print("-" * 40)

result1 = demonstrate_finally(False)  # Success case
print(f"Returned: {result1}")

result2 = demonstrate_finally(True)   # Exception case
print(f"Returned: {result2}")

print()

# ============================================================================
# PART 4: Execution Order
# ============================================================================
# Understanding the order: try → except/else → finally

print("=" * 60)
print("PART 4: Complete Execution Flow")
print("=" * 60)

def show_execution_order(scenario):
    """
    Demonstrates the complete execution order of all clauses.
    
    Parameters:
        scenario (str): 'success', 'exception', or 'return_early'
    """
    print(f"\nScenario: {scenario}")
    print("-" * 40)
    
    try:
        print("1. Try block executed")
        if scenario == 'exception':
            raise ValueError("Test exception")
        elif scenario == 'return_early':
            print("2. Returning early from try block")
            return "Early return"
        # If scenario == 'success', just continue
    
    except ValueError as e:
        print(f"2. Except block executed: {e}")
        if scenario == 'return_early':
            return "Return from except"
    
    else:
        print("2. Else block executed (no exception)")
        if scenario == 'return_early':
            return "Return from else"
    
    finally:
        # This ALWAYS runs, even if we returned early!
        print("3. Finally block executed (cleanup)")
    
    print("4. After all blocks (only if no return statements)")
    return "Normal completion"

print("\nTesting different execution scenarios:")

# Scenario 1: Everything succeeds
result = show_execution_order('success')
print(f"Result: {result}\n")

# Scenario 2: Exception occurs
result = show_execution_order('exception')
print(f"Result: {result}\n")

print()

# ============================================================================
# PART 5: Practical Example - File Operations
# ============================================================================
# Real-world use case: Ensuring file is closed even if error occurs

print("=" * 60)
print("PART 5: Practical File Handling")
print("=" * 60)

def process_file_without_finally(filename):
    """
    File processing WITHOUT finally - not recommended.
    File might not be closed if exception occurs.
    """
    print(f"\nProcessing {filename} WITHOUT finally:")
    try:
        file = open(filename, 'r')
        content = file.read()
        # What if an error occurs here before close()?
        # The file would remain open!
        file.close()
        return len(content)
    except FileNotFoundError:
        print(f"  Error: File {filename} not found")
        # File was never opened, so no close needed
        return 0
    except Exception as e:
        print(f"  Error during processing: {e}")
        # File might still be open here!
        return 0

def process_file_with_finally(filename):
    """
    File processing WITH finally - recommended approach.
    File is guaranteed to be closed.
    """
    print(f"\nProcessing {filename} WITH finally:")
    file = None  # Initialize to None
    try:
        file = open(filename, 'r')
        content = file.read()
        # Even if error occurs here, file will be closed in finally
        return len(content)
    
    except FileNotFoundError:
        print(f"  Error: File {filename} not found")
        return 0
    
    except Exception as e:
        print(f"  Error during processing: {e}")
        return 0
    
    finally:
        # Ensure file is closed if it was opened
        if file is not None:
            file.close()
            print(f"  File closed in finally block")

# Create a test file
test_filename = "/tmp/test_file.txt"
try:
    with open(test_filename, 'w') as f:
        f.write("This is a test file for demonstrating exception handling.\n")
        f.write("It contains multiple lines.\n")
        f.write("We'll use it to show proper file handling.\n")
    print("Test file created successfully")
except:
    print("Could not create test file")

# Test both approaches
result1 = process_file_with_finally(test_filename)
print(f"  Characters read: {result1}")

result2 = process_file_with_finally("nonexistent.txt")
print(f"  Characters read: {result2}")

print()

# ============================================================================
# PART 6: Complex Example - Database Connection Simulation
# ============================================================================
# Simulating database operations with proper cleanup

print("=" * 60)
print("PART 6: Resource Management Simulation")
print("=" * 60)

class DatabaseConnection:
    """
    Simulates a database connection for demonstration.
    """
    def __init__(self, database_name):
        self.database_name = database_name
        self.is_connected = False
    
    def connect(self):
        """Simulate connection establishment."""
        print(f"    → Connecting to {self.database_name}...")
        self.is_connected = True
        print(f"    → Connected successfully")
    
    def execute_query(self, query):
        """Simulate query execution."""
        if not self.is_connected:
            raise RuntimeError("Not connected to database")
        print(f"    → Executing: {query}")
        
        # Simulate query errors
        if "INVALID" in query:
            raise ValueError("Invalid SQL syntax")
        
        return f"Query result for: {query}"
    
    def close(self):
        """Simulate connection closure."""
        if self.is_connected:
            print(f"    → Closing connection to {self.database_name}")
            self.is_connected = False
        else:
            print(f"    → Connection already closed")

def perform_database_operation(db_name, query):
    """
    Performs database operation with proper cleanup.
    
    Parameters:
        db_name (str): Name of database
        query (str): SQL query to execute
    
    Returns:
        str: Query result or error message
    """
    print(f"\nDatabase operation on '{db_name}':")
    
    db = None  # Initialize connection variable
    
    try:
        # Establish connection
        db = DatabaseConnection(db_name)
        db.connect()
    
    except Exception as e:
        print(f"    ✗ Connection failed: {e}")
        return None
    
    else:
        # Connection successful, now execute query
        try:
            result = db.execute_query(query)
            print(f"    ✓ Query successful")
            return result
        
        except ValueError as e:
            print(f"    ✗ Query error: {e}")
            return None
        
        except Exception as e:
            print(f"    ✗ Unexpected error: {e}")
            return None
    
    finally:
        # ALWAYS close connection if it was opened
        if db is not None:
            db.close()
        print(f"    Cleanup completed")

# Test various scenarios
print("\nTesting database operations:")
print("-" * 40)

# Test 1: Successful operation
result = perform_database_operation("mydb", "SELECT * FROM users")
print(f"Result: {result}")

# Test 2: Invalid query
result = perform_database_operation("mydb", "INVALID SQL")
print(f"Result: {result}")

print()

# ============================================================================
# PART 7: Best Practices Summary
# ============================================================================

print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
THE ELSE CLAUSE:
1. Executes only if no exception occurred in try block
2. Use it for code that depends on try block success
3. Keeps try block minimal (only code that might raise exceptions)
4. Makes code structure clearer and more maintainable
5. Better than putting everything in try block

THE FINALLY CLAUSE:
1. ALWAYS executes, regardless of exceptions or returns
2. Perfect for cleanup: closing files, releasing resources, logging
3. Executes even if try/except contains return statements
4. Guarantees cleanup operations happen
5. Essential for proper resource management

EXECUTION ORDER:
- try → (if exception) except → finally
- try → (if no exception) else → finally
- finally runs even with return statements in try/except/else

BEST PRACTICES:
- Use else to separate success handling from exception handling
- Use finally for guaranteed cleanup operations
- Keep try blocks minimal (only risky operations)
- Always clean up resources (files, connections, locks)
- Initialize resources before try block when using finally
- Check if resource is not None before cleanup in finally

COMMON PATTERNS:
1. File operations: Open in try, process in else, close in finally
2. Database operations: Connect in try, query in else, close in finally
3. Lock acquisition: Acquire in try, use in else, release in finally
4. Resource allocation: Allocate in try, use in else, free in finally

NOTE: Python's 'with' statement (context managers) provides a cleaner
way to handle resources - we'll cover that in module 09.
""")

print("\n" + "=" * 60)
print("End of Module 03: else and finally Clauses")
print("=" * 60)
