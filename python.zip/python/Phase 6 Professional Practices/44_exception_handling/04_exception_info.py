"""
04_exception_info.py
====================
Accessing and Using Exception Information

Topics Covered:
- Exception object attributes (__class__, args, __str__)
- The traceback object
- sys.exc_info() function
- Exception context and cause
- Formatting exception information

Learning Objectives:
- Extract detailed exception information
- Use exception data for logging and debugging
- Understand exception attributes
- Access stack traces programmatically
"""

import sys
import traceback

# ============================================================================
# PART 1: Basic Exception Attributes
# ============================================================================
# Every exception object has useful attributes for debugging

print("=" * 60)
print("PART 1: Basic Exception Attributes")
print("=" * 60)

def examine_exception_attributes():
    """
    Demonstrates accessing basic exception attributes.
    """
    try:
        # Create an exception situation
        result = 10 / 0
    except ZeroDivisionError as e:
        print("\nException caught! Let's examine its attributes:")
        print("-" * 40)
        
        # Attribute 1: __class__ - the exception type
        print(f"Type: {e.__class__}")
        print(f"Type name: {e.__class__.__name__}")
        
        # Attribute 2: args - tuple of arguments passed to exception
        print(f"Arguments: {e.args}")
        
        # Attribute 3: __str__() - string representation
        print(f"String representation: {str(e)}")
        
        # Attribute 4: repr() - official string representation
        print(f"Repr: {repr(e)}")
        
        # Check exception type programmatically
        if isinstance(e, ZeroDivisionError):
            print("\nConfirmed: This is a ZeroDivisionError")
        
        # Check if it's an instance of parent class
        if isinstance(e, ArithmeticError):
            print("Also: ZeroDivisionError is an ArithmeticError")
        
        if isinstance(e, Exception):
            print("Also: All exceptions inherit from Exception")

examine_exception_attributes()
print()

# ============================================================================
# PART 2: Custom Exception Messages
# ============================================================================
# Exceptions can have custom messages with detailed information

print("=" * 60)
print("PART 2: Exception Messages and Arguments")
print("=" * 60)

def validate_age(age):
    """
    Validates age and raises exception with detailed message.
    
    Parameters:
        age (int): Age to validate
    
    Raises:
        ValueError: If age is invalid
    """
    if age < 0:
        # Raise exception with custom message
        raise ValueError(f"Age cannot be negative. Received: {age}")
    
    if age > 150:
        # Exception with multiple arguments
        raise ValueError("Age exceeds maximum", age, 150)
    
    return True

print("\nTesting age validation with custom messages:")
print("-" * 40)

test_ages = [25, -5, 200]

for age in test_ages:
    try:
        validate_age(age)
        print(f"✓ Age {age} is valid")
    except ValueError as e:
        print(f"\n✗ Invalid age {age}:")
        print(f"  Exception message: {str(e)}")
        print(f"  Exception args: {e.args}")
        print(f"  Number of args: {len(e.args)}")
        
        # Access individual arguments if multiple
        if len(e.args) > 1:
            print(f"  Detailed args:")
            for i, arg in enumerate(e.args):
                print(f"    args[{i}]: {arg}")

print()

# ============================================================================
# PART 3: sys.exc_info() for Current Exception
# ============================================================================
# sys.exc_info() returns (type, value, traceback) of current exception

print("=" * 60)
print("PART 3: Using sys.exc_info()")
print("=" * 60)

def demonstrate_exc_info():
    """
    Shows how to use sys.exc_info() to get exception details.
    """
    try:
        # Create an exception
        numbers = [1, 2, 3]
        print(numbers[10])  # IndexError
    except:
        # Get current exception information
        exc_type, exc_value, exc_traceback = sys.exc_info()
        
        print("\nException information from sys.exc_info():")
        print("-" * 40)
        print(f"Exception type: {exc_type}")
        print(f"Exception type name: {exc_type.__name__}")
        print(f"Exception value: {exc_value}")
        print(f"Exception traceback: {exc_traceback}")
        
        # Traceback information
        print(f"\nTraceback details:")
        print(f"  Filename: {exc_traceback.tb_frame.f_code.co_filename}")
        print(f"  Function: {exc_traceback.tb_frame.f_code.co_name}")
        print(f"  Line number: {exc_traceback.tb_lineno}")

demonstrate_exc_info()
print()

# ============================================================================
# PART 4: Traceback Module
# ============================================================================
# The traceback module provides utilities for working with tracebacks

print("=" * 60)
print("PART 4: Working with Tracebacks")
print("=" * 60)

def function_a():
    """Top-level function in call stack."""
    function_b()

def function_b():
    """Mid-level function in call stack."""
    function_c()

def function_c():
    """Function that raises an exception."""
    # This will raise an exception
    result = "string" + 5

def demonstrate_traceback():
    """
    Demonstrates traceback formatting and extraction.
    """
    try:
        function_a()  # Start call chain
    except TypeError as e:
        print("\nCaught TypeError in nested function calls")
        print("-" * 40)
        
        # Get traceback information
        exc_type, exc_value, exc_traceback = sys.exc_info()
        
        # Format the full traceback
        print("\n1. Full traceback:")
        tb_lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        print(''.join(tb_lines))
        
        # Format just the exception
        print("\n2. Exception only:")
        exc_lines = traceback.format_exception_only(exc_type, exc_value)
        print(''.join(exc_lines))
        
        # Extract traceback information
        print("\n3. Traceback frames:")
        tb_list = traceback.extract_tb(exc_traceback)
        for frame in tb_list:
            print(f"  File: {frame.filename}")
            print(f"  Function: {frame.name}")
            print(f"  Line: {frame.lineno}")
            print(f"  Code: {frame.line}")
            print()

demonstrate_traceback()

# ============================================================================
# PART 5: Exception Context and Cause
# ============================================================================
# Exceptions have __context__ and __cause__ attributes for chaining

print("=" * 60)
print("PART 5: Exception Context and Cause")
print("=" * 60)

def demonstrate_exception_context():
    """
    Demonstrates implicit exception context (__context__).
    """
    print("\nExample 1: Implicit context")
    print("-" * 40)
    
    try:
        try:
            # First exception
            result = 10 / 0
        except ZeroDivisionError:
            # While handling first exception, raise another
            result = int("not_a_number")
    except ValueError as e:
        print("Caught ValueError")
        print(f"Current exception: {e}")
        print(f"Exception has context: {e.__context__ is not None}")
        
        if e.__context__:
            print(f"Context exception: {e.__context__}")
            print(f"Context type: {type(e.__context__).__name__}")

def demonstrate_exception_cause():
    """
    Demonstrates explicit exception cause (__cause__).
    """
    print("\n\nExample 2: Explicit cause")
    print("-" * 40)
    
    try:
        try:
            # Original exception
            data = {"key": "value"}
            missing = data["nonexistent"]
        except KeyError as ke:
            # Explicitly chain exceptions
            raise ValueError("Failed to process data") from ke
    except ValueError as e:
        print("Caught ValueError")
        print(f"Current exception: {e}")
        print(f"Exception has cause: {e.__cause__ is not None}")
        
        if e.__cause__:
            print(f"Cause exception: {e.__cause__}")
            print(f"Cause type: {type(e.__cause__).__name__}")

demonstrate_exception_context()
demonstrate_exception_cause()
print()

# ============================================================================
# PART 6: Practical Example - Error Logging System
# ============================================================================

print("=" * 60)
print("PART 6: Practical Error Logging")
print("=" * 60)

class ErrorLogger:
    """
    Comprehensive error logger that captures all exception details.
    """
    def __init__(self):
        self.errors = []
    
    def log_exception(self, context=""):
        """
        Logs current exception with full details.
        
        Parameters:
            context (str): Additional context about where error occurred
        """
        exc_type, exc_value, exc_traceback = sys.exc_info()
        
        if exc_type is None:
            print("No exception to log")
            return
        
        # Create error record
        error_record = {
            "context": context,
            "type": exc_type.__name__,
            "message": str(exc_value),
            "args": exc_value.args,
            "traceback": traceback.format_tb(exc_traceback),
        }
        
        # Add context information if present
        if hasattr(exc_value, '__context__') and exc_value.__context__:
            error_record["has_context"] = True
            error_record["context_type"] = type(exc_value.__context__).__name__
        
        # Add cause information if present  
        if hasattr(exc_value, '__cause__') and exc_value.__cause__:
            error_record["has_cause"] = True
            error_record["cause_type"] = type(exc_value.__cause__).__name__
        
        self.errors.append(error_record)
    
    def display_errors(self):
        """Display all logged errors."""
        print(f"\nTotal errors logged: {len(self.errors)}")
        print("=" * 60)
        
        for i, error in enumerate(self.errors, 1):
            print(f"\nError #{i}:")
            print(f"Context: {error['context']}")
            print(f"Type: {error['type']}")
            print(f"Message: {error['message']}")
            
            if error.get('has_context'):
                print(f"Has context: {error['context_type']}")
            
            if error.get('has_cause'):
                print(f"Has cause: {error['cause_type']}")
            
            print(f"Traceback (last call):")
            if error['traceback']:
                print(error['traceback'][-1], end='')

# Test the error logger
logger = ErrorLogger()

print("\nTesting error logger:")
print("-" * 40)

# Test 1: Division error
try:
    result = 100 / 0
except:
    logger.log_exception("Division operation")
    print("Error logged: Division by zero")

# Test 2: Type error
try:
    result = "text" + 123
except:
    logger.log_exception("String concatenation")
    print("Error logged: Type mismatch")

# Test 3: Index error
try:
    my_list = [1, 2, 3]
    value = my_list[10]
except:
    logger.log_exception("List access")
    print("Error logged: Index out of range")

# Display all logged errors
logger.display_errors()
print()

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
EXCEPTION ATTRIBUTES:
1. __class__: The exception type
2. __class__.__name__: Exception type name as string
3. args: Tuple of arguments passed to exception
4. __str__(): Human-readable string representation
5. __context__: Previous exception (implicit chaining)
6. __cause__: Explicitly chained exception (via 'from')

sys.exc_info():
- Returns (type, value, traceback) of current exception
- Useful in bare except blocks
- Must be called within exception handler
- Returns (None, None, None) if no exception

TRACEBACK MODULE:
- format_exception(): Full formatted traceback
- format_exception_only(): Just the exception line
- extract_tb(): List of traceback frames
- print_exception(): Print to stdout/stderr

BEST PRACTICES:
- Capture exception details for logging
- Use 'from' for explicit exception chaining
- Access traceback for debugging
- Log context, not just exception message
- Include timestamp in error logs
- Don't expose sensitive data in exception messages

COMMON USE CASES:
1. Error logging systems
2. Debugging tools
3. Exception monitoring/reporting
4. Test frameworks
5. API error responses
""")

print("\n" + "=" * 60)
print("End of Module 04: Exception Information")
print("=" * 60)
