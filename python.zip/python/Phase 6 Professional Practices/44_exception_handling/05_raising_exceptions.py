"""
05_raising_exceptions.py
========================
Raising and Re-raising Exceptions

Topics Covered:
- Raising exceptions with raise statement
- Re-raising caught exceptions
- Raising exceptions with custom messages
- When to raise exceptions
- Exception propagation

Learning Objectives:
- Understand when and how to raise exceptions
- Master re-raising exceptions
- Create informative exception messages
- Use exceptions for control flow appropriately
"""

# ============================================================================
# PART 1: Basic raise Statement
# ============================================================================

print("=" * 60)
print("PART 1: Raising Exceptions")
print("=" * 60)

def withdraw(balance, amount):
    """
    Withdraw money from account.
    
    Parameters:
        balance (float): Current balance
        amount (float): Amount to withdraw
    
    Returns:
        float: New balance
    
    Raises:
        ValueError: If amount is negative or exceeds balance
    """
    if amount < 0:
        # Raise an exception with descriptive message
        raise ValueError(f"Withdrawal amount cannot be negative: {amount}")
    
    if amount > balance:
        # Raise exception with detailed information
        raise ValueError(f"Insufficient funds: balance={balance}, requested={amount}")
    
    return balance - amount

print("\nExample 1: Raising ValueError for invalid input")
print("-" * 40)

test_cases = [
    (1000, 500),   # Valid
    (1000, -100),  # Negative amount
    (1000, 1500),  # Insufficient funds
]

for balance, amount in test_cases:
    try:
        new_balance = withdraw(balance, amount)
        print(f"✓ Withdrew ${amount} from ${balance} -> New balance: ${new_balance}")
    except ValueError as e:
        print(f"✗ Error: {e}")

print()

# ============================================================================
# PART 2: Raising Different Exception Types
# ============================================================================

print("=" * 60)
print("PART 2: Choosing Appropriate Exception Types")
print("=" * 60)

def process_data(data):
    """
    Process data with appropriate exception types.
    
    Parameters:
        data: Input data to process
    
    Raises:
        TypeError: If data type is wrong
        ValueError: If data value is invalid
        RuntimeError: If operation fails
    """
    # Check type
    if not isinstance(data, (int, float)):
        raise TypeError(f"Expected numeric type, got {type(data).__name__}")
    
    # Check value
    if data < 0:
        raise ValueError(f"Data must be non-negative, got {data}")
    
    # Simulate processing that might fail
    if data > 1000:
        raise RuntimeError(f"Cannot process values exceeding 1000")
    
    return data * 2

print("\nExample 2: Different exception types for different errors")
print("-" * 40)

test_data = [50, "text", -10, 1500]

for data in test_data:
    try:
        result = process_data(data)
        print(f"✓ process_data({repr(data)}) = {result}")
    except TypeError as e:
        print(f"✗ TypeError: {e}")
    except ValueError as e:
        print(f"✗ ValueError: {e}")
    except RuntimeError as e:
        print(f"✗ RuntimeError: {e}")

print()

# ============================================================================
# PART 3: Re-raising Exceptions
# ============================================================================

print("=" * 60)
print("PART 3: Re-raising Caught Exceptions")
print("=" * 60)

def divide_and_log(a, b):
    """
    Perform division with logging, then re-raise exception.
    
    This pattern is useful when you want to:
    - Log the error
    - Do some cleanup
    - But still propagate the exception to caller
    """
    try:
        result = a / b
        return result
    except ZeroDivisionError as e:
        # Log the error
        print(f"  [LOG] Division by zero: {a}/{b}")
        
        # Re-raise the same exception
        raise  # No argument = re-raise current exception
        
        # Alternative: raise e  (same effect)
        # Alternative: raise ZeroDivisionError("custom message")  (new exception)

print("\nExample 3a: Re-raising without modification")
print("-" * 40)

try:
    result = divide_and_log(10, 0)
except ZeroDivisionError as e:
    print(f"  [MAIN] Caught re-raised exception: {e}")

print("\nExample 3b: Conditional re-raising")
print("-" * 40)

def smart_divide(a, b, default=None):
    """
    Division that handles or re-raises based on whether default is provided.
    """
    try:
        return a / b
    except ZeroDivisionError:
        if default is not None:
            print(f"  Using default value: {default}")
            return default
        else:
            print(f"  No default provided, re-raising exception")
            raise  # Re-raise when no default

# Case 1: With default
try:
    result = smart_divide(10, 0, default=0)
    print(f"  Result: {result}")
except ZeroDivisionError:
    print(f"  Exception not handled")

# Case 2: Without default
try:
    result = smart_divide(10, 0)
    print(f"  Result: {result}")
except ZeroDivisionError as e:
    print(f"  Caught re-raised exception: {e}")

print()

# ============================================================================
# PART 4: Exception Chaining
# ============================================================================

print("=" * 60)
print("PART 4: Exception Chaining with 'from'")
print("=" * 60)

def parse_config_file(filename):
    """
    Parse configuration file, chain exceptions to show context.
    """
    try:
        # Simulate file reading
        if filename == "missing.txt":
            raise FileNotFoundError(f"Config file not found: {filename}")
        
        # Simulate parsing
        config_text = "invalid: : syntax"
        if ": :" in config_text:
            raise ValueError("Invalid config syntax")
        
    except FileNotFoundError as e:
        # Chain with more context
        raise RuntimeError(f"Failed to load configuration") from e
    
    except ValueError as e:
        # Chain parsing error
        raise RuntimeError(f"Configuration file is malformed") from e

print("\nExample 4: Exception chaining shows full context")
print("-" * 40)

try:
    config = parse_config_file("missing.txt")
except RuntimeError as e:
    print(f"Caught: {e}")
    print(f"Caused by: {e.__cause__}")
    print(f"Original exception type: {type(e.__cause__).__name__}")

print()

# ============================================================================
# PART 5: Suppressing Exception Context
# ============================================================================

print("=" * 60)
print("PART 5: Suppressing Context with 'from None'")
print("=" * 60)

def validate_user_age(age_string):
    """
    Convert and validate age, hiding internal exception.
    """
    try:
        age = int(age_string)
        if age < 0 or age > 150:
            raise ValueError("Age out of valid range")
        return age
    except ValueError:
        # Raise new exception without showing the conversion error
        raise ValueError(f"Invalid age input: {age_string}") from None

print("\nExample 5: Clean error messages without implementation details")
print("-" * 40)

test_inputs = ["25", "abc", "-5"]

for inp in test_inputs:
    try:
        age = validate_user_age(inp)
        print(f"✓ Valid age: {age}")
    except ValueError as e:
        print(f"✗ {e}")
        # Note: No mention of int() conversion failure

print()

# ============================================================================
# PART 6: When to Raise Exceptions
# ============================================================================

print("=" * 60)
print("PART 6: When to Raise Exceptions")
print("=" * 60)

print("""
RAISE EXCEPTIONS WHEN:
1. Preconditions are not met
2. Invalid arguments provided
3. Operation cannot be completed
4. Resource not available
5. Data is corrupted or invalid
6. Contract/invariant is violated

DON'T RAISE EXCEPTIONS FOR:
1. Normal control flow
2. Expected variations in data
3. Performance-critical paths
4. User mistakes that can be handled gracefully
""")

# Good example: Precondition checking
class Stack:
    """Stack implementation with appropriate exception raising."""
    
    def __init__(self, max_size=10):
        if max_size <= 0:
            raise ValueError(f"Stack size must be positive, got {max_size}")
        self.items = []
        self.max_size = max_size
    
    def push(self, item):
        """Push item onto stack."""
        if len(self.items) >= self.max_size:
            raise OverflowError(f"Stack is full (max size: {self.max_size})")
        self.items.append(item)
    
    def pop(self):
        """Pop item from stack."""
        if not self.items:
            raise IndexError("Cannot pop from empty stack")
        return self.items.pop()
    
    def peek(self):
        """View top item without removing."""
        if not self.items:
            raise IndexError("Cannot peek at empty stack")
        return self.items[-1]

print("\nExample 6: Stack with proper exception raising")
print("-" * 40)

try:
    # Create stack
    stack = Stack(max_size=3)
    print("Created stack with max_size=3")
    
    # Push items
    for i in range(3):
        stack.push(i)
        print(f"  Pushed: {i}")
    
    # Try to overflow
    stack.push(999)  # Should raise OverflowError
    
except OverflowError as e:
    print(f"  ✗ {e}")

try:
    # Pop all items
    while True:
        item = stack.pop()
        print(f"  Popped: {item}")
except IndexError as e:
    print(f"  ✗ {e}")

print()

# ============================================================================
# PART 7: Practical Example - Input Validation
# ============================================================================

print("=" * 60)
print("PART 7: Comprehensive Input Validation")
print("=" * 60)

def create_user_account(username, email, age):
    """
    Create user account with thorough validation.
    
    Parameters:
        username (str): Username (3-20 chars, alphanumeric)
        email (str): Email address (must contain @)
        age (int): User age (must be 13+)
    
    Returns:
        dict: User account information
    
    Raises:
        TypeError: If arguments have wrong types
        ValueError: If arguments have invalid values
    """
    # Type validation
    if not isinstance(username, str):
        raise TypeError(f"Username must be string, got {type(username).__name__}")
    
    if not isinstance(email, str):
        raise TypeError(f"Email must be string, got {type(email).__name__}")
    
    if not isinstance(age, int):
        raise TypeError(f"Age must be integer, got {type(age).__name__}")
    
    # Value validation
    if len(username) < 3 or len(username) > 20:
        raise ValueError(f"Username must be 3-20 characters, got {len(username)}")
    
    if not username.isalnum():
        raise ValueError(f"Username must be alphanumeric: {username}")
    
    if "@" not in email:
        raise ValueError(f"Invalid email format: {email}")
    
    if age < 13:
        raise ValueError(f"Users must be 13+, got age {age}")
    
    # All validation passed
    return {
        "username": username,
        "email": email,
        "age": age,
        "status": "active"
    }

print("\nTesting comprehensive validation:")
print("-" * 40)

test_users = [
    ("john_doe", "john@email.com", 25),  # Valid
    ("ab", "short@email.com", 25),       # Username too short
    ("john@123", "john@email.com", 25),  # Invalid characters
    ("john_doe", "invalidemail", 25),    # Bad email
    ("john_doe", "john@email.com", 10),  # Too young
    ("john_doe", 123, 25),                # Wrong type for email
]

for username, email, age in test_users:
    try:
        user = create_user_account(username, email, age)
        print(f"✓ Created account: {user['username']}")
    except (TypeError, ValueError) as e:
        print(f"✗ {type(e).__name__}: {e}")

print()

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
RAISING EXCEPTIONS:
1. Use 'raise ExceptionType(message)' to raise exceptions
2. Choose appropriate built-in exception types
3. Provide clear, descriptive error messages
4. Include relevant context in exception messages

RE-RAISING:
1. Use bare 'raise' to re-raise current exception
2. Re-raise after logging or cleanup operations
3. Preserves original traceback
4. Useful for exception monitoring

EXCEPTION CHAINING:
1. Use 'raise NewException from original_exception'
2. Explicitly shows exception context
3. Helps debug complex error scenarios
4. Shows full chain of events

SUPPRESSING CONTEXT:
1. Use 'raise NewException from None'
2. Hides implementation details
3. Provides clean user-facing errors
4. Use sparingly, mainly for API boundaries

BEST PRACTICES:
- Raise exceptions for exceptional conditions
- Don't use exceptions for normal control flow
- Choose specific exception types over generic
- Provide actionable error messages
- Document exceptions in docstrings
- Re-raise after logging when appropriate
- Chain exceptions to preserve context
- Validate inputs early
- Fail fast with clear error messages

COMMON EXCEPTION TYPES:
- ValueError: Invalid value
- TypeError: Wrong type
- RuntimeError: Operation failed
- IndexError: Invalid index
- KeyError: Missing dictionary key
- AttributeError: Missing attribute
- FileNotFoundError: File doesn't exist
- PermissionError: Access denied
""")

print("\n" + "=" * 60)
print("End of Module 05: Raising Exceptions")
print("=" * 60)
