"""
06_custom_exceptions.py
=======================
Creating Custom Exception Classes

Topics Covered:
- Defining custom exception classes
- Exception class hierarchy
- Adding custom attributes to exceptions
- When to create custom exceptions
- Best practices for custom exceptions

Learning Objectives:
- Create custom exception classes for specific use cases
- Understand exception inheritance
- Add meaningful attributes to exceptions
- Design exception hierarchies
"""

# ============================================================================
# PART 1: Basic Custom Exception
# ============================================================================

print("=" * 60)
print("PART 1: Creating Basic Custom Exceptions")
print("=" * 60)

# Simplest custom exception - just inherits from Exception
class NetworkError(Exception):
    """Raised when network operation fails."""
    pass

# Custom exception with default message
class DatabaseError(Exception):
    """Raised when database operation fails."""
    def __init__(self, message="Database operation failed"):
        self.message = message
        super().__init__(self.message)

print("\nExample 1: Basic custom exceptions")
print("-" * 40)

def connect_to_server(server_address):
    """Simulate server connection."""
    if "invalid" in server_address:
        raise NetworkError(f"Cannot connect to {server_address}")
    return f"Connected to {server_address}"

def query_database(query):
    """Simulate database query."""
    if "DROP" in query.upper():
        raise DatabaseError("Destructive operations not allowed")
    return "Query executed"

# Test custom exceptions
test_cases = [
    ("connect", "valid.server.com"),
    ("connect", "invalid.server.com"),
    ("query", "SELECT * FROM users"),
    ("query", "DROP TABLE users"),
]

for operation, param in test_cases:
    try:
        if operation == "connect":
            result = connect_to_server(param)
        else:
            result = query_database(param)
        print(f"✓ {operation}('{param}'): {result}")
    except (NetworkError, DatabaseError) as e:
        print(f"✗ {type(e).__name__}: {e}")

print()

# ============================================================================
# PART 2: Custom Exceptions with Attributes
# ============================================================================

print("=" * 60)
print("PART 2: Adding Attributes to Custom Exceptions")
print("=" * 60)

class ValidationError(Exception):
    """
    Raised when validation fails.
    
    Attributes:
        field (str): Name of field that failed validation
        value: The invalid value
        reason (str): Why validation failed
    """
    def __init__(self, field, value, reason):
        self.field = field
        self.value = value
        self.reason = reason
        
        # Create informative message
        message = f"Validation failed for '{field}': {reason} (value: {repr(value)})"
        super().__init__(message)

class InsufficientFundsError(Exception):
    """
    Raised when account has insufficient funds.
    
    Attributes:
        balance (float): Current account balance
        required (float): Amount required for operation
        shortfall (float): Amount short
    """
    def __init__(self, balance, required):
        self.balance = balance
        self.required = required
        self.shortfall = required - balance
        
        message = f"Insufficient funds: need ${required}, have ${balance} (short ${self.shortfall})"
        super().__init__(message)

print("\nExample 2: Exceptions with custom attributes")
print("-" * 40)

def validate_email(email):
    """Validate email address."""
    if not isinstance(email, str):
        raise ValidationError("email", email, "must be a string")
    
    if "@" not in email:
        raise ValidationError("email", email, "missing @ symbol")
    
    if len(email) < 5:
        raise ValidationError("email", email, "too short")
    
    return True

def make_purchase(balance, cost):
    """Simulate purchase with balance check."""
    if cost > balance:
        raise InsufficientFundsError(balance, cost)
    return balance - cost

# Test validation error
test_emails = ["valid@email.com", "nopsat", 12345, "a@b"]

for email in test_emails:
    try:
        validate_email(email)
        print(f"✓ Valid email: {email}")
    except ValidationError as e:
        print(f"✗ ValidationError:")
        print(f"  Field: {e.field}")
        print(f"  Value: {repr(e.value)}")
        print(f"  Reason: {e.reason}")

print()

# Test insufficient funds error
try:
    new_balance = make_purchase(100, 150)
except InsufficientFundsError as e:
    print(f"✗ Purchase failed:")
    print(f"  Balance: ${e.balance}")
    print(f"  Required: ${e.required}")
    print(f"  Shortfall: ${e.shortfall}")

print()

# ============================================================================
# PART 3: Exception Hierarchy
# ============================================================================

print("=" * 60)
print("PART 3: Creating Exception Hierarchies")
print("=" * 60)

# Base exception for all API errors
class APIError(Exception):
    """Base class for all API-related errors."""
    pass

# Specific API errors inherit from base
class AuthenticationError(APIError):
    """Raised when authentication fails."""
    def __init__(self, username):
        self.username = username
        super().__init__(f"Authentication failed for user: {username}")

class RateLimitError(APIError):
    """Raised when rate limit is exceeded."""
    def __init__(self, limit, reset_time):
        self.limit = limit
        self.reset_time = reset_time
        super().__init__(f"Rate limit ({limit} requests) exceeded. Reset at {reset_time}")

class ResourceNotFoundError(APIError):
    """Raised when requested resource doesn\'t exist."""
    def __init__(self, resource_type, resource_id):
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(f"{resource_type} with ID {resource_id} not found")

print("\nExample 3: Exception hierarchy allows flexible catching")
print("-" * 40)

def api_operation(operation_type):
    """Simulate various API operations."""
    if operation_type == "auth_fail":
        raise AuthenticationError("john_doe")
    elif operation_type == "rate_limit":
        raise RateLimitError(100, "2024-01-01 12:00:00")
    elif operation_type == "not_found":
        raise ResourceNotFoundError("User", 12345)
    return "Success"

operations = ["success", "auth_fail", "rate_limit", "not_found"]

for op in operations:
    try:
        result = api_operation(op)
        print(f"✓ {op}: {result}")
    except AuthenticationError as e:
        print(f"✗ Authentication failed: {e.username}")
    except RateLimitError as e:
        print(f"✗ Rate limited: {e.limit} requests, reset at {e.reset_time}")
    except ResourceNotFoundError as e:
        print(f"✗ Not found: {e.resource_type} #{e.resource_id}")
    except APIError as e:
        # Catches any other API error
        print(f"✗ API Error: {e}")

print("\nCatching all API errors at once:")
print("-" * 40)

for op in operations:
    try:
        result = api_operation(op)
        print(f"✓ {op}: {result}")
    except APIError as e:
        # Single handler for entire hierarchy
        print(f"✗ API Error ({type(e).__name__}): {e}")

print()

# ============================================================================
# PART 4: When to Create Custom Exceptions
# ============================================================================

print("=" * 60)
print("PART 4: When to Create Custom Exceptions")
print("=" * 60)

print("""
CREATE CUSTOM EXCEPTIONS WHEN:
1. You need domain-specific error handling
2. You want to add custom attributes
3. You need to distinguish your errors from standard ones
4. Building a library or framework
5. Need exception hierarchy for flexible handling

DON\'T CREATE CUSTOM EXCEPTIONS WHEN:
1. Built-in exceptions are sufficient
2. Exception is too specific (used only once)
3. Standard exception clearly communicates the problem
4. Adding unnecessary complexity

DESIGN PRINCIPLES:
- Inherit from Exception or appropriate subclass
- Use descriptive names ending in "Error"
- Document the exception purpose
- Add relevant attributes
- Provide clear error messages
- Create hierarchy for related exceptions
""")

# ============================================================================
# PART 5: Practical Example - Order Processing System
# ============================================================================

print("=" * 60)
print("PART 5: Complete Example - Order Processing")
print("=" * 60)

# Exception hierarchy for order processing
class OrderError(Exception):
    """Base class for order-related errors."""
    pass

class InvalidOrderError(OrderError):
    """Raised when order data is invalid."""
    def __init__(self, order_id, reason):
        self.order_id = order_id
        self.reason = reason
        super().__init__(f"Order {order_id} is invalid: {reason}")

class OutOfStockError(OrderError):
    """Raised when product is out of stock."""
    def __init__(self, product_id, quantity_available, quantity_requested):
        self.product_id = product_id
        self.quantity_available = quantity_available
        self.quantity_requested = quantity_requested
        super().__init__(
            f"Product {product_id} out of stock: "
            f"requested {quantity_requested}, available {quantity_available}"
        )

class PaymentDeclinedError(OrderError):
    """Raised when payment is declined."""
    def __init__(self, order_id, amount, decline_reason):
        self.order_id = order_id
        self.amount = amount
        self.decline_reason = decline_reason
        super().__init__(
            f"Payment declined for order {order_id}: "
            f"${amount} - {decline_reason}"
        )

class ShippingError(OrderError):
    """Raised when shipping fails."""
    def __init__(self, order_id, address, reason):
        self.order_id = order_id
        self.address = address
        self.reason = reason
        super().__init__(
            f"Cannot ship order {order_id} to {address}: {reason}"
        )

# Order processing system
class OrderProcessor:
    """Processes customer orders with custom exception handling."""
    
    def __init__(self):
        self.inventory = {
            "PROD001": 10,
            "PROD002": 5,
            "PROD003": 0,
        }
    
    def process_order(self, order):
        """
        Process a customer order.
        
        Parameters:
            order (dict): Order details
        
        Raises:
            InvalidOrderError: If order data is invalid
            OutOfStockError: If product unavailable
            PaymentDeclinedError: If payment fails
            ShippingError: If shipping fails
        """
        # Validate order
        if "order_id" not in order:
            raise InvalidOrderError("UNKNOWN", "Missing order ID")
        
        order_id = order["order_id"]
        
        if "product_id" not in order:
            raise InvalidOrderError(order_id, "Missing product ID")
        
        if "quantity" not in order or order["quantity"] <= 0:
            raise InvalidOrderError(order_id, "Invalid quantity")
        
        # Check inventory
        product_id = order["product_id"]
        quantity = order["quantity"]
        
        if product_id not in self.inventory:
            raise InvalidOrderError(order_id, f"Unknown product: {product_id}")
        
        available = self.inventory[product_id]
        if quantity > available:
            raise OutOfStockError(product_id, available, quantity)
        
        # Process payment
        amount = order.get("amount", 0)
        if amount < 10:
            raise PaymentDeclinedError(order_id, amount, "Amount too low")
        
        # Validate shipping
        address = order.get("address", "")
        if not address:
            raise ShippingError(order_id, address, "Address missing")
        
        # Success - update inventory
        self.inventory[product_id] -= quantity
        return {
            "order_id": order_id,
            "status": "completed",
            "message": f"Order {order_id} processed successfully"
        }

print("\nTesting order processing system:")
print("-" * 40)

processor = OrderProcessor()

# Test orders with various issues
test_orders = [
    {
        "order_id": "ORD001",
        "product_id": "PROD001",
        "quantity": 2,
        "amount": 50,
        "address": "123 Main St"
    },  # Valid
    {
        "product_id": "PROD001",
        "quantity": 2
    },  # Missing order_id
    {
        "order_id": "ORD002",
        "product_id": "PROD003",
        "quantity": 1,
        "amount": 20,
        "address": "456 Oak Ave"
    },  # Out of stock
    {
        "order_id": "ORD003",
        "product_id": "PROD002",
        "quantity": 1,
        "amount": 5,
        "address": "789 Pine Rd"
    },  # Payment declined
    {
        "order_id": "ORD004",
        "product_id": "PROD002",
        "quantity": 1,
        "amount": 20,
    },  # Missing address
]

for order in test_orders:
    try:
        result = processor.process_order(order)
        print(f"✓ {result['message']}")
    except InvalidOrderError as e:
        print(f"✗ Invalid Order: {e.reason}")
    except OutOfStockError as e:
        print(f"✗ Out of Stock: {e.product_id} (need {e.quantity_requested}, have {e.quantity_available})")
    except PaymentDeclinedError as e:
        print(f"✗ Payment Declined: ${e.amount} - {e.decline_reason}")
    except ShippingError as e:
        print(f"✗ Shipping Failed: {e.reason}")
    except OrderError as e:
        print(f"✗ Order Error: {e}")

print()

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
CREATING CUSTOM EXCEPTIONS:
1. Inherit from Exception or appropriate subclass
2. Use descriptive names ending in "Error"
3. Override __init__ to add custom attributes
4. Call super().__init__(message) with clear message
5. Document purpose and attributes

EXCEPTION HIERARCHY:
1. Create base exception for related errors
2. Specific exceptions inherit from base
3. Allows catching at different levels of specificity
4. Organizes exceptions logically
5. Makes exception handling more flexible

CUSTOM ATTRIBUTES:
1. Store relevant context in exception object
2. Makes error handling more informative
3. Allows programmatic error analysis
4. Useful for logging and debugging
5. Enables recovery strategies

BEST PRACTICES:
- Keep exception classes simple
- Don\'t duplicate standard exceptions
- Use hierarchy for related exceptions
- Provide meaningful default messages
- Document when exceptions are raised
- Include context in exception objects
- Name exceptions clearly and consistently
- Consider recovery strategies when designing

NAMING CONVENTIONS:
- End names with "Error" or "Exception"
- Use descriptive names (InvalidOrderError vs Error1)
- Follow domain terminology
- Be consistent across codebase

WHEN TO USE:
✓ Domain-specific errors
✓ Need custom attributes
✓ Building library/framework
✓ Complex error handling scenarios
✓ Need exception hierarchy

✗ Built-in exception sufficient
✗ Exception used only once
✗ Standard exception is clear
✗ Adds unnecessary complexity
""")

print("\n" + "=" * 60)
print("End of Module 06: Custom Exceptions")
print("=" * 60)
