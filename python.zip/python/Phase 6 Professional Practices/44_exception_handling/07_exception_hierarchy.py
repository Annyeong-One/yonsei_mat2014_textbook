"""
07_exception_hierarchy.py
=========================
Understanding the Python Exception Hierarchy

Topics Covered:
- Built-in exception hierarchy
- Common exception base classes
- Catching exceptions by hierarchy level
- Multiple inheritance in exceptions
- Designing exception hierarchies

Learning Objectives:
- Understand Python\'s exception class structure
- Catch exceptions at appropriate levels
- Design effective exception hierarchies
- Use exception inheritance properly
"""

# ============================================================================
# PART 1: Python\'s Built-in Exception Hierarchy
# ============================================================================

print("=" * 60)
print("PART 1: Built-in Exception Hierarchy")
print("=" * 60)

print("""
Python\'s Exception Hierarchy:

BaseException
 ├── BaseExceptionGroup
 ├── GeneratorExit
 ├── KeyboardInterrupt
 ├── SystemExit
 └── Exception
      ├── ArithmeticError
      │    ├── FloatingPointError
      │    ├── OverflowError
      │    └── ZeroDivisionError
      ├── AssertionError
      ├── AttributeError
      ├── BufferError
      ├── EOFError
      ├── ImportError
      │    └── ModuleNotFoundError
      ├── LookupError
      │    ├── IndexError
      │    └── KeyError
      ├── MemoryError
      ├── NameError
      │    └── UnboundLocalError
      ├── OSError
      │    ├── FileNotFoundError
      │    ├── PermissionError
      │    ├── TimeoutError
      │    └── ... (many OS-related errors)
      ├── RuntimeError
      │    ├── NotImplementedError
      │    └── RecursionError
      ├── StopIteration
      ├── TypeError
      ├── ValueError
      │    └── UnicodeError
      │         ├── UnicodeDecodeError
      │         └── UnicodeEncodeError
      └── Warning (and many warning types)
""")

# ============================================================================
# PART 2: Exploring Exception Relationships
# ============================================================================

print("=" * 60)
print("PART 2: Exception Inheritance Relationships")
print("=" * 60)

def show_exception_hierarchy(exception_class):
    """
    Display the inheritance hierarchy for an exception class.
    
    Parameters:
        exception_class: Exception class to analyze
    """
    print(f"\n{exception_class.__name__} hierarchy:")
    print("-" * 40)
    
    # Get method resolution order (MRO)
    mro = exception_class.__mro__
    
    for i, cls in enumerate(mro):
        indent = "  " * i
        print(f"{indent}└─ {cls.__name__}")

# Examine various exception hierarchies
exceptions_to_examine = [
    ZeroDivisionError,
    FileNotFoundError,
    IndexError,
    ModuleNotFoundError,
]

for exc_class in exceptions_to_examine:
    show_exception_hierarchy(exc_class)

print()

# ============================================================================
# PART 3: Catching at Different Hierarchy Levels
# ============================================================================

print("=" * 60)
print("PART 3: Catching at Different Hierarchy Levels")
print("=" * 60)

def demonstrate_catching_levels():
    """Show how catching at different levels works."""
    
    operations = [
        ("Division by zero", lambda: 10 / 0),  # ZeroDivisionError
        ("Overflow", lambda: pow(10, 10000)),  # OverflowError (may not raise on all systems)
        ("Type error", lambda: "str" + 5),      # TypeError
    ]
    
    print("\nExample 1: Catching specific exception")
    print("-" * 40)
    for name, operation in operations:
        try:
            operation()
        except ZeroDivisionError as e:
            print(f"{name}: Caught ZeroDivisionError - {e}")
        except Exception as e:
            print(f"{name}: Caught {type(e).__name__} - {e}")
    
    print("\nExample 2: Catching parent class (ArithmeticError)")
    print("-" * 40)
    for name, operation in operations:
        try:
            operation()
        except ArithmeticError as e:
            # Catches ZeroDivisionError, OverflowError, FloatingPointError
            print(f"{name}: Caught ArithmeticError subtype - {type(e).__name__}")
        except Exception as e:
            print(f"{name}: Caught {type(e).__name__}")
    
    print("\nExample 3: Catching at Exception level")
    print("-" * 40)
    for name, operation in operations:
        try:
            operation()
        except Exception as e:
            # Catches all normal exceptions
            print(f"{name}: Caught {type(e).__name__}")

demonstrate_catching_levels()
print()

# ============================================================================
# PART 4: LookupError Family
# ============================================================================

print("=" * 60)
print("PART 4: The LookupError Family")
print("=" * 60)

print("""
LookupError is the base class for exceptions raised when a key or index
is invalid:
- IndexError: Invalid sequence index
- KeyError: Invalid dictionary key
""")

def demonstrate_lookup_errors():
    """Show LookupError and its subclasses."""
    
    print("\nExample: Catching LookupError catches both IndexError and KeyError")
    print("-" * 40)
    
    test_cases = [
        ("List index", lambda: [1, 2, 3][10]),          # IndexError
        ("Dict key", lambda: {"a": 1}["missing"]),      # KeyError
        ("String index", lambda: "hello"[100]),          # IndexError
        ("Valid access", lambda: [1, 2, 3][1]),         # Success
    ]
    
    for name, operation in test_cases:
        try:
            result = operation()
            print(f"✓ {name}: {result}")
        except LookupError as e:
            # Catches both IndexError and KeyError
            print(f"✗ {name}: {type(e).__name__} - {e}")

demonstrate_lookup_errors()
print()

# ============================================================================
# PART 5: OSError Family
# ============================================================================

print("=" * 60)
print("PART 5: The OSError Family")
print("=" * 60)

print("""
OSError is the base class for exceptions raised by operating system operations:
- FileNotFoundError: File or directory not found
- PermissionError: Operation not permitted
- TimeoutError: Operation timed out
- IsADirectoryError: File operation on directory
- NotADirectoryError: Directory operation on file
... and many more
""")

def demonstrate_os_errors():
    """Show OSError family exceptions."""
    
    print("\nExample: Various file system operations")
    print("-" * 40)
    
    operations = [
        ("Open missing file", lambda: open("nonexistent.txt", "r")),
        ("Read from directory", lambda: open("/tmp", "r")),
    ]
    
    for name, operation in operations:
        try:
            operation()
        except FileNotFoundError as e:
            print(f"✗ {name}: File not found")
        except IsADirectoryError as e:
            print(f"✗ {name}: Is a directory")
        except OSError as e:
            # Catches any other OS error
            print(f"✗ {name}: OS Error - {type(e).__name__}")

demonstrate_os_errors()
print()

# ============================================================================
# PART 6: Designing Custom Exception Hierarchies
# ============================================================================

print("=" * 60)
print("PART 6: Designing Custom Exception Hierarchies")
print("=" * 60)

# Well-designed exception hierarchy for a web application

class AppError(Exception):
    """Base exception for all application errors."""
    pass

# Authentication/Authorization errors
class SecurityError(AppError):
    """Base class for security-related errors."""
    pass

class AuthenticationError(SecurityError):
    """User authentication failed."""
    pass

class AuthorizationError(SecurityError):
    """User lacks required permissions."""
    pass

# Data errors
class DataError(AppError):
    """Base class for data-related errors."""
    pass

class ValidationError(DataError):
    """Data validation failed."""
    pass

class IntegrityError(DataError):
    """Data integrity constraint violated."""
    pass

# External service errors
class ExternalServiceError(AppError):
    """Base class for external service errors."""
    pass

class APIError(ExternalServiceError):
    """External API call failed."""
    pass

class TimeoutError(ExternalServiceError):
    """External service timeout."""
    pass

print("\nExample: Multi-level exception hierarchy")
print("-" * 40)

def process_request(scenario):
    """Simulate various error scenarios."""
    if scenario == "auth_fail":
        raise AuthenticationError("Invalid credentials")
    elif scenario == "no_permission":
        raise AuthorizationError("Insufficient permissions")
    elif scenario == "bad_data":
        raise ValidationError("Invalid email format")
    elif scenario == "api_down":
        raise APIError("Payment service unavailable")
    return "Success"

scenarios = ["success", "auth_fail", "no_permission", "bad_data", "api_down"]

# Catching at different hierarchy levels
print("\nCatching at specific level:")
for scenario in scenarios:
    try:
        result = process_request(scenario)
        print(f"  ✓ {scenario}: {result}")
    except AuthenticationError:
        print(f"  ✗ {scenario}: Authentication failed")
    except AuthorizationError:
        print(f"  ✗ {scenario}: Not authorized")
    except ValidationError:
        print(f"  ✗ {scenario}: Validation error")
    except ExternalServiceError:
        print(f"  ✗ {scenario}: External service issue")
    except AppError as e:
        print(f"  ✗ {scenario}: Application error")

print("\nCatching security errors together:")
for scenario in scenarios:
    try:
        result = process_request(scenario)
        print(f"  ✓ {scenario}: {result}")
    except SecurityError:
        # Catches both Authentication and Authorization errors
        print(f"  ✗ {scenario}: Security issue")
    except AppError:
        print(f"  ✗ {scenario}: Other application error")

print("\nCatching all app errors together:")
for scenario in scenarios:
    try:
        result = process_request(scenario)
        print(f"  ✓ {scenario}: {result}")
    except AppError as e:
        # Catches ALL custom application errors
        print(f"  ✗ {scenario}: App error ({type(e).__name__})")

print()

# ============================================================================
# PART 7: Best Practices for Exception Hierarchies
# ============================================================================

print("=" * 60)
print("PART 7: Hierarchy Design Best Practices")
print("=" * 60)

print("""
GOOD HIERARCHY DESIGN:

1. Single Base Exception:
   - Create one base exception for your library/application
   - All custom exceptions inherit from this base
   - Example: class MyLibraryError(Exception)

2. Logical Grouping:
   - Group related exceptions under common parent
   - Example: SecurityError → AuthenticationError, AuthorizationError
   
3. Appropriate Depth:
   - 2-3 levels is usually sufficient
   - Too shallow: lose grouping benefits
   - Too deep: overly complex

4. Catch at Appropriate Level:
   - Catch specific when you can handle it specifically
   - Catch parent when handling all children the same way
   - Catch base to handle all custom exceptions

5. Documentation:
   - Document the hierarchy
   - Explain when each exception is raised
   - Show example handling code

EXAMPLE HIERARCHY STRUCTURE:

MyLibraryError (base)
├── ConfigurationError
│   ├── MissingConfigError
│   └── InvalidConfigError
├── DataError
│   ├── ValidationError
│   └── TransformError
└── ConnectionError
    ├── TimeoutError
    └── AuthError

ANTI-PATTERNS TO AVOID:

✗ Too many levels (deep nesting)
✗ Inconsistent naming (Error vs Exception)
✗ Multiple inheritance without clear purpose
✗ Creating exceptions that are never caught separately
✗ Not using a common base exception
✗ Duplicating built-in exception purpose
""")

# ============================================================================
# PART 8: isinstance vs Exception Hierarchy
# ============================================================================

print("=" * 60)
print("PART 8: Using isinstance with Exceptions")
print("=" * 60)

def check_exception_type(exception):
    """
    Demonstrate using isinstance to check exception types.
    
    Parameters:
        exception: Exception instance to check
    """
    print(f"\nAnalyzing {type(exception).__name__}:")
    print("-" * 40)
    
    # Check specific type
    print(f"Is {type(exception).__name__}: {isinstance(exception, type(exception))}")
    
    # Check parent types
    checks = [
        (Exception, "Exception"),
        (ArithmeticError, "ArithmeticError"),
        (LookupError, "LookupError"),
        (OSError, "OSError"),
        (BaseException, "BaseException"),
    ]
    
    for exc_class, name in checks:
        is_instance = isinstance(exception, exc_class)
        if is_instance:
            print(f"Is {name}: True")

# Test with various exceptions
exceptions_to_check = [
    ZeroDivisionError("division by zero"),
    IndexError("list index out of range"),
    FileNotFoundError("file not found"),
    ValueError("invalid value"),
]

for exc in exceptions_to_check:
    check_exception_type(exc)

print()

# ============================================================================
# KEY TAKEAWAYS
# ============================================================================

print("=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
EXCEPTION HIERARCHY PRINCIPLES:

1. All exceptions inherit from BaseException
2. Normal exceptions inherit from Exception
3. System exceptions (KeyboardInterrupt, SystemExit) inherit directly from BaseException
4. Built-in exceptions are organized in logical groups

KEY EXCEPTION FAMILIES:
- ArithmeticError: Math-related errors
- LookupError: Index/key errors
- OSError: Operating system errors
- ImportError: Module import errors
- UnicodeError: Text encoding errors

CATCHING STRATEGIES:
1. Catch specific exception for specific handling
2. Catch parent class to handle related exceptions similarly
3. Catch Exception to handle all normal exceptions
4. Never catch BaseException (would catch system exceptions)

DESIGNING HIERARCHIES:
1. Start with single base exception
2. Group related exceptions logically
3. Keep hierarchy 2-3 levels deep
4. Use meaningful names
5. Document when each exception is raised

BEST PRACTICES:
✓ Inherit from Exception or specific subclass
✓ Create logical groupings
✓ Use appropriate catching level
✓ Document exception hierarchy
✓ Keep hierarchy simple
✓ Use isinstance for type checking

ANTI-PATTERNS:
✗ Catching BaseException
✗ Too deep hierarchy
✗ Inconsistent naming
✗ Not using a common base
✗ Overly specific exceptions never caught separately

BENEFITS OF HIERARCHIES:
1. Flexible error handling
2. Logical organization
3. Easy to extend
4. Clear responsibility
5. Better code maintainability
""")

print("\n" + "=" * 60)
print("End of Module 07: Exception Hierarchy")
print("=" * 60)
