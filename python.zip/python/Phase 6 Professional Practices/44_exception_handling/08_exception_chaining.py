"""
08_exception_chaining.py
========================
Exception Chaining and Context

Topics Covered:
- Implicit exception chaining (__context__)
- Explicit exception chaining (raise ... from)
- Suppressing context (from None)
- When to use each approach
- Debugging chained exceptions

Learning Objectives:
- Understand implicit vs explicit chaining
- Use 'from' keyword appropriately
- Suppress context when needed
- Debug complex exception chains
"""

import sys

print("=" * 60)
print("PART 1: Implicit Exception Chaining")
print("=" * 60)

print("""
When an exception is raised while handling another exception,
Python automatically creates a chain using __context__.
""")

def demonstrate_implicit_chaining():
    """Show implicit exception chaining."""
    print("\nExample 1: Implicit chaining")
    print("-" * 40)
    
    try:
        try:
            # First exception
            result = 10 / 0
        except ZeroDivisionError:
            # Second exception while handling first
            value = int("not_a_number")
    except ValueError as e:
        print(f"Caught: {type(e).__name__}: {e}")
        print(f"Has context: {e.__context__ is not None}")
        if e.__context__:
            print(f"Context: {type(e.__context__).__name__}: {e.__context__}")

demonstrate_implicit_chaining()

print("\n" + "=" * 60)
print("PART 2: Explicit Exception Chaining")
print("=" * 60)

print("""
Use 'raise ... from ...' to explicitly chain exceptions.
This shows clear cause-and-effect relationships.
""")

def load_config(filename):
    """Load configuration with explicit chaining."""
    try:
        with open(filename) as f:
            return f.read()
    except FileNotFoundError as e:
        raise RuntimeError(f"Cannot load config from {filename}") from e

try:
    config = load_config("nonexistent.conf")
except RuntimeError as e:
    print(f"\nCaught: {e}")
    print(f"Caused by: {e.__cause__}")

print("\n" + "=" * 60)
print("PART 3: Suppressing Context")
print("=" * 60)

print("""
Use 'raise ... from None' to suppress context.
Useful for hiding implementation details from users.
""")

def parse_age(age_str):
    """Parse age, suppressing internal conversion error."""
    try:
        age = int(age_str)
        if age < 0:
            raise ValueError("Age cannot be negative")
        return age
    except ValueError:
        raise ValueError(f"Invalid age: {age_str}") from None

try:
    parse_age("abc")
except ValueError as e:
    print(f"\nClean error message: {e}")
    print(f"No context shown: {e.__context__ is None}")
    print(f"No cause shown: {e.__cause__ is None}")

print("\n" + "=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
IMPLICIT CHAINING (__context__):
- Automatic when exception raised during exception handling
- Shows what was being handled when new exception occurred
- Preserved in traceback

EXPLICIT CHAINING (from):
- Use 'raise NewException from original'
- Shows clear cause-and-effect
- Recommended for wrapping lower-level exceptions

SUPPRESSING (from None):
- Use 'raise NewException from None'
- Hides implementation details
- Use sparingly, mainly for APIs

BEST PRACTICES:
- Use 'from' to show causation
- Use 'from None' to hide internals
- Don't suppress context unnecessarily
- Preserve debugging information
""")

print("\nEnd of Module 08: Exception Chaining")
