"""
09_context_managers.py
======================
Context Managers and Exception Handling

Topics Covered:
- The with statement
- __enter__ and __exit__ methods
- Exception handling in context managers
- Creating custom context managers
- contextlib module

Learning Objectives:
- Use with statement for resource management
- Understand context manager protocol
- Handle exceptions in __exit__
- Create custom context managers
"""

import contextlib

print("=" * 60)
print("PART 1: The with Statement")
print("=" * 60)

print("""
The 'with' statement ensures proper resource cleanup,
even when exceptions occur.
""")

# Traditional approach (manual cleanup)
print("\nWithout context manager:")
print("-" * 40)
file = None
try:
    file = open("/tmp/test.txt", "w")
    file.write("test")
except Exception as e:
    print(f"Error: {e}")
finally:
    if file:
        file.close()
        print("File closed manually")

# With context manager
print("\nWith context manager:")
print("-" * 40)
try:
    with open("/tmp/test.txt", "w") as file:
        file.write("test")
        print("File written successfully")
except Exception as e:
    print(f"Error: {e}")
print("File automatically closed")

print("\n" + "=" * 60)
print("PART 2: Custom Context Managers")
print("=" * 60)

class DatabaseConnection:
    """Custom context manager for database connections."""
    
    def __init__(self, db_name):
        self.db_name = db_name
        self.connected = False
    
    def __enter__(self):
        """Called when entering 'with' block."""
        print(f"  Connecting to {self.db_name}...")
        self.connected = True
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        """
        Called when exiting 'with' block.
        
        Parameters:
            exc_type: Exception class (or None)
            exc_value: Exception instance (or None)
            traceback: Traceback object (or None)
        
        Returns:
            bool: True to suppress exception, False to propagate
        """
        print(f"  Closing connection to {self.db_name}")
        self.connected = False
        
        if exc_type:
            print(f"  Exception occurred: {exc_type.__name__}")
            # Return False to propagate exception
            return False
        
        return False
    
    def query(self, sql):
        """Execute a query."""
        if not self.connected:
            raise RuntimeError("Not connected")
        print(f"  Executing: {sql}")
        return "Query result"

print("\nUsing custom context manager:")
print("-" * 40)

# Success case
with DatabaseConnection("mydb") as db:
    result = db.query("SELECT * FROM users")
    print(f"  Result: {result}")

# Exception case
try:
    with DatabaseConnection("mydb") as db:
        result = db.query("SELECT * FROM users")
        raise ValueError("Simulated error")
except ValueError:
    print("  Exception propagated after cleanup")

print("\n" + "=" * 60)
print("PART 3: contextlib Helpers")
print("=" * 60)

@contextlib.contextmanager
def timer(label):
    """Simple timer context manager."""
    import time
    print(f"  Starting: {label}")
    start = time.time()
    try:
        yield
    finally:
        elapsed = time.time() - start
        print(f"  Finished: {label} ({elapsed:.4f}s)")

print("\nUsing @contextmanager decorator:")
print("-" * 40)

with timer("Test operation"):
    total = sum(range(1000000))
    print(f"  Computed sum: {total}")

print("\n" + "=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
CONTEXT MANAGERS:
- Guarantee cleanup code runs
- Handle exceptions gracefully
- Simplify resource management
- More Pythonic than try/finally

THE with STATEMENT:
- Calls __enter__ when entering
- Calls __exit__ when exiting
- Always calls __exit__, even with exceptions

CREATING CONTEXT MANAGERS:
1. Class-based: Define __enter__ and __exit__
2. Decorator-based: Use @contextlib.contextmanager
3. __exit__ receives exception info
4. Return True from __exit__ to suppress exception

BEST PRACTICES:
- Use 'with' for file operations
- Use 'with' for locks and connections
- Create context managers for paired operations
- Document exception behavior
- Keep context managers simple

COMMON USE CASES:
- File I/O
- Database connections
- Lock acquisition
- Temporary state changes
- Resource cleanup
""")

print("\nEnd of Module 09: Context Managers")
