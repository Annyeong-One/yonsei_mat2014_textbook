"""
10_assertion_errors.py
======================
Assertions and AssertionError

Topics Covered:
- The assert statement
- When to use assertions
- AssertionError handling
- Assertions vs exceptions
- Debugging with assertions

Learning Objectives:
- Use assert for development checks
- Understand when NOT to use assert
- Handle AssertionError appropriately
- Distinguish assertions from validation
"""

print("=" * 60)
print("PART 1: Basic Assertions")
print("=" * 60)

print("""
Assertions are used to check conditions that should never be false.
They're for debugging, not for handling runtime errors.
""")

def calculate_average(numbers):
    """Calculate average of numbers."""
    # Assertion: numbers should never be empty (programmer error if it is)
    assert len(numbers) > 0, "numbers list cannot be empty"
    return sum(numbers) / len(numbers)

print("\nValid use:")
result = calculate_average([1, 2, 3, 4, 5])
print(f"Average: {result}")

print("\nInvalid use (will raise AssertionError):")
try:
    result = calculate_average([])
except AssertionError as e:
    print(f"AssertionError: {e}")

print("\n" + "=" * 60)
print("PART 2: Assertions vs Exceptions")
print("=" * 60)

print("""
ASSERTIONS:
- For checking code correctness
- Should never fail in production
- Can be disabled with -O flag
- Used during development/testing

EXCEPTIONS:
- For handling expected runtime conditions
- Normal program flow
- Always active
- Used in production
""")

# BAD: Using assert for validation
def withdraw_bad(balance, amount):
    """Bad example: using assert for validation."""
    assert amount > 0, "Amount must be positive"  # WRONG!
    assert amount <= balance, "Insufficient funds"  # WRONG!
    return balance - amount

# GOOD: Using exceptions for validation
def withdraw_good(balance, amount):
    """Good example: using exceptions for validation."""
    if amount <= 0:
        raise ValueError("Amount must be positive")
    if amount > balance:
        raise ValueError("Insufficient funds")
    return balance - amount

print("\nGood practice:")
try:
    withdraw_good(100, -50)
except ValueError as e:
    print(f"ValueError (correct): {e}")

print("\n" + "=" * 60)
print("PART 3: When to Use Assertions")
print("=" * 60)

print("""
USE ASSERTIONS FOR:
✓ Checking preconditions in private methods
✓ Checking postconditions
✓ Checking invariants
✓ Documenting assumptions
✓ Catching programmer errors

DON'T USE ASSERTIONS FOR:
✗ Validating user input
✗ Validating data from external sources
✗ Error handling
✗ Anything that can happen in production
✗ Side effects (assert count+=1)
""")

class Rectangle:
    """Rectangle with assertion checks."""
    
    def __init__(self, width, height):
        # Assertions check programmer assumptions
        assert width > 0, "Width must be positive"
        assert height > 0, "Height must be positive"
        self._width = width
        self._height = height
    
    def area(self):
        """Calculate area."""
        result = self._width * self._height
        # Postcondition: area must be positive
        assert result > 0, "Area calculation error"
        return result
    
    def scale(self, factor):
        """Scale rectangle."""
        # Precondition
        assert factor > 0, "Scale factor must be positive"
        
        self._width *= factor
        self._height *= factor
        
        # Invariant: dimensions stay positive
        assert self._width > 0 and self._height > 0

print("\nUsing assertions in classes:")
print("-" * 40)
rect = Rectangle(5, 10)
print(f"Area: {rect.area()}")
rect.scale(2)
print(f"After scaling: {rect.area()}")

print("\n" + "=" * 60)
print("KEY TAKEAWAYS")
print("=" * 60)
print("""
ASSERTIONS:
- Use for debugging and development
- Check conditions that should always be true
- Can be disabled with python -O
- Raise AssertionError when fail

SYNTAX:
assert condition, "optional message"

BEST PRACTICES:
- Use for internal consistency checks
- Don't use for user input validation
- Don't rely on assertions in production code
- Include helpful error messages
- Don't put side effects in assertions

COMMON PATTERNS:
- Precondition checks
- Postcondition checks
- Invariant checks
- Type checks during development
- State validation

REMEMBER:
Assertions are for finding bugs during development,
not for handling runtime errors in production!
""")

print("\nEnd of Module 10: Assertion Errors")
