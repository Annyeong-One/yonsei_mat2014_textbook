# 15_best_practices.py - Will be created
