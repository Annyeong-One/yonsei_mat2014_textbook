"""
03_logging_to_file.py - File-Based Logging

LEARNING OBJECTIVES:
- Write log messages to files
- Understand different file modes
- Manage log file locations
- Read and analyze log files
- Handle file permissions

DIFFICULTY: Beginner
ESTIMATED TIME: 40 minutes
PREREQUISITES: 01_basic_logging.py, 02_logging_levels.py
"""

import logging
import os
from datetime import datetime

# ============================================================================
# PART 1: WHY LOG TO FILES?
# ============================================================================

print("=" * 80)
print("PART 1: Why Log to Files Instead of Console?")
print("=" * 80)

"""
ADVANTAGES OF FILE LOGGING:

1. PERSISTENCE:
   - Console output disappears when program ends
   - Files persist for later analysis
   - Can review historical logs

2. PRODUCTION REQUIREMENTS:
   - Server programs don't have interactive consoles
   - Background processes need permanent records
   - Automated systems need log files for monitoring

3. ANALYSIS:
   - Can use text processing tools (grep, awk, etc.)
   - Can import into log analysis systems
   - Can search large volumes of logs

4. DEBUGGING:
   - Capture issues that happen sporadically
   - Share logs with team members
   - Compare logs from different runs

5. COMPLIANCE:
   - Many industries require audit trails
   - Legal requirements for log retention
   - Security monitoring needs permanent records
"""

print("\nFile logging is essential for:")
print("- Production applications")
print("- Long-running services")
print("- Systems without interactive terminals")
print("- Applications requiring audit trails")

# ============================================================================
# PART 2: BASIC FILE LOGGING
# ============================================================================

print("\n" + "=" * 80)
print("PART 2: Simple File Logging with basicConfig()")
print("=" * 80)

"""
The simplest way to log to a file is using basicConfig() with filename parameter.

KEY PARAMETERS:
- filename: Name of the file to write to
- filemode: 'w' (overwrite) or 'a' (append)
- level: Minimum logging level
- format: Log message format
"""

# Clean up any previous log files for this demo
if os.path.exists('app_log.txt'):
    os.remove('app_log.txt')

# Configure basic file logging
logging.basicConfig(
    filename='app_log.txt',    # File to write to
    filemode='w',              # 'w' = overwrite, 'a' = append
    level=logging.DEBUG,       # Minimum level
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Now all logging goes to the file instead of console
logging.debug("This is a debug message")
logging.info("Application started")
logging.warning("This is a warning")
logging.error("An error occurred")

print("\nLogged several messages to 'app_log.txt'")
print("Let's read the file to see what was written:\n")

# Read and display the log file
with open('app_log.txt', 'r') as f:
    print(f.read())

"""
IMPORTANT NOTES:

1. FILE MODE 'w' vs 'a':
   - 'w' (write): Creates new file or OVERWRITES existing file
   - 'a' (append): Creates new file or APPENDS to existing file
   - In production, you almost always want 'a' to preserve logs

2. FILE LOCATION:
   - Relative path: File created in current working directory
   - Absolute path: Specify full path like '/var/log/myapp.log'
   - Make sure directory exists and is writable

3. BUFFERING:
   - Log messages might be buffered
   - May not immediately appear in file
   - Buffering improves performance
"""

# ============================================================================
# PART 3: APPEND MODE - PRESERVING PREVIOUS LOGS
# ============================================================================

print("\n" + "=" * 80)
print("PART 3: Append Mode - Adding to Existing Logs")
print("=" * 80)

"""
In real applications, you usually want to APPEND to log files, not overwrite them.
This preserves your history.
"""

# For demonstration, we need to reset logging configuration
# In a real app, you'd configure once at startup
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# Configure with append mode
logging.basicConfig(
    filename='app_log.txt',
    filemode='a',  # APPEND mode
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

logging.info("This is a second run - file will be appended to")
logging.info("Previous logs are preserved")

print("\nAppended new messages. File now contains:\n")
with open('app_log.txt', 'r') as f:
    print(f.read())

"""
NOTICE: Both the original messages and new messages are present.
This is crucial for production systems where you need complete history.
"""

# ============================================================================
# PART 4: LOGGING TO DIFFERENT FILES
# ============================================================================

print("\n" + "=" * 80)
print("PART 4: Logging to Multiple Files")
print("=" * 80)

"""
Sometimes you want to log different types of messages to different files:
- General application log: app.log
- Error log: errors.log
- Audit log: audit.log
- Access log: access.log

We'll learn more about this in the Handlers section, but here's a preview.
"""

# Clean up
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# Create a custom logger
app_logger = logging.getLogger('application')
app_logger.setLevel(logging.DEBUG)

# Handler for general log
general_handler = logging.FileHandler('general.log', mode='w')
general_handler.setLevel(logging.DEBUG)
general_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
general_handler.setFormatter(general_formatter)

# Handler for errors only
error_handler = logging.FileHandler('errors.log', mode='w')
error_handler.setLevel(logging.ERROR)  # Only ERROR and CRITICAL
error_formatter = logging.Formatter('%(asctime)s - ERROR LOG - %(message)s')
error_handler.setFormatter(error_formatter)

# Add both handlers to logger
app_logger.addHandler(general_handler)
app_logger.addHandler(error_handler)

# Log messages at different levels
app_logger.debug("Debug message")
app_logger.info("Info message")
app_logger.warning("Warning message")
app_logger.error("Error message")
app_logger.critical("Critical message")

print("\nCreated two log files: general.log and errors.log\n")

print("Contents of general.log (all messages):")
print("-" * 60)
with open('general.log', 'r') as f:
    print(f.read())

print("\nContents of errors.log (only ERROR and CRITICAL):")
print("-" * 60)
with open('errors.log', 'r') as f:
    content = f.read()
    if content:
        print(content)
    else:
        print("File is empty - no errors logged yet")

"""
PATTERN: Different files for different purposes
- general.log: Everything for debugging
- errors.log: Only errors for quick review
- This pattern is very common in production systems
"""

# ============================================================================
# PART 5: ORGANIZING LOG FILES
# ============================================================================

print("\n" + "=" * 80)
print("PART 5: Organizing Log Files in Directories")
print("=" * 80)

"""
BEST PRACTICES FOR LOG FILE ORGANIZATION:

1. Use a dedicated logs directory
2. Use descriptive filenames
3. Include dates in filenames for historical logs
4. Use subdirectories for different components
5. Set appropriate file permissions

EXAMPLE DIRECTORY STRUCTURE:
/var/log/myapp/
├── general/
│   ├── app_2024-01-15.log
│   ├── app_2024-01-16.log
│   └── app_2024-01-17.log
├── errors/
│   ├── errors_2024-01-15.log
│   └── errors_2024-01-16.log
└── audit/
    └── audit_2024-01.log
"""

# Create a logs directory structure
logs_dir = 'logs'
os.makedirs(logs_dir, exist_ok=True)

# Create a log file with today's date
today = datetime.now().strftime('%Y-%m-%d')
log_filename = os.path.join(logs_dir, f'app_{today}.log')

# Clean up existing handlers
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# Configure logging to organized location
logging.basicConfig(
    filename=log_filename,
    filemode='w',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logging.info(f"Logging to organized location: {log_filename}")
logging.info("This helps keep logs organized and manageable")

print(f"\nCreated log file: {log_filename}")
print("Directory structure:")
print(f"  {logs_dir}/")
print(f"    └── app_{today}.log")

"""
ADVANTAGES:
- Easy to find logs
- Can implement retention policies (delete old logs)
- Can backup entire directory
- Clear separation of different log types
"""

# ============================================================================
# PART 6: READING AND ANALYZING LOG FILES
# ============================================================================

print("\n" + "=" * 80)
print("PART 6: Programmatically Reading Log Files")
print("=" * 80)

"""
Once you have log files, you often need to analyze them.
Here are common operations:
"""

# First, create a sample log file with various messages
sample_log = 'sample_analysis.log'
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

logging.basicConfig(
    filename=sample_log,
    filemode='w',
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Generate sample log entries
logging.debug("Starting application")
logging.info("User alice logged in")
logging.info("Processing request from 192.168.1.100")
logging.warning("Database query took 5.2 seconds")
logging.error("Failed to connect to cache server")
logging.info("User bob logged in")
logging.error("Timeout connecting to API")
logging.critical("Out of disk space!")
logging.info("User alice logged out")

print("\nGenerated sample log. Now let's analyze it:\n")

# Analysis 1: Count messages by level
print("Analysis 1: Count messages by level")
print("-" * 60)
level_counts = {
    'DEBUG': 0,
    'INFO': 0,
    'WARNING': 0,
    'ERROR': 0,
    'CRITICAL': 0
}

with open(sample_log, 'r') as f:
    for line in f:
        for level in level_counts.keys():
            if level in line:
                level_counts[level] += 1
                break

for level, count in level_counts.items():
    print(f"{level}: {count}")

# Analysis 2: Extract all ERROR and CRITICAL messages
print("\nAnalysis 2: Extract all ERROR and CRITICAL messages")
print("-" * 60)
with open(sample_log, 'r') as f:
    for line in f:
        if 'ERROR' in line or 'CRITICAL' in line:
            print(line.strip())

# Analysis 3: Find specific patterns
print("\nAnalysis 3: Find all user login/logout events")
print("-" * 60)
with open(sample_log, 'r') as f:
    for line in f:
        if 'logged in' in line or 'logged out' in line:
            print(line.strip())

"""
COMMON LOG ANALYSIS TASKS:
1. Count errors over time
2. Find specific error patterns
3. Track user activities
4. Monitor performance metrics
5. Identify security events

TOOLS FOR LOG ANALYSIS:
- grep, awk, sed (command-line)
- Python scripts (as shown above)
- Log aggregation tools (ELK, Splunk, etc.)
"""

# ============================================================================
# PART 7: FILE PERMISSIONS AND SECURITY
# ============================================================================

print("\n" + "=" * 80)
print("PART 7: Log File Security Considerations")
print("=" * 80)

"""
SECURITY BEST PRACTICES:

1. FILE PERMISSIONS:
   - Log files may contain sensitive information
   - Set appropriate read/write permissions
   - On Unix: chmod 640 (owner read/write, group read)
   - On Windows: Use NTFS permissions

2. SENSITIVE DATA:
   - NEVER log passwords
   - NEVER log credit card numbers
   - NEVER log social security numbers
   - Be careful with API keys and tokens
   - Consider GDPR and privacy laws

3. LOG LOCATION:
   - Store logs in secure directory
   - Not in web-accessible directories
   - Use separate partition if possible (prevent disk full attacks)

4. LOG ROTATION:
   - Don't let log files grow indefinitely
   - Implement rotation policy
   - Archive old logs
   - Encrypt archived logs if necessary
"""

def safe_logging_example(username, password, credit_card):
    """
    Demonstrate safe vs unsafe logging practices.
    """
    # Create logger for this example
    safe_logger = logging.getLogger('security_example')
    safe_logger.setLevel(logging.INFO)
    
    # UNSAFE - Never do this!
    # safe_logger.info(f"User {username} logged in with password {password}")
    # safe_logger.info(f"Processing payment with card {credit_card}")
    
    # SAFE - Do this instead
    safe_logger.info(f"User {username} logged in successfully")
    safe_logger.info(f"Processing payment with card ending in {credit_card[-4:]}")
    
    return True

print("\nExample of safe logging practices:")
safe_logging_example("alice", "secret123", "1234567890123456")

"""
REMEMBER: Logs are often readable by many people (sysadmins, support staff, etc.)
Never log sensitive information that could be exploited if logs are compromised.
"""

# ============================================================================
# PART 8: PRACTICAL EXAMPLE - APPLICATION WITH FILE LOGGING
# ============================================================================

print("\n" + "=" * 80)
print("PART 8: Complete Application Example")
print("=" * 80)

"""
Let's build a complete example: a simple task manager that logs to file.
"""

class TaskManager:
    """
    A simple task manager with comprehensive file logging.
    """
    
    def __init__(self, log_file='task_manager.log'):
        """Initialize the task manager with logging."""
        # Set up logging
        self.logger = logging.getLogger('TaskManager')
        self.logger.setLevel(logging.DEBUG)
        
        # Clear any existing handlers
        self.logger.handlers.clear()
        
        # Create file handler
        file_handler = logging.FileHandler(log_file, mode='w')
        file_handler.setLevel(logging.DEBUG)
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(formatter)
        
        # Add handler to logger
        self.logger.addHandler(file_handler)
        
        # Initialize task list
        self.tasks = []
        self.logger.info("TaskManager initialized")
    
    def add_task(self, task):
        """Add a task to the list."""
        self.logger.debug(f"add_task() called with task='{task}'")
        
        if not task or not task.strip():
            self.logger.warning("Attempted to add empty task")
            return False
        
        self.tasks.append(task)
        self.logger.info(f"Task added: '{task}' (Total tasks: {len(self.tasks)})")
        return True
    
    def complete_task(self, task_index):
        """Mark a task as complete (remove it)."""
        self.logger.debug(f"complete_task() called with index={task_index}")
        
        if task_index < 0 or task_index >= len(self.tasks):
            self.logger.error(f"Invalid task index: {task_index} (valid range: 0-{len(self.tasks)-1})")
            return False
        
        task = self.tasks[task_index]
        del self.tasks[task_index]
        self.logger.info(f"Task completed and removed: '{task}'")
        return True
    
    def list_tasks(self):
        """List all tasks."""
        self.logger.debug("list_tasks() called")
        self.logger.info(f"Listing {len(self.tasks)} task(s)")
        return self.tasks

# Use the TaskManager
print("\nRunning TaskManager with file logging:\n")
manager = TaskManager('task_manager.log')

manager.add_task("Write logging tutorial")
manager.add_task("Review code")
manager.add_task("Deploy application")

tasks = manager.list_tasks()
print(f"Current tasks: {tasks}")

manager.complete_task(1)
manager.complete_task(5)  # Invalid index - will log error

print("\n" + "Log file contents:" + "\n" + "-" * 60)
with open('task_manager.log', 'r') as f:
    print(f.read())

# ============================================================================
# PART 9: KEY TAKEAWAYS
# ============================================================================

print("\n" + "=" * 80)
print("KEY TAKEAWAYS")
print("=" * 80)

"""
1. FILE LOGGING BASICS:
   - Use filename parameter in basicConfig()
   - Choose 'a' (append) for production, 'w' (write) for testing
   - Specify full path or use relative path carefully

2. FILE ORGANIZATION:
   - Use dedicated logs directory
   - Include dates in filenames
   - Separate different types of logs

3. SECURITY:
   - Set appropriate file permissions
   - Never log sensitive data (passwords, credit cards, etc.)
   - Store logs in secure locations

4. ANALYSIS:
   - Log files are text files - easy to analyze
   - Use scripts or tools to extract insights
   - Keep format consistent for parsing

5. PRODUCTION CONSIDERATIONS:
   - Use append mode to preserve history
   - Implement log rotation (covered later)
   - Monitor disk space
   - Archive old logs

NEXT STEPS:
- Learn about custom formatting (04_formatters.py)
- Explore different handlers (05_handlers.py)
- Study log rotation (08_rotating_logs.py)
"""

# Cleanup demonstration files
cleanup_files = [
    'app_log.txt', 'general.log', 'errors.log', 
    'sample_analysis.log', 'task_manager.log'
]
for f in cleanup_files:
    if os.path.exists(f):
        os.remove(f)

if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("TUTORIAL COMPLETE!")
    print("=" * 80)
    print("\nYou now understand:")
    print("✓ Why log to files instead of console")
    print("✓ Basic file logging configuration")
    print("✓ Append vs overwrite modes")
    print("✓ Organizing log files in directories")
    print("✓ Reading and analyzing log files")
    print("✓ Security considerations")
    print("\nNext: Study 04_formatters.py to learn about customizing log output!")
