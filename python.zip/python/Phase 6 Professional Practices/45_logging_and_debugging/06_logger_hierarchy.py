"""06_logger_hierarchy.py - Logger Hierarchy and Naming"""
import logging

print("LOGGER HIERARCHY TUTORIAL")
print("="*80)

# Root logger
root_logger = logging.getLogger()

# Named loggers - hierarchical
app_logger = logging.getLogger('myapp')
db_logger = logging.getLogger('myapp.database')
api_logger = logging.getLogger('myapp.api')

# Configure
logging.basicConfig(level=logging.DEBUG, format='%(name)-20s | %(levelname)s | %(message)s')

print("\nDemonstrating logger hierarchy:")
app_logger.info("App level message")
db_logger.info("Database level message")
api_logger.info("API level message")

print("\nKey concepts: Loggers form a hierarchy using dots in names")
print("myapp is parent of myapp.database and myapp.api")
print("Messages propagate up to parent loggers unless propagate=False")
