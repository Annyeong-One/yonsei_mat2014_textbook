"""07_configuration_methods.py - Configuration Methods"""
import logging
import logging.config

print("LOGGING CONFIGURATION METHODS")
print("="*80)

# Method 1: basicConfig
print("\nMethod 1: basicConfig()")
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)

# Method 2: Dictionary config
print("\nMethod 2: Dictionary configuration")
config = {
    'version': 1,
    'formatters': {
        'simple': {'format': '%(levelname)s - %(message)s'},
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
            'level': 'INFO',
        },
    },
    'root': {
        'level': 'DEBUG',
        'handlers': ['console']
    }
}

logging.config.dictConfig(config)
print("Dictionary configuration allows complex setups")
