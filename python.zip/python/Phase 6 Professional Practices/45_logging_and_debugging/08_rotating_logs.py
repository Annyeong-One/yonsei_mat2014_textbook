"""08_rotating_logs.py - Rotating File Handlers"""
import logging
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
import os

print("ROTATING LOG FILES")
print("="*80)

# Create logger
logger = logging.getLogger('rotating')
logger.setLevel(logging.DEBUG)

# Rotating by size
rotating_handler = RotatingFileHandler(
    'app_rotating.log',
    maxBytes=1024,  # 1 KB for demo
    backupCount=3   # Keep 3 backup files
)
rotating_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
logger.addHandler(rotating_handler)

print("\nRotatingFileHandler rotates when file reaches maxBytes")
for i in range(100):
    logger.info(f"Log message number {i}")

print(f"Log files created: {[f for f in os.listdir('.') if 'app_rotating' in f]}")

# Cleanup
logger.handlers.clear()
for f in os.listdir('.'):
    if 'app_rotating' in f:
        os.remove(f)

print("\nTimedRotatingFileHandler rotates based on time (when='midnight', 'H', etc.)")
