"""09_filters.py - Custom Filters"""
import logging

print("LOGGING FILTERS")
print("="*80)

class LevelFilter(logging.Filter):
    """Only allow specific level."""
    def __init__(self, level):
        super().__init__()
        self.level = level
    
    def filter(self, record):
        return record.levelno == self.level

# Setup
logger = logging.getLogger('filtered')
logger.setLevel(logging.DEBUG)
handler = logging.StreamHandler()
handler.addFilter(LevelFilter(logging.WARNING))
logger.addHandler(handler)

print("\nWith filter that only allows WARNING:")
logger.debug("Debug - won't show")
logger.info("Info - won't show")
logger.warning("Warning - will show!")
logger.error("Error - won't show")

print("\nFilters provide fine-grained control over which records are processed")
