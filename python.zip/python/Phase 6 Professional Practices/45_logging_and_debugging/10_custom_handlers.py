"""10_custom_handlers.py - Custom Handlers"""
import logging

print("CUSTOM HANDLERS")
print("="*80)

class ListHandler(logging.Handler):
    """Custom handler that stores logs in a list."""
    def __init__(self):
        super().__init__()
        self.logs = []
    
    def emit(self, record):
        log_entry = self.format(record)
        self.logs.append(log_entry)

# Use custom handler
logger = logging.getLogger('custom')
logger.setLevel(logging.DEBUG)
list_handler = ListHandler()
list_handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
logger.addHandler(list_handler)

logger.info("First message")
logger.warning("Second message")
logger.error("Third message")

print("\nLogs stored in list:")
for log in list_handler.logs:
    print(f"  - {log}")

print("\nCustom handlers allow logging to any destination (database, API, etc.)")
