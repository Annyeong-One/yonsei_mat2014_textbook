"""11_structured_logging.py - JSON/Structured Logging"""
import logging
import json
from datetime import datetime

print("STRUCTURED LOGGING")
print("="*80)

class JSONFormatter(logging.Formatter):
    """Format logs as JSON."""
    def format(self, record):
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        return json.dumps(log_data)

logger = logging.getLogger('json')
logger.setLevel(logging.INFO)
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logger.addHandler(handler)

print("\nJSON formatted logs:")
logger.info("User logged in", extra={'user_id': 123})
logger.error("Database connection failed", extra={'database': 'users_db'})

print("\nStructured logs are machine-readable and ideal for log aggregation tools")
