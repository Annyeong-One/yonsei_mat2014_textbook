"""12_logging_best_practices.py - Production Best Practices"""
import logging
import sys

print("LOGGING BEST PRACTICES")
print("="*80)

# Best Practice 1: Use __name__ for logger names
logger = logging.getLogger(__name__)

# Best Practice 2: Log exceptions with exc_info
try:
    1 / 0
except ZeroDivisionError:
    logger.error("Math error occurred", exc_info=True)

# Best Practice 3: Use lazy formatting
# GOOD: logger.debug("User %s logged in", username)
# BAD: logger.debug(f"User {username} logged in")  # String formatted even if DEBUG disabled

# Best Practice 4: Structure your application
class Application:
    def __init__(self):
        self.logger = logging.getLogger('app')
        self.setup_logging()
    
    def setup_logging(self):
        self.logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            '%(asctime)s | %(name)s | %(levelname)-8s | %(message)s'
        )
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.info("Logging configured")

print("\nBest Practices Summary:")
print("1. Use __name__ for logger names")
print("2. Log exceptions with exc_info=True")
print("3. Use lazy % formatting")
print("4. Never log passwords or sensitive data")
print("5. Set appropriate levels for environments")
print("6. Use handlers for different destinations")
print("7. Implement log rotation")
print("8. Include context (user_id, request_id, etc.)")
