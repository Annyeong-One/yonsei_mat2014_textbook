# Python Logging Tutorial - Complete Educational Package

## Course Overview
This comprehensive package teaches Python's logging module from fundamentals to advanced techniques, designed for undergraduate computer science students in a one-year Python course.

## Learning Objectives
By completing this module, students will:
- Understand the importance of logging in software development
- Master Python's built-in logging module
- Configure logging for different use cases
- Implement custom logging solutions
- Apply logging best practices in real-world applications

## Package Structure

### Beginner Level (Week 1-2)
1. **01_basic_logging.py** - Introduction to logging basics
   - Print vs logging comparison
   - Basic logging levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)
   - Simple logging configuration
   - Basic logging methods

2. **02_logging_levels.py** - Understanding logging levels in depth
   - Detailed explanation of each level
   - When to use each level
   - Setting log levels
   - Level hierarchy and filtering

3. **03_logging_to_file.py** - File-based logging
   - Writing logs to files
   - Basic file configuration
   - File modes and permissions
   - Reading and analyzing log files

### Intermediate Level (Week 3-4)
4. **04_formatters.py** - Customizing log message format
   - LogRecord attributes
   - Custom format strings
   - Time formatting
   - Creating readable log outputs

5. **05_handlers.py** - Working with different handlers
   - FileHandler, StreamHandler
   - Multiple handlers
   - Handler-specific configurations
   - Directing logs to different destinations

6. **06_logger_hierarchy.py** - Understanding logger organization
   - Named loggers
   - Logger hierarchy and inheritance
   - Parent-child relationships
   - Best practices for logger naming

7. **07_configuration_methods.py** - Different ways to configure logging
   - basicConfig()
   - Dictionary-based configuration
   - File-based configuration (INI, YAML, JSON)
   - Programmatic configuration

### Advanced Level (Week 5-6)
8. **08_rotating_logs.py** - Managing log file sizes and rotation
   - RotatingFileHandler
   - TimedRotatingFileHandler
   - Log archiving strategies
   - Disk space management

9. **09_filters.py** - Advanced filtering techniques
   - Creating custom filters
   - Context-based filtering
   - Performance considerations
   - Real-world filtering scenarios

10. **10_custom_handlers.py** - Building custom handlers
    - Handler base class
    - Creating specialized handlers
    - Email handlers
    - Database handlers
    - Web service handlers

11. **11_structured_logging.py** - Modern structured logging
    - JSON logging
    - Structured data in logs
    - Machine-readable logs
    - Integration with log aggregation tools

12. **12_logging_best_practices.py** - Production-ready logging
    - Exception logging with tracebacks
    - Performance considerations
    - Security concerns
    - Thread safety
    - Complete application example

### Exercise Files
- **exercise_01_basics.py** - Beginner exercises
- **exercise_02_intermediate.py** - Intermediate exercises
- **exercise_03_advanced.py** - Advanced exercises
- **solutions/** directory - Complete solutions with explanations

## How to Use This Package

### For Students:
1. Start with beginner files (01-03) and work through them sequentially
2. Run each file and observe the output
3. Experiment by modifying parameters and configurations
4. Complete exercises after finishing each difficulty level
5. Compare your solutions with provided solutions

### For Instructors:
1. Each file is heavily commented for classroom presentation
2. Files can be used as live coding demonstrations
3. Exercise files provide assessment opportunities
4. Solutions include detailed explanations for review sessions
5. Files are modular and can be taught in any order after basics

## Prerequisites
- Python 3.7 or higher
- Basic understanding of Python syntax
- Familiarity with file I/O operations
- Understanding of functions and modules

## Running the Examples
```bash
# Run any tutorial file
python 01_basic_logging.py

# Run exercises
python exercise_01_basics.py

# View solutions
python solutions/solution_01_basics.py
```

## Additional Resources
- Python Official Logging Documentation: https://docs.python.org/3/library/logging.html
- Logging HOWTO: https://docs.python.org/3/howto/logging.html
- Logging Cookbook: https://docs.python.org/3/howto/logging-cookbook.html

## Course Timeline Suggestion
- Week 1: Files 01-03 + Exercise 1
- Week 2: Files 04-05 (review and practice)
- Week 3: Files 06-07 + Exercise 2
- Week 4: Review and mini-project
- Week 5: Files 08-10
- Week 6: Files 11-12 + Exercise 3 + Final project

## Assessment Suggestions
1. Code review of exercise solutions
2. Small project: Add logging to existing Python application
3. Written exam on logging concepts and best practices
4. Practical exam: Debug application using logging

## Common Student Questions Addressed
- Why use logging instead of print()?
- Which logging level should I use?
- How do I log to both console and file?
- How do I format timestamps?
- How do I capture exceptions with full tracebacks?
- How do I prevent log files from growing too large?

## License
Educational use - Free for academic institutions

## Author Notes
Each file is designed to be self-contained with extensive comments explaining not just "how" but "why". Encourage students to experiment and break things - that's how they learn best!
