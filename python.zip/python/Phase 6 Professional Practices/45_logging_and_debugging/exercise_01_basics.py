"""
exercise_01_basics.py - Beginner Level Exercises

Complete these exercises to practice basic logging concepts.
Run this file to check your solutions.
"""

import logging

print("="*80)
print("EXERCISE 1: Basic Logging Setup")
print("="*80)

# TODO: Configure logging to show DEBUG level and above
# TODO: Use format: '%(levelname)s - %(message)s'

# Your code here:


# Test your configuration:
logging.debug("This is a debug message")
logging.info("This is an info message")
logging.warning("This is a warning message")

print("\n" + "="*80)
print("EXERCISE 2: Function with Logging")
print("="*80)

# TODO: Create a function called 'calculate_average' that:
# 1. Takes a list of numbers as input
# 2. Logs a DEBUG message with the input list
# 3. Calculates the average
# 4. Logs an INFO message with the result
# 5. If list is empty, log an ERROR and return None

# Your function here:
def calculate_average(numbers):
    pass  # Replace with your implementation


# Test your function:
print("\nTest 1: Normal list")
result = calculate_average([10, 20, 30, 40, 50])
print(f"Result: {result}")

print("\nTest 2: Empty list")
result = calculate_average([])
print(f"Result: {result}")

print("\n" + "="*80)
print("EXERCISE 3: Logging Levels")
print("="*80)

# TODO: For each scenario, determine the appropriate logging level
# and log an appropriate message

# Scenario 1: User successfully logged in
# Your code:

# Scenario 2: Configuration file not found, using defaults
# Your code:

# Scenario 3: Database connection failed
# Your code:

# Scenario 4: Loop iteration counter for debugging
# Your code:

print("\n" + "="*80)
print("Exercises complete! Check solutions/solution_01_basics.py")
print("="*80)
