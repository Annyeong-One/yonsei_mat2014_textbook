"""
exercise_02_intermediate.py - Intermediate Level Exercises

Practice handlers, formatters, and file logging.
"""

import logging
import os

print("="*80)
print("EXERCISE 4: Multiple Handlers")
print("="*80)

# TODO: Create a logger named 'myapp' that:
# 1. Has a console handler showing INFO and above
# 2. Has a file handler 'app.log' showing DEBUG and above
# 3. Console uses simple format: '%(levelname)s - %(message)s'
# 4. File uses detailed format: '%(asctime)s - %(levelname)s - %(message)s'

# Your code here:


# Test your logger:
# logger.debug("Debug message")
# logger.info("Info message")
# logger.warning("Warning message")

print("\n" + "="*80)
print("EXERCISE 5: Custom Formatter")
print("="*80)

# TODO: Create a custom formatter that:
# 1. Adds '[APP]' prefix to all messages
# 2. Uses different colors for different levels (optional)
# 3. Includes timestamp in format: '%Y-%m-%d %H:%M:%S'

# Your code here:


print("\n" + "="*80)
print("EXERCISE 6: Error-Only File")
print("="*80)

# TODO: Create a logging setup where:
# 1. All logs go to 'all.log'
# 2. Only ERROR and CRITICAL go to 'errors.log'
# 3. Console shows INFO and above

# Your code here:


print("\nCheck solutions/solution_02_intermediate.py for answers")
