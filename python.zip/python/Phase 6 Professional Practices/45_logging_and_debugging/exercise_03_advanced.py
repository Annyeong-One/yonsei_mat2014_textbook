"""
exercise_03_advanced.py - Advanced Level Exercises

Practice rotation, filters, and custom handlers.
"""

import logging
from logging.handlers import RotatingFileHandler

print("="*80)
print("EXERCISE 7: Rotating File Handler")
print("="*80)

# TODO: Create a RotatingFileHandler that:
# 1. Rotates when file reaches 10KB
# 2. Keeps 5 backup files
# 3. Uses comprehensive format with timestamp, level, and message

# Your code here:


print("\n" + "="*80)
print("EXERCISE 8: Custom Filter")
print("="*80)

# TODO: Create a filter that:
# 1. Only allows messages containing the word "important"
# 2. Apply it to a handler

# Your code here:


print("\n" + "="*80)
print("EXERCISE 9: Custom Handler")
print("="*80)

# TODO: Create a custom handler that:
# 1. Counts how many messages of each level were logged
# 2. Provides a method to print statistics

# Your code here:


print("\n" + "="*80)
print("EXERCISE 10: Complete Application")
print("="*80)

# TODO: Design a complete logging system for a web application with:
# 1. Console: INFO+ with simple format
# 2. General log: DEBUG+ with detailed format, rotating at 1MB
# 3. Error log: ERROR+ with very detailed format
# 4. Access log: INFO+ with timestamp and message only
# 5. All with appropriate formatters

# Your code here:


print("\nCheck solutions/solution_03_advanced.py for answers")
