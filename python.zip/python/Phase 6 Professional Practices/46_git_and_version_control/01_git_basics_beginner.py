"""
Git & Version Control - Beginner Level
=======================================

This module introduces fundamental Git concepts and basic operations using Python's
subprocess module to execute Git commands. Students will learn about version control
basics, repository initialization, and simple Git workflows.

Learning Objectives:
- Understand what version control is and why it's important
- Learn to initialize a Git repository
- Master basic Git commands (add, commit, status, log)
- Understand the staging area concept
- Learn to track file changes over time

Prerequisites:
- Git must be installed on your system
- Basic Python knowledge (functions, subprocess)
- Understanding of file systems

Author: Educational Materials for Undergraduate Python Course
Level: Beginner
"""

import subprocess
import os
import tempfile
import shutil
from pathlib import Path
from typing import Tuple, Optional


# =============================================================================
# SECTION 1: Understanding Version Control and Git Basics
# =============================================================================

def explain_version_control():
    """
    Explains the concept of version control systems.
    
    Version Control System (VCS):
    - A system that records changes to files over time
    - Allows you to recall specific versions later
    - Enables collaboration among multiple developers
    - Provides backup and history of your work
    
    Why Use Version Control?
    1. History: Track who changed what and when
    2. Collaboration: Multiple people can work on same project
    3. Branching: Experiment without affecting main code
    4. Backup: Distributed nature provides redundancy
    5. Accountability: Every change is attributed to someone
    
    Types of VCS:
    - Local: Database on local computer (RCS)
    - Centralized: Single server contains all versions (SVN, CVS)
    - Distributed: Every developer has full repository copy (Git, Mercurial)
    """
    print("=" * 70)
    print("WHAT IS VERSION CONTROL?")
    print("=" * 70)
    print("""
    Version control is like a time machine for your code:
    
    WITHOUT Version Control:
    - project_final.py
    - project_final_v2.py
    - project_final_v2_actualfinal.py
    - project_final_v2_actualfinal_FIXED.py
    - project_final_v2_actualfinal_FIXED_really_final.py
    
    WITH Version Control (Git):
    - project.py (with complete history of all changes)
    
    Benefits:
    ✓ Track every change made to your code
    ✓ Know who made each change and why
    ✓ Revert to any previous version
    ✓ Experiment safely with new features
    ✓ Collaborate without overwriting others' work
    """)
    print("=" * 70)


def demonstrate_git_workflow_concept():
    """
    Demonstrates the conceptual Git workflow with clear explanations.
    
    Git Workflow (Three Trees):
    1. Working Directory: Your actual files where you make changes
    2. Staging Area (Index): A preparation area before committing
    3. Repository (.git): Where Git stores all committed snapshots
    
    The Three States of Files:
    - Modified: Changed but not staged
    - Staged: Marked to go in next commit
    - Committed: Safely stored in repository
    
    Basic Workflow:
    1. Modify files in working directory
    2. Stage files (add to staging area)
    3. Commit staged files (create snapshot in repository)
    """
    print("\n" + "=" * 70)
    print("GIT WORKFLOW CONCEPT")
    print("=" * 70)
    print("""
    The Three-Stage Workflow:
    
    ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
    │    Working      │       │    Staging      │       │   Repository    │
    │   Directory     │──────▶│     Area        │──────▶│    (.git)       │
    │                 │ add   │    (Index)      │commit │                 │
    └─────────────────┘       └─────────────────┘       └─────────────────┘
         (modify)                 (prepare)                 (snapshot)
    
    Example:
    1. You edit file.py in working directory    [Modified]
    2. You run 'git add file.py'                [Staged]
    3. You run 'git commit -m "message"'        [Committed]
    
    Why Staging Area?
    - Review changes before committing
    - Commit only specific changes (granular control)
    - Organize related changes together
    """)
    print("=" * 70)


# =============================================================================
# SECTION 2: Git Repository Initialization
# =============================================================================

def git_init_repository(repo_path: str) -> bool:
    """
    Initialize a new Git repository in the specified directory.
    
    What happens when you run 'git init':
    1. Creates a .git subdirectory (repository database)
    2. Contains all Git metadata and object database
    3. Your working directory remains unchanged
    4. Repository is now ready to track files
    
    Args:
        repo_path: Path where repository should be initialized
        
    Returns:
        bool: True if successful, False otherwise
        
    Git Command Equivalent:
        git init
        
    Technical Details:
        The .git directory contains:
        - objects/: Git's object database (commits, trees, blobs)
        - refs/: References to commits (branches, tags)
        - HEAD: Points to current branch
        - config: Repository configuration
        - hooks/: Scripts for automation
    """
    try:
        # Ensure the directory exists
        os.makedirs(repo_path, exist_ok=True)
        
        # Run git init command
        # subprocess.run() executes shell commands from Python
        # check=True raises exception if command fails
        # capture_output=True captures stdout and stderr
        # text=True returns output as string (not bytes)
        result = subprocess.run(
            ['git', 'init'],  # Command and arguments as list
            cwd=repo_path,    # Change to this directory before running
            check=True,        # Raise exception on non-zero exit
            capture_output=True,  # Capture standard output and error
            text=True         # Return strings instead of bytes
        )
        
        print(f"✓ Repository initialized at: {repo_path}")
        print(f"  Output: {result.stdout.strip()}")
        
        # Verify .git directory was created
        git_dir = Path(repo_path) / '.git'
        if git_dir.exists() and git_dir.is_dir():
            print(f"✓ .git directory created successfully")
            return True
        else:
            print(f"✗ .git directory not found")
            return False
            
    except subprocess.CalledProcessError as e:
        # This exception is raised when command returns non-zero exit code
        print(f"✗ Git initialization failed: {e.stderr}")
        return False
    except FileNotFoundError:
        # This means 'git' command is not found in system PATH
        print("✗ Git is not installed or not in PATH")
        return False
    except Exception as e:
        # Catch any other unexpected errors
        print(f"✗ Unexpected error: {str(e)}")
        return False


def git_config_user(repo_path: str, name: str, email: str) -> bool:
    """
    Configure Git user information for commits.
    
    Every commit in Git records:
    - Author name
    - Author email
    - Timestamp
    
    This information identifies who made each change.
    
    Configuration Levels:
    1. System: /etc/gitconfig (all users)
    2. Global: ~/.gitconfig (current user)
    3. Local: .git/config (current repository only)
    
    Args:
        repo_path: Path to repository
        name: User's full name
        email: User's email address
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git config user.name "Your Name"
        git config user.email "your.email@example.com"
    """
    try:
        # Configure user name
        # --local flag: Configuration applies to this repository only
        subprocess.run(
            ['git', 'config', '--local', 'user.name', name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        # Configure user email
        subprocess.run(
            ['git', 'config', '--local', 'user.email', email],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Git user configured:")
        print(f"  Name: {name}")
        print(f"  Email: {email}")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Configuration failed: {e.stderr}")
        return False


# =============================================================================
# SECTION 3: Basic Git Operations - Status, Add, Commit
# =============================================================================

def git_status(repo_path: str) -> Tuple[str, bool]:
    """
    Check the status of the Git repository.
    
    'git status' shows:
    - Current branch name
    - Files in staging area (to be committed)
    - Files modified but not staged
    - Untracked files (not under version control)
    
    File States:
    1. Untracked: Git doesn't know about the file
    2. Unmodified: File is tracked, no changes since last commit
    3. Modified: File changed but not staged
    4. Staged: File ready to be committed
    
    Args:
        repo_path: Path to repository
        
    Returns:
        Tuple of (status output string, success boolean)
        
    Git Command Equivalent:
        git status
        
    Understanding Output:
        "Changes to be committed" → Staged files (green)
        "Changes not staged" → Modified but not staged (red)
        "Untracked files" → New files Git doesn't track (red)
    """
    try:
        result = subprocess.run(
            ['git', 'status'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("GIT STATUS")
        print("=" * 70)
        print(result.stdout)
        print("=" * 70)
        
        return result.stdout, True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Git status failed: {e.stderr}")
        return "", False


def git_add_file(repo_path: str, filename: str) -> bool:
    """
    Add a file to the staging area.
    
    Staging Process:
    1. Git takes a snapshot of the file's current state
    2. Stores snapshot in staging area (index)
    3. File is now ready to be committed
    
    Why Stage Files?
    - Granular control: Commit only specific changes
    - Review: Check what you're about to commit
    - Organization: Group related changes together
    
    Args:
        repo_path: Path to repository
        filename: Name of file to add (relative to repo root)
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git add filename
        
    Common Patterns:
        git add file.py           # Add specific file
        git add *.py              # Add all Python files
        git add .                 # Add all files in directory
        git add -A                # Add all changes in repository
    """
    try:
        result = subprocess.run(
            ['git', 'add', filename],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Added '{filename}' to staging area")
        
        # Note: git add produces no output on success
        # So we don't print result.stdout here
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to add '{filename}': {e.stderr}")
        return False


def git_add_all(repo_path: str) -> bool:
    """
    Add all changes to the staging area.
    
    'git add -A' stages:
    - New files (untracked)
    - Modified files
    - Deleted files
    
    Difference between git add variations:
    - 'git add .'  : Stages all in current directory and subdirectories
    - 'git add -A' : Stages all changes in entire repository
    - 'git add -u' : Stages only modified and deleted (not new files)
    
    Args:
        repo_path: Path to repository
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git add -A
        
    Use Case:
        When you want to stage all changes at once before committing
    """
    try:
        subprocess.run(
            ['git', 'add', '-A'],  # -A stages everything
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("✓ All changes added to staging area")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to add all changes: {e.stderr}")
        return False


def git_commit(repo_path: str, message: str) -> Optional[str]:
    """
    Commit staged changes to the repository.
    
    What is a Commit?
    - A snapshot of your entire project at a specific point in time
    - Contains: author, timestamp, message, parent commit(s)
    - Identified by unique SHA-1 hash (40 characters)
    - Immutable once created
    
    Commit Message Best Practices:
    1. Use present tense ("Add feature" not "Added feature")
    2. Be concise but descriptive
    3. First line: summary (50 chars max)
    4. Blank line, then detailed description if needed
    5. Reference issue/ticket numbers if applicable
    
    Args:
        repo_path: Path to repository
        message: Commit message describing the changes
        
    Returns:
        Optional[str]: Commit hash if successful, None otherwise
        
    Git Command Equivalent:
        git commit -m "message"
        
    Technical Details:
        - Only staged files are included in commit
        - Creates a new commit object in .git/objects/
        - Updates branch reference to point to new commit
        - Working directory remains unchanged
    """
    try:
        result = subprocess.run(
            ['git', 'commit', '-m', message],  # -m flag: inline message
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        # Extract commit hash from output
        # Output format: [branch hash] message
        output = result.stdout.strip()
        print(f"✓ Commit successful:")
        print(f"  {output}")
        
        # Get the commit hash from the most recent commit
        commit_hash = git_get_last_commit_hash(repo_path)
        
        return commit_hash
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Commit failed: {e.stderr}")
        return None


def git_get_last_commit_hash(repo_path: str) -> Optional[str]:
    """
    Get the hash of the most recent commit.
    
    SHA-1 Hash:
    - Unique identifier for each commit
    - 40 hexadecimal characters
    - Often abbreviated to first 7 characters
    - Ensures integrity of repository history
    
    Args:
        repo_path: Path to repository
        
    Returns:
        Optional[str]: Full commit hash or None if no commits
        
    Git Command Equivalent:
        git rev-parse HEAD
        
    HEAD Reference:
        - HEAD points to the current branch
        - Current branch points to latest commit
        - Therefore, HEAD represents current commit
    """
    try:
        result = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],  # Get commit hash that HEAD points to
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        commit_hash = result.stdout.strip()
        return commit_hash
        
    except subprocess.CalledProcessError:
        # No commits yet in repository
        return None


# =============================================================================
# SECTION 4: Viewing History and Changes
# =============================================================================

def git_log_oneline(repo_path: str, max_count: int = 10) -> bool:
    """
    Display commit history in compact format.
    
    Git Log Information:
    - Commit hash (abbreviated)
    - Commit message
    - Author and timestamp (in other formats)
    - Branch and tag information
    
    Log Formats:
    - --oneline: Compact (hash + message)
    - --stat: With file change statistics
    - --patch: With full diff of changes
    - --graph: Visual branch structure
    
    Args:
        repo_path: Path to repository
        max_count: Maximum number of commits to show
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git log --oneline -n 10
        
    Reading the Output:
        abc1234 Add user authentication feature
        def5678 Fix login bug
        ghi9012 Update README
        
        Each line shows:
        - First 7 chars of commit hash
        - Commit message
    """
    try:
        result = subprocess.run(
            [
                'git', 'log',
                '--oneline',              # Compact format
                f'-n', str(max_count),    # Limit number of commits
                '--decorate'              # Show branch/tag names
            ],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print(f"COMMIT HISTORY (Last {max_count} commits)")
        print("=" * 70)
        
        if result.stdout.strip():
            print(result.stdout)
        else:
            print("No commits yet.")
            
        print("=" * 70)
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Git log failed: {e.stderr}")
        return False


def git_log_detailed(repo_path: str, max_count: int = 5) -> bool:
    """
    Display detailed commit history with full information.
    
    Detailed Log Shows:
    - Full commit hash (40 characters)
    - Author name and email
    - Commit date and time
    - Full commit message
    - Changed files (with --stat flag)
    
    Args:
        repo_path: Path to repository
        max_count: Maximum number of commits to show
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git log -n 5
    """
    try:
        result = subprocess.run(
            ['git', 'log', f'-n', str(max_count)],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print(f"DETAILED COMMIT HISTORY (Last {max_count} commits)")
        print("=" * 70)
        
        if result.stdout.strip():
            print(result.stdout)
        else:
            print("No commits yet.")
            
        print("=" * 70)
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Git log failed: {e.stderr}")
        return False


def git_diff_unstaged(repo_path: str) -> bool:
    """
    Show differences in files that are modified but not staged.
    
    Understanding Git Diff:
    - Shows line-by-line changes in files
    - '+' prefix: lines added
    - '-' prefix: lines removed
    - Context lines (no prefix): unchanged for reference
    
    Diff Output Format:
        diff --git a/file.py b/file.py
        --- a/file.py    (old version)
        +++ b/file.py    (new version)
        @@ -10,7 +10,8 @@  (line numbers and context)
        -removed line
        +added line
         unchanged line
    
    Args:
        repo_path: Path to repository
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git diff
        
    Note:
        This only shows unstaged changes.
        Use 'git diff --staged' to see staged changes.
    """
    try:
        result = subprocess.run(
            ['git', 'diff'],  # Show unstaged changes
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("UNSTAGED CHANGES (git diff)")
        print("=" * 70)
        
        if result.stdout.strip():
            print(result.stdout)
        else:
            print("No unstaged changes.")
            
        print("=" * 70)
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Git diff failed: {e.stderr}")
        return False


def git_diff_staged(repo_path: str) -> bool:
    """
    Show differences in files that are staged for commit.
    
    Staged vs Unstaged Differences:
    - Staged: Changes you've added with 'git add'
    - Unstaged: Changes in working directory not yet added
    
    Use Case:
        Review exactly what you're about to commit before committing
    
    Args:
        repo_path: Path to repository
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git diff --staged
        (or git diff --cached)
    """
    try:
        result = subprocess.run(
            ['git', 'diff', '--staged'],  # Show staged changes only
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("STAGED CHANGES (git diff --staged)")
        print("=" * 70)
        
        if result.stdout.strip():
            print(result.stdout)
        else:
            print("No staged changes.")
            
        print("=" * 70)
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Git diff failed: {e.stderr}")
        return False


# =============================================================================
# SECTION 5: Complete Beginner Workflow Demonstration
# =============================================================================

def demonstrate_basic_workflow():
    """
    Demonstrates a complete basic Git workflow.
    
    Workflow Steps:
    1. Create a new project directory
    2. Initialize Git repository
    3. Configure user information
    4. Create some files
    5. Check status
    6. Stage files
    7. Commit changes
    8. View history
    9. Make modifications
    10. View differences
    11. Commit again
    
    This function creates a temporary repository to demonstrate
    all basic Git operations in a safe, isolated environment.
    """
    print("\n" + "=" * 70)
    print("COMPLETE BASIC GIT WORKFLOW DEMONSTRATION")
    print("=" * 70)
    
    # Create temporary directory for demonstration
    temp_dir = tempfile.mkdtemp(prefix='git_demo_')
    print(f"\nCreated temporary directory: {temp_dir}")
    
    try:
        # Step 1: Initialize repository
        print("\n--- Step 1: Initialize Git Repository ---")
        git_init_repository(temp_dir)
        
        # Step 2: Configure user
        print("\n--- Step 2: Configure User Information ---")
        git_config_user(temp_dir, "Student Name", "student@university.edu")
        
        # Step 3: Create a sample file
        print("\n--- Step 3: Create Sample Files ---")
        sample_file = Path(temp_dir) / "hello.py"
        with open(sample_file, 'w') as f:
            f.write('print("Hello, Git!")\n')
        print(f"✓ Created {sample_file.name}")
        
        readme_file = Path(temp_dir) / "README.md"
        with open(readme_file, 'w') as f:
            f.write('# My First Git Project\n\nThis is a demo.\n')
        print(f"✓ Created {readme_file.name}")
        
        # Step 4: Check status (files are untracked)
        print("\n--- Step 4: Check Status (Untracked Files) ---")
        git_status(temp_dir)
        
        # Step 5: Add files to staging area
        print("\n--- Step 5: Add Files to Staging Area ---")
        git_add_file(temp_dir, "hello.py")
        git_add_file(temp_dir, "README.md")
        
        # Step 6: Check status (files are staged)
        print("\n--- Step 6: Check Status (Files Staged) ---")
        git_status(temp_dir)
        
        # Step 7: Commit changes
        print("\n--- Step 7: Commit Changes ---")
        commit_hash = git_commit(temp_dir, "Initial commit: Add hello.py and README")
        print(f"  Commit Hash: {commit_hash}")
        
        # Step 8: View history
        print("\n--- Step 8: View Commit History ---")
        git_log_oneline(temp_dir, max_count=5)
        
        # Step 9: Modify a file
        print("\n--- Step 9: Modify a File ---")
        with open(sample_file, 'a') as f:
            f.write('\nprint("Version control is awesome!")\n')
        print(f"✓ Modified {sample_file.name}")
        
        # Step 10: Check status (file is modified but not staged)
        print("\n--- Step 10: Check Status (Modified File) ---")
        git_status(temp_dir)
        
        # Step 11: View unstaged changes
        print("\n--- Step 11: View Unstaged Changes ---")
        git_diff_unstaged(temp_dir)
        
        # Step 12: Stage and commit the change
        print("\n--- Step 12: Stage and Commit the Change ---")
        git_add_file(temp_dir, "hello.py")
        git_commit(temp_dir, "Add enthusiastic message about version control")
        
        # Step 13: View updated history
        print("\n--- Step 13: View Updated History ---")
        git_log_detailed(temp_dir, max_count=3)
        
        # Step 14: Final status (clean working directory)
        print("\n--- Step 14: Final Status (Clean) ---")
        git_status(temp_dir)
        
        print("\n" + "=" * 70)
        print("WORKFLOW DEMONSTRATION COMPLETE")
        print("=" * 70)
        print("""
        Summary of what we did:
        1. ✓ Initialized a Git repository
        2. ✓ Configured user information
        3. ✓ Created files in working directory
        4. ✓ Staged files with 'git add'
        5. ✓ Committed files with 'git commit'
        6. ✓ Viewed commit history with 'git log'
        7. ✓ Modified files
        8. ✓ Viewed changes with 'git diff'
        9. ✓ Committed changes
        10. ✓ Verified clean working directory
        
        Key Takeaways:
        • Git tracks file changes over time
        • Staging area allows selective commits
        • Each commit is a snapshot of your project
        • Git log provides complete history
        • Git diff shows what changed
        """)
        
    finally:
        # Cleanup: Remove temporary directory
        print(f"\nCleaning up temporary directory: {temp_dir}")
        shutil.rmtree(temp_dir, ignore_errors=True)
        print("✓ Cleanup complete")


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function demonstrating all beginner-level Git concepts.
    
    This function:
    1. Explains version control concepts
    2. Demonstrates Git workflow
    3. Runs a complete practical example
    
    For Students:
        Run this file to see Git basics in action.
        Study the functions to understand how Git commands work.
        Experiment by modifying the code and creating your own examples.
    """
    print("\n" + "=" * 70)
    print("GIT & VERSION CONTROL - BEGINNER TUTORIAL")
    print("=" * 70)
    
    # Theoretical foundation
    explain_version_control()
    input("\nPress Enter to continue to workflow concepts...")
    
    demonstrate_git_workflow_concept()
    input("\nPress Enter to start practical demonstration...")
    
    # Practical demonstration
    demonstrate_basic_workflow()
    
    print("\n" + "=" * 70)
    print("TUTORIAL COMPLETE!")
    print("=" * 70)
    print("""
    Next Steps:
    1. Install Git on your computer if you haven't already
    2. Open a terminal and try these commands yourself
    3. Create your own repository and practice
    4. Move on to intermediate topics (branching, remotes)
    
    Helpful Resources:
    - Official Git Documentation: https://git-scm.com/doc
    - Git Book: https://git-scm.com/book/en/v2
    - Interactive Tutorial: https://learngitbranching.js.org/
    
    Practice Exercises:
    - See exercises_01_basics.py for hands-on practice
    """)


if __name__ == "__main__":
    main()
