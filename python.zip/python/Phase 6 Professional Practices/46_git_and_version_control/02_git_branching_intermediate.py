"""
Git & Version Control - Intermediate Level: Branching
======================================================

This module covers Git branching concepts and operations. Students will learn
how to create, switch, merge, and delete branches, understanding how branches
enable parallel development and experimentation.

Learning Objectives:
- Understand what branches are and why they're essential
- Learn to create and switch between branches
- Master merging strategies (fast-forward and three-way)
- Handle merge conflicts
- Understand branch management best practices

Prerequisites:
- Completion of 01_git_basics_beginner.py
- Understanding of commits and Git workflow
- Familiarity with Git commands (add, commit, status)

Author: Educational Materials for Undergraduate Python Course
Level: Intermediate
"""

import subprocess
import os
import tempfile
import shutil
from pathlib import Path
from typing import List, Optional, Tuple


# =============================================================================
# SECTION 1: Understanding Branches
# =============================================================================

def explain_branches():
    """
    Explains the concept of Git branches.
    
    What is a Branch?
    - A lightweight movable pointer to a commit
    - Represents an independent line of development
    - Allows multiple features to be developed simultaneously
    - Default branch is usually called 'main' or 'master'
    
    Why Use Branches?
    1. Isolation: Work on features without affecting main code
    2. Experimentation: Try ideas safely
    3. Collaboration: Multiple developers work in parallel
    4. Organization: Separate bug fixes, features, releases
    5. Code Review: Develop in branch, review before merging
    
    Branch Structure:
    - Branches are just pointers to commits
    - Creating a branch is instantaneous (just creates a pointer)
    - Branches don't duplicate files (they share commits)
    - HEAD pointer indicates current branch
    
    Common Branching Strategies:
    1. Feature Branches: One branch per feature
    2. Release Branches: Prepare for production release
    3. Hotfix Branches: Quick fixes for production bugs
    4. Development Branches: Integration branch for features
    """
    print("=" * 70)
    print("UNDERSTANDING GIT BRANCHES")
    print("=" * 70)
    print("""
    Branch Concept:
    
    WITHOUT Branches:
    - Everyone works on same code
    - Conflicts are common
    - Unstable code affects everyone
    - Hard to experiment
    
    WITH Branches:
    - Multiple parallel development lines
    - Work in isolation
    - Stable main branch
    - Easy experimentation
    
    Visualizing Branches:
    
                    main
                     ↓
        A --- B --- C
                     \\
                      D --- E  ← feature-branch
    
    - A, B, C are commits on main branch
    - D, E are commits on feature-branch
    - Both branches share commits A, B, C
    - Branches diverged at commit C
    
    Key Concepts:
    • Branch = Pointer to a commit (not a copy of files)
    • HEAD = Pointer to current branch
    • Creating branch = Creating a new pointer
    • Switching branch = Moving HEAD pointer
    • Merging = Combining branch histories
    """)
    print("=" * 70)


def visualize_branch_operations():
    """
    Visualizes common branch operations with ASCII diagrams.
    
    This function shows step-by-step what happens during:
    - Branch creation
    - Switching branches
    - Making commits
    - Merging branches
    """
    print("\n" + "=" * 70)
    print("BRANCH OPERATION VISUALIZATIONS")
    print("=" * 70)
    
    print("""
    1. INITIAL STATE (on main branch):
    
        A --- B --- C  ← main, HEAD
    
    
    2. CREATE NEW BRANCH (git branch feature):
    
        A --- B --- C  ← main, feature, HEAD
    
       Note: Both main and feature point to C
             HEAD still points to main
    
    
    3. SWITCH TO NEW BRANCH (git checkout feature):
    
        A --- B --- C  ← main
                     ↑
                  feature, HEAD
    
       Note: HEAD now points to feature
    
    
    4. MAKE COMMIT ON FEATURE BRANCH:
    
        A --- B --- C  ← main
                     \\
                      D  ← feature, HEAD
    
       Note: feature pointer moved to D
             main still points to C
    
    
    5. SWITCH BACK TO MAIN (git checkout main):
    
        A --- B --- C  ← main, HEAD
                     \\
                      D  ← feature
    
       Note: HEAD now points to main
             Working directory reverts to C's state
    
    
    6. MAKE COMMIT ON MAIN:
    
                      E  ← main, HEAD
                     /
        A --- B --- C
                     \\
                      D  ← feature
    
       Note: Branches have diverged
             Need to merge to combine changes
    
    
    7. MERGE FEATURE INTO MAIN (git merge feature):
    
                      E --- F  ← main, HEAD
                     /     /
        A --- B --- C     /
                     \\   /
                      D  ← feature
    
       Note: F is a merge commit
             Combines changes from E and D
             Has two parent commits
    """)
    print("=" * 70)


# =============================================================================
# SECTION 2: Branch Creation and Navigation
# =============================================================================

def git_branch_list(repo_path: str) -> List[str]:
    """
    List all branches in the repository.
    
    Output Format:
    * main          ← Current branch (indicated by *)
      feature-login
      bugfix-auth
    
    Branch Naming Conventions:
    - Use lowercase with hyphens
    - Be descriptive but concise
    - Include category prefix (feature/, bugfix/, hotfix/)
    - Examples:
        ✓ feature/user-authentication
        ✓ bugfix/login-error
        ✓ hotfix/security-patch
        ✗ branch1 (not descriptive)
        ✗ MyFeature (use lowercase)
    
    Args:
        repo_path: Path to repository
        
    Returns:
        List of branch names
        
    Git Command Equivalent:
        git branch
        
    Options:
        git branch -a  # List all (including remote)
        git branch -r  # List remote branches only
        git branch -v  # Verbose (show last commit)
    """
    try:
        result = subprocess.run(
            ['git', 'branch'],  # List local branches
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("BRANCHES IN REPOSITORY")
        print("=" * 70)
        print(result.stdout)
        print("=" * 70)
        print("Note: * indicates current branch")
        
        # Parse branch names from output
        # Each line is either "* branch" (current) or "  branch"
        branches = []
        for line in result.stdout.strip().split('\n'):
            branch_name = line.strip().lstrip('* ')
            if branch_name:
                branches.append(branch_name)
        
        return branches
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to list branches: {e.stderr}")
        return []


def git_create_branch(repo_path: str, branch_name: str) -> bool:
    """
    Create a new branch.
    
    What Happens:
    1. Git creates new pointer to current commit
    2. Branch name is stored in .git/refs/heads/
    3. HEAD remains on current branch
    4. Working directory unchanged
    
    Important Notes:
    - Creating branch doesn't switch to it
    - Branch starts at current commit
    - No files are copied (branches are just pointers)
    - Operation is instantaneous
    
    Args:
        repo_path: Path to repository
        branch_name: Name for new branch
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git branch branch_name
        
    Common Pattern:
        # Create and switch in one command
        git checkout -b branch_name
        # or in newer Git versions
        git switch -c branch_name
    """
    try:
        result = subprocess.run(
            ['git', 'branch', branch_name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Created branch '{branch_name}'")
        print(f"  Note: Still on current branch. Use 'git checkout {branch_name}' to switch.")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to create branch '{branch_name}': {e.stderr}")
        return False


def git_checkout_branch(repo_path: str, branch_name: str) -> bool:
    """
    Switch to a different branch.
    
    What Happens:
    1. HEAD pointer moves to specified branch
    2. Working directory updates to match branch's commit
    3. Staging area is updated
    4. Any uncommitted changes carry over (if compatible)
    
    Switching Requirements:
    - Working directory must be clean (or changes compatible)
    - Cannot switch with uncommitted changes that conflict
    - Use 'git stash' to temporarily save changes
    
    Args:
        repo_path: Path to repository
        branch_name: Name of branch to switch to
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git checkout branch_name
        
    Modern Alternative:
        git switch branch_name  (Git 2.23+)
        
    Safety Note:
        Git won't let you switch if you have uncommitted changes
        that would be overwritten. This prevents data loss.
    """
    try:
        result = subprocess.run(
            ['git', 'checkout', branch_name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Switched to branch '{branch_name}'")
        print(f"  {result.stdout.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to switch to branch '{branch_name}': {e.stderr}")
        return False


def git_create_and_checkout_branch(repo_path: str, branch_name: str) -> bool:
    """
    Create a new branch and immediately switch to it.
    
    This is equivalent to:
        git branch branch_name    # Create
        git checkout branch_name  # Switch
    
    Common Workflow:
        1. Start on main branch
        2. Create new feature branch
        3. Switch to it
        4. Make changes and commits
        5. Switch back to main
        6. Merge feature branch
    
    Args:
        repo_path: Path to repository
        branch_name: Name for new branch
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git checkout -b branch_name
        
    Modern Alternative:
        git switch -c branch_name
    """
    try:
        result = subprocess.run(
            ['git', 'checkout', '-b', branch_name],  # -b creates and switches
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Created and switched to branch '{branch_name}'")
        print(f"  {result.stdout.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to create and checkout branch '{branch_name}': {e.stderr}")
        return False


def git_current_branch(repo_path: str) -> Optional[str]:
    """
    Get the name of the current branch.
    
    Methods to Identify Current Branch:
    1. git branch (current marked with *)
    2. git rev-parse --abbrev-ref HEAD (just the name)
    3. cat .git/HEAD (shows what HEAD points to)
    
    HEAD States:
    - Normal: HEAD -> refs/heads/branch_name (on a branch)
    - Detached: HEAD -> commit_hash (not on any branch)
    
    Args:
        repo_path: Path to repository
        
    Returns:
        Optional[str]: Name of current branch or None
        
    Git Command Equivalent:
        git rev-parse --abbrev-ref HEAD
    """
    try:
        result = subprocess.run(
            ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        branch_name = result.stdout.strip()
        return branch_name
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to get current branch: {e.stderr}")
        return None


# =============================================================================
# SECTION 3: Merging Branches
# =============================================================================

def explain_merge_types():
    """
    Explains different types of merges in Git.
    
    Two Main Merge Types:
    
    1. Fast-Forward Merge:
       - Target branch hasn't changed since branching
       - Simply moves branch pointer forward
       - No merge commit created
       - Linear history maintained
    
    2. Three-Way Merge (Recursive):
       - Both branches have new commits
       - Creates a merge commit with two parents
       - Combines changes from both branches
       - Non-linear history
    
    Merge Strategies:
    - recursive (default): Standard three-way merge
    - ours: Keep our version in conflicts
    - theirs: Take their version in conflicts
    - octopus: Merge multiple branches at once
    """
    print("\n" + "=" * 70)
    print("TYPES OF MERGES")
    print("=" * 70)
    print("""
    1. FAST-FORWARD MERGE:
    
       Before merge (on main):
           A --- B --- C  ← main, HEAD
                        \\
                         D --- E  ← feature
    
       After 'git merge feature':
           A --- B --- C --- D --- E  ← main, HEAD, feature
    
       Result:
       • main pointer moved to E
       • No merge commit created
       • Linear history preserved
       • Fast and clean
    
    
    2. THREE-WAY MERGE:
    
       Before merge (on main):
                         F  ← main, HEAD
                        /
           A --- B --- C
                        \\
                         D --- E  ← feature
    
       After 'git merge feature':
                         F --- G  ← main, HEAD
                        /     /
           A --- B --- C     /
                        \\   /
                         D --- E  ← feature
    
       Result:
       • G is a merge commit (has two parents: F and E)
       • Combines changes from both F and E
       • Non-linear history
       • Preserves complete history
    
    
    Choosing Merge Type:
    • Git automatically chooses based on history
    • Fast-forward if possible (linear path)
    • Three-way merge if branches diverged
    • Use --no-ff to force merge commit even for fast-forward
    """)
    print("=" * 70)


def git_merge_branch(repo_path: str, branch_name: str, 
                     message: Optional[str] = None) -> bool:
    """
    Merge specified branch into current branch.
    
    Merge Process:
    1. Git finds common ancestor commit (merge base)
    2. Compares changes in both branches since ancestor
    3. Combines changes automatically if possible
    4. Creates merge commit if needed
    5. Reports conflicts if automatic merge fails
    
    Merge Outcomes:
    - Fast-forward: Branch pointer moved
    - Successful three-way: Merge commit created
    - Conflict: User must resolve manually
    
    Args:
        repo_path: Path to repository
        branch_name: Name of branch to merge into current
        message: Optional custom merge commit message
        
    Returns:
        bool: True if successful (may have conflicts)
        
    Git Command Equivalent:
        git merge branch_name
        git merge branch_name -m "message"
        
    Best Practices:
    - Commit or stash changes before merging
    - Review what you're merging (git log, git diff)
    - Merge frequently to avoid large conflicts
    - Test after merging before pushing
    """
    try:
        cmd = ['git', 'merge', branch_name]
        
        # Add custom message if provided
        if message:
            cmd.extend(['-m', message])
        
        result = subprocess.run(
            cmd,
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Successfully merged '{branch_name}' into current branch")
        print(f"  {result.stdout.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        # Check if failure is due to conflicts
        if 'CONFLICT' in e.stdout or 'CONFLICT' in e.stderr:
            print(f"⚠ Merge conflicts detected when merging '{branch_name}'")
            print(e.stdout)
            print("\nResolve conflicts manually, then:")
            print("  1. Edit conflicted files")
            print("  2. git add <resolved-files>")
            print("  3. git commit")
            return False
        else:
            print(f"✗ Merge failed: {e.stderr}")
            return False


def git_merge_abort(repo_path: str) -> bool:
    """
    Abort a merge in progress and return to pre-merge state.
    
    When to Use:
    - Merge conflicts are too complex
    - Wrong branch was merged
    - Need to do something before merging
    
    What Happens:
    1. Removes merge-related files (.git/MERGE_HEAD, etc.)
    2. Resets working directory to pre-merge state
    3. Cleans up conflict markers
    4. Returns to normal state
    
    Args:
        repo_path: Path to repository
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git merge --abort
        
    Note:
        Only works during an active merge.
        Cannot undo a completed merge (use revert instead).
    """
    try:
        result = subprocess.run(
            ['git', 'merge', '--abort'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("✓ Merge aborted, returned to pre-merge state")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to abort merge: {e.stderr}")
        return False


# =============================================================================
# SECTION 4: Handling Merge Conflicts
# =============================================================================

def explain_merge_conflicts():
    """
    Explains what merge conflicts are and how to handle them.
    
    What Causes Conflicts?
    - Same line modified differently in both branches
    - File deleted in one branch, modified in another
    - File renamed differently in both branches
    - Binary files changed in both branches
    
    Conflict Markers:
        <<<<<<< HEAD
        Content from current branch
        =======
        Content from branch being merged
        >>>>>>> branch-name
    
    Resolution Steps:
    1. Open conflicted file
    2. Find conflict markers (<<<<<<< ======= >>>>>>>)
    3. Decide which content to keep
    4. Remove conflict markers
    5. Stage resolved file (git add)
    6. Complete merge (git commit)
    
    Prevention Strategies:
    - Merge frequently (small, manageable conflicts)
    - Communicate with team about file changes
    - Use feature branches for isolated work
    - Pull before starting new work
    """
    print("\n" + "=" * 70)
    print("UNDERSTANDING MERGE CONFLICTS")
    print("=" * 70)
    print("""
    Conflict Scenario:
    
    On main branch, file.py contains:
        def greet():
            return "Hello"
    
    On feature branch, file.py contains:
        def greet():
            return "Hi there"
    
    When merging, Git cannot decide which version to keep.
    
    
    Conflict Markers in file.py:
    
        def greet():
        <<<<<<< HEAD
            return "Hello"
        =======
            return "Hi there"
        >>>>>>> feature
    
    
    Reading Conflict Markers:
    • <<<<<<< HEAD: Start of current branch's version
    • =======: Separator between versions
    • >>>>>>> feature: End of merging branch's version
    
    
    Resolution Options:
    
    1. Keep Current (HEAD):
        def greet():
            return "Hello"
    
    2. Keep Incoming (feature):
        def greet():
            return "Hi there"
    
    3. Keep Both:
        def greet():
            return "Hello, Hi there"
    
    4. Write New Solution:
        def greet():
            return "Hello, friend!"
    
    
    After Resolving:
    1. Save the file (without conflict markers)
    2. git add file.py
    3. git commit (or git merge --continue)
    
    
    Checking Conflict Status:
    • git status: Shows which files have conflicts
    • git diff: Shows conflicts with markers
    • git ls-files -u: Lists unmerged files
    """)
    print("=" * 70)


def demonstrate_conflict_resolution(repo_path: str, file_path: Path):
    """
    Simulates and demonstrates conflict resolution.
    
    This function:
    1. Creates a conflict scenario
    2. Shows conflict markers
    3. Demonstrates resolution
    4. Completes the merge
    
    Args:
        repo_path: Path to repository
        file_path: Path to conflicted file
    """
    print("\n" + "=" * 70)
    print("CONFLICT RESOLUTION DEMONSTRATION")
    print("=" * 70)
    
    # Read file with conflict markers
    if file_path.exists():
        print(f"\nConflicted file: {file_path.name}")
        print("-" * 70)
        with open(file_path, 'r') as f:
            content = f.read()
            print(content)
        print("-" * 70)
        
        # Check if file has conflict markers
        if '<<<<<<< HEAD' in content:
            print("\n⚠ Conflict markers found!")
            print("\nTo resolve:")
            print("1. Edit the file to remove markers and choose desired content")
            print("2. Run: git add", file_path.name)
            print("3. Run: git commit")
        else:
            print("\n✓ No conflict markers found")


# =============================================================================
# SECTION 5: Branch Management
# =============================================================================

def git_delete_branch(repo_path: str, branch_name: str, force: bool = False) -> bool:
    """
    Delete a branch.
    
    Safety Considerations:
    - Git prevents deletion of unmerged branches (use -D to force)
    - Cannot delete current branch (switch first)
    - Deleted branches can be recovered (for a while)
    
    When to Delete:
    - Feature merged and no longer needed
    - Experimental branch abandoned
    - Cleanup of old branches
    
    Args:
        repo_path: Path to repository
        branch_name: Name of branch to delete
        force: Force deletion even if unmerged
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git branch -d branch_name   # Safe delete (merged only)
        git branch -D branch_name   # Force delete
        
    Recovery:
        Deleted branches can be recovered using reflog:
        git reflog
        git checkout -b recovered-branch <commit-hash>
    """
    try:
        flag = '-D' if force else '-d'
        
        result = subprocess.run(
            ['git', 'branch', flag, branch_name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        action = "Force deleted" if force else "Deleted"
        print(f"✓ {action} branch '{branch_name}'")
        print(f"  {result.stdout.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to delete branch '{branch_name}': {e.stderr}")
        if not force and 'not fully merged' in e.stderr:
            print("  Hint: Use force=True to delete unmerged branch (git branch -D)")
        return False


def git_rename_branch(repo_path: str, old_name: str, new_name: str) -> bool:
    """
    Rename a branch.
    
    Use Cases:
    - Fix typo in branch name
    - Better describe branch purpose
    - Follow team naming conventions
    
    Args:
        repo_path: Path to repository
        old_name: Current branch name
        new_name: New branch name
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git branch -m old_name new_name
        
    Rename Current Branch:
        git branch -m new_name
    """
    try:
        result = subprocess.run(
            ['git', 'branch', '-m', old_name, new_name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Renamed branch '{old_name}' to '{new_name}'")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to rename branch: {e.stderr}")
        return False


# =============================================================================
# SECTION 6: Complete Branching Workflow Demonstration
# =============================================================================

def demonstrate_branching_workflow():
    """
    Demonstrates a complete feature branch workflow.
    
    Workflow:
    1. Start on main branch
    2. Create feature branch
    3. Make changes on feature
    4. Switch back to main
    5. Make different changes on main
    6. Merge feature into main
    7. Handle any conflicts
    8. Clean up feature branch
    """
    print("\n" + "=" * 70)
    print("COMPLETE BRANCHING WORKFLOW DEMONSTRATION")
    print("=" * 70)
    
    # Create temporary repository
    temp_dir = tempfile.mkdtemp(prefix='git_branch_demo_')
    print(f"\nCreated temporary directory: {temp_dir}")
    
    try:
        # Initialize repository
        print("\n--- Setup: Initialize Repository ---")
        subprocess.run(['git', 'init'], cwd=temp_dir, check=True,
                      capture_output=True, text=True)
        subprocess.run(['git', 'config', 'user.name', 'Demo User'],
                      cwd=temp_dir, check=True, capture_output=True, text=True)
        subprocess.run(['git', 'config', 'user.email', 'demo@example.com'],
                      cwd=temp_dir, check=True, capture_output=True, text=True)
        
        # Create initial commit on main
        print("\n--- Step 1: Create Initial Commit on Main ---")
        main_file = Path(temp_dir) / "calculator.py"
        with open(main_file, 'w') as f:
            f.write('def add(a, b):\n    return a + b\n\n')
            f.write('def subtract(a, b):\n    return a - b\n')
        
        subprocess.run(['git', 'add', 'calculator.py'], cwd=temp_dir,
                      check=True, capture_output=True)
        subprocess.run(['git', 'commit', '-m', 'Initial commit: basic calculator'],
                      cwd=temp_dir, check=True, capture_output=True)
        print("✓ Created initial commit on main")
        
        # Show current state
        current = git_current_branch(temp_dir)
        print(f"✓ Current branch: {current}")
        
        # Create and switch to feature branch
        print("\n--- Step 2: Create Feature Branch ---")
        git_create_and_checkout_branch(temp_dir, 'feature/multiply')
        
        # Make changes on feature branch
        print("\n--- Step 3: Add Feature on Feature Branch ---")
        with open(main_file, 'a') as f:
            f.write('\ndef multiply(a, b):\n    return a * b\n')
        
        subprocess.run(['git', 'add', 'calculator.py'], cwd=temp_dir,
                      check=True, capture_output=True)
        subprocess.run(['git', 'commit', '-m', 'Add multiply function'],
                      cwd=temp_dir, check=True, capture_output=True)
        print("✓ Added multiply function on feature/multiply branch")
        
        # Switch back to main
        print("\n--- Step 4: Switch Back to Main ---")
        git_checkout_branch(temp_dir, 'main')
        
        # Make different changes on main
        print("\n--- Step 5: Make Different Changes on Main ---")
        with open(main_file, 'a') as f:
            f.write('\ndef divide(a, b):\n    return a / b\n')
        
        subprocess.run(['git', 'add', 'calculator.py'], cwd=temp_dir,
                      check=True, capture_output=True)
        subprocess.run(['git', 'commit', '-m', 'Add divide function'],
                      cwd=temp_dir, check=True, capture_output=True)
        print("✓ Added divide function on main branch")
        
        # Show branch structure
        print("\n--- Step 6: View Branch Structure ---")
        git_branch_list(temp_dir)
        
        # Merge feature into main
        print("\n--- Step 7: Merge Feature Branch into Main ---")
        success = git_merge_branch(temp_dir, 'feature/multiply',
                                   message='Merge feature/multiply into main')
        
        if success:
            print("\n✓ Merge completed successfully!")
            
            # Show merged content
            print("\n--- Step 8: View Merged File ---")
            with open(main_file, 'r') as f:
                content = f.read()
            print("-" * 70)
            print(content)
            print("-" * 70)
            
            # Delete feature branch
            print("\n--- Step 9: Clean Up Feature Branch ---")
            git_delete_branch(temp_dir, 'feature/multiply')
            
            # Show final branch list
            print("\n--- Step 10: Final Branch State ---")
            git_branch_list(temp_dir)
        
        print("\n" + "=" * 70)
        print("BRANCHING WORKFLOW DEMONSTRATION COMPLETE")
        print("=" * 70)
        print("""
        Summary:
        1. ✓ Started on main branch
        2. ✓ Created feature branch
        3. ✓ Made commits on feature branch
        4. ✓ Switched back to main
        5. ✓ Made different commits on main
        6. ✓ Merged feature branch into main
        7. ✓ Deleted merged feature branch
        
        Key Takeaways:
        • Branches enable parallel development
        • Each branch has independent commits
        • Merging combines branch histories
        • Feature branches keep main stable
        • Clean up merged branches
        """)
        
    finally:
        # Cleanup
        print(f"\nCleaning up: {temp_dir}")
        shutil.rmtree(temp_dir, ignore_errors=True)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function demonstrating Git branching concepts.
    """
    print("\n" + "=" * 70)
    print("GIT BRANCHING - INTERMEDIATE TUTORIAL")
    print("=" * 70)
    
    # Theoretical concepts
    explain_branches()
    input("\nPress Enter to see branch operation visualizations...")
    
    visualize_branch_operations()
    input("\nPress Enter to learn about merge types...")
    
    explain_merge_types()
    input("\nPress Enter to learn about merge conflicts...")
    
    explain_merge_conflicts()
    input("\nPress Enter to start practical demonstration...")
    
    # Practical demonstration
    demonstrate_branching_workflow()
    
    print("\n" + "=" * 70)
    print("TUTORIAL COMPLETE!")
    print("=" * 70)
    print("""
    Next Steps:
    1. Practice creating and merging branches
    2. Intentionally create conflicts to practice resolution
    3. Learn about remote branches (next module)
    4. Explore advanced workflows (rebase, cherry-pick)
    
    Practice Exercises:
    - See exercises_02_intermediate.py for hands-on practice
    
    Common Branch Commands:
    • git branch: List branches
    • git branch <name>: Create branch
    • git checkout <name>: Switch branch
    • git checkout -b <name>: Create and switch
    • git merge <name>: Merge branch
    • git branch -d <name>: Delete branch
    """)


if __name__ == "__main__":
    main()
