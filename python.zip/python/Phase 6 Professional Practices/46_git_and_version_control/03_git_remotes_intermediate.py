"""
Git & Version Control - Intermediate Level: Remote Repositories
===============================================================

This module covers working with remote repositories, including clone, fetch,
pull, and push operations. Students will learn how Git enables distributed
collaboration and understand the relationship between local and remote branches.

Learning Objectives:
- Understand distributed version control concepts
- Learn to clone repositories
- Master fetch, pull, and push operations
- Understand remote tracking branches
- Handle authentication and remote management

Prerequisites:
- Completion of basic and branching modules
- Understanding of commits and branches
- Familiarity with command-line operations

Author: Educational Materials for Undergraduate Python Course
Level: Intermediate
"""

import subprocess
import os
import tempfile
import shutil
from pathlib import Path
from typing import List, Optional, Dict


# =============================================================================
# SECTION 1: Understanding Remote Repositories
# =============================================================================

def explain_remote_repositories():
    """
    Explains the concept of remote repositories and distributed version control.
    
    What is a Remote Repository?
    - A version of your repository hosted elsewhere (GitHub, GitLab, etc.)
    - Enables collaboration among multiple developers
    - Provides backup and redundancy
    - Can be on internet or local network
    
    Distributed vs Centralized:
    
    Centralized (SVN, CVS):
    - Single central server
    - Developers commit directly to server
    - Requires network for most operations
    - Single point of failure
    
    Distributed (Git, Mercurial):
    - Every developer has full repository copy
    - Work offline, commit locally
    - Sync changes when convenient
    - No single point of failure
    - Multiple backup locations
    
    Common Remote Hosting Services:
    1. GitHub: Most popular, great features
    2. GitLab: Open source, self-hosted option
    3. Bitbucket: Integrates with Atlassian tools
    4. Azure DevOps: Microsoft ecosystem
    5. Self-hosted: GitLab, Gitea, Gogs
    """
    print("=" * 70)
    print("UNDERSTANDING REMOTE REPOSITORIES")
    print("=" * 70)
    print("""
    Distributed Version Control:
    
    Centralized System:
                    ┌─────────┐
                    │ Central │
                    │ Server  │
                    └─────────┘
                         ↑
              ┌──────────┼──────────┐
              ↓          ↓          ↓
         Developer1  Developer2  Developer3
    
    Problem: Network required, single point of failure
    
    
    Distributed System (Git):
    
         ┌──────────┐     ┌──────────┐     ┌──────────┐
         │Developer1│────▶│  Remote  │◀────│Developer2│
         │ (full    │     │ (GitHub) │     │ (full    │
         │  repo)   │     │          │     │  repo)   │
         └──────────┘     └──────────┘     └──────────┘
              ↑                                   ↑
              └─────────────────┬─────────────────┘
                                ↓
                         ┌──────────┐
                         │Developer3│
                         │ (full    │
                         │  repo)   │
                         └──────────┘
    
    Benefits:
    ✓ Work offline
    ✓ Fast operations (everything is local)
    ✓ Multiple backups
    ✓ Flexible workflows
    ✓ No single point of failure
    
    
    Remote Repository Concepts:
    
    • Origin: Default name for cloned remote
    • Upstream: Original repo you forked from
    • Remote Branch: Branch on remote repository
    • Tracking Branch: Local branch linked to remote
    • HEAD: Current commit on local
    • origin/main: Remote tracking branch
    
    
    Common Operations:
    • clone: Copy remote repository locally
    • fetch: Download remote changes (doesn't merge)
    • pull: Download and merge remote changes
    • push: Upload local changes to remote
    • remote: Manage remote connections
    """)
    print("=" * 70)


def visualize_remote_operations():
    """
    Visualizes how remote operations affect repository state.
    """
    print("\n" + "=" * 70)
    print("REMOTE OPERATION VISUALIZATIONS")
    print("=" * 70)
    print("""
    1. INITIAL STATE:
    
       Remote (GitHub):
       A --- B --- C  ← main
    
       Local:
       (nothing yet)
    
    
    2. AFTER CLONE:
    
       Remote (GitHub):
       A --- B --- C  ← main
    
       Local:
       A --- B --- C  ← main, origin/main
                  ↑
                 HEAD
    
       Note: Local has full copy including history
    
    
    3. LOCAL COMMIT:
    
       Remote (GitHub):
       A --- B --- C  ← main
    
       Local:
       A --- B --- C --- D  ← main, HEAD
                     ↑
                 origin/main
    
       Note: origin/main still at C (not updated yet)
    
    
    4. AFTER PUSH:
    
       Remote (GitHub):
       A --- B --- C --- D  ← main
    
       Local:
       A --- B --- C --- D  ← main, origin/main, HEAD
    
       Note: Remote and local now synchronized
    
    
    5. REMOTE CHANGES (someone else pushed E):
    
       Remote (GitHub):
       A --- B --- C --- D --- E  ← main
    
       Local:
       A --- B --- C --- D  ← main, origin/main, HEAD
    
       Note: Local doesn't know about E yet
    
    
    6. AFTER FETCH:
    
       Remote (GitHub):
       A --- B --- C --- D --- E  ← main
    
       Local:
       A --- B --- C --- D  ← main, HEAD
                           \\
                            E  ← origin/main
    
       Note: origin/main updated, but main unchanged
    
    
    7. AFTER MERGE (completing pull):
    
       Remote (GitHub):
       A --- B --- C --- D --- E  ← main
    
       Local:
       A --- B --- C --- D --- E  ← main, origin/main, HEAD
    
       Note: Local main now includes E
    
    
    8. DIVERGED STATE (local and remote differ):
    
       Remote (GitHub):
       A --- B --- C --- E  ← main
    
       Local:
       A --- B --- C --- D  ← main, HEAD
                     ↑
                 origin/main (outdated)
    
       Solution: fetch + merge (pull) or rebase
    """)
    print("=" * 70)


# =============================================================================
# SECTION 2: Cloning Repositories
# =============================================================================

def git_clone(url: str, target_dir: Optional[str] = None, 
              parent_dir: str = None) -> Optional[str]:
    """
    Clone a remote repository.
    
    What Happens During Clone:
    1. Creates a new directory (if not specified)
    2. Initializes .git directory
    3. Downloads all commits, branches, and history
    4. Checks out default branch (usually main/master)
    5. Sets up 'origin' as remote
    6. Creates remote-tracking branches
    
    Clone vs Download:
    - Clone: Full repository with history
    - Download: Just current files (no Git)
    
    Args:
        url: Repository URL (https:// or git://)
        target_dir: Optional directory name for repo
        parent_dir: Directory where repo will be cloned
        
    Returns:
        Optional[str]: Path to cloned repository
        
    Git Command Equivalent:
        git clone <url>
        git clone <url> <directory>
        
    URL Formats:
        HTTPS: https://github.com/user/repo.git
        SSH:   git@github.com:user/repo.git
        Local: /path/to/repo or file:///path/to/repo
    
    Authentication:
        HTTPS: Username/password or token
        SSH: SSH keys (more secure, no password needed)
    """
    try:
        cmd = ['git', 'clone', url]
        
        if target_dir:
            cmd.append(target_dir)
        
        cwd = parent_dir if parent_dir else os.getcwd()
        
        result = subprocess.run(
            cmd,
            cwd=cwd,
            check=True,
            capture_output=True,
            text=True
        )
        
        # Determine repository path
        if target_dir:
            repo_path = os.path.join(cwd, target_dir)
        else:
            # Extract directory name from URL
            repo_name = url.rstrip('/').split('/')[-1]
            if repo_name.endswith('.git'):
                repo_name = repo_name[:-4]
            repo_path = os.path.join(cwd, repo_name)
        
        print(f"✓ Successfully cloned repository")
        print(f"  URL: {url}")
        print(f"  Location: {repo_path}")
        print(f"  {result.stderr}")
        
        return repo_path
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Clone failed: {e.stderr}")
        return None


def git_clone_shallow(url: str, depth: int = 1, 
                     target_dir: Optional[str] = None,
                     parent_dir: str = None) -> Optional[str]:
    """
    Clone repository with limited history (shallow clone).
    
    Shallow Clone Benefits:
    - Faster cloning (less data to download)
    - Less disk space
    - Good for CI/CD pipelines
    - Suitable when history isn't needed
    
    Limitations:
    - Can't access older commits
    - Some operations restricted
    - Can't push from shallow clone (usually)
    
    Args:
        url: Repository URL
        depth: Number of commits to include
        target_dir: Optional directory name
        parent_dir: Where to clone
        
    Returns:
        Optional[str]: Path to cloned repository
        
    Git Command Equivalent:
        git clone --depth 1 <url>
        
    Use Cases:
        - Deploying latest version only
        - CI/CD builds
        - Saving bandwidth/time
        - Working with huge repositories
    """
    try:
        cmd = ['git', 'clone', '--depth', str(depth), url]
        
        if target_dir:
            cmd.append(target_dir)
        
        cwd = parent_dir if parent_dir else os.getcwd()
        
        result = subprocess.run(
            cmd,
            cwd=cwd,
            check=True,
            capture_output=True,
            text=True
        )
        
        if target_dir:
            repo_path = os.path.join(cwd, target_dir)
        else:
            repo_name = url.rstrip('/').split('/')[-1]
            if repo_name.endswith('.git'):
                repo_name = repo_name[:-4]
            repo_path = os.path.join(cwd, repo_name)
        
        print(f"✓ Successfully cloned shallow repository (depth={depth})")
        print(f"  Location: {repo_path}")
        
        return repo_path
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Shallow clone failed: {e.stderr}")
        return None


# =============================================================================
# SECTION 3: Remote Management
# =============================================================================

def git_remote_list(repo_path: str) -> List[str]:
    """
    List all configured remotes.
    
    Remote Information:
    - Name: Alias for remote (e.g., 'origin')
    - URL: Location of remote repository
    - Fetch: URL for fetching changes
    - Push: URL for pushing changes (can differ)
    
    Args:
        repo_path: Path to repository
        
    Returns:
        List of remote names
        
    Git Command Equivalent:
        git remote
        git remote -v  (verbose with URLs)
        
    Common Remotes:
        origin: Default remote when cloning
        upstream: Original repo for forks
        production: Deployment remote
    """
    try:
        # Get remote names
        result = subprocess.run(
            ['git', 'remote'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        remotes = result.stdout.strip().split('\n') if result.stdout.strip() else []
        
        # Get verbose information
        result_v = subprocess.run(
            ['git', 'remote', '-v'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("CONFIGURED REMOTES")
        print("=" * 70)
        
        if result_v.stdout.strip():
            print(result_v.stdout)
        else:
            print("No remotes configured.")
        
        print("=" * 70)
        
        return remotes
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to list remotes: {e.stderr}")
        return []


def git_remote_add(repo_path: str, name: str, url: str) -> bool:
    """
    Add a new remote repository.
    
    Use Cases:
    - Fork workflow: Add upstream remote
    - Multiple deployment targets
    - Mirror repositories
    - Backup locations
    
    Args:
        repo_path: Path to repository
        name: Name for remote (e.g., 'upstream')
        url: URL of remote repository
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git remote add <name> <url>
        
    Example:
        # Add upstream remote for a fork
        git remote add upstream https://github.com/original/repo.git
    """
    try:
        subprocess.run(
            ['git', 'remote', 'add', name, url],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Added remote '{name}'")
        print(f"  URL: {url}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to add remote '{name}': {e.stderr}")
        return False


def git_remote_remove(repo_path: str, name: str) -> bool:
    """
    Remove a remote repository.
    
    What Gets Removed:
    - Remote configuration
    - Remote-tracking branches
    - Does NOT affect local branches
    
    Args:
        repo_path: Path to repository
        name: Name of remote to remove
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git remote remove <name>
        (or git remote rm <name>)
    """
    try:
        subprocess.run(
            ['git', 'remote', 'remove', name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Removed remote '{name}'")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to remove remote '{name}': {e.stderr}")
        return False


def git_remote_rename(repo_path: str, old_name: str, new_name: str) -> bool:
    """
    Rename a remote.
    
    Args:
        repo_path: Path to repository
        old_name: Current remote name
        new_name: New remote name
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git remote rename <old> <new>
    """
    try:
        subprocess.run(
            ['git', 'remote', 'rename', old_name, new_name],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Renamed remote '{old_name}' to '{new_name}'")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to rename remote: {e.stderr}")
        return False


# =============================================================================
# SECTION 4: Fetching and Pulling
# =============================================================================

def explain_fetch_vs_pull():
    """
    Explains the difference between fetch and pull.
    
    Fetch:
    - Downloads changes from remote
    - Updates remote-tracking branches (origin/main)
    - Does NOT modify local branches
    - Does NOT modify working directory
    - Safe operation (no conflicts possible)
    
    Pull:
    - Combination of fetch + merge
    - Downloads changes (fetch)
    - Merges into current branch (merge)
    - Can cause conflicts
    - Updates working directory
    
    Formula:
        git pull = git fetch + git merge origin/<branch>
    """
    print("\n" + "=" * 70)
    print("FETCH vs PULL")
    print("=" * 70)
    print("""
    Understanding the Difference:
    
    FETCH (Safe, Review First):
    ┌─────────────────────────────────────────┐
    │ Remote (origin)                         │
    │ A --- B --- C --- D  ← main             │
    └─────────────────────────────────────────┘
                   ↓ fetch
    ┌─────────────────────────────────────────┐
    │ Local Repository                        │
    │                                         │
    │ A --- B --- C  ← main, HEAD             │
    │              \\                          │
    │               D  ← origin/main          │
    │                                         │
    │ Working directory: unchanged            │
    └─────────────────────────────────────────┘
    
    After fetch:
    • origin/main updated to D
    • Local main still at C
    • Working directory unchanged
    • Can review changes before merging
    
    
    PULL (Fetch + Merge):
    ┌─────────────────────────────────────────┐
    │ Remote (origin)                         │
    │ A --- B --- C --- D  ← main             │
    └─────────────────────────────────────────┘
                   ↓ pull
    ┌─────────────────────────────────────────┐
    │ Local Repository                        │
    │                                         │
    │ A --- B --- C --- D  ← main, origin/main│
    │                  ↑                      │
    │                 HEAD                    │
    │                                         │
    │ Working directory: updated to D         │
    └─────────────────────────────────────────┘
    
    After pull:
    • Local main updated to D
    • Working directory updated
    • Automatic merge performed
    
    
    When to Use Each:
    
    Use FETCH when:
    ✓ Want to see changes before merging
    ✓ Review others' work first
    ✓ Check for conflicts before merging
    ✓ Need to compare local and remote
    
    Use PULL when:
    ✓ Trust changes from remote
    ✓ Want to update quickly
    ✓ Working alone or small team
    ✓ Confident no conflicts
    
    
    Best Practice:
    1. git fetch origin
    2. git diff main origin/main  (review changes)
    3. git merge origin/main      (merge if okay)
    
    Or simply:
    git pull  (combines all steps)
    """)
    print("=" * 70)


def git_fetch(repo_path: str, remote: str = 'origin', 
              branch: Optional[str] = None) -> bool:
    """
    Fetch changes from remote repository.
    
    Fetch Process:
    1. Contacts remote repository
    2. Downloads new commits, branches, tags
    3. Updates remote-tracking branches
    4. Local branches unchanged
    5. Working directory unchanged
    
    Args:
        repo_path: Path to repository
        remote: Remote name (default: 'origin')
        branch: Optional specific branch to fetch
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git fetch origin
        git fetch origin main
        git fetch --all  (all remotes)
        
    After Fetch:
        Use 'git diff main origin/main' to see changes
        Use 'git merge origin/main' to integrate changes
    """
    try:
        cmd = ['git', 'fetch', remote]
        if branch:
            cmd.append(branch)
        
        result = subprocess.run(
            cmd,
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Fetched from '{remote}'")
        if result.stderr:  # Git outputs fetch info to stderr
            print(f"  {result.stderr.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Fetch failed: {e.stderr}")
        return False


def git_pull(repo_path: str, remote: str = 'origin', 
             branch: Optional[str] = None) -> bool:
    """
    Pull changes from remote (fetch + merge).
    
    Pull Process:
    1. Fetch changes from remote
    2. Merge into current branch
    3. Update working directory
    
    Pull Strategies:
    - merge (default): Create merge commit
    - rebase: Replay local commits on top of remote
    - fast-forward only: Only if can fast-forward
    
    Args:
        repo_path: Path to repository
        remote: Remote name (default: 'origin')
        branch: Optional specific branch to pull
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git pull
        git pull origin main
        git pull --rebase
        
    Common Issues:
        - Merge conflicts: Resolve manually
        - Diverged histories: May need rebase
        - Uncommitted changes: Stash or commit first
    """
    try:
        cmd = ['git', 'pull', remote]
        if branch:
            cmd.append(branch)
        
        result = subprocess.run(
            cmd,
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Pulled from '{remote}'")
        print(f"  {result.stdout.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        if 'CONFLICT' in e.stdout or 'CONFLICT' in e.stderr:
            print("⚠ Pull resulted in merge conflicts")
            print(e.stdout)
            print("\nResolve conflicts, then commit.")
        else:
            print(f"✗ Pull failed: {e.stderr}")
        return False


# =============================================================================
# SECTION 5: Pushing Changes
# =============================================================================

def git_push(repo_path: str, remote: str = 'origin', 
             branch: Optional[str] = None, force: bool = False) -> bool:
    """
    Push local changes to remote repository.
    
    Push Process:
    1. Check if local ahead of remote
    2. Upload new commits to remote
    3. Update remote branch pointer
    4. Fast-forward if possible
    
    Push Requirements:
    - Local branch must be up-to-date with remote
    - Need write permissions on remote
    - Authentication required (HTTPS/SSH)
    
    Args:
        repo_path: Path to repository
        remote: Remote name (default: 'origin')
        branch: Branch to push (default: current)
        force: Force push (dangerous!)
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git push
        git push origin main
        git push -f  (force push - DANGEROUS!)
        git push --set-upstream origin branch
        
    Force Push Warning:
        - Overwrites remote history
        - Can lose others' work
        - Only use on personal branches
        - Team members may need to re-clone
        
    Common Errors:
        "rejected": Remote has changes you don't have (pull first)
        "no upstream": Need to set tracking branch
        "permission denied": Authentication failed
    """
    try:
        cmd = ['git', 'push']
        
        if force:
            cmd.append('-f')
        
        if remote and branch:
            cmd.extend([remote, branch])
        elif remote:
            cmd.append(remote)
        
        result = subprocess.run(
            cmd,
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Pushed to '{remote}'")
        if result.stderr:  # Git outputs push info to stderr
            print(f"  {result.stderr.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        error_msg = e.stderr.lower()
        if 'rejected' in error_msg:
            print("✗ Push rejected: Remote has changes you don't have")
            print("  Run 'git pull' first to merge remote changes")
        elif 'no upstream' in error_msg:
            print("✗ No upstream branch configured")
            print(f"  Run: git push --set-upstream {remote} <branch>")
        else:
            print(f"✗ Push failed: {e.stderr}")
        return False


def git_push_set_upstream(repo_path: str, remote: str, branch: str) -> bool:
    """
    Push branch and set up tracking relationship.
    
    Tracking Branch:
    - Links local branch to remote branch
    - Enables 'git pull' and 'git push' without arguments
    - Shows ahead/behind status
    
    Args:
        repo_path: Path to repository
        remote: Remote name
        branch: Branch name
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git push -u origin branch
        git push --set-upstream origin branch
        
    After Setup:
        Can use 'git push' and 'git pull' without specifying remote/branch
    """
    try:
        result = subprocess.run(
            ['git', 'push', '--set-upstream', remote, branch],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Pushed and set upstream: {remote}/{branch}")
        print(f"  {result.stderr.strip()}")
        
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to push and set upstream: {e.stderr}")
        return False


# =============================================================================
# SECTION 6: Complete Remote Workflow Demonstration
# =============================================================================

def demonstrate_remote_workflow():
    """
    Demonstrates a complete remote repository workflow.
    
    Workflow:
    1. Create "remote" repository (simulated locally)
    2. Clone it
    3. Make local changes
    4. Push to remote
    5. Make changes in "remote"
    6. Fetch and merge (pull)
    """
    print("\n" + "=" * 70)
    print("COMPLETE REMOTE WORKFLOW DEMONSTRATION")
    print("=" * 70)
    
    # Create temporary directories
    temp_base = tempfile.mkdtemp(prefix='git_remote_demo_')
    remote_dir = os.path.join(temp_base, 'remote_repo')
    local_dir = os.path.join(temp_base, 'local_repo')
    
    print(f"\nCreated temporary directories:")
    print(f"  Remote: {remote_dir}")
    print(f"  Local:  {local_dir}")
    
    try:
        # Create "remote" repository
        print("\n--- Step 1: Create Remote Repository ---")
        os.makedirs(remote_dir)
        subprocess.run(['git', 'init', '--bare'], cwd=remote_dir,
                      check=True, capture_output=True)
        print(f"✓ Created bare repository at {remote_dir}")
        
        # Clone repository
        print("\n--- Step 2: Clone Repository ---")
        subprocess.run(['git', 'clone', remote_dir, local_dir],
                      cwd=temp_base, check=True, capture_output=True)
        print(f"✓ Cloned to {local_dir}")
        
        # Configure local repo
        subprocess.run(['git', 'config', 'user.name', 'Demo User'],
                      cwd=local_dir, check=True, capture_output=True)
        subprocess.run(['git', 'config', 'user.email', 'demo@example.com'],
                      cwd=local_dir, check=True, capture_output=True)
        
        # Check remotes
        print("\n--- Step 3: Check Remote Configuration ---")
        git_remote_list(local_dir)
        
        # Create initial file and push
        print("\n--- Step 4: Create File and Push ---")
        test_file = Path(local_dir) / "project.py"
        with open(test_file, 'w') as f:
            f.write('# My Project\n\ndef main():\n    print("Hello, Git!")\n')
        
        subprocess.run(['git', 'add', 'project.py'], cwd=local_dir,
                      check=True, capture_output=True)
        subprocess.run(['git', 'commit', '-m', 'Initial commit'],
                      cwd=local_dir, check=True, capture_output=True)
        
        # Push to remote (set upstream for initial push)
        result = subprocess.run(
            ['git', 'push', '-u', 'origin', 'master'],
            cwd=local_dir,
            capture_output=True,
            text=True
        )
        
        print("✓ Pushed initial commit to remote")
        
        # Make more local changes
        print("\n--- Step 5: Make Local Changes ---")
        with open(test_file, 'a') as f:
            f.write('\nif __name__ == "__main__":\n    main()\n')
        
        subprocess.run(['git', 'add', 'project.py'], cwd=local_dir,
                      check=True, capture_output=True)
        subprocess.run(['git', 'commit', '-m', 'Add main guard'],
                      cwd=local_dir, check=True, capture_output=True)
        print("✓ Committed local changes")
        
        # Push changes
        print("\n--- Step 6: Push Changes ---")
        git_push(local_dir, 'origin')
        
        # Simulate fetching (demonstrate fetch vs pull)
        print("\n--- Step 7: Demonstrate Fetch ---")
        print("In real scenario, remote would have new changes.")
        print("Fetch downloads changes without merging:")
        git_fetch(local_dir, 'origin')
        
        print("\n" + "=" * 70)
        print("REMOTE WORKFLOW DEMONSTRATION COMPLETE")
        print("=" * 70)
        print("""
        Summary:
        1. ✓ Created remote repository
        2. ✓ Cloned repository locally
        3. ✓ Made local commits
        4. ✓ Pushed to remote
        5. ✓ Demonstrated fetch operation
        
        Key Takeaways:
        • Clone creates full copy of repository
        • Push uploads local commits to remote
        • Pull downloads and merges remote changes
        • Fetch downloads without merging
        • Remote tracking branches (origin/main)
        • Always pull before push
        
        Common Workflow:
        1. git pull          # Get latest changes
        2. <make changes>    # Edit files
        3. git add .         # Stage changes
        4. git commit -m     # Commit locally
        5. git push          # Upload to remote
        """)
        
    except Exception as e:
        print(f"Error in demonstration: {e}")
        
    finally:
        # Cleanup
        print(f"\nCleaning up: {temp_base}")
        shutil.rmtree(temp_base, ignore_errors=True)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function demonstrating remote repository concepts.
    """
    print("\n" + "=" * 70)
    print("GIT REMOTE REPOSITORIES - INTERMEDIATE TUTORIAL")
    print("=" * 70)
    
    # Theoretical concepts
    explain_remote_repositories()
    input("\nPress Enter to see remote operation visualizations...")
    
    visualize_remote_operations()
    input("\nPress Enter to learn about fetch vs pull...")
    
    explain_fetch_vs_pull()
    input("\nPress Enter to start practical demonstration...")
    
    # Practical demonstration
    demonstrate_remote_workflow()
    
    print("\n" + "=" * 70)
    print("TUTORIAL COMPLETE!")
    print("=" * 70)
    print("""
    Next Steps:
    1. Create a GitHub/GitLab account
    2. Create a repository and clone it
    3. Practice push/pull workflow
    4. Learn about advanced topics (rebase, cherry-pick)
    
    Common Remote Commands:
    • git clone <url>: Clone repository
    • git remote -v: List remotes
    • git fetch: Download changes
    • git pull: Download and merge
    • git push: Upload changes
    • git push -u origin <branch>: Set upstream
    
    Practice Exercises:
    - See exercises_02_intermediate.py for hands-on practice
    """)


if __name__ == "__main__":
    main()
