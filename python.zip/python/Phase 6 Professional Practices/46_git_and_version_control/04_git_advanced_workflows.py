"""
Git & Version Control - Advanced Level: Workflows & Best Practices
==================================================================

This module covers advanced Git concepts including rebasing, cherry-picking,
stashing, tags, and professional workflows. Students will learn industry-standard
practices and advanced techniques for managing complex projects.

Learning Objectives:
- Understand and use git rebase
- Learn cherry-picking for selective commits
- Master git stash for temporary storage
- Create and manage tags
- Understand professional Git workflows
- Learn Git best practices and conventions

Prerequisites:
- Mastery of basic Git operations
- Understanding of branches and merging
- Experience with remote repositories
- Familiarity with merge conflicts

Author: Educational Materials for Undergraduate Python Course
Level: Advanced
"""

import subprocess
import os
import tempfile
import shutil
from pathlib import Path
from typing import Optional, List


# =============================================================================
# SECTION 1: Understanding Git Rebase
# =============================================================================

def explain_rebase():
    """
    Explains git rebase and its differences from merge.
    
    What is Rebase?
    - Rewrites commit history
    - Moves commits to new base
    - Creates linear history
    - Alternative to merging
    
    Rebase vs Merge:
    
    MERGE (Preserves History):
    - Creates merge commit
    - Non-linear history
    - Shows when branches merged
    - Safer for public branches
    
    REBASE (Cleaner History):
    - Linear history
    - No merge commits
    - Looks like sequential development
    - Dangerous for public branches
    
    Golden Rule of Rebase:
    "Never rebase commits that have been pushed to a shared repository"
    
    Why? Because rebase rewrites history, causing problems for others
    who have based work on the original commits.
    """
    print("=" * 70)
    print("UNDERSTANDING GIT REBASE")
    print("=" * 70)
    print("""
    Rebase: Changing the Base of Your Branch
    
    BEFORE REBASE:
    
                    D --- E  ← feature
                   /
        A --- B --- C --- F  ← main
    
    After checkout feature and 'git rebase main':
    
        A --- B --- C --- F  ← main
                           \\
                            D' --- E'  ← feature
    
    Note: D' and E' are NEW commits (different hashes)
          They have same content as D and E
          But different parent (F instead of C)
    
    
    MERGE vs REBASE Comparison:
    
    Merge Result:
                    D --- E
                   /       \\
        A --- B --- C --- F --- M  ← main
                           
    History shows:
    - Branch point (C)
    - Parallel development
    - Merge point (M)
    
    Rebase Result:
        A --- B --- C --- F --- D' --- E'  ← main
    
    History shows:
    - Linear sequence
    - No merge commit
    - Clean, simple history
    
    
    When to Use Each:
    
    Use MERGE when:
    ✓ Branch is shared/public
    ✓ Want to preserve exact history
    ✓ Working with others on same branch
    ✓ Need to show when features merged
    
    Use REBASE when:
    ✓ Private feature branch
    ✓ Want clean linear history
    ✓ Before merging to main
    ✓ Incorporating upstream changes
    
    
    Interactive Rebase:
    • Reorder commits
    • Edit commit messages
    • Squash multiple commits
    • Split commits
    • Delete commits
    
    Command: git rebase -i HEAD~3
    
    
    Rebase Workflow:
    1. git checkout feature
    2. git rebase main
    3. Resolve conflicts if any
    4. git rebase --continue
    5. git checkout main
    6. git merge feature  (fast-forward)
    """)
    print("=" * 70)


def git_rebase(repo_path: str, base_branch: str) -> bool:
    """
    Rebase current branch onto specified base branch.
    
    Process:
    1. Git finds common ancestor
    2. Temporarily removes commits from current branch
    3. Fast-forwards to base branch
    4. Replays removed commits one by one
    5. Creates new commits with same changes
    
    Args:
        repo_path: Path to repository
        base_branch: Branch to rebase onto
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git rebase <base_branch>
        
    If Conflicts:
        1. Resolve conflicts in files
        2. git add <resolved-files>
        3. git rebase --continue
        Or: git rebase --abort (cancel rebase)
    """
    try:
        result = subprocess.run(
            ['git', 'rebase', base_branch],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Successfully rebased onto '{base_branch}'")
        print(f"  {result.stdout.strip()}")
        return True
        
    except subprocess.CalledProcessError as e:
        if 'CONFLICT' in e.stdout or 'CONFLICT' in e.stderr:
            print(f"⚠ Rebase conflicts detected")
            print(e.stdout)
            print("\nResolve conflicts, then:")
            print("  git add <resolved-files>")
            print("  git rebase --continue")
        else:
            print(f"✗ Rebase failed: {e.stderr}")
        return False


# =============================================================================
# SECTION 2: Cherry-Picking
# =============================================================================

def explain_cherry_pick():
    """
    Explains git cherry-pick for selective commit application.
    
    What is Cherry-Pick?
    - Applies specific commit from one branch to another
    - Creates new commit with same changes
    - Doesn't move or copy the original commit
    - Useful for hotfixes and selective features
    
    Use Cases:
    - Apply hotfix to multiple branches
    - Port feature to different version
    - Undo mistake (pick good commits)
    - Extract specific changes
    """
    print("\n" + "=" * 70)
    print("CHERRY-PICKING COMMITS")
    print("=" * 70)
    print("""
    Cherry-Pick: Applying Specific Commits
    
    Scenario:
    
        main:     A --- B --- C --- D
                           \\
        feature:            E --- F --- G
    
    You want commit F's changes on main, but not E or G.
    
    Solution:
    1. git checkout main
    2. git cherry-pick <F's hash>
    
    Result:
    
        main:     A --- B --- C --- D --- F'
                           \\
        feature:            E --- F --- G
    
    F' is a NEW commit with F's changes
    Different hash, same content
    
    
    Common Use Cases:
    
    1. Hotfix to Multiple Branches:
       fix bug → feature branch
       cherry-pick → release-1.0
       cherry-pick → release-2.0
       cherry-pick → main
    
    2. Selective Feature Port:
       feature on dev branch
       cherry-pick specific commits to stable
    
    3. Recovering from Mistakes:
       bad branch with some good commits
       cherry-pick good commits to new branch
    
    
    Cherry-Pick Options:
    • -n, --no-commit: Apply without committing
    • -x: Add reference to original commit
    • -e: Edit commit message
    • --continue: Continue after resolving conflicts
    • --abort: Cancel cherry-pick
    
    
    Multiple Commits:
    git cherry-pick <hash1> <hash2> <hash3>
    git cherry-pick <hash1>..<hash3>  (range)
    """)
    print("=" * 70)


def git_cherry_pick(repo_path: str, commit_hash: str) -> bool:
    """
    Cherry-pick a specific commit to current branch.
    
    Args:
        repo_path: Path to repository
        commit_hash: Hash of commit to cherry-pick
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git cherry-pick <hash>
    """
    try:
        result = subprocess.run(
            ['git', 'cherry-pick', commit_hash],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print(f"✓ Cherry-picked commit {commit_hash[:7]}")
        print(f"  {result.stdout.strip()}")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Cherry-pick failed: {e.stderr}")
        return False


# =============================================================================
# SECTION 3: Stashing Changes
# =============================================================================

def explain_stash():
    """
    Explains git stash for temporarily storing changes.
    
    What is Stash?
    - Temporary storage for uncommitted changes
    - Saves both staged and unstaged changes
    - Allows switching branches with dirty working directory
    - Stack-based (LIFO - Last In, First Out)
    
    Use Cases:
    - Switch branches with uncommitted work
    - Pull changes with local modifications
    - Experiment without committing
    - Save work-in-progress
    """
    print("\n" + "=" * 70)
    print("STASHING CHANGES")
    print("=" * 70)
    print("""
    Stash: Temporary Storage for Changes
    
    Scenario:
    - Working on feature branch
    - Uncommitted changes
    - Need to switch to main for urgent fix
    - Don't want to commit incomplete work
    
    Solution:
    1. git stash                    # Save changes
    2. git checkout main            # Switch branch
    3. <fix urgent issue>
    4. git checkout feature         # Back to feature
    5. git stash pop                # Restore changes
    
    
    Stash Stack (LIFO):
    
    git stash save "message"
    ┌─────────────────┐
    │ Stash 2: msg C  │  ← Top (most recent)
    ├─────────────────┤
    │ Stash 1: msg B  │
    ├─────────────────┤
    │ Stash 0: msg A  │  ← Bottom (oldest)
    └─────────────────┘
    
    git stash pop → Applies stash 2 and removes it
    git stash apply → Applies stash 2 but keeps it
    
    
    Common Stash Operations:
    
    • git stash
      Save changes and clean working directory
    
    • git stash list
      Show all stashes with their messages
    
    • git stash pop
      Apply most recent stash and remove it
    
    • git stash apply stash@{n}
      Apply specific stash (keep it in stack)
    
    • git stash drop stash@{n}
      Delete specific stash
    
    • git stash clear
      Delete all stashes
    
    • git stash show stash@{n}
      Show changes in stash
    
    • git stash branch <name>
      Create branch from stash
    
    
    Stash Contents:
    - Tracked files (modified)
    - Staged changes
    - Untracked files (-u flag)
    - Ignored files (-a flag)
    
    
    Best Practices:
    • Add descriptive messages
    • Don't let stashes accumulate
    • Clean up after applying
    • Use stash for short-term only
    • Prefer commits for long-term
    """)
    print("=" * 70)


def git_stash(repo_path: str, message: Optional[str] = None) -> bool:
    """
    Stash current changes.
    
    Args:
        repo_path: Path to repository
        message: Optional description of stashed changes
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git stash
        git stash save "message"
    """
    try:
        cmd = ['git', 'stash']
        if message:
            cmd.extend(['save', message])
        
        result = subprocess.run(
            cmd,
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("✓ Changes stashed")
        print(f"  {result.stdout.strip()}")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Stash failed: {e.stderr}")
        return False


def git_stash_list(repo_path: str) -> List[str]:
    """
    List all stashes.
    
    Returns:
        List of stash descriptions
        
    Git Command Equivalent:
        git stash list
    """
    try:
        result = subprocess.run(
            ['git', 'stash', 'list'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("STASH LIST")
        print("=" * 70)
        
        if result.stdout.strip():
            print(result.stdout)
            stashes = result.stdout.strip().split('\n')
        else:
            print("No stashes saved.")
            stashes = []
        
        print("=" * 70)
        return stashes
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to list stashes: {e.stderr}")
        return []


def git_stash_pop(repo_path: str) -> bool:
    """
    Apply and remove most recent stash.
    
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git stash pop
    """
    try:
        result = subprocess.run(
            ['git', 'stash', 'pop'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("✓ Stash applied and removed")
        print(f"  {result.stdout.strip()}")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Stash pop failed: {e.stderr}")
        return False


# =============================================================================
# SECTION 4: Tagging
# =============================================================================

def explain_tags():
    """
    Explains Git tags for marking important points in history.
    
    What are Tags?
    - Named references to specific commits
    - Mark release points (v1.0, v2.0)
    - Immutable (don't move like branches)
    - Two types: lightweight and annotated
    
    Tag Types:
    1. Lightweight: Just a pointer (like branch that doesn't move)
    2. Annotated: Full Git object with tagger, date, message
    
    Use Cases:
    - Mark releases (v1.0.0, v2.1.3)
    - Mark milestones
    - Reference stable points
    - Semantic versioning
    """
    print("\n" + "=" * 70)
    print("GIT TAGS")
    print("=" * 70)
    print("""
    Tags: Marking Important Commits
    
    Version Timeline:
    
    A --- B --- C --- D --- E --- F
          ↑           ↑           ↑
        v1.0        v1.1        v2.0
    
    
    Lightweight vs Annotated Tags:
    
    Lightweight:
    - Just a name for a commit
    - No additional information
    - Created with: git tag v1.0
    
    Annotated:
    - Full Git object
    - Contains: tagger name, email, date, message
    - Can be signed with GPG
    - Created with: git tag -a v1.0 -m "Release 1.0"
    - Recommended for releases
    
    
    Semantic Versioning (SemVer):
    
    Format: MAJOR.MINOR.PATCH  (e.g., 2.1.3)
    
    - MAJOR: Incompatible API changes
    - MINOR: Backward-compatible functionality
    - PATCH: Backward-compatible bug fixes
    
    Examples:
    v1.0.0 → Initial release
    v1.0.1 → Bug fix
    v1.1.0 → New feature (compatible)
    v2.0.0 → Breaking changes
    
    
    Tag Operations:
    
    • git tag
      List all tags
    
    • git tag v1.0
      Create lightweight tag
    
    • git tag -a v1.0 -m "message"
      Create annotated tag
    
    • git tag -a v1.0 <hash>
      Tag specific commit
    
    • git show v1.0
      Show tag information
    
    • git tag -d v1.0
      Delete local tag
    
    • git push origin v1.0
      Push tag to remote
    
    • git push origin --tags
      Push all tags
    
    • git push origin :refs/tags/v1.0
      Delete remote tag
    
    
    Best Practices:
    • Use annotated tags for releases
    • Follow semantic versioning
    • Add release notes in tag message
    • Sign tags for security (GPG)
    • Push tags explicitly (not automatic)
    """)
    print("=" * 70)


def git_create_tag(repo_path: str, tag_name: str, 
                   message: Optional[str] = None,
                   annotated: bool = True) -> bool:
    """
    Create a Git tag.
    
    Args:
        repo_path: Path to repository
        tag_name: Name of tag (e.g., 'v1.0.0')
        message: Tag message (for annotated tags)
        annotated: Create annotated tag (default) or lightweight
        
    Returns:
        bool: True if successful
        
    Git Command Equivalent:
        git tag v1.0                     # Lightweight
        git tag -a v1.0 -m "message"     # Annotated
    """
    try:
        if annotated:
            cmd = ['git', 'tag', '-a', tag_name]
            if message:
                cmd.extend(['-m', message])
            else:
                cmd.extend(['-m', f'Tag {tag_name}'])
        else:
            cmd = ['git', 'tag', tag_name]
        
        subprocess.run(
            cmd,
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        tag_type = "annotated" if annotated else "lightweight"
        print(f"✓ Created {tag_type} tag: {tag_name}")
        return True
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to create tag: {e.stderr}")
        return False


def git_list_tags(repo_path: str) -> List[str]:
    """
    List all tags.
    
    Returns:
        List of tag names
        
    Git Command Equivalent:
        git tag
    """
    try:
        result = subprocess.run(
            ['git', 'tag'],
            cwd=repo_path,
            check=True,
            capture_output=True,
            text=True
        )
        
        print("\n" + "=" * 70)
        print("TAGS")
        print("=" * 70)
        
        if result.stdout.strip():
            print(result.stdout)
            tags = result.stdout.strip().split('\n')
        else:
            print("No tags created.")
            tags = []
        
        print("=" * 70)
        return tags
        
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to list tags: {e.stderr}")
        return []


# =============================================================================
# SECTION 5: Git Workflows & Best Practices
# =============================================================================

def explain_git_workflows():
    """
    Explains common professional Git workflows.
    """
    print("\n" + "=" * 70)
    print("PROFESSIONAL GIT WORKFLOWS")
    print("=" * 70)
    print("""
    1. FEATURE BRANCH WORKFLOW
    
    - Each feature in separate branch
    - Merge to main when complete
    - Main always deployable
    
    Workflow:
    main → feature/login → (develop, test) → merge to main
    main → feature/logout → (develop, test) → merge to main
    
    Pros: Simple, isolated development
    Cons: Merge conflicts if long-lived branches
    
    
    2. GITFLOW WORKFLOW
    
    Branches:
    • main: Production code
    • develop: Integration branch
    • feature/*: New features
    • release/*: Release preparation
    • hotfix/*: Production fixes
    
    Process:
    1. Feature branches from develop
    2. Merge features to develop
    3. Create release branch from develop
    4. Merge release to main and develop
    5. Hotfixes branch from main
    
    Pros: Structured, supports multiple versions
    Cons: Complex, more merge overhead
    
    
    3. GITHUB FLOW
    
    - Main branch always deployable
    - Create feature branch
    - Make pull request
    - Review and discuss
    - Deploy and test
    - Merge to main
    
    Pros: Simple, continuous deployment
    Cons: Less structure for complex projects
    
    
    4. TRUNK-BASED DEVELOPMENT
    
    - Everyone commits to main (trunk)
    - Very short-lived feature branches
    - Feature flags for incomplete features
    - Continuous integration
    
    Pros: Fast integration, less merge conflicts
    Cons: Requires discipline, good CI/CD
    
    
    BEST PRACTICES:
    
    Commit Messages:
    ✓ Use imperative mood ("Add feature" not "Added feature")
    ✓ First line: brief summary (50 chars)
    ✓ Blank line, then detailed description
    ✓ Reference issue numbers (#123)
    ✓ Explain why, not just what
    
    Example:
    Fix memory leak in image processor
    
    The image processor was not releasing buffers after processing,
    causing memory usage to grow unbounded in long-running processes.
    
    This adds proper cleanup in the destructor and after each
    processing cycle.
    
    Fixes #456
    
    
    Branching:
    ✓ Use descriptive names (feature/user-auth, fix/memory-leak)
    ✓ Keep branches short-lived
    ✓ Delete merged branches
    ✓ Pull before starting new work
    ✓ Rebase feature branches on main
    
    
    Pull Requests/Merge Requests:
    ✓ Write clear description
    ✓ Link related issues
    ✓ Request specific reviewers
    ✓ Address review comments
    ✓ Keep PRs focused and small
    ✓ Update branch before merging
    
    
    Code Review:
    ✓ Review code, not people
    ✓ Be constructive and specific
    ✓ Praise good practices
    ✓ Ask questions for understanding
    ✓ Approve only when ready
    
    
    General:
    ✓ Commit often, push regularly
    ✓ Write meaningful commit messages
    ✓ Test before committing
    ✓ Don't commit sensitive data
    ✓ Use .gitignore appropriately
    ✓ Keep main/master stable
    ✓ Tag releases
    ✓ Document your workflow
    """)
    print("=" * 70)


def explain_gitignore():
    """
    Explains .gitignore file for excluding files from version control.
    """
    print("\n" + "=" * 70)
    print(".GITIGNORE BEST PRACTICES")
    print("=" * 70)
    print("""
    What is .gitignore?
    - Specifies files Git should ignore
    - Prevents committing unwanted files
    - Pattern-based matching
    - One pattern per line
    
    Common Files to Ignore:
    
    # Compiled code
    *.pyc
    *.class
    *.o
    *.exe
    
    # Dependencies
    node_modules/
    venv/
    .env
    
    # IDE files
    .vscode/
    .idea/
    *.swp
    
    # OS files
    .DS_Store
    Thumbs.db
    
    # Build outputs
    dist/
    build/
    *.egg-info/
    
    # Logs
    *.log
    
    # Secrets
    .env
    secrets.yml
    *.key
    *.pem
    
    
    Pattern Syntax:
    
    # Comment
    *.txt           # All .txt files
    !important.txt  # Exception: don't ignore this
    folder/         # Entire folder
    /file.txt       # Only in root directory
    **/logs         # logs folder anywhere
    doc/*.pdf       # PDFs in doc/ only
    doc/**/*.pdf    # PDFs in doc/ and subdirectories
    
    
    Creating .gitignore:
    1. Create file named .gitignore in repo root
    2. Add patterns for files to ignore
    3. Commit .gitignore to repository
    
    
    Templates:
    GitHub provides templates:
    https://github.com/github/gitignore
    
    
    Already Tracked Files:
    If file is already tracked:
    git rm --cached <file>    # Remove from Git, keep local
    Then add to .gitignore
    """)
    print("=" * 70)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function for advanced Git topics.
    """
    print("\n" + "=" * 70)
    print("GIT ADVANCED WORKFLOWS - ADVANCED TUTORIAL")
    print("=" * 70)
    
    explain_rebase()
    input("\nPress Enter to learn about cherry-picking...")
    
    explain_cherry_pick()
    input("\nPress Enter to learn about stashing...")
    
    explain_stash()
    input("\nPress Enter to learn about tags...")
    
    explain_tags()
    input("\nPress Enter to learn about Git workflows...")
    
    explain_git_workflows()
    input("\nPress Enter to learn about .gitignore...")
    
    explain_gitignore()
    
    print("\n" + "=" * 70)
    print("TUTORIAL COMPLETE!")
    print("=" * 70)
    print("""
    Congratulations! You've completed the advanced Git tutorial.
    
    Key Concepts Covered:
    ✓ Rebase for clean history
    ✓ Cherry-pick for selective commits
    ✓ Stash for temporary storage
    ✓ Tags for releases
    ✓ Professional workflows
    ✓ Best practices
    
    Next Steps:
    1. Practice these advanced techniques
    2. Choose a workflow for your projects
    3. Learn about Git hooks
    4. Explore Git internals
    5. Contribute to open source
    
    Practice Exercises:
    - See exercises_03_advanced.py
    
    Remember:
    • Commit early, commit often
    • Write clear commit messages
    • Keep branches focused
    • Review before pushing
    • Learn from others' code
    """)


if __name__ == "__main__":
    main()
