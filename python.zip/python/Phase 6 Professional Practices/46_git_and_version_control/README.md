# Git & Version Control - Complete Educational Package

## 📚 Overview

This comprehensive educational package provides a complete curriculum for teaching Git and version control to undergraduate computer science students in a one-year Python course. The materials progress from fundamental concepts through advanced professional workflows, with extensive code comments, practical examples, and hands-on exercises.

## 🎯 Learning Objectives

By completing this package, students will:

- **Understand** version control fundamentals and distributed systems
- **Master** basic Git operations (init, add, commit, status, log)
- **Create and manage** branches for parallel development
- **Resolve** merge conflicts effectively
- **Collaborate** using remote repositories
- **Apply** advanced techniques (rebase, cherry-pick, stash)
- **Implement** professional Git workflows
- **Follow** industry best practices and conventions

## 📦 Package Contents

### Tutorial Files (Progressive Difficulty)

#### 1. **01_git_basics_beginner.py**
   - **Level**: Beginner
   - **Topics Covered**:
     - Version control concepts and benefits
     - Repository initialization
     - Staging and committing files
     - Viewing status and history
     - Understanding diffs
     - Complete workflow demonstration
   - **Line Count**: ~950 lines of heavily commented code
   - **Duration**: 60-90 minutes

#### 2. **02_git_branching_intermediate.py**
   - **Level**: Intermediate
   - **Topics Covered**:
     - Branch concepts and operations
     - Creating and switching branches
     - Merging strategies (fast-forward, three-way)
     - Handling merge conflicts
     - Branch management and cleanup
     - Complete branching workflow
   - **Line Count**: ~900 lines of heavily commented code
   - **Duration**: 75-100 minutes

#### 3. **03_git_remotes_intermediate.py**
   - **Level**: Intermediate
   - **Topics Covered**:
     - Distributed version control concepts
     - Cloning repositories
     - Remote management (add, remove, rename)
     - Fetch vs pull operations
     - Pushing changes
     - Complete remote workflow
   - **Line Count**: ~850 lines of heavily commented code
   - **Duration**: 75-100 minutes

#### 4. **04_git_advanced_workflows.py**
   - **Level**: Advanced
   - **Topics Covered**:
     - Git rebase and history manipulation
     - Cherry-picking commits
     - Stashing changes
     - Tagging and releases
     - Professional workflows (Feature Branch, Gitflow, GitHub Flow)
     - Best practices and .gitignore
   - **Line Count**: ~650 lines of heavily commented code
   - **Duration**: 90-120 minutes

### Exercise Files

#### 1. **exercises_01_basics.py**
   - 5 structured exercises
   - 3 challenge problems
   - Covers: initialization, commits, status, diff, complete workflows
   - Includes solution templates and test cases

#### 2. **exercises_02_intermediate.py**
   - 5 structured exercises
   - 3 challenge problems
   - Covers: branching, merging, conflicts, remotes, collaboration
   - More open-ended problem solving

#### 3. **exercises_03_advanced.py**
   - 5 structured exercises
   - 4 challenge problems
   - Covers: rebase, cherry-pick, stash, releases, professional workflows
   - Professional-level implementations

## 🚀 Getting Started

### Prerequisites

#### System Requirements
- Python 3.7 or higher
- Git 2.20 or higher installed and accessible via command line
- Terminal/Command Prompt access
- Text editor or IDE

#### Checking Git Installation

```bash
# Check if Git is installed
git --version

# Should output something like: git version 2.x.x
```

#### Installing Git

**Linux (Ubuntu/Debian)**:
```bash
sudo apt-get update
sudo apt-get install git
```

**macOS**:
```bash
# Using Homebrew
brew install git

# Or install Xcode Command Line Tools
xcode-select --install
```

**Windows**:
- Download from https://git-scm.com/download/win
- Run installer with default settings

### Installation

1. **Extract the Package**
   ```bash
   unzip git_version_control_package.zip
   cd git_version_control_package
   ```

2. **Verify Python**
   ```bash
   python --version
   # or
   python3 --version
   ```

3. **Test Basic Functionality**
   ```bash
   python 01_git_basics_beginner.py
   ```

## 📖 Usage Guide

### For Instructors

#### Suggested Teaching Schedule (One-Year Course)

**Semester 1 - Fundamentals**
- Week 1-2: Introduction and Basic Operations (01_git_basics_beginner.py)
  - Lecture: Version control concepts
  - Lab: Repository creation and commits
  - Homework: exercises_01_basics.py (exercises 1-3)

- Week 3-4: Branching (02_git_branching_intermediate.py)
  - Lecture: Parallel development concepts
  - Lab: Creating and merging branches
  - Homework: exercises_02_intermediate.py (exercises 1-2)

- Week 5-6: Merge Conflicts
  - Lecture: Conflict resolution strategies
  - Lab: Simulated conflict scenarios
  - Homework: exercises_02_intermediate.py (exercise 3)

**Semester 2 - Collaboration & Advanced Topics**
- Week 1-2: Remote Repositories (03_git_remotes_intermediate.py)
  - Lecture: Distributed workflows
  - Lab: GitHub/GitLab setup and cloning
  - Homework: exercises_02_intermediate.py (exercises 4-5)

- Week 3-4: Advanced Techniques (04_git_advanced_workflows.py)
  - Lecture: Rebase, cherry-pick, stash
  - Lab: History manipulation practice
  - Homework: exercises_03_advanced.py (exercises 1-3)

- Week 5-6: Professional Workflows
  - Lecture: Industry practices
  - Lab: Implement workflow in group project
  - Homework: exercises_03_advanced.py (exercises 4-5)

#### Classroom Activities

1. **Live Coding Sessions**: Run tutorial files in class, pause for questions
2. **Pair Programming**: Students work through exercises together
3. **Code Reviews**: Practice reviewing each other's Git commits
4. **Group Projects**: Apply Git workflows in team settings
5. **Lightning Talks**: Students present Git features they learned

#### Assessment Ideas

- **Quizzes**: Based on concepts in tutorial files
- **Practical Exams**: Perform Git operations under time constraints
- **Project Evaluation**: Grade on commit quality, branch usage, workflow
- **Peer Reviews**: Students review each other's Git practices
- **Portfolio**: Maintain semester-long project demonstrating all skills

### For Students

#### Study Path

**Beginner (Weeks 1-2)**
1. Read 01_git_basics_beginner.py thoroughly
2. Run the demonstrations
3. Complete exercises_01_basics.py (exercises 1-5)
4. Practice with your own test repository

**Intermediate (Weeks 3-6)**
1. Study 02_git_branching_intermediate.py
2. Study 03_git_remotes_intermediate.py
3. Complete exercises_02_intermediate.py (all exercises)
4. Create GitHub account and practice with remote repos

**Advanced (Weeks 7-12)**
1. Master 04_git_advanced_workflows.py
2. Complete exercises_03_advanced.py (all exercises)
3. Attempt challenge problems
4. Contribute to open source projects

#### Self-Study Tips

- **Type, Don't Copy**: Manually type code examples to build muscle memory
- **Experiment Safely**: Use temporary directories for practice
- **Break Things**: Learn by making mistakes in safe environments
- **Read Error Messages**: Git's error messages are educational
- **Visualize**: Draw branch diagrams while learning
- **Practice Daily**: Spend 15-30 minutes daily rather than cramming
- **Teach Others**: Explaining concepts reinforces learning

#### Common Pitfalls to Avoid

❌ **Don't**:
- Force push to shared branches (`git push -f`)
- Commit sensitive information (passwords, API keys)
- Work directly on main/master branch
- Ignore merge conflicts
- Create massive commits mixing multiple features
- Use Git without understanding commands

✅ **Do**:
- Commit early and often
- Write descriptive commit messages
- Pull before pushing
- Use .gitignore appropriately
- Create feature branches
- Test before committing

## 🎓 Course Integration

### Suggested Grading Rubric

**Git Usage in Projects (30% of project grade)**
- Commit Quality (10 points)
  - Descriptive messages
  - Logical units of work
  - Proper attribution
  
- Branch Usage (10 points)
  - Appropriate branch naming
  - Feature isolation
  - Clean merges
  
- Collaboration (10 points)
  - Regular commits
  - Pull requests (if applicable)
  - Conflict resolution

**Practical Assessments (20% of course grade)**
- Exercise completion
- Challenge problems
- Practical exams

### Learning Outcomes Mapping

This package supports achievement of:
- **ABET Student Outcome 2**: Design and conduct experiments, analyze data
- **ABET Student Outcome 5**: Ability to function on multidisciplinary teams
- **ABET Student Outcome 6**: Professional and ethical responsibility
- **ACM CS2013 SE/Software Engineering**: Configuration management

## 🛠️ Technical Details

### Code Structure

All tutorial files follow consistent patterns:

```python
# 1. Module docstring with learning objectives
"""
Module description
Learning objectives
Prerequisites
"""

# 2. Imports
import subprocess
import os
# ... etc

# 3. Sectioned content with clear headers
# =============================================================================
# SECTION: Topic Name
# =============================================================================

# 4. Explanatory functions
def explain_concept():
    """Detailed explanation with visualizations"""
    print("Concept explanation...")

# 5. Implementation functions
def git_operation(repo_path: str) -> bool:
    """
    Heavily commented implementation
    
    Args:
        repo_path: Description
    
    Returns:
        Description
        
    Git Command Equivalent:
        git command
    """
    # Detailed comments for each step
    pass

# 6. Demonstration functions
def demonstrate_workflow():
    """Complete working example"""
    pass

# 7. Main execution
if __name__ == "__main__":
    main()
```

### Design Principles

1. **Heavy Commenting**: Every 2-3 lines of code have explanatory comments
2. **Progressive Difficulty**: Each file builds on previous knowledge
3. **Practical Examples**: Working demonstrations that students can run
4. **Error Handling**: Shows how to handle Git command failures
5. **Best Practices**: Models professional coding standards
6. **Subprocess Usage**: Direct Git command execution for transparency

### Key Features

- **Self-Contained**: Each file can be run independently
- **No External Dependencies**: Only Python stdlib and Git
- **Cross-Platform**: Works on Windows, macOS, and Linux
- **Safe Practice**: Uses temporary directories for demonstrations
- **Extensive Documentation**: Comments explain both Python and Git
- **ASCII Visualizations**: Branch diagrams for visual learners

## 📚 Additional Resources

### Official Documentation
- **Git Official**: https://git-scm.com/doc
- **Pro Git Book**: https://git-scm.com/book/en/v2 (Free online)
- **Git Reference**: https://git-scm.com/docs

### Interactive Learning
- **Learn Git Branching**: https://learngitbranching.js.org/
- **GitHub Learning Lab**: https://lab.github.com/
- **Atlassian Git Tutorials**: https://www.atlassian.com/git/tutorials

### Video Tutorials
- **Git & GitHub Crash Course**: FreeCodeCamp on YouTube
- **Git Tutorial for Beginners**: Corey Schafer on YouTube
- **Advanced Git Tutorials**: The Net Ninja on YouTube

### Cheat Sheets
- **GitHub Git Cheat Sheet**: https://education.github.com/git-cheat-sheet-education.pdf
- **Atlassian Git Cheat Sheet**: https://www.atlassian.com/git/tutorials/atlassian-git-cheatsheet
- **GitLab Git Cheat Sheet**: https://about.gitlab.com/images/press/git-cheat-sheet.pdf

### Books
- "Pro Git" by Scott Chacon and Ben Straub (Free online)
- "Version Control with Git" by Jon Loeliger and Matthew McCullough
- "Git Pocket Guide" by Richard E. Silverman

## 🤝 Contributing & Support

### For Instructors Using This Package

We welcome feedback and contributions:

- **Bug Reports**: If you find errors in code or documentation
- **Enhancement Requests**: Suggestions for additional content
- **Success Stories**: Share how you used this in your course
- **Exercise Solutions**: Contribute model solutions for exercises

### Customization

This package is designed to be customized:

- Modify examples to match your course context
- Add institution-specific workflows
- Integrate with your learning management system
- Adapt difficulty levels for your students

## 📝 License

This educational package is provided for academic use. Instructors are free to:
- Use in their courses
- Modify content
- Share with students
- Adapt for their institution

Please maintain attribution when using or adapting this material.

## 🙏 Acknowledgments

This package was created to support undergraduate computer science education, emphasizing:
- Practical, hands-on learning
- Progressive skill development
- Industry-relevant practices
- Accessible explanations

Special thanks to the Git community for excellent documentation that informed this curriculum.

## 📧 Contact & Support

For questions about using this package in your course:
- Review the README thoroughly
- Check the comments in tutorial files
- Refer to official Git documentation for command details

---

## Quick Reference Commands

### Basic Operations
```bash
git init                    # Initialize repository
git add <file>             # Stage file
git commit -m "message"    # Commit changes
git status                 # Check status
git log                    # View history
```

### Branching
```bash
git branch <name>          # Create branch
git checkout <name>        # Switch branch
git checkout -b <name>     # Create and switch
git merge <name>           # Merge branch
git branch -d <name>       # Delete branch
```

### Remote Operations
```bash
git clone <url>            # Clone repository
git remote -v              # List remotes
git fetch origin           # Fetch changes
git pull origin main       # Pull and merge
git push origin main       # Push changes
```

### Advanced
```bash
git rebase <branch>        # Rebase onto branch
git cherry-pick <hash>     # Apply specific commit
git stash                  # Stash changes
git stash pop              # Apply stashed changes
git tag v1.0.0             # Create tag
```

---

**Happy Learning! Master Git and become a more effective developer! 🚀**
