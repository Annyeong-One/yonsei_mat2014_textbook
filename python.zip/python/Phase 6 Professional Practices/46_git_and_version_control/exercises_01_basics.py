"""
Git & Version Control - Exercise Set 1: Basics
==============================================

These exercises provide hands-on practice with fundamental Git operations.
Work through them sequentially, as each builds on previous concepts.

Instructions:
- Read each exercise carefully
- Implement the solution
- Run your code to verify it works
- Compare with expected outcomes
- Challenge yourself with bonus questions

Level: Beginner
Estimated Time: 45-60 minutes
"""

import subprocess
import os
import tempfile
import shutil
from pathlib import Path


# =============================================================================
# EXERCISE 1: Repository Initialization and Configuration
# =============================================================================

def exercise_1_init_and_config():
    """
    EXERCISE 1: Initialize a Repository and Configure User
    
    Task:
    Create a function that:
    1. Creates a new directory at the given path
    2. Initializes a Git repository in that directory
    3. Configures the user name as "Student User"
    4. Configures the user email as "student@university.edu"
    5. Returns True if all operations succeed, False otherwise
    
    Function Signature:
        def setup_repository(repo_path: str) -> bool:
            # Your code here
            pass
    
    Test Your Solution:
        temp_dir = tempfile.mkdtemp()
        success = setup_repository(temp_dir)
        print(f"Setup successful: {success}")
    
    Expected Output:
        ✓ Directory created
        ✓ Repository initialized
        ✓ User configured
        Setup successful: True
    
    Hint:
        - Use os.makedirs() to create directory
        - Use subprocess.run() to execute Git commands
        - Git commands: 'git init', 'git config user.name', 'git config user.email'
    """
    print("=" * 70)
    print("EXERCISE 1: Repository Initialization and Configuration")
    print("=" * 70)
    print(__doc__)
    print("\n[Your implementation goes here]")
    print("\n")
    
    # Solution template (students should implement)
    def setup_repository(repo_path: str) -> bool:
        """
        Initialize a Git repository and configure user.
        
        Args:
            repo_path: Path where repository should be created
            
        Returns:
            bool: True if successful, False otherwise
        """
        try:
            # TODO: Create directory
            # TODO: Initialize Git repository
            # TODO: Configure user.name
            # TODO: Configure user.email
            # TODO: Return success status
            pass
        except Exception as e:
            print(f"Error: {e}")
            return False
    
    # Test code (uncomment to test your solution)
    # temp_dir = tempfile.mkdtemp(prefix='git_ex1_')
    # try:
    #     success = setup_repository(temp_dir)
    #     print(f"\nSetup successful: {success}")
    # finally:
    #     shutil.rmtree(temp_dir, ignore_errors=True)


# =============================================================================
# EXERCISE 2: Adding and Committing Files
# =============================================================================

def exercise_2_add_commit():
    """
    EXERCISE 2: Create, Add, and Commit Files
    
    Task:
    Write a function that:
    1. Creates a file with given name and content
    2. Stages the file (git add)
    3. Commits the file with given commit message
    4. Returns the commit hash
    
    Function Signature:
        def create_and_commit_file(repo_path: str, filename: str, 
                                   content: str, message: str) -> str:
            # Your code here
            pass
    
    Test Your Solution:
        # Assume repository already initialized
        hash1 = create_and_commit_file(
            repo_path, 
            "hello.py",
            'print("Hello, Git!")',
            "Initial commit"
        )
        print(f"Commit hash: {hash1}")
        
        hash2 = create_and_commit_file(
            repo_path,
            "goodbye.py", 
            'print("Goodbye!")',
            "Add goodbye script"
        )
        print(f"Commit hash: {hash2}")
    
    Expected Output:
        ✓ File hello.py created
        ✓ File staged
        ✓ Changes committed
        Commit hash: abc1234...
        
        ✓ File goodbye.py created
        ✓ File staged
        ✓ Changes committed
        Commit hash: def5678...
    
    Bonus Challenge:
        Modify the function to handle multiple files at once:
        def create_and_commit_files(repo_path: str, 
                                    files: dict,  # {filename: content}
                                    message: str) -> str:
    """
    print("=" * 70)
    print("EXERCISE 2: Adding and Committing Files")
    print("=" * 70)
    print(__doc__)
    print("\n[Your implementation goes here]")
    print("\n")


# =============================================================================
# EXERCISE 3: Working with Git Status and Log
# =============================================================================

def exercise_3_status_and_log():
    """
    EXERCISE 3: Check Status and View History
    
    Task:
    Create a function that:
    1. Shows the current status of the repository
    2. Counts and returns the number of untracked files
    3. Counts and returns the number of modified files
    4. Counts and returns the total number of commits
    
    Function Signature:
        def analyze_repository(repo_path: str) -> dict:
            # Your code here
            # Return dict with keys: 'untracked', 'modified', 'commits'
            pass
    
    Test Your Solution:
        # Create some files without committing
        Path(repo_path, "temp1.txt").touch()
        Path(repo_path, "temp2.txt").touch()
        
        # Modify existing file
        with open(Path(repo_path, "hello.py"), 'a') as f:
            f.write('\nprint("Modified")')
        
        stats = analyze_repository(repo_path)
        print(f"Untracked files: {stats['untracked']}")
        print(f"Modified files: {stats['modified']}")
        print(f"Total commits: {stats['commits']}")
    
    Expected Output:
        Untracked files: 2
        Modified files: 1
        Total commits: 2
    
    Hints:
        - Use 'git status --porcelain' for machine-readable output
        - Untracked files start with '??'
        - Modified files start with ' M'
        - Use 'git rev-list --count HEAD' to count commits
    
    Bonus Challenge:
        Add functionality to also return:
        - Staged files count
        - Current branch name
        - Is working directory clean? (boolean)
    """
    print("=" * 70)
    print("EXERCISE 3: Working with Git Status and Log")
    print("=" * 70)
    print(__doc__)
    print("\n[Your implementation goes here]")
    print("\n")


# =============================================================================
# EXERCISE 4: Viewing Changes with Git Diff
# =============================================================================

def exercise_4_diff():
    """
    EXERCISE 4: Compare File Changes
    
    Task:
    Write a function that:
    1. Modifies an existing file
    2. Shows the diff (unstaged changes)
    3. Stages the changes
    4. Shows the staged diff
    5. Commits the changes
    
    Function Signature:
        def modify_and_track_changes(repo_path: str, filename: str,
                                     new_content: str, message: str) -> bool:
            # Your code here
            pass
    
    Workflow:
        1. Read existing file
        2. Append new content
        3. Show unstaged diff
        4. Stage changes
        5. Show staged diff
        6. Commit
    
    Test Your Solution:
        success = modify_and_track_changes(
            repo_path,
            "hello.py",
            '\n# Added new comment\nprint("Updated version")',
            "Update hello.py with new features"
        )
        print(f"Success: {success}")
    
    Expected Output:
        === Unstaged Changes ===
        +# Added new comment
        +print("Updated version")
        
        === Staged Changes ===
        +# Added new comment
        +print("Updated version")
        
        ✓ Changes committed
        Success: True
    
    Hints:
        - Use 'git diff' for unstaged changes
        - Use 'git diff --staged' for staged changes
        - Check if diff output is empty to verify state
    """
    print("=" * 70)
    print("EXERCISE 4: Viewing Changes with Git Diff")
    print("=" * 70)
    print(__doc__)
    print("\n[Your implementation goes here]")
    print("\n")


# =============================================================================
# EXERCISE 5: Complete Git Workflow
# =============================================================================

def exercise_5_complete_workflow():
    """
    EXERCISE 5: Implement Complete Git Workflow
    
    Task:
    Create a comprehensive function that simulates a complete development cycle:
    
    1. Initialize repository
    2. Create initial project structure:
       - README.md with project description
       - .gitignore with common Python patterns
       - main.py with basic code
    3. Make initial commit
    4. Make multiple changes:
       - Update README.md
       - Modify main.py
       - Add new file utils.py
    5. Stage and commit each change separately with descriptive messages
    6. Display final commit history
    
    Function Signature:
        def complete_project_workflow(base_path: str, 
                                      project_name: str) -> str:
            '''
            Create a complete project with Git history.
            
            Returns:
                Path to created project directory
            '''
            pass
    
    Test Your Solution:
        project_path = complete_project_workflow(
            tempfile.gettempdir(),
            "my_python_project"
        )
        print(f"Project created at: {project_path}")
        
        # Verify repository
        # Should have:
        # - At least 4 commits
        # - 4 files (README.md, .gitignore, main.py, utils.py)
        # - Clean working directory
    
    Expected Commit History:
        abc1234 Add utility functions
        def5678 Update main.py with new features
        ghi9012 Update README with detailed description
        jkl3456 Initial commit: project structure
    
    Hints:
        - Break down into smaller functions
        - Commit after each logical change
        - Use meaningful commit messages
        - Verify each step before proceeding
    
    Bonus Challenges:
        1. Add error handling for each step
        2. Return statistics (number of commits, files, etc.)
        3. Create a function to verify the repository is valid
        4. Add functionality to create additional branches
    """
    print("=" * 70)
    print("EXERCISE 5: Complete Git Workflow")
    print("=" * 70)
    print(__doc__)
    print("\n[Your implementation goes here]")
    print("\n")


# =============================================================================
# CHALLENGE EXERCISES
# =============================================================================

def challenge_exercise_1():
    """
    CHALLENGE 1: Git Log Parser
    
    Task:
    Write a function that parses git log output and extracts:
    - Commit hash
    - Author name
    - Date
    - Commit message
    
    Return as list of dictionaries.
    
    Function Signature:
        def parse_git_log(repo_path: str, max_count: int = 10) -> list:
            '''
            Returns list of dicts with keys:
            'hash', 'author', 'date', 'message'
            '''
            pass
    
    Hint:
        Use 'git log --format=...' with custom format
        Format specifiers: %H (hash), %an (author), %ad (date), %s (subject)
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 1: Git Log Parser")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_2():
    """
    CHALLENGE 2: Commit Statistics
    
    Task:
    Analyze a repository and produce statistics:
    - Total number of commits
    - Number of files tracked
    - Lines added vs deleted (from git log --stat)
    - Most frequently modified files
    - Commit frequency by day of week
    
    Function Signature:
        def repository_statistics(repo_path: str) -> dict:
            '''
            Returns dict with repository statistics
            '''
            pass
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 2: Commit Statistics")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_3():
    """
    CHALLENGE 3: Interactive Git Tutorial
    
    Task:
    Create an interactive tutorial that:
    1. Creates a temporary repository
    2. Guides user through Git commands
    3. Validates each step
    4. Provides feedback
    5. Tracks progress
    
    Should cover:
    - Repository initialization
    - Creating and committing files
    - Viewing history
    - Making changes
    - Understanding Git states
    
    Be creative with your implementation!
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 3: Interactive Git Tutorial")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function to run all exercises.
    """
    print("\n" + "=" * 70)
    print("GIT BASICS - EXERCISE SET 1")
    print("=" * 70)
    print("""
    Welcome to Git Basics Exercises!
    
    This exercise set covers fundamental Git operations:
    - Repository initialization
    - Adding and committing files
    - Checking status and viewing history
    - Working with diffs
    - Complete workflows
    
    Instructions:
    1. Read each exercise carefully
    2. Implement the solution in the provided template
    3. Test your code
    4. Verify the output matches expected results
    
    Tips:
    - Use subprocess.run() to execute Git commands
    - Check return codes for errors
    - Add proper error handling
    - Test incrementally
    
    Uncomment individual exercises to work on them.
    """)
    
    # Uncomment to work on specific exercises
    # exercise_1_init_and_config()
    # exercise_2_add_commit()
    # exercise_3_status_and_log()
    # exercise_4_diff()
    # exercise_5_complete_workflow()
    
    # Challenge exercises
    # challenge_exercise_1()
    # challenge_exercise_2()
    # challenge_exercise_3()
    
    print("\n" + "=" * 70)
    print("Ready to begin? Uncomment an exercise and start coding!")
    print("=" * 70)


if __name__ == "__main__":
    main()
