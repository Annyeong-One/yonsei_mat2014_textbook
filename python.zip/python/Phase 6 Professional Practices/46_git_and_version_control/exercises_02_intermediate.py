"""
Git & Version Control - Exercise Set 2: Intermediate
====================================================

These exercises focus on branching, merging, and remote repositories.
More challenging than Exercise Set 1, requiring understanding of
Git's branching model and collaboration workflows.

Instructions:
- Complete Exercise Set 1 before attempting these
- Test each solution thoroughly
- Handle edge cases and errors
- Practice merge conflict resolution

Level: Intermediate
Estimated Time: 60-90 minutes
"""

import subprocess
import tempfile
import shutil
from pathlib import Path


# =============================================================================
# EXERCISE 1: Branch Creation and Management
# =============================================================================

def exercise_1_branches():
    """
    EXERCISE 1: Branch Creation, Switching, and Management
    
    Task:
    Implement a class to manage Git branches:
    
    class BranchManager:
        def __init__(self, repo_path: str):
            self.repo_path = repo_path
        
        def create_branch(self, name: str) -> bool:
            '''Create new branch'''
            pass
        
        def switch_branch(self, name: str) -> bool:
            '''Switch to branch'''
            pass
        
        def list_branches(self) -> list:
            '''Return list of all branches'''
            pass
        
        def current_branch(self) -> str:
            '''Return current branch name'''
            pass
        
        def delete_branch(self, name: str, force: bool = False) -> bool:
            '''Delete branch'''
            pass
    
    Test Your Solution:
        manager = BranchManager(repo_path)
        manager.create_branch('feature/new-ui')
        manager.switch_branch('feature/new-ui')
        current = manager.current_branch()
        branches = manager.list_branches()
        
    Expected Behavior:
        - Create branch without switching
        - Switch between branches
        - List all local branches
        - Identify current branch
        - Delete branches safely
    
    Bonus:
        - Add method to create and switch in one call
        - Add method to rename branches
        - Handle errors gracefully
    """
    print("=" * 70)
    print("EXERCISE 1: Branch Creation and Management")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 2: Merging Branches
# =============================================================================

def exercise_2_merging():
    """
    EXERCISE 2: Branch Merging Workflow
    
    Task:
    Create a function that implements a complete feature branch workflow:
    
    def feature_branch_workflow(repo_path: str, 
                                feature_name: str,
                                files_to_create: dict) -> bool:
        '''
        1. Create feature branch
        2. Switch to feature branch
        3. Create specified files
        4. Commit changes
        5. Switch back to main
        6. Merge feature branch
        7. Delete feature branch
        
        Args:
            repo_path: Repository path
            feature_name: Name for feature branch
            files_to_create: Dict of {filename: content}
        
        Returns:
            True if workflow completes successfully
        '''
        pass
    
    Test Your Solution:
        success = feature_branch_workflow(
            repo_path,
            'feature/authentication',
            {
                'auth.py': 'def login():\n    pass',
                'test_auth.py': 'def test_login():\n    pass'
            }
        )
        
    Expected Outcome:
        - Feature branch created and used
        - Files committed to feature branch
        - Clean merge to main
        - Feature branch deleted
        - Main contains new files
    
    Bonus Challenges:
        1. Add option for fast-forward or create merge commit
        2. Simulate and handle merge conflict
        3. Add rollback capability if merge fails
    """
    print("=" * 70)
    print("EXERCISE 2: Merging Branches")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 3: Conflict Resolution
# =============================================================================

def exercise_3_conflicts():
    """
    EXERCISE 3: Handling Merge Conflicts
    
    Task:
    Create a scenario generator and conflict resolver:
    
    def create_conflict_scenario(repo_path: str):
        '''
        Creates a merge conflict scenario:
        1. Create file on main
        2. Commit
        3. Create feature branch
        4. Modify file on main
        5. Commit main
        6. Switch to feature
        7. Modify same file differently
        8. Commit feature
        9. Attempt merge (will conflict)
        '''
        pass
    
    def detect_conflicts(repo_path: str) -> list:
        '''
        Returns list of files with conflicts
        '''
        pass
    
    def resolve_conflict(repo_path: str, 
                        filename: str,
                        resolution: str) -> bool:
        '''
        Resolves conflict by writing resolution to file
        and staging it.
        '''
        pass
    
    Test Your Solution:
        create_conflict_scenario(repo_path)
        conflicts = detect_conflicts(repo_path)
        print(f"Conflicts in: {conflicts}")
        
        for file in conflicts:
            # Read conflict markers
            # Decide resolution
            resolve_conflict(repo_path, file, "resolved content")
        
        # Complete merge
    
    Learning Goals:
        - Understand how conflicts occur
        - Identify conflict markers
        - Resolve conflicts programmatically
        - Complete merge after resolution
    
    Bonus:
        Create different conflict types:
        - Content conflicts
        - Delete vs modify conflicts
        - Rename conflicts
    """
    print("=" * 70)
    print("EXERCISE 3: Handling Merge Conflicts")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 4: Remote Repository Simulation
# =============================================================================

def exercise_4_remotes():
    """
    EXERCISE 4: Working with Remote Repositories
    
    Task:
    Simulate remote repository operations:
    
    def simulate_remote_workflow(base_path: str) -> dict:
        '''
        1. Create "remote" bare repository
        2. Clone it to create "local" repository
        3. Make changes in local
        4. Push to remote
        5. Clone to create second "local" repository
        6. Make changes in second local
        7. Push to remote
        8. Pull changes in first local
        
        Returns:
            Dict with paths to remote and both locals
        '''
        pass
    
    def push_changes(local_path: str, remote_name: str = 'origin') -> bool:
        '''Push local commits to remote'''
        pass
    
    def pull_changes(local_path: str, remote_name: str = 'origin') -> bool:
        '''Pull and merge remote changes'''
        pass
    
    def fetch_changes(local_path: str, remote_name: str = 'origin') -> bool:
        '''Fetch without merging'''
        pass
    
    Test Your Solution:
        paths = simulate_remote_workflow(temp_dir)
        
        # Make change in first local
        # Push changes
        push_changes(paths['local1'])
        
        # Pull in second local
        pull_changes(paths['local2'])
        
        # Verify second local has changes
    
    Learning Goals:
        - Understand distributed nature of Git
        - Practice push/pull workflow
        - Experience collaboration simulation
    
    Bonus:
        - Handle push rejection (remote ahead)
        - Implement fetch + merge vs pull
        - Add multiple remotes (origin, upstream)
    """
    print("=" * 70)
    print("EXERCISE 4: Working with Remote Repositories")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 5: Complete Collaboration Workflow
# =============================================================================

def exercise_5_collaboration():
    """
    EXERCISE 5: Multi-Developer Collaboration Simulation
    
    Task:
    Simulate collaboration between two developers:
    
    class Developer:
        def __init__(self, name: str, email: str, repo_path: str):
            self.name = name
            self.email = email
            self.repo_path = repo_path
            self.configure_git()
        
        def configure_git(self):
            '''Set user name and email'''
            pass
        
        def create_feature_branch(self, feature_name: str):
            '''Create and switch to feature branch'''
            pass
        
        def make_changes(self, files: dict):
            '''Create/modify files and commit'''
            pass
        
        def push_branch(self):
            '''Push current branch to remote'''
            pass
        
        def pull_changes(self):
            '''Pull changes from remote'''
            pass
    
    def simulate_collaboration(base_path: str):
        '''
        1. Create remote repository
        2. Create two developers with clones
        3. Dev1 creates feature, pushes
        4. Dev2 pulls, creates different feature, pushes
        5. Dev1 pulls Dev2's changes
        6. Both merge to main
        '''
        pass
    
    Test Your Solution:
        simulate_collaboration(temp_dir)
        
        # Should demonstrate:
        # - Multiple developers working independently
        # - Pushing and pulling changes
        # - Branch-based development
        # - Merging to main branch
    
    Bonus Challenges:
        1. Simulate pull request workflow
        2. Add code review simulation
        3. Handle merge conflicts between developers
        4. Track who made which changes
    """
    print("=" * 70)
    print("EXERCISE 5: Complete Collaboration Workflow")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# CHALLENGE EXERCISES
# =============================================================================

def challenge_exercise_1():
    """
    CHALLENGE 1: Branch Visualization
    
    Task:
    Create ASCII visualization of branch structure:
    
    def visualize_branches(repo_path: str) -> str:
        '''
        Returns ASCII art showing:
        - All branches
        - Commit relationships
        - Merge points
        - Current branch
        
        Example output:
        * commit D (HEAD -> feature)
        * commit C
        | * commit F (main)
        | * commit E
        |/
        * commit B
        * commit A
        '''
        pass
    
    Hint: Use 'git log --all --graph --oneline'
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 1: Branch Visualization")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_2():
    """
    CHALLENGE 2: Automated Merge Strategy
    
    Task:
    Implement intelligent merge conflict resolver:
    
    def smart_merge(repo_path: str, branch_name: str,
                   strategy: str = 'ours') -> bool:
        '''
        Attempt merge with automatic conflict resolution:
        - 'ours': Keep current branch version
        - 'theirs': Take incoming branch version
        - 'both': Keep both versions
        - 'interactive': Prompt user for each conflict
        '''
        pass
    
    Should handle various conflict types intelligently.
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 2: Automated Merge Strategy")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_3():
    """
    CHALLENGE 3: Git Workflow Simulator
    
    Task:
    Create interactive simulator for different Git workflows:
    - Feature Branch Workflow
    - Gitflow Workflow
    - GitHub Flow
    
    Should:
    - Visualize each workflow
    - Allow user to practice
    - Validate correct command sequence
    - Provide feedback and hints
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 3: Git Workflow Simulator")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function for intermediate exercises.
    """
    print("\n" + "=" * 70)
    print("GIT INTERMEDIATE - EXERCISE SET 2")
    print("=" * 70)
    print("""
    Welcome to Git Intermediate Exercises!
    
    This exercise set covers:
    - Branch creation and management
    - Merging strategies
    - Conflict resolution
    - Remote repository operations
    - Collaboration workflows
    
    Prerequisites:
    - Completed Exercise Set 1
    - Understanding of basic Git commands
    - Familiarity with branches concept
    
    Tips:
    - Test thoroughly with different scenarios
    - Handle edge cases (empty repos, conflicts, etc.)
    - Add error handling
    - Create helper functions for reusable code
    
    Uncomment exercises to work on them.
    """)
    
    # Uncomment to work on exercises
    # exercise_1_branches()
    # exercise_2_merging()
    # exercise_3_conflicts()
    # exercise_4_remotes()
    # exercise_5_collaboration()
    
    # Challenge exercises
    # challenge_exercise_1()
    # challenge_exercise_2()
    # challenge_exercise_3()
    
    print("\n" + "=" * 70)
    print("Ready to advance your Git skills? Start coding!")
    print("=" * 70)


if __name__ == "__main__":
    main()
