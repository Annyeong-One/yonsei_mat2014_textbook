"""
Git & Version Control - Exercise Set 3: Advanced
================================================

These exercises cover advanced Git techniques including rebase,
cherry-pick, stash, tags, and professional workflows. Designed for
students ready to master Git at a professional level.

Instructions:
- Complete Exercise Sets 1 and 2 first
- These exercises are more open-ended
- Focus on understanding WHY, not just HOW
- Practice until workflows become natural

Level: Advanced
Estimated Time: 90-120 minutes
"""

import subprocess
import tempfile
from pathlib import Path


# =============================================================================
# EXERCISE 1: Git Rebase Workflow
# =============================================================================

def exercise_1_rebase():
    """
    EXERCISE 1: Interactive Rebase and History Cleanup
    
    Task:
    Implement functions demonstrating rebase operations:
    
    def rebase_feature_on_main(repo_path: str, feature_branch: str) -> bool:
        '''
        Rebase feature branch onto latest main.
        
        Steps:
        1. Checkout feature branch
        2. Rebase onto main
        3. Handle any conflicts
        4. Verify linear history
        '''
        pass
    
    def interactive_rebase_cleanup(repo_path: str, num_commits: int):
        '''
        Use interactive rebase to:
        - Reorder commits
        - Squash related commits
        - Edit commit messages
        - Drop unnecessary commits
        
        Hint: Can't directly automate interactive rebase,
        but can prepare scenarios and demonstrate process
        '''
        pass
    
    def compare_merge_vs_rebase(base_path: str) -> dict:
        '''
        Create two scenarios:
        1. Same changes merged
        2. Same changes rebased
        
        Compare resulting histories
        
        Returns:
            Dict with commit counts, graph structure
        '''
        pass
    
    Test Your Solution:
        # Create scenario with diverged branches
        # Rebase feature onto main
        # Verify linear history
        # Compare with merge approach
    
    Learning Goals:
        - Understand rebase mechanics
        - Know when to use rebase vs merge
        - Master conflict resolution during rebase
        - Appreciate clean history benefits
    
    Bonus:
        - Implement undo for rebase (reflog)
        - Create visualization of before/after
        - Handle rebase of rebase
    """
    print("=" * 70)
    print("EXERCISE 1: Git Rebase Workflow")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 2: Cherry-Picking Strategy
# =============================================================================

def exercise_2_cherry_pick():
    """
    EXERCISE 2: Selective Commit Application
    
    Task:
    Implement cherry-pick use cases:
    
    def cherry_pick_hotfix(repo_path: str, fix_commit: str, 
                          target_branches: list) -> dict:
        '''
        Apply hotfix commit to multiple branches:
        - main
        - release-1.0
        - release-2.0
        
        Returns:
            Dict mapping branch -> new commit hash
        '''
        pass
    
    def extract_feature_commits(repo_path: str,
                               feature_branch: str,
                               commit_hashes: list) -> bool:
        '''
        Cherry-pick specific commits from feature branch
        to create clean feature implementation.
        
        Use case: Feature branch has debugging commits,
        experiments, etc. Only cherry-pick production-ready commits.
        '''
        pass
    
    def port_feature_between_versions(source_repo: str,
                                     target_repo: str,
                                     commits: list) -> bool:
        '''
        Cherry-pick commits from one repository to another.
        Simulate porting feature between product versions.
        '''
        pass
    
    Test Your Solution:
        # Create multiple release branches
        # Apply fix to all
        # Verify each branch has fix
        # Confirm different commit hashes
    
    Learning Goals:
        - Strategic use of cherry-pick
        - Handling conflicts during cherry-pick
        - Multi-branch maintenance
        - Selective feature porting
    
    Bonus:
        - Implement cherry-pick range
        - Add commit signing
        - Create audit trail of cherry-picks
    """
    print("=" * 70)
    print("EXERCISE 2: Cherry-Picking Strategy")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 3: Stash Management
# =============================================================================

def exercise_3_stash():
    """
    EXERCISE 3: Advanced Stash Operations
    
    Task:
    Create comprehensive stash management system:
    
    class StashManager:
        def __init__(self, repo_path: str):
            self.repo_path = repo_path
        
        def save_with_message(self, message: str) -> int:
            '''Stash with descriptive message, return stash index'''
            pass
        
        def list_all(self) -> list:
            '''Return all stashes with descriptions'''
            pass
        
        def preview(self, stash_index: int) -> str:
            '''Show stash contents without applying'''
            pass
        
        def apply_by_index(self, index: int, keep: bool = True) -> bool:
            '''Apply specific stash, optionally keep in stack'''
            pass
        
        def pop_latest(self) -> bool:
            '''Pop and apply most recent stash'''
            pass
        
        def create_branch_from_stash(self, stash_index: int,
                                     branch_name: str) -> bool:
            '''Create new branch from stashed changes'''
            pass
        
        def clear_all(self) -> bool:
            '''Remove all stashes'''
            pass
    
    Test Your Solution:
        manager = StashManager(repo_path)
        
        # Make changes
        idx1 = manager.save_with_message("WIP: feature A")
        
        # Different changes
        idx2 = manager.save_with_message("WIP: feature B")
        
        # List and preview
        stashes = manager.list_all()
        content = manager.preview(idx1)
        
        # Apply specific stash
        manager.apply_by_index(idx1)
    
    Learning Goals:
        - Manage multiple work-in-progress states
        - Strategic stash usage
        - Stash stack manipulation
        - Converting stashes to branches
    
    Bonus:
        - Add stash searching by message
        - Implement stash merging
        - Create stash expiration system
    """
    print("=" * 70)
    print("EXERCISE 3: Stash Management")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 4: Tagging and Release Management
# =============================================================================

def exercise_4_tags_releases():
    """
    EXERCISE 4: Version Tagging and Release Process
    
    Task:
    Implement complete release management system:
    
    class ReleaseManager:
        def __init__(self, repo_path: str):
            self.repo_path = repo_path
        
        def create_release(self, version: str, message: str) -> bool:
            '''
            Create annotated tag for release.
            Version should follow semantic versioning.
            '''
            pass
        
        def list_releases(self, pattern: str = None) -> list:
            '''
            List all releases, optionally filtered.
            Returns sorted by version number.
            '''
            pass
        
        def get_release_notes(self, from_tag: str, to_tag: str) -> str:
            '''
            Generate release notes from commits between tags.
            '''
            pass
        
        def checkout_release(self, version: str) -> bool:
            '''Checkout specific release version'''
            pass
        
        def delete_release(self, version: str, remote: bool = False) -> bool:
            '''Delete release tag locally and optionally from remote'''
            pass
        
        def validate_version(self, version: str) -> bool:
            '''Validate semantic version format (X.Y.Z)'''
            pass
        
        def suggest_next_version(self, change_type: str) -> str:
            '''
            Suggest next version based on change type:
            - 'major': Incompatible changes
            - 'minor': New features
            - 'patch': Bug fixes
            '''
            pass
    
    Test Your Solution:
        manager = ReleaseManager(repo_path)
        
        # Create releases
        manager.create_release('v1.0.0', 'Initial release')
        manager.create_release('v1.1.0', 'Add new features')
        manager.create_release('v1.1.1', 'Bug fixes')
        
        # List and navigate
        releases = manager.list_releases()
        notes = manager.get_release_notes('v1.0.0', 'v1.1.0')
        
        # Suggest next version
        next_ver = manager.suggest_next_version('minor')
    
    Learning Goals:
        - Semantic versioning principles
        - Release tagging workflow
        - Version management
        - Release note generation
    
    Bonus:
        - Implement GPG signing for tags
        - Create changelog automation
        - Add pre-release version support (alpha, beta, rc)
    """
    print("=" * 70)
    print("EXERCISE 4: Tagging and Release Management")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# EXERCISE 5: Complete Git Workflow Implementation
# =============================================================================

def exercise_5_complete_workflow():
    """
    EXERCISE 5: Professional Git Workflow System
    
    Task:
    Implement a complete workflow management system supporting
    multiple professional Git workflows.
    
    class GitWorkflow:
        def __init__(self, workflow_type: str, repo_path: str):
            '''
            workflow_type: 'feature-branch', 'gitflow', 'github-flow'
            '''
            self.workflow_type = workflow_type
            self.repo_path = repo_path
        
        def start_feature(self, feature_name: str) -> bool:
            '''Begin new feature following workflow rules'''
            pass
        
        def complete_feature(self, feature_name: str) -> bool:
            '''Finish feature following workflow rules'''
            pass
        
        def start_release(self, version: str) -> bool:
            '''Begin release process (Gitflow only)'''
            pass
        
        def complete_release(self, version: str) -> bool:
            '''Complete release process (Gitflow only)'''
            pass
        
        def create_hotfix(self, name: str) -> bool:
            '''Create hotfix branch'''
            pass
        
        def validate_workflow(self) -> dict:
            '''
            Validate current repo state follows workflow rules:
            - Correct branch names
            - No commits directly to main
            - Release tags properly formatted
            
            Returns dict with validation results
            '''
            pass
    
    Implement for Each Workflow:
    
    FEATURE BRANCH WORKFLOW:
    - feature/* branches from main
    - Merge back to main when complete
    - Delete feature branch after merge
    
    GITFLOW WORKFLOW:
    - main, develop branches
    - feature/* from develop
    - release/* from develop
    - hotfix/* from main
    - Proper merge targets for each
    
    GITHUB FLOW:
    - Any branch name from main
    - Pull request workflow simulation
    - Continuous deployment ready
    
    Test Your Solution:
        # Test Feature Branch Workflow
        fb_workflow = GitWorkflow('feature-branch', repo1)
        fb_workflow.start_feature('user-auth')
        # ... make changes ...
        fb_workflow.complete_feature('user-auth')
        
        # Test Gitflow
        gf_workflow = GitWorkflow('gitflow', repo2)
        gf_workflow.start_feature('new-api')
        gf_workflow.complete_feature('new-api')
        gf_workflow.start_release('1.0.0')
        gf_workflow.complete_release('1.0.0')
        
        # Validate
        validation = gf_workflow.validate_workflow()
    
    Learning Goals:
        - Master multiple Git workflows
        - Understand workflow trade-offs
        - Implement workflow automation
        - Enforce workflow rules
    
    Bonus Challenges:
        1. Add custom workflow support
        2. Create workflow transition tools
        3. Implement pull request simulation
        4. Add CI/CD integration hooks
        5. Generate workflow documentation
    """
    print("=" * 70)
    print("EXERCISE 5: Professional Git Workflow System")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# CHALLENGE EXERCISES
# =============================================================================

def challenge_exercise_1():
    """
    CHALLENGE 1: Git Reflog Recovery System
    
    Task:
    Implement system to recover lost commits using reflog:
    
    - Find "lost" commits
    - Visualize reflog history
    - Recover deleted branches
    - Undo dangerous operations (reset, rebase)
    - Create safety net for Git operations
    
    This is advanced and requires deep understanding of
    Git internals and reflog mechanics.
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 1: Git Reflog Recovery System")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_2():
    """
    CHALLENGE 2: Git Hook System
    
    Task:
    Create automated hook system for:
    - Pre-commit: Code formatting, linting
    - Commit-msg: Message validation
    - Pre-push: Run tests
    - Post-merge: Update dependencies
    
    Implement configurable hook manager:
    - Enable/disable hooks
    - Custom hook scripts
    - Hook execution logging
    - Bypass mechanisms
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 2: Git Hook System")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_3():
    """
    CHALLENGE 3: Git Repository Analyzer
    
    Task:
    Build comprehensive repository analysis tool:
    
    - Commit frequency analysis
    - Code churn metrics
    - Contributor statistics
    - Branch lifecycle analysis
    - Merge complexity metrics
    - Repository health score
    - Workflow compliance checking
    - Visualization of all metrics
    
    Should work on any Git repository and produce
    detailed report with actionable insights.
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 3: Git Repository Analyzer")
    print("=" * 70)
    print(__doc__)


def challenge_exercise_4():
    """
    CHALLENGE 4: Multi-Repository Manager
    
    Task:
    Create tool to manage multiple related repositories:
    
    - Sync changes across repos
    - Coordinate releases
    - Check status of all repos
    - Execute commands across repos
    - Handle dependencies between repos
    - Monorepo vs multi-repo strategies
    
    Think: meta-repository management system.
    """
    print("\n" + "=" * 70)
    print("CHALLENGE 4: Multi-Repository Manager")
    print("=" * 70)
    print(__doc__)


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def main():
    """
    Main function for advanced exercises.
    """
    print("\n" + "=" * 70)
    print("GIT ADVANCED - EXERCISE SET 3")
    print("=" * 70)
    print("""
    Welcome to Git Advanced Exercises!
    
    This exercise set covers professional-level Git usage:
    - Rebase and history manipulation
    - Cherry-picking strategies
    - Stash management
    - Release and tag management
    - Complete workflow implementations
    
    Prerequisites:
    - Completed Exercise Sets 1 and 2
    - Solid understanding of branches and merging
    - Experience with remotes and collaboration
    
    These exercises are more open-ended and require:
    - Creative problem solving
    - Understanding of Git internals
    - Professional workflow knowledge
    - Attention to edge cases
    
    Tips:
    - Focus on understanding concepts deeply
    - Practice until workflows feel natural
    - Read Git documentation for advanced features
    - Experiment and break things (safely!)
    - Learn from real-world Git repositories
    
    Uncomment exercises to work on them.
    """)
    
    # Uncomment to work on exercises
    # exercise_1_rebase()
    # exercise_2_cherry_pick()
    # exercise_3_stash()
    # exercise_4_tags_releases()
    # exercise_5_complete_workflow()
    
    # Challenge exercises
    # challenge_exercise_1()
    # challenge_exercise_2()
    # challenge_exercise_3()
    # challenge_exercise_4()
    
    print("\n" + "=" * 70)
    print("Ready to master Git? Start with Exercise 1!")
    print("=" * 70)


if __name__ == "__main__":
    main()
