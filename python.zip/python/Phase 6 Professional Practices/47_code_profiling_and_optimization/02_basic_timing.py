"""
PYTHON CODE PROFILING & OPTIMIZATION - BEGINNER LEVEL
======================================================
Module 2: Basic Timing - Using Python's time module

LEARNING OBJECTIVES:
- Understand different timing functions in Python
- Learn how to measure code execution time accurately
- Recognize common timing pitfalls
- Compare multiple implementations
- Understand when timing measurements are reliable

THEORY:
-------
The time module provides various functions for time measurement:
- time.time(): Wall-clock time (seconds since epoch)
- time.perf_counter(): High-resolution timer for performance measurement
- time.process_time(): CPU time used by current process

For performance measurement, time.perf_counter() is generally preferred
as it provides the highest available resolution.

Author: Python Course Development Team
Date: 2024
"""

import time
import random


# ============================================================================
# SECTION 1: BASIC TIME MEASUREMENT
# ============================================================================

def basic_timing_example():
    """
    Basic example of measuring execution time
    
    Demonstrates the fundamental pattern of timing code:
    1. Record start time
    2. Execute code
    3. Record end time
    4. Calculate elapsed time
    """
    print("=" * 70)
    print("BASIC TIME MEASUREMENT")
    print("=" * 70)
    
    # Record start time
    start_time = time.time()
    
    # Code to measure
    total = 0
    for i in range(1000000):
        total += i
    
    # Record end time
    end_time = time.time()
    
    # Calculate elapsed time
    elapsed = end_time - start_time
    
    print(f"Sum of 1 to 1,000,000: {total}")
    print(f"Time elapsed: {elapsed:.6f} seconds")
    print(f"Time elapsed: {elapsed * 1000:.3f} milliseconds")
    print()


# ============================================================================
# SECTION 2: DIFFERENT TIMING FUNCTIONS
# ============================================================================

def compare_timing_functions():
    """
    Compare different timing functions in Python
    
    time.time():
        - Returns wall-clock time
        - Can be affected by system clock adjustments
        - Lower resolution on some systems
    
    time.perf_counter():
        - High-resolution performance counter
        - Best for measuring short durations
        - Includes time elapsed during sleep
    
    time.process_time():
        - CPU time used by current process
        - Excludes sleep time
        - Good for measuring actual computation
    """
    print("=" * 70)
    print("COMPARING TIMING FUNCTIONS")
    print("=" * 70)
    
    # Create some work to measure
    def do_work():
        """Perform some computation"""
        result = sum(i * i for i in range(100000))
        return result
    
    # Measure with time.time()
    start = time.time()
    result = do_work()
    end = time.time()
    time_time_elapsed = end - start
    
    # Measure with time.perf_counter()
    start = time.perf_counter()
    result = do_work()
    end = time.perf_counter()
    perf_counter_elapsed = end - start
    
    # Measure with time.process_time()
    start = time.process_time()
    result = do_work()
    end = time.process_time()
    process_time_elapsed = end - start
    
    print(f"time.time():         {time_time_elapsed:.9f} seconds")
    print(f"time.perf_counter(): {perf_counter_elapsed:.9f} seconds")
    print(f"time.process_time(): {process_time_elapsed:.9f} seconds")
    
    print("\nRecommendation: Use time.perf_counter() for benchmarking")
    print("It provides the highest resolution timer available.\n")


# ============================================================================
# SECTION 3: TIMING CONTEXT MANAGER
# ============================================================================

class Timer:
    """
    Context manager for timing code blocks
    
    Usage:
        with Timer("My operation"):
            # code to time
            pass
    
    This provides a clean, reusable way to time code blocks
    """
    
    def __init__(self, description="Code block"):
        """
        Initialize timer
        
        Args:
            description: Description of what we're timing
        """
        self.description = description
        self.start_time = None
        self.elapsed = None
    
    def __enter__(self):
        """
        Called when entering the 'with' block
        Records the start time
        """
        self.start_time = time.perf_counter()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Called when exiting the 'with' block
        Calculates and prints elapsed time
        
        Args:
            exc_type: Exception type (if any)
            exc_val: Exception value (if any)
            exc_tb: Exception traceback (if any)
        """
        end_time = time.perf_counter()
        self.elapsed = end_time - self.start_time
        print(f"{self.description}: {self.elapsed:.6f} seconds")
        return False  # Don't suppress exceptions


def demonstrate_timer_context():
    """
    Demonstrate using the Timer context manager
    """
    print("=" * 70)
    print("TIMER CONTEXT MANAGER")
    print("=" * 70)
    
    # Example 1: Timing a simple computation
    with Timer("Sum computation"):
        total = sum(range(1000000))
    
    # Example 2: Timing list creation
    with Timer("List creation"):
        squares = [i**2 for i in range(100000)]
    
    # Example 3: Timing multiple operations
    print("\nTiming multiple operations:")
    
    with Timer("  Sorting"):
        data = [random.randint(0, 1000) for _ in range(10000)]
        data.sort()
    
    with Timer("  Searching"):
        for _ in range(1000):
            _ = 500 in data
    
    print()


# ============================================================================
# SECTION 4: COMPARING IMPLEMENTATIONS
# ============================================================================

def sum_with_loop(n):
    """
    Calculate sum using a loop
    
    Time Complexity: O(n)
    """
    total = 0
    for i in range(n):
        total += i
    return total


def sum_with_builtin(n):
    """
    Calculate sum using built-in function
    
    Time Complexity: O(n) but optimized in C
    """
    return sum(range(n))


def sum_with_formula(n):
    """
    Calculate sum using mathematical formula
    Sum of 1 to n = n * (n-1) / 2
    
    Time Complexity: O(1)
    """
    return n * (n - 1) // 2


def compare_sum_implementations():
    """
    Compare different ways to calculate sum of numbers
    
    Demonstrates:
    - How to compare multiple implementations
    - The importance of choosing the right algorithm
    - Built-in functions are often optimized
    """
    print("=" * 70)
    print("COMPARING IMPLEMENTATIONS: Sum of 1 to n")
    print("=" * 70)
    
    n = 1000000
    
    print(f"Calculating sum of 1 to {n:,}\n")
    
    # Method 1: Loop
    with Timer("Loop implementation"):
        result1 = sum_with_loop(n)
    print(f"  Result: {result1:,}")
    
    # Method 2: Built-in
    with Timer("Built-in sum()"):
        result2 = sum_with_builtin(n)
    print(f"  Result: {result2:,}")
    
    # Method 3: Formula
    with Timer("Mathematical formula"):
        result3 = sum_with_formula(n)
    print(f"  Result: {result3:,}")
    
    print("\nKey Observations:")
    print("1. All methods give the same result (correctness)")
    print("2. Mathematical formula is O(1) - fastest")
    print("3. Built-in sum() is faster than pure Python loop")
    print("4. Choosing right algorithm matters most!\n")


# ============================================================================
# SECTION 5: TIMING PITFALLS AND BEST PRACTICES
# ============================================================================

def demonstrate_timing_variability():
    """
    Demonstrate that single measurements can be unreliable
    
    Shows why we need multiple runs for accurate measurements
    """
    print("=" * 70)
    print("TIMING VARIABILITY")
    print("=" * 70)
    
    def test_operation():
        """Simple operation to test"""
        return sum(i * i for i in range(10000))
    
    print("Running the same operation 10 times:\n")
    
    times = []
    for i in range(10):
        start = time.perf_counter()
        result = test_operation()
        end = time.perf_counter()
        elapsed = end - start
        times.append(elapsed)
        print(f"Run {i+1:2d}: {elapsed:.9f} seconds")
    
    # Calculate statistics
    min_time = min(times)
    max_time = max(times)
    avg_time = sum(times) / len(times)
    
    print(f"\nMinimum: {min_time:.9f} seconds")
    print(f"Maximum: {max_time:.9f} seconds")
    print(f"Average: {avg_time:.9f} seconds")
    print(f"Variation: {((max_time - min_time) / avg_time * 100):.2f}%")
    
    print("\nKey Point: Always run multiple iterations!")
    print("System background tasks cause variability.\n")


def demonstrate_warmup_effect():
    """
    Demonstrate the warm-up effect
    
    First few runs may be slower due to:
    - Python interpreter optimization
    - CPU cache warming
    - Operating system scheduling
    """
    print("=" * 70)
    print("WARM-UP EFFECT")
    print("=" * 70)
    
    def compute_fibonacci(n):
        """Calculate nth Fibonacci number"""
        if n <= 1:
            return n
        a, b = 0, 1
        for _ in range(2, n + 1):
            a, b = b, a + b
        return b
    
    print("Calculating Fibonacci(1000) multiple times:\n")
    
    for i in range(5):
        start = time.perf_counter()
        result = compute_fibonacci(1000)
        end = time.perf_counter()
        elapsed = end - start
        print(f"Run {i+1}: {elapsed:.9f} seconds")
    
    print("\nNote: First run is often slower (warm-up effect)")
    print("Solution: Discard first few measurements or use timeit module\n")


# ============================================================================
# SECTION 6: TIMING LONGER OPERATIONS
# ============================================================================

def time_with_progress(n_iterations):
    """
    Time a longer operation with progress indication
    
    For operations that take significant time, show progress
    to reassure users the program is running
    
    Args:
        n_iterations: Number of iterations to perform
    """
    print("=" * 70)
    print("TIMING LONGER OPERATIONS")
    print("=" * 70)
    
    print(f"Processing {n_iterations:,} iterations...")
    
    start_time = time.perf_counter()
    
    # Perform the operation
    results = []
    checkpoint = n_iterations // 10  # Report every 10%
    
    for i in range(n_iterations):
        # Some computation
        result = sum(j * j for j in range(100))
        results.append(result)
        
        # Progress indication
        if (i + 1) % checkpoint == 0:
            elapsed = time.perf_counter() - start_time
            progress = (i + 1) / n_iterations * 100
            print(f"  {progress:5.1f}% complete - Elapsed: {elapsed:.2f}s")
    
    end_time = time.perf_counter()
    total_time = end_time - start_time
    
    print(f"\nTotal time: {total_time:.2f} seconds")
    print(f"Average per iteration: {total_time/n_iterations*1000:.3f} milliseconds")
    print()


# ============================================================================
# SECTION 7: PRACTICAL TIMING UTILITIES
# ============================================================================

def time_function(func, *args, **kwargs):
    """
    Utility function to time any function call
    
    Args:
        func: Function to time
        *args: Positional arguments for function
        **kwargs: Keyword arguments for function
        
    Returns:
        Tuple of (result, elapsed_time)
    """
    start = time.perf_counter()
    result = func(*args, **kwargs)
    end = time.perf_counter()
    elapsed = end - start
    return result, elapsed


def benchmark_function(func, *args, n_runs=10, **kwargs):
    """
    Benchmark a function with multiple runs
    
    Args:
        func: Function to benchmark
        *args: Positional arguments for function
        n_runs: Number of times to run the function
        **kwargs: Keyword arguments for function
        
    Returns:
        Dictionary with timing statistics
    """
    times = []
    
    # Run function multiple times
    for _ in range(n_runs):
        start = time.perf_counter()
        func(*args, **kwargs)
        end = time.perf_counter()
        times.append(end - start)
    
    # Calculate statistics
    min_time = min(times)
    max_time = max(times)
    avg_time = sum(times) / len(times)
    
    return {
        'min': min_time,
        'max': max_time,
        'avg': avg_time,
        'runs': n_runs
    }


def demonstrate_timing_utilities():
    """
    Demonstrate practical timing utility functions
    """
    print("=" * 70)
    print("PRACTICAL TIMING UTILITIES")
    print("=" * 70)
    
    # Example function to time
    def factorial(n):
        """Calculate factorial"""
        if n <= 1:
            return 1
        result = 1
        for i in range(2, n + 1):
            result *= i
        return result
    
    # Using time_function
    print("Using time_function utility:")
    result, elapsed = time_function(factorial, 100)
    print(f"  factorial(100) = {result:.2e}")
    print(f"  Time: {elapsed:.9f} seconds")
    
    # Using benchmark_function
    print("\nUsing benchmark_function utility:")
    stats = benchmark_function(factorial, 100, n_runs=100)
    print(f"  Runs: {stats['runs']}")
    print(f"  Average: {stats['avg']:.9f} seconds")
    print(f"  Minimum: {stats['min']:.9f} seconds")
    print(f"  Maximum: {stats['max']:.9f} seconds")
    print()


# ============================================================================
# SECTION 8: BEST PRACTICES SUMMARY
# ============================================================================

def print_best_practices():
    """
    Print best practices for timing code
    """
    print("=" * 70)
    print("TIMING BEST PRACTICES")
    print("=" * 70)
    
    practices = """
    1. USE time.perf_counter() for performance measurement
       - Highest resolution timer available
       - Consistent across different systems
    
    2. RUN MULTIPLE ITERATIONS
       - Single measurements are unreliable
       - Calculate min, max, and average
       - Report confidence intervals if possible
    
    3. ACCOUNT FOR WARM-UP
       - First run may be slower
       - Consider discarding initial measurements
       - Or use timeit module (covered in next module)
    
    4. MINIMIZE EXTERNAL FACTORS
       - Close unnecessary applications
       - Use consistent system state
       - Run on same hardware for comparisons
    
    5. TIME REALISTIC WORKLOADS
       - Use representative data sizes
       - Test with real-world inputs
       - Consider best/worst/average cases
    
    6. REPORT CONTEXT
       - Include Python version
       - Document hardware specs
       - Specify data characteristics
    
    7. USE APPROPRIATE UNITS
       - Seconds for long operations
       - Milliseconds for medium operations
       - Microseconds for short operations
    
    8. COMPARE RELATIVE PERFORMANCE
       - Focus on ratios, not absolute times
       - "2x faster" is more meaningful than "0.5s vs 1.0s"
    """
    
    print(practices)


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """
    Main function to run all demonstrations
    """
    print("\n" + "=" * 70)
    print("BASIC TIMING WITH TIME MODULE - COMPREHENSIVE TUTORIAL")
    print("=" * 70 + "\n")
    
    # Run all demonstrations
    basic_timing_example()
    compare_timing_functions()
    demonstrate_timer_context()
    compare_sum_implementations()
    demonstrate_timing_variability()
    demonstrate_warmup_effect()
    time_with_progress(10000)
    demonstrate_timing_utilities()
    print_best_practices()
    
    # Summary
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print("""
    Key Takeaways:
    1. time.perf_counter() is best for performance measurement
    2. Always run multiple iterations for reliable results
    3. Use context managers for clean timing code
    4. Compare implementations to find the best solution
    5. Be aware of timing variability and warm-up effects
    6. Use utility functions for common timing patterns
    
    Next Steps:
    - Learn about timeit module for micro-benchmarking
    - Explore cProfile for function-level profiling
    - Practice timing your own code
    """)


if __name__ == "__main__":
    main()
