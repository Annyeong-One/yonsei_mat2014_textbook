"""
PYTHON CODE PROFILING & OPTIMIZATION - BEGINNER LEVEL
======================================================
Module 4: Memory Basics - Understanding Memory Usage

LEARNING OBJECTIVES:
- Understand how Python manages memory
- Learn to measure object sizes
- Understand reference counting and garbage collection
- Identify memory-heavy operations
- Learn memory-efficient programming practices

Author: Python Course Development Team
Date: 2024
"""

import sys
import gc


def demonstrate_sys_getsizeof():
    """Show basic memory measurement with sys.getsizeof()"""
    print("=" * 70)
    print("MEASURING OBJECT SIZES")
    print("=" * 70)
    
    # Basic types
    print("
Basic Types:")
    print(f"int(0):        {sys.getsizeof(0):,} bytes")
    print(f"int(1000):     {sys.getsizeof(1000):,} bytes")
    print(f"int(10**100):  {sys.getsizeof(10**100):,} bytes")
    print(f"float(1.0):    {sys.getsizeof(1.0):,} bytes")
    print(f"bool(True):    {sys.getsizeof(True):,} bytes")
    print(f"None:          {sys.getsizeof(None):,} bytes")
    
    # Containers
    print("
Container Types:")
    empty_list = []
    print(f"Empty list:          {sys.getsizeof(empty_list):,} bytes")
    print(f"List [1,2,3]:        {sys.getsizeof([1,2,3]):,} bytes")
    print(f"List of 100 items:   {sys.getsizeof(list(range(100))):,} bytes")
    
    empty_dict = {}
    print(f"
Empty dict:          {sys.getsizeof(empty_dict):,} bytes")
    print(f"Dict with 10 items:  {sys.getsizeof({i: i for i in range(10)}):,} bytes")
    
    print(f"
Empty tuple:         {sys.getsizeof(()):,} bytes")
    print(f"Tuple (1,2,3):       {sys.getsizeof((1,2,3)):,} bytes")
    
    # Strings
    print("
Strings:")
    print(f"Empty string:        {sys.getsizeof(''):,} bytes")
    print(f"'Hello':             {sys.getsizeof('Hello'):,} bytes")
    print(f"'A'*100:             {sys.getsizeof('A'*100):,} bytes")
    print()


def demonstrate_shallow_vs_deep_size():
    """Show difference between shallow and deep size"""
    print("=" * 70)
    print("SHALLOW VS DEEP SIZE")
    print("=" * 70)
    
    # Nested structure
    data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    
    print(f"
List of lists: {data}")
    print(f"Shallow size (list container): {sys.getsizeof(data):,} bytes")
    
    # Calculate deep size manually
    deep_size = sys.getsizeof(data)
    for item in data:
        deep_size += sys.getsizeof(item)
        for elem in item:
            deep_size += sys.getsizeof(elem)
    
    print(f"Deep size (including contents): {deep_size:,} bytes")
    print("
Key Point: sys.getsizeof() only measures the container,")
    print("not the referenced objects!
")


def demonstrate_memory_growth():
    """Show how memory usage grows with data structures"""
    print("=" * 70)
    print("MEMORY GROWTH WITH SIZE")
    print("=" * 70)
    
    print("
List memory growth:")
    for n in [0, 10, 100, 1000, 10000]:
        lst = list(range(n))
        size = sys.getsizeof(lst)
        per_element = size / n if n > 0 else 0
        print(f"  {n:6} elements: {size:8,} bytes ({per_element:.2f} bytes/element)")
    
    print("
Dict memory growth:")
    for n in [0, 10, 100, 1000, 10000]:
        dct = {i: i*2 for i in range(n)}
        size = sys.getsizeof(dct)
        per_element = size / n if n > 0 else 0
        print(f"  {n:6} elements: {size:8,} bytes ({per_element:.2f} bytes/element)")
    print()


def demonstrate_reference_counting():
    """Explain Python's reference counting"""
    print("=" * 70)
    print("REFERENCE COUNTING")
    print("=" * 70)
    
    print("
Python uses reference counting for memory management.")
    
    # Create object and check ref count
    x = [1, 2, 3]
    print(f"
Created list x = {x}")
    print(f"Reference count: {sys.getrefcount(x)}")  # +1 for parameter passing
    
    # Create another reference
    y = x
    print(f"
Created y = x (another reference)")
    print(f"Reference count: {sys.getrefcount(x)}")
    
    # Delete reference
    del y
    print(f"
Deleted y")
    print(f"Reference count: {sys.getrefcount(x)}")
    
    print("
When ref count reaches 0, memory is freed.
")


def main():
    """Run all demonstrations"""
    print("
" + "=" * 70)
    print("MEMORY BASICS - COMPREHENSIVE TUTORIAL")
    print("=" * 70 + "
")
    
    demonstrate_sys_getsizeof()
    demonstrate_shallow_vs_deep_size()
    demonstrate_memory_growth()
    demonstrate_reference_counting()
    
    print("=" * 70)
    print("SUMMARY")
    print("=" * 70)
    print("""
    Key Takeaways:
    1. sys.getsizeof() measures shallow size only
    2. Different types have different memory overheads
    3. Containers grow in size with more elements
    4. Python uses reference counting for memory management
    5. Understanding memory is crucial for large datasets
    
    Next Steps:
    - Learn about memory profilers
    - Explore memory-efficient data structures
    - Study garbage collection in detail
    """)

if __name__ == "__main__":
    main()
