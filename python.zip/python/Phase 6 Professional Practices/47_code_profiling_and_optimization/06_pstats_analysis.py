"""
PYTHON CODE PROFILING & OPTIMIZATION - INTERMEDIATE LEVEL
==========================================================
Module 6: pstats Analysis - Analyzing Profiling Results

LEARNING OBJECTIVES:
- Master pstats for analyzing profiling data
- Learn different sorting and filtering options
- Create custom profiling reports
- Save and load profiling data
- Compare multiple profiling runs

Author: Python Course Development Team
Date: 2024
"""

import cProfile
import pstats
from io import StringIO
import random


def sort_algorithm(arr):
    """Bubble sort - intentionally inefficient"""
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
    return arr


def search_algorithm(arr, target):
    """Linear search"""
    for i, val in enumerate(arr):
        if val == target:
            return i
    return -1


def process_data(n):
    """Process data with multiple operations"""
    data = [random.randint(0, 1000) for _ in range(n)]
    sorted_data = sort_algorithm(data.copy())
    target = random.choice(data)
    index = search_algorithm(sorted_data, target)
    return sorted_data, index


def demonstrate_sort_options():
    """Show different ways to sort profiling results"""
    print("=" * 70)
    print("SORTING OPTIONS IN PSTATS")
    print("=" * 70)
    
    # Profile the code
    profiler = cProfile.Profile()
    profiler.enable()
    process_data(500)
    profiler.disable()
    
    stats = pstats.Stats(profiler)
    stats.strip_dirs()
    
    # Sort by cumulative time
    print("\n1. Sorted by Cumulative Time:")
    stats.sort_stats('cumulative')
    stats.print_stats(5)
    
    # Sort by total time
    print("\n2. Sorted by Total Time (self time):")
    stats.sort_stats('tottime')
    stats.print_stats(5)
    
    # Sort by number of calls
    print("\n3. Sorted by Number of Calls:")
    stats.sort_stats('ncalls')
    stats.print_stats(5)


def demonstrate_filtering():
    """Show how to filter profiling results"""
    print("\n" + "=" * 70)
    print("FILTERING PROFILING RESULTS")
    print("=" * 70)
    
    profiler = cProfile.Profile()
    profiler.enable()
    process_data(300)
    profiler.disable()
    
    stats = pstats.Stats(profiler)
    stats.strip_dirs()
    stats.sort_stats('cumulative')
    
    print("\n1. Show only functions matching 'algorithm':")
    stats.print_stats('algorithm')
    
    print("\n2. Show only custom functions (exclude built-ins):")
    stats.print_stats('^[^<]')  # Exclude functions starting with <


def save_and_load_stats():
    """Demonstrate saving and loading profile data"""
    print("\n" + "=" * 70)
    print("SAVING AND LOADING PROFILE DATA")
    print("=" * 70)
    
    # Profile and save
    profiler = cProfile.Profile()
    profiler.enable()
    process_data(200)
    profiler.disable()
    
    # Save to file
    filename = '/tmp/profile_results.prof'
    profiler.dump_stats(filename)
    print(f"\nProfile data saved to: {filename}")
    
    # Load and analyze
    stats = pstats.Stats(filename)
    stats.strip_dirs()
    stats.sort_stats('cumulative')
    
    print("\nLoaded profile data:")
    stats.print_stats(5)


def main():
    """Run all demonstrations"""
    print("\n" + "=" * 70)
    print("PSTATS ANALYSIS - COMPREHENSIVE TUTORIAL")
    print("=" * 70 + "\n")
    
    demonstrate_sort_options()
    demonstrate_filtering()
    save_and_load_stats()
    
    print("\n" + "=" * 70)
    print("PSTATS SORT OPTIONS")
    print("=" * 70)
    print("""
    Available sort keys:
    - 'calls' or 'ncalls': Number of calls
    - 'cumulative' or 'cumtime': Cumulative time
    - 'tottime' or 'time': Total time in function
    - 'pcalls': Primitive call count
    - 'filename' or 'file': File name
    - 'line' or 'nfl': Name/file/line
    - 'name': Function name
    - 'stdname': Standard name
    
    Filtering:
    - Use regex patterns to filter results
    - stats.print_stats('pattern') shows matching functions
    - Combine multiple filters for precise analysis
    """)

if __name__ == "__main__":
    main()
