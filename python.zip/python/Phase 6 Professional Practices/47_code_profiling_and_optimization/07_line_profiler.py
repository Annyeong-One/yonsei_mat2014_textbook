"""
INTERMEDIATE: Line-by-Line Profiling
Note: Requires pip install line-profiler
Shows line-by-line execution time
"""
# Installation and usage examples
print("Line profiler tutorial - requires: pip install line-profiler")
print("Use @profile decorator and run: kernprof -l -v script.py")
