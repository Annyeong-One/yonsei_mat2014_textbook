"""
INTERMEDIATE: Memory Profiling
Note: Requires pip install memory-profiler
Shows memory usage per line
"""
print("Memory profiler tutorial - requires: pip install memory-profiler")
print("Use @profile decorator and run: python -m memory_profiler script.py")
