"""
INTERMEDIATE: Algorithmic Optimization Examples
"""
import time

def find_duplicates_slow(nums):
    """O(n²) solution"""
    duplicates = []
    for i in range(len(nums)):
        for j in range(i+1, len(nums)):
            if nums[i] == nums[j]:
                duplicates.append(nums[i])
    return list(set(duplicates))

def find_duplicates_fast(nums):
    """O(n) solution using set"""
    seen = set()
    duplicates = set()
    for num in nums:
        if num in seen:
            duplicates.add(num)
        seen.add(num)
    return list(duplicates)

print("Algorithmic Optimization Demonstration")
data = list(range(1000)) * 2  # 2000 elements with duplicates

start = time.time()
result1 = find_duplicates_slow(data)
time1 = time.time() - start
print(f"Slow O(n²): {time1:.4f}s")

start = time.time()
result2 = find_duplicates_fast(data)
time2 = time.time() - start
print(f"Fast O(n): {time2:.4f}s")
print(f"Speedup: {time1/time2:.1f}x faster!")
