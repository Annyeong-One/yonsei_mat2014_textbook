"""
INTERMEDIATE: Data Structure Optimization
"""
import time
import array

# List vs array for numeric data
print("List vs Array for numeric data:")

# List
start = time.time()
py_list = [i for i in range(1000000)]
list_time = time.time() - start

# Array
start = time.time()
py_array = array.array('i', (i for i in range(1000000)))
array_time = time.time() - start

print(f"List creation: {list_time:.4f}s")
print(f"Array creation: {array_time:.4f}s")

# Memory comparison
import sys
print(f"\nList memory: {sys.getsizeof(py_list):,} bytes")
print(f"Array memory: {sys.getsizeof(py_array):,} bytes")
