"""
ADVANCED: NumPy Vectorization for Performance
Note: Requires numpy
"""
try:
    import numpy as np
    import time
    
    # Pure Python loops
    def sum_python(n):
        result = 0
        for i in range(n):
            result += i * i
        return result
    
    # NumPy vectorized
    def sum_numpy(n):
        arr = np.arange(n)
        return np.sum(arr * arr)
    
    n = 1000000
    
    start = time.time()
    r1 = sum_python(n)
    t1 = time.time() - start
    
    start = time.time()
    r2 = sum_numpy(n)
    t2 = time.time() - start
    
    print(f"Python loops: {t1:.4f}s")
    print(f"NumPy vectorized: {t2:.4f}s")
    print(f"Speedup: {t1/t2:.1f}x faster!")
    
except ImportError:
    print("NumPy not installed. Install: pip install numpy")
