"""
ADVANCED: List Comprehensions vs Generators
Memory-efficient iteration
"""
import sys
import time

# List comprehension - creates entire list in memory
def sum_list_comp(n):
    numbers = [i * i for i in range(n)]
    return sum(numbers)

# Generator expression - lazy evaluation
def sum_generator(n):
    numbers = (i * i for i in range(n))
    return sum(numbers)

n = 1000000

# Memory usage
list_comp = [i * i for i in range(n)]
gen_expr = (i * i for i in range(n))

print("Memory Comparison:")
print(f"List comprehension: {sys.getsizeof(list_comp):,} bytes")
print(f"Generator: {sys.getsizeof(gen_expr):,} bytes")

# Time comparison
start = time.time()
r1 = sum_list_comp(n)
t1 = time.time() - start

start = time.time()
r2 = sum_generator(n)
t2 = time.time() - start

print(f"\nTime Comparison:")
print(f"List comprehension: {t1:.4f}s")
print(f"Generator: {t2:.4f}s")
print(f"\nUse generators for memory efficiency!")
