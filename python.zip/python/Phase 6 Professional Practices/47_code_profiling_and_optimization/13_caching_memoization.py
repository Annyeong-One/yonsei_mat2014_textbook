"""
ADVANCED: Caching and Memoization
"""
import time
from functools import lru_cache

# Without memoization
def fibonacci_slow(n):
    if n < 2:
        return n
    return fibonacci_slow(n-1) + fibonacci_slow(n-2)

# With memoization
@lru_cache(maxsize=None)
def fibonacci_fast(n):
    if n < 2:
        return n
    return fibonacci_fast(n-1) + fibonacci_fast(n-2)

n = 35

print(f"Calculating Fibonacci({n}):")

start = time.time()
r1 = fibonacci_slow(n)
t1 = time.time() - start
print(f"Without cache: {t1:.4f}s")

start = time.time()
r2 = fibonacci_fast(n)
t2 = time.time() - start
print(f"With @lru_cache: {t2:.6f}s")

print(f"\nSpeedup: {t1/t2:.0f}x faster!")
print(f"Cache info: {fibonacci_fast.cache_info()}")
