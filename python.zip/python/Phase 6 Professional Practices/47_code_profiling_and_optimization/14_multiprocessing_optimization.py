"""
ADVANCED: Multiprocessing for CPU-bound tasks
"""
import time
import multiprocessing as mp

def cpu_intensive(n):
    """Simulate CPU-intensive work"""
    result = 0
    for i in range(n):
        result += i ** 2
    return result

def sequential_processing(tasks):
    """Process tasks sequentially"""
    return [cpu_intensive(task) for task in tasks]

def parallel_processing(tasks):
    """Process tasks in parallel"""
    with mp.Pool(mp.cpu_count()) as pool:
        return pool.map(cpu_intensive, tasks)

if __name__ == '__main__':
    tasks = [1000000] * 8
    
    start = time.time()
    sequential_results = sequential_processing(tasks)
    t1 = time.time() - start
    
    start = time.time()
    parallel_results = parallel_processing(tasks)
    t2 = time.time() - start
    
    print(f"Sequential: {t1:.2f}s")
    print(f"Parallel ({mp.cpu_count()} cores): {t2:.2f}s")
    print(f"Speedup: {t1/t2:.1f}x")
