"""
ADVANCED: Threading for I/O-bound tasks
"""
import time
import threading
import requests

def download_sequential(urls):
    """Download URLs sequentially"""
    results = []
    for url in urls:
        time.sleep(0.1)  # Simulate I/O
        results.append(f"Downloaded {url}")
    return results

def download_threaded(urls):
    """Download URLs with threading"""
    results = []
    
    def download(url):
        time.sleep(0.1)  # Simulate I/O
        results.append(f"Downloaded {url}")
    
    threads = [threading.Thread(target=download, args=(url,)) for url in urls]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    return results

urls = [f"http://example.com/{i}" for i in range(10)]

start = time.time()
r1 = download_sequential(urls)
t1 = time.time() - start

start = time.time()
r2 = download_threaded(urls)
t2 = time.time() - start

print(f"Sequential: {t1:.2f}s")
print(f"Threaded: {t2:.2f}s")
print(f"Speedup: {t1/t2:.1f}x")
