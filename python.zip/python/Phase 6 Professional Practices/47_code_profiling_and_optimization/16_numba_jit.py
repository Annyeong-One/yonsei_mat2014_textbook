"""
ADVANCED: Just-In-Time Compilation with Numba
Note: Requires numba
"""
try:
    import numpy as np
    from numba import jit
    import time
    
    def monte_carlo_pi_python(n):
        """Pure Python Monte Carlo"""
        inside = 0
        for i in range(n):
            x = np.random.random()
            y = np.random.random()
            if x*x + y*y <= 1:
                inside += 1
        return 4 * inside / n
    
    @jit(nopython=True)
    def monte_carlo_pi_numba(n):
        """Numba JIT compiled"""
        inside = 0
        for i in range(n):
            x = np.random.random()
            y = np.random.random()
            if x*x + y*y <= 1:
                inside += 1
        return 4 * inside / n
    
    n = 1000000
    
    start = time.time()
    pi_python = monte_carlo_pi_python(n)
    t1 = time.time() - start
    
    # Warm up JIT
    monte_carlo_pi_numba(100)
    
    start = time.time()
    pi_numba = monte_carlo_pi_numba(n)
    t2 = time.time() - start
    
    print(f"Python: {t1:.4f}s, π ≈ {pi_python:.4f}")
    print(f"Numba JIT: {t2:.4f}s, π ≈ {pi_numba:.4f}")
    print(f"Speedup: {t1/t2:.1f}x")
    
except ImportError:
    print("Numba not installed. Install: pip install numba")
