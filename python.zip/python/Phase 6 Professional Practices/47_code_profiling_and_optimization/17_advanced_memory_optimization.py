"""
ADVANCED: Advanced Memory Optimization Techniques
"""
import sys

# Using __slots__ to reduce memory
class PointNoSlots:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class PointWithSlots:
    __slots__ = ['x', 'y']
    def __init__(self, x, y):
        self.x = x
        self.y = y

# Create many objects
points_no_slots = [PointNoSlots(i, i) for i in range(1000)]
points_with_slots = [PointWithSlots(i, i) for i in range(1000)]

size_no_slots = sum(sys.getsizeof(p) + sys.getsizeof(p.__dict__) for p in points_no_slots)
size_with_slots = sum(sys.getsizeof(p) for p in points_with_slots)

print("Memory Optimization with __slots__:")
print(f"Without __slots__: {size_no_slots:,} bytes")
print(f"With __slots__: {size_with_slots:,} bytes")
print(f"Savings: {(1 - size_with_slots/size_no_slots)*100:.1f}%")

# String interning
import sys
s1 = "hello"
s2 = "hello"
s3 = "".join(["h", "e", "l", "l", "o"])

print(f"\nString interning:")
print(f"s1 is s2: {s1 is s2}")
print(f"s1 is s3: {s1 is s3}")
print(f"s1 is sys.intern(s3): {s1 is sys.intern(s3)}")
