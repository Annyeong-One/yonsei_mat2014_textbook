"""
ADVANCED: Complete Profiling Workflow
Real-world optimization example
"""
import cProfile
import pstats
import time

def process_data_v1(data):
    """Original implementation"""
    result = []
    for item in data:
        if item % 2 == 0:
            result.append(item * 2)
    return result

def process_data_v2(data):
    """Optimized: list comprehension"""
    return [item * 2 for item in data if item % 2 == 0]

def process_data_v3(data):
    """Optimized: generator for memory"""
    return (item * 2 for item in data if item % 2 == 0)

# Test data
data = list(range(100000))

print("Complete Profiling Workflow")
print("=" * 60)

# Profile each version
for i, func in enumerate([process_data_v1, process_data_v2, process_data_v3], 1):
    profiler = cProfile.Profile()
    profiler.enable()
    
    start = time.time()
    result = func(data)
    if i == 3:  # Generator - need to consume it
        result = list(result)
    elapsed = time.time() - start
    
    profiler.disable()
    
    stats = pstats.Stats(profiler)
    print(f"\nVersion {i} ({func.__name__}):")
    print(f"  Time: {elapsed:.6f}s")
    print(f"  Calls: {stats.total_calls}")
    
print("\nKey Insight: Measure before and after optimization!")
