"""
EXERCISE 1: Time Complexity Analysis Practice
==============================================

INSTRUCTIONS:
For each function below, analyze its time complexity and write your answer
in the docstring. Then run the tests to verify your understanding.

DIFFICULTY: Beginner
TIME: 30-45 minutes
"""

def exercise_1a(n):
    """
    TODO: Analyze time complexity
    
    Your answer: O(?)
    Explanation: 
    """
    total = 0
    for i in range(n):
        total += i
    return total


def exercise_1b(arr):
    """
    TODO: Analyze time complexity
    
    Your answer: O(?)
    Explanation:
    """
    n = len(arr)
    for i in range(n):
        for j in range(n):
            if arr[i] == arr[j] and i != j:
                return True
    return False


def exercise_1c(n):
    """
    TODO: Analyze time complexity
    
    Your answer: O(?)
    Explanation:
    """
    result = 1
    while n > 1:
        result *= n
        n = n // 2
    return result


def exercise_1d(arr, target):
    """
    TODO: Analyze time complexity
    
    Your answer: O(?)
    Explanation:
    """
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1


def exercise_1e(n):
    """
    TODO: Analyze time complexity
    
    Your answer: O(?)
    Explanation:
    """
    result = []
    for i in range(n):
        for j in range(i, n):
            result.append(i + j)
    return result


# ANSWERS (hidden - try solving first!)
"""
SOLUTIONS:
----------
exercise_1a: O(n) - single loop iterating n times
exercise_1b: O(n²) - nested loops, each iterating n times
exercise_1c: O(log n) - n is halved each iteration
exercise_1d: O(log n) - binary search, problem halves each step
exercise_1e: O(n²) - outer loop n times, inner loop average n/2 times
"""

if __name__ == "__main__":
    print("Complete the complexity analysis in the docstrings!")
    print("Then compare with the solutions at the bottom.")
