"""
EXERCISE 2: Timing and Comparison Practice
===========================================

INSTRUCTIONS:
Implement the TODO functions and compare their performance.
Measure execution time and identify the fastest implementation.

DIFFICULTY: Beginner
TIME: 45-60 minutes
"""

import time

# TASK 1: Implement three different ways to reverse a string
def reverse_string_v1(s):
    """TODO: Reverse string using loop"""
    # Your code here
    pass

def reverse_string_v2(s):
    """TODO: Reverse string using slicing"""
    # Your code here
    pass

def reverse_string_v3(s):
    """TODO: Reverse string using reversed()"""
    # Your code here
    pass


# TASK 2: Implement three different ways to find sum of even numbers
def sum_evens_v1(n):
    """TODO: Use loop with condition"""
    # Your code here
    pass

def sum_evens_v2(n):
    """TODO: Use list comprehension"""
    # Your code here
    pass

def sum_evens_v3(n):
    """TODO: Use mathematical formula (sum of 2+4+6+...+n)"""
    # Your code here
    pass


# TEST YOUR IMPLEMENTATIONS
def test_implementations():
    """Test and time your implementations"""
    
    # Test string reversal
    test_string = "hello" * 10000
    
    print("String Reversal Timing:")
    for i, func in enumerate([reverse_string_v1, reverse_string_v2, reverse_string_v3], 1):
        start = time.time()
        result = func(test_string)
        elapsed = time.time() - start
        print(f"  Version {i}: {elapsed:.6f}s")
    
    # Test sum of evens
    n = 1000000
    
    print("\nSum of Evens Timing:")
    for i, func in enumerate([sum_evens_v1, sum_evens_v2, sum_evens_v3], 1):
        start = time.time()
        result = func(n)
        elapsed = time.time() - start
        print(f"  Version {i}: {elapsed:.6f}s, Result: {result}")


if __name__ == "__main__":
    print("Implement the TODO functions, then run test_implementations()")
    # Uncomment when ready:
    # test_implementations()
