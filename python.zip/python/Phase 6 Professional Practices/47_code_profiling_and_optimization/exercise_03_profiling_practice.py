"""
EXERCISE 3: Profiling Practice
===============================

INSTRUCTIONS:
Profile the provided code, identify bottlenecks, and optimize.
Document your findings and improvements.

DIFFICULTY: Intermediate
TIME: 60-90 minutes
"""

import cProfile
import pstats


def inefficient_function(n):
    """
    This function has performance issues. 
    TODO:
    1. Profile this function
    2. Identify the bottleneck(s)
    3. Rewrite as efficient_function() with improvements
    4. Document the speedup achieved
    """
    result = []
    for i in range(n):
        # Creating new string each time (slow!)
        temp = ""
        for j in range(100):
            temp += str(j)
        result.append(temp)
    
    # Checking membership in list (slow!)
    unique_results = []
    for item in result:
        if item not in unique_results:
            unique_results.append(item)
    
    return unique_results


def efficient_function(n):
    """
    TODO: Implement optimized version
    
    Improvements made:
    1. [Your optimization 1]
    2. [Your optimization 2]
    3. [Your optimization 3]
    
    Expected speedup: [Your prediction]
    """
    # Your optimized code here
    pass


def profile_and_compare():
    """Profile both functions and compare"""
    n = 1000
    
    print("Profiling inefficient_function:")
    profiler = cProfile.Profile()
    profiler.enable()
    result1 = inefficient_function(n)
    profiler.disable()
    
    stats = pstats.Stats(profiler)
    stats.strip_dirs()
    stats.sort_stats('cumulative')
    stats.print_stats(10)
    
    print("\n" + "="*60)
    print("Now profile your efficient_function and compare!")
    print("="*60)


if __name__ == "__main__":
    profile_and_compare()
