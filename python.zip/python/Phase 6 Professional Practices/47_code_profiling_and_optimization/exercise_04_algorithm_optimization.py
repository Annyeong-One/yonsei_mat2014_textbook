"""
EXERCISE 4: Algorithm Optimization Challenge
=============================================

INSTRUCTIONS:
Each task has a slow implementation. Your job is to optimize it.

DIFFICULTY: Intermediate
TIME: 90-120 minutes
"""

# TASK 1: Find first duplicate
def find_first_duplicate_slow(arr):
    """
    Current: O(n²)
    Target: O(n)
    
    TODO: Optimize using a set
    """
    for i in range(len(arr)):
        for j in range(i+1, len(arr)):
            if arr[i] == arr[j]:
                return arr[i]
    return None


def find_first_duplicate_fast(arr):
    """TODO: Implement O(n) solution"""
    pass


# TASK 2: Two Sum Problem
def two_sum_slow(nums, target):
    """
    Current: O(n²)
    Target: O(n)
    
    Find indices of two numbers that add up to target
    TODO: Optimize using a dictionary
    """
    for i in range(len(nums)):
        for j in range(i+1, len(nums)):
            if nums[i] + nums[j] == target:
                return [i, j]
    return None


def two_sum_fast(nums, target):
    """TODO: Implement O(n) solution"""
    pass


# TASK 3: Count word frequencies
def count_words_slow(text):
    """
    Current: O(n²) due to list operations
    Target: O(n)
    
    TODO: Use Counter or dictionary
    """
    words = text.lower().split()
    result = []
    for word in words:
        found = False
        for item in result:
            if item[0] == word:
                item[1] += 1
                found = True
                break
        if not found:
            result.append([word, 1])
    return result


def count_words_fast(text):
    """TODO: Implement O(n) solution"""
    pass


# TESTING CODE
def test_optimizations():
    """Test your optimizations"""
    import time
    
    # Test Task 1
    test_arr = list(range(10000)) + [50]
    
    start = time.time()
    r1 = find_first_duplicate_slow(test_arr)
    t1 = time.time() - start
    
    start = time.time()
    r2 = find_first_duplicate_fast(test_arr)
    t2 = time.time() - start
    
    print(f"Task 1: Slow={t1:.4f}s, Fast={t2:.4f}s, Speedup={t1/t2:.1f}x")
    
    # Add tests for Task 2 and 3


if __name__ == "__main__":
    print("Implement the fast versions, then run test_optimizations()")
