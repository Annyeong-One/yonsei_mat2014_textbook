"""
EXERCISE 5: NumPy Vectorization Practice
=========================================

INSTRUCTIONS:
Convert loop-based implementations to vectorized NumPy operations.

DIFFICULTY: Advanced
TIME: 60-90 minutes

NOTE: Requires NumPy - install with: pip install numpy
"""

try:
    import numpy as np
    import time
    
    # TASK 1: Element-wise operations
    def element_wise_slow(arr):
        """
        TODO: Convert to NumPy vectorized operation
        Multiply each element by 2, then add 10
        """
        result = []
        for x in arr:
            result.append(x * 2 + 10)
        return result
    
    
    def element_wise_fast(arr):
        """TODO: Implement with NumPy"""
        pass
    
    
    # TASK 2: Conditional operations
    def conditional_slow(arr):
        """
        TODO: Convert to NumPy vectorized operation
        Return elements > 50, squared
        """
        result = []
        for x in arr:
            if x > 50:
                result.append(x * x)
        return result
    
    
    def conditional_fast(arr):
        """TODO: Implement with NumPy and boolean indexing"""
        pass
    
    
    # TASK 3: Matrix operations
    def matrix_multiply_slow(A, B):
        """
        TODO: Convert to NumPy matrix multiplication
        """
        result = [[0 for _ in range(len(B[0]))] for _ in range(len(A))]
        for i in range(len(A)):
            for j in range(len(B[0])):
                for k in range(len(B)):
                    result[i][j] += A[i][k] * B[k][j]
        return result
    
    
    def matrix_multiply_fast(A, B):
        """TODO: Implement with NumPy"""
        pass
    
    
    def test_vectorization():
        """Test your vectorized implementations"""
        print("Testing vectorization improvements...")
        
        # Test 1
        arr = list(range(1000000))
        np_arr = np.array(arr)
        
        start = time.time()
        r1 = element_wise_slow(arr)
        t1 = time.time() - start
        
        start = time.time()
        r2 = element_wise_fast(np_arr)
        t2 = time.time() - start
        
        print(f"Task 1: Slow={t1:.4f}s, Fast={t2:.4f}s, Speedup={t1/t2:.1f}x")
    
    
    if __name__ == "__main__":
        print("Implement the fast versions using NumPy!")
        print("Then run: test_vectorization()")

except ImportError:
    print("NumPy not installed!")
    print("Install with: pip install numpy")
