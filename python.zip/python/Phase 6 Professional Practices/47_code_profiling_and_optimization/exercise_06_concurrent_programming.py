"""
EXERCISE 6: Concurrent Programming Challenge
=============================================

INSTRUCTIONS:
Implement parallel solutions for CPU-bound and I/O-bound tasks.

DIFFICULTY: Advanced
TIME: 90-120 minutes
"""

import time
import multiprocessing as mp
import threading


# TASK 1: CPU-bound task with multiprocessing
def is_prime(n):
    """Check if n is prime"""
    if n < 2:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def count_primes_sequential(numbers):
    """TODO: Sequential implementation"""
    pass


def count_primes_parallel(numbers):
    """TODO: Parallel implementation using multiprocessing"""
    pass


# TASK 2: I/O-bound task with threading
def download_url(url):
    """Simulate downloading (I/O-bound)"""
    time.sleep(0.1)  # Simulate network delay
    return f"Downloaded {url}"


def download_all_sequential(urls):
    """TODO: Sequential implementation"""
    pass


def download_all_threaded(urls):
    """TODO: Threaded implementation"""
    pass


def test_concurrency():
    """Test your concurrent implementations"""
    
    # Test CPU-bound task
    numbers = [1000000 + i for i in range(20)]
    
    print("Testing CPU-bound task (prime counting):")
    start = time.time()
    seq_result = count_primes_sequential(numbers)
    seq_time = time.time() - start
    print(f"  Sequential: {seq_time:.2f}s")
    
    start = time.time()
    par_result = count_primes_parallel(numbers)
    par_time = time.time() - start
    print(f"  Parallel: {par_time:.2f}s")
    print(f"  Speedup: {seq_time/par_time:.1f}x")
    
    # Test I/O-bound task
    urls = [f"http://example.com/{i}" for i in range(20)]
    
    print("\nTesting I/O-bound task (downloads):")
    start = time.time()
    seq_result = download_all_sequential(urls)
    seq_time = time.time() - start
    print(f"  Sequential: {seq_time:.2f}s")
    
    start = time.time()
    thr_result = download_all_threaded(urls)
    thr_time = time.time() - start
    print(f"  Threaded: {thr_time:.2f}s")
    print(f"  Speedup: {seq_time/thr_time:.1f}x")


if __name__ == "__main__":
    print("Implement the concurrent versions!")
    print("Then run: test_concurrency()")
