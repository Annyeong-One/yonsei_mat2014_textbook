"""
EXERCISE 7: Complete Optimization Project
==========================================

INSTRUCTIONS:
This is a comprehensive optimization challenge. You are given a program
with multiple performance issues. Your task is to:

1. Profile the code to identify bottlenecks
2. Optimize the bottlenecks
3. Measure and document improvements
4. Write a report of your findings

DIFFICULTY: Advanced
TIME: 2-3 hours

SCENARIO:
You work for a data analytics company. The code below processes
customer data but is too slow for production use.
"""

import time
import random


class DataProcessor:
    """Data processing system with performance issues"""
    
    def __init__(self, data):
        self.data = data
        self.cache = []  # Performance issue: using list
    
    def process(self):
        """Main processing pipeline"""
        # Step 1: Clean data
        cleaned = self.clean_data()
        
        # Step 2: Transform data
        transformed = self.transform_data(cleaned)
        
        # Step 3: Aggregate results
        results = self.aggregate_data(transformed)
        
        return results
    
    def clean_data(self):
        """Remove invalid entries"""
        # Performance issue: inefficient filtering
        result = []
        for item in self.data:
            is_valid = True
            for cached in self.cache:
                if item == cached:
                    is_valid = False
                    break
            if is_valid and item > 0:
                result.append(item)
                self.cache.append(item)
        return result
    
    def transform_data(self, data):
        """Apply transformations"""
        # Performance issue: repeated string concatenation
        result = []
        for item in data:
            label = ""
            for i in range(10):
                label += str(item) + "_"
            result.append((item, label))
        return result
    
    def aggregate_data(self, data):
        """Calculate statistics"""
        # Performance issue: inefficient calculations
        result = {}
        for item, label in data:
            if label not in result:
                result[label] = []
            result[label].append(item)
        
        # Calculate averages (inefficient)
        averages = {}
        for label, values in result.items():
            total = 0
            for v in values:
                total += v
            averages[label] = total / len(values)
        
        return averages


# YOUR TASK: Create optimized version
class OptimizedDataProcessor:
    """
    TODO: Implement optimized version
    
    Optimizations to apply:
    1. [List your optimizations]
    2. 
    3. 
    
    Expected speedup: [Your prediction]
    """
    
    def __init__(self, data):
        # Your optimized initialization
        pass
    
    def process(self):
        """Optimized processing pipeline"""
        # Your optimized code
        pass


def benchmark():
    """Benchmark original vs optimized"""
    # Generate test data
    data = [random.randint(-100, 1000) for _ in range(10000)]
    
    # Test original
    print("Testing original implementation...")
    processor1 = DataProcessor(data)
    start = time.time()
    result1 = processor1.process()
    time1 = time.time() - start
    print(f"  Time: {time1:.4f}s")
    print(f"  Results: {len(result1)} groups")
    
    # Test optimized
    print("\nTesting optimized implementation...")
    # processor2 = OptimizedDataProcessor(data)
    # start = time.time()
    # result2 = processor2.process()
    # time2 = time.time() - start
    # print(f"  Time: {time2:.4f}s")
    # print(f"  Speedup: {time1/time2:.1f}x")
    
    print("\n[TODO: Implement OptimizedDataProcessor]")


def profile_original():
    """Profile the original to find bottlenecks"""
    import cProfile
    import pstats
    
    data = [random.randint(-100, 1000) for _ in range(5000)]
    processor = DataProcessor(data)
    
    profiler = cProfile.Profile()
    profiler.enable()
    processor.process()
    profiler.disable()
    
    stats = pstats.Stats(profiler)
    stats.strip_dirs()
    stats.sort_stats('cumulative')
    print("\nProfile Results:")
    stats.print_stats(15)


if __name__ == "__main__":
    print("=" * 70)
    print("COMPLETE OPTIMIZATION PROJECT")
    print("=" * 70)
    print("\n1. First, run profile_original() to identify bottlenecks")
    print("2. Then, implement OptimizedDataProcessor")
    print("3. Finally, run benchmark() to measure improvements")
    print("\nStarting profile...\n")
    
    profile_original()
    print("\n" + "=" * 70)
    print("Now implement your optimizations!")
    print("=" * 70)
