"""
Tutorial 01: Introduction to SQLite with Python
===============================================

Topics Covered:
- What is a database?
- Introduction to SQLite
- Connecting to a database
- Creating tables
- Basic INSERT operations
- Basic SELECT queries
- Closing connections properly

Learning Objectives:
- Understand relational database basics
- Create and connect to SQLite databases
- Perform basic CREATE and INSERT operations
- Query data with simple SELECT statements
- Follow best practices for database connections

Difficulty: Beginner
Estimated Time: 45-60 minutes
"""

import sqlite3  # SQLite is built into Python, no installation needed
import os


def create_database_directory():
    """
    Create a directory to store our database files.
    This keeps our project organized.
    """
    # Check if the 'databases' directory exists
    if not os.path.exists('databases'):
        # Create the directory if it doesn't exist
        os.makedirs('databases')
        print("✓ Created 'databases' directory")
    else:
        print("✓ 'databases' directory already exists")


def basic_database_connection():
    """
    Demonstrates how to connect to a SQLite database.
    
    Key Concepts:
    - SQLite creates the database file if it doesn't exist
    - Connection objects manage the database session
    - Always close connections when done
    """
    print("\n" + "="*60)
    print("PART 1: Basic Database Connection")
    print("="*60)
    
    # Connect to a database (creates it if it doesn't exist)
    # The database file will be stored as 'databases/intro.db'
    connection = sqlite3.connect('databases/intro.db')
    print("✓ Connected to database: databases/intro.db")
    
    # A cursor object is used to execute SQL commands
    # Think of it as a pointer that traverses the database
    cursor = connection.cursor()
    print("✓ Created cursor object")
    
    # Always close the connection when finished
    # This releases system resources and ensures data is saved
    connection.close()
    print("✓ Connection closed properly")
    
    print("\nKey Takeaway: Always close database connections!")


def create_simple_table():
    """
    Demonstrates table creation with SQL CREATE TABLE statement.
    
    Key Concepts:
    - Tables have columns with specific data types
    - PRIMARY KEY uniquely identifies each row
    - Data types: INTEGER, TEXT, REAL, BLOB
    """
    print("\n" + "="*60)
    print("PART 2: Creating a Simple Table")
    print("="*60)
    
    # Establish connection
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # SQL command to create a table
    # This creates a 'students' table with three columns
    create_table_sql = """
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        age INTEGER
    )
    """
    
    # Execute the SQL command
    cursor.execute(create_table_sql)
    print("✓ Created 'students' table")
    
    # Explanation of the SQL command:
    print("\nTable Structure:")
    print("  - id: INTEGER PRIMARY KEY (unique identifier, auto-increments)")
    print("  - name: TEXT NOT NULL (required text field)")
    print("  - age: INTEGER (optional number field)")
    
    # Commit changes to save them permanently
    # Without commit(), changes are not saved to the database file
    connection.commit()
    print("\n✓ Changes committed to database")
    
    # Close connection
    connection.close()


def insert_single_record():
    """
    Demonstrates inserting a single record into a table.
    
    Key Concepts:
    - INSERT INTO statement adds new rows
    - Values can be provided directly or as parameters
    - commit() must be called to save changes
    """
    print("\n" + "="*60)
    print("PART 3: Inserting a Single Record")
    print("="*60)
    
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # Method 1: Direct value insertion
    # Note: This is NOT recommended for user input (SQL injection risk)
    insert_sql = """
    INSERT INTO students (name, age)
    VALUES ('Alice Johnson', 20)
    """
    
    cursor.execute(insert_sql)
    print("✓ Inserted: Alice Johnson, age 20")
    
    # Commit to save the change
    connection.commit()
    
    # Close connection
    connection.close()


def insert_with_parameters():
    """
    Demonstrates safe parameter insertion to prevent SQL injection.
    
    Key Concepts:
    - Use ? placeholders for values
    - Pass values as a tuple to execute()
    - This prevents SQL injection attacks
    - More secure than string concatenation
    """
    print("\n" + "="*60)
    print("PART 4: Safe Parameter Insertion")
    print("="*60)
    
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # SAFE method: Use placeholders (?)
    # This is the RECOMMENDED approach for all insertions
    insert_sql = """
    INSERT INTO students (name, age)
    VALUES (?, ?)
    """
    
    # Student data
    student_name = "Bob Smith"
    student_age = 22
    
    # Execute with parameters as a tuple
    # The ? placeholders are replaced with the tuple values
    cursor.execute(insert_sql, (student_name, student_age))
    print(f"✓ Inserted: {student_name}, age {student_age}")
    
    connection.commit()
    connection.close()
    
    print("\n⚠ Always use parameterized queries to prevent SQL injection!")


def insert_multiple_records():
    """
    Demonstrates inserting multiple records efficiently.
    
    Key Concepts:
    - executemany() for bulk inserts
    - More efficient than multiple execute() calls
    - Data passed as a list of tuples
    """
    print("\n" + "="*60)
    print("PART 5: Inserting Multiple Records")
    print("="*60)
    
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # Multiple students as a list of tuples
    students = [
        ('Carol White', 21),
        ('David Brown', 19),
        ('Eve Davis', 23),
        ('Frank Miller', 20)
    ]
    
    # SQL with placeholders
    insert_sql = """
    INSERT INTO students (name, age)
    VALUES (?, ?)
    """
    
    # executemany() efficiently inserts all records
    cursor.executemany(insert_sql, students)
    print(f"✓ Inserted {len(students)} students in bulk")
    
    # Print each student
    for name, age in students:
        print(f"  - {name}, age {age}")
    
    connection.commit()
    connection.close()


def select_all_records():
    """
    Demonstrates retrieving all records from a table.
    
    Key Concepts:
    - SELECT statement retrieves data
    - fetchall() returns all matching rows
    - Each row is a tuple
    - * means "all columns"
    """
    print("\n" + "="*60)
    print("PART 6: Selecting All Records")
    print("="*60)
    
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # SELECT statement to retrieve all data
    # * means "select all columns"
    select_sql = "SELECT * FROM students"
    
    # Execute the query
    cursor.execute(select_sql)
    
    # fetchall() retrieves all matching rows as a list of tuples
    all_students = cursor.fetchall()
    
    print(f"\nTotal students in database: {len(all_students)}\n")
    
    # Display each student
    print("ID | Name              | Age")
    print("-" * 40)
    for student in all_students:
        # Each student is a tuple: (id, name, age)
        student_id, name, age = student
        print(f"{student_id:2d} | {name:17s} | {age}")
    
    # Note: No commit() needed for SELECT queries
    # SELECT doesn't modify the database
    connection.close()


def select_specific_columns():
    """
    Demonstrates selecting specific columns instead of all columns.
    
    Key Concepts:
    - Specify column names instead of *
    - More efficient than selecting all columns
    - Results still returned as tuples
    """
    print("\n" + "="*60)
    print("PART 7: Selecting Specific Columns")
    print("="*60)
    
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # Select only the name column
    select_sql = "SELECT name FROM students"
    cursor.execute(select_sql)
    names = cursor.fetchall()
    
    print("\nAll student names:")
    for (name,) in names:  # Each result is a tuple with one element
        print(f"  - {name}")
    
    # Select multiple specific columns
    select_sql = "SELECT name, age FROM students"
    cursor.execute(select_sql)
    students = cursor.fetchall()
    
    print("\nNames and ages:")
    for name, age in students:
        print(f"  - {name}: {age} years old")
    
    connection.close()


def select_with_where_clause():
    """
    Demonstrates filtering results with WHERE clause.
    
    Key Concepts:
    - WHERE filters rows based on conditions
    - Use parameterized queries for user input
    - Common operators: =, >, <, >=, <=, !=
    """
    print("\n" + "="*60)
    print("PART 8: Filtering with WHERE Clause")
    print("="*60)
    
    connection = sqlite3.connect('databases/intro.db')
    cursor = connection.cursor()
    
    # Find students older than 20
    select_sql = "SELECT * FROM students WHERE age > ?"
    cursor.execute(select_sql, (20,))
    older_students = cursor.fetchall()
    
    print("\nStudents older than 20:")
    for student_id, name, age in older_students:
        print(f"  - {name}, age {age}")
    
    # Find a specific student by name
    select_sql = "SELECT * FROM students WHERE name = ?"
    cursor.execute(select_sql, ('Alice Johnson',))
    alice = cursor.fetchone()  # fetchone() returns a single row
    
    if alice:
        print(f"\nFound student: {alice[1]}, age {alice[2]}")
    else:
        print("\nStudent not found")
    
    connection.close()


def demonstrate_context_manager():
    """
    Demonstrates using context managers for automatic cleanup.
    
    Key Concepts:
    - 'with' statement ensures proper cleanup
    - Connection automatically closed on exit
    - More Pythonic and safer
    - Recommended for production code
    """
    print("\n" + "="*60)
    print("PART 9: Using Context Managers (Best Practice)")
    print("="*60)
    
    # The 'with' statement automatically handles connection cleanup
    # Even if an error occurs, the connection will be closed properly
    with sqlite3.connect('databases/intro.db') as connection:
        cursor = connection.cursor()
        
        # Query the database
        cursor.execute("SELECT COUNT(*) FROM students")
        count = cursor.fetchone()[0]
        
        print(f"\nTotal students: {count}")
        print("\n✓ Using 'with' statement - connection will close automatically")
    
    # Connection is automatically closed here
    print("✓ Connection closed by context manager")
    
    print("\n⭐ Best Practice: Use 'with' statements for database connections!")


def main():
    """
    Main function to run all examples in sequence.
    """
    print("\n")
    print("="*60)
    print("TUTORIAL 01: INTRODUCTION TO SQLITE WITH PYTHON")
    print("="*60)
    
    # Create database directory
    create_database_directory()
    
    # Part 1: Basic connection
    basic_database_connection()
    
    # Part 2: Create table
    create_simple_table()
    
    # Part 3: Insert single record
    insert_single_record()
    
    # Part 4: Safe parameter insertion
    insert_with_parameters()
    
    # Part 5: Insert multiple records
    insert_multiple_records()
    
    # Part 6: Select all records
    select_all_records()
    
    # Part 7: Select specific columns
    select_specific_columns()
    
    # Part 8: Filter with WHERE
    select_with_where_clause()
    
    # Part 9: Context managers
    demonstrate_context_manager()
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print("""
Key Concepts Covered:
1. ✓ Connecting to SQLite databases
2. ✓ Creating tables with CREATE TABLE
3. ✓ Inserting data with INSERT INTO
4. ✓ Querying data with SELECT
5. ✓ Filtering with WHERE clause
6. ✓ Using parameterized queries (prevent SQL injection)
7. ✓ Context managers for automatic cleanup

Next Steps:
- Practice: Create your own table and insert data
- Next Tutorial: 02_intermediate_sql_operations.py
- Exercise: Complete exercise_01_basics.py
    """)


if __name__ == "__main__":
    # This ensures the code only runs when the file is executed directly
    # Not when it's imported as a module
    main()
