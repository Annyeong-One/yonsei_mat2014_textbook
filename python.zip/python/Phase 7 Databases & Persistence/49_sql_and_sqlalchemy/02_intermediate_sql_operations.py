"""
Tutorial 02: Intermediate SQL Operations
=========================================

Topics Covered:
- UPDATE operations
- DELETE operations
- ORDER BY clause
- LIMIT and OFFSET
- Aggregate functions (COUNT, SUM, AVG, MIN, MAX)
- GROUP BY and HAVING
- String pattern matching with LIKE
- Working with NULL values

Learning Objectives:
- Modify existing data with UPDATE
- Remove data with DELETE
- Sort and limit query results
- Perform aggregate calculations
- Group data for analysis
- Use pattern matching in queries

Difficulty: Beginner-Intermediate
Estimated Time: 60-75 minutes
"""

import sqlite3
import os


def setup_sample_database():
    """
    Creates a fresh database with sample data for demonstrations.
    
    Key Concepts:
    - DROP TABLE removes existing tables
    - Creates a more complex schema with additional columns
    """
    print("\n" + "="*60)
    print("SETUP: Creating Sample Database")
    print("="*60)
    
    # Ensure databases directory exists
    if not os.path.exists('databases'):
        os.makedirs('databases')
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Drop existing table if it exists (for clean demo)
        cursor.execute("DROP TABLE IF EXISTS students")
        
        # Create students table with more fields
        cursor.execute("""
            CREATE TABLE students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER,
                grade REAL,
                major TEXT,
                email TEXT
            )
        """)
        
        # Insert sample data
        students = [
            ('Alice Johnson', 20, 3.8, 'Computer Science', 'alice@university.edu'),
            ('Bob Smith', 22, 3.2, 'Mathematics', 'bob@university.edu'),
            ('Carol White', 21, 3.9, 'Computer Science', 'carol@university.edu'),
            ('David Brown', 19, 2.8, 'Physics', 'david@university.edu'),
            ('Eve Davis', 23, 3.6, 'Computer Science', 'eve@university.edu'),
            ('Frank Miller', 20, 3.4, 'Mathematics', None),  # NULL email
            ('Grace Lee', 21, 3.7, 'Physics', 'grace@university.edu'),
            ('Henry Wilson', 22, 2.9, 'Mathematics', 'henry@university.edu'),
            ('Ivy Chen', 20, 4.0, 'Computer Science', 'ivy@university.edu'),
            ('Jack Taylor', 19, 3.1, 'Physics', None)  # NULL email
        ]
        
        cursor.executemany("""
            INSERT INTO students (name, age, grade, major, email)
            VALUES (?, ?, ?, ?, ?)
        """, students)
        
        conn.commit()
        print(f"✓ Created database with {len(students)} sample students")


def demonstrate_update():
    """
    Demonstrates updating existing records.
    
    Key Concepts:
    - UPDATE modifies existing rows
    - WHERE clause specifies which rows to update
    - Without WHERE, ALL rows are updated
    - Always use WHERE unless you want to update all rows
    """
    print("\n" + "="*60)
    print("PART 1: UPDATE Operations")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Update a single record
        print("\n1. Updating Bob's grade:")
        
        # Check current grade
        cursor.execute("SELECT name, grade FROM students WHERE name = ?", ('Bob Smith',))
        before = cursor.fetchone()
        print(f"   Before: {before[0]} has grade {before[1]}")
        
        # Update the grade
        cursor.execute("""
            UPDATE students
            SET grade = ?
            WHERE name = ?
        """, (3.5, 'Bob Smith'))
        
        # Check updated grade
        cursor.execute("SELECT name, grade FROM students WHERE name = ?", ('Bob Smith',))
        after = cursor.fetchone()
        print(f"   After:  {after[0]} has grade {after[1]}")
        
        # Example 2: Update multiple columns
        print("\n2. Updating multiple columns for Alice:")
        cursor.execute("""
            UPDATE students
            SET age = ?, grade = ?
            WHERE name = ?
        """, (21, 3.9, 'Alice Johnson'))
        print("   ✓ Updated Alice's age and grade")
        
        # Example 3: Update with conditions
        print("\n3. Giving bonus points to Physics majors:")
        cursor.execute("""
            UPDATE students
            SET grade = grade + 0.1
            WHERE major = ? AND grade < 4.0
        """, ('Physics',))
        
        # Get affected rows
        affected = cursor.rowcount
        print(f"   ✓ Updated {affected} Physics students")
        
        conn.commit()
    
    print("\n⚠ WARNING: UPDATE without WHERE updates ALL rows!")


def demonstrate_delete():
    """
    Demonstrates deleting records from tables.
    
    Key Concepts:
    - DELETE removes rows permanently
    - WHERE clause specifies which rows to delete
    - Without WHERE, ALL rows are deleted
    - There is no "undo" - use with caution
    """
    print("\n" + "="*60)
    print("PART 2: DELETE Operations")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Count before deletion
        cursor.execute("SELECT COUNT(*) FROM students")
        count_before = cursor.fetchone()[0]
        print(f"\nTotal students before deletion: {count_before}")
        
        # Example 1: Delete specific record
        print("\n1. Deleting a specific student:")
        cursor.execute("""
            DELETE FROM students
            WHERE name = ?
        """, ('Jack Taylor',))
        print(f"   ✓ Deleted {cursor.rowcount} student(s)")
        
        # Example 2: Delete with conditions
        print("\n2. Deleting students with low grades:")
        cursor.execute("""
            DELETE FROM students
            WHERE grade < 3.0
        """)
        print(f"   ✓ Deleted {cursor.rowcount} student(s) with grade < 3.0")
        
        # Count after deletion
        cursor.execute("SELECT COUNT(*) FROM students")
        count_after = cursor.fetchone()[0]
        print(f"\nTotal students after deletion: {count_after}")
        print(f"Students deleted: {count_before - count_after}")
        
        conn.commit()
    
    print("\n⚠ WARNING: DELETE without WHERE deletes ALL rows!")
    print("   Better: Use DELETE with WHERE to be specific")


def demonstrate_order_by():
    """
    Demonstrates sorting query results.
    
    Key Concepts:
    - ORDER BY sorts results
    - ASC (ascending) is default
    - DESC for descending order
    - Can sort by multiple columns
    """
    print("\n" + "="*60)
    print("PART 3: ORDER BY - Sorting Results")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Sort by name (ascending)
        print("\n1. Students sorted by name (A-Z):")
        cursor.execute("""
            SELECT name, grade
            FROM students
            ORDER BY name ASC
            LIMIT 5
        """)
        
        for name, grade in cursor.fetchall():
            print(f"   {name:20s} - Grade: {grade}")
        
        # Example 2: Sort by grade (descending)
        print("\n2. Top 5 students by grade:")
        cursor.execute("""
            SELECT name, grade
            FROM students
            ORDER BY grade DESC
            LIMIT 5
        """)
        
        for i, (name, grade) in enumerate(cursor.fetchall(), 1):
            print(f"   {i}. {name:20s} - Grade: {grade}")
        
        # Example 3: Sort by multiple columns
        print("\n3. Students sorted by major, then by grade:")
        cursor.execute("""
            SELECT name, major, grade
            FROM students
            ORDER BY major ASC, grade DESC
            LIMIT 6
        """)
        
        current_major = None
        for name, major, grade in cursor.fetchall():
            if major != current_major:
                print(f"\n   {major}:")
                current_major = major
            print(f"      {name:20s} - Grade: {grade}")


def demonstrate_limit_offset():
    """
    Demonstrates pagination with LIMIT and OFFSET.
    
    Key Concepts:
    - LIMIT restricts number of results
    - OFFSET skips a number of rows
    - Useful for pagination (e.g., pages of results)
    - Always use with ORDER BY for consistent results
    """
    print("\n" + "="*60)
    print("PART 4: LIMIT and OFFSET - Pagination")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Get total count
        cursor.execute("SELECT COUNT(*) FROM students")
        total = cursor.fetchone()[0]
        print(f"\nTotal students: {total}")
        
        # Example: Paginate through results
        page_size = 3
        total_pages = (total + page_size - 1) // page_size  # Ceiling division
        
        print(f"Page size: {page_size} students per page")
        print(f"Total pages: {total_pages}\n")
        
        for page in range(1, min(4, total_pages + 1)):  # Show first 3 pages
            offset = (page - 1) * page_size
            
            print(f"Page {page}:")
            cursor.execute("""
                SELECT name, grade
                FROM students
                ORDER BY grade DESC
                LIMIT ? OFFSET ?
            """, (page_size, offset))
            
            for name, grade in cursor.fetchall():
                print(f"   {name:20s} - Grade: {grade}")
            print()


def demonstrate_aggregate_functions():
    """
    Demonstrates aggregate functions for data analysis.
    
    Key Concepts:
    - COUNT(*) counts all rows
    - SUM() adds numeric values
    - AVG() calculates average
    - MIN() finds minimum value
    - MAX() finds maximum value
    - Aggregate functions work on columns
    """
    print("\n" + "="*60)
    print("PART 5: Aggregate Functions")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Basic aggregates
        print("\n1. Overall statistics:")
        cursor.execute("""
            SELECT 
                COUNT(*) as total_students,
                AVG(grade) as avg_grade,
                MIN(grade) as min_grade,
                MAX(grade) as max_grade,
                MIN(age) as min_age,
                MAX(age) as max_age
            FROM students
        """)
        
        stats = cursor.fetchone()
        print(f"   Total Students: {stats[0]}")
        print(f"   Average Grade:  {stats[1]:.2f}")
        print(f"   Grade Range:    {stats[2]:.1f} - {stats[3]:.1f}")
        print(f"   Age Range:      {stats[4]} - {stats[5]}")
        
        # Example 2: COUNT with WHERE
        print("\n2. Students by major:")
        majors = ['Computer Science', 'Mathematics', 'Physics']
        
        for major in majors:
            cursor.execute("""
                SELECT COUNT(*)
                FROM students
                WHERE major = ?
            """, (major,))
            count = cursor.fetchone()[0]
            print(f"   {major:20s}: {count} students")
        
        # Example 3: Advanced calculations
        print("\n3. Honor roll (grade >= 3.5):")
        cursor.execute("""
            SELECT COUNT(*) as honor_students
            FROM students
            WHERE grade >= 3.5
        """)
        honor_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM students")
        total_count = cursor.fetchone()[0]
        
        percentage = (honor_count / total_count) * 100 if total_count > 0 else 0
        print(f"   Honor students: {honor_count} out of {total_count} ({percentage:.1f}%)")


def demonstrate_group_by():
    """
    Demonstrates grouping data for analysis.
    
    Key Concepts:
    - GROUP BY groups rows with same values
    - Used with aggregate functions
    - Each group returns one result row
    - Can group by multiple columns
    """
    print("\n" + "="*60)
    print("PART 6: GROUP BY - Grouping Data")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Group by major
        print("\n1. Average grade by major:")
        cursor.execute("""
            SELECT 
                major,
                COUNT(*) as student_count,
                AVG(grade) as avg_grade,
                MIN(grade) as min_grade,
                MAX(grade) as max_grade
            FROM students
            GROUP BY major
            ORDER BY avg_grade DESC
        """)
        
        print(f"   {'Major':20s} | Count | Avg   | Min  | Max")
        print("   " + "-" * 50)
        for major, count, avg, min_g, max_g in cursor.fetchall():
            print(f"   {major:20s} | {count:5d} | {avg:5.2f} | {min_g:4.1f} | {max_g:4.1f}")
        
        # Example 2: Group by age
        print("\n2. Students grouped by age:")
        cursor.execute("""
            SELECT 
                age,
                COUNT(*) as student_count,
                AVG(grade) as avg_grade
            FROM students
            GROUP BY age
            ORDER BY age
        """)
        
        for age, count, avg_grade in cursor.fetchall():
            print(f"   Age {age}: {count} students, avg grade {avg_grade:.2f}")


def demonstrate_having_clause():
    """
    Demonstrates filtering grouped results with HAVING.
    
    Key Concepts:
    - HAVING filters GROUP BY results
    - WHERE filters rows before grouping
    - HAVING filters groups after aggregation
    - Use HAVING with aggregate functions
    """
    print("\n" + "="*60)
    print("PART 7: HAVING - Filtering Groups")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Majors with multiple students
        print("\n1. Majors with more than 2 students:")
        cursor.execute("""
            SELECT 
                major,
                COUNT(*) as student_count,
                AVG(grade) as avg_grade
            FROM students
            GROUP BY major
            HAVING COUNT(*) > 2
            ORDER BY student_count DESC
        """)
        
        for major, count, avg_grade in cursor.fetchall():
            print(f"   {major:20s}: {count} students (avg: {avg_grade:.2f})")
        
        # Example 2: High-performing majors
        print("\n2. Majors with average grade > 3.5:")
        cursor.execute("""
            SELECT 
                major,
                COUNT(*) as student_count,
                AVG(grade) as avg_grade
            FROM students
            GROUP BY major
            HAVING AVG(grade) > 3.5
            ORDER BY avg_grade DESC
        """)
        
        for major, count, avg_grade in cursor.fetchall():
            print(f"   {major:20s}: {count} students (avg: {avg_grade:.2f})")
    
    print("\n📝 Note: WHERE filters rows, HAVING filters groups")


def demonstrate_like_pattern_matching():
    """
    Demonstrates pattern matching with LIKE operator.
    
    Key Concepts:
    - LIKE performs pattern matching on strings
    - % matches any sequence of characters
    - _ matches exactly one character
    - Case-insensitive by default in SQLite
    """
    print("\n" + "="*60)
    print("PART 8: LIKE - Pattern Matching")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Names starting with 'A'
        print("\n1. Students whose names start with 'A':")
        cursor.execute("""
            SELECT name, major
            FROM students
            WHERE name LIKE 'A%'
            ORDER BY name
        """)
        
        for name, major in cursor.fetchall():
            print(f"   {name:20s} - {major}")
        
        # Example 2: Names containing 'son'
        print("\n2. Students with 'son' in their name:")
        cursor.execute("""
            SELECT name
            FROM students
            WHERE name LIKE '%son%'
        """)
        
        for (name,) in cursor.fetchall():
            print(f"   {name}")
        
        # Example 3: Email domain matching
        print("\n3. Emails from university.edu:")
        cursor.execute("""
            SELECT name, email
            FROM students
            WHERE email LIKE '%@university.edu'
        """)
        
        for name, email in cursor.fetchall():
            print(f"   {name:20s} - {email}")
        
        # Example 4: Underscore pattern (exactly one character)
        print("\n4. Three-letter first names:")
        cursor.execute("""
            SELECT name
            FROM students
            WHERE name LIKE '___ %'
        """)
        
        for (name,) in cursor.fetchall():
            print(f"   {name}")


def demonstrate_null_handling():
    """
    Demonstrates working with NULL values.
    
    Key Concepts:
    - NULL represents missing/unknown data
    - NULL is not equal to anything (not even NULL)
    - Use IS NULL and IS NOT NULL
    - NULL in calculations returns NULL
    """
    print("\n" + "="*60)
    print("PART 9: Working with NULL Values")
    print("="*60)
    
    with sqlite3.connect('databases/intermediate.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Find NULL emails
        print("\n1. Students without email addresses:")
        cursor.execute("""
            SELECT name, major
            FROM students
            WHERE email IS NULL
        """)
        
        for name, major in cursor.fetchall():
            print(f"   {name:20s} - {major}")
        
        # Example 2: Count NULL values
        print("\n2. Email statistics:")
        cursor.execute("""
            SELECT 
                COUNT(*) as total_students,
                COUNT(email) as students_with_email,
                COUNT(*) - COUNT(email) as students_without_email
            FROM students
        """)
        
        total, with_email, without_email = cursor.fetchone()
        print(f"   Total students:         {total}")
        print(f"   With email:             {with_email}")
        print(f"   Without email (NULL):   {without_email}")
        
        # Example 3: Update NULL values
        print("\n3. Setting default email for NULL values:")
        cursor.execute("""
            UPDATE students
            SET email = name || '@pending.edu'
            WHERE email IS NULL
        """)
        
        print(f"   ✓ Updated {cursor.rowcount} student(s)")
        
        # Verify
        cursor.execute("SELECT name, email FROM students WHERE email LIKE '%@pending.edu'")
        print("\n   Updated emails:")
        for name, email in cursor.fetchall():
            print(f"   {name:20s} - {email}")
        
        conn.commit()
    
    print("\n⚠ Remember: Use IS NULL, not = NULL")


def main():
    """
    Main function to run all demonstrations.
    """
    print("\n")
    print("="*60)
    print("TUTORIAL 02: INTERMEDIATE SQL OPERATIONS")
    print("="*60)
    
    # Setup
    setup_sample_database()
    
    # Run demonstrations
    demonstrate_update()
    demonstrate_delete()
    demonstrate_order_by()
    demonstrate_limit_offset()
    demonstrate_aggregate_functions()
    demonstrate_group_by()
    demonstrate_having_clause()
    demonstrate_like_pattern_matching()
    demonstrate_null_handling()
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print("""
Key Concepts Covered:
1. ✓ UPDATE - Modify existing records
2. ✓ DELETE - Remove records
3. ✓ ORDER BY - Sort results
4. ✓ LIMIT/OFFSET - Paginate results
5. ✓ Aggregate functions (COUNT, AVG, MIN, MAX, SUM)
6. ✓ GROUP BY - Group data for analysis
7. ✓ HAVING - Filter grouped results
8. ✓ LIKE - Pattern matching
9. ✓ NULL handling - IS NULL, IS NOT NULL

Important Warnings:
⚠ UPDATE without WHERE updates ALL rows
⚠ DELETE without WHERE deletes ALL rows
⚠ Always use WHERE clauses to be specific

Next Steps:
- Practice: Try the operations on your own data
- Next Tutorial: 03_advanced_sql_queries.py
- Exercise: Complete exercise_02_operations.py
    """)


if __name__ == "__main__":
    main()
