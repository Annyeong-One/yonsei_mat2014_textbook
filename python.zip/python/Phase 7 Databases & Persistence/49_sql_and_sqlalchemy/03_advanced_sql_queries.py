"""
Tutorial 03: Advanced SQL Queries
==================================

Topics Covered:
- Database normalization and relationships
- INNER JOIN, LEFT JOIN, RIGHT JOIN
- Multiple table joins
- Subqueries (scalar, column, table)
- UNION and UNION ALL
- Transactions and ACID properties
- Indexes for performance
- Views for query simplification

Learning Objectives:
- Design normalized database schemas
- Join multiple tables effectively
- Use subqueries for complex queries
- Understand transaction management
- Optimize queries with indexes

Difficulty: Intermediate-Advanced
Estimated Time: 90-120 minutes
"""

import sqlite3
import os
from datetime import datetime, timedelta
import random


def setup_relational_database():
    """
    Creates a properly normalized database with multiple related tables.
    
    Key Concepts:
    - Database normalization reduces redundancy
    - Foreign keys establish relationships
    - Primary keys uniquely identify records
    - One-to-many and many-to-many relationships
    """
    print("\n" + "="*60)
    print("SETUP: Creating Relational Database")
    print("="*60)
    
    if not os.path.exists('databases'):
        os.makedirs('databases')
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Enable foreign key constraints (not enabled by default in SQLite)
        cursor.execute("PRAGMA foreign_keys = ON")
        
        # Drop existing tables
        cursor.execute("DROP TABLE IF EXISTS enrollments")
        cursor.execute("DROP TABLE IF EXISTS courses")
        cursor.execute("DROP TABLE IF EXISTS students")
        cursor.execute("DROP TABLE IF EXISTS departments")
        
        # Create departments table
        cursor.execute("""
            CREATE TABLE departments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE,
                building TEXT,
                budget REAL
            )
        """)
        
        # Create students table
        cursor.execute("""
            CREATE TABLE students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                department_id INTEGER,
                enrollment_year INTEGER,
                gpa REAL,
                FOREIGN KEY (department_id) REFERENCES departments(id)
            )
        """)
        
        # Create courses table
        cursor.execute("""
            CREATE TABLE courses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                credits INTEGER,
                department_id INTEGER,
                max_students INTEGER,
                FOREIGN KEY (department_id) REFERENCES departments(id)
            )
        """)
        
        # Create enrollments table (junction table for many-to-many)
        cursor.execute("""
            CREATE TABLE enrollments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id INTEGER NOT NULL,
                course_id INTEGER NOT NULL,
                semester TEXT,
                grade REAL,
                enrollment_date TEXT,
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (course_id) REFERENCES courses(id),
                UNIQUE(student_id, course_id, semester)
            )
        """)
        
        # Insert departments
        departments = [
            ('Computer Science', 'Engineering Hall', 500000),
            ('Mathematics', 'Science Building', 300000),
            ('Physics', 'Science Building', 450000),
            ('English', 'Liberal Arts Center', 250000)
        ]
        cursor.executemany("""
            INSERT INTO departments (name, building, budget)
            VALUES (?, ?, ?)
        """, departments)
        
        # Insert students
        students = [
            ('Alice Johnson', 'alice@university.edu', 1, 2023, 3.8),
            ('Bob Smith', 'bob@university.edu', 2, 2023, 3.2),
            ('Carol White', 'carol@university.edu', 1, 2022, 3.9),
            ('David Brown', 'david@university.edu', 3, 2024, 3.1),
            ('Eve Davis', 'eve@university.edu', 1, 2023, 3.7),
            ('Frank Miller', 'frank@university.edu', 2, 2022, 3.5),
            ('Grace Lee', 'grace@university.edu', 3, 2024, 3.6),
            ('Henry Wilson', 'henry@university.edu', 4, 2023, 3.3)
        ]
        cursor.executemany("""
            INSERT INTO students (name, email, department_id, enrollment_year, gpa)
            VALUES (?, ?, ?, ?, ?)
        """, students)
        
        # Insert courses
        courses = [
            ('CS101', 'Introduction to Programming', 3, 1, 30),
            ('CS201', 'Data Structures', 4, 1, 25),
            ('CS301', 'Algorithms', 4, 1, 20),
            ('MATH101', 'Calculus I', 4, 2, 40),
            ('MATH201', 'Linear Algebra', 3, 2, 30),
            ('PHYS101', 'Physics I', 4, 3, 35),
            ('PHYS201', 'Quantum Mechanics', 4, 3, 15),
            ('ENG101', 'Composition', 3, 4, 50)
        ]
        cursor.executemany("""
            INSERT INTO courses (code, name, credits, department_id, max_students)
            VALUES (?, ?, ?, ?, ?)
        """, courses)
        
        # Insert enrollments (many-to-many relationship)
        # Generate realistic enrollment data
        enrollments = [
            (1, 1, 'Fall 2023', 3.7, '2023-08-15'),
            (1, 2, 'Fall 2023', 3.9, '2023-08-15'),
            (1, 4, 'Fall 2023', 3.5, '2023-08-15'),
            (2, 4, 'Fall 2023', 3.0, '2023-08-15'),
            (2, 5, 'Fall 2023', 3.4, '2023-08-15'),
            (3, 1, 'Fall 2022', 4.0, '2022-08-15'),
            (3, 2, 'Spring 2023', 3.8, '2023-01-10'),
            (3, 3, 'Fall 2023', 3.9, '2023-08-15'),
            (4, 6, 'Spring 2024', 3.2, '2024-01-10'),
            (5, 1, 'Fall 2023', 3.8, '2023-08-15'),
            (5, 2, 'Fall 2023', 3.6, '2023-08-15'),
            (6, 4, 'Fall 2022', 3.7, '2022-08-15'),
            (6, 5, 'Spring 2023', 3.3, '2023-01-10'),
            (7, 6, 'Spring 2024', 3.5, '2024-01-10'),
            (8, 8, 'Fall 2023', 3.4, '2023-08-15')
        ]
        cursor.executemany("""
            INSERT INTO enrollments (student_id, course_id, semester, grade, enrollment_date)
            VALUES (?, ?, ?, ?, ?)
        """, enrollments)
        
        conn.commit()
        print("✓ Created normalized database with 4 tables")
        print(f"   - {len(departments)} departments")
        print(f"   - {len(students)} students")
        print(f"   - {len(courses)} courses")
        print(f"   - {len(enrollments)} enrollments")


def demonstrate_inner_join():
    """
    Demonstrates INNER JOIN to combine related tables.
    
    Key Concepts:
    - INNER JOIN returns only matching rows from both tables
    - Join condition usually involves foreign key = primary key
    - Can alias table names for shorter syntax
    - Multiple joins can be chained
    """
    print("\n" + "="*60)
    print("PART 1: INNER JOIN")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Simple join
        print("\n1. Students with their department names:")
        cursor.execute("""
            SELECT 
                s.name AS student_name,
                d.name AS department_name,
                s.gpa
            FROM students s
            INNER JOIN departments d ON s.department_id = d.id
            ORDER BY s.name
        """)
        
        print(f"   {'Student':20s} | {'Department':20s} | GPA")
        print("   " + "-" * 55)
        for student, dept, gpa in cursor.fetchall():
            print(f"   {student:20s} | {dept:20s} | {gpa:.2f}")
        
        # Example 2: Join three tables
        print("\n2. Student enrollments with course details:")
        cursor.execute("""
            SELECT 
                s.name AS student_name,
                c.code,
                c.name AS course_name,
                e.semester,
                e.grade
            FROM enrollments e
            INNER JOIN students s ON e.student_id = s.id
            INNER JOIN courses c ON e.course_id = c.id
            WHERE s.name = 'Alice Johnson'
            ORDER BY e.semester, c.code
        """)
        
        print(f"\n   Alice Johnson's Courses:")
        print(f"   {'Code':8s} | {'Course':30s} | {'Semester':12s} | Grade")
        print("   " + "-" * 65)
        for name, code, course, semester, grade in cursor.fetchall():
            print(f"   {code:8s} | {course:30s} | {semester:12s} | {grade:.1f}")


def demonstrate_left_join():
    """
    Demonstrates LEFT JOIN to include all rows from the left table.
    
    Key Concepts:
    - LEFT JOIN returns all rows from left table
    - Returns NULL for non-matching right table columns
    - Useful for finding missing relationships
    - Also called LEFT OUTER JOIN
    """
    print("\n" + "="*60)
    print("PART 2: LEFT JOIN (LEFT OUTER JOIN)")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: All courses with enrollment count
        print("\n1. All courses with their enrollment counts:")
        cursor.execute("""
            SELECT 
                c.code,
                c.name,
                c.max_students,
                COUNT(e.id) AS enrolled_count
            FROM courses c
            LEFT JOIN enrollments e ON c.id = e.course_id
            GROUP BY c.id, c.code, c.name, c.max_students
            ORDER BY c.code
        """)
        
        print(f"   {'Code':8s} | {'Course':30s} | Max | Enrolled")
        print("   " + "-" * 60)
        for code, name, max_students, enrolled in cursor.fetchall():
            print(f"   {code:8s} | {name:30s} | {max_students:3d} | {enrolled:3d}")
        
        # Example 2: Students without enrollments
        print("\n2. Students not enrolled in any courses:")
        cursor.execute("""
            SELECT 
                s.name,
                s.email,
                d.name AS department
            FROM students s
            LEFT JOIN enrollments e ON s.id = e.student_id
            LEFT JOIN departments d ON s.department_id = d.id
            WHERE e.id IS NULL
        """)
        
        results = cursor.fetchall()
        if results:
            for name, email, dept in results:
                print(f"   {name:20s} | {email:30s} | {dept}")
        else:
            print("   (All students are enrolled in at least one course)")


def demonstrate_multiple_joins():
    """
    Demonstrates complex queries with multiple joins.
    
    Key Concepts:
    - Can join many tables in one query
    - Join order matters for readability
    - Use meaningful table aliases
    - Combine joins with WHERE, GROUP BY, etc.
    """
    print("\n" + "="*60)
    print("PART 3: Multiple Table Joins")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example: Complete student record with all relationships
        print("\n1. Complete student records with department and course info:")
        cursor.execute("""
            SELECT 
                s.name AS student_name,
                d.name AS department,
                d.building,
                c.code AS course_code,
                c.name AS course_name,
                e.semester,
                e.grade
            FROM students s
            INNER JOIN departments d ON s.department_id = d.id
            LEFT JOIN enrollments e ON s.id = e.student_id
            LEFT JOIN courses c ON e.course_id = c.id
            WHERE s.name IN ('Alice Johnson', 'Carol White')
            ORDER BY s.name, e.semester, c.code
        """)
        
        current_student = None
        for student, dept, building, code, course, semester, grade in cursor.fetchall():
            if student != current_student:
                print(f"\n   {student}")
                print(f"   Department: {dept} ({building})")
                print(f"   Courses:")
                current_student = student
            
            if code:  # If student has enrollments
                print(f"      {code}: {course:30s} ({semester}) - Grade: {grade:.1f}")


def demonstrate_subqueries():
    """
    Demonstrates subqueries for complex data retrieval.
    
    Key Concepts:
    - Subquery: a query nested inside another query
    - Scalar subquery: returns single value
    - Column subquery: returns single column
    - Table subquery: returns result set
    - Can be used in SELECT, FROM, WHERE clauses
    """
    print("\n" + "="*60)
    print("PART 4: Subqueries")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Scalar subquery in SELECT
        print("\n1. Students with GPA above average:")
        cursor.execute("""
            SELECT 
                name,
                gpa,
                (SELECT AVG(gpa) FROM students) AS avg_gpa,
                gpa - (SELECT AVG(gpa) FROM students) AS diff_from_avg
            FROM students
            WHERE gpa > (SELECT AVG(gpa) FROM students)
            ORDER BY gpa DESC
        """)
        
        print(f"   {'Student':20s} | GPA  | Avg  | Diff")
        print("   " + "-" * 50)
        for name, gpa, avg_gpa, diff in cursor.fetchall():
            print(f"   {name:20s} | {gpa:.2f} | {avg_gpa:.2f} | +{diff:.2f}")
        
        # Example 2: Subquery with IN operator
        print("\n2. Students enrolled in Computer Science courses:")
        cursor.execute("""
            SELECT DISTINCT
                s.name,
                s.email
            FROM students s
            WHERE s.id IN (
                SELECT DISTINCT e.student_id
                FROM enrollments e
                INNER JOIN courses c ON e.course_id = c.id
                INNER JOIN departments d ON c.department_id = d.id
                WHERE d.name = 'Computer Science'
            )
            ORDER BY s.name
        """)
        
        for name, email in cursor.fetchall():
            print(f"   {name:20s} - {email}")
        
        # Example 3: Correlated subquery
        print("\n3. Courses with above-average enrollment:")
        cursor.execute("""
            SELECT 
                c.code,
                c.name,
                (
                    SELECT COUNT(*)
                    FROM enrollments e
                    WHERE e.course_id = c.id
                ) AS enrollment_count
            FROM courses c
            WHERE (
                SELECT COUNT(*)
                FROM enrollments e
                WHERE e.course_id = c.id
            ) > (
                SELECT AVG(enrollment_count)
                FROM (
                    SELECT COUNT(*) AS enrollment_count
                    FROM enrollments
                    GROUP BY course_id
                )
            )
            ORDER BY enrollment_count DESC
        """)
        
        print(f"\n   {'Code':8s} | {'Course':30s} | Enrolled")
        print("   " + "-" * 50)
        for code, name, count in cursor.fetchall():
            print(f"   {code:8s} | {name:30s} | {count}")


def demonstrate_union():
    """
    Demonstrates UNION to combine results from multiple queries.
    
    Key Concepts:
    - UNION combines results from multiple SELECT statements
    - UNION removes duplicates
    - UNION ALL keeps all rows including duplicates
    - All queries must have same number of columns
    - Column types must be compatible
    """
    print("\n" + "="*60)
    print("PART 5: UNION and UNION ALL")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Combine different queries
        print("\n1. High performers (GPA > 3.7 OR grade > 3.8):")
        cursor.execute("""
            SELECT 'High GPA' AS category, name, gpa AS score
            FROM students
            WHERE gpa > 3.7
            
            UNION
            
            SELECT 'High Course Grade' AS category, s.name, e.grade
            FROM students s
            INNER JOIN enrollments e ON s.id = e.student_id
            WHERE e.grade > 3.8
            
            ORDER BY score DESC
        """)
        
        print(f"   {'Category':20s} | {'Student':20s} | Score")
        print("   " + "-" * 55)
        for category, name, score in cursor.fetchall():
            print(f"   {category:20s} | {name:20s} | {score:.2f}")
        
        # Example 2: UNION vs UNION ALL
        print("\n2. Demonstration of UNION vs UNION ALL:")
        
        # Using UNION (removes duplicates)
        cursor.execute("""
            SELECT name FROM students WHERE gpa > 3.5
            UNION
            SELECT name FROM students WHERE enrollment_year >= 2023
        """)
        union_count = len(cursor.fetchall())
        
        # Using UNION ALL (keeps duplicates)
        cursor.execute("""
            SELECT name FROM students WHERE gpa > 3.5
            UNION ALL
            SELECT name FROM students WHERE enrollment_year >= 2023
        """)
        union_all_count = len(cursor.fetchall())
        
        print(f"   UNION result count:     {union_count} (duplicates removed)")
        print(f"   UNION ALL result count: {union_all_count} (all rows kept)")


def demonstrate_transactions():
    """
    Demonstrates transaction management and ACID properties.
    
    Key Concepts:
    - Transaction: a group of operations that succeed or fail together
    - ACID: Atomicity, Consistency, Isolation, Durability
    - BEGIN TRANSACTION starts a transaction
    - COMMIT saves all changes
    - ROLLBACK undoes all changes
    - Important for data integrity
    """
    print("\n" + "="*60)
    print("PART 6: Transactions and ACID Properties")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Successful transaction
        print("\n1. Successful transaction (COMMIT):")
        
        # Check initial count
        cursor.execute("SELECT COUNT(*) FROM students")
        initial_count = cursor.fetchone()[0]
        print(f"   Initial student count: {initial_count}")
        
        try:
            # Start transaction (implicit in Python's sqlite3)
            cursor.execute("""
                INSERT INTO students (name, email, department_id, enrollment_year, gpa)
                VALUES ('Test Student', 'test@university.edu', 1, 2024, 3.5)
            """)
            
            # Commit the transaction
            conn.commit()
            print("   ✓ Transaction committed successfully")
            
            # Verify
            cursor.execute("SELECT COUNT(*) FROM students")
            new_count = cursor.fetchone()[0]
            print(f"   New student count: {new_count}")
            
        except Exception as e:
            conn.rollback()
            print(f"   ✗ Transaction rolled back: {e}")
        
        # Example 2: Transaction rollback
        print("\n2. Failed transaction (ROLLBACK):")
        
        cursor.execute("SELECT COUNT(*) FROM students")
        before_count = cursor.fetchone()[0]
        print(f"   Student count before: {before_count}")
        
        try:
            # Try to insert invalid data (duplicate email)
            cursor.execute("""
                INSERT INTO students (name, email, department_id, enrollment_year, gpa)
                VALUES ('Another Student', 'test@university.edu', 1, 2024, 3.5)
            """)
            conn.commit()
            
        except sqlite3.IntegrityError as e:
            # Rollback on error
            conn.rollback()
            print(f"   ✗ Transaction rolled back due to error")
            print(f"   Error: {e}")
            
            cursor.execute("SELECT COUNT(*) FROM students")
            after_count = cursor.fetchone()[0]
            print(f"   Student count after: {after_count} (unchanged)")
        
        # Clean up test data
        cursor.execute("DELETE FROM students WHERE email = 'test@university.edu'")
        conn.commit()


def demonstrate_indexes():
    """
    Demonstrates creating and using indexes for performance.
    
    Key Concepts:
    - Indexes speed up data retrieval
    - Trade-off: faster SELECT, slower INSERT/UPDATE/DELETE
    - Create indexes on frequently queried columns
    - Indexes on foreign keys improve join performance
    - Unique indexes enforce uniqueness
    """
    print("\n" + "="*60)
    print("PART 7: Indexes for Performance")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Create indexes
        print("\n1. Creating indexes:")
        
        # Index on student email (for quick lookups)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_student_email 
            ON students(email)
        """)
        print("   ✓ Created index on students.email")
        
        # Index on enrollment student_id (for joins)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_enrollment_student 
            ON enrollments(student_id)
        """)
        print("   ✓ Created index on enrollments.student_id")
        
        # Composite index (multiple columns)
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_enrollment_semester 
            ON enrollments(semester, student_id)
        """)
        print("   ✓ Created composite index on enrollments(semester, student_id)")
        
        # Example 2: Query performance comparison
        print("\n2. Benefits of indexes:")
        print("   - Faster lookups on indexed columns")
        print("   - Improved JOIN performance")
        print("   - Faster sorting on indexed columns")
        print("   - Better WHERE clause performance")
        
        # Example 3: View existing indexes
        print("\n3. Existing indexes:")
        cursor.execute("""
            SELECT name, tbl_name, sql
            FROM sqlite_master
            WHERE type = 'index' AND sql IS NOT NULL
            ORDER BY tbl_name, name
        """)
        
        for name, table, sql in cursor.fetchall():
            print(f"   Index: {name}")
            print(f"   Table: {table}")
            print(f"   SQL:   {sql[:60]}...")
            print()
        
        conn.commit()


def demonstrate_views():
    """
    Demonstrates creating and using views for query simplification.
    
    Key Concepts:
    - View: a saved query that acts like a virtual table
    - Simplifies complex queries
    - Provides data abstraction
    - Can be used in joins like regular tables
    - Updated automatically when underlying data changes
    """
    print("\n" + "="*60)
    print("PART 8: Views for Query Simplification")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Example 1: Create a view
        print("\n1. Creating views:")
        
        # View for student details
        cursor.execute("""
            CREATE VIEW IF NOT EXISTS student_details AS
            SELECT 
                s.id,
                s.name,
                s.email,
                s.gpa,
                d.name AS department,
                d.building,
                s.enrollment_year
            FROM students s
            INNER JOIN departments d ON s.department_id = d.id
        """)
        print("   ✓ Created view: student_details")
        
        # View for course enrollment summary
        cursor.execute("""
            CREATE VIEW IF NOT EXISTS course_summary AS
            SELECT 
                c.code,
                c.name,
                c.credits,
                d.name AS department,
                COUNT(e.id) AS enrolled_students,
                AVG(e.grade) AS avg_grade
            FROM courses c
            INNER JOIN departments d ON c.department_id = d.id
            LEFT JOIN enrollments e ON c.id = e.course_id
            GROUP BY c.id, c.code, c.name, c.credits, d.name
        """)
        print("   ✓ Created view: course_summary")
        
        # Example 2: Query views
        print("\n2. Querying the student_details view:")
        cursor.execute("""
            SELECT name, department, gpa
            FROM student_details
            WHERE gpa > 3.5
            ORDER BY gpa DESC
            LIMIT 5
        """)
        
        print(f"   {'Student':20s} | {'Department':20s} | GPA")
        print("   " + "-" * 55)
        for name, dept, gpa in cursor.fetchall():
            print(f"   {name:20s} | {dept:20s} | {gpa:.2f}")
        
        print("\n3. Querying the course_summary view:")
        cursor.execute("""
            SELECT code, name, enrolled_students, avg_grade
            FROM course_summary
            WHERE enrolled_students > 0
            ORDER BY avg_grade DESC
        """)
        
        print(f"\n   {'Code':8s} | {'Course':30s} | Students | Avg Grade")
        print("   " + "-" * 70)
        for code, name, students, avg_grade in cursor.fetchall():
            avg_display = f"{avg_grade:.2f}" if avg_grade else "N/A"
            print(f"   {code:8s} | {name:30s} | {students:8d} | {avg_display:9s}")
        
        conn.commit()


def demonstrate_practical_queries():
    """
    Demonstrates practical real-world query scenarios.
    """
    print("\n" + "="*60)
    print("PART 9: Practical Query Scenarios")
    print("="*60)
    
    with sqlite3.connect('databases/advanced.db') as conn:
        cursor = conn.cursor()
        
        # Scenario 1: Course catalog with availability
        print("\n1. Course Catalog with Availability:")
        cursor.execute("""
            SELECT 
                c.code,
                c.name,
                c.credits,
                d.name AS department,
                c.max_students,
                COUNT(e.id) AS current_enrollment,
                c.max_students - COUNT(e.id) AS available_seats
            FROM courses c
            INNER JOIN departments d ON c.department_id = d.id
            LEFT JOIN enrollments e ON c.id = e.course_id
            GROUP BY c.id
            HAVING available_seats > 0
            ORDER BY available_seats
        """)
        
        print(f"\n   {'Code':8s} | {'Course':25s} | Dept | Max | Current | Available")
        print("   " + "-" * 80)
        for code, name, credits, dept, max_s, current, available in cursor.fetchall():
            dept_short = dept[:4].upper()
            print(f"   {code:8s} | {name:25s} | {dept_short:4s} | {max_s:3d} | {current:7d} | {available:9d}")
        
        # Scenario 2: Student transcript
        print("\n2. Student Transcript:")
        student_name = 'Alice Johnson'
        cursor.execute("""
            SELECT 
                c.code,
                c.name,
                c.credits,
                e.semester,
                e.grade
            FROM enrollments e
            INNER JOIN students s ON e.student_id = s.id
            INNER JOIN courses c ON e.course_id = c.id
            WHERE s.name = ?
            ORDER BY e.semester, c.code
        """, (student_name,))
        
        print(f"\n   Transcript for: {student_name}")
        print(f"   {'Code':8s} | {'Course':30s} | Credits | {'Semester':12s} | Grade")
        print("   " + "-" * 75)
        
        total_credits = 0
        total_grade_points = 0
        
        for code, name, credits, semester, grade in cursor.fetchall():
            print(f"   {code:8s} | {name:30s} | {credits:7d} | {semester:12s} | {grade:5.2f}")
            total_credits += credits
            total_grade_points += credits * grade
        
        if total_credits > 0:
            gpa = total_grade_points / total_credits
            print("   " + "-" * 75)
            print(f"   Total Credits: {total_credits}")
            print(f"   Cumulative GPA: {gpa:.2f}")


def main():
    """
    Main function to run all demonstrations.
    """
    print("\n")
    print("="*60)
    print("TUTORIAL 03: ADVANCED SQL QUERIES")
    print("="*60)
    
    # Setup
    setup_relational_database()
    
    # Run demonstrations
    demonstrate_inner_join()
    demonstrate_left_join()
    demonstrate_multiple_joins()
    demonstrate_subqueries()
    demonstrate_union()
    demonstrate_transactions()
    demonstrate_indexes()
    demonstrate_views()
    demonstrate_practical_queries()
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print("""
Key Concepts Covered:
1. ✓ Database normalization and relationships
2. ✓ INNER JOIN - matching rows from both tables
3. ✓ LEFT JOIN - all rows from left table
4. ✓ Multiple table joins
5. ✓ Subqueries - nested queries
6. ✓ UNION/UNION ALL - combine query results
7. ✓ Transactions - ACID properties
8. ✓ Indexes - improve query performance
9. ✓ Views - simplify complex queries

Important Concepts:
✓ Foreign keys establish relationships
✓ JOIN types determine which rows are returned
✓ Subqueries enable complex filtering
✓ Transactions ensure data integrity
✓ Indexes trade write speed for read speed
✓ Views provide abstraction and simplification

Next Steps:
- Practice: Try complex joins on your own schema
- Next Tutorial: 04_sqlalchemy_core_basics.py
- Exercise: Complete exercise_03_joins.py
    """)


if __name__ == "__main__":
    main()
