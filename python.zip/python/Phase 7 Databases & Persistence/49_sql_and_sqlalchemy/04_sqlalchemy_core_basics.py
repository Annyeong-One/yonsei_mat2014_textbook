"""
Tutorial 04: SQLAlchemy Core Basics
====================================

Topics Covered:
- Introduction to SQLAlchemy
- Database engines and connections
- Defining tables with MetaData
- Creating tables
- Inserting data with Core
- Selecting data with Core
- Basic query building

Learning Objectives:
- Understand SQLAlchemy's architecture (Core vs ORM)
- Create database engines and manage connections
- Define table schemas programmatically
- Perform CRUD operations using Core API
- Build queries with the expression language

Difficulty: Intermediate
Estimated Time: 60-75 minutes

Prerequisites:
- Understanding of SQL (tutorials 01-03)
- Familiarity with Python classes and objects
"""

from sqlalchemy import (
    create_engine,      # Creates database connection engine
    MetaData,          # Container for database metadata
    Table,             # Represents a database table
    Column,            # Represents a table column
    Integer,           # Integer data type
    String,            # String data type
    Float,             # Floating point data type
    Date,              # Date data type
    ForeignKey,        # Foreign key constraint
    select,            # SELECT query builder
    insert,            # INSERT query builder
    update,            # UPDATE query builder
    delete             # DELETE query builder
)
from datetime import date
import os


def introduction_to_sqlalchemy():
    """
    Explains SQLAlchemy's architecture and benefits.
    
    Key Concepts:
    - SQLAlchemy has two main APIs: Core and ORM
    - Core: Lower-level, SQL-focused, explicit
    - ORM: Higher-level, object-focused, Pythonic
    - Core is foundation for ORM
    - Use Core for SQL-like operations, ORM for object mapping
    """
    print("\n" + "="*60)
    print("PART 1: Introduction to SQLAlchemy")
    print("="*60)
    
    print("""
SQLAlchemy is a SQL toolkit and Object-Relational Mapping (ORM) library.

Two Main Components:
┌─────────────────────────────────────────────────────────┐
│                    SQLAlchemy ORM                       │
│                 (Object-Relational Mapping)             │
│                   - High-level API                      │
│                   - Work with Python objects            │
│                   - Automatic SQL generation            │
├─────────────────────────────────────────────────────────┤
│                   SQLAlchemy Core                       │
│                  (This tutorial)                        │
│                   - SQL Expression Language             │
│                   - Direct SQL construction             │
│                   - Database abstraction                │
├─────────────────────────────────────────────────────────┤
│                   Database Drivers                      │
│              (sqlite3, psycopg2, pymysql, etc.)        │
└─────────────────────────────────────────────────────────┘

Benefits of SQLAlchemy Core:
✓ Database-agnostic: Write once, run on any database
✓ Pythonic: Build queries with Python expressions
✓ Type-safe: Column types are enforced
✓ SQL injection protection: Automatic parameter binding
✓ Connection pooling: Efficient resource management

When to use Core vs ORM:
- Use Core: When you need SQL-like control and performance
- Use ORM: When working with complex object relationships
- Can mix both in the same application!

This tutorial covers Core. ORM is covered in tutorials 07-12.
    """)


def demonstrate_engine_creation():
    """
    Demonstrates creating database engines.
    
    Key Concepts:
    - Engine manages database connections
    - Connection string format: dialect+driver://connection_params
    - SQLite: sqlite:///path/to/database.db
    - PostgreSQL: postgresql://user:pass@host/database
    - MySQL: mysql+pymysql://user:pass@host/database
    - Engine should be created once and reused
    """
    print("\n" + "="*60)
    print("PART 2: Creating Database Engines")
    print("="*60)
    
    # Ensure databases directory exists
    if not os.path.exists('databases'):
        os.makedirs('databases')
    
    # Create a SQLite engine
    # The /// means relative path (four slashes for absolute: ////)
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    
    # echo=True would print all SQL statements (useful for learning)
    # echo=False is better for production
    
    print("\n✓ Created SQLite engine")
    print(f"  URL: {engine.url}")
    print(f"  Dialect: {engine.dialect.name}")
    print(f"  Driver: {engine.driver}")
    
    # Engine doesn't connect immediately (lazy connection)
    print("\n📝 Note: Engine doesn't connect until needed (lazy connection)")
    
    # Test connection
    with engine.connect() as connection:
        print("✓ Successfully connected to database")
        # Connection automatically closed when leaving 'with' block
    
    print("✓ Connection closed")
    
    # Connection string examples (for reference)
    print("\n📚 Connection String Examples:")
    print("  SQLite:     sqlite:///path/to/database.db")
    print("  PostgreSQL: postgresql://user:password@localhost/dbname")
    print("  MySQL:      mysql+pymysql://user:password@localhost/dbname")
    
    return engine


def demonstrate_metadata_and_tables():
    """
    Demonstrates defining table schemas with MetaData.
    
    Key Concepts:
    - MetaData: Container for table definitions
    - Table: Represents a database table
    - Column: Defines a table column with type and constraints
    - Data types: Integer, String, Float, Date, etc.
    - Constraints: primary_key, nullable, unique, default
    """
    print("\n" + "="*60)
    print("PART 3: Defining Tables with MetaData")
    print("="*60)
    
    # Create engine
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    
    # MetaData holds table definitions
    # Think of it as a "catalog" of your database schema
    metadata = MetaData()
    
    print("\n✓ Created MetaData object")
    
    # Define a users table
    users = Table(
        'users',              # Table name
        metadata,             # MetaData object
        Column('id', Integer, primary_key=True, autoincrement=True),
        Column('username', String(50), nullable=False, unique=True),
        Column('email', String(100), nullable=False),
        Column('age', Integer),
        Column('salary', Float)
    )
    
    print("✓ Defined 'users' table")
    print(f"  Table name: {users.name}")
    print(f"  Columns: {[col.name for col in users.columns]}")
    
    # Define a posts table with foreign key
    posts = Table(
        'posts',
        metadata,
        Column('id', Integer, primary_key=True, autoincrement=True),
        Column('user_id', Integer, ForeignKey('users.id'), nullable=False),
        Column('title', String(200), nullable=False),
        Column('content', String(1000)),
        Column('created_date', Date, default=date.today)
    )
    
    print("✓ Defined 'posts' table with foreign key to users")
    
    # Create all tables in the database
    # This executes CREATE TABLE statements
    metadata.create_all(engine)
    print("\n✓ Created all tables in database")
    
    print("\n📝 Table Schema Details:")
    print("\nusers table:")
    for column in users.columns:
        pk = " (PRIMARY KEY)" if column.primary_key else ""
        nullable = " (NULLABLE)" if column.nullable else " (NOT NULL)"
        print(f"  - {column.name}: {column.type}{pk}{nullable}")
    
    print("\nposts table:")
    for column in posts.columns:
        pk = " (PRIMARY KEY)" if column.primary_key else ""
        fk = f" (FK -> {list(column.foreign_keys)[0].target_fullname})" if column.foreign_keys else ""
        nullable = " (NULLABLE)" if column.nullable else " (NOT NULL)"
        print(f"  - {column.name}: {column.type}{pk}{fk}{nullable}")
    
    return engine, metadata, users, posts


def demonstrate_insert_operations():
    """
    Demonstrates inserting data using SQLAlchemy Core.
    
    Key Concepts:
    - insert() creates an INSERT statement
    - values() specifies data to insert
    - execute() runs the statement
    - Can insert single or multiple rows
    - Returns a Result object
    """
    print("\n" + "="*60)
    print("PART 4: Inserting Data")
    print("="*60)
    
    # Setup
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    metadata = MetaData()
    
    # Reflect existing tables (load from database)
    users = Table('users', metadata, autoload_with=engine)
    posts = Table('posts', metadata, autoload_with=engine)
    
    # Method 1: Insert single row
    print("\n1. Inserting a single user:")
    
    # Build INSERT statement
    stmt = insert(users).values(
        username='john_doe',
        email='john@example.com',
        age=30,
        salary=75000.0
    )
    
    # Execute the statement
    with engine.connect() as conn:
        result = conn.execute(stmt)
        # Commit to save changes
        conn.commit()
        # Get the auto-generated ID
        user_id = result.inserted_primary_key[0]
        print(f"   ✓ Inserted user with ID: {user_id}")
    
    # Method 2: Insert with dictionary
    print("\n2. Inserting using dictionary:")
    
    user_data = {
        'username': 'jane_smith',
        'email': 'jane@example.com',
        'age': 28,
        'salary': 82000.0
    }
    
    stmt = insert(users).values(**user_data)
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        conn.commit()
        user_id = result.inserted_primary_key[0]
        print(f"   ✓ Inserted user: {user_data['username']} (ID: {user_id})")
    
    # Method 3: Insert multiple rows (bulk insert)
    print("\n3. Bulk inserting multiple users:")
    
    user_list = [
        {'username': 'bob_wilson', 'email': 'bob@example.com', 'age': 35, 'salary': 90000.0},
        {'username': 'alice_brown', 'email': 'alice@example.com', 'age': 26, 'salary': 68000.0},
        {'username': 'charlie_davis', 'email': 'charlie@example.com', 'age': 32, 'salary': 78000.0}
    ]
    
    with engine.connect() as conn:
        # Execute with multiple parameter sets
        result = conn.execute(insert(users), user_list)
        conn.commit()
        print(f"   ✓ Inserted {result.rowcount} users")
    
    # Method 4: Insert posts (with foreign keys)
    print("\n4. Inserting posts with foreign keys:")
    
    post_data = [
        {'user_id': 1, 'title': 'First Post', 'content': 'Hello World!', 'created_date': date(2024, 1, 15)},
        {'user_id': 1, 'title': 'Python Tips', 'content': 'Use list comprehensions!', 'created_date': date(2024, 1, 20)},
        {'user_id': 2, 'title': 'SQLAlchemy Basics', 'content': 'Core vs ORM explained', 'created_date': date(2024, 2, 1)}
    ]
    
    with engine.connect() as conn:
        conn.execute(insert(posts), post_data)
        conn.commit()
        print(f"   ✓ Inserted {len(post_data)} posts")


def demonstrate_select_operations():
    """
    Demonstrates querying data using SQLAlchemy Core.
    
    Key Concepts:
    - select() creates a SELECT statement
    - Can select specific columns or entire table
    - where() adds filtering conditions
    - order_by() sorts results
    - limit() restricts number of rows
    - fetchall() returns all rows, fetchone() returns one
    """
    print("\n" + "="*60)
    print("PART 5: Selecting Data")
    print("="*60)
    
    # Setup
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    metadata = MetaData()
    users = Table('users', metadata, autoload_with=engine)
    posts = Table('posts', metadata, autoload_with=engine)
    
    # Method 1: Select all columns
    print("\n1. Select all users:")
    
    stmt = select(users)
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        
        print(f"   {'ID':3s} | {'Username':15s} | {'Email':25s} | Age | Salary")
        print("   " + "-" * 75)
        
        for row in result:
            # Access columns by name or position
            print(f"   {row.id:3d} | {row.username:15s} | {row.email:25s} | {row.age:3d} | ${row.salary:,.2f}")
    
    # Method 2: Select specific columns
    print("\n2. Select specific columns:")
    
    stmt = select(users.c.username, users.c.email)
    # Note: users.c is shorthand for users.columns
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        
        print(f"   {'Username':15s} | {'Email':25s}")
        print("   " + "-" * 45)
        
        for row in result:
            print(f"   {row.username:15s} | {row.email:25s}")
    
    # Method 3: Select with WHERE clause
    print("\n3. Select users older than 30:")
    
    stmt = select(users).where(users.c.age > 30)
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.age} years old")
    
    # Method 4: Select with multiple conditions
    print("\n4. Select users with age > 25 AND salary > 70000:")
    
    stmt = select(users).where(
        (users.c.age > 25) & (users.c.salary > 70000)
    )
    # Note: Use & for AND, | for OR, ~ for NOT
    # Parentheses are required!
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.age} years, ${row.salary:,.2f}")
    
    # Method 5: Order by
    print("\n5. Users ordered by salary (descending):")
    
    stmt = select(users).order_by(users.c.salary.desc())
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        
        for i, row in enumerate(result, 1):
            print(f"   {i}. {row.username:15s} - ${row.salary:,.2f}")
    
    # Method 6: Limit results
    print("\n6. Top 3 youngest users:")
    
    stmt = select(users).order_by(users.c.age).limit(3)
    
    with engine.connect() as conn:
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.age} years")


def demonstrate_query_building():
    """
    Demonstrates building complex queries with Core.
    
    Key Concepts:
    - Query objects are composable (can chain methods)
    - Expressions for complex conditions
    - Aggregate functions
    - Column operators: ==, !=, <, >, <=, >=, in_, like, etc.
    """
    print("\n" + "="*60)
    print("PART 6: Building Complex Queries")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    metadata = MetaData()
    users = Table('users', metadata, autoload_with=engine)
    
    with engine.connect() as conn:
        # Example 1: IN clause
        print("\n1. Users with specific usernames:")
        
        stmt = select(users).where(users.c.username.in_(['john_doe', 'jane_smith']))
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.email}")
        
        # Example 2: LIKE pattern matching
        print("\n2. Users whose username contains 'doe':")
        
        stmt = select(users).where(users.c.username.like('%doe%'))
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}")
        
        # Example 3: BETWEEN
        print("\n3. Users aged between 25 and 30:")
        
        stmt = select(users).where(users.c.age.between(25, 30))
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.age} years")
        
        # Example 4: OR conditions
        print("\n4. Users aged < 27 OR salary > 85000:")
        
        stmt = select(users).where(
            (users.c.age < 27) | (users.c.salary > 85000)
        )
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.age} years, ${row.salary:,.2f}")
        
        # Example 5: NOT condition
        print("\n5. Users NOT named 'john_doe':")
        
        stmt = select(users).where(~(users.c.username == 'john_doe'))
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}")


def demonstrate_joins():
    """
    Demonstrates joining tables in Core.
    
    Key Concepts:
    - join() performs INNER JOIN by default
    - outerjoin() performs LEFT OUTER JOIN
    - Join condition usually on foreign keys
    - Can access columns from joined tables
    """
    print("\n" + "="*60)
    print("PART 7: Joins in SQLAlchemy Core")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    metadata = MetaData()
    users = Table('users', metadata, autoload_with=engine)
    posts = Table('posts', metadata, autoload_with=engine)
    
    with engine.connect() as conn:
        # Example 1: Simple join
        print("\n1. Posts with user information:")
        
        # Method 1: Explicit join condition
        stmt = select(
            users.c.username,
            posts.c.title,
            posts.c.created_date
        ).select_from(
            users.join(posts, users.c.id == posts.c.user_id)
        )
        
        result = conn.execute(stmt)
        
        print(f"   {'Username':15s} | {'Title':25s} | Date")
        print("   " + "-" * 60)
        
        for row in result:
            print(f"   {row.username:15s} | {row.title:25s} | {row.created_date}")
        
        # Example 2: Join with automatic FK detection
        print("\n2. Posts per user (using automatic FK):")
        
        # SQLAlchemy can detect the foreign key relationship
        stmt = select(
            users.c.username,
            posts.c.title
        ).select_from(
            users.join(posts)  # Automatic FK detection
        )
        
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username}: {row.title}")


def demonstrate_aggregate_functions():
    """
    Demonstrates aggregate functions in Core.
    
    Key Concepts:
    - func provides SQL functions (count, sum, avg, min, max)
    - group_by() groups results
    - having() filters grouped results
    - label() provides column aliases
    """
    print("\n" + "="*60)
    print("PART 8: Aggregate Functions")
    print("="*60)
    
    from sqlalchemy import func
    
    engine = create_engine('sqlite:///databases/core_basics.db', echo=False)
    metadata = MetaData()
    users = Table('users', metadata, autoload_with=engine)
    posts = Table('posts', metadata, autoload_with=engine)
    
    with engine.connect() as conn:
        # Example 1: COUNT
        print("\n1. Total number of users:")
        
        stmt = select(func.count(users.c.id).label('user_count'))
        result = conn.execute(stmt)
        count = result.scalar()  # Get single value
        
        print(f"   Total users: {count}")
        
        # Example 2: AVG, MIN, MAX
        print("\n2. Salary statistics:")
        
        stmt = select(
            func.avg(users.c.salary).label('avg_salary'),
            func.min(users.c.salary).label('min_salary'),
            func.max(users.c.salary).label('max_salary')
        )
        result = conn.execute(stmt)
        row = result.fetchone()
        
        print(f"   Average: ${row.avg_salary:,.2f}")
        print(f"   Minimum: ${row.min_salary:,.2f}")
        print(f"   Maximum: ${row.max_salary:,.2f}")
        
        # Example 3: GROUP BY
        print("\n3. Posts per user:")
        
        stmt = select(
            users.c.username,
            func.count(posts.c.id).label('post_count')
        ).select_from(
            users.join(posts, isouter=True)  # LEFT JOIN to include users with no posts
        ).group_by(users.c.username)
        
        result = conn.execute(stmt)
        
        for row in result:
            print(f"   {row.username:15s}: {row.post_count} post(s)")


def main():
    """
    Main function to run all demonstrations.
    """
    print("\n")
    print("="*60)
    print("TUTORIAL 04: SQLALCHEMY CORE BASICS")
    print("="*60)
    
    # Part 1: Introduction
    introduction_to_sqlalchemy()
    
    # Part 2: Engine creation
    demonstrate_engine_creation()
    
    # Part 3: Defining tables
    demonstrate_metadata_and_tables()
    
    # Part 4: Insert operations
    demonstrate_insert_operations()
    
    # Part 5: Select operations
    demonstrate_select_operations()
    
    # Part 6: Query building
    demonstrate_query_building()
    
    # Part 7: Joins
    demonstrate_joins()
    
    # Part 8: Aggregate functions
    demonstrate_aggregate_functions()
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print("""
Key Concepts Covered:
1. ✓ SQLAlchemy architecture (Core vs ORM)
2. ✓ Creating database engines
3. ✓ Defining tables with MetaData
4. ✓ Insert operations with insert()
5. ✓ Select operations with select()
6. ✓ Building complex queries
7. ✓ Joins (inner and outer)
8. ✓ Aggregate functions with func

Important Notes:
✓ Core provides SQL abstraction while remaining SQL-like
✓ Queries are built with Python expressions
✓ Automatic parameter binding prevents SQL injection
✓ Connection pooling is automatic
✓ Works with multiple database backends

Core vs Raw SQL:
- Core: Pythonic, portable, type-safe
- Raw SQL: Database-specific, less portable
- Both have their place in applications

Next Steps:
- Practice: Build queries for your own schemas
- Next Tutorial: 05_sqlalchemy_core_intermediate.py
- Exercise: Complete exercise_04_core_basics.py
    """)


if __name__ == "__main__":
    main()
