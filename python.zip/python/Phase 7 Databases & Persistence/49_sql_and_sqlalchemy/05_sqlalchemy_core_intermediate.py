"""
Tutorial 05: SQLAlchemy Core Intermediate
==========================================

Topics Covered:
- UPDATE and DELETE with Core
- Complex WHERE clauses and expressions
- Text SQL and hybrid approaches
- Connection and transaction management
- Result processing and row proxies
- Executing multiple statements

Learning Objectives:
- Modify and delete data with Core
- Build complex conditional expressions
- Mix SQL text with Core expressions
- Manage transactions explicitly
- Process query results efficiently

Difficulty: Intermediate
Estimated Time: 60-75 minutes
"""

from sqlalchemy import (
    create_engine, MetaData, Table, Column, Integer, String, Float,
    select, insert, update, delete, and_, or_, not_, text, bindparam
)
import os


def setup_database():
    """Setup database with sample data."""
    print("\n" + "="*60)
    print("SETUP: Creating Sample Database")
    print("="*60)
    
    if not os.path.exists('databases'):
        os.makedirs('databases')
    
    engine = create_engine('sqlite:///databases/core_intermediate.db', echo=False)
    metadata = MetaData()
    
    # Drop and recreate table
    products = Table(
        'products', metadata,
        Column('id', Integer, primary_key=True, autoincrement=True),
        Column('name', String(100), nullable=False),
        Column('category', String(50)),
        Column('price', Float),
        Column('stock', Integer, default=0)
    )
    
    metadata.drop_all(engine)
    metadata.create_all(engine)
    
    # Insert sample data
    sample_products = [
        {'name': 'Laptop', 'category': 'Electronics', 'price': 999.99, 'stock': 15},
        {'name': 'Mouse', 'category': 'Electronics', 'price': 25.99, 'stock': 50},
        {'name': 'Keyboard', 'category': 'Electronics', 'price': 79.99, 'stock': 30},
        {'name': 'Monitor', 'category': 'Electronics', 'price': 299.99, 'stock': 20},
        {'name': 'Desk', 'category': 'Furniture', 'price': 199.99, 'stock': 10},
        {'name': 'Chair', 'category': 'Furniture', 'price': 149.99, 'stock': 25},
        {'name': 'Notebook', 'category': 'Stationery', 'price': 5.99, 'stock': 100},
        {'name': 'Pen', 'category': 'Stationery', 'price': 1.99, 'stock': 200}
    ]
    
    with engine.connect() as conn:
        conn.execute(insert(products), sample_products)
        conn.commit()
    
    print(f"✓ Created database with {len(sample_products)} products")
    return engine, metadata, products


def demonstrate_update_operations():
    """
    Demonstrates UPDATE operations with Core.
    
    Key Concepts:
    - update() creates UPDATE statements
    - values() specifies new values
    - where() specifies which rows to update
    - Can update single or multiple columns
    - Returns number of affected rows
    """
    print("\n" + "="*60)
    print("PART 1: UPDATE Operations")
    print("="*60)
    
    engine, metadata, products = setup_database()
    
    with engine.connect() as conn:
        # Example 1: Update single column
        print("\n1. Increasing laptop price by 10%:")
        
        # First, show current price
        stmt = select(products).where(products.c.name == 'Laptop')
        result = conn.execute(stmt).fetchone()
        print(f"   Before: ${result.price:.2f}")
        
        # Update price
        stmt = (
            update(products)
            .where(products.c.name == 'Laptop')
            .values(price=products.c.price * 1.1)
        )
        result = conn.execute(stmt)
        conn.commit()
        
        # Show new price
        stmt = select(products).where(products.c.name == 'Laptop')
        result = conn.execute(stmt).fetchone()
        print(f"   After:  ${result.price:.2f}")
        
        # Example 2: Update multiple columns
        print("\n2. Updating mouse - both price and stock:")
        
        stmt = (
            update(products)
            .where(products.c.name == 'Mouse')
            .values(price=29.99, stock=45)
        )
        result = conn.execute(stmt)
        conn.commit()
        print(f"   ✓ Updated {result.rowcount} row(s)")
        
        # Example 3: Conditional update
        print("\n3. Discount all Electronics items over $100:")
        
        stmt = (
            update(products)
            .where(
                and_(
                    products.c.category == 'Electronics',
                    products.c.price > 100
                )
            )
            .values(price=products.c.price * 0.9)
        )
        result = conn.execute(stmt)
        conn.commit()
        print(f"   ✓ Applied discount to {result.rowcount} product(s)")


def demonstrate_delete_operations():
    """
    Demonstrates DELETE operations with Core.
    
    Key Concepts:
    - delete() creates DELETE statements
    - where() specifies which rows to delete
    - Use with caution - no undo!
    - Returns number of deleted rows
    """
    print("\n" + "="*60)
    print("PART 2: DELETE Operations")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_intermediate.db', echo=False)
    metadata = MetaData()
    products = Table('products', metadata, autoload_with=engine)
    
    with engine.connect() as conn:
        # Count before deletion
        count_stmt = select(products)
        before_count = len(conn.execute(count_stmt).fetchall())
        print(f"\nProducts before deletion: {before_count}")
        
        # Example 1: Delete specific product
        print("\n1. Deleting 'Pen' from inventory:")
        
        stmt = delete(products).where(products.c.name == 'Pen')
        result = conn.execute(stmt)
        conn.commit()
        print(f"   ✓ Deleted {result.rowcount} product(s)")
        
        # Example 2: Delete with conditions
        print("\n2. Deleting out-of-stock items:")
        
        stmt = delete(products).where(products.c.stock == 0)
        result = conn.execute(stmt)
        conn.commit()
        print(f"   ✓ Deleted {result.rowcount} product(s)")
        
        # Count after deletion
        after_count = len(conn.execute(count_stmt).fetchall())
        print(f"\nProducts after deletion: {after_count}")


def demonstrate_complex_expressions():
    """
    Demonstrates complex WHERE clause expressions.
    
    Key Concepts:
    - and_() for multiple AND conditions
    - or_() for OR conditions
    - not_() for negation
    - Comparison operators: ==, !=, <, >, <=, >=
    - in_(), like(), between() for special conditions
    """
    print("\n" + "="*60)
    print("PART 3: Complex WHERE Expressions")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_intermediate.db', echo=False)
    metadata = MetaData()
    products = Table('products', metadata, autoload_with=engine)
    
    with engine.connect() as conn:
        # Example 1: AND conditions
        print("\n1. Electronics products under $100:")
        
        stmt = select(products).where(
            and_(
                products.c.category == 'Electronics',
                products.c.price < 100
            )
        )
        
        for row in conn.execute(stmt):
            print(f"   {row.name:15s} - ${row.price:.2f}")
        
        # Example 2: OR conditions
        print("\n2. Products that are Electronics OR under $10:")
        
        stmt = select(products).where(
            or_(
                products.c.category == 'Electronics',
                products.c.price < 10
            )
        ).order_by(products.c.price)
        
        for row in conn.execute(stmt):
            print(f"   {row.name:15s} - {row.category:12s} - ${row.price:.2f}")
        
        # Example 3: NOT condition
        print("\n3. Non-Electronics products:")
        
        stmt = select(products).where(
            not_(products.c.category == 'Electronics')
        )
        
        for row in conn.execute(stmt):
            print(f"   {row.name:15s} - {row.category}")
        
        # Example 4: Complex nested conditions
        print("\n4. Complex query: (Electronics under $50) OR (Furniture over $150):")
        
        stmt = select(products).where(
            or_(
                and_(
                    products.c.category == 'Electronics',
                    products.c.price < 50
                ),
                and_(
                    products.c.category == 'Furniture',
                    products.c.price > 150
                )
            )
        )
        
        for row in conn.execute(stmt):
            print(f"   {row.name:15s} - {row.category:12s} - ${row.price:.2f}")


def demonstrate_text_sql():
    """
    Demonstrates using text SQL with Core.
    
    Key Concepts:
    - text() allows raw SQL strings
    - Useful for database-specific features
    - Can mix with Core constructs
    - Use bindparam() for parameters
    - Maintains security with proper binding
    """
    print("\n" + "="*60)
    print("PART 4: Text SQL and Hybrid Approaches")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_intermediate.db', echo=False)
    
    with engine.connect() as conn:
        # Example 1: Pure text SQL
        print("\n1. Using text SQL:")
        
        stmt = text("SELECT name, price FROM products WHERE category = :cat")
        result = conn.execute(stmt, {'cat': 'Electronics'})
        
        print("   Electronics products:")
        for row in result:
            print(f"   {row.name:15s} - ${row.price:.2f}")
        
        # Example 2: Text with multiple parameters
        print("\n2. Text SQL with multiple parameters:")
        
        stmt = text("""
            SELECT name, category, price, stock
            FROM products
            WHERE price BETWEEN :min_price AND :max_price
            ORDER BY price
        """)
        
        result = conn.execute(stmt, {'min_price': 50, 'max_price': 200})
        
        print(f"   {'Name':15s} | {'Category':12s} | {'Price':8s} | Stock")
        print("   " + "-" * 50)
        for row in result:
            print(f"   {row.name:15s} | {row.category:12s} | ${row.price:6.2f} | {row.stock:3d}")


def demonstrate_transactions():
    """
    Demonstrates explicit transaction management.
    
    Key Concepts:
    - Transactions group operations
    - begin() starts explicit transaction
    - commit() saves changes
    - rollback() undoes changes
    - Context managers handle cleanup
    """
    print("\n" + "="*60)
    print("PART 5: Transaction Management")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_intermediate.db', echo=False)
    metadata = MetaData()
    products = Table('products', metadata, autoload_with=engine)
    
    # Example 1: Successful transaction
    print("\n1. Successful transaction:")
    
    with engine.connect() as conn:
        # Start transaction
        trans = conn.begin()
        
        try:
            # Multiple operations
            conn.execute(
                update(products)
                .where(products.c.name == 'Laptop')
                .values(stock=products.c.stock - 1)
            )
            
            conn.execute(
                update(products)
                .where(products.c.name == 'Mouse')
                .values(stock=products.c.stock - 2)
            )
            
            # Commit if all operations succeed
            trans.commit()
            print("   ✓ Transaction committed successfully")
            
        except Exception as e:
            # Rollback on error
            trans.rollback()
            print(f"   ✗ Transaction rolled back: {e}")
    
    # Example 2: Transaction rollback on error
    print("\n2. Transaction rollback demo:")
    
    with engine.connect() as conn:
        # Get current stock
        stmt = select(products.c.stock).where(products.c.name == 'Chair')
        stock_before = conn.execute(stmt).scalar()
        print(f"   Chair stock before: {stock_before}")
        
        trans = conn.begin()
        
        try:
            # Valid operation
            conn.execute(
                update(products)
                .where(products.c.name == 'Chair')
                .values(stock=stock_before - 5)
            )
            
            # Simulate error
            raise ValueError("Simulated error for demonstration")
            
            trans.commit()
            
        except Exception as e:
            trans.rollback()
            print(f"   ✗ Transaction rolled back: {e}")
        
        # Verify rollback
        stock_after = conn.execute(stmt).scalar()
        print(f"   Chair stock after:  {stock_after} (unchanged)")


def demonstrate_result_processing():
    """
    Demonstrates different ways to process query results.
    
    Key Concepts:
    - fetchall() returns all rows as list
    - fetchone() returns one row
    - fetchmany(n) returns n rows
    - scalar() returns single value
    - Rows are dict-like and tuple-like
    - Can iterate directly over result
    """
    print("\n" + "="*60)
    print("PART 6: Result Processing")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/core_intermediate.db', echo=False)
    metadata = MetaData()
    products = Table('products', metadata, autoload_with=engine)
    
    with engine.connect() as conn:
        # Example 1: fetchall()
        print("\n1. Using fetchall():")
        
        stmt = select(products).limit(3)
        result = conn.execute(stmt)
        rows = result.fetchall()  # Returns list
        
        print(f"   Fetched {len(rows)} rows")
        for row in rows:
            print(f"   {row.name}")
        
        # Example 2: fetchone()
        print("\n2. Using fetchone():")
        
        result = conn.execute(stmt)
        row = result.fetchone()  # Returns single row
        
        if row:
            print(f"   First row: {row.name}")
        
        # Example 3: scalar()
        print("\n3. Using scalar() for single value:")
        
        from sqlalchemy import func
        stmt = select(func.count(products.c.id))
        count = conn.execute(stmt).scalar()
        
        print(f"   Total products: {count}")
        
        # Example 4: Iterating over result
        print("\n4. Direct iteration:")
        
        stmt = select(products.c.name, products.c.price).order_by(products.c.price).limit(3)
        result = conn.execute(stmt)
        
        print("   Cheapest products:")
        for row in result:  # Iterate directly
            print(f"   {row.name:15s} - ${row.price:.2f}")
        
        # Example 5: Accessing columns different ways
        print("\n5. Different ways to access column values:")
        
        stmt = select(products).where(products.c.name == 'Laptop')
        row = conn.execute(stmt).fetchone()
        
        print("   Tuple-style:  ", row[0], row[1])  # By index
        print("   Dict-style:   ", row['id'], row['name'])  # By name
        print("   Attribute:    ", row.id, row.name)  # As attributes
        print("   _mapping:     ", dict(row._mapping))  # As dictionary


def main():
    """Main function to run all demonstrations."""
    print("\n")
    print("="*60)
    print("TUTORIAL 05: SQLALCHEMY CORE INTERMEDIATE")
    print("="*60)
    
    # Setup
    engine, metadata, products = setup_database()
    
    # Demonstrations
    demonstrate_update_operations()
    demonstrate_delete_operations()
    demonstrate_complex_expressions()
    demonstrate_text_sql()
    demonstrate_transactions()
    demonstrate_result_processing()
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print("""
Key Concepts Covered:
1. ✓ UPDATE operations with conditions
2. ✓ DELETE operations safely
3. ✓ Complex WHERE expressions (and_, or_, not_)
4. ✓ Text SQL for database-specific features
5. ✓ Explicit transaction management
6. ✓ Result processing methods

Best Practices:
✓ Always use WHERE clause with UPDATE/DELETE
✓ Use transactions for multiple related operations
✓ Prefer Core expressions over text SQL when possible
✓ Handle exceptions properly in transactions
✓ Use appropriate result fetching method for use case

Next Steps:
- Practice: Implement CRUD operations for your schema
- Next Tutorial: 06_core_advanced.py
- Exercise: Complete exercise_05_core_operations.py
    """)


if __name__ == "__main__":
    main()
