# Tutorial 06: Advanced Core Features
# Topics: Subqueries, CTEs, Window functions, Advanced joins
