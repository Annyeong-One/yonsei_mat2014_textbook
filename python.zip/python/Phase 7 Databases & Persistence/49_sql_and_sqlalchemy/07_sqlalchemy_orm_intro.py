"""
Tutorial 07: SQLAlchemy ORM Introduction
========================================

Topics Covered:
- Introduction to Object-Relational Mapping (ORM)
- Declarative Base and model classes
- Defining ORM models
- Creating and dropping tables
- Session basics
- Creating, reading, updating, deleting objects (CRUD)
- Basic querying

Learning Objectives:
- Understand ORM concepts and benefits
- Define Python classes as database tables
- Use sessions to interact with database
- Perform CRUD operations with ORM
- Query objects using ORM syntax

Difficulty: Intermediate
Estimated Time: 75-90 minutes

Prerequisites:
- SQL fundamentals (tutorials 01-03)
- SQLAlchemy Core basics (tutorial 04)
- Python classes and OOP
"""

from sqlalchemy import create_engine, Column, Integer, String, Float, Date, ForeignKey
from sqlalchemy.orm import declarative_base, Session, relationship
from datetime import date
import os


# Create the Declarative Base
# This is the base class for all ORM models
Base = declarative_base()


def introduction_to_orm():
    """
    Explains ORM concepts and SQLAlchemy's approach.
    
    Key Concepts:
    - ORM maps Python classes to database tables
    - Class attributes become table columns
    - Class instances represent table rows
    - Provides Pythonic interface to database
    - Abstracts away SQL details
    """
    print("\n" + "="*60)
    print("PART 1: Introduction to ORM")
    print("="*60)
    
    print("""
Object-Relational Mapping (ORM) Concept:
┌─────────────────────┐         ┌─────────────────────┐
│   Python Classes    │  <--->  │  Database Tables    │
├─────────────────────┤         ├─────────────────────┤
│ Class attributes    │  <--->  │  Table columns      │
│ Class instances     │  <--->  │  Table rows         │
│ Methods             │         │  SQL operations     │
└─────────────────────┘         └─────────────────────┘

Core vs ORM:

Core:
  stmt = select(users).where(users.c.age > 25)
  result = connection.execute(stmt)

ORM:
  users = session.query(User).filter(User.age > 25).all()

Benefits of ORM:
✓ More Pythonic - work with objects instead of SQL
✓ Type safety - Python type hints and IDE support
✓ Relationship management - automatic joins and eager loading
✓ Less boilerplate - no manual SQL for simple operations
✓ Maintainability - database changes easier to manage

When to use ORM:
✓ Complex object relationships
✓ Domain-driven design
✓ Rapid development
✓ Object-oriented applications

When to use Core:
✓ Complex queries requiring fine control
✓ Bulk operations needing maximum performance
✓ SQL-centric applications
✓ Reporting and analytics
    """)


# Define ORM Models
class User(Base):
    """
    User model representing the users table.
    
    Key Concepts:
    - Inherits from Base (declarative_base)
    - __tablename__ specifies table name
    - Column() defines table columns
    - Column types map to SQL types
    - primary_key=True sets primary key
    """
    # Table name in database
    __tablename__ = 'users'
    
    # Define columns
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False)
    email = Column(String(100), nullable=False)
    age = Column(Integer)
    salary = Column(Float)
    
    # Relationship to posts (one-to-many)
    # 'posts' will be a list of Post objects
    # back_populates creates two-way relationship
    posts = relationship('Post', back_populates='user', cascade='all, delete-orphan')
    
    def __repr__(self):
        """
        String representation of User object.
        Useful for debugging and printing.
        """
        return f"<User(id={self.id}, username='{self.username}')>"
    
    def __str__(self):
        """Human-readable string representation."""
        return f"{self.username} ({self.email})"


class Post(Base):
    """
    Post model representing the posts table.
    
    Key Concepts:
    - ForeignKey establishes relationship
    - relationship() provides object access
    - back_populates links bidirectional relationship
    """
    __tablename__ = 'posts'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    title = Column(String(200), nullable=False)
    content = Column(String(1000))
    created_date = Column(Date, default=date.today)
    
    # Relationship back to user
    user = relationship('User', back_populates='posts')
    
    def __repr__(self):
        return f"<Post(id={self.id}, title='{self.title[:30]}...')>"
    
    def __str__(self):
        return f"{self.title} by {self.user.username if self.user else 'Unknown'}"


def demonstrate_engine_and_tables():
    """
    Demonstrates creating engine and tables with ORM.
    
    Key Concepts:
    - Same engine creation as Core
    - Base.metadata.create_all() creates all tables
    - Models must be imported before create_all()
    - Creates tables only if they don't exist
    """
    print("\n" + "="*60)
    print("PART 2: Engine and Table Creation")
    print("="*60)
    
    # Ensure databases directory exists
    if not os.path.exists('databases'):
        os.makedirs('databases')
    
    # Create engine
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    print("✓ Created database engine")
    
    # Create all tables defined by models
    # This executes CREATE TABLE statements for User and Post
    Base.metadata.create_all(engine)
    print("✓ Created all tables from models")
    
    # Show created tables
    print("\nCreated tables:")
    print("  1. users")
    print("     - id, username, email, age, salary")
    print("  2. posts")
    print("     - id, user_id (FK), title, content, created_date")
    
    return engine


def demonstrate_sessions():
    """
    Demonstrates Session basics and the Unit of Work pattern.
    
    Key Concepts:
    - Session manages database transactions
    - Session tracks object changes (Unit of Work)
    - add() stages objects for insertion
    - commit() persists changes to database
    - rollback() discards changes
    - close() releases connection
    """
    print("\n" + "="*60)
    print("PART 3: Sessions and Unit of Work")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    print("""
Session Lifecycle:
┌──────────────────────────────────────────────────────────┐
│ 1. Create Session    session = Session(engine)           │
│ 2. Add Objects       session.add(user)                   │
│ 3. Flush (optional)  session.flush()  # sends to DB     │
│ 4. Commit            session.commit() # saves changes    │
│ 5. Close             session.close()  # releases conn    │
└──────────────────────────────────────────────────────────┘

Or use context manager (recommended):
    with Session(engine) as session:
        # work with session
        session.commit()
    # automatically closed
    """)
    
    # Create session
    session = Session(engine)
    print("✓ Created session")
    
    # Session is ready to use
    print("✓ Session ready for database operations")
    
    # Close session
    session.close()
    print("✓ Session closed")


def demonstrate_creating_objects():
    """
    Demonstrates creating and inserting objects.
    
    Key Concepts:
    - Create object instances like normal Python objects
    - Objects exist in memory until added to session
    - add() marks object for insertion
    - commit() executes INSERT and assigns IDs
    - Can add multiple objects before committing
    """
    print("\n" + "="*60)
    print("PART 4: Creating Objects (INSERT)")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    # Use context manager (automatically closes session)
    with Session(engine) as session:
        # Example 1: Create single user
        print("\n1. Creating a single user:")
        
        user1 = User(
            username='john_doe',
            email='john@example.com',
            age=30,
            salary=75000.0
        )
        
        print(f"   Created object: {user1}")
        print(f"   ID before commit: {user1.id}")  # None - not yet in database
        
        # Add to session
        session.add(user1)
        print("   ✓ Added to session")
        
        # Commit to database
        session.commit()
        print(f"   ✓ Committed to database")
        print(f"   ID after commit: {user1.id}")  # Auto-generated ID
        
        # Example 2: Create multiple users
        print("\n2. Creating multiple users:")
        
        users = [
            User(username='jane_smith', email='jane@example.com', age=28, salary=82000.0),
            User(username='bob_wilson', email='bob@example.com', age=35, salary=90000.0),
            User(username='alice_brown', email='alice@example.com', age=26, salary=68000.0)
        ]
        
        # Add all users at once
        session.add_all(users)
        print(f"   ✓ Added {len(users)} users to session")
        
        # Commit
        session.commit()
        print("   ✓ Committed all users")
        
        # Show IDs
        for user in users:
            print(f"   {user.username}: ID = {user.id}")


def demonstrate_querying_objects():
    """
    Demonstrates querying objects from database.
    
    Key Concepts:
    - query() starts a query (legacy API)
    - select() is newer syntax (preferred)
    - filter() adds WHERE conditions
    - all() returns list of objects
    - first() returns first object or None
    - one() returns exactly one or raises error
    """
    print("\n" + "="*60)
    print("PART 5: Querying Objects (SELECT)")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    with Session(engine) as session:
        # Example 1: Get all users (legacy API)
        print("\n1. Get all users:")
        
        users = session.query(User).all()
        
        print(f"   Found {len(users)} users:")
        for user in users:
            print(f"   - {user.username:15s} ({user.email})")
        
        # Example 2: Get all users (modern API with select)
        print("\n2. Get all users (modern syntax):")
        
        from sqlalchemy import select
        stmt = select(User)
        users = session.execute(stmt).scalars().all()
        
        print(f"   Found {len(users)} users using select()")
        
        # Example 3: Filter by condition
        print("\n3. Users older than 30:")
        
        users = session.query(User).filter(User.age > 30).all()
        
        for user in users:
            print(f"   {user.username}: {user.age} years old")
        
        # Example 4: Get single user
        print("\n4. Get specific user:")
        
        user = session.query(User).filter(User.username == 'john_doe').first()
        
        if user:
            print(f"   Found: {user.username}")
            print(f"   Email: {user.email}")
            print(f"   Age: {user.age}")
        
        # Example 5: Get by primary key
        print("\n5. Get user by ID:")
        
        user = session.get(User, 1)  # Get user with ID=1
        
        if user:
            print(f"   User ID 1: {user.username}")


def demonstrate_updating_objects():
    """
    Demonstrates updating objects.
    
    Key Concepts:
    - Modify object attributes directly
    - Session tracks changes automatically (dirty tracking)
    - commit() persists changes
    - Can update multiple objects before commit
    """
    print("\n" + "="*60)
    print("PART 6: Updating Objects (UPDATE)")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    with Session(engine) as session:
        # Example 1: Update single object
        print("\n1. Updating user salary:")
        
        # Get user
        user = session.query(User).filter(User.username == 'john_doe').first()
        
        if user:
            print(f"   Before: {user.username} - ${user.salary:,.2f}")
            
            # Update attribute
            user.salary = 80000.0
            
            print(f"   After (in memory): ${user.salary:,.2f}")
            
            # Commit changes
            session.commit()
            print("   ✓ Changes committed to database")
        
        # Example 2: Update multiple attributes
        print("\n2. Updating multiple attributes:")
        
        user = session.query(User).filter(User.username == 'jane_smith').first()
        
        if user:
            print(f"   Before: {user.username}, age {user.age}, ${user.salary:,.2f}")
            
            # Update multiple attributes
            user.age = 29
            user.salary = 85000.0
            
            session.commit()
            print(f"   After: {user.username}, age {user.age}, ${user.salary:,.2f}")


def demonstrate_deleting_objects():
    """
    Demonstrates deleting objects.
    
    Key Concepts:
    - delete() marks object for deletion
    - commit() executes DELETE
    - Can delete multiple objects before commit
    - Deleted objects remain in memory until session closed
    """
    print("\n" + "="*60)
    print("PART 7: Deleting Objects (DELETE)")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    with Session(engine) as session:
        # Count before deletion
        count_before = session.query(User).count()
        print(f"\nUsers before deletion: {count_before}")
        
        # Example: Delete specific user
        print("\n1. Deleting a user:")
        
        user = session.query(User).filter(User.username == 'alice_brown').first()
        
        if user:
            print(f"   Deleting: {user.username}")
            
            # Mark for deletion
            session.delete(user)
            
            # Commit deletion
            session.commit()
            print("   ✓ User deleted from database")
        
        # Count after deletion
        count_after = session.query(User).count()
        print(f"\nUsers after deletion: {count_after}")


def demonstrate_relationships():
    """
    Demonstrates working with relationships.
    
    Key Concepts:
    - Relationships are accessed like attributes
    - Can navigate from parent to children
    - Can navigate from child to parent
    - Lazy loading: related objects loaded on access
    - Cascade: parent operations affect children
    """
    print("\n" + "="*60)
    print("PART 8: Working with Relationships")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    with Session(engine) as session:
        # Example 1: Create user with posts
        print("\n1. Creating user with posts:")
        
        user = session.query(User).filter(User.username == 'john_doe').first()
        
        if user:
            # Create posts for user
            post1 = Post(
                user_id=user.id,
                title='First Post',
                content='Hello World!',
                created_date=date(2024, 1, 15)
            )
            
            post2 = Post(
                user_id=user.id,
                title='Python Tips',
                content='Use list comprehensions!',
                created_date=date(2024, 1, 20)
            )
            
            session.add_all([post1, post2])
            session.commit()
            print(f"   ✓ Created 2 posts for {user.username}")
        
        # Example 2: Access posts through relationship
        print("\n2. Accessing user's posts:")
        
        user = session.query(User).filter(User.username == 'john_doe').first()
        
        if user:
            print(f"   {user.username}'s posts:")
            for post in user.posts:  # Access relationship
                print(f"   - {post.title} ({post.created_date})")
        
        # Example 3: Access user through post
        print("\n3. Accessing post's user:")
        
        post = session.query(Post).first()
        
        if post:
            print(f"   Post: {post.title}")
            print(f"   Author: {post.user.username}")  # Access relationship


def demonstrate_common_patterns():
    """
    Demonstrates common ORM usage patterns.
    """
    print("\n" + "="*60)
    print("PART 9: Common Patterns")
    print("="*60)
    
    engine = create_engine('sqlite:///databases/orm_intro.db', echo=False)
    
    with Session(engine) as session:
        # Pattern 1: Get or create
        print("\n1. Get or create pattern:")
        
        username = 'test_user'
        user = session.query(User).filter(User.username == username).first()
        
        if not user:
            user = User(username=username, email='test@example.com', age=25)
            session.add(user)
            session.commit()
            print(f"   Created new user: {username}")
        else:
            print(f"   User already exists: {username}")
        
        # Pattern 2: Bulk operations
        print("\n2. Bulk query:")
        
        # Get multiple users at once
        usernames = ['john_doe', 'jane_smith', 'bob_wilson']
        users = session.query(User).filter(User.username.in_(usernames)).all()
        
        print(f"   Found {len(users)} users:")
        for user in users:
            print(f"   - {user.username}")
        
        # Pattern 3: Chaining filters
        print("\n3. Chaining filters:")
        
        users = (
            session.query(User)
            .filter(User.age > 25)
            .filter(User.salary > 70000)
            .order_by(User.salary.desc())
            .all()
        )
        
        print(f"   Users (age>25, salary>70k):")
        for user in users:
            print(f"   {user.username}: age {user.age}, ${user.salary:,.2f}")


def main():
    """Main function to run all demonstrations."""
    print("\n")
    print("="*60)
    print("TUTORIAL 07: SQLALCHEMY ORM INTRODUCTION")
    print("="*60)
    
    # Introduction
    introduction_to_orm()
    
    # Setup
    engine = demonstrate_engine_and_tables()
    
    # Sessions
    demonstrate_sessions()
    
    # CRUD operations
    demonstrate_creating_objects()
    demonstrate_querying_objects()
    demonstrate_updating_objects()
    demonstrate_deleting_objects()
    
    # Relationships
    demonstrate_relationships()
    
    # Common patterns
    demonstrate_common_patterns()
    
    print("\n" + "="*60)
    print("SUMMARY")
    print("="*60)
    print("""
Key Concepts Covered:
1. ✓ ORM fundamentals and benefits
2. ✓ Declarative Base and model definition
3. ✓ Session lifecycle and Unit of Work
4. ✓ CRUD operations with ORM
5. ✓ Querying objects (legacy and modern syntax)
6. ✓ Relationships and navigation
7. ✓ Common usage patterns

Core vs ORM Comparison:
┌──────────────────────┬────────────────────────┐
│ Core                 │ ORM                    │
├──────────────────────┼────────────────────────┤
│ SQL-focused          │ Object-focused         │
│ Explicit queries     │ Pythonic syntax        │
│ Fine-grained control │ Higher abstraction     │
│ Better for bulk ops  │ Better for objects     │
└──────────────────────┴────────────────────────┘

Important Concepts:
✓ Models = Python classes = Database tables
✓ Sessions manage transactions and track changes
✓ Relationships enable object navigation
✓ ORM provides automatic SQL generation
✓ Can mix Core and ORM in same application

Next Steps:
- Practice: Create your own models and relationships
- Next Tutorial: 08_orm_relationships.py
- Exercise: Complete exercise_07_orm_basics.py
    """)


if __name__ == "__main__":
    main()
